-- fornecer sid, serial, nome e valor do parametro, como no exemplo abaixo:
exec dbms_system.SET_INT_PARAM_IN_SESSION(237, 49369, 'SORT_AREA_SIZE',131072);