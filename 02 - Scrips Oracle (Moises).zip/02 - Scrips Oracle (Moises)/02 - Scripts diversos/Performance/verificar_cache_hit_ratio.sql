Select sum(getmisses) / sum(gets) "Miss ratio" 
From v$rowcache;

