-- ver table fetch continued row
select name, value from v$sysstat  where name like '%table%';