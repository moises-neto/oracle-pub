SELECT rtrim ('      Aprenda PL/SQL          ') FROM dual;

SELECT rtrim('Aprenda PL/SQL', 'PL/SQL') FROM dual;

SELECT rtrim('Aprenda Oracle_PL/SQL', 'SQL/Oracle_PL') FROM dual;

SELECT rtrim('Aprenda Oracle_PL/SQL', 'Aprenda') FROM dual;

SELECT ltrim ('      Aprenda PL/SQL         ') FROM dual;

SELECT ltrim('Aprenda Oracle_PL/SQL', 'SQL/Oracle_PL') FROM dual;

SELECT ltrim('Aprenda Oracle_PL/SQL', 'Aprenda') FROM dual;

SELECT trim ('   Aprenda PL/SQL   ') FROM dual;

SELECT trim(' '  from  '   Aprenda PL/SQL   ') FROM dual;

SELECT trim (leading '0' from '0001230') FROM dual;

SELECT trim(trailing 'x' from 'Aprendax') FROM dual;

SELECT trim (both 'x' from 'xxxAprendaxxx') FROM dual;