-- listar usuarios que possuem privs de SYSDBA, SYSOPER e outros privs administrativos:
select * from SYS.V_$PWFILE_USERS