
--LEFT JOIN
select * from emp, dept where emp.dept_id=dept.dept_id(+)
--consulta todos os dados que tem na tabela emp, mesmo não tendo na tabela dept.

--RIGHT JOIN 

select * from emp, dept where emp.dept_id(+)=dept.dept_id
--consulta todos os dados que tem na tabela dept, mesmo não tendo na tabela emp .


--https://qastack.com.br/programming/4020786/oracle-operator