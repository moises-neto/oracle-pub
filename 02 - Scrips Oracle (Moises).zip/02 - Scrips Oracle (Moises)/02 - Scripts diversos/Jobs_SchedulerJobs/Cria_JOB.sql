--APAGA JOB
BEGIN
  BEGIN
    SYS.DBMS_SCHEDULER.DROP_JOB('job_criarquivo'); --NOME DO JOB
    EXCEPTION WHEN OTHERS THEN NULL;
  END;


--CRIA JOB  
 dbms_scheduler.create_job(
  job_name        => 'JOB_CRIARQUIVO',
  job_type        => 'PLSQL_BLOCK',
  job_action      => 'CRIARARQUIVOTXT', --PROCEDURE
  ENABLED        => TRUE,
  AUTO_DROP       => TRUE,
  START_DATE      => SYSDATE, 
  REPEAT_INTERVAL => 'FREQ=SECONDLY; BYSECOND=0,10,20,30,40,50'); --EXECUTA A CADA 10 SEGUNDOS
END;

/*repeat_interval  =>  'FREQ=SECONDLY;INTERVAL=30'        -- A cada 30 segundos
repeat_interval  =>  'FREQ=HOURLY;INTERVAL=1'           -- a cada hora
repeat_interval  =>  'FREQ=MONTHLY;BYDAY=1'             -- todo dia primeiro do mês
repeat_interval  =>  'FREQ=DAILY;BYHOUR=22;BYMINUTE=30' -- todos os dias às 22:30
repeat_interval  =>  'FREQ=MINUTELY;INTERVAL=10'        -- a cada 10 minutos

*/