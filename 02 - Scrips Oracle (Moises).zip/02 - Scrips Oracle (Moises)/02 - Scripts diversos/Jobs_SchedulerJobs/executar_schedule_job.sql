begin
    DBMS_SCHEDULER.RUN_JOB ('&NOME_JOB');
end;