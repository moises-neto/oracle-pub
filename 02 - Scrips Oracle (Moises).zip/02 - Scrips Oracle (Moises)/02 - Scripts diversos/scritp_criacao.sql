-- Cria tablespace p/ dados
--drop tablespace tbs_dados;

create tablespace tbs_dados
datafile 'C:\oraclexe\app\oracle\oradata\tbd_dados.dbf' size 300M reuse
autoextend on next 10M maxsize 500M
online;


-- Cria usuario (dono das tabelas)
create user dbamoises --usuario
identified by "simulation"  --senha
default tablespace tbs_dados
temporary tablespace temp;

-- Cria e define a "role" de privilegios (perfil)
create role perfil_desenv;

grant
create cluster,
create database link,
create procedure,
create session,
create sequence,
create synonym,
create table,
create any type,
create trigger,
create view
to perfil_desenv;



grant alter session to perfil_desenv;


grant create trigger to dbamoises;


grant perfil_desenv to dbamoises;

grant unlimited tablespace to dbamoises;

create or replace DIRECTORY dir_laudo AS 'C:\teste';


DECLARE 

arquivo_saida utl_file.File_Type;
Cursor c is
select ds_laudo, dt_laudo from laudo;

BEGIN

arquivo_saida := UTL_File.Fopen('DIR_LAUDO','laudo.txt', 'w');
for linha in c Loop
Utl_file.Put_line(arquivo_saida, linha.ds_laudo||'-'|| linha.dt_laudo);
utl_file.Put_line(arquivo_saida, linha.dt_laudo);
end loop;
utl_File.Fclose(arquivo_saida);
DBMS_OUTPUT.PUT_LINE('Arquivo geradi cin sucesso');

END;
select * from all_directories

   


utl_file.












