-- ver coluna auto optimizer stats collection = enabled (11g)
select client_name,status from dba_autotask_client; 