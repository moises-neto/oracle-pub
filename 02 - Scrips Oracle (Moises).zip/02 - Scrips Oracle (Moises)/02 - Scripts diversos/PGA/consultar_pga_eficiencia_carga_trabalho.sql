select    * 
from      v$pgastat
where     name = 'cache hit percentage'