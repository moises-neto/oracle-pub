-- lista de objetos auditados (com os respectivos privil�gios sendo auditados)
select  * 
from    DBA_OBJ_AUDIT_OPTS;