CREATE VIEW resume_location AS
    SELECT
        r.region_name       AS continente,
        c.country_name      AS pais,
        c.country_name      AS cidade,
        l.street_address    AS endereco,
        l.postal_code       AS cep
    FROM
             countries c
        INNER JOIN regions    r ON c.region_id = r.region_id
        INNER JOIN locations  l ON l.country_id = c.country_id
    ORDER BY
        1;

SELECT
    *
FROM
    resume_location;

SELECT
    *
FROM
    employees
WHERE
    ROWNUM <= 10
    
  INSERT INTO EMPLOYEES 
  VALUES (EMPLOYEES_SEQ.nextval,'MOISÉS','NETO','MOISESSOUZA108@GMAIL.COM','996796838','01/07/2000','IT_PROG',5000,NULL,NULL,210)

    
    SELECT * FROM departmentS
    
    SELECT * FROM JOBS






