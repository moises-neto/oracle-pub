create tablespace tbs_empresa
datafile 'C:\oraclexe\app\oracle\oradata\tbd_dados.dbf' size 100M reuse
autoextend on next 10M maxsize 200M
online;