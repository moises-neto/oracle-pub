select * from v$database;

select * from v$tablespace;

select * from all_users;

select * from all_tables;

select * from user_tables;

SELECT * FROM TBS_EMPRESA;

--
DECLARE
       vCONTADOR INTEGER := 0;
BEGIN
       LOOP
         vCONTADOR := vCONTADOR +1;
         DBMS_OUTPUT.PUT_LINE(vCONTADOR);
         EXIT WHEN vCONTADOR = 1000;  
       END LOOP;
       DBMS_OUTPUT.PUT_LINE('FIM DO LOOP!');
END;

--
DECLARE
       TYPE TIPO IS TABLE OF VARCHAR2(30) INDEX BY VARCHAR(2);
       UF_CAPITAL TIPO;
       
BEGIN
       uf_capital('SP') := 'S�O PAULO';
       
       dbms_output.put_line(UF_CAPITAL('SP'));
END;

--
  
SELECT * FROM CD_CLIENTE;

--CURSOSRES
DECLARE
       vNOME CD_CLIENTE.NOME%TYPE;
       vID CD_CLIENTE.ID_CLIENTE%TYPE;
       
       CURSOR c1 IS
       SELECT ID_CLIENTE, NOME
       FROM CD_CLIENTE;
BEGIN
       OPEN c1;
        LOOP 
         FETCH c1 INTO vID, vNOME;
         EXIT WHEN c1%ROWCOUNT > 10 OR c1%NOTFOUND;
         dbms_output.put_line('C�DIGO: ' || LPAD(vID, 4,'0') || ' - ' || 'NOME: ' || vNOME);
        END LOOP;
       
       CLOSE c1;
END;
-- CURSORES

DECLARE
       CURSOR c1 IS
       SELECT * FROM CD_CLIENTE;
       vREG c1%ROWTYPE;
BEGIN
       OPEN c1;
        LOOP 
         FETCH c1 INTO vREG;
         EXIT WHEN c1%ROWCOUNT > 10 OR c1%NOTFOUND;
         dbms_output.put_line('C�DIGO: ' || LPAD(vREG.ID_CLIENTE, 4,'0') 
         || ' - ' || 'NOME: ' || vREG.NOME);
        END LOOP;
       
       CLOSE c1;
END;


--CURSORES - MELHOR MANEIRA COM O COMANDO FOR = PARA QUANDO N�O ENCONTRAR MAIS REGISTROS

DECLARE
           CURSOR c1 IS
           SELECT * FROM CD_CLIENTE;
           vREG CD_CLIENTE%ROWTYPE;
BEGIN
           FOR vREG IN c1
             LOOP
               dbms_output.put_line('Codigo: ' || LPAD(vREG.ID_CLIENTE, 5, '0') 
               || ' - ' || 'NOME: ' || vREG.NOME);

            END LOOP;       
END;

-- SEM CURSORES, USADO QUANDO O SELECT � MENOR

DECLARE
      vREG CD_CLIENTE%ROWTYPE;
BEGIN
           FOR vREG IN (SELECT * FROM CD_CLIENTE)
             LOOP
               dbms_output.put_line('Codigo: ' || LPAD(vREG.ID_CLIENTE, 5, '0') 
               || ' - ' || 'NOME: ' || vREG.NOME);

            END LOOP;       
END;

--CURSOR BLOQUEANDO COLUNA PARA ALTERA��O
DECLARE
       CURSOR c1 (pID_CLIENTE NUMBER) IS
       SELECT * FROM CD_CLIENTE
       WHERE ID_CLIENTE = pID_CLIENTE
       FOR UPDATE OF NOME NOWAIT; -- BLOQUEIA A COLUNA NOME DE ALTERA��ES
      vREG c1%ROWTYPE; 
BEGIN
       OPEN c1 (&CODIGO);
       FETCH c1 INTO vREG;
        dbms_output.put_line('Codigo: ' || LPAD(vREG.ID_CLIENTE, 5, '0') 
               || ' - ' || 'NOME: ' || vREG.NOME);
       CLOSE c1; -- LIBERA A COLUNA NOME PARA ALTERA��ES
END;

--CURSOR UPDATE NOME PARA PRIMEIRA LETRA DE CADA NOME EM MAIUSCULA;

DECLARE 
         CURSOR c1 IS
         SELECT NOME FROM CD_CLIENTE FOR UPDATE;
         
         vREG_CLIENTE c1%ROWTYPE; 
BEGIN
         FOR vREG_CLIENTE IN c1
           LOOP
             UPDATE CD_CLIENTE
             SET NOME = INITCAP(vREG_CLIENTE.NOME)
             WHERE CURRENT OF c1;
             DBMS_OUTPUT.put_line('Nome: ' || INITCAP(vREG_CLIENTE.NOME));
         END LOOP;     
END;

select * from cd_cliente;

rollback;
---------------------------blocos anonimos da tablespace TBS_EMPRESA---------------------------
DECLARE
     vNOME VARCHAR(50);
     vCPF VARCHAR(15);
     vDATA DATE;
BEGIN
     SELECT NOME_CLIENTE, CPF, TO_CHAR(DT_CADASTRO, 'DD/MM/YYYY')
     INTO vNOME, vCPF, vDATA
     FROM CD_CLIENTE
     WHERE ID_CLIENTE = &CODIGO;
     
     DBMS_OUTPUT.PUT_LINE ('O NOME do CLIENTE �: ' || vNome);
     DBMS_OUTPUT.PUT_LINE ('O CPF do CLIENTE �: ' || vCPF);
     DBMS_OUTPUT.PUT_LINE ('O CLIENTE foi cadastrado em: ' || vDATA);
END;


DECLARE
       vID_CLIENTE INTEGER;
       vNOME CD_CLIENTE.NOME_CLIENTE%TYPE := &NOME;
       vCPF CD_CLIENTE.CPF%TYPE := &CPF;
       vTEL CD_CLIENTE.TELEFONE%TYPE := &TELEFONE;
       vENDERECO CD_CLIENTE.ENDERECO%TYPE := &ENDERECO;
       vBAIRRO CD_CLIENTE.BAIRRO%TYPE := &BAIRRO;
       vCIDADE CD_CLIENTE.CIDADE%TYPE := &CIDADE;
       vESTADO CD_CLIENTE.ESTADO%TYPE := &ESTADO;
BEGIN
       SELECT SEQ_CLIENTE.NEXTVAL
       INTO vID_CLIENTE
       FROM DUAL;
       
       INSERT INTO CD_CLIENTE(ID_CLIENTE, NOME_CLIENTE, CPF, TELEFONE,
       ENDERECO, BAIRRO, CIDADE, ESTADO)
       
       VALUES(vID_CLIENTE, vNOME, vCPF, vTEL, vENDERECO, vBAIRRO, vCIDADE, vESTADO);
       
       DBMS_OUTPUT.PUT_LINE('O CADASTRO: ' || vID_CLIENTE || ' FOI REALIZADO!');

END;

--------------------fim blocos anonimos tablespace empresa-----



