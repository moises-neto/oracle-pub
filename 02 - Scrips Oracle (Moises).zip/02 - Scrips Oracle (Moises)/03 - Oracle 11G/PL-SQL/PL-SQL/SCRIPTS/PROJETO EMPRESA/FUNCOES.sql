CREATE OR REPLACE FUNCTION FC_CONSULTA_CLIENTE(pID NUMBER) RETURN VARCHAR2

IS
     pNOME VARCHAR2(50);  
BEGIN
     SELECT NOME 
     INTO pNOME
     FROM CD_CLIENTE
     WHERE pID = ID_CLIENTE;    
  
RETURN(pNOME);
END;

DECLARE
vID NUMBER := &CODIGO;
vNOME vARCHAR2(50);
BEGIN
      vNOME := FC_CONSULTA_CLIENTE(vID);
      dbms_output.put_line('Nome do Cliente: ' || vNOME);
  
END;

CREATE OR REPLACE FUNCTION FC_EXISTE_CLIENTE(pID IN CD_CLIENTE.ID_CLIENTE%TYPE)
RETURN BOOLEAN

IS
       vCLIENTE NUMBER(10);
BEGIN
       SELECT ID_CLIENTE
       INTO vCLIENTE
       FROM CD_CLIENTE
       WHERE ID_CLIENTE = pID;
       RETURN (TRUE);
       
       EXCEPTION
         WHEN OTHERS THEN
         RETURN (FALSE);
  
END;
         
DECLARE
         vCODIGO NUMBER(10) := &CODIGO;
BEGIN
         IF FC_EXISTE_CLIENTE(vCODIGO) THEN
           dbms_output.put_line('Cadastro encontrado!');
           
         ELSE
           dbms_output.put_line('Cadastro N�O encontrado!');
         END IF;       
        PUT       
END;
