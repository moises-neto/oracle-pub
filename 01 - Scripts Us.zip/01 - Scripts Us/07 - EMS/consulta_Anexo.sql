Select * from custom.Vw_Opme_Ems_Caminho_Anexo c
where c.Nr_Transacao = 2102000018636
