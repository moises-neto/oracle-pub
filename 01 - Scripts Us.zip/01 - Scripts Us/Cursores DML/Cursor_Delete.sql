DECLARE

  CURSOR cDados
  
  IS
  
    SELECT a.campo1
    
      FROM Tabela a
    
       FOR UPDATE OF a.campo1;

BEGIN

  FOR x IN cDados
  
   LOOP
  
    DELETE Tabela a
    
     WHERE CURRENT OF cDados;
  
  END LOOP;

  -- COMMIT;
  /*  EXCEPTION
  WHEN DUP_VAL_ON_INDEX THEN
    NULL;*/

Exception
  When Others Then
    Rollback;
    Raise_Application_Error(-20001,
                            'Falha: ' || Sqlerrm || 'campo: ' || x.campo1);
End;

END;
