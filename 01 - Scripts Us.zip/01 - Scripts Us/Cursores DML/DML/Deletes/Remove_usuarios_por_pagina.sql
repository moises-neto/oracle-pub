--Consultas
SELECT UPP.CD_USUARIO_PORTAL
  FROM DBACP.USUARIO_PORTAL_PAGINA UPP
  JOIN DBACP.PAGINA P
    ON P.CD_PAGINA = UPP.CD_PAGINA
 WHERE P.DS_TITULO IN ('75 - CONTAS MEDICAS HMS')
      
   AND UPP.CD_USUARIO_PORTAL IN ('ALTEIXEIRA', 'SILIMA')
       


---------------
SELECT *
  FROM DBACP.USUARIO_PORTAL_PAGINA UPP
 WHERE UPP.CD_USUARIO_PORTAL IN
       (SELECT u.cd_usuario
          from usuarios@ormvprd u
         where u.ds_observacao in ('75 - CONTAS MEDICAS HMS')
           and u.sn_ativo = 'S')
   AND UPP.CD_PAGINA IN
       (SELECT P.CD_PAGINA
          FROM DBACP.PAGINA P
         WHERE P.DS_TITULO IN ('Gest�o � Vista - Assistencial'))
--Blocos anonimos
-- Exclui usu�rios de uma determinada p�gina

DELETE DBACP.USUARIO_PORTAL_PAGINA UPP
 WHERE UPP.CD_USUARIO_PORTAL IN ('RROSOLEN',
                                 'BTAVARES',
                                 'GMONCAYO',
                                 'FADIAS',
                                 'JBASTOS',
                                 'MABRANCO',
                                 'KASILVA',
                                 'SMORAIS',
                                 'JESILVA',
                                 'GGONCALVES',
                                 'ALAURA',
                                 'VERSILVA',
                                 'TLEONCIO',
                                 'GSILVEIRA',
                                 'FEFOGACA',
                                 'FCFERREIRA',
                                 'KPIOVEZANI',
                                 'PMANHANELLI',
                                 'SINEVES',
                                 'JUPAIXAO',
                                 'JUARRUDA',
                                 'PHMARQUES',
                                 'EFERNANDES',
                                 'TPONSTINNICOFF',
                                 'VBALDASSIN',
                                 'ANACARSILVA',
                                 'JONSOUZA',
                                 'CAMIRIBEIRO',
                                 'PMARQUES',
                                 'JWATANABE',
                                 'FLEME',
                                 'JVAZ',
                                 'AMOMI',
                                 'MYAMADA',
                                 'APAIXAO',
                                 'DAYBARROS',
                                 'KATLIMA',
                                 'EPROENCA',
                                 'DHIPOLITO',
                                 'JSOUZA',
                                 'ABAENA',
                                 'LACAMARGO',
                                 'MFIORAVANTI',
                                 'FGUERREIRO',
                                 'LUCTEIXEIRA',
                                 'RARIBEIRO',
                                 'RVILALON',
                                 'ANEEMEH',
                                 'LFRANCA',
                                 'MILCAMPOS')
   AND UPP.CD_PAGINA IN
       (SELECT P.CD_PAGINA
          FROM DBACP.PAGINA P
         WHERE P.CD_PAGINA in (165))


--Exclui todos os usu�rios por setor das p�ginas no painel de indicadores.

 DELETE DBACP.USUARIO_PORTAL_PAGINA UPP
  WHERE UPP.CD_USUARIO_PORTAL IN
        (SELECT u.cd_usuario
           from usuarios@ormvprd u
          where u.ds_observacao in ('75 - CONTAS MEDICAS HMS')
            and u.sn_ativo = 'S')
    AND UPP.CD_PAGINA IN
        (SELECT P.CD_PAGINA FROM DBACP.PAGINA P WHERE P.CD_PAGINA IN (542))
       
       
---remove todas as p�ginas de usu�rios que n�o possuem licen�a
 DELETE DBACP.USUARIO_PORTAL_PAGINA UPP
  WHERE UPP.CD_USUARIO_PORTAL IN
        (SELECT P.CD_USUARIO_PORTAL
           FROM DBACP.USUARIO_PORTAL P
          WHERE P.CD_USUARIO_PORTAL NOT IN
                (SELECT SL.CD_USUARIO_PORTAL
                   FROM DBACP.USUARIO_SISTEMA_LICENCA SL))
       
--DBACP.PRC_IMPORTA_USUARIO_MV2000



