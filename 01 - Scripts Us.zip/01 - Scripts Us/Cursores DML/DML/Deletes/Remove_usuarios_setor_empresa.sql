
--- DELETETANDO TODOS OS USU�RIOS POR SETOR A EMPRESA 2.---
DELETE
  FROM DBAMV.USUARIO_MULTI_EMPRESA M
 WHERE M.cd_id_usuario IN (select u.cd_usuario
                             from dbasgu.usuarios u
                            where u.ds_observacao IN ('OBSERVACAO DO MV')
                              AND u.sn_ativo = 'S')
   AND M.CD_MULTI_EMPRESA = 2;
   


SELECT U.CD_USUARIO,
       INITCAP(U.NM_USUARIO) AS MEDICO,
       U.CD_PRESTADOR AS PRESTADOR,
       U.DS_OBSERVACAO AS SETOR,
       U.DS_EMAIL,
       DECODE(M.CD_MULTI_EMPRESA, 2, 'NAIS') EMPRESA
  FROM dbasgu.usuarios u
 INNER JOIN DBAMV.USUARIO_MULTI_EMPRESA M
    ON U.CD_USUARIO = M.CD_ID_USUARIO
 WHERE U.DS_OBSERVACAO LIKE UPPER('%MEDICO%')
   AND U.SN_ATIVO = 'S'
   AND M.CD_MULTI_EMPRESA = 2;
