select * from all_users a where a.username = 'FRSOARES'


SELECT U.CD_USUARIO, U.SN_ATIVO
 FROM DBASGU.USUARIOS@ORMVPS U
 INNER JOIN DBASGU.USUARIOS UP
ON UP.CD_USUARIO = U.CD_USUARIO
WHERE U.SN_ATIVO = 'S'
AND UP.SN_ATIVO = 'N' 


SELECT * FROM DBASGU.USUARIOS@ORMVPS U, DBASGU.USUARIOS UP
WHERE U.CD_USUARIO = UP.CD_USUARIO
AND U.SN_ATIVO


select U.CD_USUARIO, U.NM_USUARIO, U.DS_OBSERVACAO, E.CD_MULTI_EMPRESA from dbasgu.usuarios u 
inner join dbamv.usuario_multi_empresa e
on e.cd_id_usuario = u.cd_usuario
where u.sn_ativo = 'S'

BEGIN
  FOR C IN (SELECT U.CD_USUARIO, U.SN_ATIVO
              FROM DBASGU.USUARIOS@ORMVPS U
             INNER JOIN DBASGU.USUARIOS UP
                ON UP.CD_USUARIO = U.CD_USUARIO
             WHERE U.SN_ATIVO = 'S'
               AND UP.SN_ATIVO = 'N') LOOP
    BEGIN
      UPDATE DBASGU.USUARIOS@ORMVPS U
         SET U.SN_ATIVO = 'N'
       WHERE U.CD_USUARIO = C.CD_USUARIO;
    END;
    END LOOP;
  END;

