--select * from inovapar.iun_laboratorio i where i.atd_senha = '1329237'

update inovapar.iun_laboratorio i set i.reg_status = 1, i.cont_updt_mv = 1, i.cont_updt_vedocs = 1, i.reg_dahora_atualizacao = sysdate 
where i.exam_exec_cod in (7746808, 7746810)
