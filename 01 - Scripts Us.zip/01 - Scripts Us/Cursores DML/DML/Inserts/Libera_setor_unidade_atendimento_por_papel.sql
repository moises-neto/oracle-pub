BEGIN

FOR U IN (SELECT U.CD_USUARIO
          FROM DBASGU.PAPEL_USUARIOS U
         WHERE U.CD_PAPEL = 164
           AND U.CD_USUARIO IN (SELECT U.CD_USUARIO
                                  FROM DBASGU.USUARIOS U
                                 WHERE U.SN_ATIVO = 'S'))
                                 
    LOOP
      
    BEGIN
      INSERT INTO DBAMV.Usuario_Setor
      VALUES (119, U.CD_USUARIO);
      
      EXCEPTION
        WHEN DUP_VAL_ON_INDEX THEN
        NULL;

      
    END;
    
    END LOOP;                             
END;



select * from (
SELECT U.CD_USUARIO
          FROM DBASGU.PAPEL_USUARIOS U
         WHERE U.CD_PAPEL = 164
           AND U.CD_USUARIO IN (SELECT U.CD_USUARIO
                                  FROM DBASGU.USUARIOS U
                                 WHERE U.SN_ATIVO = 'S')) x,
                                 
                                 (select * from DBAMV.Usuario_Setor ) y
                                 where y.nm_usuario = x.cd_usuario
                                 and y.cd_setor = 119





