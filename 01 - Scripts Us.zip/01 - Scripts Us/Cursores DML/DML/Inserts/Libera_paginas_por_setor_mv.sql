BEGIN
  FOR U NOT IN (SELECT up.cd_usuario_portal
              FROM DBACP.USUARIO_PORTAL up
             WHERE UP.CD_USUARIO_PORTAL IN
                   (SELECT u.cd_usuario
                      from usuarios@ormvprd u
                     where u.ds_observacao in ('222 - TI - SUPORTE - HMS')
                       and u.sn_ativo = 'S')) LOOP
    BEGIN
      INSERT INTO DBACP.USUARIO_PORTAL_PAGINA
      VALUES
        (DEFAULT, 419, U.CD_USUARIO_PORTAL, 'N');
    EXCEPTION
      WHEN DUP_VAL_ON_INDEX THEN
        NULL;
      
    END;
  
  END LOOP;
END;

-------------------------------------------------------------------------------------------------    
       AND UPP.CD_PAGINA IN
       (SELECT P.CD_PAGINA FROM DBACP.PAGINA P 
       WHERE P.CD_PAGINA IN (435))
       
       select * from DBACP.USUARIO_PORTAL_PAGINA por
        where por.cd_usuario_portal = 'MNETO' FOR UPDATE
    
        
        SELECT UPP.CD_USUARIO_PORTAL, UPP.CD_PAGINA, UPP.CD_USUARIO_PORTAL FROM DBACP.USUARIO_PORTAL_PAGINA UPP 
 WHERE UPP.CD_USUARIO_PORTAL IN (SELECT u.cd_usuario from usuarios@ormvprd u
        where u.ds_observacao in ('222 - TI - SUPORTE - HMS')
        and u.sn_ativo = 'S') 
        AND UPP.CD_PAGINA = 419 FOR UPDATE
   
        
 
 SELECT DISTINCT up.cd_usuario_portal
   FROM DBACP.USUARIO_PORTAL up
  inner join dbacp.USUARIO_PORTAL_PAGINA UPP
     on upp.cd_usuario_portal = up.cd_usuario_portal
     INNER JOIN DBASGU.USUARIOS@ORMVPRD U
     ON U.CD_USUARIO = UP.CD_USUARIO_PORTAL
     WHERE UPP.CD_PAGINA IN 419
     
  AND U.DS_OBSERVACAO IN ('222 - TI - SUPORTE - HMS')
  
  
  
    and up.cd_usuario_portal in
        (SELECT U.CD_USUARIO
           FROM DBASGU.USUARIOS@ORMVPRD U
          WHERE U.DS_OBSERVACAO IN ('222 - TI - SUPORTE - HMS'))
          
          
          
  
  (SELECT UPP.CD_USUARIO_PORTAL
           FROM DBACP.USUARIO_PORTAL_PAGINA UPP
           INNER JOIN usuarios@ormvprd u
           ON U.CD_USUARIO = UPP.cd_usuario_portal
          WHERE UPP.CD_PAGINA NOT IN (419)
          AND u.ds_observacao in ('222 - TI - SUPORTE - HMS'))
          
          
    
     
        
        
        
        
        
        
