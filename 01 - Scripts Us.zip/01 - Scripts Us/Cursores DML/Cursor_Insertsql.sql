DECLARE

BEGIN

 FOR F IN (SELECT S.CD_SETOR FROM SETOR S WHERE S.SN_ATIVO = 'S')
  
   LOOP
    BEGIN
    
      INSERT INTO DBAMV.USUARIO_UNID_INT
        (CD_UNID_INT, CD_ID_USUARIO, CD_SETOR)
      VALUES
        (NULL, :NEW.CD_USUARIO, F.CD_SETOR);
    
    EXCEPTION
      WHEN DUP_VAL_ON_INDEX THEN
        NULL;
      
    END;
  END LOOP;

Exception
  When Others Then
    Rollback;
    Raise_Application_Error(-20001,
                            'Falha: ' || Sqlerrm || 'campo: ' || x.campo1);
End;

END;
