DECLARE

  CURSOR cDados
  
  IS
  
    SELECT *
    
      FROM dbaps.IMPORT_PROCEDIMENTO_1 ip; 
     --  FOR UPDATE;

BEGIN

  FOR x IN cDados
  
   LOOP
  
    UPDATE dbaps.procedimento p
    
       SET p.tp_valor_pago_padrao = x.tp_valor_pago_padrao,
           p.tp_valor_pago_padrao_inter = x.tp_valor_pago_padrao_inter
         Where p.cd_procedimento = x.cd_procedimento; 
           
  END LOOP;

  -- COMMIT;
  /*  EXCEPTION
  WHEN DUP_VAL_ON_INDEX THEN
    NULL;*/

Exception
  When Others Then
    Rollback;
    Raise_Application_Error(-20001,
                            'Falha: ' || Sqlerrm);

END;

Select ip.cd_procedimento,
       ip.tp_valor_pago_padrao,
       ip.tp_valor_pago_padrao_inter
  from dbaps.IMPORT_PROCEDIMENTO_1 ip

minus
Select p.cd_procedimento,
       p.tp_valor_pago_padrao,
       p.tp_valor_pago_padrao_inter
  from dbaps.procedimento p
