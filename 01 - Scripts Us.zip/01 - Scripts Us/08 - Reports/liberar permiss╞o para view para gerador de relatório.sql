grant select on vw_proposta_pf to DBAMV;
grant select on vw_proposta_pf to MV2000;
