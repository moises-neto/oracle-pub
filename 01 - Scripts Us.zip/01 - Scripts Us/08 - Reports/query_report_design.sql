Select * From remweb.report rp
where rp.report_id = '750' 


         REMWEB.ANALYZED_QUERY 
