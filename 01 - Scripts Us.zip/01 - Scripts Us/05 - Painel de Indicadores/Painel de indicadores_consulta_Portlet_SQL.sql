select t.ds_sql, T.*, rowid
  from DBACP.PORTLET_SQL t
 where (t.ds_sql LIKE '%2013%' or t.ds_sql LIKE '%2007%' or t.ds_sql LIKE '%0189%' or t.ds_sql LIKE '%0289%')
   AND T.CD_DATA_SOURCE_SQL = 49

Select * from dbacp.lista_valores l
where (l.ds_sql LIKE '%2013%' or l.ds_sql LIKE '%2007%' or l.ds_sql LIKE '%0189%' or l.ds_sql LIKE '%0289%')
and l.CD_DATA_SOURCE_SQL = 49





