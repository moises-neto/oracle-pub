CALL CUSTOM.PRC_LIBERA_PAGINA_USUARIO(V_USUARIO => 'BEFREITAS', V_PAGINA => 688);

Select rowid, p.*  From dbacp.usuario_portal_papel p where p.cd_usuario_portal = '11551'
where p.cd_usuario_portal in ('FRASOUZA',
'GABRSANTOS',
'LALCOLEA',
'FPIATTI',
'MOSOUZA',
'BEFREITAS'
)
and


Select * From dbacp.papel pa
where pa.nm_papel like '%Cadastro%'
