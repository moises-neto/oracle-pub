--USER: dbaportal
--DATA: BI_MV

Select p.*, rowid From dbacp.portlet_sql p   
Where upper(p.ds_sql) like upper('%@ORMVPS%')
And P.CD_DATA_SOURCE_SQL = 30

Select * From DBACP.DATA_SOURCE_SQL


Select * From dbacp.portlet p Where p.cd_portlet =
5834


Select * From custom.log_portlet_sql pr Where pr.cod_portlet =
5834;


Select * From dbacp.param_link_portlet_sql;

Select * From dbacp.parametro_jsp t

Where t.cd_portlet = 6085;

Select * From dbacp.configuracao_parametros_sql;


Select Distinct t.Cd_Portlet,
       --  T.CD_USUARIO_PORTAL,
       -- T.ZONEID AS LOCAL,
       Por.Ds_Titulo  As Portlet,
       Por.Dt_Criacao As Dt_Criacao_Portlet,
       -- POR.CD_USUARIO_CRIADOR,
     --  Papel.Nm_Papel,
      Pag.Ds_Titulo  As Pagina,
       p.Ds_Titulo    As Aba
      

  From Dbacp.Portlet_Configuracao t
 Inner Join Dbacp.Portlet Por
    On Por.Cd_Portlet = t.Cd_Portlet
 Inner Join Dbacp.Portlet_Sql Ps
    On Por.Cd_Portlet = Ps.Cd_Portlet
 Inner Join Dbacp.Coluna c
    On t.Cd_Coluna = c.Cd_Coluna
 Inner Join Dbacp.Pasta p
    On p.Cd_Pasta = c.Cd_Pasta
 Inner Join Dbacp.Usuario_Portal_Pagina Upp
    On Upp.Cd_Usuario_Portal_Pagina = p.Cd_Usuario_Portal_Pagina
 Inner Join Dbacp.Pagina Pag
    On Pag.Cd_Pagina = Upp.Cd_Pagina
 Inner Join Dbacp.Portlet_Papel Pp
    On Pp.Cd_Portlet = Por.Cd_Portlet
 Inner Join Dbacp.Papel Papel
    On Papel.Cd_Papel = Pp.Cd_Papel
 Where 1 = 1
   And (Upper(Ps.Ds_Sql) Like Upper('%@ORMVPS%') Or  Upper(Ps.Ds_Sql) Like Upper('%@ORCOOP%'))
   And Ps.Cd_Data_Source_Sql = 30


