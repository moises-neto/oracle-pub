select l.username, l.nm_usuario, l.machine, count(l.machine) licensas 
from custom.ige_vw_licencas l
group by l.nm_usuario, l.username, l.machine
having count(l.machine) > 1
order by count(l.machine)

select l.username, count(*) QT_LICENSAS from custom.ige_vw_licencas l
group by l.username
having count(*) > 1

UNION

select UPPER(l.nm_usuario) as nm_usuario,
       l.username,
       count(l.nm_usuario) QT_LICENSAS
  from custom.ige_vw_licencas l
 group by l.nm_usuario, l.username
having count(l.nm_usuario) > 1



group

union

select l.machine, count(*) QT_LICENSAS from custom.ige_vw_licencas l
having count(*) > 1


select x.* from
(select l.username, L.nm_usuario, L.machine, 1 id from custom.ige_vw_licencas l
union
select 'TOTAL:' USERNAME,
 '' NM_USUARIO,
 TO_CHAR(COUNT(*)) MACHINE, 
 2 id from custom.ige_vw_licencas l) x
order by id, x.username 

select distinct username,
                (select u.nm_usuario
                   from dbasgu.usuarios u
                  where u.cd_usuario = username) nm_usuario,
                MACHINE
  from v$session@medora
 where username is not null
   and upper(status) not like '%KILLED%'
   --and username in ('INOVA', 'PACSADMIN')
 order by username 
 
SELECT DISTINCT sm.username,
       count(sm.username),
       (SELECT u.nm_usuario
          FROM DBASGU.USUARIOS u
         WHERE sm.username = u.cd_usuario) as NM_USUARIO,
       (SELECT u.ds_observacao
          FROM DBASGU.USUARIOS u
         WHERE sm.username = u.cd_usuario) as SETOR, 
         sm.client_identifier,
       sm.status
  FROM V_DOLLAR_SESSION@medora sm, mitarbeiter@medora M
 WHERE sm.USERNAME = M.MITARBEITER_ORACLE_USER_NAME
   and sm.status not in 'KILLED'
   AND sm.client_identifier is not null
   AND sm.username not in ('CRIS_ADMIN',
                           'PACSADMIN',
                           'SCHNITTY2000',
                           'CRIS_PROXY',
                           'INOVA',
                           'MEDORA')
 group by sm.username, sm.client_identifier, sm.status
 
having count(sm.username) > 1
order by sm.username                       
 
 
 select * from v$session@medora sm
 where sm.username = 'ATOCCHETON'
 select * from mitarbeiter@medora m
 
 
 SELECT distinct v.username username,
        M.VORNAME||' '||M.NAME nm_usuario,
        v.osuser as Windows,
        case when v.client_identifier is null then v.machine
          else v.client_identifier end  MACHINE

   FROM V_DOLLAR_SESSION@medora V, mitarbeiter@medora M
  WHERE V.USERNAME = M.MITARBEITER_ORACLE_USER_NAME
    AND UPPER(V.Status) NOT LIKE '%KILLED%'
    AND V.USERNAME NOT IN( 'SPEECHMAGIC', 'CRIS_ADMIN', 'CRIS_PROXY',
                          'MEDORA', 'MEDWEB_PROXY', 'SCHNITTY2000', 'INOVA', 'PACSADMIN')
                          
                          
                          
                          
                          
                          
       
select UPPER(l.nm_usuario) as nm_usuario,
       l.username,
       count(l.nm_usuario) QT_LICENSAS
  from custom.ige_vw_licencas l
 group by l.nm_usuario, l.username
having count(l.nm_usuario) > 1


    
select upper(l.nm_usuario) nm_usuario,
       l.username,
       (SELECT listagg(u.ds_observacao, ' , ') within group(ORDER by u.ds_observacao)
          from DBASGU.USUARIOS u
         where u.cd_usuario = l.username) as SETOR,
       count(l.nm_usuario) QT_LICENSAS,
       (Select listagg(ll.machine, ' , ') within group(order by ll.nm_usuario)
          from custom.ige_vw_licencas ll
         where ll.nm_usuario = l.nm_usuario) Maquinas
  from custom.ige_vw_licencas l
 group by l.nm_usuario, l.username
having count(l.nm_usuario) > 1
 
           SELECT u.ds_observacao
          FROM DBASGU.USUARIOS u
         WHERE sm.username = u.cd_usuario        
                          
                          
                          
                          
                          
                          
                          
                          
                          
                          
                          
                          
                          
                          
                          
                          
                          
                          
                          
                          
                          
                          
                          
 
