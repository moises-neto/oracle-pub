--Consulta usu�rio x p�gina
select u.cd_pagina,
       p.ds_titulo         as Nome_Pagina,
       u.cd_usuario_portal as Usuario,
       initcap(up.nm_usuario)       as Colaborador
  from dbacp.usuario_portal_pagina u
 inner join dbacp.pagina p
    on u.cd_pagina = p.cd_pagina
 inner join dbacp.usuario_portal up
    on up.cd_usuario_portal = u.cd_usuario_portal
 where U.CD_USUARIO_PORTAL in ('CRODRIGUES')
 order by p.ds_titulo


---------------------------------------------------------------------------


Select u.Cd_Usuario_Portal,
       u.Nm_Usuario,
       p.ds_titulo,
       u.Sn_Ativo
  From Dbacp.Usuario_Portal_Pagina pp, 
     --  Dbacp.Usuario_Portal_Papel pp,
       Dbacp.Usuario_Portal u,
       Dbacp.Pagina p
 Where p.Cd_Pagina = 140     
And pp.Cd_Usuario_Portal Is Not Null   
And pp.Cd_Usuario_Portal = u.Cd_Usuario_Portal


select * from Dbacp.Usuario_Portal_Papel pp
where pp.cd_usuario_portal = 'TRIAGEM'

select distinct up.cd_usuario_portal AS USUARIO,
       up.nm_usuario,
       up.ds_email AS EMAIL,
       UP.SN_ATIVO,
       pag.ds_titulo NM_PAGINA,
       pag.cd_pagina
    --   papel.nm_papel
       
  from Dbacp.Usuario_Portal        up,
       Dbacp.Usuario_Portal_Pagina pp,
       Dbacp.Pagina                pag,
       Dbacp.papel                 papel,
       dbacp.usuario_portal_papel  upp
 --where up.cd_usuario_portal = 'TRIAGEM'
 WHERE pag.ds_titulo in 'Gest�o de Leitos'
   and up.cd_usuario_portal = pp.cd_usuario_portal
   and pp.cd_pagina = pag.cd_pagina
   and upp.cd_usuario_portal = up.cd_usuario_portal
   and papel.cd_papel = upp.cd_papel
  and up.sn_ativo = 'S'
  and pag.cd_pagina = 293
   order by pag.ds_titulo;


SELECT * FROM dbacp.papel

select * from dbacp.usuario_portal_papel

 select r.*, r.rowid from custom.ti_paineis r order by r.cd_local;

select * from 
dbacp.modulo_sistema s,
dbacp.modulo_permissao_usuario u, 
dbacp.modulo_permissao_papel pp,
dbacp.usuario_portal up
where up.cd_usuario_portal = 'TRIAGEM'

and pp.cd_modulo_sistema = u.cd_modulo_sistema
and u.cd_modulo_sistema = s.cd_modulo
and up.cd_usuario_portal = u.cd_usuario_portal



select * from dbacp.modulo_sistema s
dbacp.modulo_permissao_usuario u, 
dbacp.modulo_permissao_papel pp,
dbacp.usuario_portal up


select p.ds_titulo, up.nm_usuario, up.cd_usuario_portal
  from Dbacp.Pagina                p,
       dbacp.usuario_portal_pagina upp,
       dbacp.usuario_portal        up
 where p.cd_pagina = '324'
   and p.cd_pagina = upp.cd_pagina
   and up.cd_usuario_portal = upp.cd_usuario_portal;


select * from Dbacp.Pagina p
where p.ds_titulo like '%Risco%';

select * from dbacp.pagina p
where p.cd_pagina = '235';
/**/
select * from dbacp.usuario_portal_papel upp
INNER JOIN dbacp.papel p
on upp.cd_papel = p.cd_papel
where upp.cd_usuario_portal = 'TRIAGEM';

select distinct UPP.CD_USUARIO_PORTAL, por.ds_titulo, pap.nm_papel from dbacp.portlet_papel pp
join dBACP.PORTLET por
on pp.cd_portlet = por.cd_portlet
join dbacp.papel pap
on pap.cd_papel = pp.cd_papel
join dbacp.usuario_portal_papel upp
on upp.cd_papel = pp.cd_papel
join dbacp.usuario_portal_pagina upag
on upag.cd_usuario_portal = upp.cd_usuario_portal
join dbacp.usuario_portal up
on up.cd_usuario_portal = upp.cd_usuario_portal
where up.cd_usuario_portal = 'BROLIVEIRA';

select UPP.rowid, PAP.ROWID, UPP.*, PAP.* from dbacp.usuario_portal_papel upp
INNER JOIN dbacp.papel pap
ON PAP.CD_PAPEL = UPP.CD_PAPEL
where upp.cd_usuario_portal = 'BROLIVEIRA';

select ROWID, UPP.* from dbacp.usuario_portal_papel upp
where upp.cd_usuario_portal = 'MTHOMAZELLA';

Select rowid, upag.* from dbacp.usuario_portal_pagina upag
where upag.cd_usuario_portal = 'TESTESUPORTE'

Select rowid, upag.* from dbacp.usuario_portal_pagina upag
where upag.cd_usuario_portal = 'JUCOUTO'


select ROWID, UPP.* from Dbacp.usuario_portal_papel upp
where upp.cd_usuario_portal = '';



select * from dbacp.portlet_papel pp
join dbacp.papel pap
on pp.cd_papel = pap.cd_papel
where pp.cd_portlet = 240

/*DECLARE 
      CURSOR USUARIO1 IS
      SELECT CD_USUARIO_PORTAL, CD_PAPEL FROM Dbacp.usuario_portal_papel
      WHERE CD_USUARIO_PORTAL = 'TESTESUPORTE';
      
     CURSOR USUARIO2 IS
     SELECT CD_USUARIO_PORTAL, CD_PAPEL FROM Dbacp.usuario_portal_papel
     WHERE CD_USUARIO_PORTAL = 'TESTE3';
     
BEGIN
  FOR USUARIO IN USUARIO2 LOOP
    BEGIN
  UPDATE Dbacp.usuario_portal_papel P
         SET P.CD_PAPEL =  USUARIO.
  WHERE P.CD_USUARIO_PORTAL = USUARIO.CD_USUARIO_PORTAL
       AND P.CD_PAPEL = USUARIO.CD_PAPEL;
 
    END;
  END LOOP;
END;*/

select ROWID, UPP.* from Dbacp.usuario_portal_papel upp
where upp.cd_usuario_portal = 'TESTE3';


/*DECLARE 
      CURSOR USUARIO1 IS
      SELECT CD_USUARIO_PORTAL, CD_PAPEL FROM Dbacp.usuario_portal_papel
      WHERE CD_USUARIO_PORTAL = 'TESTESUPORTE';
      
     CURSOR USUARIO2 IS
     SELECT CD_USUARIO_PORTAL, CD_PAPEL FROM Dbacp.usuario_portal_papel
     WHERE CD_USUARIO_PORTAL = 'TESTE3';
     
BEGIN
  FOR USUARIO IN USUARIO2 LOOP
    BEGIN
  UPDATE Dbacp.usuario_portal_papel P
         SET P.CD_PAPEL =  USUARIO.
  WHERE P.CD_USUARIO_PORTAL = USUARIO.CD_USUARIO_PORTAL
       AND P.CD_PAPEL = USUARIO.CD_PAPEL;
 
    END;
  END LOOP;
END;*/


DECLARE 
           
     CURSOR USUARIO1 IS
     SELECT P.CD_PAPEL FROM Dbacp.usuario_portal_papel P
     WHERE P.CD_USUARIO_PORTAL = 'TESTESUPORTE';
     
     
BEGIN
  FOR USUARIO IN USUARIO1 LOOP
    BEGIN
      
      INSERT INTO Dbacp.usuario_portal_papel (Cd_Usuario_Portal, Cd_Papel)
      VALUES ('TESTE3', USUARIO.CD_PAPEL);  
      
     -- DBMS_OUTPUT.put_line(USUARIO.CD_USUARIO_PORTAL ||' '||USUARIO.CD_PAPEL);
              
    END;
  END LOOP;
END;




