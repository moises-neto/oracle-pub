sELECT *
  fROM (SELECT DISTINCT PAG.CD_PAGINA,
                        pag.ds_titulo as Pagina,
                        POR.DS_TITULO as Portlet
        
          FROM DBACP.PORTLET_CONFIGURACAO T
         INNER JOIN DBACP.PORTLET POR
            ON POR.CD_PORTLET = T.CD_PORTLET
         INNER JOIN DBACP.COLUNA C
            ON T.CD_COLUNA = C.CD_COLUNA
         INNER JOIN DBACP.PASTA P
            ON P.CD_PASTA = C.CD_PASTA
         INNER JOIN DBACP.USUARIO_PORTAL_PAGINA UPP --DBACP.USUARIO_PORTAL_PAGINA P
            ON UPP.CD_USUARIO_PORTAL_PAGINA = P.CD_USUARIO_PORTAL_PAGINA
         INNER JOIN DBACP.PAGINA PAG
            ON PAG.CD_PAGINA = UPP.CD_PAGINA
         INNER JOIN DBACP.PORTLET_PAPEL PP
            ON PP.CD_PORTLET = POR.CD_PORTLET
         INNER JOIN DBACP.PAPEL PAPEL
            ON PAPEL.CD_PAPEL = PP.CD_PAPEL
        
         WHERE POR.Cd_Portlet in
               (select p.cd_portlet --, p.ds_portlet, p.ds_titulo
                  from DBACP.PORTLET_SQL t, dbacp.portlet p
                 where p.cd_portlet = t.cd_portlet
                   and T.CD_DATA_SOURCE_SQL = 49
                   and (upper(t.ds_sql) like '%VW_PAINEL_LIDERANCA_INTER%' or
                       upper(t.ds_sql) like '%VW_PAINEL_LIDERANCA_INTER%' or
                       upper(t.ds_sql) like '%VW_PAINEL_TERAPIAS%' or
                       upper(t.ds_sql) like '%VW_PAINEL_VISAO_GERAL_RECEP%' or
                       upper(t.ds_sql) like '%VW_PRODUTIVIDADE_RECEPCAO%' or
                       upper(t.ds_sql) like '%VW_REPASSE_INTERCAMBIO%' or
                       upper(t.ds_sql) like
                       '%VW_RN395_RECEPCAO_INTER_POSTOS%' or
                       upper(t.ds_sql) like '%VW_RN395_RECEPCAO_SEM3%' or
                       upper(t.ds_sql) like '%VW_USUARIOS_RECEPCAO_SEDE%' or
                       upper(t.ds_sql) like '%VW_AUT_HORA_RECEP_SOUL%' or
                       upper(t.ds_sql) like '%VW_AUT_HORA_RECEP_TOTVS%' or
                       upper(t.ds_sql) like '%VW_AUT_HORA_RECEP_TOTVS_SOUL%' or
                       upper(t.ds_sql) like '%VW_AUT_POR_HORA_RECEP%' or
                       upper(t.ds_sql) like '%VW_AUT_POR_HORA_RECEP2%' or
                       upper(t.ds_sql) like '%VW_FUNCIONARIO_RECEP%' or
                       upper(t.ds_sql) like '%VW_PAINEL_INTERCAMBIO%' or
                       upper(t.ds_sql) like
                       '%VW_PAINEL_INTERCAMBIO_018_FORA%' or
                       upper(t.ds_sql) like '%VW_PAINEL_INTERCAMBIO_COVID%' or
                       upper(t.ds_sql) like
                       '%VW_PAINEL_INTERC_PRORROG_FORA%' or
                       upper(t.ds_sql) like '%VW_PAINEL_INTER_INSISTENCIA%' or
                       upper(t.ds_sql) like '%VW_PAINEL_INTER_INSIS_RELAT%' or
                       upper(t.ds_sql) like
                       '%VW_PAINEL_INTER_SADT_018_FORA%' or
                       upper(t.ds_sql) like '%VW_PAINEL_VISAO_GERAL_RECEP%' or
                       upper(t.ds_sql) like
                       '%VW_PROCEDIMENTOS_IMAGEM_RECEP%' or
                       upper(t.ds_sql) like '%VW_PROTOCOLO_INTERCAMBIO%' or
                       upper(t.ds_sql) like '%VW_RECEPCAO_CONSULTA_SADT%' or
                       upper(t.ds_sql) like '%VW_RECEPCAO_CONSULTA_SADT2%' or
                       upper(t.ds_sql) like '%VW_RECEPCAO_INTERNACAO%' or
                       upper(t.ds_sql) like '%VW_RECEPCAO_INTERNACAO2%' or
                       upper(t.ds_sql) like '%VW_RECEPCAO_OCT%' or
                       upper(t.ds_sql) like '%VW_RECEPCAO_SEM_ANEXO%' or
                       upper(t.ds_sql) like '%VW_RECEPCAO_SEM_ANEXO2%' or
                       upper(t.ds_sql) like '%VW_RECEPCAO_SEM_OCORRENCIA%' or
                       upper(t.ds_sql) like
                       '%VW_RECEPCAO_TOMO_RM_COLONO_EDA%' or
                       upper(t.ds_sql) like '%VW_RECEPCAO_VISAO%' or
                       upper(t.ds_sql) like '%VW_RECEPCAO_VISAO2%' or
                       upper(t.ds_sql) like '%VW_RECEPCAO_VISAO3%' or
                       upper(t.ds_sql) like '%VW_RECEP_KFLOW%' or
                       upper(t.ds_sql) like '%VW_RECEP_SEM_OCORRENCIA%' or
                       upper(t.ds_sql) like '%VW_RN395_RECEPCAO%' or
                       upper(t.ds_sql) like '%VW_RN395_RECEPCAO2%' or
                       upper(t.ds_sql) like '%VW_RN395_RECEPCAO3%' or
                       upper(t.ds_sql) like '%VW_RN395_RECEPCAO4%' or
                       upper(t.ds_sql) like '%VW_RN395_RECEPCAO4_1%' or
                       upper(t.ds_sql) like '%VW_RN395_RECEPCAO_GERAL%' or
                       upper(t.ds_sql) like '%VW_RN395_RECEPCAO_INTER%' or
                       upper(t.ds_sql) like '%VW_RN395_RECEPCAO_INTER_2%' or
                       upper(t.ds_sql) like '%VW_RN395_RECEPCAO_INTER_3%' or
                       upper(t.ds_sql) like '%VW_RN395_RECEPCAO_INTER_4%' or
                       upper(t.ds_sql) like
                       '%VW_RN395_RECEPCAO_INTER_POSTOS%' or
                       upper(t.ds_sql) like '%VW_RN395_RECEPCAO_SEM%' or
                       upper(t.ds_sql) like '%VW_RN395_RECEPCAO_SEM2%' or
                       upper(t.ds_sql) like '%VW_RN395_RECEPCAO_SEM3%' or
                       upper(t.ds_sql) like '%VW_RN395_RECEPCAO_SEM_ANEXO%' or
                       upper(t.ds_sql) like '%VW_RN395_RECEPCAO_VISAO%' or
                       upper(t.ds_sql) like '%VW_RN395_RECEPCAO_ZN%' or
                       upper(t.ds_sql) like '%VW_RN395_RECEPCAO_ZN_018%' or
                       upper(t.ds_sql) like '%VW_RN395_RECEPCAO_ZN_018_3%' or
                       upper(t.ds_sql) like '%VW_RN395_RECEPCAO_ZN_018_4%' or
                       upper(t.ds_sql) like '%VW_SPREAD_INTERCAMBIO%' or
                       upper(t.ds_sql) like '%VW_VENC_FAT_INTERCAMBIO_A500%' or
                       upper(t.ds_sql) like '%V_PTU_STATUS_INTERCAMBIO%'))
           AND PAPEL.NM_PAPEL NOT IN ('Super Usu�rio', 'TI')
           AND PAPEL.NM_PAPEL NOT LIKE ('SE_%')) X,
       
       (sELECT USUA.CD_USUARIO_PORTAL, U.NM_USUARIO, USUA.CD_PAGINA, us.ds_observacao
          fROM DBACP.USUARIO_PORTAL_PAGINA USUA, DBACP.USUARIO_PORTAL U, dbasgu.usuarios@ormvprd us
         WHERE U.CD_USUARIO_PORTAL = USUA.CD_USUARIO_PORTAL                               
         And us.cd_usuario = u.cd_usuario_portal
           AND U.SN_ATIVO = 'S') Y
 WHERE X.CD_PAGINA = Y.CD_PAGINA
