SELECT U.CD_USUARIO_PORTAL AS USUARIO,
       U.NM_USUARIO        AS NOME,
       DECODE(L.CD_TIPO_LICENCA, 1, 'LITE', 
                                 2, 'REPORT', 
                                 3, 'DEVELOPER') LICENCA,
       DECODE(U.SN_ATIVO, 'N', 'INATIVO') AS STATUS
      
  FROM DBACP.USUARIO_SISTEMA_LICENCA L
 INNER JOIN DBACP.USUARIO_PORTAL U
    ON U.CD_USUARIO_PORTAL = L.CD_USUARIO_PORTAL

 WHERE U.SN_ATIVO = 'N'
 
 UNION
 
select  '',
        '',
        '',
        DECODE(l.cd_tipo_licenca,
              1,
              'LITE: ' || (999 - sum(l.cd_tipo_licenca)) ||
              '  Licensas  Restantes',
              2,
              'REPORT: ' || (999 - sum(l.cd_tipo_licenca)) ||
              '  Licensas  Restantes',
              3,
              'DEVELOPER: ' || (999 - sum(l.cd_tipo_licenca)) ||
              '  Licensas  Restantes') as Qtdd_Licensas 

  from dbacp.usuario_sistema_licenca l
 group by l.cd_tipo_licenca
 order by nome;
 
 
/*DELETE  

  FROM DBACP.USUARIO_SISTEMA_LICENCA L
  where L.CD_USUARIO_PORTAL IN (SELECT U.CD_USUARIO_PORTAL FROM DBACP.USUARIO_PORTAL U WHERE U.SN_ATIVO = 'N')*/
  


 
 
 
 
 
 
 
 
 
 
