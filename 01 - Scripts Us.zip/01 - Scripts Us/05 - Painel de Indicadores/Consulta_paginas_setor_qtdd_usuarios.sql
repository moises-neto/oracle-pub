SELECT X.DS_TITULO, 
       X.SETOR, 
       X.QTD_USUARIOS,
      -- Y.USUARIO,
      -- Y.COLABORADOR
  FROM (SELECT P.DS_TITULO,
               U.DS_OBSERVACAO AS SETOR,     
               COUNT(P.DS_TITULO) QTD_USUARIOS
        
          FROM DBACP.PAGINA P
         INNER JOIN DBACP.USUARIO_PORTAL_PAGINA UPP
         USING (CD_PAGINA)
         INNER JOIN USUARIOS@ORMVPRD U
            ON U.CD_USUARIO = UPP.CD_USUARIO_PORTAL
         WHERE U.SN_ATIVO = 'S'
           AND U.DS_OBSERVACAO IS NOT NULL
           AND U.DS_OBSERVACAO LIKE '%0071 - RECEPCAO - HMS%'
         GROUP BY P.DS_TITULO,                 
                  U.DS_OBSERVACAO
        HAVING COUNT(P.DS_TITULO) <= 2) X,
       
       (SELECT U.CD_USUARIO AS USUARIO, 
               U.NM_USUARIO AS COLABORADOR, 
               P.DS_TITULO
          FROM DBACP.PAGINA P
          
         INNER JOIN DBACP.USUARIO_PORTAL_PAGINA UPP
         USING (CD_PAGINA)
         INNER JOIN USUARIOS@ORMVPRD U
            ON U.CD_USUARIO = UPP.CD_USUARIO_PORTAL
            
         WHERE U.SN_ATIVO = 'S'
           AND U.DS_OBSERVACAO IS NOT NULL
           AND U.DS_OBSERVACAO LIKE '%0071 - RECEPCAO - HMS%') Y
           
WHERE X.DS_TITULO = Y.DS_TITULO
ORDER BY X.DS_TITULO DESC;

SELECT P.DS_TITULO AS PAGINA,
       -- U.NM_USUARIO AS COLABORADOR,
       -- U.CD_USUARIO AS USUARIO,
       U.DS_OBSERVACAO AS SETOR,
       COUNT(U.DS_OBSERVACAO) QTD_USUARIOS
  FROM DBACP.PAGINA P
 INNER JOIN DBACP.USUARIO_PORTAL_PAGINA UPP
 USING (CD_PAGINA)
 INNER JOIN USUARIOS@ORMVPRD U
    ON U.CD_USUARIO = UPP.CD_USUARIO_PORTAL
 WHERE U.SN_ATIVO = 'S'
 AND U.DS_OBSERVACAO IS NOT NULL
 AND U.DS_OBSERVACAO LIKE '%0071 - RECEPCAO - HMS%'
 GROUP BY P.DS_TITULO, -- U.CD_USUARIO,
          U.DS_OBSERVACAO
          



SELECT X.DS_TITULO AS PAGINA,
       X.SETOR,
       X.QTD_USUARIOS,
       listagg (Y.usuario,', ') within group (order by X.DS_TITULO) Usuario,
       listagg (Y.colaborador,', ') within group (order by X.DS_TITULO) Colaborador
  FROM (SELECT P.DS_TITULO,
               U.DS_OBSERVACAO AS SETOR,   
               COUNT(P.DS_TITULO) QTD_USUARIOS
      
          FROM DBACP.PAGINA P
         INNER JOIN DBACP.USUARIO_PORTAL_PAGINA UPP
         USING (CD_PAGINA)
         INNER JOIN USUARIOS@ORMVPRD U
            ON U.CD_USUARIO = UPP.CD_USUARIO_PORTAL
         WHERE U.SN_ATIVO = 'S'
           AND U.DS_OBSERVACAO IS NOT NULL
           AND U.DS_OBSERVACAO LIKE '%0071 - RECEPCAO - HMS%'
         GROUP BY P.DS_TITULO,               
                  U.DS_OBSERVACAO
        HAVING COUNT(P.DS_TITULO) <= 2) X,
     
       (SELECT U.CD_USUARIO AS USUARIO,
               U.NM_USUARIO AS COLABORADOR,
               P.DS_TITULO
          FROM DBACP.PAGINA P
        
         INNER JOIN DBACP.USUARIO_PORTAL_PAGINA UPP
         USING (CD_PAGINA)
         INNER JOIN USUARIOS@ORMVPRD U
            ON U.CD_USUARIO = UPP.CD_USUARIO_PORTAL
          
         WHERE U.SN_ATIVO = 'S'
           AND U.DS_OBSERVACAO IS NOT NULL
           AND U.DS_OBSERVACAO LIKE '%0071 - RECEPCAO - HMS%') Y
         
WHERE X.DS_TITULO = Y.DS_TITULO
group by X.DS_TITULO,
       X.SETOR,
       X.QTD_USUARIOS
ORDER BY X.DS_TITULO DESC


SELECT X.DS_TITULO AS PAGINA,
       X.SETOR,
       X.QTD_USUARIOS,
       listagg (Y.usuario,', ') within group (order by X.DS_TITULO) Usuario,
       listagg (Y.colaborador,', ') within group (order by X.DS_TITULO) Colaborador
  FROM (SELECT P.DS_TITULO,
               U.DS_OBSERVACAO AS SETOR,   
               COUNT(P.DS_TITULO) QTD_USUARIOS
      
          FROM DBACP.PAGINA P
         INNER JOIN DBACP.USUARIO_PORTAL_PAGINA UPP
         USING (CD_PAGINA)
         INNER JOIN USUARIOS@ORMVPRD U
            ON U.CD_USUARIO = UPP.CD_USUARIO_PORTAL
         WHERE U.SN_ATIVO = 'S'
           AND U.DS_OBSERVACAO IS NOT NULL
           AND U.DS_OBSERVACAO IN ('1619 - ENDOSCOPIA')
         GROUP BY P.DS_TITULO,               
                  U.DS_OBSERVACAO
       -- HAVING COUNT(P.DS_TITULO) <= 2
       ) X,
     
       (SELECT U.CD_USUARIO AS USUARIO,
               INITCAP(U.NM_USUARIO) AS COLABORADOR,
               P.DS_TITULO
          FROM DBACP.PAGINA P
        
         INNER JOIN DBACP.USUARIO_PORTAL_PAGINA UPP
         USING (CD_PAGINA)
         INNER JOIN USUARIOS@ORMVPRD U
            ON U.CD_USUARIO = UPP.CD_USUARIO_PORTAL
          
         WHERE U.SN_ATIVO = 'S'
           AND U.DS_OBSERVACAO IS NOT NULL
           AND U.DS_OBSERVACAO IN ('1619 - ENDOSCOPIA'))  Y
         
WHERE X.DS_TITULO = Y.DS_TITULO
--AND Y.usuario not in ('MANASCIMENTO','RAIOX')
group by X.DS_TITULO,
         X.SETOR,
         X.QTD_USUARIOS
ORDER BY X.DS_TITULO DESC

--------------------------Remover p�gina----------------------------
BEGIN
      SELECT UPP.CD_USUARIO_PORTAL FROM DBACP.USUARIO_PORTAL_PAGINA UPP 
      JOIN DBACP.PAGINA P
      ON P.CD_PAGINA = UPP.CD_PAGINA
      WHERE P.DS_TITULO IN ('Lideran�a Gest�o Imagem')
      
      AND UPP.CD_USUARIO_PORTAL IN ('ABASTOS', 'ESGOES', 'KANTUNES', 'LGOUVEA', 'MREIS', 'RENIOLIVEIRA', 'REVICENTE')
       
       
      DELETE  DBACP.USUARIO_PORTAL_PAGINA UPP  
       WHERE UPP.CD_USUARIO_PORTAL IN ('ANROCHA', 'IZSILVA', 'JUGOES')
       AND UPP.CD_PAGINA IN
       (SELECT P.CD_PAGINA FROM DBACP.PAGINA P 
       WHERE P.DS_TITULO IN ('Gest�o Unificada Recep��o'))

END;

SELECT * FROM DBACP.PAGINA P WHERE P.DS_TITULO IN 'Gest�o do Atendimento de Emerg�ncia'

SELECT * FROM DBACP.PORTLET

select * from dbacp.parametro_global_portlet

select u.* from dbacp.usuario_portal u where u.cd_usuario_portal = 'MIFERREIRA'







