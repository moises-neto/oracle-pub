--Gabriel 25/01/2021: Painel para exibir as pend�ncias dos respectivos colaboradores do Interc�mbio.
--Entra quando inserida a ocorr�ncia: 179 - 34-ENC COLABORADOR.
--Sai quando inserido qualquer outra ocorr�ncia do tipo "Workflow".
--Apenas a lider Karina consegue ver todos os usu�rios, enquanto os demais conseguem ver apenas suas
--pr�prias pend�ncias. 

select g.dt_emissao,
       g.nr_transacao,
       bt.cd_matricula,
       g.nr_guia_externa,
       dbaps.fn_dias_uteis_feriado(g.dt_emissao, sysdate) dias_uteis,
       dbaps.fnc_status_guia(g.nr_guia) status,
       go.ds_observacao,
       cog.abreviacao_descricao,
       g.cd_usuario_emissao,
       (select a.cd_usuario
          from dbaps.autorizador a
         where a.cd_autorizador = g.cd_autorizador) autorizador,
       1 linha
  from dbaps.guia                          g,
       dbaps.guia_ocorrencia               go,
       dbaps.classificacao_ocorrencia_guia cog,
       dbaps.beneficiario_transito         bt
 where g.nr_guia = go.nr_guia
   and bt.cd_matricula(+) = g.nr_carteira_beneficiario
   and go.cd_classificacao_ocor_guia = cog.cd_classificacao_ocor_guia
   and go.cd_guia_ocorrencia =
       (select max(goo.cd_guia_ocorrencia)
          from dbaps.guia_ocorrencia               goo,
               dbaps.classificacao_ocorrencia_guia cl
         where goo.nr_guia = g.nr_guia
           and goo.cd_classificacao_ocor_guia =
               cl.cd_classificacao_ocor_guia
           and cl.tp_class_ocorrencia_guia = 'W')
   and go.cd_classificacao_ocor_guia = '179'
   and (g.cd_autorizador =
       (select a.cd_autorizador
           from dbaps.autorizador a
          where a.cd_autorizador = g.cd_autorizador
            and a.cd_usuario = @CODIGOUSUARIO@) or
       g.cd_usuario_emissao = @CODIGOUSUARIO@)

union

select g.dt_emissao,
       g.nr_transacao,
       bt.cd_matricula,
       g.nr_guia_externa,
       dbaps.fn_dias_uteis_feriado(g.dt_emissao, sysdate) dias_uteis,
       dbaps.fnc_status_guia(g.nr_guia) status,
       go.ds_observacao,
       cog.abreviacao_descricao,
       g.cd_usuario_emissao,
       (select a.cd_usuario
          from dbaps.autorizador a
         where a.cd_autorizador = g.cd_autorizador) autorizador,
       1 linha
  from dbaps.guia                          g,
       dbaps.guia_ocorrencia               go,
       dbaps.classificacao_ocorrencia_guia cog,
       dbaps.beneficiario_transito         bt
 where g.nr_guia = go.nr_guia
   and bt.cd_matricula(+) = g.nr_carteira_beneficiario
   and go.cd_classificacao_ocor_guia = cog.cd_classificacao_ocor_guia
   and go.cd_guia_ocorrencia =
       (select max(goo.cd_guia_ocorrencia)
          from dbaps.guia_ocorrencia               goo,
               dbaps.classificacao_ocorrencia_guia cl
         where goo.nr_guia = g.nr_guia
           and goo.cd_classificacao_ocor_guia =
               cl.cd_classificacao_ocor_guia
           and cl.tp_class_ocorrencia_guia = 'W')
   and go.cd_classificacao_ocor_guia = '179'
   and go.cd_guia_ocorrencia =
       (select max(goo.cd_guia_ocorrencia)
          from dbaps.guia_ocorrencia               goo,
               dbaps.classificacao_ocorrencia_guia cl
         where goo.nr_guia = g.nr_guia
           and cog.cd_classificacao_ocor_guia =
               goo.cd_classificacao_ocor_guia
           and cl.tp_class_ocorrencia_guia = 'W')
   and @CODIGOUSUARIO@ in
       ('KZACARIAS', 'JULIANASANTOS', 'SIVIEIRA', 'GACQUAVIVA')
   and #usuario# = 'TODOS'

union

select g.dt_emissao,
       g.nr_transacao,
       bt.cd_matricula,
       g.nr_guia_externa,
       dbaps.fn_dias_uteis_feriado(g.dt_emissao, sysdate) dias_uteis,
       dbaps.fnc_status_guia(g.nr_guia) status,
       go.ds_observacao,
       cog.abreviacao_descricao,
       g.cd_usuario_emissao,
       (select a.cd_usuario
          from dbaps.autorizador a
         where a.cd_autorizador = g.cd_autorizador) autorizador,
       1 linha
  from dbaps.guia                          g,
       dbaps.guia_ocorrencia               go,
       dbaps.classificacao_ocorrencia_guia cog,
       dbaps.beneficiario_transito         bt
 where g.nr_guia = go.nr_guia
   and bt.cd_matricula(+) = g.nr_carteira_beneficiario
   and go.cd_classificacao_ocor_guia = cog.cd_classificacao_ocor_guia
   and go.cd_guia_ocorrencia =
       (select max(goo.cd_guia_ocorrencia)
          from dbaps.guia_ocorrencia               goo,
               dbaps.classificacao_ocorrencia_guia cl
         where goo.nr_guia = g.nr_guia
           and goo.cd_classificacao_ocor_guia =
               cl.cd_classificacao_ocor_guia
           and cl.tp_class_ocorrencia_guia = 'W')
   and go.cd_classificacao_ocor_guia = '179'
   and go.cd_guia_ocorrencia =
       (select max(goo.cd_guia_ocorrencia)
          from dbaps.guia_ocorrencia               goo,
               dbaps.classificacao_ocorrencia_guia cl
         where goo.nr_guia = g.nr_guia
           and cog.cd_classificacao_ocor_guia =
               goo.cd_classificacao_ocor_guia
           and cl.tp_class_ocorrencia_guia = 'W')
   and @CODIGOUSUARIO@ in
       ('KZACARIAS', 'JULIANASANTOS', 'SIVIEIRA', 'GACQUAVIVA')
   and #usuario# <> 'TODOS'
   and (g.cd_autorizador =
       (select a.cd_autorizador
           from dbaps.autorizador a
          where a.cd_autorizador = g.cd_autorizador
            and a.cd_usuario = #usuario#) or
       g.cd_usuario_emissao = #usuario#)
