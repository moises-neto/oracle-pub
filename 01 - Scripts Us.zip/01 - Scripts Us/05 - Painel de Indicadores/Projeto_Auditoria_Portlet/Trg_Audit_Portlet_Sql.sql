CREATE OR REPLACE Trigger CUSTOM.Trg_Audit_Portlet_Sql
  Before Insert Or Update Or Delete On Dbacp.Portlet_Sql
  Referencing New As New Old As Old
  For Each Row

  /****************************************************************************************************
  * OBJETO: CUSTOM.PRC_CORRIGE_PRESTADOR_PTU                                                          * 
  *****************************************************************************************************
  * M�DULO: SOUL MV - PLANO DE SA�DE (CONTAS M�DICAS - M_CONTA_MEDICA                                 *                                   *
  * OBJETIVO: Inserir no campo cd_prestador_ptu um prestador executante(PF) para envio das informa��es*
  * no XML nos itens que possuem HM.                                                                  *
  *****************************************************************************************************
  |---------------------------------------------------------------------------------------------------|
  |  CHAMADO   |     DATA   |   SOLICITANTE    |   RESPONS�VEL     |  VERS�O  | ALTERA��O             |
  |------------+------------+------------------+-------------------+----------------------------------|
  |CH2204-0124 | 04/04/2022 |  Equipe Sistemas |  Mois�s de Souza  |  1.0     |  Cria��o da Trigger   |
  |------------+------------+------------------+-------------------+----------+-----------------------|
  ****************************************************************************************************/

Declare

  Cursor Cauditportlet Is
    Select p.Ds_Titulo   As Aba,
           Pag.Ds_Titulo As Pagina,
           t.Cd_Portlet  As Cod_Portlet,
           Por.Ds_Titulo As Nm_Portlet,
           Por.Dt_Criacao As Dt_Criacao_Portlet,
           Por.Cd_Usuario_Criador,
           :Old.Ds_Sql As Old_Sql_Portlet,
           :New.Ds_Sql As New_Sql_Portlet,
           :Old.Nr_Campo_Ds_Link As Old_Nr_Campo_Ds_Link,
           :New.Nr_Campo_Ds_Link As New_Nr_Campo_Ds_Link,
           :Old.Nr_Campo_Ds_Hint As Old_Nr_Campo_Ds_Hint,
           :New.Nr_Campo_Ds_Hint As New_Nr_Campo_Ds_Hint,
           (Select s.Ds_Data_Source
              From Dbacp.Data_Source_Sql s
             Where s.Cd_Data_Source_Sql = :New.Cd_Data_Source_Sql) As Banco,
           :Old.Tipo_Link As Old_Tipo_Link,
           :New.Tipo_Link As New_Tipo_Link,
           :Old.Nr_Campo_Ds_Pesquisa As Old_Nr_Campo_Ds_Pesquisa,
           :New.Nr_Campo_Ds_Pesquisa As New_Nr_Campo_Ds_Pesquisa,
           :Old.Cd_Fonte_Cabecalho As Old_Cd_Fonte_Cabecalho,
           :New.Cd_Fonte_Cabecalho As New_Cd_Fonte_Cabecalho,
           :Old.Nr_Tamanho_Fonte_Cabecalho As Old_Nr_Tamanho_Fonte_Cabecalho,
           :New.Nr_Tamanho_Fonte_Cabecalho As New_Nr_Tamanho_Fonte_Cabecalho,
           :Old.Ds_Cor_Fonte_Cabecalho As Old_Ds_Cor_Fonte_Cabecalho,
           :New.Ds_Cor_Fonte_Cabecalho As New_Ds_Cor_Fonte_Cabecalho,
           :Old.Ds_Cor_Fundo_Cabecalho As Old_Ds_Cor_Fundo_Cabecalho,
           :New.Ds_Cor_Fundo_Cabecalho As New_Ds_Cor_Fundo_Cabecalho,
           :Old.Cd_Fonte_Rodape As Old_Cd_Fonte_Rodape,
           :New.Cd_Fonte_Rodape As New_Cd_Fonte_Rodape,
           :Old.Nr_Tamanho_Fonte_Rodape As Old_Nr_Tamanho_Fonte_Rodape,
           :New.Nr_Tamanho_Fonte_Rodape As New_Nr_Tamanho_Fonte_Rodape,
           :Old.Ds_Cor_Fonte_Rodape As Old_Ds_Cor_Fonte_Rodape,
           :New.Ds_Cor_Fonte_Rodape As New_Ds_Cor_Fonte_Rodape,
           :Old.Ds_Cor_Fundo_Rodape As Old_Ds_Cor_Fundo_Rodape,
           :New.Ds_Cor_Fundo_Rodape As New_Ds_Cor_Fundo_Rodape,
           :Old.Sn_Exibir_Cabecalho As Old_Sn_Exibir_Cabecalho,
           :New.Sn_Exibir_Cabecalho As New_Sn_Exibir_Cabecalho,
           :Old.Sn_Exibir_Borda As Old_Sn_Exibir_Borda,
           :New.Sn_Exibir_Borda As New_Sn_Exibir_Borda,
           :Old.Cd_Pasta_Link As Old_Cd_Pasta_Link,
           :New.Cd_Pasta_Link As New_Cd_Pasta_Link,
           :Old.Sn_Abrir_Link_Popup As Old_Sn_Abrir_Link_Popup,
           :New.Sn_Abrir_Link_Popup As New_Sn_Abrir_Link_Popup,
           :Old.Sn_Negrito_Cabecalho As Old_Sn_Negrito_Cabecalho,
           :New.Sn_Negrito_Cabecalho As New_Sn_Negrito_Cabecalho,
           :Old.Sn_Negrito_Rodape As Old_Sn_Negrito_Rodape,
           :New.Sn_Negrito_Rodape As New_Sn_Negrito_Rodape 
    
      From Dbacp.Portlet Por
      Left Join Dbacp.Portlet_Configuracao t
        On Por.Cd_Portlet = t.Cd_Portlet
      Left Join Dbacp.Coluna c
        On t.Cd_Coluna = c.Cd_Coluna
      Left Join Dbacp.Pasta p
        On p.Cd_Pasta = c.Cd_Pasta
      Left Join Dbacp.Usuario_Portal_Pagina Upp
        On Upp.Cd_Usuario_Portal_Pagina = p.Cd_Usuario_Portal_Pagina
      Left Join Dbacp.Pagina Pag
        On Pag.Cd_Pagina = Upp.Cd_Pagina

     Where 1 = 1
       And Por.Cd_Portlet = Nvl(:New.Cd_Portlet, :Old.Cd_Portlet);

  v_Erro_Ora Varchar2(500) := '';

Begin


  If (Inserting) Then
    For i In Cauditportlet Loop
    
      Begin
        If (Cauditportlet%Found) Then
          Begin
            Insert Into Custom.Log_Portlet_Sql
              (Cd_Log_Portlet_Sql,
               Aba,
               Pagina,
               Cod_Portlet,
               Nm_Portlet,
               Dt_Criacao_Portlet,
               Cd_Usuario_Criador,
               Old_Sql_Portlet,
               New_Sql_Portlet,
               Old_Nr_Campo_Ds_Link,
               New_Nr_Campo_Ds_Link,
               Old_Nr_Campo_Ds_Hint,
               New_Nr_Campo_Ds_Hint,
               Banco,
               Old_Tipo_Link,
               New_Tipo_Link,
               Old_Nr_Campo_Ds_Pesquisa,
               New_Nr_Campo_Ds_Pesquisa,
               Old_Cd_Fonte_Cabecalho,
               New_Cd_Fonte_Cabecalho,
               Old_Nr_Tamanho_Fonte_Cabecalho,
               New_Nr_Tamanho_Fonte_Cabecalho,
               Old_Ds_Cor_Fonte_Cabecalho,
               New_Ds_Cor_Fonte_Cabecalho,
               Old_Ds_Cor_Fundo_Cabecalho,
               New_Ds_Cor_Fundo_Cabecalho,
               Old_Cd_Fonte_Rodape,
               New_Cd_Fonte_Rodape,
               Old_Nr_Tamanho_Fonte_Rodape,
               New_Nr_Tamanho_Fonte_Rodape,
               Old_Ds_Cor_Fonte_Rodape,
               New_Ds_Cor_Fonte_Rodape,
               Old_Ds_Cor_Fundo_Rodape,
               New_Ds_Cor_Fundo_Rodape,
               Old_Sn_Exibir_Cabecalho,
               New_Sn_Exibir_Cabecalho,
               Old_Sn_Exibir_Borda,
               New_Sn_Exibir_Borda,
               Old_Cd_Pasta_Link,
               New_Cd_Pasta_Link,
               Old_Sn_Abrir_Link_Popup,
               New_Sn_Abrir_Link_Popup,
               Old_Sn_Negrito_Cabecalho,
               New_Sn_Negrito_Cabecalho,
               Old_Sn_Negrito_Rodape,
               New_Sn_Negrito_Rodape,
               Cd_Usuario_Alteracao,
               Tp_Operacao,
               Data_Log)
            Values
              (Custom.Seq_Log_Portlet_Sql.Nextval,
               i.Aba,
               i.Pagina,
               i.Cod_Portlet,
               i.Nm_Portlet,
               i.Dt_Criacao_Portlet,
               i.Cd_Usuario_Criador,
               i.Old_Sql_Portlet,
               i.New_Sql_Portlet,
               i.Old_Nr_Campo_Ds_Link,
               i.New_Nr_Campo_Ds_Link,
               i.Old_Nr_Campo_Ds_Hint,
               i.New_Nr_Campo_Ds_Hint,
               i.Banco,
               i.Old_Tipo_Link,
               i.New_Tipo_Link,
               i.Old_Nr_Campo_Ds_Pesquisa,
               i.New_Nr_Campo_Ds_Pesquisa,
               i.Old_Cd_Fonte_Cabecalho,
               i.New_Cd_Fonte_Cabecalho,
               i.Old_Nr_Tamanho_Fonte_Cabecalho,
               i.New_Nr_Tamanho_Fonte_Cabecalho,
               i.Old_Ds_Cor_Fonte_Cabecalho,
               i.New_Ds_Cor_Fonte_Cabecalho,
               i.Old_Ds_Cor_Fundo_Cabecalho,
               i.New_Ds_Cor_Fundo_Cabecalho,
               i.Old_Cd_Fonte_Rodape,
               i.New_Cd_Fonte_Rodape,
               i.Old_Nr_Tamanho_Fonte_Rodape,
               i.New_Nr_Tamanho_Fonte_Rodape,
               i.Old_Ds_Cor_Fonte_Rodape,
               i.New_Ds_Cor_Fonte_Rodape,
               i.Old_Ds_Cor_Fundo_Rodape,
               i.New_Ds_Cor_Fundo_Rodape,
               i.Old_Sn_Exibir_Cabecalho,
               i.New_Sn_Exibir_Cabecalho,
               i.Old_Sn_Exibir_Borda,
               i.New_Sn_Exibir_Borda,
               i.Old_Cd_Pasta_Link,
               i.New_Cd_Pasta_Link,
               i.Old_Sn_Abrir_Link_Popup,
               i.New_Sn_Abrir_Link_Popup,
               i.Old_Sn_Negrito_Cabecalho,
               i.New_Sn_Negrito_Cabecalho,
               i.Old_Sn_Negrito_Rodape,
               i.New_Sn_Negrito_Rodape,
               User,
               'I',
               Sysdate);
          
          Exception
            When Others Then
            
              v_Erro_Ora := Sqlerrm;
              Begin
                Insert Into Custom.Log_Ctrl_Erro_Audit_Portlet
                  (Cd_Ctrl_Erro_Audit_Portlet,
                   Erro_Ora,
                   Tp_Operacao,
                   Dt_Log_Erro,
                   Cd_Usuario)
                Values
                  (Custom.Seq_Log_Ctrl_Erro_Aud_Portlet.Nextval,
                   v_Erro_Ora,
                   'I',
                   Sysdate,
                   User);
              
              End;
            
          End;
        
        End If;
      
      End;
    End Loop;
  
  Elsif (Updating) Then
  
    For i In Cauditportlet Loop
    
      Begin
        If (Cauditportlet%Found) Then
          Begin
            Insert Into Custom.Log_Portlet_Sql
              (Cd_Log_Portlet_Sql,
               Aba,
               Pagina,
               Cod_Portlet,
               Nm_Portlet,
               Dt_Criacao_Portlet,
               Cd_Usuario_Criador,
               Old_Sql_Portlet,
               New_Sql_Portlet,
               Old_Nr_Campo_Ds_Link,
               New_Nr_Campo_Ds_Link,
               Old_Nr_Campo_Ds_Hint,
               New_Nr_Campo_Ds_Hint,
               Banco,
               Old_Tipo_Link,
               New_Tipo_Link,
               Old_Nr_Campo_Ds_Pesquisa,
               New_Nr_Campo_Ds_Pesquisa,
               Old_Cd_Fonte_Cabecalho,
               New_Cd_Fonte_Cabecalho,
               Old_Nr_Tamanho_Fonte_Cabecalho,
               New_Nr_Tamanho_Fonte_Cabecalho,
               Old_Ds_Cor_Fonte_Cabecalho,
               New_Ds_Cor_Fonte_Cabecalho,
               Old_Ds_Cor_Fundo_Cabecalho,
               New_Ds_Cor_Fundo_Cabecalho,
               Old_Cd_Fonte_Rodape,
               New_Cd_Fonte_Rodape,
               Old_Nr_Tamanho_Fonte_Rodape,
               New_Nr_Tamanho_Fonte_Rodape,
               Old_Ds_Cor_Fonte_Rodape,
               New_Ds_Cor_Fonte_Rodape,
               Old_Ds_Cor_Fundo_Rodape,
               New_Ds_Cor_Fundo_Rodape,
               Old_Sn_Exibir_Cabecalho,
               New_Sn_Exibir_Cabecalho,
               Old_Sn_Exibir_Borda,
               New_Sn_Exibir_Borda,
               Old_Cd_Pasta_Link,
               New_Cd_Pasta_Link,
               Old_Sn_Abrir_Link_Popup,
               New_Sn_Abrir_Link_Popup,
               Old_Sn_Negrito_Cabecalho,
               New_Sn_Negrito_Cabecalho,
               Old_Sn_Negrito_Rodape,
               New_Sn_Negrito_Rodape,
               Cd_Usuario_Alteracao,
               Tp_Operacao,
               Data_Log)
            Values
              (Custom.Seq_Log_Portlet_Sql.Nextval,
               i.Aba,
               i.Pagina,
               i.Cod_Portlet,
               i.Nm_Portlet,
               i.Dt_Criacao_Portlet,
               i.Cd_Usuario_Criador,
               i.Old_Sql_Portlet,
               i.New_Sql_Portlet,
               i.Old_Nr_Campo_Ds_Link,
               i.New_Nr_Campo_Ds_Link,
               i.Old_Nr_Campo_Ds_Hint,
               i.New_Nr_Campo_Ds_Hint,
               i.Banco,
               i.Old_Tipo_Link,
               i.New_Tipo_Link,
               i.Old_Nr_Campo_Ds_Pesquisa,
               i.New_Nr_Campo_Ds_Pesquisa,
               i.Old_Cd_Fonte_Cabecalho,
               i.New_Cd_Fonte_Cabecalho,
               i.Old_Nr_Tamanho_Fonte_Cabecalho,
               i.New_Nr_Tamanho_Fonte_Cabecalho,
               i.Old_Ds_Cor_Fonte_Cabecalho,
               i.New_Ds_Cor_Fonte_Cabecalho,
               i.Old_Ds_Cor_Fundo_Cabecalho,
               i.New_Ds_Cor_Fundo_Cabecalho,
               i.Old_Cd_Fonte_Rodape,
               i.New_Cd_Fonte_Rodape,
               i.Old_Nr_Tamanho_Fonte_Rodape,
               i.New_Nr_Tamanho_Fonte_Rodape,
               i.Old_Ds_Cor_Fonte_Rodape,
               i.New_Ds_Cor_Fonte_Rodape,
               i.Old_Ds_Cor_Fundo_Rodape,
               i.New_Ds_Cor_Fundo_Rodape,
               i.Old_Sn_Exibir_Cabecalho,
               i.New_Sn_Exibir_Cabecalho,
               i.Old_Sn_Exibir_Borda,
               i.New_Sn_Exibir_Borda,
               i.Old_Cd_Pasta_Link,
               i.New_Cd_Pasta_Link,
               i.Old_Sn_Abrir_Link_Popup,
               i.New_Sn_Abrir_Link_Popup,
               i.Old_Sn_Negrito_Cabecalho,
               i.New_Sn_Negrito_Cabecalho,
               i.Old_Sn_Negrito_Rodape,
               i.New_Sn_Negrito_Rodape,
               User,
               'A',
               Sysdate);
          
          Exception
            When Others Then
            
              v_Erro_Ora := Sqlerrm;
              Begin
                Insert Into Custom.Log_Ctrl_Erro_Audit_Portlet
                  (Cd_Ctrl_Erro_Audit_Portlet,
                   Erro_Ora,
                   Tp_Operacao,
                   Dt_Log_Erro,
                   Cd_Usuario)
                Values
                  (Custom.Seq_Log_Ctrl_Erro_Aud_Portlet.Nextval,
                   v_Erro_Ora,
                   'A',
                   Sysdate,
                   User);
              
              End;
            
          End;
        End If;
      
      End;
    End Loop;
  
  Else
    For i In Cauditportlet Loop
    
      Begin
      
        If (Cauditportlet%Found) Then
          Begin
            Insert Into Custom.Log_Portlet_Sql
              (Cd_Log_Portlet_Sql,
               Aba,
               Pagina,
               Cod_Portlet,
               Nm_Portlet,
               Dt_Criacao_Portlet,
               Cd_Usuario_Criador,
               Old_Sql_Portlet,
               New_Sql_Portlet,
               Old_Nr_Campo_Ds_Link,
               New_Nr_Campo_Ds_Link,
               Old_Nr_Campo_Ds_Hint,
               New_Nr_Campo_Ds_Hint,
               Banco,
               Old_Tipo_Link,
               New_Tipo_Link,
               Old_Nr_Campo_Ds_Pesquisa,
               New_Nr_Campo_Ds_Pesquisa,
               Old_Cd_Fonte_Cabecalho,
               New_Cd_Fonte_Cabecalho,
               Old_Nr_Tamanho_Fonte_Cabecalho,
               New_Nr_Tamanho_Fonte_Cabecalho,
               Old_Ds_Cor_Fonte_Cabecalho,
               New_Ds_Cor_Fonte_Cabecalho,
               Old_Ds_Cor_Fundo_Cabecalho,
               New_Ds_Cor_Fundo_Cabecalho,
               Old_Cd_Fonte_Rodape,
               New_Cd_Fonte_Rodape,
               Old_Nr_Tamanho_Fonte_Rodape,
               New_Nr_Tamanho_Fonte_Rodape,
               Old_Ds_Cor_Fonte_Rodape,
               New_Ds_Cor_Fonte_Rodape,
               Old_Ds_Cor_Fundo_Rodape,
               New_Ds_Cor_Fundo_Rodape,
               Old_Sn_Exibir_Cabecalho,
               New_Sn_Exibir_Cabecalho,
               Old_Sn_Exibir_Borda,
               New_Sn_Exibir_Borda,
               Old_Cd_Pasta_Link,
               New_Cd_Pasta_Link,
               Old_Sn_Abrir_Link_Popup,
               New_Sn_Abrir_Link_Popup,
               Old_Sn_Negrito_Cabecalho,
               New_Sn_Negrito_Cabecalho,
               Old_Sn_Negrito_Rodape,
               New_Sn_Negrito_Rodape,
               Cd_Usuario_Alteracao,
               Tp_Operacao,
               Data_Log)
            Values
              (Custom.Seq_Log_Portlet_Sql.Nextval,
               i.Aba,
               i.Pagina,
               i.Cod_Portlet,
               i.Nm_Portlet,
               i.Dt_Criacao_Portlet,
               i.Cd_Usuario_Criador,
               i.Old_Sql_Portlet,
               i.New_Sql_Portlet,
               i.Old_Nr_Campo_Ds_Link,
               i.New_Nr_Campo_Ds_Link,
               i.Old_Nr_Campo_Ds_Hint,
               i.New_Nr_Campo_Ds_Hint,
               i.Banco,
               i.Old_Tipo_Link,
               i.New_Tipo_Link,
               i.Old_Nr_Campo_Ds_Pesquisa,
               i.New_Nr_Campo_Ds_Pesquisa,
               i.Old_Cd_Fonte_Cabecalho,
               i.New_Cd_Fonte_Cabecalho,
               i.Old_Nr_Tamanho_Fonte_Cabecalho,
               i.New_Nr_Tamanho_Fonte_Cabecalho,
               i.Old_Ds_Cor_Fonte_Cabecalho,
               i.New_Ds_Cor_Fonte_Cabecalho,
               i.Old_Ds_Cor_Fundo_Cabecalho,
               i.New_Ds_Cor_Fundo_Cabecalho,
               i.Old_Cd_Fonte_Rodape,
               i.New_Cd_Fonte_Rodape,
               i.Old_Nr_Tamanho_Fonte_Rodape,
               i.New_Nr_Tamanho_Fonte_Rodape,
               i.Old_Ds_Cor_Fonte_Rodape,
               i.New_Ds_Cor_Fonte_Rodape,
               i.Old_Ds_Cor_Fundo_Rodape,
               i.New_Ds_Cor_Fundo_Rodape,
               i.Old_Sn_Exibir_Cabecalho,
               i.New_Sn_Exibir_Cabecalho,
               i.Old_Sn_Exibir_Borda,
               i.New_Sn_Exibir_Borda,
               i.Old_Cd_Pasta_Link,
               i.New_Cd_Pasta_Link,
               i.Old_Sn_Abrir_Link_Popup,
               i.New_Sn_Abrir_Link_Popup,
               i.Old_Sn_Negrito_Cabecalho,
               i.New_Sn_Negrito_Cabecalho,
               i.Old_Sn_Negrito_Rodape,
               i.New_Sn_Negrito_Rodape,
               User,
               'D',
               Sysdate);
          
          Exception
            When Others Then
            
              v_Erro_Ora := Sqlerrm;
              Begin
                Insert Into Custom.Log_Ctrl_Erro_Audit_Portlet
                  (Cd_Ctrl_Erro_Audit_Portlet,
                   Erro_Ora,
                   Tp_Operacao,
                   Dt_Log_Erro,
                   Cd_Usuario)
                Values
                  (Custom.Seq_Log_Ctrl_Erro_Aud_Portlet.Nextval,
                   v_Erro_Ora,
                   'D',
                   Sysdate,
                   User);
              
              End;
            
          End;
        End If;
      
      End;
    End Loop;
  
  End If;

  If (Cauditportlet%Isopen) Then
    Close Cauditportlet;
  End If;

Exception
  When Others Then
  
    v_Erro_Ora := Sqlerrm;
    Begin
      Insert Into Custom.Log_Ctrl_Erro_Audit_Portlet
        (Cd_Ctrl_Erro_Audit_Portlet,
         Erro_Ora,
         Tp_Operacao,
         Dt_Log_Erro,
         Cd_Usuario)
      Values
        (Custom.Seq_Log_Ctrl_Erro_Aud_Portlet.Nextval,
         v_Erro_Ora,
         'E',
         Sysdate,
         User);
    
    End;
    Null;
  
End Trg_Audit_Portlet_Sql;
/
