Create Sequence custom.seq_Log_Portlet_Sql
Start With 1
Increment By 1;

Grant Select On seq_Log_Portlet_Sql To dbacp, dbaportal;


Create Table Custom.Log_Portlet_Sql(
CD_LOG_PORTLET_SQL Number(20) Null,
Aba Varchar2(100) Null,
Pagina Varchar2(100) Null,
Cod_Portlet Number(10) Null,
Nm_Portlet Varchar2(200) Null,
Dt_Criacao_Portlet Date Null,
Cd_Usuario_Criador Varchar2(30) Null,
Old_Sql_Portlet Clob Null,
New_Sql_Portlet Clob Null,
Old_Nr_Campo_Ds_Link Varchar2(10),
New_Nr_Campo_Ds_Link Varchar2(10),
Old_Nr_Campo_Ds_Hint Varchar2(10),
New_Nr_Campo_Ds_Hint Varchar2(10),
Banco Varchar2(30),
Old_Tipo_Link Varchar2(20),
New_Tipo_Link Varchar2(20),
Old_Nr_Campo_Ds_Pesquisa Varchar2(10),
New_Nr_Campo_Ds_Pesquisa Varchar2(10),
Old_Cd_Fonte_Cabecalho Varchar2(200),
New_Cd_Fonte_Cabecalho Varchar2(200),
Old_Nr_Tamanho_Fonte_Cabecalho Number(4),
New_Nr_Tamanho_Fonte_Cabecalho Number(4),
Old_Ds_Cor_Fonte_Cabecalho Varchar2(200),
New_Ds_Cor_Fonte_Cabecalho Varchar2(200),
Old_Ds_Cor_Fundo_Cabecalho Varchar2(200),
New_Ds_Cor_Fundo_Cabecalho Varchar2(200),
Old_Cd_Fonte_Rodape Varchar2(200),
New_Cd_Fonte_Rodape Varchar2(200),
Old_Nr_Tamanho_Fonte_Rodape Number(4),
New_Nr_Tamanho_Fonte_Rodape Number(4),
Old_Ds_Cor_Fonte_Rodape Varchar2(200),
New_Ds_Cor_Fonte_Rodape Varchar2(200),
Old_Ds_Cor_Fundo_Rodape Varchar2(200),
New_Ds_Cor_Fundo_Rodape Varchar2(200),
Old_Sn_Exibir_Cabecalho Varchar2(1),
New_Sn_Exibir_Cabecalho Varchar2(1),
Old_Sn_Exibir_Borda Varchar2(1),
New_Sn_Exibir_Borda Varchar2(1),
Old_Cd_Pasta_Link Number(10),
New_Cd_Pasta_Link Number(10),
Old_Sn_Abrir_Link_Popup Varchar2(1),
New_Sn_Abrir_Link_Popup Varchar2(1),
Old_Sn_Negrito_Cabecalho Varchar2(1),
New_Sn_Negrito_Cabecalho Varchar2(1),
Old_Sn_Negrito_Rodape Varchar2(1),
New_Sn_Negrito_Rodape Varchar2(1),
cd_usuario_alteracao Varchar2(30) Default User,
Tp_operacao Char(1),
data_log Date Default Sysdate,
Constraint PK_LOG_PORTLET_SQL Primary Key (CD_LOG_PORTLET_SQL)
);

Grant All On Log_Portlet_Sql To dbacp, dbaportal;
  
Create Sequence custom.seq_log_ctrl_erro_Aud_Portlet
Start With 1
Increment By 1;
       
Create Table custom.log_ctrl_erro_Audit_Portlet(
cd_ctrl_erro_Audit_Portlet Number(20),
erro_ora Varchar2(300),
tp_operacao Varchar2(1),
dt_log_erro Date Default Sysdate,
cd_usuario Varchar2(30) Default User,
Constraint PK_LOG_ctrl_erro_PORTLET_SQL Primary Key (cd_ctrl_erro_Audit_Portlet)
);

Grant All On log_ctrl_erro_Audit_Portlet  To dbacp, dbaportal; 
Grant All On seq_log_ctrl_erro_Aud_Portlet To dbacp, dbaportal; 


Comment On Column Custom.log_ctrl_erro_Audit_Portlet.Tp_Operacao Is 'I - Inser��o, A - Altera��o, D - Dele��o, E - Exce��o do oracle n�o tratada ';



Select * From Custom.Log_Portlet_Sql;
