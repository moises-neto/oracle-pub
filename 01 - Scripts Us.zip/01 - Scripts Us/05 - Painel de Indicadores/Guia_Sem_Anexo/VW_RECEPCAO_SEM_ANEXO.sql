CREATE OR REPLACE VIEW DBAPS.VW_RECEPCAO_SEM_ANEXO AS
select GG.Nr_Transacao  Nrautorizacao,
       A.NM_AUTORIZADOR funcionario_Digitacao,
     -- GG.NR_CARTEIRA_BENEFICIARIO as Carteira,

       (GG.DT_EMISSAO) DT_DIGITACAO,
       decode(gg.cd_unimed_origem, '018', 'SOROCABA', 'INTERCAMBIO') origem,

       case
         when gg.cd_unimed_origem = '018' then
          (select u.nm_segurado
             from dbaps.usuario u
            where u.cd_matricula = gg.cd_matricula)
         when gg.ds_destino_cortesia is null then
          (select bt.nm_segurado
             from dbaps.beneficiario_transito bt
            where bt.cd_matricula = gg.nr_carteira_beneficiario)
         else
          gg.ds_destino_cortesia
       end nopessoa,

       fnc_status_guia(GG.NR_GUIA) STATUS,
       GG.CD_TIPO_ATENDIMENTO cd_Tipoautorizacao,
       Decode(GG.CD_TIPO_ATENDIMENTO,
              '2',
              'Exame',
              '3',
              'Interna��o',
              'Consulta') Tipoautorizacao,

       Case
         When To_Char(GG.DT_EMISSAO, 'd') = '1' Then --S�bado
          DBAPS.Fn_Dias_Uteis_Feriado(GG.DT_EMISSAO, (Sysdate))
         When To_Char(GG.DT_EMISSAO, 'd') = '7' Then --Domingo
          DBAPS.Fn_Dias_Uteis_Feriado(GG.DT_EMISSAO, (Sysdate))
         When DBAPS.Fn_Dias_Uteis_Feriado(GG.DT_EMISSAO, GG.DT_EMISSAO) = 0 Then
          DBAPS.Fn_Dias_Uteis_Feriado(GG.DT_EMISSAO, (Sysdate))
         Else
          DBAPS.Fn_Dias_Uteis_Feriado(GG.DT_EMISSAO, (Sysdate - 1))
       End Dias_Uteis,
       --motivo autoriza��o
       Decode(GG.CD_TIPO_ATENDIMENTO,
              '3',
              Fn_Adiciona_Dias_Uteis_Feria_t(GG.DT_EMISSAO, 2),
              Fn_Adiciona_Dias_Uteis_Feria_t(GG.DT_EMISSAO, 1)) Dias_Maximo_Resposta,

       trunc(GG.Dt_Impressao_Guia) Dt_Impressao_Guia, --emitida?
       gg.nr_guia nr_guia

  from DBAPS.GUIA GG, DBAPS.AUTORIZADOR A

 where A.CD_AUTORIZADOR = GG.CD_AUTORIZADOR

   -- Ana Flavia e Tiemi pediram para apresentar as guias emitidas.
   --and GG.DT_IMPRESSAO_GUIA is null

   And trunc(gg.dt_emissao) >= '01/02/2019'

   AND (substr(A.NM_AUTORIZADOR, 1, 1) <> 'C' and
       substr(A.NM_AUTORIZADOR, 1, 3) <> '800')

   And not exists
 (select 1
          from dbaps.mot_cancelamento_guia mc
         where mc.tp_motivo = 'C' --guia cancelada
           and mc.cd_mot_cancelamento_guia = GG.Cd_Mot_Cancelamento_Guia)

   And not exists
 (Select 1 From Guia_Anexo a Where a.nr_guia = gg.nr_guia)

   and not exists (Select GI.NR_GUIA
          FROM DBAPS.GUIA_OCORRENCIA GI
         WHERE GI.NR_GUIA = gg.nr_guia
           and gi.cd_classificacao_ocor_guia = 87)

   and exists

 (

        SELECT 1
          FROM DBAPS.LOG_AUTORIZA l, dbasgu.usuarios us
         where l.nm_usuario_oracle = us.cd_usuario
           and l.nr_guia = gg.nr_guia
           and US.Cd_Usuario = A.CD_USUARIO
           and l.ds_funcionalidade like '[I] GUIA%CADASTRADA'
           And (substr(US.DS_OBSERVACAO, 1, 27) =
               '2013 - RECEPCAO COOPERATIVA' or
               US.DS_OBSERVACAO IN('0189 - UNIDADE ZONA NORTE (POSTOS)', '209 - AUTORIZACOES ZONA NORTE'))
        )

   and gg.cd_tipo_atendimento <> 1

     and not exists

 (

        SELECT 1
          FROM DBAPS.LOG_AUTORIZA l, dbasgu.usuarios us
         where l.nm_usuario_oracle = us.cd_usuario
           and l.nr_guia = gg.nr_guia
           and US.Cd_Usuario = A.CD_USUARIO
           and us.cd_usuario in ('GIDIAS', 'ASARDELA')
           and trunc(l.dt_acao) < '09/11/2020'

        ) -- Colaboradora era da Auditoria e a condi��o foi realizada
        --para n�o trazer guias com logs dela anteriores ao dia 01/11/2020.


-- Por telefone, Tiemi pediu para tirar as guias de consultas

  /* union


   select GG.Nr_Transacao  Nrautorizacao,
       A.NM_AUTORIZADOR funcionario_Digitacao,

       trunc(GG.DT_EMISSAO) DT_DIGITACAO,
       decode(gg.cd_unimed_origem, '018', 'SOROCABA', 'INTERCAMBIO') origem,

       case
         when gg.cd_unimed_origem = '018' then
          (select u.nm_segurado
             from dbaps.usuario u
            where u.cd_matricula = gg.cd_matricula)
         when gg.ds_destino_cortesia is null then
          (select bt.nm_segurado
             from dbaps.beneficiario_transito bt
            where bt.cd_matricula = gg.nr_carteira_beneficiario)
         else
          gg.ds_destino_cortesia
       end nopessoa,

       fnc_status_guia(GG.NR_GUIA) STATUS,
       GG.CD_TIPO_ATENDIMENTO cd_Tipoautorizacao,
       Decode(GG.CD_TIPO_ATENDIMENTO,
              '2',
              'Exame',
              '3',
              'Interna��o',
              'Consulta') Tipoautorizacao,

       Case
         When To_Char(GG.DT_EMISSAO, 'd') = '1' Then --S�bado
          DBAPS.Fn_Dias_Uteis_Feriado(GG.DT_EMISSAO, (Sysdate))
         When To_Char(GG.DT_EMISSAO, 'd') = '7' Then --Domingo
          DBAPS.Fn_Dias_Uteis_Feriado(GG.DT_EMISSAO, (Sysdate))
         When DBAPS.Fn_Dias_Uteis_Feriado(GG.DT_EMISSAO, GG.DT_EMISSAO) = 0 Then
          DBAPS.Fn_Dias_Uteis_Feriado(GG.DT_EMISSAO, (Sysdate))
         Else
          DBAPS.Fn_Dias_Uteis_Feriado(GG.DT_EMISSAO, (Sysdate - 1))
       End Dias_Uteis,
       --motivo autoriza��o
       Decode(GG.CD_TIPO_ATENDIMENTO,
              '3',
              Fn_Adiciona_Dias_Uteis_Feria_t(GG.DT_EMISSAO, 2),
              Fn_Adiciona_Dias_Uteis_Feria_t(GG.DT_EMISSAO, 1)) Dias_Maximo_Resposta,

       trunc(GG.Dt_Impressao_Guia) Dt_Impressao_Guia, --emitida?
       gg.nr_guia nr_guia

  from DBAPS.GUIA GG, DBAPS.AUTORIZADOR A

 where A.CD_AUTORIZADOR = GG.CD_AUTORIZADOR

   and GG.DT_IMPRESSAO_GUIA is null
   And trunc(gg.dt_emissao) >= '01/02/2019'

   AND (substr(A.NM_AUTORIZADOR, 1, 1) <> 'C' and
       substr(A.NM_AUTORIZADOR, 1, 3) <> '800')


   And not exists
 (Select 1 From Guia_Anexo a Where a.nr_guia = gg.nr_guia)

   and not exists (Select GI.NR_GUIA
          FROM DBAPS.GUIA_OCORRENCIA GI
         WHERE GI.NR_GUIA = gg.nr_guia
           and gi.cd_classificacao_ocor_guia = 87)

   and exists

 (

        SELECT 1
          FROM DBAPS.LOG_AUTORIZA l, dbasgu.usuarios us
         where l.nm_usuario_oracle = us.cd_usuario
           and l.nr_guia = gg.nr_guia
           and US.Cd_Usuario = A.CD_USUARIO
           and l.ds_funcionalidade like '[I] GUIA%CADASTRADA'
           And (substr(US.DS_OBSERVACAO, 1, 27) =
               '2013 - RECEPCAO COOPERATIVA' or
               US.DS_OBSERVACAO = '0189 - UNIDADE ZONA NORTE (POSTOS)')

        )

   and (gg.cd_tipo_atendimento = 1 and gg.sn_valida_rest_carencia = 'N' and upper(substr(fnc_status_guia(GG.NR_GUIA), 1, 10)) = 'EM ANALISE' )
*/
;
