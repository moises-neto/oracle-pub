Create Or Replace Procedure Dbacp.Prc_Importa_Usuario_Mv2000 Is

  -- Procedure que importa usu�rios do MV2000 para as solu��es de BI e Qualidade da MV
  -- Data de Cria��o - 19/11/2012
  -- Anderson Lima 
  --Altera��o de performance (Mois�s Neto) 17/01/2023.

  --Cursores
  Cursor Cusuarios Is
    Select Upper(u.Cd_Usuario) Cd_Usuario_Portal, --Alterado de lower para upper por Keila Coutinho em 24/01/2019
           Lower(u.Ds_Email) Ds_Email,
           'S' Sn_Ativo,
           u.Nm_Usuario Nm_Usuario,
           2 Cd_Tipo_Usuario,
           Null Cd_Pagina_Principal,
           Dbaportal.Fnc_Se_Criptografia(u.Cd_Usuario,
                                         Nvl((Select Substr(Rtrim(Dbasgu.Cripto_Descripto(Cd_Senha,
                                                                                         'SMVCRIPTON'),
                                                                 'KK'),
                                                           Length(Cd_Usuario) + 1,
                                                           30)
                                               From Dbasgu.Usuarios@Ormvprd.Unimed.Com.Br
                                              Where Cd_Usuario =
                                                    u.Cd_Usuario),
                                             Cd_Usuario)) Ds_Senha,
           'N' Sn_Usuario_Microstrategy,
           Null Cd_Microstrategy_Data_Source,
           Null Cd_Tipo_Licenca,
           'S' Sn_Bsc,
           'N' Sn_Backoffice
      From Dbasgu.Usuarios@Ormvprd.Unimed.Com.Br u
     Where 1 = 1
       And u.Sn_Ativo = 'S'
       And u.Cd_Usuario Not In ('LAUDOWEB',
                                'ACOLHIMENTO',
                                'COMPRASWEB',
                                'PLANISA',
                                'SCIH',
                                'FRNASC',
                                'DBAPS')
       And Not Exists
     (Select 1
              From Dbacp.Usuario_Portal Uu
             Where Upper(Uu.Cd_Usuario_Portal) = Upper(u.Cd_Usuario))
       And Exists (Select 1
              From Dbamv.Usuario_Multi_Empresa@Ormvprd.Unimed.Com.Br e
             Where e.Cd_Id_Usuario = u.Cd_Usuario
               And e.Cd_Multi_Empresa = 1);
  --And u.cd_usuario = 'YAMAUTI';

  --Variveis
  Setor          Dbaportal.Perfil_Setor.Cd_Centro_Custo%Type;
  Organizacao_Se Dbaportal.Centro_Custo.Cd_Organizacao%Type;
  Vexistedblink  Pls_Integer := 0;

  v_Xml_Favoritos Constant Varchar2(4000) := '<root>
                <favoritos nome="Meus Favoritos"/>
                <grupos nome="Meus Grupos">
                 <grupo nome="Central">
                  <item nome="Central" url="centralDocumentos.swf" descricao="Gerencie documentos de forma segura."/>
                 </grupo>
                </grupos>
              </root>';
Begin

  Begin
  
    Select 1 Into Vexistedblink From Global_Name@Ormvprd.Unimed.Com.Br;
  Exception
    When Others Then
      Vexistedblink := 0;
    
  End;

  If (Vexistedblink = 1) Then
  
    For Rusuarios In Cusuarios Loop
      Insert Into Dbacp.Usuario_Portal
        (Cd_Usuario_Portal,
         Ds_Email,
         Sn_Ativo,
         Nm_Usuario,
         Cd_Tipo_Usuario,
         Cd_Pagina_Principal,
         Ds_Senha,
         Sn_Usuario_Microstrategy,
         Cd_Microstrategy_Data_Source,
         Cd_Tipo_Licenca,
         Sn_Bsc,
         Sn_Backoffice,
         Id_Usuario_Portal,
         Cd_Endereco,
         Cd_Cargo,
         Cd_Senioridade,
         Xml_Favoritos,
         Sn_Primeiro_Acesso)
      
      Values
        (Rusuarios.Cd_Usuario_Portal,
         Rusuarios.Ds_Email,
         Rusuarios.Sn_Ativo,
         Rusuarios.Nm_Usuario,
         Rusuarios.Cd_Tipo_Usuario,
         Rusuarios.Cd_Pagina_Principal,
         Rusuarios.Ds_Senha,
         Rusuarios.Sn_Usuario_Microstrategy,
         Rusuarios.Cd_Microstrategy_Data_Source,
         Rusuarios.Cd_Tipo_Licenca,
         Rusuarios.Sn_Bsc,
         Rusuarios.Sn_Backoffice,
         Dbacp.Seq_Usuario_Portal.Nextval,
         Null,
         Null,
         Null,
         v_Xml_Favoritos,
         'N');     
         
      --Acesso ao papel SE_Acesso_Geral - Anderson Lima - 25/09/2013
      Insert Into Dbacp.Usuario_Portal_Papel
        (Cd_Usuario_Portal, Cd_Papel)
      Values
        (Rusuarios.Cd_Usuario_Portal, 332);
      Insert Into Dbacp.Usuario_Portal_Papel
        (Cd_Usuario_Portal, Cd_Papel)
      Values
        (Rusuarios.Cd_Usuario_Portal, 361); --Anderson 26/03/2014 
    
      Commit;
    
      --APLICA SETOR X CENTRO DE CUSTO       
    
      Select Max(t.Cd_Centro_Custo)
        Into Setor
        From Dbaportal.Perfil_Setor t
       Inner Join Dbaportal.Centro_Custo c
          On t.Cd_Centro_Custo = c.Cd_Centro_Custo
       Where c.Cd_Setor_Mv2000 =
             (Select Ltrim(Translate(u.Ds_Observacao,
                                     Translate(u.Ds_Observacao,
                                               '1234567890',
                                               ' '),
                                     ' ')) Setor_Mv
                From Dbasgu.Usuarios@Ormvprd.Unimed.Com.Br u
               Where u.Cd_Usuario =
                     (Select p.Cd_Usuario_Portal
                        From Dbacp.Usuario_Portal p
                       Where p.Cd_Usuario_Portal =
                             Rusuarios.Cd_Usuario_Portal))
         And Rownum = 1;
      If Setor Is Not Null Then
        Insert Into Dbaportal.Perfil_Setor
          (Tp_Perfil, Cd_Centro_Custo, Id_Usuario_Portal)
        Values
          ('P',
           Setor,
           (Select Id_Usuario_Portal
              From Dbacp.Usuario_Portal
             Where Cd_Usuario_Portal = Rusuarios.Cd_Usuario_Portal));
      
        Insert Into Dbaportal.Mudanca_Setor
          (Cd_Mudanca_Setor,
           Id_Usuario_Portal,
           Cd_Centro_Custo,
           Dt_Vigencia)
        Values
          (Dbaportal.Seq_Mudanca_Setor.Nextval,
           (Select Id_Usuario_Portal
              From Dbacp.Usuario_Portal
             Where Cd_Usuario_Portal = Rusuarios.Cd_Usuario_Portal),
           Setor,
           Sysdate);
      End If;
    
      --APLICA PAPEL HMS OU OPERADORA
    
      Select Max(c.Cd_Organizacao)
        Into Organizacao_Se
        From Dbacp.Usuario_Portal_Papel Pp
      
        Join Dbacp.Usuario_Portal p
          On p.Cd_Usuario_Portal = Pp.Cd_Usuario_Portal
      
        Join Dbaportal.Perfil_Setor Ps
          On Ps.Id_Usuario_Portal = p.Id_Usuario_Portal
      
        Join Dbaportal.Centro_Custo c
          On Ps.Cd_Centro_Custo = c.Cd_Centro_Custo
      
       Where c.Cd_Setor_Mv2000 =
             (Select Ltrim(Translate(u.Ds_Observacao,
                                     Translate(u.Ds_Observacao,
                                               '1234567890',
                                               ' '),
                                     ' ')) Setor_Mv
                From Dbasgu.Usuarios@Ormvprd.Unimed.Com.Br u
               Where u.Cd_Usuario =
                     (Select p.Cd_Usuario_Portal
                        From Dbacp.Usuario_Portal p
                       Where p.Cd_Usuario_Portal =
                             Rusuarios.Cd_Usuario_Portal));
    
      If (Organizacao_Se = 2) Then
        Insert Into Dbacp.Usuario_Portal_Papel
          (Cd_Usuario_Portal, Cd_Papel)
        Values
          (Rusuarios.Cd_Usuario_Portal, 145);
      
      Elsif (Organizacao_Se = 3) Then
      
        Insert Into Dbacp.Usuario_Portal_Papel
          (Cd_Usuario_Portal, Cd_Papel)
        Values
          (Rusuarios.Cd_Usuario_Portal, 301);
      
      End If;
    
    End Loop;
    Commit;
  
  End If;
End;
/
