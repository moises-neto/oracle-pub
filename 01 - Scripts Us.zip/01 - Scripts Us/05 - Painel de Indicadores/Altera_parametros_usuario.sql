--USER: DBAPORTAL
--Senha: DBAPORTAL
--Banco: BI_MV

select T.*, Rowid from DBACP.CONFIGURACAO_PARAMETROS_SQL t
where t.cd_usuario_portal = 'TCAMARA'
