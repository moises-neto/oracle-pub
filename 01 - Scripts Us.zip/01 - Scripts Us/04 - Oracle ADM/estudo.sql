/*GOSTARIA DE SOLICITAR UM RELAT�RIO COM TODOS OS ATENDIMENTO ABERTOS 
COMO PARTICULAR EM 2017 E 2018; ATENDIMENTO, NOME DO PACIENTE, DATA E VALOR.
*/
/*SELECT A.CD_ATENDIMENTO,
      C.NM_CONVENIO,
      CA.NM_TITULAR,
      CAT.VL_RECEITA,
      A.DT_ATENDIMENTO
 FROM ATENDIME A, CONVENIO C, CARTEIRA CA, FA_CUSTO_ATENDIMENTO CAT
WHERE C.CD_CONVENIO = 7
  AND A.CD_PACIENTE = CA.CD_PACIENTE
  AND A.CD_CONVENIO = C.CD_CONVENIO
  AND A.CD_ATENDIMENTO = CAT.CD_ATENDIMENTO
  AND A.DT_ATENDIMENTO BETWEEN '01/01/2017' AND '01/01/2018'
ORDER BY A.DT_ATENDIMENTO, A.CD_ATENDIMENTO;*/



SELECT * FROM DBAMV.USUARIOS_SET_EXA SE
WHERE SE.NM_USUARIO = 'MNETO'



SELECT * FROM DBAMV.USUARIO_UNID_ATENDIMENTO UA

WHERE UA.CD_USUARIO = 'MNETO'


SELECT * FROM DBAMV.USUARIO_SETOR S, dbasgu.papel_usuarios p

where p.cd_papel = '221'
and s.cd_setor not in '87';

custom.trg_ti_assinatura_pendente


      SELECT DISTINCT S.CD_SETOR
        FROM CUSTOM.CHM_TI_PAPEL_SETOR S
       WHERE S.CD_PAPEL IN (SELECT P.CD_PAPEL
                              FROM DBASGU.PAPEL_USUARIOS P
                             WHERE P.CD_USUARIO = USUARIO);
                             
                             SELECT * FROM CUSTOM.CHM_TI_PAPEL_SETOR s
                             WHERE s.cd_papel = '221'


SELECT *
  FROM ATENDIME A
 
 WHERE A.TP_ATENDIMENTO = 'I'
 and a.dt_atendimento between '15/09/2019' and sysdate
 AND A.HR_ALTA IS NULL
 
   AND A.DT_ATENDIMENTO between '25/02/2019' and SYSDATE
  
 
 SELECT T.*, T.ROWID FROM TRIAGEM_ATENDIMENTO T 
--WHERE T.CD_PACIENTE = '90019918'
WHERE TO_CHAR(T.DH_PRE_ATENDIMENTO, 'dd/mm/yyyy') = '11/03/2019'
 
Select * from v$instance;

select * from v$sql;

select * from v$session

select 'Moises' || ' Souza' As NomeSobrenome from dual;

select count(*) qtd_alteracao, cd_prestador, nm_usuario, (select from dbamv.laudo_apac ) from dbamv.LAUDO_RX
 
 WHERE CD_PED_RX = 1858043 
 group by cd_prestador, nm_usuario
   
 select * from dbamv.laudo_rx
 WHERE CD_PED_RX = 1858043 
 
 select from dbamv.laudo_apac


custom.trg_assinatura_pendente
------------------------------------------------------------------------------------------
SELECT *
  FROM DBAMV.FA_CUSTO_ATENDIMENTO A
 WHERE A.CD_ATENDIMENTO = 4509873

  SELECT DISTINCT NM_TITULAR
          FROM DBAMV.CARTEIRA c join dbamv.atendime a
          on c.cd_paciente = a.cd_paciente
          
         
          
         
          SELECT * FROM ALL_TABLES ALT WHERE ALT.OWNER = 'DBAMV';

select * from CUSTOM.CHM_TI_PAPEL_SETOR ps where ps.cd_setor = '221';

select distinct *
  from CUSTOM.CHM_TI_PAPEL_UNID_ATENDIMENTO
  
  Select p.Cd_Local, COUNT(*) from custom.Ti_Paineis P
  GROUP BY P.CD_LOCAL
       
        select *
          from CUSTOM.CHM_TI_PAPEL_CEN_CIR
               
                SELECT * FROM USER_TABLES;
                
                SELECT * FROM DBAMV.IMPRESSAO I
 WHERE i.dt_solicitacao like '22/03/2019'
 
 select distinct i.destino from  DBAMV.IMPRESSAO I
 
  select distinct i.destino from  DBAMV.IMPRESSAO I
 
 
 
  AND TRUNC(I.DT_SOLICITACAO) = '16/11/2011'
  AND I.NM_USUARIO = 'WSANTOS'
-------------------------------------------------------------------------------------------------
SELECT * FROM V_USUARIO;
SELECT * FROM USER_CONSTRAINTS;

SELECT * FROM USER_VIEWS_AE;

SELECT * FROM USER_INDEXES;

SELECT * FROM USER_TABLESPACES;

SELECT * FROM USER_TABLES;

select * from all_tables;

SELECT * FROM DBA_USERS U WHERE U.;

select * from custom.chm_usuarios;

select *
  from custom.chm_u
       
        select round(15.193, 1) as Round from dual;

---------------------------------------------------------------------------------------------------------
DECLARE
  vNumero1 NUMERIC := 10;
  vNumero2 NUMERIC := 20;
BEGIN
  IF (vNumero1 < vNumero2) THEN
    Dbms_Output.Put_Line('o valor � maior');
  
  ELSE
    Dbms_Output.Put_Line('o valor � menor');
  END IF;
END;

--CALULADORA SIMPLES BY MOIS�S DE SOUZA 22/09/2018;

DECLARE
  vNUM1   INTEGER := &NUMERO1;
  vOPER   CHAR(1) := '&OPERACAO';
  vNUM2   INTEGER := &NUMERO2;
  vRESULT FLOAT;
BEGIN
  IF (vOPER = '+') THEN
    vRESULT := (vNUM1 + vNUM2);
    DBMS_OUTPUT.PUT_LINE('O RESULTADO DA ADI��O �: ' || vRESULT);
  
  ELSIF (vOPER = '-') THEN
    vRESULT := (vNUM1 - vNUM2);
    DBMS_OUTPUT.PUT_LINE('O RESULTADO DA SUBTRA��O �: ' || vRESULT);
  
  ELSIF (vOPER = '*') THEN
    vRESULT := (vNUM1 * vNUM2);
    DBMS_OUTPUT.PUT_LINE('O RESULTADO DA MULTIPLICA��O �: ' || vRESULT);
  
  ELSIF (vOPER = '/') THEN
    vRESULT := (vNUM1 / vNUM2);
    DBMS_OUTPUT.PUT_LINE('O RESULTADO DA DIVIS�O �: ' || vRESULT);
  ELSE
    DBMS_OUTPUT.PUT_LINE('ERRO, TENTE NOVAMENTE: ' || vRESULT);
  END IF;

END;

---------------------------------------------------------------------------------------------------------
DECLARE

  vATENDIMENTO   CUSTOM.CHM_ATENDIMENTO%ROWTYPE;
  vSOLIITANTES   CUSTOM.CHM_SOLICITANTES%ROWTYPE;
  vUSUARIOS      CUSTOM.CHM_USUARIOS%ROWTYPE;
  vCATERORIZACAO CUSTOM.CHM_CATEGORIZACAO%ROWTYPE;
  vSERVICO       CUSTOM.CHM_SERVICO%ROWTYPE;
  vEVENTO        CUSTOM.CHM_EVENTO%ROWTYPE;

BEGIN
  
  SELECT A.CD_ATENDIMENTO AS CHAMADO,
         U.NM_USUARIO     AS NM_USUARIO_TI,
         U.CD_LOGIN       AS CD_LOGIN_TI,
         SO.NM_USUARIO    AS SOLICITANTE,
         S.NM_SETOR       AS SETOR,
         SER.NM_SERVICO   AS SERVICO,
         E.NM_EVENTO      AS EVENTO,
         A.DS_ATENDIMENTO,
         A.DS_SOLUCAO,
         A.CD_STATUS      AS STATUS,
         A.DT_ABERTURA,
         A.DT_CONCLUSAO,
         A.DT_FECHAMENTO
         
    FROM CUSTOM.CHM_ATENDIMENTO A
   INNER JOIN CUSTOM.CHM_SETOR S
      ON A.CD_SETOR = S.CD_SETOR
   INNER JOIN CUSTOM.CHM_SOLICITANTES SO
      ON A.CD_USUARIO = SO.CD_USUARIO
   INNER JOIN CUSTOM.CHM_USUARIOS U
      ON A.CD_USUARIO_TI = U.CD_USUARIO
   INNER JOIN CUSTOM.CHM_CATEGORIZACAO C
      ON a.cd_categorizacao = c.cd_categorizacao
   INNER JOIN custom.chm_servico SER
      ON c.cd_servico = ser.cd_servico
   INNER JOIN CUSTOM.CHM_EVENTO E
      ON c.cd_evento = e.cd_evento
   WHERE SO.CD_LOGIN = '&USUARIO';

END;

---------------------------------------------------------------------------------------------------------
SELECT * FROM v$database;
SELECT * FROM v$PARAMETER;
SELECT * FROM V$TABLESPACE

/*DECLARE VARI�VEIS*/

/*DECLARE
          N1 INTEGER;
          N2 INTEGER;
BEGIN
          SET N1 = 10;
          SET N2 = 10;
          SELECT N1 + N2 FROM DUAL;      
END;
          SELECT 1+2;        
          SELECT 1 + 2 FROM DUAL;*/

SELECT * FROM DBAMV.ATENDIME A WHERE A.CD_ATENDIMENTO = 4355881;

Select S.*, Custom.Cript(S.Password, 'XMSDES-CRIPT') Senha
  From Chm_Solicitantes S
 Where S.Cd_Login = Upper('USUARIO')

  SELECT R.*, R.ROWID
          FROM CC_CENTRO_CUSTO R
         
          Select cc.*
            From Custom.Cc_Centro_Custo Cc
           Where Cc.Ativo = 'S'
           Order By 2 
                    --Select para liberar USUARIO NO SAN
                      Select *
                        From San_Usuario U
                       Where U.Cd_Usuario = 'MNETO'    
                      --Select Para trazer a lista de paineis
                        select r.*, r.rowid
                                from custom.ti_paineis r;
                                select * from custom.ti_paineis_observacoes;
                                
                               

---------------------------------------------------------------------------------------------------------

--Verificar a notinha

select * from custom.san_venda_item vi where vi.id_venda_refeicao = 1090;

select *
  from produto p
 where p.cd_produto = 1090
/*
SELECT A.CD_ATENDIMENTO AS CHAMADO,
         U.NM_USUARIO     AS NM_USUARIO_TI,
         U.CD_LOGIN       AS CD_LOGIN_TI,
         SO.NM_USUARIO    AS SOLICITANTE,
         S.NM_SETOR       AS SETOR,
         SER.NM_SERVICO   AS SERVICO,
         E.NM_EVENTO      AS EVENTO,
         A.DS_ATENDIMENTO,
         A.DS_SOLUCAO,
         A.CD_STATUS      AS STATUS,
         A.DT_ABERTURA,
         A.DT_CONCLUSAO,
         A.DT_FECHAMENTO
    FROM CUSTOM.CHM_ATENDIMENTO A
   INNER JOIN CUSTOM.CHM_SETOR S
      ON A.CD_SETOR = S.CD_SETOR
   INNER JOIN CUSTOM.CHM_SOLICITANTES SO
      ON A.CD_USUARIO = SO.CD_USUARIO
   INNER JOIN CUSTOM.CHM_USUARIOS U
      ON A.CD_USUARIO_TI = U.CD_USUARIO
   INNER JOIN CUSTOM.CHM_CATEGORIZACAO C
      ON a.cd_categorizacao = c.cd_categorizacao
   INNER JOIN custom.chm_servico SER
      ON c.cd_servico = ser.cd_servico
   INNER JOIN CUSTOM.CHM_EVENTO E
      ON c.cd_evento = e.cd_evento
   WHERE SO.CD_LOGIN = '&USUARIO'
   */

/*Excluir Parecer medico (Interconsulta) - Para poder dar alta por exemplo
-- Bloco 1
-- Pesquisa da Interconsulta em aberto
Select P.*,P.Rowid 
  From Par_Med P
Where P.Cd_Atendimento = 2748670
   And P.Dt_Parecer     Is Null
   And P.Ds_Situacao    = 'Solicitado'
  
-- Bloco 2 
-- Delete do detalhamento do parecer m�dico em aberto   
Delete Acao_Parecer_Medico A
  Where A.Cd_Par_Med = 8901 -- c�digo do parecer m�dico que ser� deletado.*/

/* TOTAL DE CHAMADOS POR EMPRESA 
BY MOIS�S DE SOUZA NETO*/

/*SELECT COUNT(A.CD_ATENDIMENTO) AS CHAMADOS,
       EM.NM_EMPRESA AS EMPRESA      
FROM CUSTOM.CHM_ATENDIMENTO A 
     INNER JOIN CUSTOM.CHM_USUARIOS U
           ON A.CD_USUARIO_TI = U.CD_USUARIO
     INNER JOIN CUSTOM.CHM_USU_EQUIPE UE
           ON U.CD_USUARIO = UE.CD_USUARIO
     INNER JOIN CUSTOM.CHM_EQUIPE E
           ON UE.CD_EQUIPE = E.CD_EQUIPE
     INNER JOIN CUSTOM.CHM_EMPRESA EM
           ON E.CD_EMPRESA = EM.CD_EMPRESA
WHERE U.SN_ATIVO = 'S'
GROUP BY EM.NM_EMPRESA;*/

--LISTA DE USU�RIOS NO BANCO, SEM OS USU�RIOS ADM.
/*SELECT username
FROM dba_users
WHERE username NOT IN('QS_CB','PERFSTAT','QS_ADM',
                      'PM','SH','HR','OE',
                      'ODM_MTR','WKPROXY','ANONYMOUS',
                      'OWNER','SYS','SYSTEM','SCOTT',
                      'SYSMAN','XDB','DBSNMP','EXFSYS',
                      'OLAPSYS','MDSYS','WMSYS','WKSYS',
                      'DMSYS','ODM','EXFSYS','CTXSYS','LBACSYS',
                      'ORDPLUGINS','SQLTXPLAIN','OUTLN',
                      'TSMSYS','XS$NULL','TOAD','STREAM',
                      'SPATIAL_CSW_ADMIN','SPATIAL_WFS_ADMIN',
                      'SI_INFORMTN_SCHEMA','QS','QS_CBADM',
                      'QS_CS','QS_ES','QS_OS','QS_WS','PA_AWR_USER',
                      'OWBSYS_AUDIT','OWBSYS','ORDSYS','ORDDATA',
                      'ORACLE_OCM','MGMT_VIEW','MDDATA',
                      'FLOWS_FILES','FLASHBACK','AWRUSER',
                      'APPQOSSYS','APEX_PUBLIC_USER',
                      'APEX_030200','FLOWS_020100');*/

---------------------------------------------------------------------------------------------------------
--CONSULTA DE SESSOES NO BANCO, SEM AS SESSOES DE USU�RIOS DE INTEGRA��O E MOSTRANDO SOMENTE OS USU�RIOS QUE EST�O EM ALGUMA TELA.                      
  SELECT S.USERNAME   AS USUARIO,
         S.OSUSER     AS USUARIO_REDE,
         S.TERMINAL   AS MAQUINA,
         S.PROGRAM,
         S.MODULE     AS MODULO,
         S.ACTION     AS TELA,
         S.LOGON_TIME AS TEMPO_EXEC,
         S.STATUS,
         S.SID,
         S.SERIAL#
          FROM V$SESSION S
         WHERE S.USERNAME IS NOT NULL
           AND S.STATUS NOT IN ('KILLED')
           AND S.USERNAME NOT IN ('TISS',
                                  'SYS',
                                  'DBAMV',
                                  'INOVAPAR',
                                  'GEINTEGRA',
                                  'ACESSOPRD',
                                  'GERENCIADOR',
                                  'KTWORKFLOWBD',
                                  'KTSIAINTEGRABD',
                                  'MVINTEGRA',
                                  'KTSIABD',
                                  'CUSTOM',
                                  'SYSMAN',
                                  'DBSNMP',
                                  'DBAKENTECH',
                                  'REMWEB',
                                  'INF$RPL')
           AND S.MODULE IS NOT NULL
           OR S.MACHINE IN ('unknown')
           AND S.ACTION NOT IN ('LOGON')
         ORDER BY S.LOGON_TIME, S.ACTION
         
         
  
---------------------------------------------------------------------------------------------------------          
             select *
               from v$session
              where username is not null
              order by logon_time,
                       sid
  
---------------------------------------------------------------------------------------------------------                     
                       -- O COMANDO ABAIXO MOSTRA TODAS AS SESS�ES NO BANCO ORACLE, SEM OS USU�RIOS DEINTEGRA��O
                         SELECT S.USERNAME   AS USUARIO,
                                S.OSUSER     AS USUARIO_REDE,
                                S.TERMINAL   AS MAQUINA,
                                S.PROGRAM,
                                S.MODULE     AS MODULO,
                                S.ACTION     AS TELA,
                                S.LOGON_TIME AS TEMPO_EXEC,
                                S.STATUS,
                                S.SID,
                                S.SERIAL#
                           FROM V$SESSION S
                          WHERE S.USERNAME IS NOT NULL
                            AND S.STATUS NOT IN ('KILLED')
                            AND S.USERNAME NOT IN
                                ('TISS',
                                 'SYS',
                                 'DBAMV',
                                 'INOVAPAR',
                                 'GEINTEGRA',
                                 'ACESSOPRD',
                                 'GERENCIADOR',
                                 'KTWORKFLOWBD',
                                 'KTSIAINTEGRABD',
                                 'MVINTEGRA',
                                 'KTSIABD',
                                 'CUSTOM',
                                 'SYSMAN',
                                 'DBSNMP',
                                 'DBAKENTECH',
                                 'REMWEB',
                                 'INF$RPL')
                          ORDER BY S.LOGON_TIME, S.ACTION
                         

--------------------------------------------------------------------------------------------------------------------------------------------------------------------
                         --ATEN��O, O COMANDO ABAIXO, FINALIZA IMEDIATAMENTE A SESS�O DENTRO DO BANCO DE DADOS;
                         --PASSAR COMO PAR�METRO, A COLUNA SID, E DEPOIS A COLUNA SERIAL#.
                         --ALTER SYSTEM KILL SESSION '2238,39191' IMMEDIATE;
                         
                         
   select * from Vdic_Monitor_Importacao_tc U;                      
                         select * from it_agenda_central ac
                         where ac.ds_observacao is not null
                         and to_char(ac.hr_agenda,'DD/MM/YYYY') = '13/12/2018';
                         
                        -- and ac.hr_agenda  like '01/12/2018';
  SELECT * FROM Agenda_Central;                    
       It_Agenda_Central                  
       SELECT * FROM Atendime;                           
       SELECT * FROM Recurso_Central;                       
                         
  select * from DBAMV.ITPED_RX   
  
  select * from it.ds_itpre_med;     
  
  select * from Ite.Cd_Atendimento; 
  
  select * from itpre_med;              
                         
        select it.ds_itpre_med, it.ds_justificativa, it.dh_inicial
           from pre_med pre,
                itpre_med it,
                ped_rx pr,
                itped_rx rx
          where pre.cd_pre_med = it.cd_pre_med
            and pr.cd_atendimento = pre.cd_atendimento
            and pr.cd_pre_med = pre.cd_pre_med
            and pr.cd_ped_rx = rx.cd_ped_rx
            and rx.cd_itpre_med = it.cd_itpre_med
           and pre.cd_atendimento = 4707222                  
                         
         SELECT  TI_TRG_VERIFICA_IMG                
                         
         CUSTOM.TI_FN_VER_IMAGEM  
         SELECT * FROM Dbamv.ITPED_RX;              
            
           Declare
  vvalida number;
Begin

  
    SELECT COUNT(P.UBERGEBNIS_UBEID)
	  INTO VRETORNO 
	  
        FROM PACSBILDSEQ@MEDORA P
            ,UNTBEH@MEDORA      U
       WHERE P.TERMIN_UBTID(+) = U.TERMIN_UBTID 
         AND P.PATIENT_PID(+) = U.PATIENT_PID 
         AND U.UNTBEH_ZUSATZ_ID = TO_CHAR(vaccess_number); 
     RETURN (vretorno); 
     
     select *
     from PACSBILDSEQ@MEDORA P,
     UNTBEH@MEDORA      U
     where P.PACSBILDSEQ_STATUS = 'F'
     --WHERE P.TERMIN_UBTID(+) = U.TERMIN_UBTID ;
     
     AND P.PATIENT_PID(+) = U.PATIENT_PID 
     
     CUSTOM.TI_FN_VER_IMAGEM(121544);
     
     select * from dbamv.atendime a
     where a.cd_paciente = '93725214'
     
     select * from dbamv.carteira c
     where c.cd_paciente = '93725214'
     
    select rowid, p.* from PACIENTE p 
    where p.nr_cep = 06405016803
     
     select * from dbamv.pw_prontuario p
     where p.cd_prontuario = 91109027
     
     select * from dbamv.atendime a
     where a.cd_paciente = 91109027
     and a.tp_atendimento IN ('I', 'E')
     
     
     
     select * from dbamv.
     
     
     select * from dbamv.
     where a.cd_ori_ate = '4'
     and a.dt_atendimento like '21/10/2019'
     and a.tp_atendimento = 'E'
     and a.cd_especialid = 15
     and a.cd_tip_situacao = 3
     and a.tp_carater_internacao = 'E'
     where a.cd_atendimento in ('5217113', '5217152', '5217241', '5217402', '521');
                
                         
                         
                         
                         
                         
                         
                         
                         
                         
                         
                         
                         
