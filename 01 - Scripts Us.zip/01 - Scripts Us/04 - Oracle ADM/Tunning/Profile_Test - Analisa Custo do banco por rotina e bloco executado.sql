--i Number :=0;
--i := Sys.Dbms_Profiler.Start_Profiler('Rafael Lucas - Comissao: ' || rLoteComissao.Cd_Lote_Comissao);
--i := Sys.Dbms_Profiler.Stop_Profiler;
Declare

  v_Retorno Number := 0;
  i         Number := 0;

Begin
  i := Sys.Dbms_Profiler.Start_Profiler('Mois�s - Auditoria Contas: ');

  For j In (Select v.Cd_Conta_Medica As Conta, v.Cd_Lote, v.Cd_Lancamento
              From Dbaps.v_Ctas_Medicas v
             Where v.Dt_Competencia = '202208'
               And v.Tp_Situacao_Conta = 'AA'
               And v.Cd_Lote In (456491,
                                 449870,
                                 456492,
                                 454987,
                                 456507,
                                 451906,
                                 457340,
                                 457331,
                                 457285)) Loop
    Begin
    
      v_Retorno := Dbaps.Fnc_Mvs_Analisa_Conta_Amb_018(j.Cd_Lote,
                                                       j.Conta,
                                                       'S',
                                                       1);
    End;
  End Loop;
  i := Sys.Dbms_Profiler.Stop_Profiler;

End;

--Dbaps.Fnc_Mvs_Analisa_Conta_Amb_018

---DEPOIS QUE RODAR O SCRIPT, CRIAR UMA NOVA JANELA COMO "TEST WINDOW", SELECIONAR A ABA "PROFILER", EM "RUN", SELECIONE O NOME INFORMADO NO "Start_Profiler", QUE DECLAROU.
