-- Reabilitar job antigo com estado broken:

 --Desabilitar jobs.
Begin
  For i In (Select * From Dba_Jobs) Loop
  
    Begin
      Dbms_Job.Broken(983,True);
    End;
  
  End Loop;

End;

--Habilitar Jobs.



begin  custom.Pr_Planium_Envia_Evento; end;

Begin
  For i In (Select * From Dba_Jobs) Loop
  
    Begin
      Dbms_Job.Broken(i.Job, False);
    End;
  
  End Loop;

End;


Begin
  Dbms_Job.Change(Job       => 1683,
                  What      => 'begin DBAPS.PR_ENVIA_SENHA_GUIA_TERAPIAS; end;',
                  Next_Date => TO_DATE('29/03/2023 17:47', 'dd/mm/yyyy hh24:mi'),
                  Interval  => 'sysdate + 1/24',
                  Instance  => 0);
End;




 

Declare
  Cursor Cdados Is
    Select a.*
      From DBA_Jobs a
     Where a.Nls_Env Like '%HMS%'
       And a.Job In (41, 202);
  JOB_NUM BINARY_INTEGER;
Begin
  For i In Cdados Loop
    Dbms_Job.Submit(Job_Num,
                    What      => i.what,
                    Next_Date => To_Date(i.Next_Date,
                                         'dd/mm/yyyy hh24:mi:ss'),
                    Interval  => i.interval);
    Dbms_Output.Put_Line('Novo Job criado: ' || Job_Num);
  
  End Loop;

End;
   

Select * From dba_jobs a
Where a.job In (641)


Select sysdate + 1/96 From dual
              
          
    Select * From all_jobs a
    Where a.schema_user = 'CUSTOM'  
    
    Where 
        -- where a.job in (6164, 5883) 
        
        custom.pkg_importa_lote_guias
        
        DBAPS.PR_IMP_LOTES_XML_AUTO
                         CUSTOM.Prc_Carga_Gestao_Transparencia  
                         
                          DBAPS.prc_altera_und_medida
                         dbaps.PR_IMP_LOTES_XML_AUTO
 -- excluindo o job
begin  
   DBMS_JOB.Remove(42); -- Coloca aqui o numero do JOB.
end;

-- Recria o Job
DECLARE
  --Declare vari�vel que recebe n�mero do JOB.
  JOB_NUM BINARY_INTEGER;
BEGIN
  --Cria o JOB no banco e retorna o n�mero dele job_num       ---- Colocar aqui a data da proxima execu��o
  --DBMS_JOB.SUBMIT(JOB_NUM, 'BEGIN Prc_Envio_Job_Broken; END;', TO_DATE('04/11/2020, 15:00', 'dd/mm/yyyy hh24:mi'), 'sysdate + 1/24');
  DBMS_JOB.submit(JOB_NUM,
                  what      => 'BEGIN custom.PRC_NAO_COMISSIONA_PLANIUM; END;',
                  next_date => TO_DATE('30/03/2023, 04:30', 'dd/mm/yyyy hh24:mi'),
                  interval  => 'sysdate + 1');
  DBMS_OUTPUT.put_line('Job criado: ' || JOB_NUM);
END;

--Altera next date :
  CALL DBMS_JOB.NEXT_DATE(63, sysdate + 15 / 1440); 
  
  Call dbms_job.interval(job => 63, interval => 'sysdate + 15/1440'); 
  
 begin Custom.Pkg_Importa_Lote_Guias.Prc_Importa_Lote_Guias; end;
  
Select sysdate + 1/24 from dual;

declare
cont integer;
BEGIN
DBMS_JOB.submit (cont,what =>'',next_date=>'1/2/2009 08:30:00',interval=>'TRUNC(LAST_DAY(SYSDATE)) + 1 + 8/24 + 30/1440');

END;
       Select * From DBA_JOBS J Where J.JOB = 6164

select * From dba_jobs j where upper(j.WHAT) like upper('%Prc_Insere_Glosa_Ocorrencia%')



begin Custom.Prc_Altera_Prest_Pag_Hms; end;
