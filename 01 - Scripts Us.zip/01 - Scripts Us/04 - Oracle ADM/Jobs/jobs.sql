
BEGIN
  dbms_scheduler.drop_job(job_name => '12840');
END;
BEGIN
DBMS_JOB.REMOVE(12840);  --remoção de job
END;


select * from all_jobs j
where j.job = 12840


BEGIN
  DBMS_SCHEDULER.DISABLE(12840);
END;

select sysdate+30/1440 from dual; -- 30 em 30 minutos
