select * from all_jobs a                                
where a.WHAT like lower('%PRC_ATUALIZA_LOCAL_ATEN_GUIA%')


begin
 DBMS_JOB.Remove(4564);
end;

declare
--Declare vari�vel que recebe n�mero do JOB.
job_num binary_integer;
begin
--Cria o JOB no banco e retorna o n�mero dele job_num
dbms_job.submit(job_num,
what => 'begin dbaps.prc_atualiza_local_aten_guia; end;',
next_date => to_date('16/03/2021, 14:30', 'dd/mm/yyyy hh24:mi'),
interval => 'sysdate + 1');
end;

---custom.PRC_ATUALIZA_LOCAL_ATEN_GUIA




 --Verifica jobs quebrados
Select * from all_jobs a
where a.BROKEN = 'Y' 
