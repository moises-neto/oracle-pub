Select Distinct o.Table_Name,
--       'Select * from ' ||o.Owner||'.' ||o.TABLE_NAME || ' where '|| o.COLUMN_NAME || ' = 1002118'  ||';'
       'Update ' ||o.Owner||'.' || o.TABLE_NAME || ' SET ' || o.COLUMN_NAME ||' = ' || '140092' || ' where '|| o.COLUMN_NAME || ' = 1002192'  ||';'
  From All_Tab_Columns o, All_Objects a
 Where o.Column_Name = 'CD_PRESTADOR'
   And o.Owner = 'DBAPS'
   And a.Object_Name = o.Table_Name
   And a.Object_Type = 'TABLE'
   AND (o.TABLE_NAME NOT LIKE '%TEMP%' 
   AND  o.TABLE_NAME NOT LIKE '%TMP%'  
   AND  o.TABLE_NAME NOT LIKE '%TISS%'
   And o.TABLE_NAME not in ('PRESTADOR'))
   Order By o.TABLE_NAME 
   
  
