Select * From Inf$dba.Log_Auditoria_Ddl g
--where g.datetime >= '26/11/2020'
where lower(g.name) like lower('%V_CTAS_MEDICAS%')
And sysevent = 'CREATE'
Order By 1 Desc


