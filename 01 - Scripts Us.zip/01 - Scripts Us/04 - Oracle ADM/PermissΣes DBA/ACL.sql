Begin
   dbaps.Post_Pedido_Autorizacao(p_Room_Id => '1', p_Party_Size => 1);

End;

Select * From sys.dba_network_acl_privileges;
 Select * From dba_network_acls;

 grant execute on utl_http to dbaps;
grant execute on dbms_lock to dbaps

BEGIN
  DBMS_NETWORK_ACL_ADMIN.create_acl (
    acl          => 'permissao_http_ptu.xml', 
    description  => 'A test of the ACL functionality',
    principal    => 'DBAPS',
    is_grant     => TRUE, 
    privilege    => 'connect',
    start_date   => SYSTIMESTAMP,
    end_date     => NULL);
end;
 
begin
  DBMS_NETWORK_ACL_ADMIN.assign_acl (
    acl         => 'permissao_http_local.xml',
    host        => 'localhost', 
    lower_port  => 9002,
    upper_port  => Null);    
end; 
                        
Begin
  DBMS_NETWORK_ACL_ADMIN.drop_acl(acl =>'permissao_http_ptu.xml' );

End;

ok := utl_http.HTTP_CREATED('http://coo-swps02:8003/mvsaudews/app/cliente-ptu/pedido-autorizacao/658847789');
