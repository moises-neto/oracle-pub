------------------------CONSULTAR SESSAO DOS USUARIOS-----------------------------

  SELECT NVL(S.USERNAME,'Internal') Usuario,
        NVL(S.TERMINAL,'None') Maquina,
          S.OsUser Usuario_Rede,
        L.SID||','||S.SERIAL# Sid_Serial,
        U1.NAME||'.'||SUBSTR(T1.NAME,1,30) Objeto,
          S.ACTION Acao,
         s.module Modulo,
       DECODE(L.LMODE,1,'No Lock',
          2,'Row Share',
          3,'Row Exclusive',
          4,'Share',
          5,'Share Row Exclusive',
          6,'Exclusive',NULL) Tipo_Lock,
        DECODE(L.REQUEST,1,'No Lock',
          2,'Row Share',
          3,'Row Exclusive',
          4,'Share',
          5,'Share Row Exclusive',
          6,'Exclusive',NULL) request,
          To_Char( TRUNC(SYSDATE) + L.CTime*( 1/(24*60*60) ), 'hh24:mi:ss' ) Tempo,
          L.INST_ID instancia,
          L.ID1, L.ID2
FROM GV$LOCK L,
      GV$SESSION S,
      SYS.USER$ U1,
      SYS.OBJ$ T1
  WHERE L.SID = S.SID
      AND T1.OBJ# = DECODE(L.ID2,0,L.ID1,L.ID2)
      AND U1.USER# = T1.OWNER#
      AND S.TYPE != 'BACKGROUND'
  ORDER BY l.ctime DESC,1,2,6;
ALTER SYSTEM KILL SESSION '1641,51071' IMMEDIATE;

------------------------------------Fim----------------------------------------------------------

-----------------------------------CONSULTAR USUARIO TRAVADO NO LABORATORIO-------------------------------------

SELECT USERNAME, TERMINAL, INSTANCIA, TAB, LMODE, REQUEST
FROM (SELECT NVL(S.USERNAME,'Internal') username, 
             NVL(S.TERMINAL,'None') terminal, 
                 L.INST_ID instancia,
             UPPER(U1.NAME||'.'||SUBSTR(T1.NAME,1,20)) tab, 
             DECODE(L.LMODE,1,'No Lock', 
                            2,'Row Share', 
                            3,'Row Exclusive', 
                            4,'Share', 
                            5,'Share Row Exclusive', 
                            6,'Exclusive',NULL) lmode, 
             DECODE(L.REQUEST,1,'No Lock', 
                            2,'Row Share', 
                            3,'Row Exclusive', 
                            4,'Share', 
                            5,'Share Row Exclusive', 
                            6,'Exclusive',NULL) request  
             FROM gV$LOCK L,  
                  gV$SESSION S, 
                  SYS.USER$ U1, 
                  SYS.OBJ$ T1 
WHERE L.INST_ID = S.INST_ID AND L.SID = S.SID  
      AND T1.OBJ# = DECODE(L.ID2,0,L.ID1,L.ID2)  
      AND U1.USER# = T1.OWNER# 
      AND S.TYPE != 'BACKGROUND' 
ORDER BY 1,2,5) x
      WHERE x.tab LIKE '%ITPED%'
