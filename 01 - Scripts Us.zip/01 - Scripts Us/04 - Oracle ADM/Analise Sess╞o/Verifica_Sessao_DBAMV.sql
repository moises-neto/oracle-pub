SELECT s.inst_id,
       s.sid,
       s.serial#,
       'alter system kill session ''' || s.sid || ',' || s.serial# || ''' immediate' comando,
       'alter system kill session ''' || s.sid || ',' || s.serial# || ',@' || s.inst_id || ''' immediate;' comando_RAC,
       p.spid,
       s.username,
       s.action,
       Trunc(MOD(s.last_call_et / 3600, 60)) || 'h:' || Trunc(MOD((s.last_call_et / 60), 60)) || 'mim:' || Trunc(MOD(s.last_call_et, 60)) || 's' "LAST_CALL_ET",
       (SELECT sql_text FULL
          FROM gv$sql
         WHERE sql_id = s.sql_id
           AND rownum < 2) sql_text
  FROM gv$session s,
       gv$process p
 WHERE s.inst_id = p.inst_id
   AND s.paddr = p.addr
   AND s.username IS NOT NULL
   AND s.status = 'ACTIVE'
   AND (s.sid, s.inst_id) NOT IN (SELECT sid,
                                         instance_number
                                    FROM v$mystat,
                                         v$instance
                                   WHERE ROWNUM = 1)
   AND s.USERNAME = 'DBAMV' 
 ORDER BY s.last_call_et DESC;
