select * from v$database;

select * from v$tablespace

show parameters;
SELECT * FROM USER_RECYCLEBIN


select * from bkp_papeis_01


-- consulta objetos exclusos na lixeira da oracle
SELECT * FROM USER_RECYCLEBIN

-- recupera o objeto excluso se a op��o "CAN_UNDROP" estiver como "YES".
FLASHBACK TABLE NOME_TABELA TO BEFORE DROP;
