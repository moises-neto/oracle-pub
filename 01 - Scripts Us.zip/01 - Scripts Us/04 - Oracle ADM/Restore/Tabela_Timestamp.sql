 Select *
   From Temp_Contas_Mens As Of Timestamp(Systimestamp - Interval '60' Minute);
