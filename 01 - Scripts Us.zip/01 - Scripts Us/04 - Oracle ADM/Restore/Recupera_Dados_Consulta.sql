select * from dbaps.guia g
where g.nr_transacao = 2101000028728


select *
  from DBASGU.USUARIOS as of timestamp(systimestamp - interval '60' minute)
 where CD_USUARIO NOT IN ('DBASGU',
                            'GEINTEGRA',
                            'COMPRASWEB',
                            'GERENCIADOR',
                            'PACS',
                            'PALM',
                            'LAUDOWEB',
                            'SUPRIMENTOS',
                            'FARMACIADAY',
                            'RAIOX',
                            'IMUNOQUIMICA',
                            'MICROBIOLOGIA',
                            'HEMATOLOGIA',
                            'ACESSOPRD',
                            'INTEGRA',
                            'IMPRESSAO',
                            'DBAPS',
                            'ACOLHIMENTO',
                            'DBAMV',
                            'NPACIENTE',
                            'LACTARIO',
                            'ASSISTENCIAL',
                            'AUTOMATICO',
                            'TRIAGEM',
                            'TESTE',
                            'MVPADRAO',
                            'SCIH',
                            'CONTROLADOR',
                            'NEOH')
