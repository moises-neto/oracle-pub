select *
  from (select w.cd_solicitacao codigo,
                (w.dt_criacao) data,
                (select max(hb.dh_ultima_alteracao)
                   from HISTORICO_SOLICITACAO_WEB hb
                  WHERE hb.cd_solicitacao = w.cd_solicitacao) data_retorno,
                c.cd_contrato_interno contrato_interno,
                
                /*
                Chamado 120454  
                1) COLUNA SMCE: CONSIDERAR COMO SIM TODOS OS CONTRATOS FILHOS, PARA OS CONTRATOS PAIS QUE JÁ ESTIVEREM COM SIM
                */
                case
                  when (select 1
                          from custom.empresas_smce es
                         where c.cd_contrato_interno like es.contrato ||'%') = 1 --alterado a pedido de Francini, para que conte os contratos filhos
                   then
                   'S'
                  else
                   'N'
                end smce,
                
                case
                  when nvl((Select 1 From dbaps.CONTRATO_OBSERVACAO co 
where c.cd_contrato = co.cd_contrato
--or co.cd_contrato = c.cd_contrato_tem
and co.cd_tipo_observacao_contrato = 17
and rownum = 1), (Select 1 From dbaps.CONTRATO_OBSERVACAO co 
where c.cd_contrato = co.cd_contrato
and co.cd_contrato = c.cd_contrato_tem
and co.cd_tipo_observacao_contrato = 17
and rownum = 1)) = 1
                   then
                   'S'
                  else
                   'N'
                end contributario,
                
                  case
                  when (select 1
                          from custom.aditivo_obito ao
                         where ao.contrato = c.cd_contrato_interno) = 1
                   then
                   'S'
                  else
                   'N'
                end aditivo_obito, 
                
                w.cd_matricula matricula,
                w.nm_segurado  beneficiario,
                
                /*       1 - Cadastro Titular; 
                2 - Cadastro dependente;
                3 - Desligamento titular; 
                4 - Desligamento dependente; 
                5 - Transferência; 
                6 - 2ª via de carteirinha; 
                7 - Alteração de dados cadastrais; 
                8- Cadastro de Reembolso; 
                9- Alteração cadastral de beneficiário; 
                10 - Atendimento Call Center
                11 - Reativação de Beneficiário
                */
                case w.tp_solicitacao
                  when 1 then
                   'Cadastro Titular'
                  when 2 then
                   'Cadastro dependente'
                  when 3 then
                   'Desligamento titular'
                  when 4 then
                   'Desligamento dependente'
                  when 5 then
                   'Transferência'
                  when 6 then
                   '2ª via de carteirinha'
                  when 7 then
                   'Alteração de dados cadastrais'
                  when 8 then
                   'Cadastro de Reembolso'
                  when 9 then
                   'Alteração cadastral de beneficiário'
                  when 10 then
                   'Atendimento Call Center'
                  when 11 then
                   'Reativação de Beneficiário'
                  else
                   null
                end tipo_solicitacao,
                
                /*
                Chamado 120454               
                2) CRIAR UMA COLUNA: RN 412? S OU N (SE S PINTAR A CÉLULA DE ROSA). 
                PARA SER S O MOTIVO DA EXCLUSÃO UTILIZADO PELA EMPRESA DEVE SER 57 - 4 SOLICITAÇÃO DO TITULAR (RN 412)
                */
                case w.cd_mot_desligamento
                  when 57 then
                   'S'
                  else
                   'N'
                end RN_412,

              w.cd_mot_desligamento cd_mot_desligamento,
 
              (select md.ds_mot_desligamento from dbaps.mot_deslig md
                where md.cd_mot_desligamento =  w.cd_mot_desligamento) mot_desligamento,
                
                gp.ds_parentesco parentesco,
                
                case
                  when (select count(*)
                          from ARQUIVO_SOLICITACAO_WEB a
                         where a.cd_solicitacao_web = w.cd_solicitacao) > 0 then
                   'S'
                  else
                   'N'
                end anexo,
                
                /*
                1 - Aberto;
                2 - Finalizado;
                3 -Cancelado ;
                4 - Divergência; 
                5- em análise; 
                6- Edição
                */
                
                case w.tp_status
                  when 1 then
                   'Aberto'
                  when 2 then
                   'Finalizado'
                  when 3 then
                   'Cancelado'
                  when 4 then
                   'Divergência'
                  when 5 then
                   'Em análise'
                  when 6 then
                   'Edição'
                  else
                   null
                end status,
                
                case w.tp_usuario
                  when 'D' then
                   (select u.cd_familia
                      from dbaps.usuario u
                     where u.cd_matricula =
                           nvl(w.cd_matricula_tem, w.cd_matricula))
                end familia,
                
                w.cd_solicitacao_titular || ' - ' ||
                (select sw.nm_segurado
                   from dbaps.solicitacao_web sw
                  where sw.cd_solicitacao = w.cd_solicitacao_titular) titular,
                
                w.dt_admissao,
                w.dt_nascimento,
                
                case
                  when (select count(*)
                          from ARQUIVO_SOLICITACAO_WEB a
                         where a.cd_solicitacao_web = w.cd_solicitacao
                           and (upper(a.ds_arquivo) like
                               upper('%CERTID%O DE CASAMENTO%') or
                               upper(a.ds_arquivo) like
                               upper('%UNI%O EST%VEL%'))) > 0 then
                   'S'
                  else
                   'N'
                end anexo_casamento,
                
                case
                  when (select count(*)
                          from ARQUIVO_SOLICITACAO_WEB a
                         where a.cd_solicitacao_web = w.cd_solicitacao
                           and (upper(a.ds_arquivo) like
                               upper('%CARTA DE ORIENTAC%O%') or
                               upper(a.ds_arquivo) like
                               upper('%DECLARA%O%SA_DE%'))) > 0 then
                   'S'
                  else
                   'N'
                end anexo_saude,
                
                (select count(*)
                   from dbaps.usuario u
                  where u.cd_contrato in
                        (select c.cd_contrato
                           from dbaps.contrato c
                          where c.cd_contrato_interno = e.cd_interno)
                    and u.sn_ativo = 'S') qtd_vidas,
                
                Case
                  When To_Char(w.dt_criacao, 'd') = '1' Then --Sábado
                   DBAPS.Fn_Dias_Uteis_Feriado(w.dt_criacao, (Sysdate))
                  When To_Char(w.dt_criacao, 'd') = '7' Then --Domingo
                   DBAPS.Fn_Dias_Uteis_Feriado(w.dt_criacao, (Sysdate))
                  When DBAPS.Fn_Dias_Uteis_Feriado(w.dt_criacao, w.dt_criacao) = 0 Then
                   DBAPS.Fn_Dias_Uteis_Feriado(w.dt_criacao, (Sysdate))
                  Else
                   DBAPS.Fn_Dias_Uteis_Feriado(w.dt_criacao, (Sysdate - 1))
                End Dias_Uteis,
                
                /*
                Chamado 120454  
                3) NOVO CAMPO DE FILTRO: NÚMERO DE CONTRATO PAR OU IMPAR
                */
                
                case
                  when MOD(c.cd_contrato_interno, 2) = 0 then
                   0
                  else
                   1
                end par_impar
         
           from dbaps.solicitacao_web w
          inner join dbaps.empresa e
             on (w.cd_empresa = e.cd_empresa)
           left join dbaps.grau_parentesco gp
             on (w.cd_parentesco = gp.cd_parentesco)
         
         --alterado a pedido de Francini, para que conte os contratos filhos
          inner join dbaps.contrato c
             on (w.cd_contrato = c.cd_contrato)
         
          where /*w.cd_empresa = 2148
               --and w.cd_contrato = 3996
            and*/
          w.tp_status not in (2, 3) -- Finalizado e cancelado
         
       and ((#dtinicial# is null and #dtfinal# is null) or
          (trunc(w.dt_criacao) between #dtinicial# and #dtfinal#))
       and (#contrato# is null or c.cd_contrato_interno = #contrato#)
       and w.tp_solicitacao in (#tp_solicitacao#)
       and w.tp_status in (#tp_status#)) t
 where t.smce in (#smce#)
   and t.anexo_saude in (#anexo_saude#)
   and t.par_impar in (#par_impar#)
 order by t.data