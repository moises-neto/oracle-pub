--26/05/2020 Alteração Gabriel - CH2005-1365: Colocar uma coluna com o nome do atendente

SELECT nome_usu,
       cartao,
       atendente,
       trunc(dt_inicio) inicio,
(Select decode(max(tp.cd_tramite_protocolo), null, 'Não', 'Sim')
          from atend_call_center c, dbaps.tramite_protocolo_call_center tp
         where tp.cd_atend_call_center = c.cd_atend_call_center
           And c.cd_atend_call_center = ocorrencia) As Tramitacao,
(Select distinct Decode(a.dt_termino, null, 'Em aberto', 'Sim')
          from dbaps.atend_call_center a, dbaps.tip_atend_call_center c
         Where c.cd_tip_atend_call_center In (3, 4, 21, 23)
           and a.cd_atend_call_center = ocorrencia) as Respondido,
/*(Select distinct 1 qtdd
          from dbaps.atend_call_center a, dbaps.tip_atend_call_center c
         Where c.cd_tip_atend_call_center In (3, 4, 21, 23)
           and a.cd_atend_call_center = ocorrencia
           And a.dt_termino is not null) as qtdd,*/
       origem,
       evento,
       ocorrencia,
       setor,
(select  CASE
                 WHEN W.NOUNIDADE = 'SEDE' AND
                      setor in
                      ('73 - ADMINISTRATIVO IMAGEM - HMS') THEN
                  'HOSPITAL'
                 ELSE
                  W.NOUNIDADE
               END ORGANIZACAO
          from WEB_CENTRO_CUSTO@ORSAT CC, WEB_UNIDADE@ORSAT W
         where CC.CDUNIDADE = W.CDUNIDADE
           AND CC.AOATIVO = 'S'
           and cc.cdcentrocusto =
               trim(substr(LTRIM(translate(setor,
                                           translate(setor, '1234567890', ' '),
                                           ' ')),
                           0,
                           3)) and rownum =1) organizacao,
      -- previsao,
       qtd,
       Listagg(medico, ' ,') Within Group(Order By medico) medico,
       legenda_motivo,
(Select tt.Ds_Acao_Tramite
          From TRAMITE_PROTOCOLO_CALL_CENTER tt
         where tt.cd_tramite_protocolo =
               (Select max(ttt.cd_tramite_protocolo)
                  From TRAMITE_PROTOCOLO_CALL_CENTER ttt
                 where ttt.cd_atend_call_center = ocorrencia)) as ACAO

  FROM (select nome_usu,
               cartao,
               atendente,
               origem,
               evento,
               ocorrencia,
               setor,
               previsao,
               qtd,
               Listagg(funci, ' ,') Within Group(Order By funci) medico,
               legenda_motivo,
               dt_inicio
          from (
                --1 SELECT NÃO TRAZ SE TIVER REPLICA
                select decode(a.cd_usuario_eventual,
                               null,
                               (select c.nm_segurado
                                  from dbaps.usuario c
                                 where c.cd_matricula = a.cd_matricula),
                               (select ue.nm_usuario_eventual
                                  from usuario_eventual ue
                                 where ue.cd_usuario_eventual =
                                       a.cd_usuario_eventual)) nome_usu,
                        decode(a.cd_usuario_eventual,
                               null,
                               (select c.cd_mat_alternativa
                                  from dbaps.usuario c
                                 where c.cd_matricula = a.cd_matricula),
                               (select ue.nr_carteira_beneficiario
                                  from usuario_eventual ue
                                 where ue.cd_usuario_eventual =
                                       a.cd_usuario_eventual)) cartao,
                        au.nm_autorizador atendente, --Atendente
                        oaa.ds_origem_atendimento Origem,
                        xc.ds_call_center_evento evento,
                        a.cd_atend_call_center ocorrencia,
                        dpp.ds_depto_operadora SETOR,
                        case
                          when cl.cd_call_center_evento = 5 then
                           'POSTURA DO MEDICO'
                          else
                           null
                        end
                        
                        legenda_motivo,
                        
                        CASE
                          WHEN DECODE(SS.CD_SLA_CALL_CENTER,
                                      NULL,
                                      NULL,
                                      DECODE(SS.TP_SLA_CALL_CENTER,
                                             'D',
                                             
                                             DBAPS.FNC_PROXIMO_DIA_UTIL(TRUNC(a.dt_inicio),
                                                                        NVL(ss.nr_quantidade,
                                                                            0),
                                                                        'D'),
                                             
                                             'H',
                                             
                                             DBAPS.FNC_PROXIMO_DIA_UTIL(TRUNC(a.dt_inicio),
                                                                        NVL(ss.nr_quantidade,
                                                                            0),
                                                                        'H'),
                                             
                                             'M',
                                             
                                             DBAPS.FNC_PROXIMO_DIA_UTIL(TRUNC(a.dt_inicio),
                                                                        NVL(ss.nr_quantidade,
                                                                            0),
                                                                        'M'),
                                             
                                             'S',
                                             
                                             DBAPS.FNC_PROXIMO_DIA_UTIL(TRUNC(a.dt_inicio),
                                                                        NVL(ss.nr_quantidade,
                                                                            0),
                                                                        'S') --,
                                             /*'DD/MM/YYYY HH24:MI:SS')*/)) <
                               to_date(trunc(a.dt_termino), 'DD/MM/YYYY') THEN
                           'SIM'
                          WHEN a.dt_termino IS NULL THEN
                           'Não Finalizada'
                          ELSE
                           'NÃO'
                        END PREVISAO,
                        1 qtd,
                        Listagg(cl.ds_usuario_eventual, ' ,') Within Group(Order By cl.ds_usuario_eventual) funci,
                        a.dt_inicio
                
                  from CALL_CENTER_MENSAGEM     cl,
                        dbaps.atend_call_center  a,
                        dbaps.call_center_evento xc,
                        origem_atendimento       oaa,
                        dbaps.depto_operadora    dpp,
                        dbaps.sla_call_center    ss,
                        dbaps.autorizador        au
                 where cl.cd_call_center_evento in ('5', '4')
                   and a.cd_prestador is null
                   and a.cd_autorizador = au.cd_autorizador
                   and a.cd_atend_call_center = cl.cd_atend_call_center
                   and xc.cd_call_center_evento = cl.cd_call_center_evento
                   and oaa.cd_origem_atendimento = a.cd_origem_atendimento
                   and dpp.cd_depto_operadora = cl.cd_depto
                   and ss.cd_sla_call_center = a.cd_sla_call_center
                   and a.cd_atend_call_center not in
                       (select cll.cd_atend_call_center
                          from dbaps.call_center_mensagem cll
                         where cll.cd_atend_call_center =
                               a.cd_atend_call_center
                           and cll.cd_call_center_evento = '3')
                      
                   and a.cd_atend_call_center in
                       (select tt.cd_atend_call_center
                          from dbaps.tramite_protocolo_call_center tt,
                               dbaps.call_center_mensagem          cf
                         where tt.cd_atend_call_center = a.cd_atend_call_center
                           and cf.cd_atend_call_center =
                               tt.cd_atend_call_center
                           and cf.cd_atend_call_center =
                               tt.cd_atend_call_center
                           and cf.cd_call_center_evento in (4, 5)) -- estava dando conflito com o select abaixo.
                      
                   and trunc(a.dt_inicio) between #inicio# and #fim#
                   and a.cd_tip_atend_call_center <> 10
                
                 group by a.cd_usuario_eventual,
                           a.cd_matricula,
                           a.cd_usuario_eventual,
                           a.cd_usuario_eventual,
                           a.cd_matricula,
                           a.cd_usuario_eventual,
                           au.nm_autorizador,
                           oaa.ds_origem_atendimento,
                           xc.ds_call_center_evento,
                           a.cd_atend_call_center,
                           dpp.ds_depto_operadora,
                           SS.CD_SLA_CALL_CENTER,
                           a.dt_inicio,
                           SS.TP_SLA_CALL_CENTER,
                           a.dt_termino,
                           ss.nr_quantidade,
                           cl.ds_usuario_eventual,
                           cl.cd_call_center_evento,
                           a.dt_inicio
                
                union
                --TRAZ OCORRENCIAS SEM PASSAR PELA TABELA DE TRAMITAÇÃO
                select decode(a.cd_usuario_eventual,
                               null,
                               (select c.nm_segurado
                                  from dbaps.usuario c
                                 where c.cd_matricula = a.cd_matricula),
                               (select ue.nm_usuario_eventual
                                  from usuario_eventual ue
                                 where ue.cd_usuario_eventual =
                                       a.cd_usuario_eventual)) nome_usu,
                        decode(a.cd_usuario_eventual,
                               null,
                               (select c.cd_mat_alternativa
                                  from dbaps.usuario c
                                 where c.cd_matricula = a.cd_matricula),
                               (select ue.nr_carteira_beneficiario
                                  from usuario_eventual ue
                                 where ue.cd_usuario_eventual =
                                       a.cd_usuario_eventual)) cartao,
                        
                        au.nm_autorizador atendente, --Atendente
                        o.ds_origem_atendimento Origem,
                        NVL((select g.ds_tip_atend_call_center
                              from dbaps.tip_atend_call_center g
                             where g.cd_tip_atend_call_center =
                                   a.cd_tip_atend_call_center),
                            (select g.ds_tip_atend_call_center
                               from dbaps.tip_atend_call_center g
                              where g.cd_tip_atend_call_center =
                                    A.CD_TIP_ATEND_CALL_CENTER)) Evento,
                        
                        a.cd_atend_call_center OCORRENCIA,
                        
                        decode(a.cd_servico_call_center,
                               null,
                               (select scc.ds_servico_call_center
                                  from dbaps.servico_call_center scc
                                 where scc.cd_servico_call_center =
                                       a.cd_servico_call_center),
                               sc.ds_servico_call_center) SETOR,
                        
                        Listagg(decode(a.cd_mot_atend_call_center,
                                       null,
                                       (select x.ds_mot_atend_call_center
                                          from dbaps.mot_atend_call_center x
                                         where x.cd_mot_atend_call_center =
                                               a.cd_mot_atend_call_center),
                                       mo.ds_mot_atend_call_center),
                                ' ,') Within Group(Order By decode(a.cd_mot_atend_call_center, null, (select x.ds_mot_atend_call_center
                                                                                                        from dbaps.mot_atend_call_center x
                                                                                                       where x.cd_mot_atend_call_center =
                                                                                                             a.cd_mot_atend_call_center), mo.ds_mot_atend_call_center))
                        
                        LEGENDA_MOTIVO,
                        --   Listagg(null, ' ,') Within Group(Order By null)MEDICO,
                        CASE
                          WHEN DECODE(S.CD_SLA_CALL_CENTER,
                                      NULL,
                                      NULL,
                                      DECODE(S.TP_SLA_CALL_CENTER,
                                             'D',
                                             /* TO_CHAR(*/
                                             DBAPS.FNC_PROXIMO_DIA_UTIL(TRUNC(a.dt_inicio),
                                                                        NVL(s.nr_quantidade,
                                                                            0),
                                                                        'D'),
                                             /*'DD/MM/YYYY HH24:MI:SS')/,*
                                             'H',
                                             /*TO_CHAR(*/
                                             DBAPS.FNC_PROXIMO_DIA_UTIL(TRUNC(a.dt_inicio),
                                                                        NVL(s.nr_quantidade,
                                                                            0),
                                                                        'H'),
                                             /*'DD/MM/YYYY HH24:MI:SS'),*/
                                             'M',
                                             /* TO_CHAR(*/
                                             DBAPS.FNC_PROXIMO_DIA_UTIL(TRUNC(a.dt_inicio),
                                                                        NVL(s.nr_quantidade,
                                                                            0),
                                                                        'M'),
                                             /*  'DD/MM/YYYY HH24:MI:SS'),*/
                                             'S',
                                             /*TO_CHAR(*/
                                             DBAPS.FNC_PROXIMO_DIA_UTIL(TRUNC(a.dt_inicio),
                                                                        NVL(s.nr_quantidade,
                                                                            0),
                                                                        'S') --,
                                             /*'DD/MM/YYYY HH24:MI:SS')*/)) <
                               to_date(trunc(a.dt_termino), 'DD/MM/YYYY') THEN
                           'SIM'
                          WHEN a.dt_termino IS NULL THEN
                           'Não Finalizada'
                          ELSE
                           'NÃO'
                        END PREVISAO,
                        1 qtd,
                        --Listagg(null, ' ,') Within Group(Order By null) funci,
                        (select Listagg(cl.ds_usuario_eventual, ' ,') Within Group(Order By cl.ds_usuario_eventual)
                           from call_center_mensagem cl
                          where cl.cd_atend_call_center = a.cd_atend_call_center) funci,
                        a.dt_inicio
                  from dbaps.atend_call_center     a,
                        dbaps.origem_atendimento    o,
                        dbaps.sla_call_center       s,
                        dbaps.servico_call_center   sc,
                        dbaps.mot_atend_call_center mo,
                        dbaps.autorizador           au
                 where a.cd_origem_atendimento = o.cd_origem_atendimento
                   and au.cd_autorizador = a.cd_autorizador
                      -- and a.cd_atend_call_center = '484111'
                   and sc.cd_servico_call_center = a.cd_servico_call_center
                   and mo.cd_mot_atend_call_center =
                       a.cd_mot_atend_call_center
                   and a.cd_sla_call_center = s.cd_sla_call_center
                   and a.cd_prestador is null
                   and a.cd_atend_call_center not in
                       (select tt.cd_atend_call_center
                          from dbaps.tramite_protocolo_call_center tt
                         where tt.cd_atend_call_center = a.cd_atend_call_center)
                   and a.cd_atend_call_center not in
                       (select mm.cd_atend_call_center
                          from dbaps.call_center_mensagem mm
                         where mm.cd_atend_call_center = a.cd_atend_call_center
                           and mm.cd_call_center_evento = '3')
                   and trunc(a.dt_inicio) between #inicio# and #fim#
                   and a.cd_tip_atend_call_center <> 10
                 group by a.cd_usuario_eventual,
                           a.cd_matricula,
                           a.cd_usuario_eventual,
                           a.cd_matricula,
                           a.cd_usuario_eventual,
                           au.nm_autorizador, --Atendente
                           o.ds_origem_atendimento,
                           a.cd_atend_call_center,
                           a.cd_servico_call_center,
                           sc.ds_servico_call_center,
                           S.CD_SLA_CALL_CENTER,
                           S.TP_SLA_CALL_CENTER,
                           s.nr_quantidade,
                           mo.ds_mot_atend_call_center,
                           a.cd_mot_atend_call_center,
                           a.dt_inicio,
                           a.dt_termino,
                           a.cd_tip_atend_call_center,
                           a.dt_inicio
                
                union --replica /tramite
                
                select decode(a.cd_usuario_eventual,
                               null,
                               (select c.nm_segurado
                                  from dbaps.usuario c
                                 where c.cd_matricula = a.cd_matricula),
                               (select ue.nm_usuario_eventual
                                  from usuario_eventual ue
                                 where ue.cd_usuario_eventual =
                                       a.cd_usuario_eventual)) nome_usu,
                        decode(a.cd_usuario_eventual,
                               null,
                               (select c.cd_mat_alternativa
                                  from dbaps.usuario c
                                 where c.cd_matricula = a.cd_matricula),
                               (select ue.nr_carteira_beneficiario
                                  from usuario_eventual ue
                                 where ue.cd_usuario_eventual =
                                       a.cd_usuario_eventual)) cartao,
                        au.nm_autorizador atendente, --Atendente
                        o.ds_origem_atendimento Origem,
                        NVL((select g.ds_tip_atend_call_center
                              from dbaps.tip_atend_call_center g
                             where g.cd_tip_atend_call_center =
                                   TP.CD_TIP_ATEND_CALL_CENTER),
                            (select g.ds_tip_atend_call_center
                               from dbaps.tip_atend_call_center g
                              where g.cd_tip_atend_call_center =
                                    A.CD_TIP_ATEND_CALL_CENTER)) Evento,
                        a.cd_atend_call_center OCORRENCIA,
                        
                        decode(tp.cd_servico_call_center,
                               null,
                               (select scc.ds_servico_call_center
                                  from dbaps.servico_call_center scc
                                 where scc.cd_servico_call_center =
                                       a.cd_servico_call_center),
                               sc.ds_servico_call_center) SETOR,
                        
                        decode(tp.cd_mot_atend_call_center,
                               null,
                               (select x.ds_mot_atend_call_center
                                  from dbaps.mot_atend_call_center x
                                 where x.cd_mot_atend_call_center =
                                       a.cd_mot_atend_call_center),
                               mo.ds_mot_atend_call_center) LEGENDA_MOTIVO,
                        'Replica' PREVISAO,
                        1 qtd,
                        Listagg(null, ', ') Within Group(Order By null) funci,
                        a.dt_inicio
                  from dbaps.atend_call_center             a,
                        dbaps.origem_atendimento            o,
                        dbaps.tramite_protocolo_call_center tp,
                        dbaps.sla_call_center               s,
                        dbaps.servico_call_center           sc,
                        dbaps.mot_atend_call_center         mo,
                        dbaps.autorizador                   au
                 where a.cd_origem_atendimento = o.cd_origem_atendimento
                   and a.cd_autorizador = au.cd_autorizador
                      --   and a.cd_atend_call_center = '484111'
                   and tp.cd_atend_call_center = a.cd_atend_call_center
                   and tp.cd_servico_call_center =
                       sc.cd_servico_call_center(+)
                   and tp.cd_autorizador_tramite <> '139'
                      --  and a.cd_depto_operadora <> '93'
                   and mo.cd_mot_atend_call_center(+) =
                       tp.cd_mot_atend_call_center
                   and a.cd_sla_call_center = s.cd_sla_call_center
                   and a.cd_prestador is null
                   and a.cd_atend_call_center in
                       (select mm.cd_atend_call_center
                          from dbaps.call_center_mensagem mm
                         where mm.cd_atend_call_center = a.cd_atend_call_center
                           and mm.cd_call_center_evento = '3')
                   and trunc(a.dt_inicio) between #inicio# and #fim#
                   and a.cd_tip_atend_call_center <> 10
                --and tp.cd_tip_atend_call_center is not null
                
                 group by a.cd_usuario_eventual,
                           a.cd_matricula,
                           a.cd_usuario_eventual,
                           a.cd_matricula,
                           a.cd_usuario_eventual,
                           au.nm_autorizador, --Atendente
                           o.ds_origem_atendimento,
                           a.cd_atend_call_center,
                           tp.cd_servico_call_center,
                           a.cd_servico_call_center,
                           sc.ds_servico_call_center,
                           S.CD_SLA_CALL_CENTER,
                           TP.DT_INICIO_TRAMITE,
                           S.TP_SLA_CALL_CENTER,
                           s.nr_quantidade,
                           --     tp.dt_final_tramite,
                           mo.ds_mot_atend_call_center,
                           1,
                           tp.cd_mot_atend_call_center,
                           a.cd_mot_atend_call_center,
                           a.dt_inicio,
                           a.dt_termino,
                           a.cd_tip_atend_call_center,
                           TP.CD_TIP_ATEND_CALL_CENTER,
                           a.dt_inicio
                
                union --apenas eventos tratando a replica / evento
                
                select decode(aa.cd_usuario_eventual,
                               null,
                               (select c.nm_segurado
                                  from dbaps.usuario c
                                 where c.cd_matricula = aa.cd_matricula),
                               (select ue.nm_usuario_eventual
                                  from usuario_eventual ue
                                 where ue.cd_usuario_eventual =
                                       aa.cd_usuario_eventual)) nome_usu,
                        decode(aa.cd_usuario_eventual,
                               null,
                               (select c.cd_mat_alternativa
                                  from dbaps.usuario c
                                 where c.cd_matricula = aa.cd_matricula),
                               (select ue.nr_carteira_beneficiario
                                  from usuario_eventual ue
                                 where ue.cd_usuario_eventual =
                                       aa.cd_usuario_eventual)) cartao,
                        au.nm_autorizador atendente, --Atendente
                        oaa.ds_origem_atendimento Origem,
                        xc.ds_call_center_evento evento,
                        aa.cd_atend_call_center ocorrencia,
                        dpp.ds_depto_operadora SETOR,
                        -- Listagg(null, ' ,') Within Group(Order By null) legenda_motivo,
                        case
                          when cl.cd_call_center_evento = 5 then
                           'POSTURA DO MEDICO'
                          else
                           null
                        end
                        
                        legenda_motivo,
                        
                        'Replica' PREVISAO,
                        1 qtd,
                        Listagg(cl.ds_usuario_eventual, ' ,') Within Group(Order By cl.ds_usuario_eventual) funci,
                        aa.dt_inicio
                
                  from CALL_CENTER_MENSAGEM     cl,
                        dbaps.atend_call_center  aa,
                        dbaps.call_center_evento xc,
                        origem_atendimento       oaa,
                        dbaps.depto_operadora    dpp,
                        dbaps.sla_call_center    ss,
                        dbaps.autorizador        au
                 where cl.cd_call_center_evento not in ('3', '2', '1')
                   and aa.cd_autorizador = au.cd_autorizador
                   and aa.cd_atend_call_center = cl.cd_atend_call_center
                   and xc.cd_call_center_evento = cl.cd_call_center_evento
                   and oaa.cd_origem_atendimento = aa.cd_origem_atendimento
                   and dpp.cd_depto_operadora(+) = cl.cd_depto
                   and ss.cd_sla_call_center = aa.cd_sla_call_center
                   and aa.cd_prestador is null
                      -- and cl.cd_atend_call_center = '484111'
                   and cl.cd_atend_call_center in
                       (select mm.cd_atend_call_center
                          from dbaps.call_center_mensagem mm
                         where mm.cd_atend_call_center =
                               aa.cd_atend_call_center
                           and mm.cd_call_center_evento IN ('3'))
                   and trunc(aa.dt_inicio) between #inicio# and #fim#
                   and aa.cd_tip_atend_call_center <> 10
                
                 group by aa.cd_usuario_eventual,
                           aa.cd_matricula,
                           aa.cd_usuario_eventual,
                           aa.cd_usuario_eventual,
                           aa.cd_matricula,
                           aa.cd_usuario_eventual,
                           au.nm_autorizador, --Atendente
                           oaa.ds_origem_atendimento,
                           xc.ds_call_center_evento,
                           aa.cd_atend_call_center,
                           dpp.ds_depto_operadora,
                           SS.CD_SLA_CALL_CENTER,
                           aa.dt_inicio,
                           SS.TP_SLA_CALL_CENTER,
                           aa.dt_termino,
                           ss.nr_quantidade,
                           cl.ds_usuario_eventual,
                           cl.cd_call_center_evento,
                           aa.dt_inicio
                
                union
                
                --sem estar tramitando tratrando a replica
                select decode(a.cd_usuario_eventual,
                               null,
                               (select c.nm_segurado
                                  from dbaps.usuario c
                                 where c.cd_matricula = a.cd_matricula),
                               (select ue.nm_usuario_eventual
                                  from usuario_eventual ue
                                 where ue.cd_usuario_eventual =
                                       a.cd_usuario_eventual)) nome_usu,
                        decode(a.cd_usuario_eventual,
                               null,
                               (select c.cd_mat_alternativa
                                  from dbaps.usuario c
                                 where c.cd_matricula = a.cd_matricula),
                               (select ue.nr_carteira_beneficiario
                                  from usuario_eventual ue
                                 where ue.cd_usuario_eventual =
                                       a.cd_usuario_eventual)) cartao,
                        au.nm_autorizador atendente, --Atendente
                        o.ds_origem_atendimento Origem,
                        NVL((select g.ds_tip_atend_call_center
                              from dbaps.tip_atend_call_center g
                             where g.cd_tip_atend_call_center =
                                   a.cd_tip_atend_call_center),
                            (select g.ds_tip_atend_call_center
                               from dbaps.tip_atend_call_center g
                              where g.cd_tip_atend_call_center =
                                    A.CD_TIP_ATEND_CALL_CENTER)) Evento,
                        
                        a.cd_atend_call_center OCORRENCIA,
                        
                        decode(a.cd_servico_call_center,
                               null,
                               (select scc.ds_servico_call_center
                                  from dbaps.servico_call_center scc
                                 where scc.cd_servico_call_center =
                                       a.cd_servico_call_center),
                               sc.ds_servico_call_center) SETOR,
                        
                        Listagg(decode(a.cd_mot_atend_call_center,
                                       null,
                                       (select x.ds_mot_atend_call_center
                                          from dbaps.mot_atend_call_center x
                                         where x.cd_mot_atend_call_center =
                                               a.cd_mot_atend_call_center),
                                       mo.ds_mot_atend_call_center),
                                ' ,') Within Group(Order By decode(a.cd_mot_atend_call_center, null, (select x.ds_mot_atend_call_center
                                                                                                        from dbaps.mot_atend_call_center x
                                                                                                       where x.cd_mot_atend_call_center =
                                                                                                             a.cd_mot_atend_call_center), mo.ds_mot_atend_call_center))
                        
                        LEGENDA_MOTIVO,
                        'Replica' PREVISAO,
                        1 qtd,
                        Listagg(null, ' ,') Within Group(Order By null) funci,
                        a.dt_inicio
                  from dbaps.atend_call_center     a,
                        dbaps.origem_atendimento    o,
                        dbaps.sla_call_center       s,
                        dbaps.servico_call_center   sc,
                        dbaps.mot_atend_call_center mo,
                        dbaps.autorizador           au
                 where a.cd_origem_atendimento = o.cd_origem_atendimento
                   and au.cd_autorizador = a.cd_autorizador
                   and sc.cd_servico_call_center = a.cd_servico_call_center
                   and a.cd_prestador is null
                   and mo.cd_mot_atend_call_center =
                       a.cd_mot_atend_call_center
                   and a.cd_sla_call_center = s.cd_sla_call_center
                   and a.cd_atend_call_center not in
                       (select tt.cd_atend_call_center
                          from dbaps.tramite_protocolo_call_center tt
                         where tt.cd_atend_call_center = a.cd_atend_call_center)
                   and a.cd_atend_call_center in
                       (select mm.cd_atend_call_center
                          from dbaps.call_center_mensagem mm
                         where mm.cd_atend_call_center = a.cd_atend_call_center
                           and mm.cd_call_center_evento = '3')
                   and trunc(a.dt_inicio) between #inicio# and #fim#
                   and a.cd_tip_atend_call_center <> 10
                 group by a.cd_usuario_eventual,
                           a.cd_matricula,
                           a.cd_usuario_eventual,
                           a.cd_matricula,
                           a.cd_usuario_eventual,
                           au.nm_autorizador,
                           o.ds_origem_atendimento,
                           a.cd_atend_call_center,
                           a.cd_servico_call_center,
                           sc.ds_servico_call_center,
                           S.CD_SLA_CALL_CENTER,
                           S.TP_SLA_CALL_CENTER,
                           s.nr_quantidade,
                           mo.ds_mot_atend_call_center,
                           a.cd_mot_atend_call_center,
                           a.dt_inicio,
                           a.dt_termino,
                           a.cd_tip_atend_call_center,
                           a.dt_inicio
                
                )
         group by nome_usu,
                  cartao,
                  atendente,
                  origem,
                  evento,
                  ocorrencia,
                  setor,
                  previsao,
                  qtd,
                  legenda_motivo,
                  dt_inicio --, funci
        
        UNION -- DIVISÃO GRUP BY
        
        select nome_usu,
               cartao,
               atendente,
               origem,
               evento,
               ocorrencia,
               setor,
               previsao,
               qtd,
               Listagg(funci, ' ,') Within Group(Order By funci) medico,
               --Listagg(legenda_motivo, ' ,') Within Group(Order By legenda_motivo) motivov
               legenda_motivo,
               dt_inicio
          from (select decode(a.cd_usuario_eventual,
                              null,
                              (select c.nm_segurado
                                 from dbaps.usuario c
                                where c.cd_matricula = a.cd_matricula),
                              (select ue.nm_usuario_eventual
                                 from usuario_eventual ue
                                where ue.cd_usuario_eventual =
                                      a.cd_usuario_eventual)) nome_usu,
                       decode(a.cd_usuario_eventual,
                              null,
                              (select c.cd_mat_alternativa
                                 from dbaps.usuario c
                                where c.cd_matricula = a.cd_matricula),
                              (select ue.nr_carteira_beneficiario
                                 from usuario_eventual ue
                                where ue.cd_usuario_eventual =
                                      a.cd_usuario_eventual)) cartao,
                       au.nm_autorizador atendente, --Atendente
                       o.ds_origem_atendimento Origem,
                       NVL((select g.ds_tip_atend_call_center
                             from dbaps.tip_atend_call_center g
                            where g.cd_tip_atend_call_center =
                                  TP.CD_TIP_ATEND_CALL_CENTER),
                           (select g.ds_tip_atend_call_center
                              from dbaps.tip_atend_call_center g
                             where g.cd_tip_atend_call_center =
                                   A.CD_TIP_ATEND_CALL_CENTER)) Evento,
                       a.cd_atend_call_center OCORRENCIA,
                       
                       decode(tp.cd_servico_call_center,
                              null,
                              (select scc.ds_servico_call_center
                                 from dbaps.servico_call_center scc
                                where scc.cd_servico_call_center =
                                      a.cd_servico_call_center),
                              sc.ds_servico_call_center) SETOR,
                       
                       /*Listagg(*/
                       decode(tp.cd_mot_atend_call_center,
                              null,
                              (select x.ds_mot_atend_call_center
                                 from dbaps.mot_atend_call_center x
                                where x.cd_mot_atend_call_center =
                                      a.cd_mot_atend_call_center),
                              mo.ds_mot_atend_call_center)
                       
                       LEGENDA_MOTIVO,
                       
                       CASE
                         WHEN DECODE(S.CD_SLA_CALL_CENTER,
                                     NULL,
                                     NULL,
                                     DECODE(S.TP_SLA_CALL_CENTER,
                                            'D',
                                            /* TO_CHAR(*/
                                            DBAPS.FNC_PROXIMO_DIA_UTIL(TRUNC(a.dt_inicio),
                                                                       NVL(s.nr_quantidade,
                                                                           0),
                                                                       'D'),
                                            /*'DD/MM/YYYY HH24:MI:SS')/,*
                                            'H',
                                            /*TO_CHAR(*/
                                            DBAPS.FNC_PROXIMO_DIA_UTIL(TRUNC(a.dt_inicio),
                                                                       NVL(s.nr_quantidade,
                                                                           0),
                                                                       'H'),
                                            /*'DD/MM/YYYY HH24:MI:SS'),*/
                                            'M',
                                            /* TO_CHAR(*/
                                            DBAPS.FNC_PROXIMO_DIA_UTIL(TRUNC(a.dt_inicio),
                                                                       NVL(s.nr_quantidade,
                                                                           0),
                                                                       'M'),
                                            /*  'DD/MM/YYYY HH24:MI:SS'),*/
                                            'S',
                                            /*TO_CHAR(*/
                                            DBAPS.FNC_PROXIMO_DIA_UTIL(TRUNC(a.dt_inicio),
                                                                       NVL(s.nr_quantidade,
                                                                           0),
                                                                       'S') --,
                                            /*'DD/MM/YYYY HH24:MI:SS')*/)) <
                              to_date(trunc(a.dt_termino), 'DD/MM/YYYY') THEN
                          'SIM'
                         WHEN a.dt_termino IS NULL THEN
                          'Não Finalizada'
                         ELSE
                          'NÃO'
                       END PREVISAO,
                       1 qtd,
                       Listagg(null, ' ,') Within Group(Order By null) funci,
                       a.dt_inicio
                  from dbaps.atend_call_center             a,
                       dbaps.origem_atendimento            o,
                       dbaps.tramite_protocolo_call_center tp,
                       dbaps.sla_call_center               s,
                       dbaps.servico_call_center           sc,
                       dbaps.mot_atend_call_center         mo,
                       dbaps.autorizador                   au
                 where a.cd_origem_atendimento = o.cd_origem_atendimento
                   and a.cd_autorizador = au.cd_autorizador
                   and tp.cd_atend_call_center = a.cd_atend_call_center
                   and a.cd_prestador is null
                   and tp.cd_servico_call_center =
                       sc.cd_servico_call_center(+)
                   and tp.cd_autorizador_tramite <> '139'
                   and a.cd_depto_operadora <> '93'
                   and mo.cd_mot_atend_call_center(+) =
                       tp.cd_mot_atend_call_center
                   and a.cd_sla_call_center = s.cd_sla_call_center
                   and a.cd_atend_call_center not in
                       (select mm.cd_atend_call_center
                          from dbaps.call_center_mensagem mm
                         where mm.cd_atend_call_center =
                               a.cd_atend_call_center
                           and mm.cd_call_center_evento = '3')
                   and trunc(a.dt_inicio) between #inicio# and #fim#
                   and a.cd_tip_atend_call_center <> 10
                 group by a.cd_usuario_eventual,
                          a.cd_matricula,
                          a.cd_usuario_eventual,
                          a.cd_matricula,
                          a.cd_usuario_eventual,
                          au.nm_autorizador,
                          o.ds_origem_atendimento,
                          a.cd_atend_call_center,
                          tp.cd_servico_call_center,
                          a.cd_servico_call_center,
                          sc.ds_servico_call_center,
                          S.CD_SLA_CALL_CENTER,
                          TP.DT_INICIO_TRAMITE,
                          S.TP_SLA_CALL_CENTER,
                          s.nr_quantidade,
                          tp.dt_final_tramite,
                          mo.ds_mot_atend_call_center,
                          1,
                          tp.cd_mot_atend_call_center,
                          a.cd_mot_atend_call_center,
                          a.dt_inicio,
                          a.dt_termino,
                          a.cd_tip_atend_call_center,
                          TP.CD_TIP_ATEND_CALL_CENTER,
                          a.dt_inicio
                
                )
         group by nome_usu,
                  cartao,
                  atendente,
                  origem,
                  evento,
                  ocorrencia,
                  setor,
                  previsao,
                  qtd,
                  legenda_motivo,
                  dt_inicio)

 where

 (('TODOS') in (#tipo_evento#) OR evento in (#tipo_evento#))

 AND (('TODOS') in (#setor_servico#) OR setor in (#setor_servico#))

 AND (('TODOS') in (#motivo#) OR legenda_motivo in (#motivo#))

 AND (('TODOS') in (#origem#) OR origem in (#origem#))

 GROUP BY nome_usu,
          cartao,
          atendente,
          origem,
          evento,
          ocorrencia,
          setor,
          previsao,
          qtd,
          legenda_motivo,
          dt_inicio