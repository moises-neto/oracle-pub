Select y.mes,       
       x.Setor,
       x.Nivel,
       x.Quantidade,
       round((x.Quantidade / y.Total) * 100, 2) As Percentual,
       y.Total
  from 
     --Quantidade
  (Select b.mes, b.setor, Sum(b.Quantidade) Quantidade, b.nivel
          from (Select usujk.SETOR As Setor,
                       count(distinct g.nr_transacao) As Quantidade,
                       p.nr_nivel_autorizacao as Nivel,
                       TO_CHAR(g.dt_emissao, 'MM/YYYY') as mes
                  From Dbaps.guia                g,
                       Dbaps.autorizador         a,
                       Dbaps.v_Usuarios_Setor_Jk usujk,
                       Dbaps.procedimento        p,
                       Dbaps.itguia              it
                --Incio Joins
                 Where g.cd_usuario_emissao = a.cd_usuario
                   And usujk.Usuario = g.cd_usuario_emissao
                   And it.nr_guia = g.nr_guia
                   And p.cd_procedimento = it.cd_procedimento
                      --Fim Joins
                      --Inicio Filtro
                  And trunc(g.dt_emissao) Between #DATAINICIAL# And #DATAFINAL#
           And p.nr_nivel_autorizacao in (#NIVEL#)
                   And g.sn_valida_rest_carencia = 'S'
                --Fim Filtro
                
                 Group By usujk.SETOR, p.nr_nivel_autorizacao, g.dt_emissao) b
        
         Group by b.mes, b.nivel, b.setor
         order by 2) x, 
         
         -- total
       (Select a.mes, sum(a.Total) as Total
          from (Select count(distinct g.nr_transacao) As Total,
                       p.nr_nivel_autorizacao as Nivel,
                       TO_CHAR(g.dt_emissao, 'MM/YYYY') As Mes,
                       g.nr_transacao
                  From Dbaps.guia                g,
                       Dbaps.autorizador         a,
                       Dbaps.v_Usuarios_Setor_Jk usujk,
                       Dbaps.procedimento        p,
                       Dbaps.itguia              it
                --Incio Joins
                 Where g.cd_usuario_emissao = a.cd_usuario
                   And usujk.Usuario = g.cd_usuario_emissao
                   And it.nr_guia = g.nr_guia
                   And p.cd_procedimento = it.cd_procedimento
                      --Fim Joins
                      --Inicio Filtro
                  And trunc(g.dt_emissao) Between #DATAINICIAL# And #DATAFINAL#
           And p.nr_nivel_autorizacao in (#NIVEL#)
                   And g.sn_valida_rest_carencia = 'S'
                --Fim Filtro
                
                 Group By g.dt_emissao,  p.nr_nivel_autorizacao, g.nr_transacao--, g.nr_transacao, p.nr_nivel_autorizacao
                 ) a
         Group by a.mes) y
   Where y.mes = x.mes
 Group by x.Setor, y.Total, x.Quantidade, x.Nivel, y.mes

 order by 1,2,3
