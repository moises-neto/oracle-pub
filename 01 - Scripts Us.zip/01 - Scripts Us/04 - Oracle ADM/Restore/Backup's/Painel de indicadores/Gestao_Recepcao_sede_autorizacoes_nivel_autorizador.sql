Select g.nr_guia As Guia,
       g.dt_emissao As Data_Atendimento,
       initcap(g.nm_profissional_solicitante) AS Medico_Solicitante,
       listagg(it.cd_procedimento || ' - ' || Initcap(p.ds_procedimento), '; ')within group(order by it.cd_procedimento)  AS Procedimento,
       p.nr_nivel_autorizacao As Nivel_Autorizacao,
      initcap(nvl(pres.nm_prestador,(select distinct pr.nm_prestador
  from dbaps.v_ctas_medicas cm, dbaps.prestador pr
 where pr.cd_prestador = cm.cd_prestador_pagamento
   and cm.nr_guia = g.nr_guia --guias
   and cm.tp_pagamento = 'HM'
   and cm.tp_fatura = 'P'
   and cm.tp_origem = '2'
   and cm.tp_situacao_conta IN ('AA', 'AT')
   and cm.tp_situacao_itconta IN ('AA', 'AT')
   and cm.tp_situacao_equipe = 'AA'
   and cm.tp_pagcob not in ('NN', 'CN') and rownum = 1))) As Prestador_Executante,
       initcap(nvl(u.nm_segurado, bt.nm_segurado)) as Nome_Cliente,
       initcap(plano.ds_plano) As Plano,
       nvl(g.nr_carteira_utilizada,nr_carteira_beneficiario ) AS Carteira,
       initcap(a.nm_autorizador) As Nome_Colaborador,
       initcap(us.ds_observacao) As Setor   
              
From Dbaps.guia g, Dbaps.autorizador a, Dbaps.Beneficiario_Transito bt, Dbaps.Usuario u, Dbaps.Itguia it, Dbaps.procedimento p, Dbaps.prestador pres, Dbasgu.usuarios us, Dbaps.Plano plano
--Incio Joins
Where g.cd_autorizador = a.cd_autorizador

And g.nr_guia = it.nr_guia
And p.cd_procedimento = it.cd_procedimento
And us.cd_usuario = a.cd_usuario
And pres.cd_prestador(+) = g.cd_prestador_executor
And g.cd_matricula = u.cd_matricula(+)
And u.cd_plano = plano.cd_plano
And g.nr_carteira_beneficiario = bt.cd_matricula(+)
--Fim Joins

--Inicio Filtro
And trunc(g.dt_emissao) Between #DATAINICIO# And #DATAFIM#
And p.nr_nivel_autorizacao in (#NIVEL#)
And initcap(us.nm_usuario) in (#COLABORADOR#)
And Dbaps.Fnc_Status_Guia(g.nr_guia) =  'Autorizado [2]'
And a.tp_autorizador = 'F'
--And us.ds_observacao not like '%MEDICO%'
--Fim Filtro

Group By
       g.nr_guia,
       g.dt_emissao,
       g.nm_profissional_solicitante,
      p.nr_nivel_autorizacao,
       g.Nm_Prestador_Executor_Pf,
       nvl(u.nm_segurado, bt.nm_segurado),
       g.nr_carteira_utilizada,
       a.nm_autorizador,
       g.nm_prest_exec_eventual,
       nr_carteira_beneficiario,
       pres.nm_prestador,
       plano.ds_plano,
      us.ds_observacao

Union --filtro por setor

Select g.nr_guia As Guia,
       g.dt_emissao As Data_Atendimento,
       initcap(g.nm_profissional_solicitante) AS Medico_Solicitante,
       listagg(it.cd_procedimento || ' - ' || Initcap(p.ds_procedimento), '; ')within group(order by it.cd_procedimento)  AS Procedimento,
       p.nr_nivel_autorizacao As Nivel_Autorizacao,
       initcap(nvl(pres.nm_prestador,(select distinct pr.nm_prestador
  from dbaps.v_ctas_medicas cm, dbaps.prestador pr
 where pr.cd_prestador = cm.cd_prestador_pagamento
   and cm.nr_guia = g.nr_guia --guias
   and cm.tp_pagamento = 'HM'
   and cm.tp_fatura = 'P'
   and cm.tp_origem = '2'
   and cm.tp_situacao_conta IN ('AA', 'AT')
   and cm.tp_situacao_itconta IN ('AA', 'AT')
   and cm.tp_situacao_equipe = 'AA'
   and cm.tp_pagcob not in ('NN', 'CN') and rownum = 1))) As Prestador_Executante,
       initcap(nvl(u.nm_segurado, bt.nm_segurado)) as Nome_Cliente,
       initcap(plano.ds_plano) As Plano,
       nvl(g.nr_carteira_utilizada,nr_carteira_beneficiario ) AS Carteira,
       initcap(a.nm_autorizador) As Nome_Colaborador,
       initcap(us.ds_observacao) As Setor
              
From Dbaps.guia g, Dbaps.autorizador a, Dbaps.Beneficiario_Transito bt, Dbaps.Usuario u, Dbaps.Itguia it, Dbaps.procedimento p, Dbaps.prestador pres, Dbasgu.usuarios us, Dbaps.Plano plano
--Incio Joins
Where g.cd_autorizador = a.cd_autorizador

And g.nr_guia = it.nr_guia
And p.cd_procedimento = it.cd_procedimento
And us.cd_usuario = a.cd_usuario
And pres.cd_prestador(+) = g.cd_prestador_executor
And g.cd_matricula = u.cd_matricula(+)
And u.cd_plano = plano.cd_plano
And g.nr_carteira_beneficiario = bt.cd_matricula(+)
--Fim Joins

--Inicio Filtro
And trunc(g.dt_emissao) Between #DATAINICIO# And #DATAFIM#
And p.nr_nivel_autorizacao in (#NIVEL#)
And INITCAP(us.nm_usuario) in 
   (Select x.Colaboradores
  from (Select Distinct 'POSTOS' as JK,
                        INITCAP(u.Nm_Usuario) Colaboradores
          from dbasgu.usuarios u
         where u.ds_observacao like '%POSTOS%'
           AND U.SN_ATIVO = 'S'
        Union
        --NAIS
        Select Distinct 'NAIS' as JK,
                        INITCAP(uS.Nm_Usuario) Colaboradores
          from dbasgu.usuarios us
         where us.cd_usuario in
               ('JGUERRERO', 'LUCCOSTA', 'VGOMES', 'GANASCIMENTO')
           AND Us.SN_ATIVO = 'S'
        Union
        --JK
        Select Distinct 'JK' as JK,
                        INITCAP(uSu.Nm_Usuario) Colaboradores
          FROM dbasgu.usuarios usu, dbasgu.papel_usuarios pu
         where pu.cd_usuario = usu.cd_usuario
           And usu.ds_observacao not like '%NAIS%'
           And usu.ds_observacao not like '%POSTOS%'
           And pu.cd_papel in (151, 153)
           And usu.sn_ativo = 'S') x

 Where x.JK in (#SETOR#))
And Dbaps.Fnc_Status_Guia(g.nr_guia) =  'Autorizado [2]'
And a.tp_autorizador = 'F'
--And us.ds_observacao not like '%MEDICO%'
--Fim Filtro

Group By
       g.nr_guia,
       g.dt_emissao,
       g.nm_profissional_solicitante,
      p.nr_nivel_autorizacao,
       g.Nm_Prestador_Executor_Pf,
       nvl(u.nm_segurado, bt.nm_segurado),
       g.nr_carteira_utilizada,
       a.nm_autorizador,
       g.nm_prest_exec_eventual,
       nr_carteira_beneficiario,
       pres.nm_prestador,
       plano.ds_plano,
       us.ds_observacao