create or replace view vw_contrato_usuario_ae as
Select Distinct
/*********************************************************************************************************************
Data             : 17/10/2017
Objetivo         : Retorna dados de usu�rios e contratos Ativos - Para Acesso Empresa
Altera��es
+--------------------------------------------------------------------------------------------------------------------+
| DATA       | RESPONSAVEL   | VERSAO  | ALTERACAO
|--------------------------------------------------------------------------------------------------------------------|
| 17/10/2017 | Renata Miranda| 0.0     | Cria��o da VW
---------------------------------------------------------------------------------------------------------------------|
| 07/11/2017 | Renata Miranda| 0.1     | Altera��o da busca de repasse devido duplicaidade
---------------------------------------------------------------------------------------------------------------------|
| 16/04/2018 | Renata Miranda| 1.0     | Pegar Usu�rios Repassados (sem carteira). Referente Chamado 106077
---------------------------------------------------------------------------------------------------------------------|
| 17/07/2018 | Renata Miranda| 1.1     | Pegar todos os repasses ativos do benefici�rio. Referente Chamado 116073
---------------------------------------------------------------------------------------------------------------------|
| 22/08/2018 | Larissa Tobias| 1.2     | Verificar o �ltimo repasse inclu�do. Referente Chamado 120248
---------------------------------------------------------------------------------------------------------------------|
| 06/03/2019 | Larissa Tobias| 1.3     | Francini e Mojarri pediram para trazer a data de validade da carteira
                                         de benefici�rios repassados. Referente Chamado 140903
---------------------------------------------------------------------------------------------------------------------|
| 23/04/2019 | Larissa Tobias| 1.4     | Thiago de Brito - TI Web, baseado no chamado 146358, solicitou a inclus�o de
                                         benefici�rios com data de desligamento programada.
---------------------------------------------------------------------------------------------------------------------|
| 29/10/2019 | Larissa Tobias| 1.5     | Pedro Almeida - TI Web, benefici�ria 1113820095 n�o estava aparecendo devido
                                        a repasse cancelado, inclui um novo bloco no Union, considerando quem s� tem
                                        registro de repasse cancelado
---------------------------------------------------------------------------------------------------------------------|
| 06/01/2020 | Larissa Tobias| 1.6     | CH2001-0049 - Laura - Cadastro - Por gentileza, incluir a restri��o para n�o
                                         constar benefici�rios inativos ao relat�rio.
---------------------------------------------------------------------------------------------------------------------|
| 03/02/2020 | Larissa Tobias| 1.7     |  CH2002-0661 - Mojarri - Cadastro - Verificado que estava duplicando os
                                         benefici�rios em foram inclu�dos os registros de hist�rico de repasse.
                                         Ex.: Unimed Paulistana e ABC
---------------------------------------------------------------------------------------------------------------------|
***********************************************************************************************************************/

                substr(Co.Cd_Contrato_Interno,1,4) Nrcontrato,
                Ut.Cd_Familia Familia,
                Co.Nm_Responsavel_Financeiro Pessoa_Contrato,
                Case
                  When Ut.Tp_Usuario = 'T' Then
                   Regexp_Replace(Lpad(Ut.Cd_Mat_Alternativa, 16, '0'),
                                  '([0-9]{3})([0-9]{4})([0-9]{6})([0-9]{2})([0-9]{1})',
                                  '\1.\2.\3.\4-\5')
                  Else
                   (Select Regexp_Replace(Lpad(u.Cd_Mat_Alternativa, 16, '0'),
                                          '([0-9]{3})([0-9]{4})([0-9]{6})([0-9]{2})([0-9]{1})',
                                          '\1.\2.\3.\4-\5')
                      From Dbaps.Usuario u
                     Where u.Cd_Matricula = Ut.Cd_Matricula_Tem
                       And u.Tp_Usuario = 'T')
                End Cdusuario_Tit,
                Case
                  When Ut.Tp_Usuario = 'T' Then
                   Ut.Nm_Segurado
                  Else
                   (Select Nvl(u.Nm_Segurado, Ut.Nm_Segurado)
                      From Dbaps.Usuario u
                     Where u.Cd_Matricula = Ut.Cd_Matricula_Tem
                       And u.Tp_Usuario = 'T')
                End Pessoa_Tit,
                Regexp_Replace(Lpad(Ut.Cd_Mat_Alternativa, 16, '0'),
                               '([0-9]{3})([0-9]{4})([0-9]{6})([0-9]{2})([0-9]{1})',
                               '\1.\2.\3.\4-\5') Cdusuario_Dependente,
                Ut.Nm_Segurado Pessoa_Dependente,
                Ut.Dt_Cadastro Dtiniciocontrato,
                Ut.Dt_Nascimento,
                Pn.Ds_Plano,
                Pn.Cd_Plano_Interno,
                Decode(Pn.Cd_Tip_Acomodacao, '7', 'B', '1', 'A') Tp_Acomodacao,
                Ut.Sn_Titular,
                Ut.Cd_Matricula Cdmatricula_Usu,
                Ut.Nr_Rg Rg_Usu,
                Ut.Nr_Cpf Cpf_Usu,
                Ut.Nr_Cns,
                Ut.Tp_Usuario,
                Case
                  When Ut.Tp_Usuario = 'T' Then
                   '00'
                  Else
                   Substr(Ut.Cd_Mat_Alternativa, 14, 2)
                End Cd_Graudependencia,
                Case
                  When Ut.Tp_Usuario = 'T' Then
                   'TITULAR'
                  Else
                   (Select Ga.Ds_Parentesco
                      From Dbaps.Grau_Parentesco Ga
                     Where Ga.Cd_Parentesco = Ut.Cd_Parentesco)
                End Ds_Graudependencia,
                (Select Replace(Replace(Substr(Em.Ds_Empresa,
                                               Instr(Em.Ds_Empresa, '(') - 0,
                                               10),
                                        '(',
                                        ''),
                                ')')
                   From Dbaps.Empresa Em
                  Where Em.Cd_Empresa = Ut.Cd_Empresa
                    And Instr(Em.Ds_Empresa, '(') > 1
                    And Em.Cd_Empresa_Tem Is Not Null) Ds_Lotacao,
                Null Dt_Repasse,
                Null Repasse,
                Nvl(Floor(Months_Between(Sysdate, Ut.Dt_Nascimento) / 12),
                    0) Idade,
                Ct.Dt_Validade Dt_Validade_Carteira,
                Nvl(Ut.Cd_Do_Rh, Ut.Cd_Na_Empresa) Cd_Matricula_Rh,
                Ut.Cd_Na_Empresa Cd_Matricula_Empresa,
                Ut.Cd_Matricula,

                -- CH2001-0049
                Ut.Sn_Ativo,

                Ut.Nr_Idade_Fixada,
                Co.Sn_Demitido_Aposentado_Obito
  From Dbaps.Usuario  Ut,
       Dbaps.Contrato Co,
       Dbaps.Plano    Pn,
       Dbaps.Carteira Ct
 Where Ut.Cd_Contrato = Co.Cd_Contrato
   And Pn.Cd_Plano = Ut.Cd_Plano
   And Ut.Cd_Matricula = Ct.Cd_Matricula
/*   And Ut.Cd_Matricula Not In
       (Select De.Cd_Matricula
          From Dbaps.Desligamento De
         Where De.Cd_Matricula = Ut.Cd_Matricula
           And De.Dt_Reativacao Is Null)*/
   And Ct.Dt_Validade =
       (Select Max(Car.Dt_Validade)
          From Dbaps.Carteira Car
         Where Car.Cd_Matricula = Ct.Cd_Matricula)

   --Alterado por Larissa Tobias: Thiago de Brito - TI Web, baseado no chamado 146358, solicitou a inclus�o de benefici�rios com data de desligamento programada.
   And (Ut.Dt_Desligamento_Programada Is Null
   or trunc(Ut.Dt_Desligamento_Programada) >= trunc(sysdate))

   And Ut.Cd_Familia <> 0

   -- Alterado por Larissa Tobias: Chamado 120248 - Objetivo: verificar o �ltimo repasse inclu�do

   /*And Ut.Cd_Matricula Not In
       (Select Iu.Cd_Matricula
          From Dbaps.Repasse_Intercambio_Usuario Iu
         Where Iu.Cd_Matricula = Ut.Cd_Matricula)*/
  -- And Ut.Cd_Matricula = 264570081

   And Not exists
       (Select 1
          From Dbaps.Repasse_Intercambio_Usuario Iu
          inner join dbaps.repasse_intercambio ri
          on (Iu.Cd_Repasse_Intercambio = ri.cd_repasse_intercambio)
         Where Iu.Cd_Matricula = Ut.Cd_Matricula
         And Iu.Dt_Cancelamento is null
         and trunc(Iu.Dt_Repasse) = (select max(trunc(ruu.dt_repasse)) from Dbaps.Repasse_Intercambio_Usuario Ruu
         inner join dbaps.repasse_intercambio rii
          on (ruu.Cd_Repasse_Intercambio = rii.cd_repasse_intercambio)
   where Ruu.Cd_Matricula = Ut.Cd_Matricula
   and ri.cd_unimed_destino = rii.cd_unimed_destino
   ) )

Union

Select Distinct substr(Co.Cd_Contrato_Interno,1,4) Nrcontrato,
                Ut.Cd_Familia Familia,
                Co.Nm_Responsavel_Financeiro Pessoa_Contrato,
                Case
                  When Ut.Tp_Usuario = 'T' Then
                   Regexp_Replace(Lpad(Ut.Cd_Mat_Alternativa, 16, '0'),
                                  '([0-9]{3})([0-9]{4})([0-9]{6})([0-9]{2})([0-9]{1})',
                                  '\1.\2.\3.\4-\5')
                  Else
                   (Select Regexp_Replace(Lpad(u.Cd_Mat_Alternativa, 16, '0'),
                                          '([0-9]{3})([0-9]{4})([0-9]{6})([0-9]{2})([0-9]{1})',
                                          '\1.\2.\3.\4-\5')
                      From Dbaps.Usuario u
                     Where u.Cd_Matricula = Ut.Cd_Matricula_Tem
                       And u.Tp_Usuario = 'T')
                End Cdusuario_Tit,
                Case
                  When Ut.Tp_Usuario = 'T' Then
                   Ut.Nm_Segurado
                  Else
                   (Select Nvl(u.Nm_Segurado, Ut.Nm_Segurado)
                      From Dbaps.Usuario u
                     Where u.Cd_Matricula = Ut.Cd_Matricula_Tem
                       And u.Tp_Usuario = 'T')
                End Pessoa_Tit,
                Regexp_Replace(Lpad(Ut.Cd_Mat_Alternativa, 16, '0'),
                               '([0-9]{3})([0-9]{4})([0-9]{6})([0-9]{2})([0-9]{1})',
                               '\1.\2.\3.\4-\5') Cdusuario_Dependente,
                Ut.Nm_Segurado Pessoa_Dependente,
                Ut.Dt_Cadastro Dtiniciocontrato,
                Ut.Dt_Nascimento,
                Pn.Ds_Plano,
                Pn.Cd_Plano_Interno,
                Decode(Pn.Cd_Tip_Acomodacao, '7', 'B', '1', 'A') Tp_Acomodacao,
                Ut.Sn_Titular,
                Ut.Cd_Matricula Cdmatricula_Usu,
                Ut.Nr_Rg Rg_Usu,
                Ut.Nr_Cpf Cpf_Usu,
                Ut.Nr_Cns,
                Ut.Tp_Usuario,
                Case
                  When Ut.Tp_Usuario = 'T' Then
                   '00'
                  Else
                   Substr(Ut.Cd_Mat_Alternativa, 14, 2)
                End Cd_Graudependencia,
                Case
                  When Ut.Tp_Usuario = 'T' Then
                   'TITULAR'
                  Else
                   (Select Ga.Ds_Parentesco
                      From Dbaps.Grau_Parentesco Ga
                     Where Ga.Cd_Parentesco = Ut.Cd_Parentesco)
                End Ds_Graudependencia,
                (Select Replace(Replace(Substr(Em.Ds_Empresa,
                                               Instr(Em.Ds_Empresa, '(') - 0,
                                               10),
                                        '(',
                                        ''),
                                ')')
                   From Dbaps.Empresa Em
                  Where Em.Cd_Empresa = Ut.Cd_Empresa
                    And Instr(Em.Ds_Empresa, '(') > 1
                    And Em.Cd_Empresa_Tem Is Not Null) Ds_Lotacao,
                Ru.Dt_Repasse Dt_Repasse,
                Ri.Cd_Unimed_Destino || '-' || Un.Ds_Unimed Repasse,
                Nvl(Floor(Months_Between(Sysdate, Ut.Dt_Nascimento) / 12),
                    0) Idade,


               /*Chamado 140903
               Francini e Mojarri pediram para trazer a data de validade da carteira de benefici�rios repassados.*/

                --To_Date(Null) Dt_Validade_Carteira,
                (select ct.dt_validade
                   from dbaps.carteira ct
                  where ct.cd_matricula = ut.cd_matricula
                    and ct.dt_cancelamento is null
                    and ct.nr_via =
                    (select max(cr.nr_via) From Dbaps.Carteira Cr
                          Where Cr.Cd_Matricula = Ct.Cd_Matricula
                            and cr.dt_cancelamento is null
                    and cr.dt_validade =
                        (Select Max(Car.Dt_Validade)
                           From Dbaps.Carteira Car
                          Where Car.Cd_Matricula = Cr.Cd_Matricula
                            and car.dt_cancelamento is null))) Dt_Validade_Carteira,

                Nvl(Ut.Cd_Do_Rh, Ut.Cd_Na_Empresa) Cd_Matricula_Rh,
                Ut.Cd_Na_Empresa Cd_Matricula_Empresa,
                Ut.Cd_Matricula,

                -- CH2001-0049
                Ut.Sn_Ativo,

                Ut.Nr_Idade_Fixada,
                Co.Sn_Demitido_Aposentado_Obito
  From Dbaps.Usuario                     Ut,
       Dbaps.Contrato                    Co,
       Dbaps.Plano                       Pn,
       Dbaps.Repasse_Intercambio_Usuario Ru,
       Dbaps.Repasse_Intercambio         Ri,
       Dbaps.Unimed                      Un
 Where Ut.Cd_Contrato = Co.Cd_Contrato
   And Pn.Cd_Plano = Ut.Cd_Plano
   And Ut.Cd_Matricula = Ru.Cd_Matricula
   And Ri.Cd_Repasse_Intercambio = Ru.Cd_Repasse_Intercambio
   And Ri.Cd_Unimed_Destino = Un.Cd_Unimed
   And Ut.Cd_Matricula Not In
       (Select De.Cd_Matricula
          From Dbaps.Desligamento De
         Where De.Cd_Matricula = Ut.Cd_Matricula
           And De.Dt_Reativacao Is Null)


   --Alterado por Larissa Tobias: Thiago de Brito - TI Web, baseado no chamado 146358, solicitou a inclus�o de benefici�rios com data de desligamento programada.
   And (Ut.Dt_Desligamento_Programada Is Null
   or trunc(Ut.Dt_Desligamento_Programada) >= trunc(sysdate))

   And Ru.Dt_Cancelamento Is Null
   And Ut.Cd_Familia <> 0

   -- Inclu�do por Larissa Tobias: Chamado 120248 - Objetivo: pegar o �ltimo repasse inclu�do
    /*And Ru.Dt_Repasse = (select max(ruu.dt_repasse) from Dbaps.Repasse_Intercambio_Usuario Ruu
   inner join Dbaps.Repasse_Intercambio         Rii
   on (Ruu.Cd_Repasse_Intercambio = Rii.Cd_Repasse_Intercambio)
   where Ruu.Cd_Matricula = Ut.Cd_Matricula
   and Rii.Cd_Unimed_Destino = Ri.Cd_Unimed_Destino
   )*/

      And ru.cd_repasse_intercambio_usuario =
       ((select max(ruu.cd_repasse_intercambio_usuario)
           from Dbaps.Repasse_Intercambio_Usuario Ruu
          where Ruu.Cd_Matricula = Ut.Cd_Matricula
            and ruu.dt_repasse =
                (select max(riu2.dt_repasse)
                   from Dbaps.Repasse_Intercambio_Usuario Riu2
                  where riu2.cd_matricula = ruu.cd_matricula)))

   -- verificar linha de cancelamento do repasse
   and not exists
   (select 1 from dbaps.repasse_intercambio_usuario riuu
   where riuu.cd_matricula = ru.cd_matricula
   and riuu.cd_repasse_intercambio = ru.cd_repasse_intercambio
   and riuu.dt_cancelamento is not null
   and riuu.cd_repasse_intercambio_usuario > ru.cd_repasse_intercambio_usuario
  )


Union

--- BENEFICI�RIOS COM REPASSE CANCELADO


select distinct Co.Cd_Contrato_Interno Nrcontrato,
       Ut.Cd_Familia Familia,
       Co.Nm_Responsavel_Financeiro Pessoa_Contrato,
       Case
         When Ut.Tp_Usuario = 'T' Then
          Regexp_Replace(Lpad(Ut.Cd_Mat_Alternativa, 16, '0'),
                         '([0-9]{3})([0-9]{4})([0-9]{6})([0-9]{2})([0-9]{1})',
                         '\1.\2.\3.\4-\5')
         Else
          (Select Regexp_Replace(Lpad(u.Cd_Mat_Alternativa, 16, '0'),
                                 '([0-9]{3})([0-9]{4})([0-9]{6})([0-9]{2})([0-9]{1})',
                                 '\1.\2.\3.\4-\5')
             From Dbaps.Usuario u
            Where u.Cd_Matricula = Ut.Cd_Matricula_Tem
              And u.Tp_Usuario = 'T')
       End Cdusuario_Tit,
       Case
         When Ut.Tp_Usuario = 'T' Then
          Ut.Nm_Segurado
         Else
          (Select Nvl(u.Nm_Segurado, Ut.Nm_Segurado)
             From Dbaps.Usuario u
            Where u.Cd_Matricula = Ut.Cd_Matricula_Tem
              And u.Tp_Usuario = 'T')
       End Pessoa_Tit,
       Regexp_Replace(Lpad(Ut.Cd_Mat_Alternativa, 16, '0'),
                      '([0-9]{3})([0-9]{4})([0-9]{6})([0-9]{2})([0-9]{1})',
                      '\1.\2.\3.\4-\5') Cdusuario_Dependente,
       Ut.Nm_Segurado Pessoa_Dependente,
       Ut.Dt_Cadastro Dtiniciocontrato,
       Ut.Dt_Nascimento,
       Pn.Ds_Plano,
       Pn.Cd_Plano_Interno,
       Decode(Pn.Cd_Tip_Acomodacao, '7', 'B', '1', 'A') Tp_Acomodacao,
       Ut.Sn_Titular,
       Ut.Cd_Matricula Cdmatricula_Usu,
       Ut.Nr_Rg Rg_Usu,
       Ut.Nr_Cpf Cpf_Usu,
       Ut.Nr_Cns,
       Ut.Tp_Usuario,
       Case
         When Ut.Tp_Usuario = 'T' Then
          '00'
         Else
          Substr(Ut.Cd_Mat_Alternativa, 14, 2)
       End Cd_Graudependencia,
       Case
         When Ut.Tp_Usuario = 'T' Then
          'TITULAR'
         Else
          (Select Ga.Ds_Parentesco
             From Dbaps.Grau_Parentesco Ga
            Where Ga.Cd_Parentesco = Ut.Cd_Parentesco)
       End Ds_Graudependencia,
       (Select Replace(Replace(Substr(Em.Ds_Empresa,
                                      Instr(Em.Ds_Empresa, '(') - 0,
                                      10),
                               '(',
                               ''),
                       ')')
          From Dbaps.Empresa Em
         Where Em.Cd_Empresa = Ut.Cd_Empresa
           And Instr(Em.Ds_Empresa, '(') > 1
           And Em.Cd_Empresa_Tem Is Not Null) Ds_Lotacao,
       Null Dt_Repasse,
       Null Repasse,
       Nvl(Floor(Months_Between(Sysdate, Ut.Dt_Nascimento) / 12), 0) Idade,
       Ct.Dt_Validade Dt_Validade_Carteira,
       Nvl(Ut.Cd_Do_Rh, Ut.Cd_Na_Empresa) Cd_Matricula_Rh,
       Ut.Cd_Na_Empresa Cd_Matricula_Empresa,
       Ut.Cd_Matricula,

       -- CH2001-0049
       Ut.Sn_Ativo,

       Ut.Nr_Idade_Fixada,
       Co.Sn_Demitido_Aposentado_Obito
  From Dbaps.Usuario  Ut,
       Dbaps.Contrato Co,
       Dbaps.Plano    Pn,
       Dbaps.Carteira Ct
 Where Ut.Cd_Contrato = Co.Cd_Contrato
   And Pn.Cd_Plano = Ut.Cd_Plano
   And Ut.Cd_Matricula = Ct.Cd_Matricula
   And Ut.Cd_Matricula Not In
       (Select De.Cd_Matricula
          From Dbaps.Desligamento De
         Where De.Cd_Matricula = Ut.Cd_Matricula
           And De.Dt_Reativacao Is Null)
   And Ct.Dt_Validade =
       (Select Max(Car.Dt_Validade)
          From Dbaps.Carteira Car
         Where Car.Cd_Matricula = Ct.Cd_Matricula)

   And (Ut.Dt_Desligamento_Programada Is Null or
       trunc(Ut.Dt_Desligamento_Programada) >= trunc(sysdate))

   And Ut.Cd_Familia <> 0



   And exists
 (Select 1
          From Dbaps.Repasse_Intercambio_Usuario Iu
         /*inner join dbaps.repasse_intercambio ri
            on (Iu.Cd_Repasse_Intercambio = ri.cd_repasse_intercambio)*/
         Where Iu.Cd_Matricula = Ut.Cd_Matricula
           And Iu.Dt_Cancelamento is not null
           and Iu.Cd_Repasse_Intercambio_Usuario =
               (select max(ruu.cd_repasse_intercambio_usuario)
                  from Dbaps.Repasse_Intercambio_Usuario Ruu
                 /*inner join dbaps.repasse_intercambio rii
                    on (ruu.Cd_Repasse_Intercambio =
                       rii.cd_repasse_intercambio)*/
                 where Ruu.Cd_Matricula = Ut.Cd_Matricula
                 and trunc(ruu.dt_repasse) = (select max(trunc(riu2.dt_repasse))
                  from Dbaps.Repasse_Intercambio_Usuario riu2
                  where riu2.cd_matricula = Ut.Cd_Matricula)
                   /*and rii.cd_unimed_destino = ri.cd_unimed_destino*/))
;
