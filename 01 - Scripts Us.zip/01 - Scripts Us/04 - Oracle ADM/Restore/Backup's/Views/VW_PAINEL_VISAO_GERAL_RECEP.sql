CREATE OR REPLACE VIEW DBAPS.VW_PAINEL_VISAO_GERAL_RECEP AS
select "NR_GUIA","NR_TRANSACAO","DT_EMISSAO","CD_MAT_ALTERNATIVA","NM_SEGURADO","STATUS","TIPOAUTORIZACAO","DIAS_UTEIS","DIAS_MAXIMO_RESPOSTA","PRESTADOR","CD_OCORRENCIA","OCORRENCIA","OBSERVACAO","PROCEDIMENTO","AUTORIZADOR","LINHA"
  from (
        /*
        -- Geral sem Ocorr�ncia
        select g.nr_guia,
                g.nr_transacao,
                trunc(g.dt_emissao) dt_emissao,
                u.cd_mat_alternativa,
                u.nm_segurado,
                dbaps.fnc_status_guia(g.nr_guia) Status,
                decode(g.cd_tipo_atendimento,
                       '2',
                       'Exame',
                       '3',
                       'Interna��o',
                       'Consulta') Tipoautorizacao,
                Case
                  when to_char(g.dt_emissao, 'd') = '1' then --S�bado
                   dbaps.fn_dias_uteis_feriado(g.dt_emissao, (sysdate))
                  when to_char(g.dt_emissao, 'd') = '7' then --Domingo
                   dbaps.fn_dias_uteis_feriado(g.dt_emissao, (sysdate))
                  when dbaps.fn_dias_uteis_feriado(g.dt_emissao, g.dt_emissao) = 0 then
                   dbaps.fn_dias_uteis_feriado(g.dt_emissao, (sysdate))
                  else
                   dbaps.fn_dias_uteis_feriado(g.dt_emissao, (sysdate - 1))
                end dias_uteis,

                decode(g.cd_tipo_atendimento,
                       '3',
                       dbaps.fn_adiciona_dias_uteis_feria_t(g.dt_emissao, 2),
                       dbaps.fn_adiciona_dias_uteis_feria_t(g.dt_emissao, 1)) dias_maximo_resposta,

                lpad(g.cd_prestador_executor, 6, 0) || ' - ' ||
                pr.nm_prestador prestador,
                null cd_ocorrencia,
                null ocorrencia,
                'SEM OCORR�NCIA' observacao,
                (select listagg(p.ds_procedimento, ', ') within group(order by p.ds_procedimento) procedimento
                   from dbaps.itguia it, dbaps.procedimento p
                  where it.cd_procedimento = p.cd_procedimento
                    and it.nr_guia = g.nr_guia) procedimento,
                (select a.nm_autorizador
                   from dbaps.autorizador a
                  where a.cd_autorizador = g.cd_autorizador) autorizador,
                1 linha

          from dbaps.guia g, dbaps.usuario u, dbaps.prestador pr
         where g.cd_matricula = u.cd_matricula
           and pr.cd_prestador(+) = g.cd_prestador_executor
           and g.dt_impressao_guia is null
           and (g.cd_mot_cancelamento_guia is null or
               g.cd_mot_cancelamento_guia in ('7', '8')) --exceto canceladas e negadas
           and g.cd_matricula is not null
           and exists
         (select l.nr_guia
                  from dbaps.log_autoriza l, dbasgu.usuarios us
                 where l.nm_usuario_oracle = us.cd_usuario
                   and l.nr_guia = g.nr_guia
                   and l.ds_funcionalidade like '[I] GUIA%CADASTRADA'
                   and substr(us.ds_observacao, 0, 4) in ('2013', '0189'))
           and not exists
         (select 1
                  from dbaps.classificacao_ocorrencia_guia co,
                       dbaps.guia_ocorrencia               goc
                 where goc.nr_guia = g.nr_guia
                   and goc.cd_classificacao_ocor_guia =
                       co.cd_classificacao_ocor_guia
                   and co.tp_class_ocorrencia_guia = 'W')

        union*/

        -- Geral sem Ocorr�ncia e Terapias
        select g.nr_guia,
                g.nr_transacao,
                trunc(g.dt_emissao) dt_emissao,
                u.cd_mat_alternativa,
                u.nm_segurado,
                dbaps.fnc_status_guia(g.nr_guia) Status,
                case
                  when dbaps.fnc_retorna_guia_terapia(g.nr_guia) = 'S' then
                   'Terapia'
                  else
                   decode(g.cd_tipo_atendimento,
                          '2',
                          'Exame',
                          '3',
                          'Interna��o',
                          'Consulta')
                end Tipoautorizacao,
                Case
                  when to_char(g.dt_emissao, 'd') = '1' then --S�bado
                   dbaps.fn_dias_uteis_feriado(g.dt_emissao, (sysdate))
                  when to_char(g.dt_emissao, 'd') = '7' then --Domingo
                   dbaps.fn_dias_uteis_feriado(g.dt_emissao, (sysdate))
                  when dbaps.fn_dias_uteis_feriado(g.dt_emissao, g.dt_emissao) = 0 then
                   dbaps.fn_dias_uteis_feriado(g.dt_emissao, (sysdate))
                  else
                   dbaps.fn_dias_uteis_feriado(g.dt_emissao, (sysdate - 1))
                end dias_uteis,

                decode(g.cd_tipo_atendimento,
                       '3',
                       dbaps.fn_adiciona_dias_uteis_feria_t(g.dt_emissao, 2),
                       dbaps.fn_adiciona_dias_uteis_feria_t(g.dt_emissao, 1)) dias_maximo_resposta,

                lpad(g.cd_prestador_executor, 6, 0) || ' - ' ||
                pr.nm_prestador prestador,
                null cd_ocorrencia,
                null ocorrencia,
                'SEM OCORR�NCIA' observacao,
                (select listagg(p.ds_procedimento, ', ') within group(order by p.ds_procedimento) procedimento
                   from dbaps.itguia it, dbaps.procedimento p
                  where it.cd_procedimento = p.cd_procedimento
                    and it.nr_guia = g.nr_guia) procedimento,
                (select a.nm_autorizador
                   from dbaps.autorizador a
                  where a.cd_autorizador = g.cd_autorizador) autorizador,
                1 linha

          from dbaps.guia g, dbaps.usuario u, dbaps.prestador pr
         where g.cd_matricula = u.cd_matricula
           and pr.cd_prestador(+) = g.cd_prestador_executor
           and g.dt_impressao_guia is null
           and (g.cd_mot_cancelamento_guia is null or
               g.cd_mot_cancelamento_guia in ('7', '8')) --exceto canceladas e negadas
           and g.cd_matricula is not null
           and g.cd_matricula <> '1173830071'
           and exists
         (select l.nr_guia
                  from dbaps.log_autoriza l, dbasgu.usuarios us
                 where l.nm_usuario_oracle = us.cd_usuario
                   and l.nr_guia = g.nr_guia
                   and l.nm_usuario_oracle not in ('GEODOMINGUES', 'KATLIMA')
                   and l.ds_funcionalidade like '[I] GUIA%CADASTRADA'
                   and substr(us.ds_observacao, 1, 3) in ('318','103','112','113','209','205','114','289','291'))
           and not exists (select 1
                  from dbaps.classificacao_ocorrencia_guia co,
                       dbaps.guia_ocorrencia               goc
                 where goc.nr_guia = g.nr_guia
                   and goc.cd_classificacao_ocor_guia =
                       co.cd_classificacao_ocor_guia
                   and (co.tp_class_ocorrencia_guia = 'W'
                   or co.cd_classificacao_ocor_guia = 200))

              -- revalidar
           and not exists
         (select 1
                  from DBAPS.LOG_AUTORIZA l, dbasgu.usuarios u
                 where l.nr_guia = g.nr_guia
                   and l.ds_funcionalidade = 'CANCELAMENTO DA AUTORIZA��O.'
                   and u.cd_usuario = l.nm_usuario_oracle
                   and substr(u.ds_observacao, 1, 3) not in ('318','103','112','113','209','205','114','289','291'))

                  and trunc(g.dt_emissao) > '01/06/2020' -- INSERIDO EM 24/06/2021 VERIFICA��O DE PERFORMACE.

        union

        /*
        -- Com ocorr�ncia
        select g.nr_guia,
                g.nr_transacao,
                trunc(g.dt_emissao) dt_emissao,
                u.cd_mat_alternativa,
                u.nm_segurado,
                dbaps.fnc_status_guia(g.nr_guia) Status,
                decode(g.cd_tipo_atendimento,
                       '2',
                       'Exame',
                       '3',
                       'Interna��o',
                       'Consulta') Tipoautorizacao,
                Case
                  when to_char(g.dt_emissao, 'd') = '1' then --S�bado
                   dbaps.fn_dias_uteis_feriado(g.dt_emissao, (sysdate))
                  when to_char(g.dt_emissao, 'd') = '7' then --Domingo
                   dbaps.fn_dias_uteis_feriado(g.dt_emissao, (sysdate))
                  when dbaps.fn_dias_uteis_feriado(g.dt_emissao, g.dt_emissao) = 0 then
                   dbaps.fn_dias_uteis_feriado(g.dt_emissao, (sysdate))
                  else
                   dbaps.fn_dias_uteis_feriado(g.dt_emissao, (sysdate - 1))
                end dias_uteis,
                decode(g.cd_tipo_atendimento,
                       '3',
                       dbaps.fn_adiciona_dias_uteis_feria_t(g.dt_emissao, 2),
                       dbaps.fn_adiciona_dias_uteis_feria_t(g.dt_emissao, 1)) dias_maximo_resposta,
                lpad(g.cd_prestador_executor, 6, 0) || ' - ' ||
                pr.nm_prestador prestador,
                go.cd_classificacao_ocor_guia cd_ocorrencia,
                cog.abreviacao_descricao ocorrencia,
                go.ds_observacao observacao,
                (select listagg(p.ds_procedimento, ', ') within group(order by p.ds_procedimento) procedimento
                   from dbaps.itguia it, dbaps.procedimento p
                  where it.cd_procedimento = p.cd_procedimento
                    and it.nr_guia = g.nr_guia) procedimento,
                (select a.nm_autorizador
                   from dbaps.autorizador a
                  where a.cd_autorizador = g.cd_autorizador) autorizador,
                1 linha

          from dbaps.guia                          g,
                dbaps.usuario                       u,
                dbaps.prestador                     pr,
                dbaps.guia_ocorrencia               go,
                dbaps.classificacao_ocorrencia_guia cog
         where g.cd_matricula = u.cd_matricula
           and pr.cd_prestador(+) = g.cd_prestador_executor
           and go.nr_guia = g.nr_guia
           and go.cd_classificacao_ocor_guia = cog.cd_classificacao_ocor_guia
           and (g.cd_mot_cancelamento_guia is null or
               g.cd_mot_cancelamento_guia in ('7', '8')) --exceto canceladas e negadas
           and g.dt_impressao_guia is null
           and g.cd_matricula is not null

           and go.dt_inclusao =
               (select max(goo.dt_inclusao)
                  from dbaps.classificacao_ocorrencia_guia c,
                       dbaps.guia_ocorrencia               goo
                 where goo.nr_guia = g.nr_guia
                   and goo.cd_classificacao_ocor_guia =
                       c.cd_classificacao_ocor_guia
                   and c.tp_class_ocorrencia_guia = 'W')
           and go.cd_classificacao_ocor_guia in
               (select co.cd_classificacao_ocor_guia
                  from dbaps.classificacao_ocorrencia_guia co
                 where (co.cd_classificacao_ocor_guia in
                       ('32',
                         '33',
                         '51',
                         '52',
                         '53',
                         '54',
                         '55',
                         '73',
                         '74',
                         '75',
                         '87',
                         '98',
                         '132',
                         '133',
                         '147',
                         '168'))
                   and co.cd_classificacao_ocor_guia <> '87')

           and not exists
         (select 1
                  from dbaps.log_autoriza l
                 where l.nr_guia = g.nr_guia
                   and l.ds_funcionalidade = 'CANCELAMENTO DA AUTORIZA��O.'
                   and exists (select 1
                          from dbasgu.usuarios u
                         where u.cd_usuario = l.nm_usuario_oracle
                           and substr(u.ds_observacao, 0, 4) not in
                               ('2013', '0189')))*/

        -- Com ocorr�ncia e Terapias
        select g.nr_guia,
                g.nr_transacao,
                trunc(g.dt_emissao) dt_emissao,
                u.cd_mat_alternativa,
                u.nm_segurado,
                dbaps.fnc_status_guia(g.nr_guia) Status,
                case
                  when dbaps.fnc_retorna_guia_terapia(g.nr_guia) = 'S' then
                   'Terapia'
                  else
                   decode(g.cd_tipo_atendimento,
                          '2',
                          'Exame',
                          '3',
                          'Interna��o',
                          'Consulta')
                end Tipoautorizacao,
                Case
                  when to_char(g.dt_emissao, 'd') = '1' then --S�bado
                   dbaps.fn_dias_uteis_feriado(g.dt_emissao, (sysdate))
                  when to_char(g.dt_emissao, 'd') = '7' then --Domingo
                   dbaps.fn_dias_uteis_feriado(g.dt_emissao, (sysdate))
                  when dbaps.fn_dias_uteis_feriado(g.dt_emissao, g.dt_emissao) = 0 then
                   dbaps.fn_dias_uteis_feriado(g.dt_emissao, (sysdate))
                  else
                   dbaps.fn_dias_uteis_feriado(g.dt_emissao, (sysdate - 1))
                end dias_uteis,
                decode(g.cd_tipo_atendimento,
                       '3',
                       dbaps.fn_adiciona_dias_uteis_feria_t(g.dt_emissao, 2),
                       dbaps.fn_adiciona_dias_uteis_feria_t(g.dt_emissao, 1)) dias_maximo_resposta,
                lpad(g.cd_prestador_executor, 6, 0) || ' - ' ||
                pr.nm_prestador prestador,
                go.cd_classificacao_ocor_guia cd_ocorrencia,
                cog.abreviacao_descricao ocorrencia,
                go.ds_observacao observacao,
                (select listagg(p.ds_procedimento, ', ') within group(order by p.ds_procedimento) procedimento
                   from dbaps.itguia it, dbaps.procedimento p
                  where it.cd_procedimento = p.cd_procedimento
                    and it.nr_guia = g.nr_guia) procedimento,
                (select a.nm_autorizador
                   from dbaps.autorizador a
                  where a.cd_autorizador = g.cd_autorizador) autorizador,
                1 linha

          from dbaps.guia                          g,
                dbaps.usuario                       u,
                dbaps.prestador                     pr,
                dbaps.guia_ocorrencia               go,
                dbaps.classificacao_ocorrencia_guia cog
         where g.cd_matricula = u.cd_matricula
           and pr.cd_prestador(+) = g.cd_prestador_executor
           and go.nr_guia = g.nr_guia
           and go.cd_classificacao_ocor_guia = cog.cd_classificacao_ocor_guia
           and (g.cd_mot_cancelamento_guia is null or
               g.cd_mot_cancelamento_guia in ('7', '8')) --exceto canceladas e negadas
           and g.dt_impressao_guia is null
           and g.cd_matricula is not null
           and g.cd_matricula <> '1173830071'


           and go.dt_inclusao =
               (select max(goo.dt_inclusao)
                  from dbaps.classificacao_ocorrencia_guia c,
                       dbaps.guia_ocorrencia               goo
                 where goo.nr_guia = g.nr_guia
                   and goo.cd_classificacao_ocor_guia =
                       c.cd_classificacao_ocor_guia
                   and c.tp_class_ocorrencia_guia = 'W')
           and go.cd_classificacao_ocor_guia in
               (select co.cd_classificacao_ocor_guia
                  from dbaps.classificacao_ocorrencia_guia co
                 where (co.cd_classificacao_ocor_guia in
                       ('32',
                         '33',
                         '51',
                         '52',
                         '53',
                         '54',
                         '55',
                         '73',
                         '74',
                         '75',
                         '87',
                         '98',
                         '132',
                         '133',
                         '147',
                         '168',
                         '188',
                         '200'
                         ))
                   and co.cd_classificacao_ocor_guia <> '87')

           and not exists
         (select 1
                  from dbaps.log_autoriza l
                 where l.nr_guia = g.nr_guia
                   and l.ds_funcionalidade = 'CANCELAMENTO DA AUTORIZA��O.'
                   and exists (select 1
                          from dbasgu.usuarios u
                         where u.cd_usuario = l.nm_usuario_oracle
                           and substr(u.ds_observacao, 1, 3) not in
                               ('318','103','112','113','209','205','114','289','291')))
                               and trunc(g.dt_emissao) > '01/06/2020' -- INSERIDO EM 24/06/2021 VERIFICA��O DE PERFORMACE.

        union

        -- Sem Log
        select g.nr_guia,
                g.nr_transacao,
                trunc(g.dt_emissao) dt_emissao,
                u.cd_mat_alternativa,
                u.nm_segurado,
                dbaps.fnc_status_guia(g.nr_guia) Status,
                decode(g.cd_tipo_atendimento,
                       '2',
                       'Exame',
                       '3',
                       'Interna��o',
                       'Consulta') Tipoautorizacao,
                Case
                  when to_char(g.dt_emissao, 'd') = '1' then --S�bado
                   dbaps.fn_dias_uteis_feriado(g.dt_emissao, (sysdate))
                  when to_char(g.dt_emissao, 'd') = '7' then --Domingo
                   dbaps.fn_dias_uteis_feriado(g.dt_emissao, (sysdate))
                  when dbaps.fn_dias_uteis_feriado(g.dt_emissao, g.dt_emissao) = 0 then
                   dbaps.fn_dias_uteis_feriado(g.dt_emissao, (sysdate))
                  else
                   dbaps.fn_dias_uteis_feriado(g.dt_emissao, (sysdate - 1))
                end dias_uteis,
                decode(g.cd_tipo_atendimento,
                       '3',
                       dbaps.fn_adiciona_dias_uteis_feria_t(g.dt_emissao, 2),
                       dbaps.fn_adiciona_dias_uteis_feria_t(g.dt_emissao, 1)) dias_maximo_resposta,
                lpad(g.cd_prestador_executor, 6, 0) || ' - ' ||
                pr.nm_prestador prestador,
                null cd_ocorrencia,
                null ocorrencia,
                'SEM LOG' observacao,
                (select listagg(p.ds_procedimento, ', ') within group(order by p.ds_procedimento) procedimento
                   from dbaps.itguia it, dbaps.procedimento p
                  where it.cd_procedimento = p.cd_procedimento
                    and it.nr_guia = g.nr_guia) procedimento,
                (select au.nm_autorizador
                   from dbaps.autorizador au
                  where au.cd_autorizador = g.cd_autorizador) autorizador,
                1 linha

          from dbaps.guia        g,
                dbaps.usuario     u,
                dbaps.prestador   pr,
                dbaps.autorizador a,
                dbasgu.usuarios   us
         where g.cd_matricula = u.cd_matricula
           and pr.cd_prestador(+) = g.cd_prestador_executor
           and a.cd_autorizador = g.cd_autorizador
           and a.cd_usuario = us.cd_usuario
           and (g.cd_mot_cancelamento_guia is null or
               g.cd_mot_cancelamento_guia in ('7', '8')) --exceto canceladas e negadas
           and g.dt_impressao_guia is null
           and g.cd_matricula is not null
           and g.cd_matricula <> '1173830071'
           and substr(us.ds_observacao, 1, 3) in ('318','103','112','113',  '209','205','114','289','291')
           and not exists
         (

                select 1
                  from dbaps.log_autoriza l, dbasgu.usuarios us
                 where l.nm_usuario_oracle = us.cd_usuario
                   and l.nr_guia = g.nr_guia
                   and l.ds_funcionalidade like '[I] GUIA%CADASTRADA')
           and not exists
         (select 1
                  from dbaps.guia_ocorrencia goc
                 inner join dbaps.classificacao_ocorrencia_guia co
                    on (goc.cd_classificacao_ocor_guia =
                       co.cd_classificacao_ocor_guia)
                 where goc.nr_guia = g.nr_guia
                   and co.tp_class_ocorrencia_guia = 'W')
                   and trunc(g.dt_emissao) > '01/06/2020' -- INSERIDO EM 24/06/2021 VERIFICA��O DE PERFORMACE.

        union

        --Terapia Autorizador

        select g.nr_guia,
                g.nr_transacao,
                trunc(g.dt_emissao) dt_emissao,
                u.cd_mat_alternativa,
                u.nm_segurado,
                dbaps.fnc_status_guia(g.nr_guia) Status,
                'Terapia' Tipoautorizacao,
                Case
                  when to_char(g.dt_emissao, 'd') = '1' then --S�bado
                   dbaps.fn_dias_uteis_feriado(g.dt_emissao, (sysdate))
                  when to_char(g.dt_emissao, 'd') = '7' then --Domingo
                   dbaps.fn_dias_uteis_feriado(g.dt_emissao, (sysdate))
                  when dbaps.fn_dias_uteis_feriado(g.dt_emissao, g.dt_emissao) = 0 then
                   dbaps.fn_dias_uteis_feriado(g.dt_emissao, (sysdate))
                  else
                   dbaps.fn_dias_uteis_feriado(g.dt_emissao, (sysdate - 1))
                end dias_uteis,
                decode(g.cd_tipo_atendimento,
                       '3',
                       dbaps.fn_adiciona_dias_uteis_feria_t(g.dt_emissao, 2),
                       dbaps.fn_adiciona_dias_uteis_feria_t(g.dt_emissao, 1)) dias_maximo_resposta,
                lpad(g.cd_prestador_executor, 6, 0) || ' - ' ||
                pr.nm_prestador prestador,
                goc.cd_classificacao_ocor_guia cd_ocorrencia,
                co.abreviacao_descricao ocorrencia,
                goc.ds_observacao observacao,
                (select listagg(p.ds_procedimento, ', ') within group(order by p.ds_procedimento) procedimento
                   from dbaps.itguia it, dbaps.procedimento p
                  where it.cd_procedimento = p.cd_procedimento
                    and it.nr_guia = g.nr_guia) procedimento,
                (select a.nm_autorizador
                   from dbaps.autorizador a
                  where a.cd_autorizador = g.cd_autorizador) autorizador,
                1 linha

          from dbaps.guia                          g,
                dbaps.usuario                       u,
                dbaps.prestador                     pr,
                dbaps.guia_ocorrencia               goc,
                dbaps.classificacao_ocorrencia_guia co,
                dbaps.procedimento                  po,
                dbaps.itguia                        it
         where g.cd_matricula = u.cd_matricula
           AND Pr.CD_PRESTADOR(+) = G.Cd_Prestador_Executor
           and goc.nr_guia = g.nr_guia
           and goc.cd_classificacao_ocor_guia = co.cd_classificacao_ocor_guia
           and it.nr_guia = g.nr_guia
           and po.cd_procedimento = it.cd_procedimento
           and g.cd_matricula <> '1173830071'


           and (g.cd_mot_cancelamento_guia is null or
               g.cd_mot_cancelamento_guia in (7, 8)) --exceto canceladas e negadas
           and g.dt_impressao_guia is null
           and g.cd_matricula is not null

           AND GOC.DT_INCLUSAO =
               (SELECT MAX(GI.DT_INCLUSAO)
                  FROM DBAPS.GUIA_OCORRENCIA               GI,
                       DBAPS.CLASSIFICACAO_OCORRENCIA_GUIA C
                 WHERE GI.NR_GUIA = G.NR_GUIA
                   AND C.CD_CLASSIFICACAO_OCOR_GUIA =
                       GI.CD_CLASSIFICACAO_OCOR_GUIA
                   AND C.TP_CLASS_OCORRENCIA_GUIA = 'W')

           and g.cd_tipo_atendimento = '11'
           and it.cd_procedimento not in ('50000144', '31601014')
           and po.cd_grupo_procedimento <> '1014' -- 11/03 Retirado Grupo de Procedimento Fisioterapias

           and dbaps.fnc_status_guia(g.nr_guia) = 'Em analise [3]'

          -- and goc.cd_classificacao_ocor_guia not in ('34', '86', '143') -- 16/03 Inseridas as ocorr�ncias 86 e 143 a pedido da Andreia

           /* inserido o bloco em 24/06/2021 - CH2106-1440 Guia no painel indevida
             -inicio
             */

            and not exists
               (select 1
                  from dbaps.classificacao_ocorrencia_guia co, dbaps.guia_ocorrencia goc
                  Where goc.cd_classificacao_ocor_guia = co.cd_classificacao_ocor_guia
                  And goc.nr_guia = g.nr_guia
                 and co.cd_classificacao_ocor_guia in ('34', '86', '143'))
             --fim
           and not exists
         (select 1
                  from DBAPS.LOG_AUTORIZA l
                 where l.nr_guia = g.nr_guia
                   and l.ds_funcionalidade = 'CANCELAMENTO DA AUTORIZA��O.'
                   and exists (select 1
                          from dbasgu.usuarios u
                         where u.cd_usuario = l.nm_usuario_oracle
                           and substr(u.ds_observacao, 1, 3) not in
                               ('318','103','112','113','209','205','114','289','291')))
                               and trunc(g.dt_emissao) > '01/06/2020' -- INSERIDO EM 24/06/2021 VERIFICA��O DE PERFORMACE.
        ) v
;
