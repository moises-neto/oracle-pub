CREATE OR REPLACE NONEDITIONABLE Procedure DBAPS.Prc_Valida_Prot_Tiss_Tes(Pcd_Protocolo_Ctamed In Number,
                                                                          Pcd_Lote_Autweb      In Number Default Null) Is
  /**************************************************************
    Objeto de valida��o do protocolo Tiss da Unimed Sorocaba
  CRIA��O           : Vania Gomes de Medeiros - UNIMED SOROCABA
  DATA             : 05/08/2020
  OBJETIVO         : Estamos seguindo o objeto da MV prc_mvs_valida_protocolo_tiss,
                     mas nesse obejto vamos validar somente o que precisamos.(Como se fosse um ponto de entrada)
  
  ***************************************************************/
  /************************************************************
  *                          TYPES                           *
  ***********************************************************/
  Type Tparametros Is Table Of Dbaps.Config_Valida_Lote_Cobr_Unimed%Rowtype Index By Varchar2(10);
  --cursor do dados das guias
  -- DIF_HORAS_VALIDACAO - ESQUEMA PARA EVITAR VALIDA��O DE GUIAS J� HOMOLOGADAS NA ULTIMA HORA (FOCO: PERFORMANCE) (apos 1 hora revalida-se tudo)
  Cursor Cvtissloteguia(p_Cd_Protocolo_Ctamed In Number) Is
    Select v.Nr_Numero_Carteira,
           Regexp_Replace(v.Nr_Guia_Prestador, '[^[:digit:]]+') Nr_Guia_Prestador,
           Regexp_Replace(v.Nr_Guia_Operadora, '[^[:digit:]]+') Nr_Guia_Operadora,
           v.Cd_Prestador,
           v.Nm_Beneficiario,
           Regexp_Replace(v.Nr_Senha_Autorizacao, '[^[:digit:]]+') Nr_Senha_Autorizacao,
           v.Cd_Protocolo_Ctamed,
           Regexp_Replace(v.Nr_Identificador_Beneficiario, '[^[:digit:]]+') Nr_Identificador_Beneficiario,
           Regexp_Replace(v.Cd_Prestador_Exec, '[^[:digit:]]+') Cd_Prestador_Exec,
           Regexp_Replace(v.Cnpj_Exec, '[^[:digit:]]+') Cnpj_Exec,
           Regexp_Replace(v.Cpf_Exec, '[^[:digit:]]+') Cpf_Exec,
           v.Cd_Multi_Empresa,
           v.Id_Pai,
           v.Cd_Procedimento
      From Dbaps.v_Tiss_Lote_Guia v
     Where v.Cd_Protocolo_Ctamed = Pcd_Protocolo_Ctamed
       And Pcd_Protocolo_Ctamed Is Not Null
     Group By v.Nr_Numero_Carteira,
              v.Nr_Guia_Prestador,
              v.Nr_Guia_Operadora,
              v.Cd_Prestador,
              v.Nm_Beneficiario,
              v.Nr_Senha_Autorizacao,
              v.Cd_Protocolo_Ctamed,
              v.Nr_Identificador_Beneficiario,
              v.Cd_Prestador_Exec,
              v.Cnpj_Exec,
              v.Cpf_Exec,
              v.Cd_Multi_Empresa,
              v.Id_Pai,
              v.Cd_Procedimento;

  Cursor Cexisteerro(p_Cd_Erro             In Varchar,
                     p_Cd_Protocolo_Ctamed In Number,
                     p_Nr_Guia_Prestador   In Varchar2) Is
    Select 1
      From Dbaps.Log_Erro_Protocolo_Tiss
     Where Cd_Protocolo_Ctamed = p_Cd_Protocolo_Ctamed
       And Cd_Erro = p_Cd_Erro
       And Ds_Guia_Prestador = p_Nr_Guia_Prestador;
  /**
  * Obtem o valor de uma chave
  */
  Cursor Cmvsconfiguracao(p_Chave In Varchar2, Pcd_Multi_Empresa In Number) Is
    Select Valor
      From Dbaps.Mvs_Configuracao
     Where Chave = p_Chave
       And Cd_Multi_Empresa = Pcd_Multi_Empresa;

  /**
  *  Cursor cProtocoloCtaMed
  */
  Cursor Cprotocoloctamed(p_Cd_Protocolo_Ctamed In Number) Is
    Select Pc.Id_Tisslotguia,
           Pc.Cd_Prestador,
           Mt.Cd_Retorno_Tiss_Mensagem Id_Tiss_Mensagem_Retorno,
           Tm.Id,
           Mt.Cd_Tiss_Mensagem,
           Pc.Cd_Protocolo_Ctamed,
           Pc.Cd_Multi_Empresa,
           Pc.Dt_Envio_Lote
      From Dbaps.Protocolo_Ctamed Pc,
           Dbaps.Tiss_Lot_Guia    Tlg,
           Dbaps.Tiss_Mensagem    Tm,
           Dbaps.Mv_Tiss          Mt,
           Dbaps.Prestador        p,
           Dbaps.Fatura           f
     Where Pc.Id_Tisslotguia = Tlg.Id
       And Tlg.Id_Pai = Tm.Id
       And Tm.Id = Mt.Cd_Tiss_Mensagem(+)
       And Pc.Cd_Prestador = p.Cd_Prestador
       And Pc.Cd_Fatura = f.Cd_Fatura(+)
       And Pc.Cd_Protocolo_Ctamed = p_Cd_Protocolo_Ctamed;

  /**
  *  Cursor cVerificaProcedimento, verifica se o Procedimento precisa de avalicao previa.
  */
  Cursor Cverificaprocedimento(p_Cd_Procedimento In Varchar2) Is
    Select p.Sn_Alerta_Audit_Cm,
           p.Tp_Sexo,
           p.Nr_Idade_Minima,
           p.Nr_Idade_Maxima,
           p.Cd_Grupo_Procedimento,
           p.Qtd_Max_Exec_Item,
           p.Qtd_Max_Exec_Dia,
           p.Sn_Obriga_Equipe_Xml
      From Dbaps.Procedimento p
     Where p.Cd_Procedimento = p_Cd_Procedimento;

  --Mois�s 25/03/2022 --> (CH2203-0567) N�o permitir a postagem de arquivo com consulta 10101039 COM o CD_TIPO_ATENDIMENTO_TISS <>11

  Cursor Cverificaconsultaps Is
    Select v.Cd_Protocolo_Ctamed,
           v.Nr_Numero_Carteira,
           v.Nr_Guia_Prestador,
           v.Nr_Senha_Autorizacao,
           v.Cd_Prestador,
           v.Nm_Beneficiario,
           v.Nr_Guia_Operadora,
           v.Cd_Tipo_Atendimento
      From Dbaps.v_Tiss_Lote_Guia v
     Where v.Cd_Protocolo_Ctamed = Pcd_Protocolo_Ctamed
       And v.Cd_Procedimento = '10101039'
       And v.Cd_Tipo_Atendimento <> '11';
  -- Mois�s --> 12/04/2022 atender ao requisito do manual do PTU XML --> CH2202-2485
  -- (travar quando for guia de interna��o, conter os procedimento
  --31309038, 31309054, 31309097, 31309127 e 31309135, e n�o tiver o CD_TIPO_INTERNACAO = 3.

  Cursor Ctipointernacao Is
    Select v.Cd_Protocolo_Ctamed,
           v.Nr_Numero_Carteira,
           v.Nr_Guia_Prestador,
           v.Nr_Senha_Autorizacao,
           v.Cd_Prestador,
           v.Nm_Beneficiario,
           v.Nr_Guia_Operadora,
           v.Cd_Tipo_Internacao
      From Dbaps.v_Tiss_Lote_Guia v
     Where v.Cd_Protocolo_Ctamed = Pcd_Protocolo_Ctamed
       And v.Cd_Tipo_Internacao <> 3
       And v.Cd_Procedimento In
           (31309038, 31309054, 31309097, 31309127, 31309135);

  -- CH2203-1210 (Moises --> Travar XML quando j� conter uma guia no contas). Data: 04/05/2022

  Cursor Cguiasduplicadas Is
    Select v.Cd_Protocolo_Ctamed,
           v.Nr_Numero_Carteira,
           v.Nr_Guia_Prestador,
           v.Nr_Senha_Autorizacao,
           v.Cd_Prestador,
           v.Nm_Beneficiario,
           v.Nr_Guia_Operadora,
           v.Cd_Tipo_Atendimento,
           v.Cd_Tipo_Internacao
      From Dbaps.v_Tiss_Lote_Guia v
     Where v.Cd_Tipo_Atendimento = 1
       And v.Cd_Prestador <> 1001949 --CH2212-2482
       And Exists (Select 1
              From Dbaps.Remessa_Prestador Rp
            
             Where Rp.Nr_Guia =
                   To_Number(Custom.Pkg_Conmvs_Tiss_Xml.Fnc_Ajusta_Numero(v_String => v.Nr_Guia_Operadora))
               And Rownum = 1
            Union All
            Select 1
              From Dbaps.Remessa_Prestador Rp
             Where Rp.Nr_Guia =
                   To_Number(Custom.Pkg_Conmvs_Tiss_Xml.Fnc_Ajusta_Numero(v_String => v.Nr_Guia_Prestador))
               And Rownum = 1
            
            )
          
       And v.Cd_Protocolo_Ctamed = Pcd_Protocolo_Ctamed
    
    Union All
    --Interna��o
    Select v.Cd_Protocolo_Ctamed,
           v.Nr_Numero_Carteira,
           v.Nr_Guia_Prestador,
           v.Nr_Senha_Autorizacao,
           v.Cd_Prestador,
           v.Nm_Beneficiario,
           v.Nr_Guia_Operadora,
           v.Cd_Tipo_Atendimento,
           v.Cd_Tipo_Internacao
      From Dbaps.v_Tiss_Lote_Guia v, Dbaps.Tiss_Lot_Guia_Fat_Resint Iod
     Where v.Cd_Protocolo_Ctamed = Pcd_Protocolo_Ctamed
       And Iod.Id = v.Id_Pai
       And Iod.Cd_Tipo_Faturamento <> 3
       And v.Cd_Prestador <> 1001949 --CH2212-2482
       And Exists (Select 1
              From Dbaps.Conta_Hospitalar c
             Where c.Nr_Guia =
                   To_Number(Custom.Pkg_Conmvs_Tiss_Xml.Fnc_Ajusta_Numero(v_String => v.Nr_Guia_Operadora))
               And c.Cd_Tipo_Faturamento <> 'C'
               And Rownum = 1
            Union All
            
            Select 1
              From Dbaps.Conta_Hospitalar c
             Where c.Nr_Guia =
                   To_Number(Custom.Pkg_Conmvs_Tiss_Xml.Fnc_Ajusta_Numero(v_String => v.Nr_Guia_Prestador))
               And c.Cd_Tipo_Faturamento <> 'C'
               And Rownum = 1)
    
    Union All --(SADT)
    
    Select v.Cd_Protocolo_Ctamed,
           v.Nr_Numero_Carteira,
           v.Nr_Guia_Prestador,
           v.Nr_Senha_Autorizacao,
           v.Cd_Prestador,
           v.Nm_Beneficiario,
           v.Nr_Guia_Operadora,
           v.Cd_Tipo_Atendimento,
           v.Cd_Tipo_Internacao
      From Dbaps.v_Tiss_Lote_Guia v
     Where v.Cd_Protocolo_Ctamed = Pcd_Protocolo_Ctamed
       And v.Cd_Tipo_Atendimento Not In (3, 8, 10)
       And v.Cd_Prestador <> 1001949 --CH2212-2482  
       And Exists
     (Select 1
              From Dbaps.Remessa_Prestador Rp, Itremessa_Prestador Ip
             Where Rp.Cd_Remessa = Ip.Cd_Remessa
               And Rp.Nr_Guia =
                   To_Number(Custom.Pkg_Conmvs_Tiss_Xml.Fnc_Ajusta_Numero(v_String => v.Nr_Guia_Prestador))
               And Nvl(Ip.Cd_Procedimento, Ip.Cd_Proc_Digita) =
                   v.Cd_Procedimento
               And To_Char(Ip.Qt_Cobrado) = v.Qt_Realizado
               And To_Char(Ip.Dt_Realizado, 'DD/MM/YYYY') =
                   Substr(v.Dt_Procedimento, 9, 9) || '/' ||
                   Substr(v.Dt_Procedimento, 6, 2) || '/' ||
                   Substr(v.Dt_Procedimento, 0, 4)
               And Rownum = 1
            Union All
            
            Select 1
              From Dbaps.Remessa_Prestador Rp, Itremessa_Prestador Ip
             Where Rp.Cd_Remessa = Ip.Cd_Remessa
                  
               And Rp.Nr_Guia =
                   To_Number(Custom.Pkg_Conmvs_Tiss_Xml.Fnc_Ajusta_Numero(v_String => v.Nr_Guia_Operadora))
               And Nvl(Ip.Cd_Procedimento, Ip.Cd_Proc_Digita) =
                   v.Cd_Procedimento
               And To_Char(Ip.Qt_Cobrado) = v.Qt_Realizado
               And To_Char(Ip.Dt_Realizado, 'DD/MM/YYYY') =
                   Substr(v.Dt_Procedimento, 9, 9) || '/' ||
                   Substr(v.Dt_Procedimento, 6, 2) || '/' ||
                   Substr(v.Dt_Procedimento, 0, 4)
               And Rownum = 1);

  Cursor Ccodigoinexistente Is
    Select Distinct v.Cd_Protocolo_Ctamed,
                    v.Nr_Numero_Carteira,
                    v.Nr_Guia_Prestador,
                    v.Nr_Senha_Autorizacao,
                    v.Cd_Prestador,
                    v.Nm_Beneficiario,
                    v.Nr_Guia_Operadora,
                    v.Cd_Procedimento
      From Dbaps.v_Tiss_Lote_Guia v
     Where v.Cd_Protocolo_Ctamed = Pcd_Protocolo_Ctamed
       And v.Cd_Procedimento <> '99910073'
       And Not Exists
     (Select 1
              From Dbaps.Procedimento p
             Where p.Cd_Procedimento = v.Cd_Procedimento);

  --Guia vencida
  Cursor Cguiavencida Is
  --Interna��o
    Select v.Cd_Protocolo_Ctamed,
           v.Nr_Numero_Carteira,
           v.Nr_Guia_Prestador,
           v.Nr_Senha_Autorizacao,
           v.Cd_Prestador,
           v.Nm_Beneficiario,
           v.Nr_Guia_Operadora,
           v.Cd_Tipo_Atendimento,
           v.Cd_Tipo_Internacao
      From Dbaps.v_Tiss_Lote_Guia v
     Where v.Cd_Protocolo_Ctamed = Pcd_Protocolo_Ctamed
       And Exists
     (Select 1
              From Dbaps.Conta_Hospitalar c, Dbaps.Itconta_Hospitalar Ih
             Where c.Cd_Conta_Hospitalar = Ih.Cd_Conta_Hospitalar
               And c.Nr_Guia =
                   To_Number(Custom.Pkg_Conmvs_Tiss_Xml.Fnc_Ajusta_Numero(v_String => v.Nr_Guia_Operadora))
               And Exists (Select 1
                      From Dbaps.Guia g
                     Where g.Nr_Guia = c.Nr_Guia
                       And g.Sn_Valida_Rest_Carencia = 'S'
                       And Substr(v.Dt_Procedimento, 9, 9) || '/' ||
                           Substr(v.Dt_Procedimento, 6, 2) || '/' ||
                           Substr(v.Dt_Procedimento, 0, 4) >
                           Trunc(g.Dt_Vencimento))
            
            Union
            
            Select 1
              From Dbaps.Conta_Hospitalar c, Dbaps.Itconta_Hospitalar Ih
             Where c.Cd_Conta_Hospitalar = Ih.Cd_Conta_Hospitalar
               And c.Nr_Guia =
                   To_Number(Custom.Pkg_Conmvs_Tiss_Xml.Fnc_Ajusta_Numero(v_String => v.Nr_Guia_Prestador))
               And Exists (Select 1
                      From Dbaps.Guia g
                     Where g.Nr_Guia = c.Nr_Guia
                       And g.Sn_Valida_Rest_Carencia = 'S'
                       And Substr(v.Dt_Procedimento, 9, 9) || '/' ||
                           Substr(v.Dt_Procedimento, 6, 2) || '/' ||
                           Substr(v.Dt_Procedimento, 0, 4) >
                           Trunc(g.Dt_Vencimento)))
    Union All --(SADT) e Consulta
    
    Select v.Cd_Protocolo_Ctamed,
           v.Nr_Numero_Carteira,
           v.Nr_Guia_Prestador,
           v.Nr_Senha_Autorizacao,
           v.Cd_Prestador,
           v.Nm_Beneficiario,
           v.Nr_Guia_Operadora,
           v.Cd_Tipo_Atendimento,
           v.Cd_Tipo_Internacao
      From Dbaps.v_Tiss_Lote_Guia v
     Where v.Cd_Protocolo_Ctamed = Pcd_Protocolo_Ctamed
       And v.Cd_Tipo_Atendimento Not In (3, 8, 10)
       And Exists
     (Select 1
              From Dbaps.Remessa_Prestador Rp, Itremessa_Prestador Ip
             Where Rp.Cd_Remessa = Ip.Cd_Remessa
               And Rp.Nr_Guia =
                   To_Number(Custom.Pkg_Conmvs_Tiss_Xml.Fnc_Ajusta_Numero(v_String => v.Nr_Guia_Prestador))
               And Exists (Select 1
                      From Dbaps.Guia g
                     Where g.Nr_Guia = Rp.Nr_Guia
                       And g.Sn_Valida_Rest_Carencia = 'S'
                       And Substr(v.Dt_Procedimento, 9, 9) || '/' ||
                           Substr(v.Dt_Procedimento, 6, 2) || '/' ||
                           Substr(v.Dt_Procedimento, 0, 4) >
                           Trunc(g.Dt_Vencimento))
            
            Union
            
            Select 1
              From Dbaps.Remessa_Prestador Rp, Itremessa_Prestador Ip
             Where Rp.Cd_Remessa = Ip.Cd_Remessa
               And Rp.Nr_Guia =
                   To_Number(Custom.Pkg_Conmvs_Tiss_Xml.Fnc_Ajusta_Numero(v_String => v.Nr_Guia_Operadora))
                  
               And Exists (Select 1
                      From Dbaps.Guia g
                     Where g.Nr_Guia = Rp.Nr_Guia
                       And g.Sn_Valida_Rest_Carencia = 'S'
                       And Substr(v.Dt_Procedimento, 9, 9) || '/' ||
                           Substr(v.Dt_Procedimento, 6, 2) || '/' ||
                           Substr(v.Dt_Procedimento, 0, 4) >
                           Trunc(g.Dt_Vencimento)));

  --Valida��o da Carteira

  Cursor Cvalidacarteira Is
    Select v.Cd_Protocolo_Ctamed,
           v.Nr_Numero_Carteira,
           v.Nr_Guia_Prestador,
           v.Nr_Senha_Autorizacao,
           v.Cd_Prestador,
           v.Nm_Beneficiario,
           v.Nr_Guia_Operadora
      From Dbaps.v_Tiss_Lote_Guia v
     Where v.Cd_Protocolo_Ctamed = Pcd_Protocolo_Ctamed
       And Length(Trim(v.Nr_Numero_Carteira)) <= 16
       And Exists (Select 1
              From Dbaps.Guia g
             Where To_Char(g.Nr_Guia) = v.Nr_Guia_Operadora
               And Trim(g.Nr_Carteira_Utilizada) <>
                   Trim(v.Nr_Numero_Carteira))
    Union
    
    Select v.Cd_Protocolo_Ctamed,
           v.Nr_Numero_Carteira,
           v.Nr_Guia_Prestador,
           v.Nr_Senha_Autorizacao,
           v.Cd_Prestador,
           v.Nm_Beneficiario,
           v.Nr_Guia_Operadora
      From Dbaps.v_Tiss_Lote_Guia v
     Where v.Cd_Protocolo_Ctamed = Pcd_Protocolo_Ctamed
       And Length(Trim(v.Nr_Numero_Carteira)) >= 17
       And Exists
     (Select 1
              From Dbaps.Guia g
             Where To_Char(g.Nr_Guia) = v.Nr_Guia_Operadora
               And '0' || Trim(Nvl(g.Nr_Carteira_Utilizada,
                                   g.Nr_Carteira_Beneficiario)) <>
                   (v.Nr_Numero_Carteira));

  Cursor Cdadosprocprestador Is
    Select v.Cd_Protocolo_Ctamed,
           v.Nr_Numero_Carteira,
           v.Nr_Guia_Prestador,
           v.Nr_Senha_Autorizacao,
           v.Cd_Prestador,
           v.Nm_Beneficiario,
           v.Nr_Guia_Operadora,
           v.Cd_Procedimento
      From Dbaps.v_Tiss_Lote_Guia v
     Where v.Cd_Protocolo_Ctamed = Pcd_Protocolo_Ctamed
          
       And v.Cd_Prestador Is Null
       And Exists
     (Select 1
              From Procedimento p, Grupo_Procedimento Gp
             Where p.Cd_Grupo_Procedimento = Gp.Cd_Grupo_Procedimento
               And p.Cd_Procedimento = v.Cd_Procedimento
               And Gp.Tp_Gru_Pro = 'SP');

  --CH2210-1552 ORIGEM PORTAL TISS VALIDAR PELO PROPRIO XML SE A DATA DE REALIZACAO DO PROCEDIMENTO FOI INFORMADA.
  Cursor Cprazoexcecidoportal Is
    Select Tab.*
      From (Select v.Cd_Protocolo_Ctamed,
                   v.Nr_Numero_Carteira,
                   v.Nr_Guia_Prestador,
                   v.Nr_Senha_Autorizacao,
                   v.Cd_Prestador,
                   v.Nm_Beneficiario,
                   v.Nr_Guia_Operadora,
                   v.Cd_Procedimento,
                   To_Date(Substr(v.Dt_Procedimento, 9, 10) || '/' ||
                           Substr(v.Dt_Procedimento, 6, 2) || '/' ||
                           Substr(v.Dt_Procedimento, 1, 4),
                           'DD/MM/YYYY') Dt_Realizado
              From Dbaps.v_Tiss_Lote_Guia v
             Where v.Cd_Protocolo_Ctamed = Pcd_Protocolo_Ctamed
                  
               And v.Cd_Prestador <> 1001949 --CH2212-2482 
                  -- 17/10/2022 exce��a para  guias skype: 08:37  
               ) Tab
     Where Tab.Dt_Realizado <= Trunc(Sysdate) - 60
          
       And Exists (Select 1
              From Dbaps.Guia g
             Where g.Nr_Guia =
                   To_Number(Custom.Pkg_Conmvs_Tiss_Xml.Fnc_Ajusta_Numero(v_String => Tab.Nr_Guia_Operadora))
               And (g.Cd_Tipo_Atendimento Not In (2, 11) And
                   g.Cd_Tipo_Atendimento_Tiss Not In (3, 23)
                   
                   Or (g.Cd_Tipo_Atendimento Not In (2, 11) And
                   g.Cd_Tipo_Atendimento_Tiss Is Null))
            
            Union All
            Select 1
              From Dbaps.Guia g
             Where g.Nr_Guia =
                   To_Number(Custom.Pkg_Conmvs_Tiss_Xml.Fnc_Ajusta_Numero(v_String => Tab.Nr_Guia_Prestador))
               And (g.Cd_Tipo_Atendimento Not In (2, 11) And
                   g.Cd_Tipo_Atendimento_Tiss Not In (3, 23)
                   
                   Or (g.Cd_Tipo_Atendimento Not In (2, 11) And
                   g.Cd_Tipo_Atendimento_Tiss Is Null))
            
            );

  Cursor Climitetaxa Is
  
    Select a.Cd_Protocolo_Ctamed,
           a.Nr_Numero_Carteira,
           a.Nr_Guia_Prestador,
           a.Nr_Senha_Autorizacao,
           a.Cd_Prestador,
           a.Nm_Beneficiario,
           a.Nr_Guia_Operadora,
           a.Cd_Procedimento,
           Sum(a.Proctaxa) As Qtd_Taxa,
           a.Dt_Realizacao
      From (Select v.Cd_Protocolo_Ctamed,
                   v.Nr_Numero_Carteira,
                   v.Nr_Guia_Prestador,
                   v.Nr_Senha_Autorizacao,
                   v.Cd_Prestador,
                   v.Nm_Beneficiario,
                   v.Nr_Guia_Operadora,
                   v.Cd_Procedimento,
                   1                      As Proctaxa,
                   v.Dt_Procedimento      As Dt_Realizacao
              From Dbaps.v_Tiss_Lote_Guia v,
                   Dbaps.Procedimento     p,
                   Dbaps.Itguia           It
             Where v.Cd_Protocolo_Ctamed = Pcd_Protocolo_Ctamed
               And v.Cd_Procedimento = p.Cd_Procedimento
               And To_Char(It.Nr_Guia) = v.Nr_Guia_Operadora
               And It.Cd_Procedimento = p.Cd_Procedimento
               And p.Cd_Procedimento In ('60023001',
                                         '60023022',
                                         '60023033',
                                         '60023384',
                                         '60023287',
                                         '60023244')
               And It.Tp_Status = 4) a
    
     Group By a.Cd_Protocolo_Ctamed,
              a.Nr_Numero_Carteira,
              a.Nr_Guia_Prestador,
              a.Nr_Senha_Autorizacao,
              a.Cd_Prestador,
              a.Nm_Beneficiario,
              a.Nr_Guia_Operadora,
              a.Cd_Procedimento,
              a.Dt_Realizacao
    Having Sum(a.Proctaxa) > 1;

  Cursor Cguiaexecucao70dias Is
    Select Tab.*
      From (Select v.Cd_Protocolo_Ctamed,
                   v.Nr_Numero_Carteira,
                   v.Nr_Guia_Prestador,
                   v.Nr_Senha_Autorizacao,
                   v.Cd_Prestador,
                   v.Nm_Beneficiario,
                   v.Nr_Guia_Operadora,
                   v.Cd_Procedimento,
                   To_Date(Substr(v.Dt_Procedimento, 9, 10) || '/' ||
                           Substr(v.Dt_Procedimento, 6, 2) || '/' ||
                           Substr(v.Dt_Procedimento, 1, 4),
                           'DD/MM/YYYY') Dt_Realizado
              From Dbaps.v_Tiss_Lote_Guia v
             Where v.Cd_Protocolo_Ctamed = Pcd_Protocolo_Ctamed
                  -- 17/10/2022 exce��a para  guias skype: 08:37
               ) Tab
     Where (Trunc(Sysdate) - Tab.Dt_Realizado) > 70
       And Exists (Select 1
              From Dbaps.Guia g
             Where g.Nr_Guia =
                   To_Number(Custom.Pkg_Conmvs_Tiss_Xml.Fnc_Ajusta_Numero(v_String => Tab.Nr_Guia_Operadora))
               And g.Cd_Tipo_Atendimento In (1, 2, 3)
               And (g.Cd_Tipo_Atendimento_Tiss <> 3 Or
                   g.Cd_Tipo_Atendimento_Tiss Is Null)
            Union All
            Select 1
              From Dbaps.Guia g
             Where g.Nr_Guia =
                   To_Number(Custom.Pkg_Conmvs_Tiss_Xml.Fnc_Ajusta_Numero(v_String => Tab.Nr_Guia_Prestador))
               And g.Cd_Tipo_Atendimento In (1, 2, 3)
               And (g.Cd_Tipo_Atendimento_Tiss <> 3 Or
                   g.Cd_Tipo_Atendimento_Tiss Is Null));

  Cursor Cobrigagrauparticipacao Is
    Select v.Cd_Protocolo_Ctamed,
           v.Nr_Numero_Carteira,
           v.Nr_Guia_Prestador,
           v.Nr_Senha_Autorizacao,
           v.Cd_Prestador,
           v.Nm_Beneficiario,
           v.Nr_Guia_Operadora,
           v.Cd_Procedimento
      From Dbaps.Tiss_Lot_Guia_Fat_Resint      r,
           Dbaps.Tiss_Lot_Guia_Fat_Resint_Proc p,
           Dbaps.Tiss_Lot_Guia_Fat_Resint_Eqp  e,
           Dbaps.v_Tiss_Lote_Guia              v
     Where r.Id = p.Id_Pai
       And p.Id = e.Id_Pai
       And v.Id_Pai = r.Id
       And v.Cd_Protocolo_Ctamed = Pcd_Protocolo_Ctamed
       And e.Cd_Posicao_Profissional Is Null
          
       And Exists
     (Select 1
              From Dbaps.Procedimento p, Dbaps.Grupo_Procedimento Gp
             Where Gp.Cd_Grupo_Procedimento = p.Cd_Grupo_Procedimento
               And p.Cd_Procedimento = v.Cd_Procedimento
               And Gp.Tp_Gru_Pro = 'SP');

  Cursor Cprestadorexistenaoperadora Is
    Select v.Cd_Protocolo_Ctamed,
           v.Nr_Numero_Carteira,
           v.Nr_Guia_Prestador,
           v.Nr_Senha_Autorizacao,
           v.Cd_Prestador,
           v.Nm_Beneficiario,
           v.Nr_Guia_Operadora,
           v.Cd_Procedimento,
           Upper(e.Nm_Membro_Eqp) As Nm_Membro_Eqp,
           e.Nr_Conselho_Membro_Eqp
      From Dbaps.Tiss_Lot_Guia_Fat_Resint      r,
           Dbaps.Tiss_Lot_Guia_Fat_Resint_Proc p,
           Dbaps.Tiss_Lot_Guia_Fat_Resint_Eqp  e,
           Dbaps.v_Tiss_Lote_Guia              v
     Where r.Id = p.Id_Pai
       And 1 = 1 --13/10/2022 08:55 CONDICIONADO PARA N�O FUNCIONAR AT� QUE SEJA AJUSTADA. 
       And p.Id = e.Id_Pai
       And v.Id_Pai = r.Id
       And v.Cd_Protocolo_Ctamed = Pcd_Protocolo_Ctamed
          --And e.Nr_Conselho_Membro_Eqp != '300100' --skype: Josiel, tira o 300100 do prestador inexistente
          ----Habiltiado 18/11/2022 a pedido do chamado CH2211-3159
          /*    And Exists
          (Select 1
                   From Procedimento p
                  Where p.Cd_Procedimento = v.Cd_Procedimento
                    And Exists
                  (Select 1
                           From Grupo_Procedimento Gp
                          Where Gp.Cd_Grupo_Procedimento = p.Cd_Grupo_Procedimento
                            And Gp.Tp_Gru_Pro = 'SP')
                 Union All
                 
                 Select 1
                   From Procedimento p
                  Where p.Cd_Procedimento = v.Cd_Procedimento
                    And Exists
                  (Select 1
                           From Grupo_Procedimento Gp
                          Where Gp.Cd_Grupo_Procedimento = p.Cd_Grupo_Procedimento
                            And Gp.Tp_Gru_Pro = 'SD')
                 \*And p.Ds_Classe In
                 ('FISIOTERAPIAS', 'TERAPIAS', 'TERAPIAS ESPECIALIZADAS')*\
                 )*/
          
       And Not Exists (Select 1
              From Dbaps.Prestador Pr
             Where Lpad(Pr.Ds_Cod_Conselho, 6, '0') =
                   Lpad(e.Nr_Conselho_Membro_Eqp, 6, '0') /*Custom.Pkg_Conmvs_Tiss_Xml.Fnc_Ajusta_Numero(Pr.Ds_Cod_Conselho,
                                                                                                                                                                v_Ignora_Zero_Esquerda => 'S') =
                                                                                                                   Custom.Pkg_Conmvs_Tiss_Xml.Fnc_Ajusta_Numero(e.Nr_Conselho_Membro_Eqp,
                                                                                                                                                                v_Ignora_Zero_Esquerda => 'S')*/
            
            )
    Union All -- sadt  
    
    Select v.Cd_Protocolo_Ctamed,
           v.Nr_Numero_Carteira,
           v.Nr_Guia_Prestador,
           v.Nr_Senha_Autorizacao,
           v.Cd_Prestador,
           v.Nm_Beneficiario,
           v.Nr_Guia_Operadora,
           v.Cd_Procedimento,
           Upper(e.Nm_Membro_Eqp) As Nm_Membro_Eqp,
           e.Nr_Conselho_Membro_Eqp
      From Dbaps.Tiss_Lot_Guia_Fat_Sadt      r,
           Dbaps.Tiss_Lot_Guia_Fat_Sadt_Proc p,
           Dbaps.Tiss_Lot_Guia_Fat_Sadt_Eqp  e,
           Dbaps.v_Tiss_Lote_Guia            v
     Where r.Id = p.Id_Pai
       And p.Id = e.Id_Pai
       And v.Id_Pai = r.Id
       And v.Cd_Protocolo_Ctamed = Pcd_Protocolo_Ctamed
          
          /*   And Exists
          (Select 1
                   From Procedimento p
                  Where p.Cd_Procedimento = v.Cd_Procedimento
                    And Exists
                  (Select 1
                           From Grupo_Procedimento Gp
                          Where Gp.Cd_Grupo_Procedimento = p.Cd_Grupo_Procedimento
                            And Gp.Tp_Gru_Pro = 'SP')
                 Union All
                 
                 Select 1
                   From Procedimento p
                  Where p.Cd_Procedimento = v.Cd_Procedimento
                    And Exists
                  (Select 1
                           From Grupo_Procedimento Gp
                          Where Gp.Cd_Grupo_Procedimento = p.Cd_Grupo_Procedimento
                            And Gp.Tp_Gru_Pro = 'SD'))*/
          /* And p.Ds_Classe In
          ('FISIOTERAPIAS', 'TERAPIAS', 'TERAPIAS ESPECIALIZADAS'))*/
          
       And Not Exists (Select 1
              From Dbaps.Prestador Pr
             Where Lpad(Pr.Ds_Cod_Conselho, 6, '0') =
                   Lpad(e.Nr_Conselho_Membro_Eqp, 6, '0') /*Custom.Pkg_Conmvs_Tiss_Xml.Fnc_Ajusta_Numero(Pr.Ds_Cod_Conselho,
                                                                                                                                                                v_Ignora_Zero_Esquerda => 'S') =
                                                                                                                   Custom.Pkg_Conmvs_Tiss_Xml.Fnc_Ajusta_Numero(e.Nr_Conselho_Membro_Eqp,
                                                                                                                                                                v_Ignora_Zero_Esquerda => 'S')*/
            );

  -- CH2209-4741 TRAVA NO XML PARA SENHA EXTERNA COM valor = "0"         
  Cursor c_Guia_Prestador_Valor_0 Is
    Select v.Cd_Protocolo_Ctamed,
           v.Nr_Numero_Carteira,
           v.Nr_Guia_Prestador,
           v.Nr_Senha_Autorizacao,
           v.Cd_Prestador,
           v.Nm_Beneficiario,
           v.Nr_Guia_Operadora,
           v.Cd_Procedimento
      From Dbaps.v_Tiss_Lote_Guia v
     Where v.Cd_Protocolo_Ctamed = Pcd_Protocolo_Ctamed
       And v.Nr_Guia_Prestador = '0';

  -- CH2209-5401 TRAVA NO XML PARA EVITAR ENVIO DE GUIA INTERNA COMO SENDO GUIA EXTERNA.  
  Cursor c_Guia_Interna_Como_Externa Is
    Select v.Cd_Protocolo_Ctamed,
           v.Nr_Numero_Carteira,
           v.Nr_Guia_Prestador,
           v.Nr_Senha_Autorizacao,
           v.Cd_Prestador,
           v.Nm_Beneficiario,
           v.Nr_Guia_Operadora,
           v.Cd_Procedimento
      From Dbaps.v_Tiss_Lote_Guia v
     Where v.Cd_Protocolo_Ctamed = Pcd_Protocolo_Ctamed
       And (v.Nr_Guia_Operadora Is Null Or v.Nr_Guia_Operadora = '0')
       And v.Nr_Guia_Prestador Is Not Null
       And Exists (Select 1
              From Dbaps.Guia g
             Where To_Char(g.Nr_Guia) =
                   To_Number(Custom.Pkg_Conmvs_Tiss_Xml.Fnc_Ajusta_Numero(v_String => v.Nr_Guia_Prestador))
               And g.Tp_Origem = 'MVS' --GUIA INTERNA
            );
  --CH2210-1552 VERIFICA SE NO XML ENVIADO A DATA DE REALIZA��O DO PROCEDIMENTO FOI INFORMADA.                  
  Cursor c_Dt_Realizado_Is_Null Is
    Select v.Cd_Protocolo_Ctamed,
           v.Nr_Numero_Carteira,
           v.Nr_Guia_Prestador,
           v.Nr_Senha_Autorizacao,
           v.Cd_Prestador,
           v.Nm_Beneficiario,
           v.Nr_Guia_Operadora,
           v.Cd_Procedimento
      From Dbaps.v_Tiss_Lote_Guia v
     Where v.Cd_Protocolo_Ctamed = Pcd_Protocolo_Ctamed
       And v.Dt_Procedimento Is Null;

  --CH2209-5396  TRAVA GUIA INEXISTENTE NA OPERADORA  
  Cursor Cguiainexistente Is
  
    Select v.Cd_Protocolo_Ctamed,
           v.Nr_Numero_Carteira,
           v.Nr_Guia_Prestador,
           v.Nr_Senha_Autorizacao,
           v.Cd_Prestador,
           v.Nm_Beneficiario,
           v.Nr_Guia_Operadora,
           v.Cd_Procedimento
      From Dbaps.v_Tiss_Lote_Guia v
     Where v.Cd_Protocolo_Ctamed = Pcd_Protocolo_Ctamed
       And v.Nr_Guia_Operadora Is Not Null
       And Not Exists
     (Select 1 From Dbaps.Guia g Where g.Nr_Guia = v.Nr_Guia_Operadora)
       And Exists
     (Select 1
              From Custom.Tiss_Controle_Protocolo Tp
             Where Tp.Cd_Protocolo_Ctamed = v.Cd_Protocolo_Ctamed
               And Tp.Sn_Validado = 'N');

  -- inicio CH2209-5400 trava racionalizacao
  Cursor Ccodracionalizacaosemautoriza Is
    Select v.Cd_Protocolo_Ctamed,
           v.Nr_Numero_Carteira,
           v.Nr_Guia_Prestador,
           v.Nr_Senha_Autorizacao,
           v.Cd_Prestador,
           v.Nm_Beneficiario,
           v.Nr_Guia_Operadora,
           v.Cd_Procedimento
      From Dbaps.v_Tiss_Lote_Guia v
     Where v.Cd_Protocolo_Ctamed = Pcd_Protocolo_Ctamed
       And (v.Nr_Senha_Autorizacao Is Null Or v.Nr_Senha_Autorizacao = '0')
       And Exists
     (Select 1
              From Dbaps.Procedimento p, Dbaps.Grupo_Procedimento Gp
             Where p.Cd_Grupo_Procedimento = Gp.Cd_Grupo_Procedimento
               And p.Cd_Procedimento = v.Cd_Procedimento
               And Gp.Tp_Gru_Pro In ('SD', 'SP')
               And Not Exists
             (Select 2
                      From Dbaps.Procedimento_Baixo_Risco Pbr
                     Where Pbr.Cd_Procedimento = p.Cd_Procedimento
                       And To_Date(Pbr.Dt_Vigencia, 'DD/MM/YYYY') <=
                           To_Date(Sysdate, 'DD/MM/YYYY')));

  -- fim trava racionalizacao

  --
  Cursor Cobrigaprestadorspsd Is
    Select v.Cd_Protocolo_Ctamed,
           v.Nr_Numero_Carteira,
           v.Nr_Guia_Prestador,
           v.Nr_Senha_Autorizacao,
           v.Cd_Prestador,
           v.Nm_Beneficiario,
           v.Nr_Guia_Operadora,
           p.Cd_Procedimento,
           Upper(e.Nm_Membro_Eqp) As Nm_Membro_Eqp,
           e.Nr_Conselho_Membro_Eqp
      From Dbaps.Tiss_Lot_Guia_Fat_Resint      r,
           Dbaps.Tiss_Lot_Guia_Fat_Resint_Proc p,
           Dbaps.Tiss_Lot_Guia_Fat_Resint_Eqp  e,
           Dbaps.v_Tiss_Lote_Guia              v
     Where r.Id = p.Id_Pai
       And 1 = 1 --13/10/2022 08:55 CONDICIONADO PARA N�O FUNCIONAR AT� QUE SEJA AJUSTADA. 
       And p.Id = e.Id_Pai
       And v.Id_Pai = r.Id
       And v.Cd_Protocolo_Ctamed = Pcd_Protocolo_Ctamed
          --And e.Nr_Conselho_Membro_Eqp != '300100' --skype: Josiel, tira o 300100 do prestador inexistente
          ----Habilitado 18/11/2022 a pedido do chamado CH2211-3159
       And Exists
     (Select 1
              From Procedimento p
             Where p.Cd_Procedimento = v.Cd_Procedimento
               And Exists
             (Select 1
                      From Grupo_Procedimento Gp
                     Where Gp.Cd_Grupo_Procedimento = p.Cd_Grupo_Procedimento
                       And Gp.Tp_Gru_Pro = 'SP')
            Union All
            
            Select 1
              From Procedimento p
             Where p.Cd_Procedimento = v.Cd_Procedimento
               And Exists
             (Select 1
                      From Grupo_Procedimento Gp
                     Where Gp.Cd_Grupo_Procedimento = p.Cd_Grupo_Procedimento
                       And Gp.Tp_Gru_Pro = 'SD')
               And p.Ds_Classe In
                   ('FISIOTERAPIAS', 'TERAPIAS', 'TERAPIAS ESPECIALIZADAS'))
          
       And Not Exists
     (Select 1
              From Dbaps.Prestador Pr
             Where Lpad(Pr.Ds_Cod_Conselho, 6, '0') =
                   Lpad(e.Nr_Conselho_Membro_Eqp, 6, '0'))
    Union All -- sadt  
    
    Select v.Cd_Protocolo_Ctamed,
           v.Nr_Numero_Carteira,
           v.Nr_Guia_Prestador,
           v.Nr_Senha_Autorizacao,
           v.Cd_Prestador,
           v.Nm_Beneficiario,
           v.Nr_Guia_Operadora,
           p.Cd_Procedimento,
           Upper(e.Nm_Membro_Eqp) As Nm_Membro_Eqp,
           e.Nr_Conselho_Membro_Eqp
      From Dbaps.Tiss_Lot_Guia_Fat_Sadt      r,
           Dbaps.Tiss_Lot_Guia_Fat_Sadt_Proc p,
           Dbaps.Tiss_Lot_Guia_Fat_Sadt_Eqp  e,
           Dbaps.v_Tiss_Lote_Guia            v
     Where r.Id = p.Id_Pai
       And p.Id = e.Id_Pai
       And v.Id_Pai = r.Id
       And v.Cd_Protocolo_Ctamed = Pcd_Protocolo_Ctamed
          
       And Exists
     (Select 1
              From Procedimento p
             Where p.Cd_Procedimento = v.Cd_Procedimento
               And Exists
             (Select 1
                      From Grupo_Procedimento Gp
                     Where Gp.Cd_Grupo_Procedimento = p.Cd_Grupo_Procedimento
                       And Gp.Tp_Gru_Pro = 'SP')
            Union All
            
            Select 1
              From Procedimento p
             Where p.Cd_Procedimento = v.Cd_Procedimento
               And Exists
             (Select 1
                      From Grupo_Procedimento Gp
                     Where Gp.Cd_Grupo_Procedimento = p.Cd_Grupo_Procedimento
                       And Gp.Tp_Gru_Pro = 'SD')
               And p.Ds_Classe In
                   ('FISIOTERAPIAS', 'TERAPIAS', 'TERAPIAS ESPECIALIZADAS'))
          
       And Not Exists
     (Select 1
              From Dbaps.Prestador Pr
             Where Lpad(Pr.Ds_Cod_Conselho, 6, '0') =
                   Lpad(e.Nr_Conselho_Membro_Eqp, 6, '0')); /*Custom.Pkg_Conmvs_Tiss_Xml.Fnc_Ajusta_Numero(Pr.Ds_Cod_Conselho,
                                                                v_Ignora_Zero_Esquerda => 'S') =
                   Custom.Pkg_Conmvs_Tiss_Xml.Fnc_Ajusta_Numero(e.Nr_Conselho_Membro_Eqp,
                                                                v_Ignora_Zero_Esquerda => 'S'));*/

  Cursor Cproctipoatendimento Is
  
    Select v.Cd_Protocolo_Ctamed,
           v.Nr_Numero_Carteira,
           v.Nr_Guia_Prestador,
           v.Nr_Senha_Autorizacao,
           v.Cd_Prestador,
           v.Nm_Beneficiario,
           v.Nr_Guia_Operadora,
           v.Cd_Tipo_Atendimento,
           v.Cd_Tipo_Internacao
      From Dbaps.v_Tiss_Lote_Guia v
     Where v.Cd_Protocolo_Ctamed = Pcd_Protocolo_Ctamed
       And (v.Cd_Procedimento = '20104065' And v.Cd_Tipo_Atendimento <> 13 Or
           (v.Cd_Procedimento = '20104065' And
           v.Cd_Tipo_Atendimento Is Null));

  Cursor Cguiaexternazerada Is
  
    Select v.Cd_Protocolo_Ctamed,
           v.Nr_Numero_Carteira,
           v.Nr_Guia_Prestador,
           v.Nr_Senha_Autorizacao,
           v.Cd_Prestador,
           v.Nm_Beneficiario,
           v.Nr_Guia_Operadora,
           v.Cd_Tipo_Atendimento,
           v.Cd_Tipo_Internacao
      From Dbaps.v_Tiss_Lote_Guia v
     Where v.Cd_Protocolo_Ctamed = Pcd_Protocolo_Ctamed
       And Length(v.Nr_Guia_Prestador) <= 9
       And Substr(v.Nr_Guia_Prestador, 1, 1) = '0';

  Cursor Ctipoatendimentoproc Is
  
    Select v.Cd_Protocolo_Ctamed,
           v.Nr_Numero_Carteira,
           v.Nr_Guia_Prestador,
           v.Nr_Senha_Autorizacao,
           v.Cd_Prestador,
           v.Nm_Beneficiario,
           v.Nr_Guia_Operadora,
           v.Cd_Tipo_Atendimento,
           v.Cd_Tipo_Internacao
      From v_Tiss_Lote_Guia v
     Where v.Cd_Protocolo_Ctamed = Pcd_Protocolo_Ctamed
          
     And Not Exists
  (Select 1
           From Dbaps.Guia g, Dbaps.Itguia It
          Where g.Nr_Guia = It.Nr_Guia
            And g.Nr_Guia = v.Nr_Guia_Operadora
            And It.Cd_Procedimento In ('20104243',
                                       '20104260',
                                       '20104278',
                                       '20104286',
                                       '20104294',
                                       '20104430',
                                       '20104308'))
 And v.Cd_Tipo_Atendimento IN('8','08');

  Cursor Cviaacesso Is
  
    Select v.Cd_Protocolo_Ctamed,
           v.Nr_Numero_Carteira,
           v.Nr_Guia_Prestador,
           v.Nr_Senha_Autorizacao,
           v.Cd_Prestador,
           v.Nm_Beneficiario,
           v.Nr_Guia_Operadora,
           v.Cd_Tipo_Atendimento,
           v.Cd_Procedimento
      From v_Tiss_Lote_Guia v
     Where v.Cd_Protocolo_Ctamed = Pcd_Protocolo_Ctamed
       And v.Cd_Procedimento = '41001133'
       And (v.Cd_Via_Acesso <> 1 Or v.Cd_Via_Acesso Is Null);

  Cursor Ccodigoguiaconsulta Is
    Select v.Cd_Protocolo_Ctamed,
           v.Nr_Numero_Carteira,
           v.Nr_Guia_Prestador,
           v.Nr_Senha_Autorizacao,
           v.Cd_Prestador,
           v.Nm_Beneficiario,
           v.Nr_Guia_Operadora,
           v.Cd_Tipo_Atendimento,
           v.Cd_Procedimento
      From v_Tiss_Lote_Guia v
     Where v.Cd_Protocolo_Ctamed = Pcd_Protocolo_Ctamed
       And v.Tp_Protocolo = 'CON'
       And v.Cd_Procedimento Not In ('10101012',
                                     '10101136',
                                     '10106014',
                                     '10106030',
                                     '10106049',
                                     '10106103',
                                     '10106146',
                                     '20101023',
                                     '20101074',
                                     '20101082',
                                     '20101090',
                                     '20101236',
                                     '50000055',
                                     '50000144',
                                     '50000462',
                                     '50000560',
                                     '50000586',
                                     '10101047',
                                     '10101057',
                                     '10101058');
  Cursor Ctipoatendimentotisscod Is
    Select v.Cd_Protocolo_Ctamed,
           v.Nr_Numero_Carteira,
           v.Nr_Guia_Prestador,
           v.Nr_Senha_Autorizacao,
           v.Cd_Prestador,
           v.Nm_Beneficiario,
           v.Nr_Guia_Operadora,
           v.Cd_Tipo_Atendimento,
           v.Cd_Tipo_Internacao,
           v.Cd_Procedimento
      From v_Tiss_Lote_Guia v
     Where v.Cd_Protocolo_Ctamed = Pcd_Protocolo_Ctamed
       And v.Cd_Tipo_Atendimento <> 22
       And v.Cd_Procedimento = '10101063';

  Cursor Cguiaexternaduplicada Is
    Select v.Cd_Protocolo_Ctamed,
           v.Nr_Numero_Carteira,
           v.Nr_Guia_Prestador,
           v.Nr_Senha_Autorizacao,
           v.Cd_Prestador,
           v.Nm_Beneficiario,
           v.Nr_Guia_Operadora,
           v.Cd_Tipo_Atendimento,
           v.Cd_Tipo_Internacao
      From Dbaps.v_Tiss_Lote_Guia v
     Where v.Cd_Tipo_Atendimento = 1
       And Exists
     (Select 1
              From Dbaps.Remessa_Prestador Rp
            
             Where Trim(Rp.Cd_Guia_Externa) = Trim(v.Nr_Guia_Operadora)
               And Rownum = 1
            Union All
            
            Select 1
              From Dbaps.Remessa_Prestador Rp
             Where Trim(Rp.Cd_Guia_Externa) = Trim(v.Nr_Guia_Prestador)
               And Rownum = 1)
       And v.Cd_Prestador <> 1001949 --CH2212-2482
       And v.Cd_Protocolo_Ctamed = Pcd_Protocolo_Ctamed
    
    Union All
    --Interna��o
    Select v.Cd_Protocolo_Ctamed,
           v.Nr_Numero_Carteira,
           v.Nr_Guia_Prestador,
           v.Nr_Senha_Autorizacao,
           v.Cd_Prestador,
           v.Nm_Beneficiario,
           v.Nr_Guia_Operadora,
           v.Cd_Tipo_Atendimento,
           v.Cd_Tipo_Internacao
      From Dbaps.v_Tiss_Lote_Guia v, Dbaps.Tiss_Lot_Guia_Fat_Resint Iod
     Where v.Cd_Protocolo_Ctamed = Pcd_Protocolo_Ctamed
       And Iod.Id = v.Id_Pai
       And Iod.Cd_Tipo_Faturamento <> 3
       And v.Cd_Prestador <> 1001949 --CH2212-2482
       And Exists
     (Select 1
              From Dbaps.Conta_Hospitalar c
             Where Trim(c.Cd_Guia_Externa) = Trim(v.Nr_Guia_Operadora)
               And c.Cd_Tipo_Faturamento <> 'C'
               And Rownum = 1
            Union All
            
            Select 1
              From Dbaps.Conta_Hospitalar c
             Where Trim(c.Cd_Guia_Externa) = Trim(v.Nr_Guia_Prestador)
               And c.Cd_Tipo_Faturamento <> 'C'
               And Rownum = 1)
    
    Union All --(SADT)
    
    Select v.Cd_Protocolo_Ctamed,
           v.Nr_Numero_Carteira,
           v.Nr_Guia_Prestador,
           v.Nr_Senha_Autorizacao,
           v.Cd_Prestador,
           v.Nm_Beneficiario,
           v.Nr_Guia_Operadora,
           v.Cd_Tipo_Atendimento,
           v.Cd_Tipo_Internacao
      From Dbaps.v_Tiss_Lote_Guia v
     Where v.Cd_Protocolo_Ctamed = Pcd_Protocolo_Ctamed
       And v.Cd_Tipo_Atendimento Not In (3, 8, 10)
       And v.Cd_Prestador <> 1001949 --CH2212-2482  
       And Exists
     (Select 1
              From Dbaps.Remessa_Prestador Rp, Itremessa_Prestador Ip
             Where Rp.Cd_Remessa = Ip.Cd_Remessa
               And Trim(Rp.Cd_Guia_Externa) = Trim(v.Nr_Guia_Prestador)
               And Nvl(Ip.Cd_Procedimento, Ip.Cd_Proc_Digita) =
                   v.Cd_Procedimento
               And To_Char(Ip.Qt_Cobrado) = v.Qt_Realizado
               And To_Char(Ip.Dt_Realizado, 'DD/MM/YYYY') =
                   Substr(v.Dt_Procedimento, 9, 9) || '/' ||
                   Substr(v.Dt_Procedimento, 6, 2) || '/' ||
                   Substr(v.Dt_Procedimento, 0, 4)
               And Rownum = 1
            Union All
            
            Select 1
              From Dbaps.Remessa_Prestador Rp, Itremessa_Prestador Ip
             Where Rp.Cd_Guia_Externa = Ip.Cd_Guia_Externa
                  
               And Trim(Rp.Cd_Guia_Externa) = Trim(v.Nr_Guia_Operadora)
               And Nvl(Ip.Cd_Procedimento, Ip.Cd_Proc_Digita) =
                   v.Cd_Procedimento
               And To_Char(Ip.Qt_Cobrado) = v.Qt_Realizado
               And To_Char(Ip.Dt_Realizado, 'DD/MM/YYYY') =
                   Substr(v.Dt_Procedimento, 9, 9) || '/' ||
                   Substr(v.Dt_Procedimento, 6, 2) || '/' ||
                   Substr(v.Dt_Procedimento, 0, 4)
               And Rownum = 1);

  Cursor Cdeclaracaonascidoouobtito Is
  
    Select v.Cd_Protocolo_Ctamed,
           v.Nr_Numero_Carteira,
           v.Nr_Guia_Prestador,
           v.Nr_Senha_Autorizacao,
           v.Cd_Prestador,
           v.Nm_Beneficiario,
           v.Nr_Guia_Operadora,
           v.Cd_Procedimento
      From Dbaps.Tiss_Lot_Guia_Fat_Resint_Decl d,
           Dbaps.Tiss_Lot_Guia_Fat_Resint      r,
           Dbaps.v_Tiss_Lote_Guia              v
     Where d.Id_Pai = r.Id
       And v.Id_Pai = r.Id
       And v.Cd_Protocolo_Ctamed = Pcd_Protocolo_Ctamed
       And (d.Ds_Declaracao_Obito Is Null And
           d.Nr_Declaracao_Nascido Is Null)
       And v.Cd_Procedimento In
           ('31309054', '31309097', '31309127', '31309135')
    
    Union All
    
    Select v.Cd_Protocolo_Ctamed,
           v.Nr_Numero_Carteira,
           v.Nr_Guia_Prestador,
           v.Nr_Senha_Autorizacao,
           v.Cd_Prestador,
           v.Nm_Beneficiario,
           v.Nr_Guia_Operadora,
           v.Cd_Procedimento
      From Dbaps.Tiss_Lot_Guia_Fat_Resint_Decl d,
           Dbaps.Tiss_Lot_Guia_Fat_Resint      r,
           Dbaps.v_Tiss_Lote_Guia              v
     Where d.Id_Pai = r.Id
       And v.Id_Pai = r.Id
       And v.Cd_Protocolo_Ctamed = Pcd_Protocolo_Ctamed
       And v.Cd_Procedimento In
           ('31309054', '31309097', '31309127', '31309135')
          
       And Length(Custom.Fnc_Ajusta_Numero(v_String => Trim(Nvl(d.Ds_Declaracao_Obito,
                                                                d.Nr_Declaracao_Nascido)))) > 11;

  Cursor Cdeclaracaoobito Is
  
    Select v.Cd_Protocolo_Ctamed,
           v.Nr_Numero_Carteira,
           v.Nr_Guia_Prestador,
           v.Nr_Senha_Autorizacao,
           v.Cd_Prestador,
           v.Nm_Beneficiario,
           v.Nr_Guia_Operadora,
           v.Cd_Procedimento
      From Dbaps.Tiss_Lot_Guia_Fat_Resint_Decl d,
           Dbaps.Tiss_Lot_Guia_Fat_Resint      r,
           Dbaps.v_Tiss_Lote_Guia              v
     Where d.Id_Pai = r.Id
       And v.Id_Pai = r.Id
       And v.Cd_Protocolo_Ctamed = Pcd_Protocolo_Ctamed
       And v.Cd_Motivo_Alta In (41, 65, 66, 67)
       And d.Ds_Declaracao_Obito Is Null
    
    Union All
    
    Select v.Cd_Protocolo_Ctamed,
           v.Nr_Numero_Carteira,
           v.Nr_Guia_Prestador,
           v.Nr_Senha_Autorizacao,
           v.Cd_Prestador,
           v.Nm_Beneficiario,
           v.Nr_Guia_Operadora,
           v.Cd_Procedimento
      From Dbaps.Tiss_Lot_Guia_Fat_Resint_Decl d,
           Dbaps.Tiss_Lot_Guia_Fat_Resint      r,
           Dbaps.v_Tiss_Lote_Guia              v
     Where d.Id_Pai = r.Id
       And v.Id_Pai = r.Id
       And v.Cd_Protocolo_Ctamed = Pcd_Protocolo_Ctamed
       And v.Cd_Motivo_Alta In (41, 65, 66, 67)
       And Length(Custom.Fnc_Ajusta_Numero(v_String => Trim(d.Ds_Declaracao_Obito))) > 11;

  Cursor Creducaoacrescimo Is
    Select v.Cd_Protocolo_Ctamed,
           v.Nr_Numero_Carteira,
           v.Nr_Guia_Prestador,
           v.Nr_Senha_Autorizacao,
           v.Cd_Prestador,
           v.Nm_Beneficiario,
           v.Nr_Guia_Operadora
      From v_Tiss_Lote_Guia v
     Where v.Cd_Protocolo_Ctamed = Pcd_Protocolo_Ctamed
       And v.Cd_Prestador <> '300011' --CH2304-2284
       And Exists
     (Select 1
              From Dbaps.Procedimento p, Dbaps.Grupo_Procedimento Gp
             Where p.Cd_Grupo_Procedimento = Gp.Cd_Grupo_Procedimento
               And p.Cd_Procedimento = v.Cd_Procedimento
               And Gp.Tp_Gru_Pro In ('SP', 'SD'))
       And (v.Vl_Perc_Reducao_Acrescimo Not In
           ('0.30',
             '0.20',
             '020',
             '030',
             '0.50',
             '0.70',
             '0.80',
             '100',
             '1.00',
             '130',
             '1.30',
             '160',
             '1.60') Or v.Vl_Perc_Reducao_Acrescimo Is Null Or Exists
            (Select 1
               From Dbaps.Tiss_Lot_Guia_Fat_Resint_Proc Tlf,
                    Dbaps.Tiss_Lot_Guia_Fat_Resint_Eqp  Eqi
              Where v.Id = Tlf.Id
                And Tlf.Id = Eqi.Id_Pai
                And Eqi.Cd_Posicao_Profissional Not In ('01', '1')
                And v.Vl_Perc_Reducao_Acrescimo In
                    ('0.30', '030', '0.20', '020')
             
             Union All
             
             Select 1
               From Dbaps.Tiss_Lot_Guia_Fat_Sadt_Proc Tlf,
                    Dbaps.Tiss_Lot_Guia_Fat_Sadt_Eqp  Eqs
              Where v.Id = Tlf.Id
                And Tlf.Id = Eqs.Id_Pai
                And Eqs.Cd_Posicao_Profissional Not In ('01', '1')
                And v.Vl_Perc_Reducao_Acrescimo In
                    ('0.30', '030', '0.20', '020')
             
             Union All
             
             Select 1
               From Dbaps.Tiss_Lot_Guia_Fat_Hono_Proc Tlf,
                    Dbaps.Tiss_Lot_Guia_Fat_Hono_Eqp  Eqh
              Where v.Id = Tlf.Id
                And Tlf.Id = Eqh.Id_Pai
                And Eqh.Cd_Grau_Part Not In ('01', '1')
                And v.Vl_Perc_Reducao_Acrescimo In
                    ('0.30', '030', '0.20', '020')
             
             )
           
           )
    
    Union All ---MD, MT, OP, DI
    
    Select v.Cd_Protocolo_Ctamed,
           v.Nr_Numero_Carteira,
           v.Nr_Guia_Prestador,
           v.Nr_Senha_Autorizacao,
           v.Cd_Prestador,
           v.Nm_Beneficiario,
           v.Nr_Guia_Operadora
      From v_Tiss_Lote_Guia v
     Where v.Cd_Protocolo_Ctamed = Pcd_Protocolo_Ctamed
          
       And Exists
     (Select 1
              From Dbaps.Procedimento p, Dbaps.Grupo_Procedimento Gp
             Where p.Cd_Grupo_Procedimento = Gp.Cd_Grupo_Procedimento
               And p.Cd_Procedimento = v.Cd_Procedimento
               And Gp.Tp_Gru_Pro In ('MD', 'MT', 'OP', 'DI'))
       And (v.Vl_Perc_Reducao_Acrescimo Not In ('100', '1.00') Or
           v.Vl_Perc_Reducao_Acrescimo Is Null)
    
    Union All
    
    --TX
    Select v.Cd_Protocolo_Ctamed,
           v.Nr_Numero_Carteira,
           v.Nr_Guia_Prestador,
           v.Nr_Senha_Autorizacao,
           v.Cd_Prestador,
           v.Nm_Beneficiario,
           v.Nr_Guia_Operadora
      From v_Tiss_Lote_Guia v
     Where v.Cd_Protocolo_Ctamed = Pcd_Protocolo_Ctamed
          
       And Exists
     (Select 1
              From Dbaps.Procedimento p, Dbaps.Grupo_Procedimento Gp
             Where p.Cd_Grupo_Procedimento = Gp.Cd_Grupo_Procedimento
               And p.Cd_Procedimento = v.Cd_Procedimento
               And Gp.Tp_Gru_Pro = 'TX')
       And (v.Vl_Perc_Reducao_Acrescimo Not In
           ('100', '1.00', '050', '0.50') Or
           v.Vl_Perc_Reducao_Acrescimo Is Null);

  Cursor Cvalidaguiaprincipalsadt Is
    Select v.Cd_Protocolo_Ctamed,
           v.Nr_Numero_Carteira,
           v.Nr_Guia_Prestador,
           v.Nr_Senha_Autorizacao,
           v.Cd_Prestador,
           v.Nm_Beneficiario,
           v.Nr_Guia_Operadora
      From v_Tiss_Lote_Guia v
     Where 1 = 1
       And Not Exists (Select 1
              From Dbaps.Tiss_Lot_Guia_Fat_Resint r
             Where v.Id_Pai = r.Id) -- n�o � uma interna��o ent�o trava
       And v.Cd_Protocolo_Ctamed = Pcd_Protocolo_Ctamed
       And v.Nr_Guia_Principal Is Not Null;

  -- Declara��o de Vari�veis
  Cparametros                   Tparametros;
  Rvtissloteguia                Cvtissloteguia%Rowtype;
  Rprotocoloctamed              Cprotocoloctamed%Rowtype;
  Ccdprocedimento               Dbaps.Procedimento.Cd_Procedimento%Type;
  Cdsprocedimento               Dbaps.Procedimento.Ds_Procedimento%Type;
  Rverificaprocedimento         Cverificaprocedimento%Rowtype;
  Rmvsconfiguracao              Cmvsconfiguracao%Rowtype;
  Vverificaconsultaps           Cverificaconsultaps%Rowtype;
  Vtipointernacao               Ctipointernacao%Rowtype;
  Vguiasduplicadas              Cguiasduplicadas%Rowtype;
  Vcodigoinexistente            Ccodigoinexistente%Rowtype;
  Vguiavencida                  Cguiavencida%Rowtype;
  Vvalidacarteira               Cvalidacarteira%Rowtype;
  Vdadosprocprestador           Cdadosprocprestador%Rowtype;
  Vprazoexcecidoportal          Cprazoexcecidoportal%Rowtype;
  Vlimitetaxa                   Climitetaxa%Rowtype;
  Vguiaexecucao70dias           Cguiaexecucao70dias%Rowtype;
  Vobrigagrauparticipacao       Cobrigagrauparticipacao%Rowtype;
  Vprestadorexistenaoperadora   Cprestadorexistenaoperadora%Rowtype;
  Vc_Guia_Prestador_Valor_0     c_Guia_Prestador_Valor_0%Rowtype;
  Vc_Guia_Interna_Como_Externa  c_Guia_Interna_Como_Externa%Rowtype;
  Vc_Dt_Realizado_Is_Null       c_Dt_Realizado_Is_Null%Rowtype;
  Vguiainexistente              Cguiainexistente%Rowtype;
  Vcodracionalizacaosemautoriza Ccodracionalizacaosemautoriza%Rowtype;
  Vobrigaprestadorspsd          Cobrigaprestadorspsd%Rowtype;
  Vproctipoatendimento          Cproctipoatendimento%Rowtype;
  Vguiaexternazerada            Cguiaexternazerada%Rowtype;
  Vtipoatendimentoproc          Ctipoatendimentoproc%Rowtype;
  Vviaacesso                    Cviaacesso%Rowtype;
  Vcodigoguiaconsulta           Ccodigoguiaconsulta%Rowtype;
  Vtipoatendimentotisscod       Ctipoatendimentotisscod%Rowtype;
  Vguiaexternaduplicada         Cguiaexternaduplicada%Rowtype;
  Vdeclaracaonascidoouobtito    Cdeclaracaonascidoouobtito%Rowtype;
  Vdeclaracaoobito              Cdeclaracaoobito%Rowtype;
  Vreducaoacrescimo             Creducaoacrescimo%Rowtype;
  Vvalidaguiaprincipalsadt      Cvalidaguiaprincipalsadt%Rowtype;

  --Variaveis de auxilio
  Vcoderro              Varchar2(10);
  Vretorno_Unidade      Varchar2(5000);
  Vretorno_Procedimento Varchar2(5000);
  Nqtderrostotal        Number;
  Nqtderrostotal2       Number;
  Nqtderros             Number;
  Vexcecao              Varchar2(1000);
  Vexcecaolinha         Varchar2(1000);
  Vdatavencimento       Varchar2(30) := '';
  Vcarteirautilizada    Varchar2(30) := '';
  --Vquantidadeultrapassada Cquantidadeultrapassada%Rowtype;
  --
  --
  Procedure Prc_Insere_Log_Erro(p_Numero_Carteira       In Varchar2,
                                p_Numero_Guia_Prestador In Varchar2,
                                p_Numero_Guia_Operadora In Varchar2,
                                p_Numero_Senha          In Varchar2,
                                p_Codigo_Prestador      In Varchar2,
                                p_Nm_Beneficiario       In Varchar2,
                                p_Node_Xml              In Varchar2,
                                p_Node_Xml_Sub          In Varchar2,
                                p_Ds_Erro               In Varchar2,
                                p_Cd_Erro               In Varchar2,
                                p_Tp_Erro               In Varchar2,
                                p_Sn_Guia_Web           In Varchar2 Default 'N',
                                p_Procedimento          In Varchar2 Default Null) Is
    Binsereerro Boolean;
    Nteste      Number;
    Vdescricao  Varchar2(6000 Char) := p_Ds_Erro;
  Begin
    -- G -> ERRO DE GUIA - APENAS UMA OCORRENCIA
    -- I -> ERRO DE ITEM DE GUIA - VARIAS OCORRENCIAS
    Binsereerro := True;
    Nteste      := Null;
    /*
     - String de apresenta��o para o PDF do PORTAL.:
    '[G001] - SENHA: XXXXXXXXX - GUIA PRESTADOR: XXXXXXXXX - Descri��o do Problema.';
    '[P001] - SENHA: XXXXXXXXX - GUIA PRESTADOR: XXXXXXXXX - PROCEDIMENTO - Descri��o do Problema.';
     - Para o autorizador a string ser� simples!
    '[G001 ou P001] - Descri��o do Problema.';
    */
    If (Pcd_Lote_Autweb Is Not Null) Then
      Vdescricao := p_Cd_Erro || ': ' || p_Ds_Erro;
    Else
      If (p_Tp_Erro = 'G') Then
        Vdescricao := Vdescricao;
      Else
        Vdescricao := p_Ds_Erro;
      End If;
    End If;
    If p_Tp_Erro = 'G' Then
      Open Cexisteerro(p_Cd_Erro,
                       Pcd_Protocolo_Ctamed,
                       p_Numero_Guia_Prestador);
      Fetch Cexisteerro
        Into Nteste;
      If Cexisteerro%Found Then
        Binsereerro := False;
      End If;
      Close Cexisteerro;
    End If;
  
    If Binsereerro Then
      Insert Into Dbaps.Log_Erro_Protocolo_Tiss
        (Cd_Log_Erro_Protocolo_Tiss,
         Cd_Protocolo_Ctamed,
         Ds_Carteira_Beneficiario,
         Ds_Guia_Prestador,
         Ds_Guia_Operadora,
         Ds_Codigo_Prestador,
         Nm_Beneficiario,
         Ds_Tipo_Guia,
         Ds_Node_Xml,
         Ds_Node_Xml_Sub,
         Ds_Erro,
         Cd_Erro)
      Values
        (Dbaps.Seq_Mvs_Log_Erro_Proto_Tiss.Nextval,
         Pcd_Protocolo_Ctamed,
         p_Numero_Carteira,
         p_Numero_Guia_Prestador,
         p_Numero_Guia_Operadora,
         p_Codigo_Prestador,
         p_Nm_Beneficiario,
         'IOD',
         p_Node_Xml,
         p_Node_Xml_Sub,
         Substr(Vdescricao, 0, 100),
         Substr(p_Cd_Erro, 0, 100));
    End If;
  End;

Begin
  Nqtderrostotal := 0;
  Nqtderros      := 0;
  -- REMOVENDO LOG ANTIGO
  If Pcd_Protocolo_Ctamed Is Not Null Then
    Delete From Dbaps.Log_Erro_Protocolo_Tiss
     Where Cd_Protocolo_Ctamed = Pcd_Protocolo_Ctamed;
  End If;

  Commit;

  Rprotocoloctamed := Null;
  Open Cprotocoloctamed(Pcd_Protocolo_Ctamed);
  Fetch Cprotocoloctamed
    Into Rprotocoloctamed;
  Close Cprotocoloctamed;

  --
  --****************************
  --* CURSOR DO CABE�ALHO DO PROTOCOLO
  --****************************
  --
  Open Cvtissloteguia(Pcd_Protocolo_Ctamed);
  Loop
    Fetch Cvtissloteguia
      Into Rvtissloteguia;
  
    If (Custom.Pkg_Conmvs_Tiss_Xml.Fnc_Motivo_Portal(Pcd_Motivo       => 'US001',
                                                     p_Sn_Portal_Tiss => 'S') = 'S') Then
      Begin
        --EXCEPTION DE GUIA
        If Cvtissloteguia%Notfound Then
          Exit;
        End If;
      
        -- if rVTissLoteGuia.Cd_Prestador = 1001153 then
      
        --Verifica se a unidade de medida esta correta
        --Verifica se procediemnto esta inativo
        Select To_Char(Dbaps.Fnc_Verifica_Procedimento_Tes1(Rvtissloteguia.Cd_Protocolo_Ctamed,
                                                            Rvtissloteguia.Nr_Guia_Operadora,
                                                            Rvtissloteguia.Cd_Procedimento))
          Into Vretorno_Procedimento
          From Dual;
      
        Select To_Char(Dbaps.Fnc_Retorna_Unidade_Med_Tes1(Rvtissloteguia.Cd_Protocolo_Ctamed,
                                                          Rvtissloteguia.Nr_Guia_Operadora,
                                                          Rvtissloteguia.Cd_Procedimento))
          Into Vretorno_Unidade
          From Dual;
      
        If ((Upper(Vretorno_Procedimento) <> 'OK' And
           Upper(Vretorno_Unidade) = 'OK') Or
           (Upper(Vretorno_Procedimento) <> 'OK' And
           Upper(Vretorno_Unidade) <> 'OK')) Then
        
          Nqtderros := Nqtderros + 1;
          Vcoderro  := 'US001';
          Prc_Insere_Log_Erro(Rvtissloteguia.Nr_Numero_Carteira,
                              Rvtissloteguia.Nr_Guia_Prestador,
                              Rvtissloteguia.Nr_Guia_Operadora,
                              Rvtissloteguia.Nr_Senha_Autorizacao,
                              Rvtissloteguia.Cd_Prestador,
                              Rvtissloteguia.Nm_Beneficiario,
                              --'',
                              '',
                              '',
                              'PROCEDIMENTO INATIVO: ( ' ||
                              Substr(Vretorno_Procedimento, 0, 1900) || ' )',
                              -- Lpad(Vretorno_Procedimento, 1900) || ')',
                              'US001',
                              'I',
                              'N');
        
        Elsif (Upper(Vretorno_Procedimento) = 'OK' And
              Upper(Vretorno_Unidade) <> 'OK') Then
          Nqtderros := Nqtderros + 1;
          Vcoderro  := 'US001';
          Prc_Insere_Log_Erro(Rvtissloteguia.Nr_Numero_Carteira,
                              Rvtissloteguia.Nr_Guia_Prestador,
                              Rvtissloteguia.Nr_Guia_Operadora,
                              Rvtissloteguia.Nr_Senha_Autorizacao,
                              Rvtissloteguia.Cd_Prestador,
                              Rvtissloteguia.Nm_Beneficiario,
                              
                              '',
                              '',
                              'UNIDADE DE MEDIDA INCORRETA: ( ' ||
                              Substr(Vretorno_Unidade, 0, 1950) || ' )',
                              -- Lpad(Vretorno_Unidade, 1900) || ')',
                              'US001',
                              'I',
                              'N');
        
        End If;
        Commit;
      
        --EXCEPTION A NIVEL DE GUIA PARA PROIBIR TODAS EM CASO DE PROBLEMA NO BANCO
      Exception
        When Others Then
          Vexcecao      := Sqlerrm;
          Vexcecaolinha := Dbms_Utility.Format_Error_Backtrace;
          Vcoderro      := 'E999';
          Prc_Insere_Log_Erro(Rvtissloteguia.Nr_Numero_Carteira,
                              Rvtissloteguia.Nr_Guia_Prestador,
                              Rvtissloteguia.Nr_Guia_Operadora,
                              Rvtissloteguia.Nr_Senha_Autorizacao,
                              Rvtissloteguia.Cd_Prestador,
                              Rvtissloteguia.Nm_Beneficiario,
                              '',
                              '',
                              '',
                              'EXCEPTION-GUIA! N�o foi possivel validar as regras. Favor entre em contato com a Operadora MSG: ' ||
                              Vexcecao || ' linha do erro: ' ||
                              Vexcecaolinha,
                              Vcoderro,
                              'E',
                              'N');
          Commit;
      End; --EXCEPTION DE GUIA   
    End If;
    Nqtderrostotal := Nqtderrostotal + Nqtderros;
  End Loop;
  -- FIM DO LOOP DE GUIAS
  Close Cvtissloteguia;
  --nQtdErrosTotal := nQtdErrosTotal + nQtdErros;

  --Mois�s 25/03/2022 --> (CH2203-0567) N�o permitir a postagem de arquivo com consulta 10101039 COM o CD_TIPO_ATENDIMENTO_TISS <>11
  If (Custom.Pkg_Conmvs_Tiss_Xml.Fnc_Motivo_Portal(Pcd_Motivo       => 'US002',
                                                   p_Sn_Portal_Tiss => 'S') = 'S') Then
  
    Begin
      For Vverificaconsultaps In Cverificaconsultaps Loop
      
        Begin
        
          Prc_Insere_Log_Erro(Vverificaconsultaps.Nr_Numero_Carteira,
                              Vverificaconsultaps.Nr_Guia_Prestador,
                              Vverificaconsultaps.Nr_Guia_Operadora,
                              Vverificaconsultaps.Nr_Senha_Autorizacao,
                              Vverificaconsultaps.Cd_Prestador,
                              Vverificaconsultaps.Nm_Beneficiario,
                              
                              '',
                              '',
                              'Conforme o padr�o TISS para procedimento de Consulta de Pronto Socorro �
                             necess�rio informar o CD_ATENDIMENTO_TISS no valor 11. Guia: ' ||
                              Vverificaconsultaps.Nr_Guia_Operadora ||
                              ' Tipo de atendimento Tiss: ' ||
                              Vverificaconsultaps.Cd_Tipo_Atendimento,
                              'US002',
                              'I',
                              'N');
        
        End;
      End Loop;
      Commit;
    
    Exception
      When Others Then
        Dbms_Output.Put_Line('exception-gral');
        Vexcecao      := Sqlerrm;
        Vexcecaolinha := Dbms_Utility.Format_Error_Backtrace;
        Vcoderro      := 'E999';
        Prc_Insere_Log_Erro(Vverificaconsultaps.Nr_Numero_Carteira,
                            Vverificaconsultaps.Nr_Guia_Prestador,
                            Vverificaconsultaps.Nr_Guia_Operadora,
                            Vverificaconsultaps.Nr_Senha_Autorizacao,
                            Vverificaconsultaps.Cd_Prestador,
                            Vverificaconsultaps.Nm_Beneficiario,
                            '',
                            '',
                            '',
                            'EXCEPTION-GLOBAL! N�o foi possivel validar as regras --> US002. Favor entre em contato com a Operadora MSG: ' ||
                            Vexcecao || ' linha do erro: ' || Vexcecaolinha,
                            Vcoderro,
                            'E',
                            'N');
        Commit;
        If (Cverificaconsultaps%Isopen) Then
          Close Cverificaconsultaps;
        End If;
    End;
  
  End If;

  -- Mois�s --> 12/04/2022 atender ao requisito do manual do PTU XML --> CH2202-2485 (travar quando for guia de interna��o, conter os procedimento
  --31309038, 31309054, 31309097, 31309127 e 31309135, e n�o tiver o CD_TIPO_INTERNACAO = 3.
  If (Custom.Pkg_Conmvs_Tiss_Xml.Fnc_Motivo_Portal(Pcd_Motivo       => 'US003',
                                                   p_Sn_Portal_Tiss => 'S') = 'S') Then
    Begin
      For Vtipointernacao In Ctipointernacao Loop
      
        Begin
          Prc_Insere_Log_Erro(Vtipointernacao.Nr_Numero_Carteira,
                              Vtipointernacao.Nr_Guia_Prestador,
                              Vtipointernacao.Nr_Guia_Operadora,
                              Vtipointernacao.Nr_Senha_Autorizacao,
                              Vtipointernacao.Cd_Prestador,
                              Vtipointernacao.Nm_Beneficiario,
                              
                              '',
                              '',
                              'TIPO DE INTERNA��O INV�LIDO: ' ||
                              Vverificaconsultaps.Nr_Guia_Operadora,
                              'US003',
                              'I',
                              'N');
        
        End;
      End Loop;
      Commit;
    
    Exception
      When Others Then
        Dbms_Output.Put_Line('exception-gral');
        Vexcecao      := Sqlerrm;
        Vexcecaolinha := Dbms_Utility.Format_Error_Backtrace;
        Vcoderro      := 'E999';
        Prc_Insere_Log_Erro(Vtipointernacao.Nr_Numero_Carteira,
                            Vtipointernacao.Nr_Guia_Prestador,
                            Vtipointernacao.Nr_Guia_Operadora,
                            Vtipointernacao.Nr_Senha_Autorizacao,
                            Vtipointernacao.Cd_Prestador,
                            Vtipointernacao.Nm_Beneficiario,
                            '',
                            '',
                            '',
                            'EXCEPTION-GLOBAL! N�o foi possivel validar as regras --> US003. Favor entre em contato com a Operadora MSG: ' ||
                            Vexcecao || ' linha do erro: ' || Vexcecaolinha,
                            Vcoderro,
                            'E',
                            'N');
        Commit;
        If (Ctipointernacao%Isopen) Then
          Close Ctipointernacao;
        End If;
    End;
  End If;

  --Guias Duplicadas (portal tiss)
  If (Custom.Pkg_Conmvs_Tiss_Xml.Fnc_Motivo_Portal(Pcd_Motivo       => 'US004',
                                                   p_Sn_Portal_Tiss => 'S') = 'S') Then
    Begin
      For Vguiasduplicadas In Cguiasduplicadas Loop
      
        Begin
        
          Prc_Insere_Log_Erro(Vguiasduplicadas.Nr_Numero_Carteira,
                              Vguiasduplicadas.Nr_Guia_Prestador,
                              Vguiasduplicadas.Nr_Guia_Operadora,
                              Vguiasduplicadas.Nr_Senha_Autorizacao,
                              Vguiasduplicadas.Cd_Prestador,
                              Vguiasduplicadas.Nm_Beneficiario,
                              
                              '',
                              '',
                              'Duplicidade de Guias: ' ||
                              Vguiasduplicadas.Nr_Guia_Operadora,
                              'US004',
                              'I',
                              'N');
        
        End;
      End Loop;
      Commit;
    
    Exception
      When Others Then
        Dbms_Output.Put_Line('exception-gral');
        Vexcecao      := Sqlerrm;
        Vexcecaolinha := Dbms_Utility.Format_Error_Backtrace;
        Vcoderro      := 'E999';
        Prc_Insere_Log_Erro(Vguiasduplicadas.Nr_Numero_Carteira,
                            Vguiasduplicadas.Nr_Guia_Prestador,
                            Vguiasduplicadas.Nr_Guia_Operadora,
                            Vguiasduplicadas.Nr_Senha_Autorizacao,
                            Vguiasduplicadas.Cd_Prestador,
                            Vguiasduplicadas.Nm_Beneficiario,
                            '',
                            '',
                            'EXCEPTION-GLOBAL! N�o foi possivel validar as regras --> US004. Favor entre em contato com a Operadora MSG: ' ||
                            Vexcecao || ' linha do erro: ' || Vexcecaolinha,
                            Vcoderro,
                            'E',
                            'N');
        Commit;
        If (Cguiasduplicadas%Isopen) Then
          Close Cguiasduplicadas;
        End If;
    End;
  End If;
  --C�digo Inexistente
  If (Custom.Pkg_Conmvs_Tiss_Xml.Fnc_Motivo_Portal(Pcd_Motivo       => 'US005',
                                                   p_Sn_Portal_Tiss => 'S') = 'S') Then
    Begin
      For Vcodigoinexistente In Ccodigoinexistente Loop
      
        Begin
        
          Prc_Insere_Log_Erro(Vcodigoinexistente.Nr_Numero_Carteira,
                              Vcodigoinexistente.Nr_Guia_Prestador,
                              Vcodigoinexistente.Nr_Guia_Operadora,
                              Vcodigoinexistente.Nr_Senha_Autorizacao,
                              Vcodigoinexistente.Cd_Prestador,
                              Vcodigoinexistente.Nm_Beneficiario,
                              
                              '',
                              '',
                              'C�digo Inexistente na Operadora: ' ||
                              Vcodigoinexistente.Cd_Procedimento,
                              'US005',
                              'I',
                              'N');
        
          Commit;
        End;
      End Loop;
    
    Exception
      When Others Then
        Dbms_Output.Put_Line('exception-gral');
        Vexcecao      := Sqlerrm;
        Vexcecaolinha := Dbms_Utility.Format_Error_Backtrace;
        Vcoderro      := 'E999';
        Prc_Insere_Log_Erro(Vcodigoinexistente.Nr_Numero_Carteira,
                            Vcodigoinexistente.Nr_Guia_Prestador,
                            Vcodigoinexistente.Nr_Guia_Operadora,
                            Vcodigoinexistente.Nr_Senha_Autorizacao,
                            Vcodigoinexistente.Cd_Prestador,
                            Vcodigoinexistente.Nm_Beneficiario,
                            '',
                            '',
                            'EXCEPTION-GLOBAL! N�o foi possivel validar as regras --> US005. Favor entre em contato com a Operadora MSG: ' ||
                            Vexcecao || ' linha do erro: ' || Vexcecaolinha,
                            Vcoderro,
                            'E',
                            'N');
        Commit;
        If (Ccodigoinexistente%Isopen) Then
          Close Ccodigoinexistente;
        End If;
    End;
  
  End If;

  --Guia Vencida            

  If (Custom.Pkg_Conmvs_Tiss_Xml.Fnc_Motivo_Portal(Pcd_Motivo       => 'US006',
                                                   p_Sn_Portal_Tiss => 'S') = 'S') Then
    Begin
      For Vguiavencida In Cguiavencida Loop
      
        Begin
        
          Begin
            Select g.Dt_Vencimento
              Into Vdatavencimento
              From Dbaps.Guia g
             Where g.Nr_Guia =
                   Nvl(Vguiavencida.Nr_Guia_Operadora,
                       Vguiavencida.Nr_Guia_Prestador);
          
          Exception
            When Others Then
              Null;
          End;
        
          Prc_Insere_Log_Erro(Vguiavencida.Nr_Numero_Carteira,
                              Vguiavencida.Nr_Guia_Prestador,
                              Vguiavencida.Nr_Guia_Operadora,
                              Vguiavencida.Nr_Senha_Autorizacao,
                              Vguiavencida.Cd_Prestador,
                              Vguiavencida.Nm_Beneficiario,
                              
                              '',
                              '',
                              'Guia Vencida: ' ||
                              Nvl(Vguiavencida.Nr_Guia_Operadora,
                                  Vguiavencida.Nr_Guia_Prestador) ||
                              ' Na data de: ' || Vdatavencimento,
                              'US006',
                              'I',
                              'N');
        
          Commit;
        End;
      End Loop;
    
    Exception
      When Others Then
        Dbms_Output.Put_Line('exception-gral');
        Vexcecao      := Sqlerrm;
        Vexcecaolinha := Dbms_Utility.Format_Error_Backtrace;
        Vcoderro      := 'E999';
        Prc_Insere_Log_Erro(Vguiavencida.Nr_Numero_Carteira,
                            Vguiavencida.Nr_Guia_Prestador,
                            Vguiavencida.Nr_Guia_Operadora,
                            Vguiavencida.Nr_Senha_Autorizacao,
                            Vguiavencida.Cd_Prestador,
                            Vguiavencida.Nm_Beneficiario,
                            '',
                            '',
                            'EXCEPTION-GLOBAL! N�o foi possivel validar as regras --> US006. Favor entre em contato com a Operadora MSG: ' ||
                            Vexcecao || ' linha do erro: ' || Vexcecaolinha,
                            Vcoderro,
                            'E',
                            'N');
        Commit;
        If (Cguiavencida%Isopen) Then
          Close Cguiavencida;
        End If;
    End;
  End If;

  -- Carteira diferente da autoriza��o 

  If (Custom.Pkg_Conmvs_Tiss_Xml.Fnc_Motivo_Portal(Pcd_Motivo       => 'US007',
                                                   p_Sn_Portal_Tiss => 'S') = 'S') Then
  
    Begin
      For Vvalidacarteira In Cvalidacarteira Loop
      
        Begin
          Begin
            Select Coalesce(g.Nr_Carteira_Beneficiario,
                            g.Nr_Carteira_Utilizada,
                            g.Ds_Destino_Cortesia)
              Into Vcarteirautilizada
              From Dbaps.Guia g
             Where g.Nr_Guia =
                   Nvl(Vvalidacarteira.Nr_Guia_Operadora,
                       Vvalidacarteira.Nr_Guia_Prestador);
          
          Exception
            When Others Then
              Vcarteirautilizada := Vvalidacarteira.Nr_Numero_Carteira;
          End;
        
          Prc_Insere_Log_Erro(Vvalidacarteira.Nr_Numero_Carteira,
                              Vvalidacarteira.Nr_Guia_Prestador,
                              Vvalidacarteira.Nr_Guia_Operadora,
                              Vvalidacarteira.Nr_Senha_Autorizacao,
                              Vvalidacarteira.Cd_Prestador,
                              Vvalidacarteira.Nm_Beneficiario,
                              
                              '',
                              '',
                              'Carteira diferente da Autorizada: ' ||
                              Vcarteirautilizada,
                              'US007',
                              'I',
                              'N');
        
          Commit;
        End;
      End Loop;
    
    Exception
      When Others Then
        Dbms_Output.Put_Line('exception-gral');
        Vexcecao      := Sqlerrm;
        Vexcecaolinha := Dbms_Utility.Format_Error_Backtrace;
        Vcoderro      := 'E999';
        Prc_Insere_Log_Erro(Vvalidacarteira.Nr_Numero_Carteira,
                            Vvalidacarteira.Nr_Guia_Prestador,
                            Vvalidacarteira.Nr_Guia_Operadora,
                            Vvalidacarteira.Nr_Senha_Autorizacao,
                            Vvalidacarteira.Cd_Prestador,
                            Vvalidacarteira.Nm_Beneficiario,
                            '',
                            '',
                            'EXCEPTION-GLOBAL! N�o foi possivel validar as regras --> US007. Favor entre em contato com a Operadora MSG: ' ||
                            Vexcecao || ' linha do erro: ' || Vexcecaolinha,
                            Vcoderro,
                            'E',
                            'N');
        Commit;
        If (Cvalidacarteira%Isopen) Then
          Close Cvalidacarteira;
        End If;
    End;
  
  End If;

  --Sem prestador e com servi�o parametrizado para conter cd_prestador
  If (Custom.Pkg_Conmvs_Tiss_Xml.Fnc_Motivo_Portal(Pcd_Motivo       => 'US008',
                                                   p_Sn_Portal_Tiss => 'S') = 'S') Then
    Begin
      For Vdadosprocprestador In Cdadosprocprestador Loop
      
        Prc_Insere_Log_Erro(Vdadosprocprestador.Nr_Numero_Carteira,
                            Vdadosprocprestador.Nr_Guia_Prestador,
                            Vdadosprocprestador.Nr_Guia_Operadora,
                            Vdadosprocprestador.Nr_Senha_Autorizacao,
                            Vdadosprocprestador.Cd_Prestador,
                            Vdadosprocprestador.Nm_Beneficiario,
                            
                            '',
                            '',
                            'Campo de Prestador obrigat�rio para procedimentos do grupo (Servi�os Profissionais): ' ||
                            Vdadosprocprestador.Cd_Procedimento,
                            'US008',
                            'I',
                            'N');
      
        Commit;
      
      End Loop;
    
    Exception
      When Others Then
        Dbms_Output.Put_Line('exception-gral');
        Vexcecao      := Sqlerrm;
        Vexcecaolinha := Dbms_Utility.Format_Error_Backtrace;
        Vcoderro      := 'E999';
        Prc_Insere_Log_Erro(Vdadosprocprestador.Nr_Numero_Carteira,
                            Vdadosprocprestador.Nr_Guia_Prestador,
                            Vdadosprocprestador.Nr_Guia_Operadora,
                            Vdadosprocprestador.Nr_Senha_Autorizacao,
                            Vdadosprocprestador.Cd_Prestador,
                            Vdadosprocprestador.Nm_Beneficiario,
                            '',
                            '',
                            'EXCEPTION-GLOBAL! N�o foi possivel validar as regras --> US008. Favor entre em contato com a Operadora MSG: ' ||
                            Vexcecao || ' linha do erro: ' || Vexcecaolinha,
                            Vcoderro,
                            'E',
                            'N');
        Commit;
        If (Cdadosprocprestador%Isopen) Then
          Close Cdadosprocprestador;
        End If;
    End;
  End If;

  --inicio  verifica se existe procedimento sem data informada     

  If (Custom.Pkg_Conmvs_Tiss_Xml.Fnc_Motivo_Portal(Pcd_Motivo       => 'US019',
                                                   p_Sn_Portal_Tiss => 'S') = 'S') Then
    Begin
      For Vc_Dt_Realizado_Is_Null In c_Dt_Realizado_Is_Null Loop
      
        Prc_Insere_Log_Erro(Vc_Dt_Realizado_Is_Null.Nr_Numero_Carteira,
                            Vc_Dt_Realizado_Is_Null.Nr_Guia_Prestador,
                            Vc_Dt_Realizado_Is_Null.Nr_Guia_Operadora,
                            Vc_Dt_Realizado_Is_Null.Nr_Senha_Autorizacao,
                            Vc_Dt_Realizado_Is_Null.Cd_Prestador,
                            Vc_Dt_Realizado_Is_Null.Nm_Beneficiario,
                            
                            '',
                            '',
                            'Nao e permitido envio de procedimento sem data de realizacao informada.',
                            'US019',
                            'I',
                            'N');
      
        Commit;
      
      End Loop;
    
    Exception
      When Others Then
        Dbms_Output.Put_Line('exception-gral');
        Vexcecao      := Sqlerrm;
        Vexcecaolinha := Dbms_Utility.Format_Error_Backtrace;
        Vcoderro      := 'E999';
        Prc_Insere_Log_Erro(Vc_Dt_Realizado_Is_Null.Nr_Numero_Carteira,
                            Vc_Dt_Realizado_Is_Null.Nr_Guia_Prestador,
                            Vc_Dt_Realizado_Is_Null.Nr_Guia_Operadora,
                            Vc_Dt_Realizado_Is_Null.Nr_Senha_Autorizacao,
                            Vc_Dt_Realizado_Is_Null.Cd_Prestador,
                            Vc_Dt_Realizado_Is_Null.Nm_Beneficiario,
                            '',
                            '',
                            'EXCEPTION-GLOBAL! N�o foi possivel validar as regras --> US019. Favor entre em contato com a Operadora MSG: ' ||
                            Vexcecao || ' linha do erro: ' || Vexcecaolinha,
                            Vcoderro,
                            'E',
                            'N');
        Commit;
        If (c_Dt_Realizado_Is_Null%Isopen) Then
          Close c_Dt_Realizado_Is_Null;
        End If;
    End;
  
  End If;

  --inicio  verifica se existe procedimento sem data informada

  --PRAZO LIMITE DO PORTAL PARA ENVIO DAS GUIAS 60 DIAS    

  If (Custom.Pkg_Conmvs_Tiss_Xml.Fnc_Motivo_Portal(Pcd_Motivo       => 'US009',
                                                   p_Sn_Portal_Tiss => 'S') = 'S') Then
    Begin
      For Vprazoexcecidoportal In Cprazoexcecidoportal Loop
      
        Prc_Insere_Log_Erro(Vprazoexcecidoportal.Nr_Numero_Carteira,
                            Vprazoexcecidoportal.Nr_Guia_Prestador,
                            Vprazoexcecidoportal.Nr_Guia_Operadora,
                            Vprazoexcecidoportal.Nr_Senha_Autorizacao,
                            Vprazoexcecidoportal.Cd_Prestador,
                            Vprazoexcecidoportal.Nm_Beneficiario,
                            
                            '',
                            '',
                            'Prazo de envio no Portal Excedido (60 dias) ap�s realiza��o',
                            'US009',
                            'I',
                            'N');
      
        Commit;
      
      End Loop;
    
    Exception
      When Others Then
        Dbms_Output.Put_Line('exception-gral');
        Vexcecao      := Sqlerrm;
        Vexcecaolinha := Dbms_Utility.Format_Error_Backtrace;
        Vcoderro      := 'E999';
        Prc_Insere_Log_Erro(Vprazoexcecidoportal.Nr_Numero_Carteira,
                            Vprazoexcecidoportal.Nr_Guia_Prestador,
                            Vprazoexcecidoportal.Nr_Guia_Operadora,
                            Vprazoexcecidoportal.Nr_Senha_Autorizacao,
                            Vprazoexcecidoportal.Cd_Prestador,
                            Vprazoexcecidoportal.Nm_Beneficiario,
                            '',
                            '',
                            'EXCEPTION-GLOBAL! N�o foi possivel validar as regras --> US009. Favor entre em contato com a Operadora MSG: ' ||
                            Vexcecao || ' linha do erro: ' || Vexcecaolinha,
                            Vcoderro,
                            'E',
                            'N');
        Commit;
        If (Cprazoexcecidoportal%Isopen) Then
          Close Cprazoexcecidoportal;
        End If;
    End;
  End If;

  --Limite de Taxa Excedido 

  If (Custom.Pkg_Conmvs_Tiss_Xml.Fnc_Motivo_Portal(Pcd_Motivo       => 'US010',
                                                   p_Sn_Portal_Tiss => 'S') = 'S') Then
    Begin
      For Vlimitetaxa In Climitetaxa Loop
      
        Prc_Insere_Log_Erro(Vlimitetaxa.Nr_Numero_Carteira,
                            Vlimitetaxa.Nr_Guia_Prestador,
                            Vlimitetaxa.Nr_Guia_Operadora,
                            Vlimitetaxa.Nr_Senha_Autorizacao,
                            Vlimitetaxa.Cd_Prestador,
                            Vlimitetaxa.Nm_Beneficiario,
                            
                            '',
                            '',
                            'Quantidade de Taxa na guia Ultrapassada (LIMITE 1)',
                            'US010',
                            'I',
                            'N');
      
        Commit;
      
      End Loop;
    
    Exception
      When Others Then
        Dbms_Output.Put_Line('exception-gral');
        Vexcecao      := Sqlerrm;
        Vexcecaolinha := Dbms_Utility.Format_Error_Backtrace;
        Vcoderro      := 'E999';
        Prc_Insere_Log_Erro(Vlimitetaxa.Nr_Numero_Carteira,
                            Vlimitetaxa.Nr_Guia_Prestador,
                            Vlimitetaxa.Nr_Guia_Operadora,
                            Vlimitetaxa.Nr_Senha_Autorizacao,
                            Vlimitetaxa.Cd_Prestador,
                            Vlimitetaxa.Nm_Beneficiario,
                            '',
                            '',
                            'EXCEPTION-GLOBAL! N�o foi possivel validar as regras --> US010. Favor entre em contato com a Operadora MSG: ' ||
                            Vexcecao || ' linha do erro: ' || Vexcecaolinha,
                            Vcoderro,
                            'E',
                            'N');
        Commit;
        If (Climitetaxa%Isopen) Then
          Close Climitetaxa;
        End If;
    End;
  End If;

  --EXECU��O 70 DIAS
  If (Custom.Pkg_Conmvs_Tiss_Xml.Fnc_Motivo_Portal(Pcd_Motivo       => 'US011',
                                                   p_Sn_Portal_Tiss => 'S') = 'S') Then
    Begin
      For Vguiaexecucao70dias In Cguiaexecucao70dias Loop
      
        Prc_Insere_Log_Erro(Vguiaexecucao70dias.Nr_Numero_Carteira,
                            Vguiaexecucao70dias.Nr_Guia_Prestador,
                            Vguiaexecucao70dias.Nr_Guia_Operadora,
                            Vguiaexecucao70dias.Nr_Senha_Autorizacao,
                            Vguiaexecucao70dias.Cd_Prestador,
                            Vguiaexecucao70dias.Nm_Beneficiario,
                            
                            '',
                            '',
                            'Limite de 70 dias ap�s a execu��o desta guia excedido !',
                            'US011',
                            'I',
                            'N');
      
        Commit;
      
      End Loop;
    
    Exception
      When Others Then
        Dbms_Output.Put_Line('exception-gral');
        Vexcecao      := Sqlerrm;
        Vexcecaolinha := Dbms_Utility.Format_Error_Backtrace;
        Vcoderro      := 'E999';
        Prc_Insere_Log_Erro(Vguiaexecucao70dias.Nr_Numero_Carteira,
                            Vguiaexecucao70dias.Nr_Guia_Prestador,
                            Vguiaexecucao70dias.Nr_Guia_Operadora,
                            Vguiaexecucao70dias.Nr_Senha_Autorizacao,
                            Vguiaexecucao70dias.Cd_Prestador,
                            Vguiaexecucao70dias.Nm_Beneficiario,
                            '',
                            '',
                            'EXCEPTION-GLOBAL! N�o foi possivel validar as regras --> US011. Favor entre em contato com a Operadora MSG: ' ||
                            Vexcecao || ' linha do erro: ' || Vexcecaolinha,
                            Vcoderro,
                            'E',
                            'N');
        Commit;
        If (Cguiaexecucao70dias%Isopen) Then
          Close Cguiaexecucao70dias;
        End If;
    End;
  End If;

  --Obriga participa��o profissional  
  If (Custom.Pkg_Conmvs_Tiss_Xml.Fnc_Motivo_Portal(Pcd_Motivo       => 'US014',
                                                   p_Sn_Portal_Tiss => 'S') = 'S') Then
    Begin
      For Vobrigagrauparticipacao In Cobrigagrauparticipacao Loop
      
        Prc_Insere_Log_Erro(Vobrigagrauparticipacao.Nr_Numero_Carteira,
                            Vobrigagrauparticipacao.Nr_Guia_Prestador,
                            Vobrigagrauparticipacao.Nr_Guia_Operadora,
                            Vobrigagrauparticipacao.Nr_Senha_Autorizacao,
                            Vobrigagrauparticipacao.Cd_Prestador,
                            Vobrigagrauparticipacao.Nm_Beneficiario,
                            
                            '',
                            '',
                            'GRAU DE PARTICIPA��O OBRIGAT�RIO PARA SERVI�O PROFISSIONAL !',
                            'US014',
                            'I',
                            'N');
      
        Commit;
      
      End Loop;
    
    Exception
      When Others Then
        Dbms_Output.Put_Line('exception-gral');
        Vexcecao      := Sqlerrm;
        Vexcecaolinha := Dbms_Utility.Format_Error_Backtrace;
        Vcoderro      := 'E999';
        Prc_Insere_Log_Erro(Vobrigagrauparticipacao.Nr_Numero_Carteira,
                            Vobrigagrauparticipacao.Nr_Guia_Prestador,
                            Vobrigagrauparticipacao.Nr_Guia_Operadora,
                            Vobrigagrauparticipacao.Nr_Senha_Autorizacao,
                            Vobrigagrauparticipacao.Cd_Prestador,
                            Vobrigagrauparticipacao.Nm_Beneficiario,
                            '',
                            '',
                            'EXCEPTION-GLOBAL! N�o foi possivel validar as regras --> US014. Favor entre em contato com a Operadora MSG: ' ||
                            Vexcecao || ' linha do erro: ' || Vexcecaolinha,
                            Vcoderro,
                            'E',
                            'N');
        Commit;
        If (Cobrigagrauparticipacao%Isopen) Then
          Close Cobrigagrauparticipacao;
        End If;
    End;
  End If;
  --

  --Prestador Existe na operadora

  If (Custom.Pkg_Conmvs_Tiss_Xml.Fnc_Motivo_Portal(Pcd_Motivo       => 'US016',
                                                   p_Sn_Portal_Tiss => 'S') = 'S') Then
  
    Begin
      For Vprestadorexistenaoperadora In Cprestadorexistenaoperadora Loop
      
        Prc_Insere_Log_Erro(Vprestadorexistenaoperadora.Nr_Numero_Carteira,
                            Vprestadorexistenaoperadora.Nr_Guia_Prestador,
                            Vprestadorexistenaoperadora.Nr_Guia_Operadora,
                            Vprestadorexistenaoperadora.Nr_Senha_Autorizacao,
                            Vprestadorexistenaoperadora.Cd_Prestador,
                            Vprestadorexistenaoperadora.Nm_Beneficiario,
                            '',
                            '',
                            'Prestador ' ||
                            Vprestadorexistenaoperadora.Nm_Membro_Eqp || ' - Conselho informado: ' || Vprestadorexistenaoperadora.Nr_Conselho_Membro_Eqp ||
                            ' - Inexistente na Operadora, para o grupo de Procedimento SD/SP - ' || Vprestadorexistenaoperadora.Cd_Procedimento ,
                            'US016',
                            'I',
                            'N');
      
        Commit;
      
      End Loop;
    
    Exception
      When Others Then
        Dbms_Output.Put_Line('exception-gral');
        Vexcecao      := Sqlerrm;
        Vexcecaolinha := Dbms_Utility.Format_Error_Backtrace;
        Vcoderro      := 'E999';
        Prc_Insere_Log_Erro(Vprestadorexistenaoperadora.Nr_Numero_Carteira,
                            Vprestadorexistenaoperadora.Nr_Guia_Prestador,
                            Vprestadorexistenaoperadora.Nr_Guia_Operadora,
                            Vprestadorexistenaoperadora.Nr_Senha_Autorizacao,
                            Vprestadorexistenaoperadora.Cd_Prestador,
                            Vprestadorexistenaoperadora.Nm_Beneficiario,
                            '',
                            '',
                            'EXCEPTION-GLOBAL! N�o foi possivel validar as regras --> US016. Favor entre em contato com a Operadora MSG: ' ||
                            Vexcecao || ' linha do erro: ' || Vexcecaolinha,
                            Vcoderro,
                            'E',
                            'N');
        Commit;
        If (Cprestadorexistenaoperadora%Isopen) Then
          Close Cprestadorexistenaoperadora;
        End If;
    End;
  End If;

  --CH2209-4741 verifica se a guia importada tem o valor/numero igual a zero. 

  If (Custom.Pkg_Conmvs_Tiss_Xml.Fnc_Motivo_Portal(Pcd_Motivo       => 'US017',
                                                   p_Sn_Portal_Tiss => 'S') = 'S') Then
    Begin
      For Vc_Guia_Prestador_Valor_0 In c_Guia_Prestador_Valor_0 Loop
      
        Prc_Insere_Log_Erro(Vc_Guia_Prestador_Valor_0.Nr_Numero_Carteira,
                            Vc_Guia_Prestador_Valor_0.Nr_Guia_Prestador,
                            Vc_Guia_Prestador_Valor_0.Nr_Guia_Operadora,
                            Vc_Guia_Prestador_Valor_0.Nr_Senha_Autorizacao,
                            Vc_Guia_Prestador_Valor_0.Cd_Prestador,
                            Vc_Guia_Prestador_Valor_0.Nm_Beneficiario,
                            '',
                            '',
                            'Guia possui valor/numero igual a 0.',
                            'US017',
                            'I',
                            'N');
      
        Commit;
      
      End Loop;
    
    Exception
      When Others Then
        Dbms_Output.Put_Line('exception-gral');
        Vexcecao      := Sqlerrm;
        Vexcecaolinha := Dbms_Utility.Format_Error_Backtrace;
        Vcoderro      := 'E999';
        Prc_Insere_Log_Erro(Vc_Guia_Prestador_Valor_0.Nr_Numero_Carteira,
                            Vc_Guia_Prestador_Valor_0.Nr_Guia_Prestador,
                            Vc_Guia_Prestador_Valor_0.Nr_Guia_Operadora,
                            Vc_Guia_Prestador_Valor_0.Nr_Senha_Autorizacao,
                            Vc_Guia_Prestador_Valor_0.Cd_Prestador,
                            Vc_Guia_Prestador_Valor_0.Nm_Beneficiario,
                            '',
                            '',
                            'EXCEPTION-GLOBAL! N�o foi possivel validar as regras --> US017. Favor entre em contato com a Operadora MSG: ' ||
                            Vexcecao || ' linha do erro: ' || Vexcecaolinha,
                            Vcoderro,
                            'E',
                            'N');
        Commit;
        If (c_Guia_Prestador_Valor_0%Isopen) Then
          Close c_Guia_Prestador_Valor_0;
        End If;
    End;
  End If;

  ---- CH2209-5401 TRAVA NO XML PARA EVITAR ENVIO DE GUIA INTERNA COMO SENDO GUIA EXTERNA. 

  If (Custom.Pkg_Conmvs_Tiss_Xml.Fnc_Motivo_Portal(Pcd_Motivo       => 'US018',
                                                   p_Sn_Portal_Tiss => 'S') = 'S') Then
    Begin
      For Vc_Guia_Interna_Como_Externa In c_Guia_Interna_Como_Externa Loop
      
        Prc_Insere_Log_Erro(Vc_Guia_Interna_Como_Externa.Nr_Numero_Carteira,
                            Vc_Guia_Interna_Como_Externa.Nr_Guia_Prestador,
                            Vc_Guia_Interna_Como_Externa.Nr_Guia_Operadora,
                            Vc_Guia_Interna_Como_Externa.Nr_Senha_Autorizacao,
                            Vc_Guia_Interna_Como_Externa.Cd_Prestador,
                            Vc_Guia_Interna_Como_Externa.Nm_Beneficiario,
                            '',
                            '',
                            'Guia de origem interna(MVS) n�o pode ser enviada no campo guia externa.',
                            'US018',
                            'I',
                            'N');
      
        Commit;
      
      End Loop;
    
    Exception
      When Others Then
        Dbms_Output.Put_Line('exception-gral');
        Vexcecao      := Sqlerrm;
        Vexcecaolinha := Dbms_Utility.Format_Error_Backtrace;
        Vcoderro      := 'E999';
        Prc_Insere_Log_Erro(Vc_Guia_Interna_Como_Externa.Nr_Numero_Carteira,
                            Vc_Guia_Interna_Como_Externa.Nr_Guia_Prestador,
                            Vc_Guia_Interna_Como_Externa.Nr_Guia_Operadora,
                            Vc_Guia_Interna_Como_Externa.Nr_Senha_Autorizacao,
                            Vc_Guia_Interna_Como_Externa.Cd_Prestador,
                            Vc_Guia_Interna_Como_Externa.Nm_Beneficiario,
                            '',
                            '',
                            'EXCEPTION-GLOBAL! N�o foi possivel validar as regras --> US018. Favor entre em contato com a Operadora MSG: ' ||
                            Vexcecao || ' linha do erro: ' || Vexcecaolinha,
                            Vcoderro,
                            'E',
                            'N');
        Commit;
        If (c_Guia_Interna_Como_Externa%Isopen) Then
          Close c_Guia_Interna_Como_Externa;
        End If;
    End;
  End If;

  ---GUIA INEXISTENTE NA OPERADORA
  If (Custom.Pkg_Conmvs_Tiss_Xml.Fnc_Motivo_Portal(Pcd_Motivo       => 'US020',
                                                   p_Sn_Portal_Tiss => 'S') = 'S') Then
    Begin
      For Vguiainexistente In Cguiainexistente Loop
      
        Prc_Insere_Log_Erro(Vguiainexistente.Nr_Numero_Carteira,
                            Vguiainexistente.Nr_Guia_Prestador,
                            Vguiainexistente.Nr_Guia_Operadora,
                            Vguiainexistente.Nr_Senha_Autorizacao,
                            Vguiainexistente.Cd_Prestador,
                            Vguiainexistente.Nm_Beneficiario,
                            '',
                            '',
                            'Guia Inexistente na Operadora !',
                            'US020',
                            'I',
                            'N');
      
        Commit;
      
      End Loop;
    
    Exception
      When Others Then
        Dbms_Output.Put_Line('exception-gral');
        Vexcecao      := Sqlerrm;
        Vexcecaolinha := Dbms_Utility.Format_Error_Backtrace;
        Vcoderro      := 'E999';
        Prc_Insere_Log_Erro(Vguiainexistente.Nr_Numero_Carteira,
                            Vguiainexistente.Nr_Guia_Prestador,
                            Vguiainexistente.Nr_Guia_Operadora,
                            Vguiainexistente.Nr_Senha_Autorizacao,
                            Vguiainexistente.Cd_Prestador,
                            Vguiainexistente.Nm_Beneficiario,
                            '',
                            '',
                            'EXCEPTION-GLOBAL! N�o foi possivel validar as regras --> US020. Favor entre em contato com a Operadora MSG: ' ||
                            Vexcecao || ' linha do erro: ' || Vexcecaolinha,
                            Vcoderro,
                            'E',
                            'N');
        Commit;
        If (Cguiainexistente%Isopen) Then
          Close Cguiainexistente;
        End If;
    End;
  
  End If;

  -- inicio trava racionalizacao  

  If (Custom.Pkg_Conmvs_Tiss_Xml.Fnc_Motivo_Portal(Pcd_Motivo       => 'US022',
                                                   p_Sn_Portal_Tiss => 'S') = 'S') Then
  
    Begin
      For Vcodracionalizacaosemautoriza In Ccodracionalizacaosemautoriza Loop
      
        Prc_Insere_Log_Erro(Vcodracionalizacaosemautoriza.Nr_Numero_Carteira,
                            Vcodracionalizacaosemautoriza.Nr_Guia_Prestador,
                            Vcodracionalizacaosemautoriza.Nr_Guia_Operadora,
                            Vcodracionalizacaosemautoriza.Nr_Senha_Autorizacao,
                            Vcodracionalizacaosemautoriza.Cd_Prestador,
                            Vcodracionalizacaosemautoriza.Nm_Beneficiario,
                            '',
                            '',
                            'CODIGO: ' ||
                            Vcodracionalizacaosemautoriza.Cd_Procedimento ||
                            ' DE RACIONALIZA��O SEM AUTORIZACAO VALIDA',
                            'US022',
                            'I',
                            'N');
      
        Commit;
      
      End Loop;
    
    Exception
      When Others Then
        Dbms_Output.Put_Line('exception-gral');
        Vexcecao      := Sqlerrm;
        Vexcecaolinha := Dbms_Utility.Format_Error_Backtrace;
        Vcoderro      := 'E999';
        Prc_Insere_Log_Erro(Vcodracionalizacaosemautoriza.Nr_Numero_Carteira,
                            Vcodracionalizacaosemautoriza.Nr_Guia_Prestador,
                            Vcodracionalizacaosemautoriza.Nr_Guia_Operadora,
                            Vcodracionalizacaosemautoriza.Nr_Senha_Autorizacao,
                            Vcodracionalizacaosemautoriza.Cd_Prestador,
                            Vcodracionalizacaosemautoriza.Nm_Beneficiario,
                            '',
                            '',
                            'EXCEPTION-GLOBAL! N�o foi possivel validar as regras --> US022. Favor entre em contato com a Operadora MSG: ' ||
                            Vexcecao || ' linha do erro: ' || Vexcecaolinha,
                            Vcoderro,
                            'E',
                            'N');
        Commit;
        If (Ccodracionalizacaosemautoriza%Isopen) Then
          Close Ccodracionalizacaosemautoriza;
        End If;
    End;
  
  End If;

  -- fim trava racionalizacao

  If (Custom.Pkg_Conmvs_Tiss_Xml.Fnc_Motivo_Portal(Pcd_Motivo       => 'US023',
                                                   p_Sn_Portal_Tiss => 'S') = 'S') Then
  
    Begin
      For Vobrigaprestadorspsd In Cobrigaprestadorspsd Loop
      
        Prc_Insere_Log_Erro(Vobrigaprestadorspsd.Nr_Numero_Carteira,
                            Vobrigaprestadorspsd.Nr_Guia_Prestador,
                            Vobrigaprestadorspsd.Nr_Guia_Operadora,
                            Vobrigaprestadorspsd.Nr_Senha_Autorizacao,
                            Vobrigaprestadorspsd.Cd_Prestador,
                            Vobrigaprestadorspsd.Nm_Beneficiario,
                            '',
                            '',
                            'Obrigat�rio o envio do Prestador para o c�digo ' ||
                            Vobrigaprestadorspsd.Cd_Procedimento,
                            'US023',
                            'I',
                            'N');
      
        Commit;
      
      End Loop;
    
    Exception
      When Others Then
        Dbms_Output.Put_Line('exception-gral');
        Vexcecao      := Sqlerrm;
        Vexcecaolinha := Dbms_Utility.Format_Error_Backtrace;
        Vcoderro      := 'E999';
        Prc_Insere_Log_Erro(Vobrigaprestadorspsd.Nr_Numero_Carteira,
                            Vobrigaprestadorspsd.Nr_Guia_Prestador,
                            Vobrigaprestadorspsd.Nr_Guia_Operadora,
                            Vobrigaprestadorspsd.Nr_Senha_Autorizacao,
                            Vobrigaprestadorspsd.Cd_Prestador,
                            Vobrigaprestadorspsd.Nm_Beneficiario,
                            '',
                            '',
                            'EXCEPTION-GLOBAL! N�o foi possivel validar as regras --> US023. Favor entre em contato com a Operadora MSG: ' ||
                            Vexcecao || ' linha do erro: ' || Vexcecaolinha,
                            Vcoderro,
                            'E',
                            'N');
        Commit;
        If (Cobrigaprestadorspsd%Isopen) Then
          Close Cobrigaprestadorspsd;
        End If;
    End;
  
  End If;

  --US024

  If (Custom.Pkg_Conmvs_Tiss_Xml.Fnc_Motivo_Portal(Pcd_Motivo       => 'US024',
                                                   p_Sn_Portal_Tiss => 'S') = 'S') Then
    Begin
      For Vproctipoatendimento In Cproctipoatendimento Loop
      
        Prc_Insere_Log_Erro(Vproctipoatendimento.Nr_Numero_Carteira,
                            Vproctipoatendimento.Nr_Guia_Prestador,
                            Vproctipoatendimento.Nr_Guia_Operadora,
                            Vproctipoatendimento.Nr_Senha_Autorizacao,
                            Vproctipoatendimento.Cd_Prestador,
                            Vproctipoatendimento.Nm_Beneficiario,
                            '',
                            '',
                            'Obrigat�rio o tipo de atendimento TISS (13) para o c�digo ' ||
                            Vobrigaprestadorspsd.Cd_Procedimento,
                            'US024',
                            'I',
                            'N');
      
        Commit;
      
      End Loop;
    
    Exception
      When Others Then
        Dbms_Output.Put_Line('exception-gral');
        Vexcecao      := Sqlerrm;
        Vexcecaolinha := Dbms_Utility.Format_Error_Backtrace;
        Vcoderro      := 'E999';
        Prc_Insere_Log_Erro(Vproctipoatendimento.Nr_Numero_Carteira,
                            Vproctipoatendimento.Nr_Guia_Prestador,
                            Vproctipoatendimento.Nr_Guia_Operadora,
                            Vproctipoatendimento.Nr_Senha_Autorizacao,
                            Vproctipoatendimento.Cd_Prestador,
                            Vproctipoatendimento.Nm_Beneficiario,
                            '',
                            '',
                            'EXCEPTION-GLOBAL! N�o foi possivel validar as regras --> US024. Favor entre em contato com a Operadora MSG: ' ||
                            Vexcecao || ' linha do erro: ' || Vexcecaolinha,
                            Vcoderro,
                            'E',
                            'N');
        Commit;
        If (Cproctipoatendimento%Isopen) Then
          Close Cproctipoatendimento;
        End If;
    End;
  End If;

  --US025
  If (Custom.Pkg_Conmvs_Tiss_Xml.Fnc_Motivo_Portal(Pcd_Motivo       => 'US025',
                                                   p_Sn_Portal_Tiss => 'S') = 'S') Then
    Begin
      For Vguiaexternazerada In Cguiaexternazerada Loop
      
        Prc_Insere_Log_Erro(Vguiaexternazerada.Nr_Numero_Carteira,
                            Vguiaexternazerada.Nr_Guia_Prestador,
                            Vguiaexternazerada.Nr_Guia_Operadora,
                            Vguiaexternazerada.Nr_Senha_Autorizacao,
                            Vguiaexternazerada.Cd_Prestador,
                            Vguiaexternazerada.Nm_Beneficiario,
                            '',
                            '',
                            'Obrigat�rio n�mero da senha prestador maior que 9 digitos e diferente de ZERO',
                            'US025',
                            'I',
                            'N');
      
        Commit;
      
      End Loop;
    
    Exception
      When Others Then
        Dbms_Output.Put_Line('exception-gral');
        Vexcecao      := Sqlerrm;
        Vexcecaolinha := Dbms_Utility.Format_Error_Backtrace;
        Vcoderro      := 'E999';
        Prc_Insere_Log_Erro(Vguiaexternazerada.Nr_Numero_Carteira,
                            Vguiaexternazerada.Nr_Guia_Prestador,
                            Vguiaexternazerada.Nr_Guia_Operadora,
                            Vguiaexternazerada.Nr_Senha_Autorizacao,
                            Vguiaexternazerada.Cd_Prestador,
                            Vguiaexternazerada.Nm_Beneficiario,
                            '',
                            '',
                            'EXCEPTION-GLOBAL! N�o foi possivel validar as regras --> US025. Favor entre em contato com a Operadora MSG: ' ||
                            Vexcecao || ' linha do erro: ' || Vexcecaolinha,
                            Vcoderro,
                            'E',
                            'N');
        Commit;
        If (Cguiaexternazerada%Isopen) Then
          Close Cguiaexternazerada;
        End If;
    End;
  End If;

  --US026
  If (Custom.Pkg_Conmvs_Tiss_Xml.Fnc_Motivo_Portal(Pcd_Motivo       => 'US026',
                                                   p_Sn_Portal_Tiss => 'S') = 'S') Then
    Begin
      For Vtipoatendimentoproc In Ctipoatendimentoproc Loop
      
        Prc_Insere_Log_Erro(Vtipoatendimentoproc.Nr_Numero_Carteira,
                            Vtipoatendimentoproc.Nr_Guia_Prestador,
                            Vtipoatendimentoproc.Nr_Guia_Operadora,
                            Vtipoatendimentoproc.Nr_Senha_Autorizacao,
                            Vtipoatendimentoproc.Cd_Prestador,
                            Vtipoatendimentoproc.Nm_Beneficiario,
                            '',
                            '',
                            'Favor informar o tipo de atendimento tiss 13 para guias sem procedimentos 2010...',
                            'US026',
                            'I',
                            'N');
      
        Commit;
      
      End Loop;
    
    Exception
      When Others Then
        Dbms_Output.Put_Line('exception-gral');
        Vexcecao      := Sqlerrm;
        Vexcecaolinha := Dbms_Utility.Format_Error_Backtrace;
        Vcoderro      := 'E999';
        Prc_Insere_Log_Erro(Vtipoatendimentoproc.Nr_Numero_Carteira,
                            Vtipoatendimentoproc.Nr_Guia_Prestador,
                            Vtipoatendimentoproc.Nr_Guia_Operadora,
                            Vtipoatendimentoproc.Nr_Senha_Autorizacao,
                            Vtipoatendimentoproc.Cd_Prestador,
                            Vtipoatendimentoproc.Nm_Beneficiario,
                            '',
                            '',
                            'EXCEPTION-GLOBAL! N�o foi possivel validar as regras --> US026. Favor entre em contato com a Operadora MSG: ' ||
                            Vexcecao || ' linha do erro: ' || Vexcecaolinha,
                            Vcoderro,
                            'E',
                            'N');
        Commit;
        If (Ctipoatendimentoproc%Isopen) Then
          Close Ctipoatendimentoproc;
        End If;
    End;
  End If;

  --
  --US027
  If (Custom.Pkg_Conmvs_Tiss_Xml.Fnc_Motivo_Portal(Pcd_Motivo       => 'US027',
                                                   p_Sn_Portal_Tiss => 'S') = 'S') Then
    Begin
      For Vviaacesso In Cviaacesso Loop
      
        Prc_Insere_Log_Erro(Vviaacesso.Nr_Numero_Carteira,
                            Vviaacesso.Nr_Guia_Prestador,
                            Vviaacesso.Nr_Guia_Operadora,
                            Vviaacesso.Nr_Senha_Autorizacao,
                            Vviaacesso.Cd_Prestador,
                            Vviaacesso.Nm_Beneficiario,
                            '',
                            '',
                            'Favor informar a VIA de Acesso para o procedimento: ' ||
                            Vviaacesso.Cd_Procedimento,
                            'US027',
                            'I',
                            'N');
      
        Commit;
      
      End Loop;
    
    Exception
      When Others Then
        Dbms_Output.Put_Line('exception-gral');
        Vexcecao      := Sqlerrm;
        Vexcecaolinha := Dbms_Utility.Format_Error_Backtrace;
        Vcoderro      := 'E999';
        Prc_Insere_Log_Erro(Vviaacesso.Nr_Numero_Carteira,
                            Vviaacesso.Nr_Guia_Prestador,
                            Vviaacesso.Nr_Guia_Operadora,
                            Vviaacesso.Nr_Senha_Autorizacao,
                            Vviaacesso.Cd_Prestador,
                            Vviaacesso.Nm_Beneficiario,
                            '',
                            '',
                            'EXCEPTION-GLOBAL! N�o foi possivel validar as regras --> US026. Favor entre em contato com a Operadora MSG: ' ||
                            Vexcecao || ' linha do erro: ' || Vexcecaolinha,
                            Vcoderro,
                            'E',
                            'N');
        Commit;
        If (Cviaacesso%Isopen) Then
          Close Cviaacesso;
        End If;
    End;
  End If;

  --US028
  If (Custom.Pkg_Conmvs_Tiss_Xml.Fnc_Motivo_Portal(Pcd_Motivo       => 'US028',
                                                   p_Sn_Portal_Tiss => 'S') = 'S') Then
    Begin
      For Vcodigoguiaconsulta In Ccodigoguiaconsulta Loop
      
        Prc_Insere_Log_Erro(Vcodigoguiaconsulta.Nr_Numero_Carteira,
                            Vcodigoguiaconsulta.Nr_Guia_Prestador,
                            Vcodigoguiaconsulta.Nr_Guia_Operadora,
                            Vcodigoguiaconsulta.Nr_Senha_Autorizacao,
                            Vcodigoguiaconsulta.Cd_Prestador,
                            Vcodigoguiaconsulta.Nm_Beneficiario,
                            '',
                            '',
                            'Procedimento N�O pertido para envio no lote (CONSULTA): ' ||
                            Vcodigoguiaconsulta.Cd_Procedimento,
                            'US028',
                            'I',
                            'N');
      
        Commit;
      
      End Loop;
    
    Exception
      When Others Then
        Dbms_Output.Put_Line('exception-gral');
        Vexcecao      := Sqlerrm;
        Vexcecaolinha := Dbms_Utility.Format_Error_Backtrace;
        Vcoderro      := 'E999';
        Prc_Insere_Log_Erro(Vviaacesso.Nr_Numero_Carteira,
                            Vviaacesso.Nr_Guia_Prestador,
                            Vviaacesso.Nr_Guia_Operadora,
                            Vviaacesso.Nr_Senha_Autorizacao,
                            Vviaacesso.Cd_Prestador,
                            Vviaacesso.Nm_Beneficiario,
                            '',
                            '',
                            'EXCEPTION-GLOBAL! N�o foi possivel validar as regras --> US026. Favor entre em contato com a Operadora MSG: ' ||
                            Vexcecao || ' linha do erro: ' || Vexcecaolinha,
                            Vcoderro,
                            'E',
                            'N');
        Commit;
        If (Cviaacesso%Isopen) Then
          Close Cviaacesso;
        End If;
    End;
  End If;

  --US029

  If (Custom.Pkg_Conmvs_Tiss_Xml.Fnc_Motivo_Portal(Pcd_Motivo       => 'US029',
                                                   p_Sn_Portal_Tiss => 'S') = 'S') Then
    Begin
      For Vtipoatendimentotisscod In Ctipoatendimentotisscod Loop
      
        Prc_Insere_Log_Erro(Vtipoatendimentotisscod.Nr_Numero_Carteira,
                            Vtipoatendimentotisscod.Nr_Guia_Prestador,
                            Vtipoatendimentotisscod.Nr_Guia_Operadora,
                            Vtipoatendimentotisscod.Nr_Senha_Autorizacao,
                            Vtipoatendimentotisscod.Cd_Prestador,
                            Vtipoatendimentotisscod.Nm_Beneficiario,
                            '',
                            '',
                            'Tipo de atendimento Diverge com o padr�o TISS para o c�digo: ' ||
                            Vtipoatendimentotisscod.Cd_Procedimento,
                            'US029',
                            'I',
                            'N');
      
        Commit;
      
      End Loop;
    
    Exception
      When Others Then
        Dbms_Output.Put_Line('exception-gral');
        Vexcecao      := Sqlerrm;
        Vexcecaolinha := Dbms_Utility.Format_Error_Backtrace;
        Vcoderro      := 'E999';
        Prc_Insere_Log_Erro(Vtipoatendimentotisscod.Nr_Numero_Carteira,
                            Vtipoatendimentotisscod.Nr_Guia_Prestador,
                            Vtipoatendimentotisscod.Nr_Guia_Operadora,
                            Vtipoatendimentotisscod.Nr_Senha_Autorizacao,
                            Vtipoatendimentotisscod.Cd_Prestador,
                            Vtipoatendimentotisscod.Nm_Beneficiario,
                            '',
                            '',
                            'EXCEPTION-GLOBAL! N�o foi possivel validar as regras --> US026. Favor entre em contato com a Operadora MSG: ' ||
                            Vexcecao || ' linha do erro: ' || Vexcecaolinha,
                            Vcoderro,
                            'E',
                            'N');
        Commit;
        If (Ctipoatendimentotisscod%Isopen) Then
          Close Ctipoatendimentotisscod;
        End If;
    End;
  End If;

  --US031
  If (Custom.Pkg_Conmvs_Tiss_Xml.Fnc_Motivo_Portal(Pcd_Motivo       => 'US031',
                                                   p_Sn_Portal_Tiss => 'S') = 'S') Then
    Begin
      For Vguiaexternaduplicada In Cguiaexternaduplicada Loop
      
        Prc_Insere_Log_Erro(Vguiaexternaduplicada.Nr_Numero_Carteira,
                            Vguiaexternaduplicada.Nr_Guia_Prestador,
                            Vguiaexternaduplicada.Nr_Guia_Operadora,
                            Vguiaexternaduplicada.Nr_Senha_Autorizacao,
                            Vguiaexternaduplicada.Cd_Prestador,
                            Vguiaexternaduplicada.Nm_Beneficiario,
                            '',
                            '',
                            'Guia Externa duplicada',
                            'US031',
                            'I',
                            'N');
      
        Commit;
      
      End Loop;
    
    Exception
      When Others Then
        Dbms_Output.Put_Line('exception-gral');
        Vexcecao      := Sqlerrm;
        Vexcecaolinha := Dbms_Utility.Format_Error_Backtrace;
        Vcoderro      := 'E999';
        Prc_Insere_Log_Erro(Vguiaexternaduplicada.Nr_Numero_Carteira,
                            Vguiaexternaduplicada.Nr_Guia_Prestador,
                            Vguiaexternaduplicada.Nr_Guia_Operadora,
                            Vguiaexternaduplicada.Nr_Senha_Autorizacao,
                            Vguiaexternaduplicada.Cd_Prestador,
                            Vguiaexternaduplicada.Nm_Beneficiario,
                            '',
                            '',
                            'EXCEPTION-GLOBAL! N�o foi possivel validar as regras --> US031. Favor entre em contato com a Operadora MSG: ' ||
                            Vexcecao || ' linha do erro: ' || Vexcecaolinha,
                            Vcoderro,
                            'E',
                            'N');
        Commit;
        If (Cguiaexternaduplicada%Isopen) Then
          Close Cguiaexternaduplicada;
        End If;
    End;
  End If;

  --US012

  If (Custom.Pkg_Conmvs_Tiss_Xml.Fnc_Motivo_Portal(Pcd_Motivo       => 'US012',
                                                   p_Sn_Portal_Tiss => 'S') = 'S') Then
    Begin
      For Vdeclaracaonascidoouobtito In Cdeclaracaonascidoouobtito Loop
      
        Prc_Insere_Log_Erro(Vdeclaracaonascidoouobtito.Nr_Numero_Carteira,
                            Vdeclaracaonascidoouobtito.Nr_Guia_Prestador,
                            Vdeclaracaonascidoouobtito.Nr_Guia_Operadora,
                            Vdeclaracaonascidoouobtito.Nr_Senha_Autorizacao,
                            Vdeclaracaonascidoouobtito.Cd_Prestador,
                            Vdeclaracaonascidoouobtito.Nm_Beneficiario,
                            '',
                            '',
                            'Declara��o do Nascido Vivo ou �bito N�o informada, 
                            ou n�o respeitou o limite de caracteres num�ricos (11)',
                            'US012',
                            'I',
                            'N');
      
        Commit;
      
      End Loop;
    
    Exception
      When Others Then
        Dbms_Output.Put_Line('exception-gral');
        Vexcecao      := Sqlerrm;
        Vexcecaolinha := Dbms_Utility.Format_Error_Backtrace;
        Vcoderro      := 'E999';
        Prc_Insere_Log_Erro(Vdeclaracaonascidoouobtito.Nr_Numero_Carteira,
                            Vdeclaracaonascidoouobtito.Nr_Guia_Prestador,
                            Vdeclaracaonascidoouobtito.Nr_Guia_Operadora,
                            Vdeclaracaonascidoouobtito.Nr_Senha_Autorizacao,
                            Vdeclaracaonascidoouobtito.Cd_Prestador,
                            Vdeclaracaonascidoouobtito.Nm_Beneficiario,
                            '',
                            '',
                            'EXCEPTION-GLOBAL! N�o foi possivel validar as regras --> US012. Favor entre em contato com a Operadora MSG: ' ||
                            Vexcecao || ' linha do erro: ' || Vexcecaolinha,
                            Vcoderro,
                            'E',
                            'N');
        Commit;
        If (Cdeclaracaonascidoouobtito%Isopen) Then
          Close Cdeclaracaonascidoouobtito;
        End If;
    End;
  End If;

  --US013

  If (Custom.Pkg_Conmvs_Tiss_Xml.Fnc_Motivo_Portal(Pcd_Motivo       => 'US013',
                                                   p_Sn_Portal_Tiss => 'S') = 'S') Then
    Begin
      For Vdeclaracaoobito In Cdeclaracaoobito Loop
      
        Prc_Insere_Log_Erro(Vdeclaracaoobito.Nr_Numero_Carteira,
                            Vdeclaracaoobito.Nr_Guia_Prestador,
                            Vdeclaracaoobito.Nr_Guia_Operadora,
                            Vdeclaracaoobito.Nr_Senha_Autorizacao,
                            Vdeclaracaoobito.Cd_Prestador,
                            Vdeclaracaoobito.Nm_Beneficiario,
                            '',
                            '',
                            'Declara��o de �bito N�o informada, 
                            ou n�o respeitou o limite de caracteres num�ricos (11)',
                            'US013',
                            'I',
                            'N');
      
        Commit;
      
      End Loop;
    
    Exception
      When Others Then
        Dbms_Output.Put_Line('exception-gral');
        Vexcecao      := Sqlerrm;
        Vexcecaolinha := Dbms_Utility.Format_Error_Backtrace;
        Vcoderro      := 'E999';
        Prc_Insere_Log_Erro(Vdeclaracaoobito.Nr_Numero_Carteira,
                            Vdeclaracaoobito.Nr_Guia_Prestador,
                            Vdeclaracaoobito.Nr_Guia_Operadora,
                            Vdeclaracaoobito.Nr_Senha_Autorizacao,
                            Vdeclaracaoobito.Cd_Prestador,
                            Vdeclaracaoobito.Nm_Beneficiario,
                            '',
                            '',
                            'EXCEPTION-GLOBAL! N�o foi possivel validar as regras --> US013. Favor entre em contato com a Operadora MSG: ' ||
                            Vexcecao || ' linha do erro: ' || Vexcecaolinha,
                            Vcoderro,
                            'E',
                            'N');
        Commit;
        If (Cdeclaracaoobito%Isopen) Then
          Close Cdeclaracaoobito;
        End If;
    End;
  End If;

  --US032 
  If (Custom.Pkg_Conmvs_Tiss_Xml.Fnc_Motivo_Portal(Pcd_Motivo       => 'US032',
                                                   p_Sn_Portal_Tiss => 'S') = 'S') Then
    Begin
      For Vreducaoacrescimo In Creducaoacrescimo Loop
      
        Prc_Insere_Log_Erro(Vreducaoacrescimo.Nr_Numero_Carteira,
                            Vreducaoacrescimo.Nr_Guia_Prestador,
                            Vreducaoacrescimo.Nr_Guia_Operadora,
                            Vreducaoacrescimo.Nr_Senha_Autorizacao,
                            Vreducaoacrescimo.Cd_Prestador,
                            Vreducaoacrescimo.Nm_Beneficiario,
                            '',
                            '',
                            'REDUTOR ACR�SCIMO DIVERGENTE',
                            'US032',
                            'I',
                            'N');
      
        Commit;
      
      End Loop;
    
    Exception
      When Others Then
        Dbms_Output.Put_Line('exception-gral');
        Vexcecao      := Sqlerrm;
        Vexcecaolinha := Dbms_Utility.Format_Error_Backtrace;
        Vcoderro      := 'E999';
        Prc_Insere_Log_Erro(Vreducaoacrescimo.Nr_Numero_Carteira,
                            Vreducaoacrescimo.Nr_Guia_Prestador,
                            Vreducaoacrescimo.Nr_Guia_Operadora,
                            Vreducaoacrescimo.Nr_Senha_Autorizacao,
                            Vreducaoacrescimo.Cd_Prestador,
                            Vreducaoacrescimo.Nm_Beneficiario,
                            '',
                            '',
                            'EXCEPTION-GLOBAL! N�o foi possivel validar as regras --> US032. Favor entre em contato com a Operadora MSG: ' ||
                            Vexcecao || ' linha do erro: ' || Vexcecaolinha,
                            Vcoderro,
                            'E',
                            'N');
        Commit;
        If (Creducaoacrescimo%Isopen) Then
          Close Creducaoacrescimo;
        End If;
    End;
  End If;

  --US033

  If (Custom.Pkg_Conmvs_Tiss_Xml.Fnc_Motivo_Portal(Pcd_Motivo       => 'US033',
                                                   p_Sn_Portal_Tiss => 'S') = 'S') Then
    Begin
      For Vvalidaguiaprincipalsadt In Cvalidaguiaprincipalsadt Loop
      
        Prc_Insere_Log_Erro(Vvalidaguiaprincipalsadt.Nr_Numero_Carteira,
                            Vvalidaguiaprincipalsadt.Nr_Guia_Prestador,
                            Vvalidaguiaprincipalsadt.Nr_Guia_Operadora,
                            Vvalidaguiaprincipalsadt.Nr_Senha_Autorizacao,
                            Vvalidaguiaprincipalsadt.Cd_Prestador,
                            Vvalidaguiaprincipalsadt.Nm_Beneficiario,
                            '',
                            '',
                            'Preenchido GUIA PRINCIPAL S�O IGUAIS (REFERENCIA CRUZADA)',
                            'US033',
                            'I',
                            'N');
      
        Commit;
      
      End Loop;
    
    Exception
      When Others Then
        Dbms_Output.Put_Line('exception-gral');
        Vexcecao      := Sqlerrm;
        Vexcecaolinha := Dbms_Utility.Format_Error_Backtrace;
        Vcoderro      := 'E999';
        Prc_Insere_Log_Erro(Vvalidaguiaprincipalsadt.Nr_Numero_Carteira,
                            Vvalidaguiaprincipalsadt.Nr_Guia_Prestador,
                            Vvalidaguiaprincipalsadt.Nr_Guia_Operadora,
                            Vvalidaguiaprincipalsadt.Nr_Senha_Autorizacao,
                            Vvalidaguiaprincipalsadt.Cd_Prestador,
                            Vvalidaguiaprincipalsadt.Nm_Beneficiario,
                            '',
                            '',
                            'EXCEPTION-GLOBAL! N�o foi possivel validar as regras --> US033. Favor entre em contato com a Operadora MSG: ' ||
                            Vexcecao || ' linha do erro: ' || Vexcecaolinha,
                            Vcoderro,
                            'E',
                            'N');
        Commit;
        If (Cvalidaguiaprincipalsadt%Isopen) Then
          Close Cvalidaguiaprincipalsadt;
        End If;
    End;
  End If;

  --FIM DAS VALIDA��ES.

  If (Rprotocoloctamed.Id_Tiss_Mensagem_Retorno Is Not Null) Then
  
    Nqtderrostotal2 := 0;
  
    Select Count(*)
      Into Nqtderrostotal2
      From Dbaps.Log_Erro_Protocolo_Tiss
     Where Cd_Protocolo_Ctamed = Pcd_Protocolo_Ctamed;
  
    If Nqtderrostotal2 > 0 Then
    
      Update Dbaps.Tiss_Mensagem
         Set Ds_Msg_Erro = Nqtderrostotal2 || ' ERROS NO XML'
       Where Id = Rprotocoloctamed.Id_Tiss_Mensagem_Retorno;
    
      Update Dbaps.Protocolo_Ctamed p
         Set p.Cd_Status_Protocolo = 9
       Where p.Cd_Protocolo_Ctamed = Pcd_Protocolo_Ctamed;
      Commit;
    Else
    
      Update Dbaps.Tiss_Mensagem
         Set Ds_Msg_Erro = Null
       Where Id = Rprotocoloctamed.Id_Tiss_Mensagem_Retorno;
    
    End If;
  
  End If;

  Commit;

Exception
  When Others Then
    Dbms_Output.Put_Line('exception-gral');
    Vexcecao      := Sqlerrm;
    Vexcecaolinha := Dbms_Utility.Format_Error_Backtrace;
    Vcoderro      := 'E999';
    Prc_Insere_Log_Erro(Rvtissloteguia.Nr_Numero_Carteira,
                        Rvtissloteguia.Nr_Guia_Prestador,
                        Rvtissloteguia.Nr_Guia_Operadora,
                        Rvtissloteguia.Nr_Senha_Autorizacao,
                        Rvtissloteguia.Cd_Prestador,
                        Rvtissloteguia.Nm_Beneficiario,
                        '',
                        '',
                        '',
                        'EXCEPTION-GLOBAL! N�o foi possivel validar as regras. Favor entre em contato com a Operadora MSG: ' ||
                        Vexcecao || ' linha do erro: ' || Vexcecaolinha,
                        Vcoderro,
                        'E',
                        'N');
    Commit;
End;
/
