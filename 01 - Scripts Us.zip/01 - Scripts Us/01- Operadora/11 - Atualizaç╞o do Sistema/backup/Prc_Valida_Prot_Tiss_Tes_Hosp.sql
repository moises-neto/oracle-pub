CREATE OR REPLACE NONEDITIONABLE Procedure DBAPS.Prc_Valida_Prot_Tiss_Tes_Hosp(Pcd_Protocolo_Ctamed In Number) Is
  /**************************************************************
      Objeto de valida��o do protocolo Tiss da Unimed Sorocaba
    CRIA��O           : Mois�s de Souza - UNIMED SOROCABA
    DATA             : 03/05/2022
    OBJETIVO         : Estamos seguindo o objeto da MV prc_mvs_valida_protocolo_tiss,
     por�m precisamos customizar valida��es do hospital.
   ATEN��O: Regra apenas para o Hospital 300100                 
  
  */ --cursor do dados das guias
  -- DIF_HORAS_VALIDACAO - ESQUEMA PARA EVITAR VALIDA��O DE GUIAS J� HOMOLOGADAS NA ULTIMA HORA (FOCO: PERFORMANCE) (apos 1 hora revalida-se tudo)
  Cursor Cvtissloteguia(p_Cd_Protocolo_Ctamed In Number) Is
    Select v.Nr_Numero_Carteira,
           Regexp_Replace(v.Nr_Guia_Prestador, '[^[:digit:]]+') Nr_Guia_Prestador,
           Regexp_Replace(v.Nr_Guia_Operadora, '[^[:digit:]]+') Nr_Guia_Operadora,
           v.Cd_Prestador,
           v.Nm_Beneficiario,
           Regexp_Replace(v.Nr_Senha_Autorizacao, '[^[:digit:]]+') Nr_Senha_Autorizacao,
           v.Cd_Protocolo_Ctamed,
           Regexp_Replace(v.Nr_Identificador_Beneficiario, '[^[:digit:]]+') Nr_Identificador_Beneficiario,
           Regexp_Replace(v.Cd_Prestador_Exec, '[^[:digit:]]+') Cd_Prestador_Exec,
           Regexp_Replace(v.Cnpj_Exec, '[^[:digit:]]+') Cnpj_Exec,
           Regexp_Replace(v.Cpf_Exec, '[^[:digit:]]+') Cpf_Exec,
           v.Cd_Multi_Empresa,
           v.Id_Pai,
           v.Cd_Procedimento
      From Dbaps.v_Tiss_Lote_Guia v
     Where v.Cd_Protocolo_Ctamed = Pcd_Protocolo_Ctamed
       And Pcd_Protocolo_Ctamed Is Not Null
       And Exists
     (Select 1
              From Custom.Tiss_Controle_Protocolo Tp
             Where Tp.Cd_Protocolo_Ctamed = v.Cd_Protocolo_Ctamed
               And Tp.Sn_Validado = 'N')
    
     Group By v.Nr_Numero_Carteira,
              v.Nr_Guia_Prestador,
              v.Nr_Guia_Operadora,
              v.Cd_Prestador,
              v.Nm_Beneficiario,
              v.Nr_Senha_Autorizacao,
              v.Cd_Protocolo_Ctamed,
              v.Nr_Identificador_Beneficiario,
              v.Cd_Prestador_Exec,
              v.Cnpj_Exec,
              v.Cpf_Exec,
              v.Cd_Multi_Empresa,
              v.Id_Pai,
              v.Cd_Procedimento;

  Cursor Cexisteerro(p_Cd_Erro             In Varchar,
                     p_Cd_Protocolo_Ctamed In Number,
                     p_Nr_Guia_Prestador   In Varchar2) Is
    Select 1
      From Dbaps.Log_Erro_Protocolo_Tiss
     Where Cd_Protocolo_Ctamed = p_Cd_Protocolo_Ctamed
       And Cd_Erro = p_Cd_Erro
       And Ds_Guia_Prestador = p_Nr_Guia_Prestador;
  /**
  *  Cursor cProtocoloCtaMed
  */
  Cursor Cprotocoloctamed(p_Cd_Protocolo_Ctamed In Number) Is
    Select Pc.Id_Tisslotguia,
           Pc.Cd_Prestador,
           Mt.Cd_Retorno_Tiss_Mensagem Id_Tiss_Mensagem_Retorno,
           Tm.Id,
           Mt.Cd_Tiss_Mensagem,
           Pc.Cd_Protocolo_Ctamed,
           Pc.Cd_Multi_Empresa,
           Pc.Dt_Envio_Lote
      From Dbaps.Protocolo_Ctamed Pc,
           Dbaps.Tiss_Lot_Guia    Tlg,
           Dbaps.Tiss_Mensagem    Tm,
           Dbaps.Mv_Tiss          Mt,
           Dbaps.Prestador        p,
           Dbaps.Fatura           f
     Where Pc.Id_Tisslotguia = Tlg.Id
       And Tlg.Id_Pai = Tm.Id
       And Tm.Id = Mt.Cd_Tiss_Mensagem(+)
       And Pc.Cd_Prestador = p.Cd_Prestador
       And Pc.Cd_Fatura = f.Cd_Fatura(+)
       And Pc.Cd_Protocolo_Ctamed = p_Cd_Protocolo_Ctamed
       And Exists
     (Select 1
              From Custom.Tiss_Controle_Protocolo Tp
             Where Tp.Cd_Protocolo_Ctamed = Pc.Cd_Protocolo_Ctamed
               And Tp.Sn_Validado = 'N');

  /**
  *  Cursor cVerificaProcedimento, verifica se o Procedimento precisa de avalicao previa.
  */

  --Mois�s 25/03/2022 --> (CH2203-0567) N�o permitir a postagem de arquivo com consulta 10101039 COM o CD_TIPO_ATENDIMENTO_TISS <>11

  Cursor Cverificaconsultaps Is
  
    Select --US002
     v.Cd_Protocolo_Ctamed,
     v.Nr_Numero_Carteira,
     v.Nr_Guia_Prestador,
     v.Nr_Senha_Autorizacao,
     v.Cd_Prestador,
     v.Nm_Beneficiario,
     v.Nr_Guia_Operadora,
     v.Cd_Tipo_Atendimento
      From Dbaps.v_Tiss_Lote_Guia v
     Where v.Cd_Protocolo_Ctamed = Pcd_Protocolo_Ctamed
       And v.Cd_Procedimento = '10101039'
       And v.Cd_Tipo_Atendimento <> '11'
       And Exists
     (Select 1
              From Custom.Tiss_Controle_Protocolo Tp
             Where Tp.Cd_Protocolo_Ctamed = v.Cd_Protocolo_Ctamed
               And Tp.Sn_Validado = 'N');
  -- Mois�s --> 12/04/2022 atender ao requisito do manual do PTU XML --> CH2202-2485
  -- (travar quando for guia de interna��o, conter os procedimento
  --31309038, 31309054, 31309097, 31309127 e 31309135, e n�o tiver o CD_TIPO_INTERNACAO = 3.

  Cursor Ctipointernacao Is
  
    Select --US003
     v.Cd_Protocolo_Ctamed,
     v.Nr_Numero_Carteira,
     v.Nr_Guia_Prestador,
     v.Nr_Senha_Autorizacao,
     v.Cd_Prestador,
     v.Nm_Beneficiario,
     v.Nr_Guia_Operadora,
     v.Cd_Tipo_Internacao
      From Dbaps.v_Tiss_Lote_Guia v
     Where v.Cd_Protocolo_Ctamed = Pcd_Protocolo_Ctamed
       And v.Cd_Tipo_Internacao <> 3
       And v.Cd_Procedimento In
           (31309038, 31309054, 31309097, 31309127, 31309135)
       And Exists
     (Select 1
              From Custom.Tiss_Controle_Protocolo Tp
             Where Tp.Cd_Protocolo_Ctamed = v.Cd_Protocolo_Ctamed
               And Tp.Sn_Validado = 'N');

  Cursor Cguiasduplicadas Is
  
    Select --US004
     v.Cd_Protocolo_Ctamed,
     v.Nr_Numero_Carteira,
     v.Nr_Guia_Prestador,
     v.Nr_Senha_Autorizacao,
     v.Cd_Prestador,
     v.Nm_Beneficiario,
     v.Nr_Guia_Operadora,
     v.Cd_Tipo_Atendimento,
     v.Cd_Tipo_Internacao
      From Dbaps.v_Tiss_Lote_Guia v
     Where v.Cd_Protocolo_Ctamed = Pcd_Protocolo_Ctamed
       And v.Cd_Tipo_Atendimento = 1
       And Exists (Select 1
              From Dbaps.Remessa_Prestador Rp
             Where Rp.Nr_Guia = v.Nr_Senha_Autorizacao
               And Rownum = 1
            
            Union All
            
            Select 1
              From Dbaps.Remessa_Prestador Rp
             Where Rp.Nr_Guia = v.Nr_Guia_Operadora
               And Rownum = 1
            
            )
          
       And Exists
     (Select 1
              From Custom.Tiss_Controle_Protocolo Tp
             Where Tp.Cd_Protocolo_Ctamed = v.Cd_Protocolo_Ctamed
               And Tp.Sn_Validado = 'N')
    
    Union All
    --Interna��o
    Select --US004
     v.Cd_Protocolo_Ctamed,
     v.Nr_Numero_Carteira,
     v.Nr_Guia_Prestador,
     v.Nr_Senha_Autorizacao,
     v.Cd_Prestador,
     v.Nm_Beneficiario,
     v.Nr_Guia_Operadora,
     v.Cd_Tipo_Atendimento,
     v.Cd_Tipo_Internacao
      From Dbaps.v_Tiss_Lote_Guia v, Dbaps.Tiss_Lot_Guia_Fat_Resint Iod
     Where v.Cd_Protocolo_Ctamed = Pcd_Protocolo_Ctamed
       And Iod.Id = v.Id_Pai
       And Iod.Cd_Tipo_Faturamento Not In (1, 2, 3)
       And Not Exists
     (Select 1
              From Dbaps.v_Tiss_Lote_Guia Vv
             Where Vv.Cd_Protocolo_Ctamed = v.Cd_Protocolo_Ctamed
               And Vv.Cd_Procedimento = '60033746'
               And Rownum = 1)
       And Exists
     (Select 1
              From Custom.Tiss_Controle_Protocolo Tp
             Where Tp.Cd_Protocolo_Ctamed = v.Cd_Protocolo_Ctamed
               And Tp.Sn_Validado = 'N')
          
       And Exists (Select 1
              From Dbaps.Conta_Hospitalar c
             Where c.Nr_Guia = v.Nr_Senha_Autorizacao
               And c.Cd_Tipo_Faturamento <> 'C'
               And Rownum = 1
            
            Union All
            Select 1
              From Dbaps.Conta_Hospitalar c
             Where c.Nr_Guia = v.Nr_Guia_Operadora
               And c.Cd_Tipo_Faturamento <> 'C'
               And Rownum = 1
            
            )
    Union All --(SADT)
    
    Select
    --US004
     v.Cd_Protocolo_Ctamed,
     v.Nr_Numero_Carteira,
     v.Nr_Guia_Prestador,
     v.Nr_Senha_Autorizacao,
     v.Cd_Prestador,
     v.Nm_Beneficiario,
     v.Nr_Guia_Operadora,
     v.Cd_Tipo_Atendimento,
     v.Cd_Tipo_Internacao
      From Dbaps.v_Tiss_Lote_Guia v
     Where v.Cd_Protocolo_Ctamed = Pcd_Protocolo_Ctamed
          
       And v.Cd_Tipo_Atendimento Not In (3, 8, 10)
          
       And Not Exists
     (Select 1
              From Dbaps.v_Tiss_Lote_Guia Vv
             Where Vv.Cd_Protocolo_Ctamed = v.Cd_Protocolo_Ctamed
               And Vv.Cd_Procedimento = '60033746')
          
       And Exists
     (Select 1
              From Custom.Tiss_Controle_Protocolo Tp
             Where Tp.Cd_Protocolo_Ctamed = v.Cd_Protocolo_Ctamed
               And Tp.Sn_Validado = 'N')
          
       And Exists
     (Select 1
              From Dbaps.Remessa_Prestador Rp, Itremessa_Prestador Ip
             Where Rp.Cd_Remessa = Ip.Cd_Remessa
                  
               And Rp.Nr_Guia = v.Nr_Senha_Autorizacao
               And Ip.Cd_Procedimento = v.Cd_Procedimento
               And To_Char(Ip.Qt_Cobrado) = v.Qt_Realizado
               And To_Char(Ip.Dt_Realizado, 'DD/MM/YYYY') =
                   Substr(v.Dt_Procedimento, 9, 9) || '/' ||
                   Substr(v.Dt_Procedimento, 6, 2) || '/' ||
                   Substr(v.Dt_Procedimento, 0, 4)
               And Rownum = 1
            
            Union All
            
            Select 1
              From Dbaps.Remessa_Prestador Rp, Itremessa_Prestador Ip
             Where Rp.Cd_Remessa = Ip.Cd_Remessa
                  
               And Rp.Nr_Guia = v.Nr_Guia_Operadora
               And Ip.Cd_Procedimento = v.Cd_Procedimento
               And To_Char(Ip.Qt_Cobrado) = v.Qt_Realizado
               And To_Char(Ip.Dt_Realizado, 'DD/MM/YYYY') =
                   Substr(v.Dt_Procedimento, 9, 9) || '/' ||
                   Substr(v.Dt_Procedimento, 6, 2) || '/' ||
                   Substr(v.Dt_Procedimento, 0, 4)
               And Rownum = 1
            
            );

  Cursor Ccodigoinexistente Is
    Select --US005
     v.Cd_Protocolo_Ctamed,
     v.Nr_Numero_Carteira,
     v.Nr_Guia_Prestador,
     v.Nr_Senha_Autorizacao,
     v.Cd_Prestador,
     v.Nm_Beneficiario,
     v.Nr_Guia_Operadora,
     v.Cd_Procedimento
      From Dbaps.v_Tiss_Lote_Guia v
     Where v.Cd_Protocolo_Ctamed = Pcd_Protocolo_Ctamed
       And v.Cd_Procedimento <> '99910073'
          
       And Exists
     (Select 1
              From Custom.Tiss_Controle_Protocolo Tp
             Where Tp.Cd_Protocolo_Ctamed = v.Cd_Protocolo_Ctamed
               And Tp.Sn_Validado = 'N')
       And Not Exists
     (Select 1
              From Dbaps.Procedimento p
             Where p.Cd_Procedimento = v.Cd_Procedimento);

  Cursor Cguiavencida Is
  --Interna��o
    Select --US006
     v.Cd_Protocolo_Ctamed,
     v.Nr_Numero_Carteira,
     v.Nr_Guia_Prestador,
     v.Nr_Senha_Autorizacao,
     v.Cd_Prestador,
     v.Nm_Beneficiario,
     v.Nr_Guia_Operadora,
     v.Cd_Tipo_Atendimento,
     v.Cd_Tipo_Internacao
      From Dbaps.v_Tiss_Lote_Guia v, Dbaps.Tiss_Lot_Guia_Fat_Resint Iod
     Where v.Cd_Protocolo_Ctamed = Pcd_Protocolo_Ctamed
       And Iod.Id = v.Id_Pai
       And Iod.Cd_Tipo_Faturamento Not In (1, 2)
       And Exists
     (Select 1
              From Custom.Tiss_Controle_Protocolo Tp
             Where Tp.Cd_Protocolo_Ctamed = v.Cd_Protocolo_Ctamed
               And Tp.Sn_Validado = 'N')
       And Exists
     (Select 1
              From Dbaps.Conta_Hospitalar c, Dbaps.Itconta_Hospitalar Ih
             Where c.Cd_Conta_Hospitalar = Ih.Cd_Conta_Hospitalar
               And c.Nr_Guia = v.Nr_Guia_Operadora
               And Exists
            
             (Select 1
                      From Dbaps.Guia g
                     Where g.Nr_Guia = c.Nr_Guia
                       And g.Sn_Valida_Rest_Carencia = 'S'
                       And Substr(v.Dt_Procedimento, 9, 9) || '/' ||
                           Substr(v.Dt_Procedimento, 6, 2) || '/' ||
                           Substr(v.Dt_Procedimento, 0, 4) >
                           Trunc(g.Dt_Vencimento))
            
            Union
            
            Select 1
              From Dbaps.Conta_Hospitalar c, Dbaps.Itconta_Hospitalar Ih
             Where c.Cd_Conta_Hospitalar = Ih.Cd_Conta_Hospitalar
               And c.Nr_Guia = v.Nr_Senha_Autorizacao
               And Exists (Select 1
                      From Dbaps.Guia g
                     Where g.Nr_Guia = c.Nr_Guia
                       And g.Sn_Valida_Rest_Carencia = 'S'
                       And Substr(v.Dt_Procedimento, 9, 9) || '/' ||
                           Substr(v.Dt_Procedimento, 6, 2) || '/' ||
                           Substr(v.Dt_Procedimento, 0, 4) >
                           Trunc(g.Dt_Vencimento)))
    Union All --(SADT) e Consulta
    
    Select --US006
     v.Cd_Protocolo_Ctamed,
     v.Nr_Numero_Carteira,
     v.Nr_Guia_Prestador,
     v.Nr_Senha_Autorizacao,
     v.Cd_Prestador,
     v.Nm_Beneficiario,
     v.Nr_Guia_Operadora,
     v.Cd_Tipo_Atendimento,
     v.Cd_Tipo_Internacao
      From Dbaps.v_Tiss_Lote_Guia v
     Where v.Cd_Protocolo_Ctamed = Pcd_Protocolo_Ctamed
       And v.Cd_Tipo_Atendimento Not In (3, 8, 10, 13) -- inclu�do tipo atendimento 13 conforme chamado CH2302-2966
       And Exists
     (Select 1
              From Custom.Tiss_Controle_Protocolo Tp
             Where Tp.Cd_Protocolo_Ctamed = v.Cd_Protocolo_Ctamed
               And Tp.Sn_Validado = 'N')
       And Exists
     (Select 1
              From Dbaps.Remessa_Prestador Rp, Itremessa_Prestador Ip
             Where Rp.Cd_Remessa = Ip.Cd_Remessa
               And Rp.Nr_Guia = v.Nr_Guia_Operadora
                  
               And Exists (Select 1
                      From Dbaps.Guia g
                     Where g.Nr_Guia = Rp.Nr_Guia
                       And g.Sn_Valida_Rest_Carencia = 'S'
                       And Substr(v.Dt_Procedimento, 9, 9) || '/' ||
                           Substr(v.Dt_Procedimento, 6, 2) || '/' ||
                           Substr(v.Dt_Procedimento, 0, 4) >
                           Trunc(g.Dt_Vencimento))
            
            Union
            
            Select 1
              From Dbaps.Remessa_Prestador Rp, Itremessa_Prestador Ip
             Where Rp.Cd_Remessa = Ip.Cd_Remessa
               And Rp.Nr_Guia = v.Nr_Senha_Autorizacao
                  
               And Exists (Select 1
                      From Dbaps.Guia g
                     Where g.Nr_Guia = Rp.Nr_Guia
                       And g.Sn_Valida_Rest_Carencia = 'S'
                       And Substr(v.Dt_Procedimento, 9, 9) || '/' ||
                           Substr(v.Dt_Procedimento, 6, 2) || '/' ||
                           Substr(v.Dt_Procedimento, 0, 4) >
                           Trunc(g.Dt_Vencimento)));

  Cursor Cdeclaracaonascidoouobtito Is
  
    Select --US012
     v.Cd_Protocolo_Ctamed,
     v.Nr_Numero_Carteira,
     v.Nr_Guia_Prestador,
     v.Nr_Senha_Autorizacao,
     v.Cd_Prestador,
     v.Nm_Beneficiario,
     v.Nr_Guia_Operadora,
     v.Cd_Procedimento
      From Dbaps.Tiss_Lot_Guia_Fat_Resint_Decl d,
           Dbaps.Tiss_Lot_Guia_Fat_Resint      r,
           Dbaps.v_Tiss_Lote_Guia              v
     Where d.Id_Pai = r.Id
       And v.Id_Pai = r.Id
       And v.Cd_Protocolo_Ctamed = Pcd_Protocolo_Ctamed
       And Exists
     (Select 1
              From Custom.Tiss_Controle_Protocolo Tp
             Where Tp.Cd_Protocolo_Ctamed = v.Cd_Protocolo_Ctamed
               And Tp.Sn_Validado = 'N')
       And (d.Ds_Declaracao_Obito Is Null And
           d.Nr_Declaracao_Nascido Is Null)
       And v.Cd_Procedimento In
           ('31309054', '31309097', '31309127', '31309135')
    
    Union
    
    Select --US012
     v.Cd_Protocolo_Ctamed,
     v.Nr_Numero_Carteira,
     v.Nr_Guia_Prestador,
     v.Nr_Senha_Autorizacao,
     v.Cd_Prestador,
     v.Nm_Beneficiario,
     v.Nr_Guia_Operadora,
     v.Cd_Procedimento
      From Dbaps.Tiss_Lot_Guia_Fat_Resint_Decl d,
           Dbaps.Tiss_Lot_Guia_Fat_Resint      r,
           Dbaps.v_Tiss_Lote_Guia              v
     Where d.Id_Pai = r.Id
       And v.Id_Pai = r.Id
       And v.Cd_Protocolo_Ctamed = Pcd_Protocolo_Ctamed
       And Exists
     (Select 1
              From Custom.Tiss_Controle_Protocolo Tp
             Where Tp.Cd_Protocolo_Ctamed = v.Cd_Protocolo_Ctamed
               And Tp.Sn_Validado = 'N')
       And v.Cd_Procedimento In
           ('31309054', '31309097', '31309127', '31309135')
          
       And Length(Custom.Fnc_Ajusta_Numero(v_String => Trim(Nvl(d.Ds_Declaracao_Obito,
                                                                d.Nr_Declaracao_Nascido)))) > 11;

  Cursor Cdeclaracaoobito Is
  
    Select --US013
     v.Cd_Protocolo_Ctamed,
     v.Nr_Numero_Carteira,
     v.Nr_Guia_Prestador,
     v.Nr_Senha_Autorizacao,
     v.Cd_Prestador,
     v.Nm_Beneficiario,
     v.Nr_Guia_Operadora,
     v.Cd_Procedimento
      From Dbaps.Tiss_Lot_Guia_Fat_Resint_Decl d,
           Dbaps.Tiss_Lot_Guia_Fat_Resint      r,
           Dbaps.v_Tiss_Lote_Guia              v
     Where d.Id_Pai = r.Id
       And v.Id_Pai = r.Id
       And v.Cd_Protocolo_Ctamed = Pcd_Protocolo_Ctamed
       And v.Cd_Motivo_Alta In (41, 65, 66, 67)
       And Exists
     (Select 1
              From Custom.Tiss_Controle_Protocolo Tp
             Where Tp.Cd_Protocolo_Ctamed = v.Cd_Protocolo_Ctamed
               And Tp.Sn_Validado = 'N')
       And d.Ds_Declaracao_Obito Is Null
    
    Union
    
    Select --US013
     v.Cd_Protocolo_Ctamed,
     v.Nr_Numero_Carteira,
     v.Nr_Guia_Prestador,
     v.Nr_Senha_Autorizacao,
     v.Cd_Prestador,
     v.Nm_Beneficiario,
     v.Nr_Guia_Operadora,
     v.Cd_Procedimento
      From Dbaps.Tiss_Lot_Guia_Fat_Resint_Decl d,
           Dbaps.Tiss_Lot_Guia_Fat_Resint      r,
           Dbaps.v_Tiss_Lote_Guia              v
     Where d.Id_Pai = r.Id
       And v.Id_Pai = r.Id
       And v.Cd_Protocolo_Ctamed = Pcd_Protocolo_Ctamed
       And v.Cd_Motivo_Alta In (41, 65, 66, 67)
       And Exists
     (Select 1
              From Custom.Tiss_Controle_Protocolo Tp
             Where Tp.Cd_Protocolo_Ctamed = v.Cd_Protocolo_Ctamed
               And Tp.Sn_Validado = 'N')
          
       And Length(Custom.Fnc_Ajusta_Numero(v_String => Trim(d.Ds_Declaracao_Obito))) > 11;

  Cursor Cobrigagrauparticipacao Is
  
    Select --US014
     v.Cd_Protocolo_Ctamed,
     v.Nr_Numero_Carteira,
     v.Nr_Guia_Prestador,
     v.Nr_Senha_Autorizacao,
     v.Cd_Prestador,
     v.Nm_Beneficiario,
     v.Nr_Guia_Operadora,
     v.Cd_Procedimento
      From Dbaps.Tiss_Lot_Guia_Fat_Resint      r,
           Dbaps.Tiss_Lot_Guia_Fat_Resint_Proc p,
           Dbaps.Tiss_Lot_Guia_Fat_Resint_Eqp  e,
           Dbaps.v_Tiss_Lote_Guia              v
     Where r.Id = p.Id_Pai
       And p.Id = e.Id_Pai
       And v.Id_Pai = r.Id
       And v.Cd_Protocolo_Ctamed = Pcd_Protocolo_Ctamed
       And e.Cd_Posicao_Profissional Is Null
       And Exists
     (Select 1
              From Custom.Tiss_Controle_Protocolo Tp
             Where Tp.Cd_Protocolo_Ctamed = v.Cd_Protocolo_Ctamed
               And Tp.Sn_Validado = 'N')
          
       And Exists
     (Select 1
              From Dbaps.Procedimento p, Dbaps.Grupo_Procedimento Gp
             Where Gp.Cd_Grupo_Procedimento = p.Cd_Grupo_Procedimento
               And p.Cd_Procedimento = v.Cd_Procedimento
               And Gp.Tp_Gru_Pro = 'SP');

  Cursor Cvalidacarteira Is
    Select --US007
     v.Cd_Protocolo_Ctamed,
     v.Nr_Numero_Carteira,
     v.Nr_Guia_Prestador,
     v.Nr_Senha_Autorizacao,
     v.Cd_Prestador,
     v.Nm_Beneficiario,
     v.Nr_Guia_Operadora
      From Dbaps.v_Tiss_Lote_Guia v
     Where v.Cd_Protocolo_Ctamed = Pcd_Protocolo_Ctamed
       And Length(Trim(v.Nr_Numero_Carteira)) <= 16
       And Exists
     (Select 1
              From Dbaps.Guia g
             Where g.Nr_Guia = v.Nr_Senha_Autorizacao
               And Trim(g.Nr_Carteira_Utilizada) <>
                   Trim(v.Nr_Numero_Carteira)
               And Not Exists
             (Select 1
                      From Dbaps.Carteira c
                     Where c.Cd_Matricula = g.Cd_Matricula
                       And c.Ds_Numero_Carteira = g.Nr_Carteira_Utilizada))
       And Exists
     (Select 1
              From Custom.Tiss_Controle_Protocolo Tp
             Where Tp.Cd_Protocolo_Ctamed = v.Cd_Protocolo_Ctamed
               And Tp.Sn_Validado = 'N')
    Union All
    
    Select --US007
     v.Cd_Protocolo_Ctamed,
     v.Nr_Numero_Carteira,
     v.Nr_Guia_Prestador,
     v.Nr_Senha_Autorizacao,
     v.Cd_Prestador,
     v.Nm_Beneficiario,
     v.Nr_Guia_Operadora
      From Dbaps.v_Tiss_Lote_Guia v
     Where v.Cd_Protocolo_Ctamed = Pcd_Protocolo_Ctamed
       And Length(Trim(v.Nr_Numero_Carteira)) >= 17
       And Exists
     (Select 1
              From Dbaps.Guia g
             Where g.Nr_Guia = v.Nr_Senha_Autorizacao
               And '0' || Trim(Nvl(g.Nr_Carteira_Utilizada,
                                   g.Nr_Carteira_Beneficiario)) <>
                   (v.Nr_Numero_Carteira))
       And Exists
     (Select 1
              From Custom.Tiss_Controle_Protocolo Tp
             Where Tp.Cd_Protocolo_Ctamed = v.Cd_Protocolo_Ctamed
               And Tp.Sn_Validado = 'N');

  Cursor Cdadosprocprestador Is
    Select --US008
     v.Cd_Protocolo_Ctamed,
     v.Nr_Numero_Carteira,
     v.Nr_Guia_Prestador,
     v.Nr_Senha_Autorizacao,
     v.Cd_Prestador,
     v.Nm_Beneficiario,
     v.Nr_Guia_Operadora,
     v.Cd_Procedimento
      From Dbaps.v_Tiss_Lote_Guia v
     Where v.Cd_Protocolo_Ctamed = Pcd_Protocolo_Ctamed
       And v.Cd_Prestador Is Null
       And Exists
     (Select 1
              From Procedimento p, Grupo_Procedimento Gp
             Where p.Cd_Grupo_Procedimento = Gp.Cd_Grupo_Procedimento
               And p.Cd_Procedimento = v.Cd_Procedimento
               And Gp.Tp_Gru_Pro = 'SP')
       And Exists
     (Select 1
              From Custom.Tiss_Controle_Protocolo Tp
             Where Tp.Cd_Protocolo_Ctamed = v.Cd_Protocolo_Ctamed
               And Tp.Sn_Validado = 'N');

  --CH2210-1552 ORIGEM Hospital Web Service VALIDAR SE ITGUIA CAMPO DT_REALIZACAO � NULL
  Cursor c_Dt_Realizado_Is_Null Is
    Select --US019
     v.Cd_Protocolo_Ctamed,
     v.Nr_Numero_Carteira,
     v.Nr_Guia_Prestador,
     v.Nr_Senha_Autorizacao,
     v.Cd_Prestador,
     v.Nm_Beneficiario,
     v.Nr_Guia_Operadora,
     v.Cd_Procedimento
      From Dbaps.v_Tiss_Lote_Guia v
     Where v.Cd_Protocolo_Ctamed = Pcd_Protocolo_Ctamed
       And v.Dt_Procedimento Is Null
       And Exists
     (Select 1
              From Custom.Tiss_Controle_Protocolo Tp
             Where Tp.Cd_Protocolo_Ctamed = v.Cd_Protocolo_Ctamed
               And Tp.Sn_Validado = 'N');
  --CH2210-1552 ORIGEM Hospital Web Service VALIDAR DT INFORMADA NO XML
  Cursor Cprazoexcecidoportal Is
    Select Tab.*
      From (Select --US009 
             v.Cd_Protocolo_Ctamed,
             v.Nr_Numero_Carteira,
             v.Nr_Guia_Prestador,
             v.Nr_Senha_Autorizacao,
             v.Cd_Prestador,
             v.Nm_Beneficiario,
             v.Nr_Guia_Operadora,
             v.Cd_Procedimento,
             To_Date(Substr(v.Dt_Procedimento, 9, 10) || '/' ||
                     Substr(v.Dt_Procedimento, 6, 2) || '/' ||
                     Substr(v.Dt_Procedimento, 1, 4),
                     'DD/MM/YYYY') Dt_Realizado
              From Dbaps.v_Tiss_Lote_Guia v
             Where v.Cd_Protocolo_Ctamed = Pcd_Protocolo_Ctamed
               And Nvl(v.Nr_Guia_Operadora, v.Nr_Guia_Prestador) Not In
                   ('101187119',
                    '101188299',
                    '101190639',
                    '101183669',
                    '101190639',
                    '101505419')) Tab
     Where Tab.Dt_Realizado <= Trunc(Sysdate) - 60
       And Exists (Select 1
              From Dbaps.Guia g
             Where g.Nr_Guia =
                   To_Number(Custom.Pkg_Conmvs_Tiss_Xml.Fnc_Ajusta_Numero(v_String => Tab.Nr_Guia_Operadora))
               And (g.Cd_Tipo_Atendimento Not In (2, 11) And
                   g.Cd_Tipo_Atendimento_Tiss Not In (3, 23)
                   
                   Or (g.Cd_Tipo_Atendimento Not In (2, 11) And
                   g.Cd_Tipo_Atendimento_Tiss Is Null))
            Union
            Select 1
              From Dbaps.Guia g
             Where g.Nr_Guia =
                   To_Number(Custom.Pkg_Conmvs_Tiss_Xml.Fnc_Ajusta_Numero(v_String => Tab.Nr_Guia_Prestador))
               And (g.Cd_Tipo_Atendimento Not In (2, 11) And
                   g.Cd_Tipo_Atendimento_Tiss Not In (3, 23)
                   
                   Or (g.Cd_Tipo_Atendimento Not In (2, 11) And
                   g.Cd_Tipo_Atendimento_Tiss Is Null)))
       And Exists
     (Select 1
              From Custom.Tiss_Controle_Protocolo Tp
             Where Tp.Cd_Protocolo_Ctamed = Tab.Cd_Protocolo_Ctamed
               And Tp.Sn_Validado = 'N');

  Cursor Climitetaxa Is
    Select --US010 
     a.Cd_Protocolo_Ctamed,
     a.Nr_Numero_Carteira,
     a.Nr_Guia_Prestador,
     a.Nr_Senha_Autorizacao,
     a.Cd_Prestador,
     a.Nm_Beneficiario,
     a.Nr_Guia_Operadora,
     a.Cd_Procedimento,
     Sum(a.Proctaxa) As Qtd_Taxa,
     a.Dt_Realizacao
      From (Select v.Cd_Protocolo_Ctamed,
                   v.Nr_Numero_Carteira,
                   v.Nr_Guia_Prestador,
                   v.Nr_Senha_Autorizacao,
                   v.Cd_Prestador,
                   v.Nm_Beneficiario,
                   v.Nr_Guia_Operadora,
                   v.Cd_Procedimento,
                   1                      As Proctaxa,
                   v.Dt_Procedimento      As Dt_Realizacao
              From Dbaps.v_Tiss_Lote_Guia v,
                   Dbaps.Procedimento     p,
                   Dbaps.Itguia           It
             Where v.Cd_Protocolo_Ctamed = Pcd_Protocolo_Ctamed
               And v.Cd_Procedimento = p.Cd_Procedimento
               And v.Cd_Prestador != 300100 -- CH2212-0081
               And To_Char(It.Nr_Guia) = v.Nr_Senha_Autorizacao
               And It.Cd_Procedimento = p.Cd_Procedimento
               And It.Cd_Procedimento In ('60023001',
                                          '60023022',
                                          '60023033',
                                          '60023384',
                                          '60023287',
                                          '60023244')
               And It.Tp_Status = 4
               And Exists
             (Select 1
                      From Custom.Tiss_Controle_Protocolo Tp
                     Where Tp.Cd_Protocolo_Ctamed = v.Cd_Protocolo_Ctamed
                       And Tp.Sn_Validado = 'N')) a
    
     Group By a.Cd_Protocolo_Ctamed,
              a.Nr_Numero_Carteira,
              a.Nr_Guia_Prestador,
              a.Nr_Senha_Autorizacao,
              a.Cd_Prestador,
              a.Nm_Beneficiario,
              a.Nr_Guia_Operadora,
              a.Cd_Procedimento,
              a.Dt_Realizacao
    Having Sum(a.Proctaxa) > 1;

  --CH2210-1552 ORIGEM Hospital Web Service VALIDAR ITGUIA DT_REALIZACAO
  Cursor Cguiaexecucao70dias Is
    Select Tab.*
      From (Select --US011
             v.Cd_Protocolo_Ctamed,
             v.Nr_Numero_Carteira,
             v.Nr_Guia_Prestador,
             v.Nr_Senha_Autorizacao,
             v.Cd_Prestador,
             v.Nm_Beneficiario,
             v.Nr_Guia_Operadora,
             v.Cd_Procedimento,
             To_Date(Substr(v.Dt_Procedimento, 9, 10) || '/' ||
                     Substr(v.Dt_Procedimento, 6, 2) || '/' ||
                     Substr(v.Dt_Procedimento, 1, 4),
                     'DD/MM/YYYY') Dt_Realizado
              From Dbaps.v_Tiss_Lote_Guia v
             Where v.Cd_Protocolo_Ctamed = Pcd_Protocolo_Ctamed
               And Nvl(v.Nr_Guia_Operadora, v.Nr_Guia_Prestador) Not In
                   ('101187119',
                    '101188299',
                    '101190639',
                    '101183669',
                    '101190639',
                    '101505419')
               And Exists
             (Select 1
                      From Custom.Tiss_Controle_Protocolo Tp
                     Where Tp.Cd_Protocolo_Ctamed = v.Cd_Protocolo_Ctamed
                       And Tp.Sn_Validado = 'N')) Tab
     Where (Trunc(Sysdate) - Tab.Dt_Realizado) > 70
       And Exists (Select 1
              From Dbaps.Guia g
             Where g.Nr_Guia =
                   To_Number(Custom.Pkg_Conmvs_Tiss_Xml.Fnc_Ajusta_Numero(v_String => Tab.Nr_Guia_Operadora))
               And g.Cd_Tipo_Atendimento In (1, 2, 3)
               And (g.Cd_Tipo_Atendimento_Tiss <> 3 Or
                   g.Cd_Tipo_Atendimento_Tiss Is Null)
            Union
            Select 1
              From Dbaps.Guia g
             Where g.Nr_Guia =
                   To_Number(Custom.Pkg_Conmvs_Tiss_Xml.Fnc_Ajusta_Numero(v_String => Tab.Nr_Guia_Prestador))
               And g.Cd_Tipo_Atendimento In (1, 2, 3)
               And (g.Cd_Tipo_Atendimento_Tiss <> 3 Or
                   g.Cd_Tipo_Atendimento_Tiss Is Null)
            
            );

  Cursor Cprestadorexistenaoperadora Is --CH2211-3159 18/11/2022
    Select --US016
     v.Cd_Protocolo_Ctamed,
     v.Nr_Numero_Carteira,
     v.Nr_Guia_Prestador,
     v.Nr_Senha_Autorizacao,
     v.Cd_Prestador,
     v.Nm_Beneficiario,
     v.Nr_Guia_Operadora,
     v.Cd_Procedimento,
     Upper(e.Nm_Membro_Eqp) As Nm_Membro_Eqp,
     e.Nr_Conselho_Membro_Eqp
      From Dbaps.Tiss_Lot_Guia_Fat_Resint      r,
           Dbaps.Tiss_Lot_Guia_Fat_Resint_Proc p,
           Dbaps.Tiss_Lot_Guia_Fat_Resint_Eqp  e,
           Dbaps.v_Tiss_Lote_Guia              v
     Where r.Id = p.Id_Pai -- tirar de a��o at� que seja ajustada a regra
       And p.Id = e.Id_Pai
       And v.Id_Pai = r.Id
       And e.Nr_Conselho_Membro_Eqp <> '300100'
       And v.Cd_Protocolo_Ctamed = Pcd_Protocolo_Ctamed
       And Exists
     (Select 1
              From Custom.Tiss_Controle_Protocolo Tp
             Where Tp.Cd_Protocolo_Ctamed = v.Cd_Protocolo_Ctamed
               And Tp.Sn_Validado = 'N')
          
       And Not Exists
     (Select 1
              From Dbaps.Prestador Pr
             Where Lpad(Regexp_Replace(Pr.Ds_Cod_Conselho, '[^0-9'']', ''),
                        6,
                        '0') = Lpad(e.Nr_Conselho_Membro_Eqp, 6, '0'))
    
    Union All -- sadt  
    
    Select --US016
     v.Cd_Protocolo_Ctamed,
     v.Nr_Numero_Carteira,
     v.Nr_Guia_Prestador,
     v.Nr_Senha_Autorizacao,
     v.Cd_Prestador,
     v.Nm_Beneficiario,
     v.Nr_Guia_Operadora,
     v.Cd_Procedimento,
     Upper(e.Nm_Membro_Eqp) As Nm_Membro_Eqp,
     e.Nr_Conselho_Membro_Eqp
      From Dbaps.Tiss_Lot_Guia_Fat_Sadt      r,
           Dbaps.Tiss_Lot_Guia_Fat_Sadt_Proc p,
           Dbaps.Tiss_Lot_Guia_Fat_Sadt_Eqp  e,
           Dbaps.v_Tiss_Lote_Guia            v
     Where 1 = 1 -- desabilitar at� que seja ajustada essa regra 14/10/2022 skype: 15:43  
          ---Habiltiado 18/11/2022 a pedido do chamado CH2211-3159
       And r.Id = p.Id_Pai
       And p.Id = e.Id_Pai
       And v.Id_Pai = r.Id
       And v.Cd_Protocolo_Ctamed = Pcd_Protocolo_Ctamed
       And e.Nr_Conselho_Membro_Eqp <> '300100'
       And Exists
     (Select 1
              From Custom.Tiss_Controle_Protocolo Tp
             Where Tp.Cd_Protocolo_Ctamed = v.Cd_Protocolo_Ctamed
               And Tp.Sn_Validado = 'N')
          
       And Not Exists
     (Select 1
              From Dbaps.Prestador Pr
             Where Lpad(Regexp_Replace(Pr.Ds_Cod_Conselho, '[^0-9'']', ''),
                        6,
                        '0') = Lpad(e.Nr_Conselho_Membro_Eqp, 6, '0'));
  /* Where Custom.Pkg_Conmvs_Tiss_Xml.Fnc_Ajusta_Numero(Pr.Ds_Cod_Conselho,
                                               v_Ignora_Zero_Esquerda => 'S') =
  Custom.Pkg_Conmvs_Tiss_Xml.Fnc_Ajusta_Numero(e.Nr_Conselho_Membro_Eqp,
                                               v_Ignora_Zero_Esquerda => 'S'))*/

  -- CH2209-4741 TRAVA NO XML PARA SENHA EXTERNA COM valor = "0"         
  Cursor c_Guia_Prestador_Valor_0 Is
    Select --US017
     v.Cd_Protocolo_Ctamed,
     v.Nr_Numero_Carteira,
     v.Nr_Guia_Prestador,
     v.Nr_Senha_Autorizacao,
     v.Cd_Prestador,
     v.Nm_Beneficiario,
     v.Nr_Guia_Operadora,
     v.Cd_Procedimento
      From Dbaps.v_Tiss_Lote_Guia v
     Where v.Cd_Protocolo_Ctamed = Pcd_Protocolo_Ctamed
       And v.Nr_Guia_Prestador = '0'
       And Exists
     (Select 1
              From Custom.Tiss_Controle_Protocolo Tp
             Where Tp.Cd_Protocolo_Ctamed = v.Cd_Protocolo_Ctamed
               And Tp.Sn_Validado = 'N');

  --CH2209-5396  TRAVA GUIA INEXISTENTE NA OPERADORA  
  Cursor Cguiainexistente Is
    Select --US020
     v.Cd_Protocolo_Ctamed,
     v.Nr_Numero_Carteira,
     v.Nr_Guia_Prestador,
     v.Nr_Senha_Autorizacao,
     v.Cd_Prestador,
     v.Nm_Beneficiario,
     v.Nr_Guia_Operadora,
     v.Cd_Procedimento
      From Dbaps.v_Tiss_Lote_Guia v
     Where v.Cd_Protocolo_Ctamed = Pcd_Protocolo_Ctamed
       And v.Nr_Guia_Operadora Is Not Null
       And Not Exists (Select 1
              From Dbaps.Guia g
             Where g.Nr_Guia = v.Nr_Guia_Operadora)
       And Exists
     (Select 1
              From Custom.Tiss_Controle_Protocolo Tp
             Where Tp.Cd_Protocolo_Ctamed = v.Cd_Protocolo_Ctamed
               And Tp.Sn_Validado = 'N');

  --16/11/2022 Desenvolvedor Josiel CH2209-5400           
  Cursor Ccodracionalizacaosemautoriza Is
    Select --US022
     v.Cd_Protocolo_Ctamed,
     v.Nr_Numero_Carteira,
     v.Nr_Guia_Prestador,
     v.Nr_Senha_Autorizacao,
     v.Cd_Prestador,
     v.Nm_Beneficiario,
     v.Nr_Guia_Operadora,
     v.Cd_Procedimento
      From Dbaps.v_Tiss_Lote_Guia v
     Where v.Cd_Protocolo_Ctamed = Pcd_Protocolo_Ctamed
       And Substr(v.Nr_Numero_Carteira, 1, 3) != '018' -- CH2212-0081 DEIXAR PRESTADOR 300100 EM EXCECAO DA REGRA QUANDO FOR 018
       And Exists
     (Select 1
              From Custom.Tiss_Controle_Protocolo Tp
             Where Tp.Cd_Protocolo_Ctamed = v.Cd_Protocolo_Ctamed
               And Tp.Sn_Validado = 'N')
       And (v.Nr_Senha_Autorizacao Is Null Or v.Nr_Senha_Autorizacao = '0')
       And Exists
     (Select 1
              From Dbaps.Procedimento p, Dbaps.Grupo_Procedimento Gp
             Where p.Cd_Grupo_Procedimento = Gp.Cd_Grupo_Procedimento
               And p.Cd_Procedimento = v.Cd_Procedimento
               And Gp.Tp_Gru_Pro In ('SD', 'SP')
               And Not Exists
             (Select 2
                      From Dbaps.Procedimento_Baixo_Risco Pbr
                     Where Pbr.Cd_Procedimento = p.Cd_Procedimento
                       And To_Date(Pbr.Dt_Vigencia, 'DD/MM/YYYY') <=
                           To_Date(Sysdate, 'DD/MM/YYYY')));

  Cursor Cobrigaprestadorspsd Is --CH2211-3159 18/11/2022
    Select --US023
     v.Cd_Protocolo_Ctamed,
     v.Nr_Numero_Carteira,
     v.Nr_Guia_Prestador,
     v.Nr_Senha_Autorizacao,
     v.Cd_Prestador,
     v.Nm_Beneficiario,
     v.Nr_Guia_Operadora,
     v.Cd_Procedimento,
     Upper(e.Nm_Membro_Eqp) As Nm_Membro_Eqp,
     e.Nr_Conselho_Membro_Eqp
      From Dbaps.Tiss_Lot_Guia_Fat_Resint      r,
           Dbaps.Tiss_Lot_Guia_Fat_Resint_Proc p,
           Dbaps.Tiss_Lot_Guia_Fat_Resint_Eqp  e,
           Dbaps.v_Tiss_Lote_Guia              v
     Where r.Id = p.Id_Pai -- tirar de a��o at� que seja ajustada a regra
       And p.Id = e.Id_Pai
       And v.Id_Pai = r.Id
       And v.Cd_Protocolo_Ctamed = Pcd_Protocolo_Ctamed
       And v.Cd_Procedimento = p.Cd_Procedimento
          --  And e.Nr_Conselho_Membro_Eqp != '300100' -- 04/10/2022 skype: Josiel, tira o 300100 do prestador inexistente
          ---Habiltiado 18/11/2022 a pedido do chamado CH2211-3159     
       And Exists
     (Select 1
              From Custom.Tiss_Controle_Protocolo Tp
             Where Tp.Cd_Protocolo_Ctamed = v.Cd_Protocolo_Ctamed
               And Tp.Sn_Validado = 'N')
          
       And Exists
     (Select 1
              From Procedimento p
             Where p.Cd_Procedimento = v.Cd_Procedimento
               And Exists
             (Select 1
                      From Grupo_Procedimento Gp
                     Where Gp.Cd_Grupo_Procedimento = p.Cd_Grupo_Procedimento
                       And Gp.Tp_Gru_Pro = 'SP')
            Union
            
            Select 1
              From Procedimento p
             Where p.Cd_Procedimento = v.Cd_Procedimento
               And Exists
             (Select 1
                      From Grupo_Procedimento Gp
                     Where Gp.Cd_Grupo_Procedimento = p.Cd_Grupo_Procedimento
                       And Gp.Tp_Gru_Pro = 'SD')
               And p.Ds_Classe In
                   ('FISIOTERAPIAS', 'TERAPIAS', 'TERAPIAS ESPECIALIZADAS'))
          
       And Not Exists
     (Select 1
              From Dbaps.Prestador Pr
             Where Lpad(Regexp_Replace(Pr.Ds_Cod_Conselho, '[^0-9'']', ''),
                        6,
                        '0') =
                   Decode(Lpad(e.Nr_Conselho_Membro_Eqp, 6, '0'),
                          '300100',
                          Lpad(Pr.Ds_Cod_Conselho, 6, '0'),
                          Lpad(e.Nr_Conselho_Membro_Eqp, 6, '0')))
    
    Union All -- sadt  
    
    Select --US023
     v.Cd_Protocolo_Ctamed,
     v.Nr_Numero_Carteira,
     v.Nr_Guia_Prestador,
     v.Nr_Senha_Autorizacao,
     v.Cd_Prestador,
     v.Nm_Beneficiario,
     v.Nr_Guia_Operadora,
     v.Cd_Procedimento,
     Upper(e.Nm_Membro_Eqp) As Nm_Membro_Eqp,
     e.Nr_Conselho_Membro_Eqp
      From Dbaps.Tiss_Lot_Guia_Fat_Sadt      r,
           Dbaps.Tiss_Lot_Guia_Fat_Sadt_Proc p,
           Dbaps.Tiss_Lot_Guia_Fat_Sadt_Eqp  e,
           Dbaps.v_Tiss_Lote_Guia            v
     Where 1 = 1 -- desabilitar at� que seja ajustada essa regra 14/10/2022 skype: 15:43  
          ---Habiltiado 18/11/2022 a pedido do chamado CH2211-3159
       And r.Id = p.Id_Pai
       And p.Id = e.Id_Pai
       And v.Id_Pai = r.Id
       And v.Cd_Protocolo_Ctamed = Pcd_Protocolo_Ctamed
       And v.Cd_Procedimento = p.Cd_Procedimento
       And Exists
     (Select 1
              From Custom.Tiss_Controle_Protocolo Tp
             Where Tp.Cd_Protocolo_Ctamed = v.Cd_Protocolo_Ctamed
               And Tp.Sn_Validado = 'N')
          
       And Exists
     (Select 1
              From Procedimento p
             Where p.Cd_Procedimento = v.Cd_Procedimento
               And Exists
             (Select 1
                      From Grupo_Procedimento Gp
                     Where Gp.Cd_Grupo_Procedimento = p.Cd_Grupo_Procedimento
                       And Gp.Tp_Gru_Pro = 'SP')
            Union
            
            Select 1
              From Procedimento p
             Where p.Cd_Procedimento = v.Cd_Procedimento
               And Exists
             (Select 1
                      From Grupo_Procedimento Gp
                     Where Gp.Cd_Grupo_Procedimento = p.Cd_Grupo_Procedimento
                       And Gp.Tp_Gru_Pro = 'SD')
               And p.Ds_Classe In
                   ('FISIOTERAPIAS', 'TERAPIAS', 'TERAPIAS ESPECIALIZADAS'))
       And Not Exists
     (Select 1
              From Dbaps.Prestador Pr
             Where Lpad(Regexp_Replace(Pr.Ds_Cod_Conselho, '[^0-9'']', ''),
                        6,
                        '0') =
                   Decode(Lpad(e.Nr_Conselho_Membro_Eqp, 6, '0'),
                          '300100',
                          Lpad(Pr.Ds_Cod_Conselho, 6, '0'),
                          Lpad(e.Nr_Conselho_Membro_Eqp, 6, '0')));
  /*Custom.Pkg_Conmvs_Tiss_Xml.Fnc_Ajusta_Numero(Pr.Ds_Cod_Conselho,
                                               v_Ignora_Zero_Esquerda => 'S') =
  Custom.Pkg_Conmvs_Tiss_Xml.Fnc_Ajusta_Numero(Decode(e.Nr_Conselho_Membro_Eqp,
                                                      '300100',
                                                      Pr.Ds_Cod_Conselho,
                                                      e.Nr_Conselho_Membro_Eqp),
                                               v_Ignora_Zero_Esquerda => 'S'));*/

  Cursor Cvalorreducaoacrescimoproc Is
  
    Select --US027
     v.Cd_Protocolo_Ctamed,
     v.Nr_Numero_Carteira,
     v.Nr_Guia_Prestador,
     v.Nr_Senha_Autorizacao,
     v.Cd_Prestador,
     v.Nm_Beneficiario,
     v.Nr_Guia_Operadora,
     v.Cd_Tipo_Atendimento,
     v.Cd_Procedimento
      From v_Tiss_Lote_Guia v
     Where v.Cd_Protocolo_Ctamed = Pcd_Protocolo_Ctamed
       And v.Cd_Procedimento = '41001133'
       And (v.Vl_Perc_Reducao_Acrescimo Not In ('1.00', '100') Or
           v.Vl_Perc_Reducao_Acrescimo Is Null)
       And Exists
     (Select 1
              From Custom.Tiss_Controle_Protocolo Tp
             Where Tp.Cd_Protocolo_Ctamed = v.Cd_Protocolo_Ctamed
               And Tp.Sn_Validado = 'N');

  Cursor Ctipoatendimentotisscod Is
    Select --US029
     v.Cd_Protocolo_Ctamed,
     v.Nr_Numero_Carteira,
     v.Nr_Guia_Prestador,
     v.Nr_Senha_Autorizacao,
     v.Cd_Prestador,
     v.Nm_Beneficiario,
     v.Nr_Guia_Operadora,
     v.Cd_Tipo_Atendimento,
     v.Cd_Tipo_Internacao,
     v.Cd_Procedimento
      From v_Tiss_Lote_Guia v
     Where v.Cd_Protocolo_Ctamed = Pcd_Protocolo_Ctamed
       And v.Cd_Tipo_Atendimento <> 22
       And v.Cd_Procedimento = '10101063'
       And Exists
     (Select 1
              From Custom.Tiss_Controle_Protocolo Tp
             Where Tp.Cd_Protocolo_Ctamed = v.Cd_Protocolo_Ctamed
               And Tp.Sn_Validado = 'N');

  Cursor Ctipoatendimentoproc Is
  
    Select --US026
     v.Cd_Protocolo_Ctamed,
     v.Nr_Numero_Carteira,
     v.Nr_Guia_Prestador,
     v.Nr_Senha_Autorizacao,
     v.Cd_Prestador,
     v.Nm_Beneficiario,
     v.Nr_Guia_Operadora,
     v.Cd_Tipo_Atendimento,
     v.Cd_Tipo_Internacao
      From v_Tiss_Lote_Guia v
     Where v.Cd_Protocolo_Ctamed = Pcd_Protocolo_Ctamed
      And Not Exists
  (Select 1
           From Dbaps.Guia g, Dbaps.Itguia It
          Where g.Nr_Guia = It.Nr_Guia
            And g.Nr_Guia = v.Nr_Guia_Operadora
            And It.Cd_Procedimento In ('20104243',
                                       '20104260',
                                       '20104278',
                                       '20104286',
                                       '20104294',
                                       '20104308',
                                       '20104430'))
    And v.Cd_Tipo_Atendimento IN('8','08')
       And Exists
     (Select 1
              From Custom.Tiss_Controle_Protocolo Tp
             Where Tp.Cd_Protocolo_Ctamed = v.Cd_Protocolo_Ctamed
               And Tp.Sn_Validado = 'N');

  Cursor Cguiaexternaduplicada Is
    Select Distinct --US031
                    v.Cd_Protocolo_Ctamed,
                    v.Nr_Numero_Carteira,
                    v.Nr_Guia_Prestador,
                    v.Nr_Senha_Autorizacao,
                    v.Cd_Prestador,
                    v.Nm_Beneficiario,
                    v.Nr_Guia_Operadora
      From Dbaps.v_Tiss_Lote_Guia v
     Where v.Cd_Protocolo_Ctamed = Pcd_Protocolo_Ctamed
       And v.Cd_Tipo_Atendimento = 1
       And Exists (Select 1
              From Dbaps.Remessa_Prestador Rp
             Where Rp.Cd_Guia_Externa = v.Nr_Guia_Prestador)
          
       And Exists
     (Select 1
              From Custom.Tiss_Controle_Protocolo Tp
             Where Tp.Cd_Protocolo_Ctamed = v.Cd_Protocolo_Ctamed
               And Tp.Sn_Validado = 'N')
    
    Union All
    --Interna��o
    Select Distinct --US031 
                    v.Cd_Protocolo_Ctamed,
                    v.Nr_Numero_Carteira,
                    v.Nr_Guia_Prestador,
                    v.Nr_Senha_Autorizacao,
                    v.Cd_Prestador,
                    v.Nm_Beneficiario,
                    v.Nr_Guia_Operadora
      From Dbaps.v_Tiss_Lote_Guia v, Dbaps.Tiss_Lot_Guia_Fat_Resint Iod
     Where v.Cd_Protocolo_Ctamed = Pcd_Protocolo_Ctamed
       And Iod.Id = v.Id_Pai
       And Iod.Cd_Tipo_Faturamento Not In (1, 2, 3)
       And Exists (Select 1
              From Dbaps.Conta_Hospitalar Ch
             Where Ch.Cd_Guia_Externa = v.Nr_Guia_Prestador
               And Rownum = 1)
          
       And Exists
     (Select 1
              From Custom.Tiss_Controle_Protocolo Tp
             Where Tp.Cd_Protocolo_Ctamed = v.Cd_Protocolo_Ctamed
               And Tp.Sn_Validado = 'N')
    
    Union All --(SADT)
    
    Select Distinct --US031
                    v.Cd_Protocolo_Ctamed,
                    v.Nr_Numero_Carteira,
                    v.Nr_Guia_Prestador,
                    v.Nr_Senha_Autorizacao,
                    v.Cd_Prestador,
                    v.Nm_Beneficiario,
                    v.Nr_Guia_Operadora
      From Dbaps.v_Tiss_Lote_Guia v
     Where v.Cd_Protocolo_Ctamed = Pcd_Protocolo_Ctamed
          
       And v.Cd_Tipo_Atendimento Not In (3, 8, 10)
          
       And Not Exists
     (Select 1
              From Dbaps.v_Tiss_Lote_Guia Vv
             Where Vv.Cd_Protocolo_Ctamed = v.Cd_Protocolo_Ctamed
               And Vv.Cd_Procedimento = '60033746'
               And Rownum = 1)
          
       And Exists
     (Select 1
              From Custom.Tiss_Controle_Protocolo Tp
             Where Tp.Cd_Protocolo_Ctamed = v.Cd_Protocolo_Ctamed
               And Tp.Sn_Validado = 'N')
          
       And Exists (Select 1
              From Dbaps.Remessa_Prestador Rp
             Where Rp.Cd_Guia_Externa = v.Nr_Guia_Prestador
               And Rownum = 1);

  Cursor Creducaoacrescimo Is
    Select --US032 
     v.Cd_Protocolo_Ctamed,
     v.Nr_Numero_Carteira,
     v.Nr_Guia_Prestador,
     v.Nr_Senha_Autorizacao,
     v.Cd_Prestador,
     v.Nm_Beneficiario,
     v.Nr_Guia_Operadora
      From v_Tiss_Lote_Guia v
     Where v.Cd_Protocolo_Ctamed = Pcd_Protocolo_Ctamed
       And Exists
     (Select 1
              From Custom.Tiss_Controle_Protocolo Tp
             Where Tp.Cd_Protocolo_Ctamed = v.Cd_Protocolo_Ctamed
               And Tp.Sn_Validado = 'N')
       And Exists
     (Select 1
              From Dbaps.Procedimento p, Dbaps.Grupo_Procedimento Gp
             Where p.Cd_Grupo_Procedimento = Gp.Cd_Grupo_Procedimento
               And p.Cd_Procedimento = v.Cd_Procedimento
               And Gp.Tp_Gru_Pro In ('SP', 'SD'))
       And (v.Vl_Perc_Reducao_Acrescimo Not In
           ('0.30',
             '0.20',
             '020',
             '030',
             '0.50',
             '0.70',
             '0.80',
             '100',
             '1.00',
             '130',
             '1.30',
             '160',
             '1.60') Or v.Vl_Perc_Reducao_Acrescimo Is Null Or Exists
            (Select 1
               From Dbaps.Tiss_Lot_Guia_Fat_Resint_Proc Tlf,
                    Dbaps.Tiss_Lot_Guia_Fat_Resint_Eqp  Eqi
              Where v.Id = Tlf.Id
                And Tlf.Id = Eqi.Id_Pai
                And Eqi.Cd_Posicao_Profissional Not In ('01', '1')
                And v.Vl_Perc_Reducao_Acrescimo In
                    ('0.30', '030', '0.20', '020')
             
             Union All
             
             Select 1
               From Dbaps.Tiss_Lot_Guia_Fat_Sadt_Proc Tlf,
                    Dbaps.Tiss_Lot_Guia_Fat_Sadt_Eqp  Eqs
              Where v.Id = Tlf.Id
                And Tlf.Id = Eqs.Id_Pai
                And Eqs.Cd_Posicao_Profissional Not In ('01', '1')
                And v.Vl_Perc_Reducao_Acrescimo In
                    ('0.30', '030', '0.20', '020')
             
             Union All
             
             Select 1
               From Dbaps.Tiss_Lot_Guia_Fat_Hono_Proc Tlf,
                    Dbaps.Tiss_Lot_Guia_Fat_Hono_Eqp  Eqh
              Where v.Id = Tlf.Id
                And Tlf.Id = Eqh.Id_Pai
                And Eqh.Cd_Grau_Part Not In ('01', '1')
                And v.Vl_Perc_Reducao_Acrescimo In
                    ('0.30', '030', '0.20', '020')
             
             )
           
           )
    
    Union All ---MD, MT, OP, DI
    
    Select --US032
     v.Cd_Protocolo_Ctamed,
     v.Nr_Numero_Carteira,
     v.Nr_Guia_Prestador,
     v.Nr_Senha_Autorizacao,
     v.Cd_Prestador,
     v.Nm_Beneficiario,
     v.Nr_Guia_Operadora
      From v_Tiss_Lote_Guia v
     Where v.Cd_Protocolo_Ctamed = Pcd_Protocolo_Ctamed
       And Exists
     (Select 1
              From Custom.Tiss_Controle_Protocolo Tp
             Where Tp.Cd_Protocolo_Ctamed = v.Cd_Protocolo_Ctamed
               And Tp.Sn_Validado = 'N')
          
       And Exists
     (Select 1
              From Dbaps.Procedimento p, Dbaps.Grupo_Procedimento Gp
             Where p.Cd_Grupo_Procedimento = Gp.Cd_Grupo_Procedimento
               And p.Cd_Procedimento = v.Cd_Procedimento
               And Gp.Tp_Gru_Pro In ('MD', 'MT', 'OP', 'DI'))
       And (v.Vl_Perc_Reducao_Acrescimo Not In ('100', '1.00') Or
           v.Vl_Perc_Reducao_Acrescimo Is Null)
    
    Union All
    
    --TX
    Select --US032
     v.Cd_Protocolo_Ctamed,
     v.Nr_Numero_Carteira,
     v.Nr_Guia_Prestador,
     v.Nr_Senha_Autorizacao,
     v.Cd_Prestador,
     v.Nm_Beneficiario,
     v.Nr_Guia_Operadora
      From v_Tiss_Lote_Guia v
     Where v.Cd_Protocolo_Ctamed = Pcd_Protocolo_Ctamed
       And Exists
     (Select 1
              From Custom.Tiss_Controle_Protocolo Tp
             Where Tp.Cd_Protocolo_Ctamed = v.Cd_Protocolo_Ctamed
               And Tp.Sn_Validado = 'N')
          
       And Exists
     (Select 1
              From Dbaps.Procedimento p, Dbaps.Grupo_Procedimento Gp
             Where p.Cd_Grupo_Procedimento = Gp.Cd_Grupo_Procedimento
               And p.Cd_Procedimento = v.Cd_Procedimento
               And Gp.Tp_Gru_Pro = 'TX')
       And (v.Vl_Perc_Reducao_Acrescimo Not In
           ('100', '1.00', '050', '0.50') Or
           v.Vl_Perc_Reducao_Acrescimo Is Null);

  Cursor Cvalidaguiaprincipalsadt Is
    Select -- US033
     v.Cd_Protocolo_Ctamed,
     v.Nr_Numero_Carteira,
     v.Nr_Guia_Prestador,
     v.Nr_Senha_Autorizacao,
     v.Cd_Prestador,
     v.Nm_Beneficiario,
     v.Nr_Guia_Operadora
      From v_Tiss_Lote_Guia v
     Where 1 = 1
       And Exists
     (Select 1
              From Custom.Tiss_Controle_Protocolo Tp
             Where Tp.Cd_Protocolo_Ctamed = v.Cd_Protocolo_Ctamed
               And Tp.Sn_Validado = 'N')
       And Not Exists (Select 1
              From Dbaps.Tiss_Lot_Guia_Fat_Resint r
             Where v.Id_Pai = r.Id) -- n�o � uma interna��o ent�o trava
       And v.Cd_Protocolo_Ctamed = Pcd_Protocolo_Ctamed
       And v.Nr_Guia_Principal Is Not Null;

  --DELCARA��O DE VARI�VEIS de controle

  Rvtissloteguia                Cvtissloteguia%Rowtype;
  Rprotocoloctamed              Cprotocoloctamed%Rowtype;
  Vvalidacarteira               Cvalidacarteira%Rowtype;
  Vverificaconsultaps           Cverificaconsultaps%Rowtype;
  Vtipointernacao               Ctipointernacao%Rowtype;
  Vguiasduplicadas              Cguiasduplicadas%Rowtype;
  Vcodigoinexistente            Ccodigoinexistente%Rowtype;
  Vguiavencida                  Cguiavencida%Rowtype;
  Vdadosprocprestador           Cdadosprocprestador%Rowtype;
  Vprazoexcecidoportal          Cprazoexcecidoportal%Rowtype;
  Vlimitetaxa                   Climitetaxa%Rowtype;
  Vguiaexecucao70dias           Cguiaexecucao70dias%Rowtype;
  Vprestadorexistenaoperadora   Cprestadorexistenaoperadora%Rowtype;
  Vc_Guia_Prestador_Valor_0     c_Guia_Prestador_Valor_0%Rowtype;
  Vc_Dt_Realizado_Is_Null       c_Dt_Realizado_Is_Null%Rowtype;
  Vguiainexistente              Cguiainexistente%Rowtype;
  Vcodracionalizacaosemautoriza Ccodracionalizacaosemautoriza%Rowtype;
  Vobrigaprestadorspsd          Cobrigaprestadorspsd%Rowtype;
  Vvalorreducaoacrescimo        Cvalorreducaoacrescimoproc%Rowtype;
  Vtipoatendimentotisscod       Ctipoatendimentotisscod%Rowtype;
  Vtipoatendimentoproc          Ctipoatendimentoproc%Rowtype;
  Vguiaexternaduplicada         Cguiaexternaduplicada%Rowtype;
  Vreducaoacrescimo             Creducaoacrescimo%Rowtype;
  Vdeclaracaonascidoouobtito    Cdeclaracaonascidoouobtito%Rowtype;
  Vdeclaracaobtito              Cdeclaracaoobito%Rowtype;
  Vobrigagrauparticipacao       Cobrigagrauparticipacao%Rowtype;
  Vvalidaguiaprincipalsadt      Cvalidaguiaprincipalsadt%Rowtype;

  --Variaveis de auxilio
  Vcoderro              Varchar2(10);
  Vretorno_Unidade      Varchar2(5000);
  Vretorno_Procedimento Varchar2(5000);
  Nqtderrostotal        Number;
  Nqtderros             Number;
  Vexcecao              Varchar2(1000);
  Vexcecaolinha         Varchar2(1000);
  Vdatavencimento       Varchar2(30) := '';
  Nqtderrostotal2       Pls_Integer := 0;
  Vhtml                 Clob := '';
  Vloteprestador        Varchar2(2000) := '';
  Vtamanhoemail         Number := 0;
  Vcarteirautilizada    Varchar2(30) := '';
  --Vquantidadeultrapassada    Cquantidadeultrapassada%Rowtype;

  --
  --
  Procedure Prc_Insere_Log_Erro(p_Numero_Carteira       In Varchar2,
                                p_Numero_Guia_Prestador In Varchar2,
                                p_Numero_Guia_Operadora In Varchar2,
                                p_Numero_Senha          In Varchar2,
                                p_Codigo_Prestador      In Varchar2,
                                p_Nm_Beneficiario       In Varchar2,
                                p_Node_Xml              In Varchar2,
                                p_Node_Xml_Sub          In Varchar2,
                                p_Ds_Erro               In Varchar2,
                                p_Cd_Erro               In Varchar2,
                                p_Tp_Erro               In Varchar2,
                                p_Sn_Guia_Web           In Varchar2 Default 'N',
                                p_Procedimento          In Varchar2 Default Null) Is
  
    Binsereerro Boolean;
    Nteste      Number;
    Vdescricao  Varchar2(6000 Char) := p_Ds_Erro;
  Begin
    -- G -> ERRO DE GUIA - APENAS UMA OCORRENCIA
    -- I -> ERRO DE ITEM DE GUIA - VARIAS OCORRENCIAS
    Binsereerro := True;
    Nteste      := Null;
    /*
     - String de apresenta��o para o PDF do PORTAL.:
    '[G001] - SENHA: XXXXXXXXX - GUIA PRESTADOR: XXXXXXXXX - Descri��o do Problema.';
    '[P001] - SENHA: XXXXXXXXX - GUIA PRESTADOR: XXXXXXXXX - PROCEDIMENTO - Descri��o do Problema.';
     - Para o autorizador a string ser� simples!
    '[G001 ou P001] - Descri��o do Problema.';
    */
  
    If (p_Tp_Erro = 'G') Then
      Vdescricao := Vdescricao;
    Else
      Vdescricao := p_Ds_Erro;
    End If;
    If p_Tp_Erro = 'G' Then
      Open Cexisteerro(p_Cd_Erro,
                       Pcd_Protocolo_Ctamed,
                       p_Numero_Guia_Prestador);
      Fetch Cexisteerro
        Into Nteste;
      If Cexisteerro%Found Then
        Binsereerro := False;
      End If;
      Close Cexisteerro;
    End If;
  
    If Binsereerro Then
      Insert Into Dbaps.Log_Erro_Protocolo_Tiss
        (Cd_Log_Erro_Protocolo_Tiss,
         Cd_Protocolo_Ctamed,
         Ds_Carteira_Beneficiario,
         Ds_Guia_Prestador,
         Ds_Guia_Operadora,
         Ds_Codigo_Prestador,
         Nm_Beneficiario,
         Ds_Tipo_Guia,
         Ds_Node_Xml,
         Ds_Node_Xml_Sub,
         Ds_Erro,
         Cd_Erro)
      Values
        (Dbaps.Seq_Mvs_Log_Erro_Proto_Tiss.Nextval,
         Pcd_Protocolo_Ctamed,
         p_Numero_Carteira,
         p_Numero_Guia_Prestador,
         p_Numero_Guia_Operadora,
         p_Codigo_Prestador,
         p_Nm_Beneficiario,
         'IOD',
         p_Node_Xml,
         p_Node_Xml_Sub,
         Vdescricao,
         Substr(p_Cd_Erro, 0, 100));
      Commit;
    End If;
  End;

Begin

  Execute Immediate 'ALTER SESSION
SET NLS_DATE_LANGUAGE = "BRAZILIAN PORTUGUESE"
NLS_NUMERIC_CHARACTERS = ",."
NLS_DATE_FORMAT = "DD/MM/YYYY"
NLS_LANGUAGE = "BRAZILIAN PORTUGUESE"
NLS_SORT = "BINARY"
NLS_TIME_FORMAT = "HH24:MI:SSXFF"
NLS_COMP = "BINARY"';

  Nqtderrostotal := 0;
  Nqtderros      := 0;
  -- REMOVENDO LOG ANTIGO

  Rprotocoloctamed := Null;
  Open Cprotocoloctamed(Pcd_Protocolo_Ctamed);
  Fetch Cprotocoloctamed
    Into Rprotocoloctamed;
  Close Cprotocoloctamed;

  --
  --****************************
  --* CURSOR DO CABE�ALHO DO PROTOCOLO
  --****************************
  --
  Open Cvtissloteguia(Pcd_Protocolo_Ctamed);
  Loop
    Fetch Cvtissloteguia
      Into Rvtissloteguia;
    Begin
      --EXCEPTION DE GUIA
      If Cvtissloteguia%Notfound Then
        Exit;
      End If;
    
      -- if rVTissLoteGuia.Cd_Prestador = 1001153 then
    
      --Verifica se a unidade de medida esta correta
      --Verifica se procediemnto esta inativo 
      If (Custom.Pkg_Conmvs_Tiss_Xml.Fnc_Motivo_Portal(Pcd_Motivo       => 'US001',
                                                       p_Sn_Web_Service => 'S') = 'S') Then
        Begin
          Select To_Char(Dbaps.Fnc_Verifica_Procedimento_Tes1(Rvtissloteguia.Cd_Protocolo_Ctamed,
                                                              Rvtissloteguia.Nr_Guia_Operadora,
                                                              Rvtissloteguia.Cd_Procedimento))
            Into Vretorno_Procedimento
            From Dual;
        
          Select To_Char(Dbaps.Fnc_Retorna_Unidade_Med_Tes1(Rvtissloteguia.Cd_Protocolo_Ctamed,
                                                            Rvtissloteguia.Nr_Guia_Operadora,
                                                            Rvtissloteguia.Cd_Procedimento))
            Into Vretorno_Unidade
            From Dual;
        Exception
          When Others Then
            Prc_Insere_Log_Erro(Rvtissloteguia.Nr_Numero_Carteira,
                                Rvtissloteguia.Nr_Guia_Prestador,
                                Rvtissloteguia.Nr_Guia_Operadora,
                                Rvtissloteguia.Nr_Senha_Autorizacao,
                                Rvtissloteguia.Cd_Prestador,
                                Rvtissloteguia.Nm_Beneficiario,
                                --'',
                                '',
                                '',
                                'Falha ao consultar Unidade medida/Procedimento --> US001',
                                -- Lpad(Vretorno_Procedimento, 1900) || ')',
                                'US001',
                                'I',
                                'N');
          
        End;
        If ((Upper(Vretorno_Procedimento) <> 'OK' And
           Upper(Vretorno_Unidade) = 'OK') Or
           (Upper(Vretorno_Procedimento) <> 'OK' And
           Upper(Vretorno_Unidade) <> 'OK')) Then
        
          Nqtderros := Nqtderros + 1;
          Vcoderro  := 'US001';
          Prc_Insere_Log_Erro(Rvtissloteguia.Nr_Numero_Carteira,
                              Rvtissloteguia.Nr_Guia_Prestador,
                              Rvtissloteguia.Nr_Guia_Operadora,
                              Rvtissloteguia.Nr_Senha_Autorizacao,
                              Rvtissloteguia.Cd_Prestador,
                              Rvtissloteguia.Nm_Beneficiario,
                              --'',
                              '',
                              '',
                              'PROCEDIMENTO INATIVO: ( ' ||
                              Substr(Vretorno_Procedimento, 0, 1950) || ' )',
                              -- Lpad(Vretorno_Procedimento, 1900) || ')',
                              'US001',
                              'I',
                              'N');
        
        Elsif (Upper(Vretorno_Procedimento) = 'OK' And
              Upper(Vretorno_Unidade) <> 'OK') Then
          Nqtderros := Nqtderros + 1;
          Vcoderro  := 'US001';
          Prc_Insere_Log_Erro(Rvtissloteguia.Nr_Numero_Carteira,
                              Rvtissloteguia.Nr_Guia_Prestador,
                              Rvtissloteguia.Nr_Guia_Operadora,
                              Rvtissloteguia.Nr_Senha_Autorizacao,
                              Rvtissloteguia.Cd_Prestador,
                              Rvtissloteguia.Nm_Beneficiario,
                              --rVTissLoteGuia.DS_TP_PROTOCOLO,
                              '',
                              '',
                              'UNIDADE DE MEDIDA INCORRETA: ( ' ||
                              Substr(Vretorno_Unidade, 0, 1950) || ' )',
                              --Lpad(Vretorno_Unidade, 1900) || ')',
                              'US001',
                              'I',
                              'N');
        
        End If;
      End If;
      Commit;
    
      --EXCEPTION A NIVEL DE GUIA PARA PROIBIR TODAS EM CASO DE PROBLEMA NO BANCO
    Exception
      When Others Then
        Vexcecao      := Sqlerrm;
        Vexcecaolinha := Dbms_Utility.Format_Error_Backtrace;
        Vcoderro      := 'E999';
        Prc_Insere_Log_Erro(Rvtissloteguia.Nr_Numero_Carteira,
                            Rvtissloteguia.Nr_Guia_Prestador,
                            Rvtissloteguia.Nr_Guia_Operadora,
                            Rvtissloteguia.Nr_Senha_Autorizacao,
                            Rvtissloteguia.Cd_Prestador,
                            Rvtissloteguia.Nm_Beneficiario,
                            '',
                            '',
                            'EXCEPTION-GUIA! N�o foi possivel validar as regras --> US001. Favor entre em contato com a Operadora MSG: ' ||
                            Vexcecao || ' linha do erro: ' || Vexcecaolinha,
                            Vcoderro,
                            'E',
                            'N');
        Commit;
      
    End; --EXCEPTION DE GUIA 
  
    Nqtderrostotal := Nqtderrostotal + Nqtderros;
  End Loop;

  -- FIM DO LOOP DE GUIAS
  Close Cvtissloteguia;
  --nQtdErrosTotal := nQtdErrosTotal + nQtdErros;

  --Mois�s 25/03/2022 --> (CH2203-0567) N�o permitir a postagem de arquivo com consulta 10101039 COM o CD_TIPO_ATENDIMENTO_TISS <>11
  If (Custom.Pkg_Conmvs_Tiss_Xml.Fnc_Motivo_Portal(Pcd_Motivo       => 'US002',
                                                   p_Sn_Web_Service => 'S') = 'S') Then
    Begin
    
      For Vverificaconsultaps In Cverificaconsultaps Loop
      
        Begin
        
          Prc_Insere_Log_Erro(Vverificaconsultaps.Nr_Numero_Carteira,
                              Vverificaconsultaps.Nr_Guia_Prestador,
                              Vverificaconsultaps.Nr_Guia_Operadora,
                              Vverificaconsultaps.Nr_Senha_Autorizacao,
                              Vverificaconsultaps.Cd_Prestador,
                              Vverificaconsultaps.Nm_Beneficiario,
                              '',
                              '',
                              'Conforme o padr�o TISS para procedimento de Consulta de Pronto Socorro �
                             necess�rio informar o CD_ATENDIMENTO_TISS no valor 11. Guia: ' ||
                              Vverificaconsultaps.Nr_Guia_Operadora ||
                              ' Tipo de atendimento Tiss: ' ||
                              Vverificaconsultaps.Cd_Tipo_Atendimento,
                              'US002',
                              'I',
                              'N');
        
        End;
      End Loop;
      Commit;
    
    Exception
      When Others Then
        Dbms_Output.Put_Line('exception-gral');
        Vexcecao      := Sqlerrm;
        Vexcecaolinha := Dbms_Utility.Format_Error_Backtrace;
        Vcoderro      := 'E999';
        Prc_Insere_Log_Erro(Vverificaconsultaps.Nr_Numero_Carteira,
                            Vverificaconsultaps.Nr_Guia_Prestador,
                            Vverificaconsultaps.Nr_Guia_Operadora,
                            Vverificaconsultaps.Nr_Senha_Autorizacao,
                            Vverificaconsultaps.Cd_Prestador,
                            Vverificaconsultaps.Nm_Beneficiario,
                            '',
                            '',
                            'EXCEPTION-GLOBAL! N�o foi possivel validar as regras --> US002. Favor entre em contato com a Operadora MSG: ' ||
                            Vexcecao || ' linha do erro: ' || Vexcecaolinha,
                            Vcoderro,
                            'E',
                            'N');
        Commit;
        If (Cverificaconsultaps%Isopen) Then
          Close Cverificaconsultaps;
        End If;
      
    End;
  End If;
  -- Mois�s --> 12/04/2022 atender ao requisito do manual do PTU XML --> CH2202-2485 (travar quando for guia de interna��o, conter os procedimento
  --31309038, 31309054, 31309097, 31309127 e 31309135, e n�o tiver o CD_TIPO_INTERNACAO = 3.

  If (Custom.Pkg_Conmvs_Tiss_Xml.Fnc_Motivo_Portal(Pcd_Motivo       => 'US003',
                                                   p_Sn_Web_Service => 'S') = 'S') Then
  
    Begin
      For Vtipointernacao In Ctipointernacao Loop
      
        Begin
          Prc_Insere_Log_Erro(Vtipointernacao.Nr_Numero_Carteira,
                              Vtipointernacao.Nr_Guia_Prestador,
                              Vtipointernacao.Nr_Guia_Operadora,
                              Vtipointernacao.Nr_Senha_Autorizacao,
                              Vtipointernacao.Cd_Prestador,
                              Vtipointernacao.Nm_Beneficiario,
                              --rVTissLoteGuia.DS_TP_PROTOCOLO,
                              '',
                              '',
                              'TIPO DE INTERNA��O INV�LIDO: ' ||
                              Vtipointernacao.Nr_Guia_Operadora,
                              'US003',
                              'I',
                              'N');
        
        End;
      End Loop;
      Commit;
    
    Exception
      When Others Then
        Dbms_Output.Put_Line('exception-gral');
        Vexcecao      := Sqlerrm;
        Vexcecaolinha := Dbms_Utility.Format_Error_Backtrace;
        Vcoderro      := 'E999';
        Prc_Insere_Log_Erro(Vtipointernacao.Nr_Numero_Carteira,
                            Vtipointernacao.Nr_Guia_Prestador,
                            Vtipointernacao.Nr_Guia_Operadora,
                            Vtipointernacao.Nr_Senha_Autorizacao,
                            Vtipointernacao.Cd_Prestador,
                            Vtipointernacao.Nm_Beneficiario,
                            '',
                            '',
                            'EXCEPTION-GLOBAL! N�o foi possivel validar as regras --> US003. Favor entre em contato com a Operadora MSG: ' ||
                            Vexcecao || ' linha do erro: ' || Vexcecaolinha,
                            Vcoderro,
                            'E',
                            'N');
        Commit;
        If (Ctipointernacao%Isopen) Then
          Close Ctipointernacao;
        End If;
    End;
  End If;

  --GUIAS DUPLICADAS
  If (Custom.Pkg_Conmvs_Tiss_Xml.Fnc_Motivo_Portal(Pcd_Motivo       => 'US004',
                                                   p_Sn_Web_Service => 'S') = 'S') Then
    Begin
      For Vguiasduplicadas In Cguiasduplicadas Loop
      
        Begin
        
          Prc_Insere_Log_Erro(Vguiasduplicadas.Nr_Numero_Carteira,
                              Vguiasduplicadas.Nr_Guia_Prestador,
                              Vguiasduplicadas.Nr_Guia_Operadora,
                              Vguiasduplicadas.Nr_Senha_Autorizacao,
                              Vguiasduplicadas.Cd_Prestador,
                              Vguiasduplicadas.Nm_Beneficiario,
                              --rVTissLoteGuia.DS_TP_PROTOCOLO,
                              '',
                              '',
                              'Duplicidade de Guias: ' ||
                              Vguiasduplicadas.Nr_Senha_Autorizacao,
                              'US004',
                              'I',
                              'N');
        
        End;
      End Loop;
      Commit;
    
    Exception
      When Others Then
        Dbms_Output.Put_Line('exception-gral');
        Vexcecao      := Sqlerrm;
        Vexcecaolinha := Dbms_Utility.Format_Error_Backtrace;
        Vcoderro      := 'E999';
        Prc_Insere_Log_Erro(Vguiasduplicadas.Nr_Numero_Carteira,
                            Vguiasduplicadas.Nr_Guia_Prestador,
                            Vguiasduplicadas.Nr_Guia_Operadora,
                            Vguiasduplicadas.Nr_Senha_Autorizacao,
                            Vguiasduplicadas.Cd_Prestador,
                            Vguiasduplicadas.Nm_Beneficiario,
                            '',
                            '',
                            'EXCEPTION-GLOBAL! N�o foi possivel validar as regras --> US004. Favor entre em contato com a Operadora MSG: ' ||
                            Vexcecao || ' linha do erro: ' || Vexcecaolinha,
                            Vcoderro,
                            'E',
                            'N');
        Commit;
        If (Cguiasduplicadas%Isopen) Then
          Close Cguiasduplicadas;
        End If;
    End;
  End If;
  --C�digo Inexistente
  If (Custom.Pkg_Conmvs_Tiss_Xml.Fnc_Motivo_Portal(Pcd_Motivo       => 'US005',
                                                   p_Sn_Web_Service => 'S') = 'S') Then
    Begin
      For Vcodigoinexistente In Ccodigoinexistente Loop
      
        Begin
        
          Prc_Insere_Log_Erro(Vcodigoinexistente.Nr_Numero_Carteira,
                              Vcodigoinexistente.Nr_Guia_Prestador,
                              Vcodigoinexistente.Nr_Guia_Operadora,
                              Vcodigoinexistente.Nr_Senha_Autorizacao,
                              Vcodigoinexistente.Cd_Prestador,
                              Vcodigoinexistente.Nm_Beneficiario,
                              --rVTissLoteGuia.DS_TP_PROTOCOLO,
                              '',
                              '',
                              'C�digo Inexistente: ' ||
                              Vcodigoinexistente.Cd_Procedimento,
                              'US005',
                              'I',
                              'N');
        
        End;
      End Loop;
      Commit;
    
    Exception
      When Others Then
        Dbms_Output.Put_Line('exception-gral');
        Vexcecao      := Sqlerrm;
        Vexcecaolinha := Dbms_Utility.Format_Error_Backtrace;
        Vcoderro      := 'E999';
        Prc_Insere_Log_Erro(Vcodigoinexistente.Nr_Numero_Carteira,
                            Vcodigoinexistente.Nr_Guia_Prestador,
                            Vcodigoinexistente.Nr_Guia_Operadora,
                            Vcodigoinexistente.Nr_Senha_Autorizacao,
                            Vcodigoinexistente.Cd_Prestador,
                            Vcodigoinexistente.Nm_Beneficiario,
                            '',
                            '',
                            'EXCEPTION-GLOBAL! N�o foi possivel validar as regras --> US005. Favor entre em contato com a Operadora MSG: ' ||
                            Vexcecao || ' linha do erro: ' || Vexcecaolinha,
                            Vcoderro,
                            'E',
                            'N');
        Commit;
        If (Ccodigoinexistente%Isopen) Then
          Close Ccodigoinexistente;
        End If;
    End;
  End If;
  --Guia Vencida
  If (Custom.Pkg_Conmvs_Tiss_Xml.Fnc_Motivo_Portal(Pcd_Motivo       => 'US006',
                                                   p_Sn_Web_Service => 'S') = 'S') Then
    Begin
      For Vguiavencida In Cguiavencida Loop
      
        Begin
        
          Begin
            Select g.Dt_Vencimento
              Into Vdatavencimento
              From Dbaps.Guia g
             Where g.Nr_Guia =
                   Nvl(Vguiavencida.Nr_Guia_Operadora,
                       Vguiavencida.Nr_Senha_Autorizacao);
          
          Exception
            When Others Then
              Prc_Insere_Log_Erro(Vguiavencida.Nr_Numero_Carteira,
                                  Vguiavencida.Nr_Guia_Prestador,
                                  Vguiavencida.Nr_Guia_Operadora,
                                  Vguiavencida.Nr_Senha_Autorizacao,
                                  Vguiavencida.Cd_Prestador,
                                  Vguiavencida.Nm_Beneficiario,
                                  '',
                                  '',
                                  'EXCEPTION-GLOBAL! N�o foi possivel Pegar a data de vencimento da guia --> US006. Favor entre em contato com a Operadora MSG: ' ||
                                  Vexcecao || ' linha do erro: ' ||
                                  Vexcecaolinha,
                                  Vcoderro,
                                  'E',
                                  'N');
          End;
        
          Prc_Insere_Log_Erro(Vguiavencida.Nr_Numero_Carteira,
                              Vguiavencida.Nr_Guia_Prestador,
                              Vguiavencida.Nr_Guia_Operadora,
                              Vguiavencida.Nr_Senha_Autorizacao,
                              Vguiavencida.Cd_Prestador,
                              Vguiavencida.Nm_Beneficiario,
                              --rVTissLoteGuia.DS_TP_PROTOCOLO,
                              '',
                              '',
                              'Guia Vencida: ' ||
                              Nvl(Vguiavencida.Nr_Guia_Operadora,
                                  Vguiavencida.Nr_Guia_Prestador) ||
                              ' Na data de: ' || Vdatavencimento,
                              'US006',
                              'I',
                              'N');
        
          Commit;
        End;
      End Loop;
    
    Exception
      When Others Then
        Dbms_Output.Put_Line('exception-gral');
        Vexcecao      := Sqlerrm;
        Vexcecaolinha := Dbms_Utility.Format_Error_Backtrace;
        Vcoderro      := 'E999';
        Prc_Insere_Log_Erro(Vguiavencida.Nr_Numero_Carteira,
                            Vguiavencida.Nr_Guia_Prestador,
                            Vguiavencida.Nr_Guia_Operadora,
                            Vguiavencida.Nr_Senha_Autorizacao,
                            Vguiavencida.Cd_Prestador,
                            Vguiavencida.Nm_Beneficiario,
                            '',
                            '',
                            'EXCEPTION-GLOBAL! N�o foi possivel validar as regras --> US006. Favor entre em contato com a Operadora MSG: ' ||
                            Vexcecao || ' linha do erro: ' || Vexcecaolinha,
                            Vcoderro,
                            'E',
                            'N');
        Commit;
        If (Cguiavencida%Isopen) Then
          Close Cguiavencida;
        End If;
    End;
  End If;

  -- Declara��o Nascido Vivo ou Obito

  If (Custom.Pkg_Conmvs_Tiss_Xml.Fnc_Motivo_Portal(Pcd_Motivo       => 'US012',
                                                   p_Sn_Web_Service => 'S') = 'S') Then
  
    Begin
      For Vdeclaracaonascidoouobtito In Cdeclaracaonascidoouobtito Loop
      
        Begin
        
          Prc_Insere_Log_Erro(Vdeclaracaonascidoouobtito.Nr_Numero_Carteira,
                              Vdeclaracaonascidoouobtito.Nr_Guia_Prestador,
                              Vdeclaracaonascidoouobtito.Nr_Guia_Operadora,
                              Vdeclaracaonascidoouobtito.Nr_Senha_Autorizacao,
                              Vdeclaracaonascidoouobtito.Cd_Prestador,
                              Vdeclaracaonascidoouobtito.Nm_Beneficiario,
                              --rVTissLoteGuia.DS_TP_PROTOCOLO,
                              '',
                              '',
                              'Declara��o do Nascido Vivo ou �bito N�o informada, 
                            ou n�o respeitou o limite de caracteres num�ricos (11)',
                              'US012',
                              'I',
                              'N');
        
          Commit;
        End;
      End Loop;
    
    Exception
      When Others Then
        Dbms_Output.Put_Line('exception-gral');
        Vexcecao      := Sqlerrm;
        Vexcecaolinha := Dbms_Utility.Format_Error_Backtrace;
        Vcoderro      := 'E999';
        Prc_Insere_Log_Erro(Vdeclaracaonascidoouobtito.Nr_Numero_Carteira,
                            Vdeclaracaonascidoouobtito.Nr_Guia_Prestador,
                            Vdeclaracaonascidoouobtito.Nr_Guia_Operadora,
                            Vdeclaracaonascidoouobtito.Nr_Senha_Autorizacao,
                            Vdeclaracaonascidoouobtito.Cd_Prestador,
                            Vdeclaracaonascidoouobtito.Nm_Beneficiario,
                            '',
                            '',
                            'EXCEPTION-GLOBAL! N�o foi possivel validar as regras --> US012. Favor entre em contato com a Operadora MSG: ' ||
                            Vexcecao || ' linha do erro: ' || Vexcecaolinha,
                            Vcoderro,
                            'E',
                            'N');
        Commit;
        If (Cdeclaracaonascidoouobtito%Isopen) Then
          Close Cdeclaracaonascidoouobtito;
        End If;
    End;
  End If;
  --Declara��o �bito se motivo 45,65,66,67
  If (Custom.Pkg_Conmvs_Tiss_Xml.Fnc_Motivo_Portal(Pcd_Motivo       => 'US013',
                                                   p_Sn_Web_Service => 'S') = 'S') Then
    Begin
      For Vdeclaracaobtito In Cdeclaracaoobito Loop
      
        Begin
        
          Prc_Insere_Log_Erro(Vdeclaracaobtito.Nr_Numero_Carteira,
                              Vdeclaracaobtito.Nr_Guia_Prestador,
                              Vdeclaracaobtito.Nr_Guia_Operadora,
                              Vdeclaracaobtito.Nr_Senha_Autorizacao,
                              Vdeclaracaobtito.Cd_Prestador,
                              Vdeclaracaobtito.Nm_Beneficiario,
                              --rVTissLoteGuia.DS_TP_PROTOCOLO,
                              '',
                              '',
                              'Declara��o de �bito N�o informada, 
                            ou n�o respeitou o limite de caracteres num�ricos (11)',
                              'US013',
                              'I',
                              'N');
        
          Commit;
        End;
      End Loop;
    
    Exception
      When Others Then
        Dbms_Output.Put_Line('exception-gral');
        Vexcecao      := Sqlerrm;
        Vexcecaolinha := Dbms_Utility.Format_Error_Backtrace;
        Vcoderro      := 'E999';
        Prc_Insere_Log_Erro(Vdeclaracaobtito.Nr_Numero_Carteira,
                            Vdeclaracaobtito.Nr_Guia_Prestador,
                            Vdeclaracaobtito.Nr_Guia_Operadora,
                            Vdeclaracaobtito.Nr_Senha_Autorizacao,
                            Vdeclaracaobtito.Cd_Prestador,
                            Vdeclaracaobtito.Nm_Beneficiario,
                            '',
                            '',
                            'EXCEPTION-GLOBAL! N�o foi possivel validar as regras --> US013. Favor entre em contato com a Operadora MSG: ' ||
                            Vexcecao || ' linha do erro: ' || Vexcecaolinha,
                            Vcoderro,
                            'E',
                            'N');
        Commit;
        If (Cdeclaracaoobito%Isopen) Then
          Close Cdeclaracaoobito;
        End If;
    End;
  End If;

  --Obriga participa��o para servi�os profissionais 
  If (Custom.Pkg_Conmvs_Tiss_Xml.Fnc_Motivo_Portal(Pcd_Motivo       => 'US014',
                                                   p_Sn_Web_Service => 'S') = 'S') Then
    Begin
      For Vobrigagrauparticipacao In Cobrigagrauparticipacao Loop
      
        Begin
        
          Prc_Insere_Log_Erro(Vobrigagrauparticipacao.Nr_Numero_Carteira,
                              Vobrigagrauparticipacao.Nr_Guia_Prestador,
                              Vobrigagrauparticipacao.Nr_Guia_Operadora,
                              Vobrigagrauparticipacao.Nr_Senha_Autorizacao,
                              Vobrigagrauparticipacao.Cd_Prestador,
                              Vobrigagrauparticipacao.Nm_Beneficiario,
                              --rVTissLoteGuia.DS_TP_PROTOCOLO,
                              '',
                              '',
                              'Grau de participa��o obrigat�rio para Servi�o Profissional: ' ||
                              Vobrigagrauparticipacao.Cd_Procedimento,
                              'US014',
                              'I',
                              'N');
        
          Commit;
        End;
      End Loop;
    
    Exception
      When Others Then
        Dbms_Output.Put_Line('exception-gral');
        Vexcecao      := Sqlerrm;
        Vexcecaolinha := Dbms_Utility.Format_Error_Backtrace;
        Vcoderro      := 'E999';
        Prc_Insere_Log_Erro(Vobrigagrauparticipacao.Nr_Numero_Carteira,
                            Vobrigagrauparticipacao.Nr_Guia_Prestador,
                            Vobrigagrauparticipacao.Nr_Guia_Operadora,
                            Vobrigagrauparticipacao.Nr_Senha_Autorizacao,
                            Vobrigagrauparticipacao.Cd_Prestador,
                            Vobrigagrauparticipacao.Nm_Beneficiario,
                            '',
                            '',
                            'EXCEPTION-GLOBAL! N�o foi possivel validar as regras --> US014. Favor entre em contato com a Operadora MSG: ' ||
                            Vexcecao || ' linha do erro: ' || Vexcecaolinha,
                            Vcoderro,
                            'E',
                            'N');
        Commit;
        If (Cobrigagrauparticipacao%Isopen) Then
          Close Cobrigagrauparticipacao;
        End If;
    End;
  End If;

  --Valida��o da carteira

  -- Carteira diferente da autoriza��o
  If (Custom.Pkg_Conmvs_Tiss_Xml.Fnc_Motivo_Portal(Pcd_Motivo       => 'US007',
                                                   p_Sn_Web_Service => 'S') = 'S') Then
    Begin
      For Vvalidacarteira In Cvalidacarteira Loop
      
        Begin
          Begin
            Select Coalesce(g.Nr_Carteira_Utilizada,
                            g.Nr_Carteira_Beneficiario,
                            g.Ds_Destino_Cortesia)
              Into Vcarteirautilizada
              From Dbaps.Guia g
             Where g.Nr_Guia =
                   Nvl(Vvalidacarteira.Nr_Guia_Operadora,
                       Vvalidacarteira.Nr_Guia_Prestador);
          
          Exception
            When Others Then
              Null;
          End;
        
          Prc_Insere_Log_Erro(Vvalidacarteira.Nr_Numero_Carteira,
                              Vvalidacarteira.Nr_Guia_Prestador,
                              Vvalidacarteira.Nr_Guia_Operadora,
                              Vvalidacarteira.Nr_Senha_Autorizacao,
                              Vvalidacarteira.Cd_Prestador,
                              Vvalidacarteira.Nm_Beneficiario,
                              --rVTissLoteGuia.DS_TP_PROTOCOLO,
                              '',
                              '',
                              'Carteira diferente da Autorizada: ' ||
                              Vcarteirautilizada,
                              'US007',
                              'I',
                              'N');
        
          Commit;
        End;
      End Loop;
    Exception
      When Others Then
        Dbms_Output.Put_Line('exception-gral');
        Vexcecao      := Sqlerrm;
        Vexcecaolinha := Dbms_Utility.Format_Error_Backtrace;
        Vcoderro      := 'E999';
        Prc_Insere_Log_Erro(Vdadosprocprestador.Nr_Numero_Carteira,
                            Vdadosprocprestador.Nr_Guia_Prestador,
                            Vdadosprocprestador.Nr_Guia_Operadora,
                            Vdadosprocprestador.Nr_Senha_Autorizacao,
                            Vdadosprocprestador.Cd_Prestador,
                            Vdadosprocprestador.Nm_Beneficiario,
                            '',
                            '',
                            'EXCEPTION-GLOBAL! N�o foi possivel validar as regras --> US007. Favor entre em contato com a Operadora MSG: ' ||
                            Vexcecao || ' linha do erro: ' || Vexcecaolinha,
                            Vcoderro,
                            'E',
                            'N');
      
        If (Cvalidacarteira%Isopen) Then
          Close Cvalidacarteira;
        End If;
    End;
  End If;
  --Sem prestador e com servi�o parametrizado para conter cd_prestador
  If (Custom.Pkg_Conmvs_Tiss_Xml.Fnc_Motivo_Portal(Pcd_Motivo       => 'US008',
                                                   p_Sn_Web_Service => 'S') = 'S') Then
    Begin
      For Vdadosprocprestador In Cdadosprocprestador Loop
      
        Prc_Insere_Log_Erro(Vdadosprocprestador.Nr_Numero_Carteira,
                            Vdadosprocprestador.Nr_Guia_Prestador,
                            Vdadosprocprestador.Nr_Guia_Operadora,
                            Vdadosprocprestador.Nr_Senha_Autorizacao,
                            Vdadosprocprestador.Cd_Prestador,
                            Vdadosprocprestador.Nm_Beneficiario,
                            --rVTissLoteGuia.DS_TP_PROTOCOLO,
                            '',
                            '',
                            'Campo de Prestador obrigat�rio para procedimentos do grupo (Servi�os Profissionais): ' ||
                            Vdadosprocprestador.Cd_Procedimento,
                            'US008',
                            'I',
                            'N');
      
        Commit;
      
      End Loop;
    
    Exception
      When Others Then
        Dbms_Output.Put_Line('exception-gral');
        Vexcecao      := Sqlerrm;
        Vexcecaolinha := Dbms_Utility.Format_Error_Backtrace;
        Vcoderro      := 'E999';
        Prc_Insere_Log_Erro(Vdadosprocprestador.Nr_Numero_Carteira,
                            Vdadosprocprestador.Nr_Guia_Prestador,
                            Vdadosprocprestador.Nr_Guia_Operadora,
                            Vdadosprocprestador.Nr_Senha_Autorizacao,
                            Vdadosprocprestador.Cd_Prestador,
                            Vdadosprocprestador.Nm_Beneficiario,
                            '',
                            '',
                            'EXCEPTION-GLOBAL! N�o foi possivel validar as regras --> US008. Favor entre em contato com a Operadora MSG: ' ||
                            Vexcecao || ' linha do erro: ' || Vexcecaolinha,
                            Vcoderro,
                            'E',
                            'N');
        Commit;
        If (Cdadosprocprestador%Isopen) Then
          Close Cdadosprocprestador;
        End If;
    End;
  End If;

  -- valida se procedimento possui data de realizado n�o informada.
  If (Custom.Pkg_Conmvs_Tiss_Xml.Fnc_Motivo_Portal(Pcd_Motivo       => 'US019',
                                                   p_Sn_Web_Service => 'S') = 'S') Then
    Begin
      For Vc_Dt_Realizado_Is_Null In c_Dt_Realizado_Is_Null Loop
      
        Prc_Insere_Log_Erro(Vc_Dt_Realizado_Is_Null.Nr_Numero_Carteira,
                            Vc_Dt_Realizado_Is_Null.Nr_Guia_Prestador,
                            Vc_Dt_Realizado_Is_Null.Nr_Guia_Operadora,
                            Vc_Dt_Realizado_Is_Null.Nr_Senha_Autorizacao,
                            Vc_Dt_Realizado_Is_Null.Cd_Prestador,
                            Vc_Dt_Realizado_Is_Null.Nm_Beneficiario,
                            --rVTissLoteGuia.DS_TP_PROTOCOLO,
                            '',
                            '',
                            'NAO E PERMITIDO ENVIO DE PROCEDIMENTO SEM DATA DE REALIZACAO INFORMADA.',
                            'US019',
                            'I',
                            'N');
      
        Commit;
      
      End Loop;
    
    Exception
      When Others Then
        Dbms_Output.Put_Line('exception-gral');
        Vexcecao      := Sqlerrm;
        Vexcecaolinha := Dbms_Utility.Format_Error_Backtrace;
        Vcoderro      := 'E999';
        Prc_Insere_Log_Erro(Vc_Dt_Realizado_Is_Null.Nr_Numero_Carteira,
                            Vc_Dt_Realizado_Is_Null.Nr_Guia_Prestador,
                            Vc_Dt_Realizado_Is_Null.Nr_Guia_Operadora,
                            Vc_Dt_Realizado_Is_Null.Nr_Senha_Autorizacao,
                            Vc_Dt_Realizado_Is_Null.Cd_Prestador,
                            Vc_Dt_Realizado_Is_Null.Nm_Beneficiario,
                            '',
                            '',
                            'EXCEPTION-GLOBAL! N�o foi possivel validar as regras --> US019. Favor entre em contato com a Operadora MSG: ' ||
                            Vexcecao || ' linha do erro: ' || Vexcecaolinha,
                            Vcoderro,
                            'E',
                            'N');
        Commit;
        If (c_Dt_Realizado_Is_Null%Isopen) Then
          Close c_Dt_Realizado_Is_Null;
        End If;
    End;
  
  End If;

  --PRAZO LIMITE DO PORTAL PARA ENVIO DAS GUIAS 60 DIAS
  If (Custom.Pkg_Conmvs_Tiss_Xml.Fnc_Motivo_Portal(Pcd_Motivo       => 'US009',
                                                   p_Sn_Web_Service => 'S') = 'S') Then
    Begin
      For Vprazoexcecidoportal In Cprazoexcecidoportal Loop
      
        Prc_Insere_Log_Erro(Vprazoexcecidoportal.Nr_Numero_Carteira,
                            Vprazoexcecidoportal.Nr_Guia_Prestador,
                            Vprazoexcecidoportal.Nr_Guia_Operadora,
                            Vprazoexcecidoportal.Nr_Senha_Autorizacao,
                            Vprazoexcecidoportal.Cd_Prestador,
                            Vprazoexcecidoportal.Nm_Beneficiario,
                            --rVTissLoteGuia.DS_TP_PROTOCOLO,
                            '',
                            '',
                            'Prazo de envio no Portal Excedido (60 dias) ap�s realiza��o',
                            'US009',
                            'I',
                            'N');
      
        Commit;
      
      End Loop;
    
    Exception
      When Others Then
        Dbms_Output.Put_Line('exception-gral');
        Vexcecao      := Sqlerrm;
        Vexcecaolinha := Dbms_Utility.Format_Error_Backtrace;
        Vcoderro      := 'E999';
        Prc_Insere_Log_Erro(Vprazoexcecidoportal.Nr_Numero_Carteira,
                            Vprazoexcecidoportal.Nr_Guia_Prestador,
                            Vprazoexcecidoportal.Nr_Guia_Operadora,
                            Vprazoexcecidoportal.Nr_Senha_Autorizacao,
                            Vprazoexcecidoportal.Cd_Prestador,
                            Vprazoexcecidoportal.Nm_Beneficiario,
                            '',
                            '',
                            'EXCEPTION-GLOBAL! N�o foi possivel validar as regras --> US009. Favor entre em contato com a Operadora MSG: ' ||
                            Vexcecao || ' linha do erro: ' || Vexcecaolinha,
                            Vcoderro,
                            'E',
                            'N');
        Commit;
        If (Cprazoexcecidoportal%Isopen) Then
          Close Cprazoexcecidoportal;
        End If;
    End;
  
  End If;

  --limite de taxa

  If (Custom.Pkg_Conmvs_Tiss_Xml.Fnc_Motivo_Portal(Pcd_Motivo       => 'US010',
                                                   p_Sn_Web_Service => 'S') = 'S') Then
  
    Begin
      For Vlimitetaxa In Climitetaxa Loop
      
        Prc_Insere_Log_Erro(Vlimitetaxa.Nr_Numero_Carteira,
                            Vlimitetaxa.Nr_Guia_Prestador,
                            Vlimitetaxa.Nr_Guia_Operadora,
                            Vlimitetaxa.Nr_Senha_Autorizacao,
                            Vlimitetaxa.Cd_Prestador,
                            Vlimitetaxa.Nm_Beneficiario,
                            --rVTissLoteGuia.DS_TP_PROTOCOLO,
                            '',
                            '',
                            'Quantidade de Taxa na guia Ultrapassada (LIMITE 1) ' ||
                            Vlimitetaxa.Cd_Procedimento,
                            'US010',
                            'I',
                            'N');
      
        Commit;
      
      End Loop;
    
    Exception
      When Others Then
        Dbms_Output.Put_Line('exception-gral');
        Vexcecao      := Sqlerrm;
        Vexcecaolinha := Dbms_Utility.Format_Error_Backtrace;
        Vcoderro      := 'E999';
        Prc_Insere_Log_Erro(Vlimitetaxa.Nr_Numero_Carteira,
                            Vlimitetaxa.Nr_Guia_Prestador,
                            Vlimitetaxa.Nr_Guia_Operadora,
                            Vlimitetaxa.Nr_Senha_Autorizacao,
                            Vlimitetaxa.Cd_Prestador,
                            Vlimitetaxa.Nm_Beneficiario,
                            '',
                            '',
                            'EXCEPTION-GLOBAL! N�o foi possivel validar as regras --> US010. Favor entre em contato com a Operadora MSG: ' ||
                            Vexcecao || ' linha do erro: ' || Vexcecaolinha,
                            Vcoderro,
                            'E',
                            'N');
        Commit;
        If (Climitetaxa%Isopen) Then
          Close Climitetaxa;
        End If;
    End;
  End If;

  --EXECU��O 70 DIAS

  --PRAZO LIMITE DO PORTAL PARA ENVIO DAS GUIAS 60 DIAS

  If (Custom.Pkg_Conmvs_Tiss_Xml.Fnc_Motivo_Portal(Pcd_Motivo       => 'US011',
                                                   p_Sn_Web_Service => 'S') = 'S') Then
    Begin
      For Vguiaexecucao70dias In Cguiaexecucao70dias Loop
      
        Prc_Insere_Log_Erro(Vguiaexecucao70dias.Nr_Numero_Carteira,
                            Vguiaexecucao70dias.Nr_Guia_Prestador,
                            Vguiaexecucao70dias.Nr_Guia_Operadora,
                            Vguiaexecucao70dias.Nr_Senha_Autorizacao,
                            Vguiaexecucao70dias.Cd_Prestador,
                            Vguiaexecucao70dias.Nm_Beneficiario,
                            --rVTissLoteGuia.DS_TP_PROTOCOLO,
                            '',
                            '',
                            'Limite de 70 dias ap�s a execu��o desta guia excedido !',
                            'US011',
                            'I',
                            'N');
      
        Commit;
      
      End Loop;
    
    Exception
      When Others Then
        Dbms_Output.Put_Line('exception-gral');
        Vexcecao      := Sqlerrm;
        Vexcecaolinha := Dbms_Utility.Format_Error_Backtrace;
        Vcoderro      := 'E999';
        Prc_Insere_Log_Erro(Vguiaexecucao70dias.Nr_Numero_Carteira,
                            Vguiaexecucao70dias.Nr_Guia_Prestador,
                            Vguiaexecucao70dias.Nr_Guia_Operadora,
                            Vguiaexecucao70dias.Nr_Senha_Autorizacao,
                            Vguiaexecucao70dias.Cd_Prestador,
                            Vguiaexecucao70dias.Nm_Beneficiario,
                            '',
                            '',
                            'EXCEPTION-GLOBAL! N�o foi possivel validar as regras --> US011. Favor entre em contato com a Operadora MSG: ' ||
                            Vexcecao || ' linha do erro: ' || Vexcecaolinha,
                            Vcoderro,
                            'E',
                            'N');
        Commit;
        If (Cguiaexecucao70dias%Isopen) Then
          Close Cguiaexecucao70dias;
        End If;
    End;
  
  End If;

  -- Prestador Existe na operadora
  If (Custom.Pkg_Conmvs_Tiss_Xml.Fnc_Motivo_Portal(Pcd_Motivo       => 'US016',
                                                   p_Sn_Web_Service => 'S') = 'S') Then
    Begin
      For Vprestadorexistenaoperadora In Cprestadorexistenaoperadora Loop
      
        Prc_Insere_Log_Erro(Vprestadorexistenaoperadora.Nr_Numero_Carteira,
                            Vprestadorexistenaoperadora.Nr_Guia_Prestador,
                            Vprestadorexistenaoperadora.Nr_Guia_Operadora,
                            Vprestadorexistenaoperadora.Nr_Senha_Autorizacao,
                            Vprestadorexistenaoperadora.Cd_Prestador,
                            Vprestadorexistenaoperadora.Nm_Beneficiario,
                            --rVTissLoteGuia.DS_TP_PROTOCOLO,
                            '',
                            '',
                            'Prestador ' ||
                            Vprestadorexistenaoperadora.Nm_Membro_Eqp ||
                            ' - ' ||
                            Vprestadorexistenaoperadora.Nr_Conselho_Membro_Eqp ||
                            Chr(10) ||
                            ' Inexistente na Operadora, para o grupo de Procedimento SD/SP - ' || Vprestadorexistenaoperadora.Cd_Procedimento ,
                            'US016',
                            'I',
                            'N');
      
        Commit;
      
      End Loop;
    
    Exception
      When Others Then
        Dbms_Output.Put_Line('exception-gral');
        Vexcecao      := Sqlerrm;
        Vexcecaolinha := Dbms_Utility.Format_Error_Backtrace;
        Vcoderro      := 'E999';
        Raise_Application_Error(-20001, 'Erro: ' || Sqlerrm);
        Commit;
        If (Cprestadorexistenaoperadora%Isopen) Then
          Close Cprestadorexistenaoperadora;
        End If;
    End;
  End If;

  --JOSIEL CH2209-4741 TRAVA NO XML PARA SENHA EXTERNA COM valor = "0"  
  If (Custom.Pkg_Conmvs_Tiss_Xml.Fnc_Motivo_Portal(Pcd_Motivo       => 'US017',
                                                   p_Sn_Web_Service => 'S') = 'S') Then
    Begin
      For Vc_Guia_Prestador_Valor_0 In c_Guia_Prestador_Valor_0 Loop
      
        Prc_Insere_Log_Erro(Vc_Guia_Prestador_Valor_0.Nr_Numero_Carteira,
                            Vc_Guia_Prestador_Valor_0.Nr_Guia_Prestador,
                            Vc_Guia_Prestador_Valor_0.Nr_Guia_Operadora,
                            Vc_Guia_Prestador_Valor_0.Nr_Senha_Autorizacao,
                            Vc_Guia_Prestador_Valor_0.Cd_Prestador,
                            Vc_Guia_Prestador_Valor_0.Nm_Beneficiario,
                            --rVTissLoteGuia.DS_TP_PROTOCOLO,
                            '',
                            '',
                            'Guia possui valor/numero igual a 0.',
                            'US017',
                            'I',
                            'N');
      
        Commit;
      
      End Loop;
    
    Exception
      When Others Then
        Dbms_Output.Put_Line('exception-gral');
        Vexcecao      := Sqlerrm;
        Vexcecaolinha := Dbms_Utility.Format_Error_Backtrace;
        Vcoderro      := 'E999';
        Prc_Insere_Log_Erro(Vc_Guia_Prestador_Valor_0.Nr_Numero_Carteira,
                            Vc_Guia_Prestador_Valor_0.Nr_Guia_Prestador,
                            Vc_Guia_Prestador_Valor_0.Nr_Guia_Operadora,
                            Vc_Guia_Prestador_Valor_0.Nr_Senha_Autorizacao,
                            Vc_Guia_Prestador_Valor_0.Cd_Prestador,
                            Vc_Guia_Prestador_Valor_0.Nm_Beneficiario,
                            '',
                            '',
                            'EXCEPTION-GLOBAL! N�o foi possivel validar as regras --> US017. Favor entre em contato com a Operadora MSG: ' ||
                            Vexcecao || ' linha do erro: ' || Vexcecaolinha,
                            Vcoderro,
                            'E',
                            'N');
        Commit;
        If (c_Guia_Prestador_Valor_0%Isopen) Then
          Close c_Guia_Prestador_Valor_0;
        End If;
    End;
  End If;

  --- GUIA INEXISTENTE NA OPERADORA
  If (Custom.Pkg_Conmvs_Tiss_Xml.Fnc_Motivo_Portal(Pcd_Motivo       => 'US020',
                                                   p_Sn_Web_Service => 'S') = 'S') Then
    Begin
      For Vguiainexistente In Cguiainexistente Loop
      
        Prc_Insere_Log_Erro(Vguiainexistente.Nr_Numero_Carteira,
                            Vguiainexistente.Nr_Guia_Prestador,
                            Vguiainexistente.Nr_Guia_Operadora,
                            Vguiainexistente.Nr_Senha_Autorizacao,
                            Vguiainexistente.Cd_Prestador,
                            Vguiainexistente.Nm_Beneficiario,
                            --rVTissLoteGuia.DS_TP_PROTOCOLO,
                            '',
                            '',
                            'Guia Inexistente na Operadora !',
                            'US020',
                            'I',
                            'N');
      
        Commit;
      
      End Loop;
    
    Exception
      When Others Then
        Dbms_Output.Put_Line('exception-gral');
        Vexcecao      := Sqlerrm;
        Vexcecaolinha := Dbms_Utility.Format_Error_Backtrace;
        Vcoderro      := 'E999';
        Prc_Insere_Log_Erro(Vguiainexistente.Nr_Numero_Carteira,
                            Vguiainexistente.Nr_Guia_Prestador,
                            Vguiainexistente.Nr_Guia_Operadora,
                            Vguiainexistente.Nr_Senha_Autorizacao,
                            Vguiainexistente.Cd_Prestador,
                            Vguiainexistente.Nm_Beneficiario,
                            '',
                            '',
                            'EXCEPTION-GLOBAL! N�o foi possivel validar as regras --> US020. Favor entre em contato com a Operadora MSG: ' ||
                            Vexcecao || ' linha do erro: ' || Vexcecaolinha,
                            Vcoderro,
                            'E',
                            'N');
        Commit;
        If (Cguiainexistente%Isopen) Then
          Close Cguiainexistente;
        End If;
    End;
  End If;

  -- INICIO TRAVA C�DIGOS DE RACIONALIZACAO.
  If (Custom.Pkg_Conmvs_Tiss_Xml.Fnc_Motivo_Portal(Pcd_Motivo       => 'US022',
                                                   p_Sn_Web_Service => 'S') = 'S') Then
    Begin
      For Vcodracionalizacaosemautoriza In Ccodracionalizacaosemautoriza Loop
      
        Prc_Insere_Log_Erro(Vcodracionalizacaosemautoriza.Nr_Numero_Carteira,
                            Vcodracionalizacaosemautoriza.Nr_Guia_Prestador,
                            Vcodracionalizacaosemautoriza.Nr_Guia_Operadora,
                            Vcodracionalizacaosemautoriza.Nr_Senha_Autorizacao,
                            Vcodracionalizacaosemautoriza.Cd_Prestador,
                            Vcodracionalizacaosemautoriza.Nm_Beneficiario,
                            --rVTissLoteGuia.DS_TP_PROTOCOLO,
                            '',
                            '',
                            'CODIGO: ' ||
                            Vcodracionalizacaosemautoriza.Cd_Procedimento ||
                            ' DE RACIONALIZA��O SEM AUTORIZACAO VALIDA',
                            'US022',
                            'I',
                            'N');
      
        Commit;
      
      End Loop;
    
    Exception
      When Others Then
        Dbms_Output.Put_Line('exception-gral');
        Vexcecao      := Sqlerrm;
        Vexcecaolinha := Dbms_Utility.Format_Error_Backtrace;
        Vcoderro      := 'E999';
        Prc_Insere_Log_Erro(Vcodracionalizacaosemautoriza.Nr_Numero_Carteira,
                            Vcodracionalizacaosemautoriza.Nr_Guia_Prestador,
                            Vcodracionalizacaosemautoriza.Nr_Guia_Operadora,
                            Vcodracionalizacaosemautoriza.Nr_Senha_Autorizacao,
                            Vcodracionalizacaosemautoriza.Cd_Prestador,
                            Vcodracionalizacaosemautoriza.Nm_Beneficiario,
                            '',
                            '',
                            'EXCEPTION-GLOBAL! N�o foi possivel validar as regras --> US022. Favor entre em contato com a Operadora MSG: ' ||
                            Vexcecao || ' linha do erro: ' || Vexcecaolinha,
                            Vcoderro,
                            'E',
                            'N');
        Commit;
        If (Ccodracionalizacaosemautoriza%Isopen) Then
          Close Ccodracionalizacaosemautoriza;
        End If;
    End;
  End If;
  --FIM TRAVA C�DIGOS DE RACIONALIZACAO

  If (Custom.Pkg_Conmvs_Tiss_Xml.Fnc_Motivo_Portal(Pcd_Motivo       => 'US023',
                                                   p_Sn_Web_Service => 'S') = 'S') Then
    Begin
      For Vobrigaprestadorspsd In Cobrigaprestadorspsd Loop
      
        Prc_Insere_Log_Erro(Vobrigaprestadorspsd.Nr_Numero_Carteira,
                            Vobrigaprestadorspsd.Nr_Guia_Prestador,
                            Vobrigaprestadorspsd.Nr_Guia_Operadora,
                            Vobrigaprestadorspsd.Nr_Senha_Autorizacao,
                            Vobrigaprestadorspsd.Cd_Prestador,
                            Vobrigaprestadorspsd.Nm_Beneficiario,
                            --rVTissLoteGuia.DS_TP_PROTOCOLO,
                            '',
                            '',
                            'Obrigat�rio o envio do Prestador para o c�digo ' ||
                            Vobrigaprestadorspsd.Cd_Procedimento,
                            'US023',
                            'I',
                            'N');
      
        Commit;
      
      End Loop;
    
    Exception
      When Others Then
        Dbms_Output.Put_Line('exception-gral');
        Vexcecao      := Sqlerrm;
        Vexcecaolinha := Dbms_Utility.Format_Error_Backtrace;
        Vcoderro      := 'E999';
        Prc_Insere_Log_Erro(Vcodracionalizacaosemautoriza.Nr_Numero_Carteira,
                            Vcodracionalizacaosemautoriza.Nr_Guia_Prestador,
                            Vcodracionalizacaosemautoriza.Nr_Guia_Operadora,
                            Vcodracionalizacaosemautoriza.Nr_Senha_Autorizacao,
                            Vcodracionalizacaosemautoriza.Cd_Prestador,
                            Vcodracionalizacaosemautoriza.Nm_Beneficiario,
                            '',
                            '',
                            'EXCEPTION-GLOBAL! N�o foi possivel validar as regras --> US023. Favor entre em contato com a Operadora MSG: ' ||
                            Vexcecao || ' linha do erro: ' || Vexcecaolinha,
                            Vcoderro,
                            'E',
                            'N');
      
        If (Cobrigaprestadorspsd%Isopen) Then
          Close Cobrigaprestadorspsd;
        End If;
    End;
  End If;

  --US027
  If (Custom.Pkg_Conmvs_Tiss_Xml.Fnc_Motivo_Portal(Pcd_Motivo       => 'US027',
                                                   p_Sn_Web_Service => 'S') = 'S') Then
    Begin
      For Vvalorreducaoacrescimo In Cvalorreducaoacrescimoproc Loop
      
        Prc_Insere_Log_Erro(Vvalorreducaoacrescimo.Nr_Numero_Carteira,
                            Vvalorreducaoacrescimo.Nr_Guia_Prestador,
                            Vvalorreducaoacrescimo.Nr_Guia_Operadora,
                            Vvalorreducaoacrescimo.Nr_Senha_Autorizacao,
                            Vvalorreducaoacrescimo.Cd_Prestador,
                            Vvalorreducaoacrescimo.Nm_Beneficiario,
                            '',
                            '',
                            'Favor informar Percentual 100 para este procedimento: ' ||
                            Vvalorreducaoacrescimo.Cd_Procedimento,
                            'US027',
                            'I',
                            'N');
      
        Commit;
      
      End Loop;
    
    Exception
      When Others Then
        Dbms_Output.Put_Line('exception-gral');
        Vexcecao      := Sqlerrm;
        Vexcecaolinha := Dbms_Utility.Format_Error_Backtrace;
        Vcoderro      := 'E999';
        Prc_Insere_Log_Erro(Vvalorreducaoacrescimo.Nr_Numero_Carteira,
                            Vvalorreducaoacrescimo.Nr_Guia_Prestador,
                            Vvalorreducaoacrescimo.Nr_Guia_Operadora,
                            Vvalorreducaoacrescimo.Nr_Senha_Autorizacao,
                            Vvalorreducaoacrescimo.Cd_Prestador,
                            Vvalorreducaoacrescimo.Nm_Beneficiario,
                            '',
                            '',
                            'EXCEPTION-GLOBAL! N�o foi possivel validar as regras --> US027. Favor entre em contato com a Operadora MSG: ' ||
                            Vexcecao || ' linha do erro: ' || Vexcecaolinha,
                            Vcoderro,
                            'E',
                            'N');
        Commit;
        If (Cvalorreducaoacrescimoproc%Isopen) Then
          Close Cvalorreducaoacrescimoproc;
        End If;
    End;
  End If;

  -- US029

  If (Custom.Pkg_Conmvs_Tiss_Xml.Fnc_Motivo_Portal(Pcd_Motivo       => 'US029',
                                                   p_Sn_Web_Service => 'S') = 'S') Then
    Begin
      For Vtipoatendimentotisscod In Ctipoatendimentotisscod Loop
      
        Prc_Insere_Log_Erro(Vtipoatendimentotisscod.Nr_Numero_Carteira,
                            Vtipoatendimentotisscod.Nr_Guia_Prestador,
                            Vtipoatendimentotisscod.Nr_Guia_Operadora,
                            Vtipoatendimentotisscod.Nr_Senha_Autorizacao,
                            Vtipoatendimentotisscod.Cd_Prestador,
                            Vtipoatendimentotisscod.Nm_Beneficiario,
                            '',
                            '',
                            'Tipo de atendimento Diverge com o padr�o TISS para o c�digo: ' ||
                            Vtipoatendimentotisscod.Cd_Procedimento,
                            'US029',
                            'I',
                            'N');
      
        Commit;
      
      End Loop;
    
    Exception
      When Others Then
        Dbms_Output.Put_Line('exception-gral');
        Vexcecao      := Sqlerrm;
        Vexcecaolinha := Dbms_Utility.Format_Error_Backtrace;
        Vcoderro      := 'E999';
        Prc_Insere_Log_Erro(Vtipoatendimentotisscod.Nr_Numero_Carteira,
                            Vtipoatendimentotisscod.Nr_Guia_Prestador,
                            Vtipoatendimentotisscod.Nr_Guia_Operadora,
                            Vtipoatendimentotisscod.Nr_Senha_Autorizacao,
                            Vtipoatendimentotisscod.Cd_Prestador,
                            Vtipoatendimentotisscod.Nm_Beneficiario,
                            '',
                            '',
                            'EXCEPTION-GLOBAL! N�o foi possivel validar as regras --> US029. Favor entre em contato com a Operadora MSG: ' ||
                            Vexcecao || ' linha do erro: ' || Vexcecaolinha,
                            Vcoderro,
                            'E',
                            'N');
        Commit;
        If (Ctipoatendimentotisscod%Isopen) Then
          Close Ctipoatendimentotisscod;
        End If;
    End;
  End If;

  --US026
  If (Custom.Pkg_Conmvs_Tiss_Xml.Fnc_Motivo_Portal(Pcd_Motivo       => 'US026',
                                                   p_Sn_Web_Service => 'S') = 'S') Then
    Begin
      For Vtipoatendimentoproc In Ctipoatendimentoproc Loop
      
        Prc_Insere_Log_Erro(Vtipoatendimentoproc.Nr_Numero_Carteira,
                            Vtipoatendimentoproc.Nr_Guia_Prestador,
                            Vtipoatendimentoproc.Nr_Guia_Operadora,
                            Vtipoatendimentoproc.Nr_Senha_Autorizacao,
                            Vtipoatendimentoproc.Cd_Prestador,
                            Vtipoatendimentoproc.Nm_Beneficiario,
                            '',
                            '',
                            'Favor informar o tipo de atendimento tiss 13 para guias sem procedimentos 2010...',
                            'US026',
                            'I',
                            'N');
      
        Commit;
      
      End Loop;
    
    Exception
      When Others Then
        Dbms_Output.Put_Line('exception-gral');
        Vexcecao      := Sqlerrm;
        Vexcecaolinha := Dbms_Utility.Format_Error_Backtrace;
        Vcoderro      := 'E999';
        Prc_Insere_Log_Erro(Vtipoatendimentoproc.Nr_Numero_Carteira,
                            Vtipoatendimentoproc.Nr_Guia_Prestador,
                            Vtipoatendimentoproc.Nr_Guia_Operadora,
                            Vtipoatendimentoproc.Nr_Senha_Autorizacao,
                            Vtipoatendimentoproc.Cd_Prestador,
                            Vtipoatendimentoproc.Nm_Beneficiario,
                            '',
                            '',
                            'EXCEPTION-GLOBAL! N�o foi possivel validar as regras --> US026. Favor entre em contato com a Operadora MSG: ' ||
                            Vexcecao || ' linha do erro: ' || Vexcecaolinha,
                            Vcoderro,
                            'E',
                            'N');
        Commit;
        If (Ctipoatendimentoproc%Isopen) Then
          Close Ctipoatendimentoproc;
        End If;
    End;
  End If;

  --US031 

  If (Custom.Pkg_Conmvs_Tiss_Xml.Fnc_Motivo_Portal(Pcd_Motivo       => 'US031',
                                                   p_Sn_Web_Service => 'S') = 'S') Then
    Begin
      For Vguiaexternaduplicada In Cguiaexternaduplicada Loop
      
        Prc_Insere_Log_Erro(Vguiaexternaduplicada.Nr_Numero_Carteira,
                            Vguiaexternaduplicada.Nr_Guia_Prestador,
                            Vguiaexternaduplicada.Nr_Guia_Operadora,
                            Vguiaexternaduplicada.Nr_Senha_Autorizacao,
                            Vguiaexternaduplicada.Cd_Prestador,
                            Vguiaexternaduplicada.Nm_Beneficiario,
                            '',
                            '',
                            'Guia Externa duplicada',
                            'US031',
                            'I',
                            'N');
      
        Commit;
      
      End Loop;
    
    Exception
      When Others Then
        Dbms_Output.Put_Line('exception-gral');
        Vexcecao      := Sqlerrm;
        Vexcecaolinha := Dbms_Utility.Format_Error_Backtrace;
        Vcoderro      := 'E999';
        Prc_Insere_Log_Erro(Vguiaexternaduplicada.Nr_Numero_Carteira,
                            Vguiaexternaduplicada.Nr_Guia_Prestador,
                            Vguiaexternaduplicada.Nr_Guia_Operadora,
                            Vguiaexternaduplicada.Nr_Senha_Autorizacao,
                            Vguiaexternaduplicada.Cd_Prestador,
                            Vguiaexternaduplicada.Nm_Beneficiario,
                            '',
                            '',
                            'EXCEPTION-GLOBAL! N�o foi possivel validar as regras --> US031. Favor entre em contato com a Operadora MSG: ' ||
                            Vexcecao || ' linha do erro: ' || Vexcecaolinha,
                            Vcoderro,
                            'E',
                            'N');
        Commit;
        If (Cguiaexternaduplicada%Isopen) Then
          Close Cguiaexternaduplicada;
        End If;
    End;
  End If;

  --US032

  If (Custom.Pkg_Conmvs_Tiss_Xml.Fnc_Motivo_Portal(Pcd_Motivo       => 'US032',
                                                   p_Sn_Web_Service => 'S') = 'S') Then
    Begin
      For Vreducaoacrescimo In Creducaoacrescimo Loop
      
        Prc_Insere_Log_Erro(Vreducaoacrescimo.Nr_Numero_Carteira,
                            Vreducaoacrescimo.Nr_Guia_Prestador,
                            Vreducaoacrescimo.Nr_Guia_Operadora,
                            Vreducaoacrescimo.Nr_Senha_Autorizacao,
                            Vreducaoacrescimo.Cd_Prestador,
                            Vreducaoacrescimo.Nm_Beneficiario,
                            '',
                            '',
                            'REDUTOR ACR�SCIMO DIVERGENTE',
                            'US032',
                            'I',
                            'N');
      
        Commit;
      
      End Loop;
    
    Exception
      When Others Then
        Dbms_Output.Put_Line('exception-gral');
        Vexcecao      := Sqlerrm;
        Vexcecaolinha := Dbms_Utility.Format_Error_Backtrace;
        Vcoderro      := 'E999';
        Prc_Insere_Log_Erro(Vreducaoacrescimo.Nr_Numero_Carteira,
                            Vreducaoacrescimo.Nr_Guia_Prestador,
                            Vreducaoacrescimo.Nr_Guia_Operadora,
                            Vreducaoacrescimo.Nr_Senha_Autorizacao,
                            Vreducaoacrescimo.Cd_Prestador,
                            Vreducaoacrescimo.Nm_Beneficiario,
                            '',
                            '',
                            'EXCEPTION-GLOBAL! N�o foi possivel validar as regras --> US032. Favor entre em contato com a Operadora MSG: ' ||
                            Vexcecao || ' linha do erro: ' || Vexcecaolinha,
                            Vcoderro,
                            'E',
                            'N');
        Commit;
        If (Creducaoacrescimo%Isopen) Then
          Close Creducaoacrescimo;
        End If;
    End;
  End If;

  --US033

  If (Custom.Pkg_Conmvs_Tiss_Xml.Fnc_Motivo_Portal(Pcd_Motivo       => 'US033',
                                                   p_Sn_Web_Service => 'S') = 'S') Then
    Begin
      For Vvalidaguiaprincipalsadt In Cvalidaguiaprincipalsadt Loop
      
        Prc_Insere_Log_Erro(Vvalidaguiaprincipalsadt.Nr_Numero_Carteira,
                            Vvalidaguiaprincipalsadt.Nr_Guia_Prestador,
                            Vvalidaguiaprincipalsadt.Nr_Guia_Operadora,
                            Vvalidaguiaprincipalsadt.Nr_Senha_Autorizacao,
                            Vvalidaguiaprincipalsadt.Cd_Prestador,
                            Vvalidaguiaprincipalsadt.Nm_Beneficiario,
                            '',
                            '',
                            'Preenchido GUIA PRINCIPAL S�O IGUAIS (REFERENCIA CRUZADA)',
                            'US033',
                            'I',
                            'N');
      
        Commit;
      
      End Loop;
    
    Exception
      When Others Then
        Dbms_Output.Put_Line('exception-gral');
        Vexcecao      := Sqlerrm;
        Vexcecaolinha := Dbms_Utility.Format_Error_Backtrace;
        Vcoderro      := 'E999';
        Prc_Insere_Log_Erro(Vvalidaguiaprincipalsadt.Nr_Numero_Carteira,
                            Vvalidaguiaprincipalsadt.Nr_Guia_Prestador,
                            Vvalidaguiaprincipalsadt.Nr_Guia_Operadora,
                            Vvalidaguiaprincipalsadt.Nr_Senha_Autorizacao,
                            Vvalidaguiaprincipalsadt.Cd_Prestador,
                            Vvalidaguiaprincipalsadt.Nm_Beneficiario,
                            '',
                            '',
                            'EXCEPTION-GLOBAL! N�o foi possivel validar as regras --> US033. Favor entre em contato com a Operadora MSG: ' ||
                            Vexcecao || ' linha do erro: ' || Vexcecaolinha,
                            Vcoderro,
                            'E',
                            'N');
        Commit;
        If (Cvalidaguiaprincipalsadt%Isopen) Then
          Close Cvalidaguiaprincipalsadt;
        End If;
    End;
  End If;

  If (Rprotocoloctamed.Id_Tiss_Mensagem_Retorno Is Not Null) Then
  
    Nqtderrostotal2 := 0;
    Begin
      Select 1
        Into Nqtderrostotal2
        From Dbaps.Log_Erro_Protocolo_Tiss l
       Where l.Cd_Protocolo_Ctamed = Pcd_Protocolo_Ctamed
         And Rownum = 1;
    Exception
      When Others Then
        Nqtderrostotal2 := 0; --Se n�o tiver registro de log de erro n�o faz nada
    
    End;
    If Nqtderrostotal2 = 1 Then
    
      Update Dbaps.Tiss_Mensagem
         Set Ds_Msg_Erro = Nqtderrostotal2 || ' ERROS NO XML'
       Where Id = Rprotocoloctamed.Id_Tiss_Mensagem_Retorno;
    
      Update Dbaps.Protocolo_Ctamed p
         Set p.Cd_Status_Protocolo = 9,
             p.Ds_Rejeicao         = 'Erro de valida��o do XML Regras internas da operadora, E-mail de rejei��o enviado para destinat�rios. (PRC_VALIDA_PROT_TISS_TES_HOSP)'
       Where p.Cd_Protocolo_Ctamed = Pcd_Protocolo_Ctamed;
    
      Update Custom.Tiss_Controle_Protocolo Tc
         Set Tc.Sn_Validado = 'S', Tc.Cd_Status_Protocolo = 9
       Where Tc.Cd_Protocolo_Ctamed = Pcd_Protocolo_Ctamed;
      Commit;
    
      --Disparando e-mail
      Begin
      
        Begin
          Select Pc.Nr_Lote_Prestador
            Into Vloteprestador
            From Dbaps.Protocolo_Ctamed Pc
           Where Pc.Cd_Protocolo_Ctamed = Pcd_Protocolo_Ctamed
             And Rownum = 1;
        Exception
          When Others Then
            Vloteprestador := 0;
          
            Prc_Insere_Log_Erro(Rvtissloteguia.Nr_Numero_Carteira,
                                Rvtissloteguia.Nr_Guia_Prestador,
                                Rvtissloteguia.Nr_Guia_Operadora,
                                Rvtissloteguia.Nr_Senha_Autorizacao,
                                Rvtissloteguia.Cd_Prestador,
                                Rvtissloteguia.Nm_Beneficiario,
                                '',
                                '',
                                'EXCEPTION-GLOBAL! N�o foi poss�vel filtrar o lote para enviar o e-mail: ' ||
                                Vexcecao || ' linha do erro: ' ||
                                Vexcecaolinha,
                                Vcoderro,
                                'E',
                                'N');
          
        End;
      
        Vhtml := Custom.Fnc_Retorna_Html(Pcd_Protocolo => Pcd_Protocolo_Ctamed);
      
        Vtamanhoemail := Dbms_Lob.Getlength(Vhtml); --Pegando o tamanho do e-mail em bytes. 
      
        Update Custom.Tiss_Controle_Protocolo Tc
           Set Tc.Tamanho_Email_Bytes = Vtamanhoemail
         Where Tc.Cd_Protocolo_Ctamed = Pcd_Protocolo_Ctamed;
        Commit;
      
        If (Vtamanhoemail <= 10000000) Then
          --fazer o ajuste para a coluna TAMANHO_EMAIL_BYTES (17000000 --> 17Mg) m�ximo 18 mb para enviar e-mail.
        
          For Envia_Email In (Select Ds_Email
                                From Custom.Env_Email_Portal_Ws) Loop
            Custom.Pkg_Rotinas_Atendmvs.Prc_Envia_Email_V2('contasmedicas@unimedsorocaba.coop.br',
                                                           Envia_Email.Ds_Email,
                                                           'PROTOCOLO REJEITADO :' ||
                                                           To_Char(Pcd_Protocolo_Ctamed) ||
                                                           ' LOTE PRESTADOR: ' ||
                                                           To_Char(Vloteprestador),
                                                           Vhtml);
          End Loop;
        
          Begin
            If (Vhtml Is Not Null) Then
            
              Update Custom.Tiss_Controle_Protocolo Tc
                 Set Tc.Sn_Envio_Email = 'S',
                     Tc.Email          = Vhtml,
                     Tc.Dt_Envio_Email = Sysdate
               Where Tc.Cd_Protocolo_Ctamed = Pcd_Protocolo_Ctamed;
            
            End If;
          End;
        End If;
      End;
    
    Else
    
      Update Dbaps.Tiss_Mensagem
         Set Ds_Msg_Erro = Null
       Where Id = Rprotocoloctamed.Id_Tiss_Mensagem_Retorno;
    
    End If;
  
  End If;

  Commit;

Exception
  When Others Then
  
    Dbms_Output.Put_Line('exception-gral');
    Vexcecao      := Sqlerrm;
    Vexcecaolinha := Dbms_Utility.Format_Error_Backtrace;
    Vcoderro      := 'E999';
    Prc_Insere_Log_Erro(Rvtissloteguia.Nr_Numero_Carteira,
                        Rvtissloteguia.Nr_Guia_Prestador,
                        Rvtissloteguia.Nr_Guia_Operadora,
                        Rvtissloteguia.Nr_Senha_Autorizacao,
                        Rvtissloteguia.Cd_Prestador,
                        Rvtissloteguia.Nm_Beneficiario,
                        '',
                        '',
                        'EXCEPTION-GLOBAL! (Final) N�o foi possivel validar as regras. Favor entre em contato com a Operadora MSG: ' ||
                        Vexcecao || ' linha do erro: ' || Vexcecaolinha,
                        Vcoderro,
                        'E',
                        'N');
  
    Commit;
End;
/
