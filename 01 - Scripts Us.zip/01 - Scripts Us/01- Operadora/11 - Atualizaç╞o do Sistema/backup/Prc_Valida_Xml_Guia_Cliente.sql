CREATE OR REPLACE NONEDITIONABLE Procedure DBAPS.Prc_Valida_Xml_Guia_Cliente(Pcd_Protocolo_Ctamed In Number,
                                                                             Pcd_Lote_Autweb      In Number Default Null) Is
  /**************************************************************
    <objeto>
     <nome>prc_valida_xml_guia_cliente</nome>
     <usuario>Dellanio Alencar</usuario>
     <alteracao>11/08/2018 11:05</alteracao>
     <ultimaAlteracao>ponto de entrada do cliente nivel de cabecalho da guia</ultimaAlteracao>
     <descricao>Valida��o do XML do Portal/Protocolo CTAMED</descricao>
     <parametro>codigo do protocolo</parametro>
     <tags>guia, xml, validacao</tags>
     <ultimoUtilizado>criada rotina</ultimoUtilizado>
     <versao>1.0</versao>
     <soul>plano-01-127</soul>
    </objeto>
  ***************************************************************/

  ---Todas as valida��es presentes foram efetuadas por Mois�s de Souza e Ana Baena a partir de 07/07/2022.

  Cursor Cexisteerro(p_Cd_Erro             In Varchar,
                     p_Cd_Protocolo_Ctamed In Number,
                     p_Nr_Guia_Prestador   In Varchar2) Is
    Select 1
      From Dbaps.Log_Erro_Protocolo_Tiss
     Where Cd_Protocolo_Ctamed = p_Cd_Protocolo_Ctamed
       And Cd_Erro = p_Cd_Erro
       And Ds_Guia_Prestador = p_Nr_Guia_Prestador;

  ---Guia vencida 
  Cursor Cguiavencida Is
    Select Distinct Nvl(g.Nr_Carteira_Beneficiario, g.Nr_Carteira_Utilizada) As Carteira,
                    Regexp_Replace(g.Nr_Guia_Prestador, '[^[:digit:]]+') Nr_Guia_Prestador,
                    Regexp_Replace(g.Nr_Guia, '[^[:digit:]]+') Nr_Guia_Operadora,
                    Nvl(g.Cd_Prestador_Executor, g.Cd_Prestador) Cd_Prestador,
                    Substr(Nvl(g.Ds_Destino_Cortesia, u.Nm_Segurado), 1, 70) Nm_Beneficiario,
                    
                    Regexp_Replace(Nvl(g.Nr_Senha_Autorizacao, g.Nr_Guia),
                                   '[^[:digit:]]+') Nr_Senha_Autorizacao
    
      From Dbaps.Guia                     g,
           Dbaps.Usuario                  u,
           Dbaps.Tipo_Atendimento         Ta,
           Dbaps.Prestador                Pf,
           Dbaps.Prestador                Ps,
           Dbaps.Lote_Guia_Web_Parametros Lp,
           Dbaps.Itguia                   It
    
     Where g.Cd_Matricula = u.Cd_Matricula(+)
       And g.Cd_Tipo_Atendimento = Ta.Cd_Tipo_Atendimento
       And g.Cd_Prestador_Executor = Pf.Cd_Prestador(+)
       And g.Cd_Prestador_Solicitante = Ps.Cd_Prestador(+)
       And g.Nr_Guia = It.Nr_Guia
       And Lp.Cd_Lote = Pcd_Lote_Autweb
       And Lp.Nr_Guia = g.Nr_Guia
       And g.Cd_Tipo_Atendimento In (1, 2, 3)
      -- And g.cd_prestador_executor <> 1001094 -- Solicitado no chamado CH2305-3877
       And g.Cd_Tipo_Atendimento_Tiss <> 3 -- solicitado no CH2211-2246 (Quando for terapias deixar passar)
       And Trunc(g.Dt_Vencimento) < Trunc(It.Dt_Realizacao)
       And Not Exists (Select 1
              From Dbaps.Guia_Web_Erros Gw
             Where Gw.Nr_Guia_Soul = Lp.Nr_Guia
               And Gw.Cd_Lote_Web_Parametros = Lp.Cd_Lote
               And Gw.Ds_Erro Like '%US006%')
    Union All --- SADT EXECU��O
    
    Select Distinct Nvl(g.Nr_Carteira_Beneficiario, g.Nr_Carteira_Utilizada) As Carteira,
                    Regexp_Replace(g.Nr_Guia_Prestador, '[^[:digit:]]+') Nr_Guia_Prestador,
                    Regexp_Replace(g.Nr_Guia, '[^[:digit:]]+') Nr_Guia_Operadora,
                    Nvl(g.Cd_Prestador_Executor, g.Cd_Prestador) Cd_Prestador,
                    Substr(Nvl(g.Ds_Destino_Cortesia, u.Nm_Segurado), 1, 70) Nm_Beneficiario,
                    
                    Regexp_Replace(Nvl(g.Nr_Senha_Autorizacao, g.Nr_Guia),
                                   '[^[:digit:]]+') Nr_Senha_Autorizacao
    
      From Dbaps.Guia                     g,
           Dbaps.Usuario                  u,
           Dbaps.Tipo_Atendimento         Ta,
           Dbaps.Prestador                Pf,
           Dbaps.Prestador                Ps,
           Dbaps.Lote_Guia_Web_Parametros Lp,
           Dbaps.Itguia                   It
    
     Where g.Cd_Matricula = u.Cd_Matricula(+)
       And g.Cd_Tipo_Atendimento = Ta.Cd_Tipo_Atendimento
       And g.Cd_Prestador_Executor = Pf.Cd_Prestador(+)
       And g.Cd_Prestador_Solicitante = Ps.Cd_Prestador(+)
       And g.Nr_Guia = It.Nr_Guia
       And Lp.Cd_Lote = Pcd_Lote_Autweb
       And Lp.Nr_Guia = g.Nr_Guia 
         --And g.cd_prestador_executor <> 1001094 -- Solicitado no chamado CH2305-3877
       And g.Cd_Tipo_Atendimento = 11
       And 180 < (Select Trunc(Sysdate) - Min(Trunc(Ie.Dt_Execucao)) As Dias_Primeira_Execucao
                    From Itguia_Execucao Ie, Dbaps.Itguia It
                   Where Ie.Cd_Itguia = It.Cd_Itguia
                     And It.Nr_Guia = g.Nr_Guia)
       And Not Exists (Select 1
              From Dbaps.Guia_Web_Erros Gw
             Where Gw.Nr_Guia_Soul = Lp.Nr_Guia
               And Gw.Cd_Lote_Web_Parametros = Lp.Cd_Lote
               And Gw.Ds_Erro Like '%US006%');

  --Duplicidade de Guias SAdt/Execu��o [US004]

  Cursor Cguiaexecucaoduplicada Is
    Select Distinct Nvl(g.Nr_Carteira_Beneficiario, g.Nr_Carteira_Utilizada) As Carteira,
                    Regexp_Replace(g.Nr_Guia_Prestador, '[^[:digit:]]+') Nr_Guia_Prestador,
                    Regexp_Replace(g.Nr_Guia, '[^[:digit:]]+') Nr_Guia_Operadora,
                    Nvl(g.Cd_Prestador_Executor, g.Cd_Prestador) Cd_Prestador,
                    Substr(Nvl(g.Ds_Destino_Cortesia, u.Nm_Segurado), 1, 70) Nm_Beneficiario,
                    
                    Regexp_Replace(Nvl(g.Nr_Senha_Autorizacao, g.Nr_Guia),
                                   '[^[:digit:]]+') Nr_Senha_Autorizacao,
                    Nvl(Trunc(Ie.Dt_Execucao), It.Dt_Realizacao) As Dt_Realizacao
      From Dbaps.Guia                     g,
           Dbaps.Usuario                  u,
           Dbaps.Tipo_Atendimento         Ta,
           Dbaps.Prestador                Pf,
           Dbaps.Prestador                Ps,
           Dbaps.Lote_Guia_Web_Parametros Lp,
           Dbaps.Itguia                   It,
           Dbaps.Itguia_Execucao          Ie
     Where g.Cd_Matricula = u.Cd_Matricula(+)
       And g.Cd_Tipo_Atendimento = Ta.Cd_Tipo_Atendimento
          
       And g.Cd_Prestador_Executor = Pf.Cd_Prestador(+)
       And g.Cd_Prestador_Solicitante = Ps.Cd_Prestador(+)
       And g.Nr_Guia = Lp.Nr_Guia(+)
       And g.Nr_Guia = It.Nr_Guia
       And Ie.Cd_Itguia = It.Cd_Itguia
       And Lp.Sn_Guia_Web = 'N'
       And Lp.Cd_Lote = Pcd_Lote_Autweb
       And Pcd_Lote_Autweb Is Not Null
       And g.Cd_Tipo_Atendimento = 11
       And Ie.Cd_Lote_Guia_Web Is Null
          
       And Exists
     (Select 1
              From Dbaps.Remessa_Prestador Rp, Dbaps.Itremessa_Prestador Ip
             Where Rp.Cd_Remessa = Ip.Cd_Remessa
               And Ip.Cd_Procedimento =
                   Nvl(It.Cd_Procedimento, It.Cd_Procedimento_Autorizadorweb)
               And Trunc(Ip.Dt_Realizado) = Trunc(Ie.Dt_Execucao)
               And Rp.Nr_Carteira_Beneficiario =
                   Nvl(g.Nr_Carteira_Beneficiario, g.Nr_Carteira_Utilizada)
               And Ie.Cd_Remessa_Prestador Is Null
               And It.Tp_Status = 4
               And Rp.Cd_Prestador = g.Cd_Prestador)
       And Not Exists (Select 1
              From Dbaps.Guia_Web_Erros Gw
             Where Gw.Nr_Guia_Soul = Lp.Nr_Guia
               And Gw.Cd_Lote_Web_Parametros = Lp.Cd_Lote
               And Gw.Ds_Erro Like '%US004%');
  -- Duplicidade de Guias Consulta 1 [US004]

  Cursor Cguiasduplicidadasconsulta Is
  
    Select Distinct Nvl(g.Nr_Carteira_Beneficiario, g.Nr_Carteira_Utilizada) As Carteira,
                    Regexp_Replace(g.Nr_Guia_Prestador, '[^[:digit:]]+') Nr_Guia_Prestador,
                    Regexp_Replace(g.Nr_Guia, '[^[:digit:]]+') Nr_Guia_Operadora,
                    Nvl(g.Cd_Prestador_Executor, g.Cd_Prestador) Cd_Prestador,
                    Substr(Nvl(g.Ds_Destino_Cortesia, u.Nm_Segurado), 1, 70) Nm_Beneficiario,
                    
                    Regexp_Replace(Nvl(g.Nr_Senha_Autorizacao, g.Nr_Guia),
                                   '[^[:digit:]]+') Nr_Senha_Autorizacao
    
      From Dbaps.Guia                     g,
           Dbaps.Usuario                  u,
           Dbaps.Tipo_Atendimento         Ta,
           Dbaps.Prestador                Pf,
           Dbaps.Prestador                Ps,
           Dbaps.Lote_Guia_Web_Parametros Lp,
           Dbaps.Itguia                   It
    
     Where g.Cd_Matricula = u.Cd_Matricula(+)
       And g.Cd_Tipo_Atendimento = Ta.Cd_Tipo_Atendimento
       And g.Cd_Prestador_Executor = Pf.Cd_Prestador(+)
       And g.Cd_Prestador_Solicitante = Ps.Cd_Prestador(+)
          
       And g.Nr_Guia = It.Nr_Guia
          
       And Lp.Cd_Lote = Pcd_Lote_Autweb
       And Lp.Nr_Guia(+) = g.Nr_Guia
       And g.Cd_Tipo_Atendimento = 1
       And Exists (Select 1
              From Dbaps.Remessa_Prestador Rp
             Where g.Nr_Guia = Rp.Nr_Guia)
       And Not Exists (Select 1
              From Dbaps.Guia_Web_Erros Gw
             Where Gw.Nr_Guia_Soul = Lp.Nr_Guia
               And Gw.Cd_Lote_Web_Parametros = Lp.Cd_Lote
               And Gw.Ds_Erro Like '%US004%');

  -- Duplicidade de Guias [SADT] --> [US004]

  Cursor Cguiasduplicidadassadt Is
  
    Select Distinct Nvl(g.Nr_Carteira_Beneficiario, g.Nr_Carteira_Utilizada) As Carteira,
                    Regexp_Replace(g.Nr_Guia_Prestador, '[^[:digit:]]+') Nr_Guia_Prestador,
                    Regexp_Replace(g.Nr_Guia, '[^[:digit:]]+') Nr_Guia_Operadora,
                    Nvl(g.Cd_Prestador_Executor, g.Cd_Prestador) Cd_Prestador,
                    Substr(Nvl(g.Ds_Destino_Cortesia, u.Nm_Segurado), 1, 70) Nm_Beneficiario,
                    
                    Regexp_Replace(Nvl(g.Nr_Senha_Autorizacao, g.Nr_Guia),
                                   '[^[:digit:]]+') Nr_Senha_Autorizacao
    
      From Dbaps.Guia                     g,
           Dbaps.Usuario                  u,
           Dbaps.Tipo_Atendimento         Ta,
           Dbaps.Prestador                Pf,
           Dbaps.Prestador                Ps,
           Dbaps.Lote_Guia_Web_Parametros Lp,
           Dbaps.Itguia                   It
    
     Where g.Cd_Matricula = u.Cd_Matricula(+)
       And g.Cd_Tipo_Atendimento = Ta.Cd_Tipo_Atendimento
       And g.Cd_Prestador_Executor = Pf.Cd_Prestador(+)
       And g.Cd_Prestador_Solicitante = Ps.Cd_Prestador(+)
       And g.Nr_Guia = It.Nr_Guia
       And Lp.Cd_Lote = Pcd_Lote_Autweb
       And Lp.Nr_Guia(+) = g.Nr_Guia
       And g.Cd_Tipo_Atendimento = 2
       And Exists (Select 1
              From Dbaps.Remessa_Prestador Rp
             Where g.Nr_Guia = Rp.Nr_Guia)
       And Not Exists (Select 1
              From Dbaps.Guia_Web_Erros Gw
             Where Gw.Nr_Guia_Soul = Lp.Nr_Guia
               And Gw.Cd_Lote_Web_Parametros = Lp.Cd_Lote
               And Gw.Ds_Erro Like '%US004%');

  Cursor Cguiasduplicidadasinternacao Is --Duplicidade de Guias [INTERNA��O] --> [US004]
    Select Distinct Nvl(g.Nr_Carteira_Beneficiario, g.Nr_Carteira_Utilizada) As Carteira,
                    Regexp_Replace(g.Nr_Guia_Prestador, '[^[:digit:]]+') Nr_Guia_Prestador,
                    Regexp_Replace(g.Nr_Guia, '[^[:digit:]]+') Nr_Guia_Operadora,
                    Nvl(g.Cd_Prestador_Executor, g.Cd_Prestador) Cd_Prestador,
                    Substr(Nvl(g.Ds_Destino_Cortesia, u.Nm_Segurado), 1, 70) Nm_Beneficiario,
                    
                    Regexp_Replace(Nvl(g.Nr_Senha_Autorizacao, g.Nr_Guia),
                                   '[^[:digit:]]+') Nr_Senha_Autorizacao
    
      From Dbaps.Guia                     g,
           Dbaps.Usuario                  u,
           Dbaps.Tipo_Atendimento         Ta,
           Dbaps.Prestador                Pf,
           Dbaps.Prestador                Ps,
           Dbaps.Lote_Guia_Web_Parametros Lp,
           Dbaps.Itguia                   It
    
     Where g.Cd_Matricula = u.Cd_Matricula(+)
       And g.Cd_Tipo_Atendimento = Ta.Cd_Tipo_Atendimento
       And g.Cd_Prestador_Executor = Pf.Cd_Prestador(+)
       And g.Cd_Prestador_Solicitante = Ps.Cd_Prestador(+)
       And g.Nr_Guia = It.Nr_Guia
       And Lp.Cd_Lote = Pcd_Lote_Autweb
       And Lp.Nr_Guia(+) = g.Nr_Guia
       And g.Cd_Tipo_Atendimento = 3
       And Exists (Select 1
              From Dbaps.Conta_Hospitalar Ch
             Where g.Nr_Guia = Ch.Nr_Guia)
       And Not Exists (Select 1
              From Dbaps.Guia_Web_Erros Gw
             Where Gw.Nr_Guia_Soul = Lp.Nr_Guia
               And Gw.Cd_Lote_Web_Parametros = Lp.Cd_Lote
               And Gw.Ds_Erro Like '%US004%');

  --Execu��o 70 dias ap�s data atual

  Cursor Cguiaexecucao70dias Is
    Select Distinct Nvl(g.Nr_Carteira_Beneficiario, g.Nr_Carteira_Utilizada) As Carteira,
                    Regexp_Replace(g.Nr_Guia_Prestador, '[^[:digit:]]+') Nr_Guia_Prestador,
                    Regexp_Replace(g.Nr_Guia, '[^[:digit:]]+') Nr_Guia_Operadora,
                    Nvl(g.Cd_Prestador_Executor, g.Cd_Prestador) Cd_Prestador,
                    Substr(Nvl(g.Ds_Destino_Cortesia, u.Nm_Segurado), 1, 70) Nm_Beneficiario,
                    
                    Regexp_Replace(Nvl(g.Nr_Senha_Autorizacao, g.Nr_Guia),
                                   '[^[:digit:]]+') Nr_Senha_Autorizacao
    
      From Dbaps.Guia                     g,
           Dbaps.Usuario                  u,
           Dbaps.Tipo_Atendimento         Ta,
           Dbaps.Prestador                Pf,
           Dbaps.Prestador                Ps,
           Dbaps.Lote_Guia_Web_Parametros Lp,
           Dbaps.Itguia                   It
    
     Where g.Cd_Matricula = u.Cd_Matricula(+)
       And g.Cd_Tipo_Atendimento = Ta.Cd_Tipo_Atendimento
          
          --AND G.CD_PRESTADOR_EXECUTOR_PF = PF.CD_PRESTADOR(+)
       And g.Cd_Prestador_Executor = Pf.Cd_Prestador(+)
       And g.Cd_Prestador_Solicitante = Ps.Cd_Prestador(+)
       And g.Nr_Guia = Lp.Nr_Guia
       And g.Nr_Guia = It.Nr_Guia
       And Lp.Sn_Guia_Web = 'N'
       And Lp.Cd_Lote = Pcd_Lote_Autweb
       And Pcd_Lote_Autweb Is Not Null
          -- And g.Nr_Guia = 74193649 
       And It.Qt_Solicitado <> 0 -- Solicita��o Efraim CH2211-2246
       And g.Cd_Tipo_Atendimento In (1, 2, 3)
       And g.Cd_Tipo_Atendimento_Tiss <> 3
       And Trunc(Sysdate) - Trunc(It.Dt_Realizacao) > 70
       And g.Nr_Guia Not In ('115033529','115033969','117260719','115035249')
       And Not Exists (Select 1
              From Dbaps.Guia_Web_Erros Gw
             Where Gw.Nr_Guia_Soul = Lp.Nr_Guia
               And Gw.Cd_Lote_Web_Parametros = Lp.Cd_Lote
               And Gw.Ds_Erro Like '%US011%');

  Cursor Cprazoexcecidoportal Is
    Select Distinct Nvl(g.Nr_Carteira_Beneficiario, g.Nr_Carteira_Utilizada) As Carteira,
                    Regexp_Replace(g.Nr_Guia_Prestador, '[^[:digit:]]+') Nr_Guia_Prestador,
                    Regexp_Replace(g.Nr_Guia, '[^[:digit:]]+') Nr_Guia_Operadora,
                    Nvl(g.Cd_Prestador_Executor, g.Cd_Prestador) Cd_Prestador,
                    Substr(Nvl(g.Ds_Destino_Cortesia, u.Nm_Segurado), 1, 70) Nm_Beneficiario,
                    
                    Regexp_Replace(Nvl(g.Nr_Senha_Autorizacao, g.Nr_Guia),
                                   '[^[:digit:]]+') Nr_Senha_Autorizacao
    
      From Dbaps.Guia                     g,
           Dbaps.Usuario                  u,
           Dbaps.Tipo_Atendimento         Ta,
           Dbaps.Prestador                Pf,
           Dbaps.Prestador                Ps,
           Dbaps.Lote_Guia_Web_Parametros Lp,
           Dbaps.Itguia                   It
    
     Where g.Cd_Matricula = u.Cd_Matricula(+)
       And g.Cd_Tipo_Atendimento = Ta.Cd_Tipo_Atendimento
          
          --AND G.CD_PRESTADOR_EXECUTOR_PF = PF.CD_PRESTADOR(+)
       And g.Cd_Prestador_Executor = Pf.Cd_Prestador(+)
       And g.Cd_Prestador_Solicitante = Ps.Cd_Prestador(+)
       And g.Nr_Guia = Lp.Nr_Guia
       And g.Nr_Guia = It.Nr_Guia
       And Lp.Sn_Guia_Web = 'N'
       And Lp.Cd_Lote = Pcd_Lote_Autweb
       And Pcd_Lote_Autweb Is Not Null
       And (g.Cd_Tipo_Atendimento Not In (2, 11) And
           g.Cd_Tipo_Atendimento_Tiss Not In (3, 23))
       And Trunc(It.Dt_Realizacao) <= Trunc(Sysdate) - 60
          -- 17/10/2022 exce��a para 3 guias skype: 08:37
       And g.Nr_Guia Not In ('101187119',
                             '101188299',
                             '101190639',
                             '101183669',
                             '101190639',
                             '101505419')
       And Not Exists (Select 1
              From Dbaps.Guia_Web_Erros Gw
             Where Gw.Nr_Guia_Soul = Lp.Nr_Guia
               And Gw.Cd_Lote_Web_Parametros = Lp.Cd_Lote
               And Gw.Ds_Erro Like '%US009%');

  --US010
  Cursor Climitetaxa Is
    Select a.Carteira,
           a.Nr_Guia_Prestador,
           a.Nr_Guia_Operadora,
           a.Cd_Prestador,
           a.Nm_Beneficiario,
           a.Nr_Senha_Autorizacao,
           Sum(a.Proctaxa) As Qtd_Taxa,
           a.Dt_Realizacao
      From (Select Distinct Nvl(g.Nr_Carteira_Beneficiario,
                                g.Nr_Carteira_Utilizada) As Carteira,
                            Regexp_Replace(g.Nr_Guia_Prestador,
                                           '[^[:digit:]]+') Nr_Guia_Prestador,
                            Regexp_Replace(g.Nr_Guia, '[^[:digit:]]+') Nr_Guia_Operadora,
                            Nvl(g.Cd_Prestador_Executor, g.Cd_Prestador) Cd_Prestador,
                            Substr(Nvl(g.Ds_Destino_Cortesia, u.Nm_Segurado),
                                   1,
                                   70) Nm_Beneficiario,
                            
                            Regexp_Replace(Nvl(g.Nr_Senha_Autorizacao,
                                               g.Nr_Guia),
                                           '[^[:digit:]]+') Nr_Senha_Autorizacao,
                            1 As Proctaxa,
                            It.Cd_Itguia,
                            It.Dt_Realizacao
              From Dbaps.Guia                     g,
                   Dbaps.Usuario                  u,
                   Dbaps.Tipo_Atendimento         Ta,
                   Dbaps.Prestador                Pf,
                   Dbaps.Prestador                Ps,
                   Dbaps.Lote_Guia_Web_Parametros Lp,
                   Dbaps.Itguia                   It,
                   Dbaps.Procedimento             p
            
             Where g.Cd_Matricula = u.Cd_Matricula(+)
               And g.Cd_Tipo_Atendimento = Ta.Cd_Tipo_Atendimento
                  
                  --AND G.CD_PRESTADOR_EXECUTOR_PF = PF.CD_PRESTADOR(+)
               And g.Cd_Prestador_Executor = Pf.Cd_Prestador(+)
               And g.Cd_Prestador_Solicitante = Ps.Cd_Prestador(+)
               And g.Nr_Guia = Lp.Nr_Guia
               And g.Nr_Guia = It.Nr_Guia
               And Lp.Sn_Guia_Web = 'N'
               And p.Cd_Procedimento =
                   Nvl(It.Cd_Procedimento, It.Cd_Procedimento_Autorizadorweb)
               And p.Cd_Procedimento In ('60023001',
                                         '60023022',
                                         '60023033',
                                         '60023384',
                                         '60023287',
                                         '60023244')
               And It.Tp_Status = 4
               And Lp.Cd_Lote = Pcd_Lote_Autweb
               And Pcd_Lote_Autweb Is Not Null
               And Not Exists
             (Select 1
                      From Dbaps.Guia_Web_Erros Gw
                     Where Gw.Nr_Guia_Soul = Lp.Nr_Guia
                       And Gw.Cd_Lote_Web_Parametros = Lp.Cd_Lote
                       And Gw.Ds_Erro Like '%US010%')) a
     Where Rownum <= 5
     Group By a.Carteira,
              a.Nr_Guia_Prestador,
              a.Nr_Guia_Operadora,
              a.Cd_Prestador,
              a.Nm_Beneficiario,
              a.Nr_Senha_Autorizacao,
              a.Dt_Realizacao
    
    Having Sum(a.Proctaxa) > 1;

  Cursor Cvalorzerado Is
    Select Distinct Nvl(g.Nr_Carteira_Beneficiario, g.Nr_Carteira_Utilizada) As Carteira,
                    Regexp_Replace(g.Nr_Guia_Prestador, '[^[:digit:]]+') Nr_Guia_Prestador,
                    Regexp_Replace(g.Nr_Guia, '[^[:digit:]]+') Nr_Guia_Operadora,
                    Nvl(g.Cd_Prestador_Executor, g.Cd_Prestador) Cd_Prestador,
                    Substr(Nvl(g.Ds_Destino_Cortesia, u.Nm_Segurado), 1, 70) Nm_Beneficiario,
                    
                    Regexp_Replace(Nvl(g.Nr_Senha_Autorizacao, g.Nr_Guia),
                                   '[^[:digit:]]+') Nr_Senha_Autorizacao
    
      From Dbaps.Guia                     g,
           Dbaps.Usuario                  u,
           Dbaps.Tipo_Atendimento         Ta,
           Dbaps.Prestador                Pf,
           Dbaps.Prestador                Ps,
           Dbaps.Lote_Guia_Web_Parametros Lp,
           Dbaps.Itguia                   It
    
     Where g.Cd_Matricula = u.Cd_Matricula(+)
       And g.Cd_Tipo_Atendimento = Ta.Cd_Tipo_Atendimento
       And g.Cd_Prestador_Executor = Pf.Cd_Prestador(+)
       And g.Cd_Prestador_Solicitante = Ps.Cd_Prestador(+)
       And g.Nr_Guia = It.Nr_Guia
       And Lp.Cd_Lote = Pcd_Lote_Autweb
       And Lp.Nr_Guia = g.Nr_Guia
       And (It.Vl_Cobrado = 0 Or It.Vl_Cobrado Is Null)
       And It.Dt_Realizacao Is Not Null
       And Not Exists (Select 1
              From Dbaps.Guia_Web_Erros Gw
             Where Gw.Nr_Guia_Soul = Lp.Nr_Guia
               And Gw.Cd_Lote_Web_Parametros = Lp.Cd_Lote
               And Gw.Ds_Erro Like '%US015%');

  -- CH2209-5401 TRAVA NO XML PARA EVITAR ENVIO DE GUIA INTERNA COMO SENDO GUIA EXTERNA.      
  Cursor c_Guia_Interna_Como_Externa Is
    Select Distinct Nvl(g.Nr_Carteira_Beneficiario, g.Nr_Carteira_Utilizada) As Carteira,
                    Regexp_Replace(g.Nr_Guia_Prestador, '[^[:digit:]]+') Nr_Guia_Prestador,
                    Regexp_Replace(g.Nr_Guia, '[^[:digit:]]+') Nr_Guia_Operadora,
                    Nvl(g.Cd_Prestador_Executor, g.Cd_Prestador) Cd_Prestador,
                    Substr(Nvl(g.Ds_Destino_Cortesia, u.Nm_Segurado), 1, 70) Nm_Beneficiario,
                    
                    Regexp_Replace(Nvl(g.Nr_Senha_Autorizacao, g.Nr_Guia),
                                   '[^[:digit:]]+') Nr_Senha_Autorizacao
    
      From Dbaps.Guia g, Dbaps.Usuario u, Dbaps.Lote_Guia_Web_Parametros Lp
    
     Where g.Cd_Matricula = u.Cd_Matricula(+)
       And Lp.Cd_Lote = Pcd_Lote_Autweb
       And Lp.Nr_Guia = g.Nr_Guia
       And (g.Nr_Guia Is Null Or g.Nr_Guia = '0')
       And g.Nr_Guia_Prestador Is Not Null
       And g.Tp_Origem = 'MVS' --GUIA INTERNA 
       And Not Exists (Select 1
              From Dbaps.Guia_Web_Erros Gw
             Where Gw.Nr_Guia_Soul = Lp.Nr_Guia
               And Gw.Cd_Lote_Web_Parametros = Lp.Cd_Lote
               And Gw.Ds_Erro Like '%US018%');

  -- VALIDA SE O PROCEDIMENTO EXECUTADO POSSUI DATA INFORMADA
  Cursor c_Dt_Realizado_Is_Null Is
    Select Distinct Nvl(g.Nr_Carteira_Beneficiario, g.Nr_Carteira_Utilizada) As Carteira,
                    Regexp_Replace(g.Nr_Guia_Prestador, '[^[:digit:]]+') Nr_Guia_Prestador,
                    Regexp_Replace(g.Nr_Guia, '[^[:digit:]]+') Nr_Guia_Operadora,
                    Nvl(g.Cd_Prestador_Executor, g.Cd_Prestador) Cd_Prestador,
                    Substr(Nvl(g.Ds_Destino_Cortesia, u.Nm_Segurado), 1, 70) Nm_Beneficiario,
                    
                    Regexp_Replace(Nvl(g.Nr_Senha_Autorizacao, g.Nr_Guia),
                                   '[^[:digit:]]+') Nr_Senha_Autorizacao
    
      From Dbaps.Guia                     g,
           Dbaps.Itguia                   It,
           Dbaps.Usuario                  u,
           Dbaps.Lote_Guia_Web_Parametros Lp
    
     Where g.Cd_Matricula = u.Cd_Matricula(+)
       And It.Nr_Guia = g.Nr_Guia
       And Lp.Cd_Lote = Pcd_Lote_Autweb
       And Lp.Nr_Guia = g.Nr_Guia
       And g.Cd_Tipo_Atendimento = 2 -- SADT CONFORME ALINHADO COM EFRAIM 10/11/2022 CH2211-1251  
       And It.Qt_Solicitado <> 0 -- Solicita��o Efraim CH2211-2246
       And It.Dt_Realizacao Is Null
       And Not Exists (Select 1
              From Dbaps.Guia_Web_Erros Gw
             Where Gw.Nr_Guia_Soul = Lp.Nr_Guia
               And Gw.Cd_Lote_Web_Parametros = Lp.Cd_Lote
               And Gw.Ds_Erro Like '%US019%');

  Cursor Cprocedimentoviaacesso Is
  
    Select Distinct Nvl(g.Nr_Carteira_Beneficiario, g.Nr_Carteira_Utilizada) As Carteira,
                    Regexp_Replace(g.Nr_Guia_Prestador, '[^[:digit:]]+') Nr_Guia_Prestador,
                    Regexp_Replace(g.Nr_Guia, '[^[:digit:]]+') Nr_Guia_Operadora,
                    Nvl(g.Cd_Prestador_Executor, g.Cd_Prestador) Cd_Prestador,
                    Substr(Nvl(g.Ds_Destino_Cortesia, u.Nm_Segurado), 1, 70) Nm_Beneficiario,
                    
                    Regexp_Replace(Nvl(g.Nr_Senha_Autorizacao, g.Nr_Guia),
                                   '[^[:digit:]]+') Nr_Senha_Autorizacao,
                    It.Cd_Procedimento
    
      From Dbaps.Guia                     g,
           Dbaps.Usuario                  u,
           Dbaps.Tipo_Atendimento         Ta,
           Dbaps.Prestador                Pf,
           Dbaps.Prestador                Ps,
           Dbaps.Lote_Guia_Web_Parametros Lp,
           Dbaps.Itguia                   It
    
     Where g.Cd_Matricula = u.Cd_Matricula(+)
       And g.Cd_Tipo_Atendimento = Ta.Cd_Tipo_Atendimento
       And g.Cd_Prestador_Executor = Pf.Cd_Prestador(+)
       And g.Cd_Prestador_Solicitante = Ps.Cd_Prestador(+)
       And g.Nr_Guia = It.Nr_Guia
       And Lp.Cd_Lote = Pcd_Lote_Autweb
       And Lp.Nr_Guia = g.Nr_Guia
       And It.Cd_Via_Acesso Is Not Null
       And It.Qt_Solicitado <> 0 -- CH2211-1974 inclus�o da regra e reativa��o.
       And Exists (Select 1
              From Dbaps.Procedimento p
             Where p.Cd_Procedimento = It.Cd_Procedimento
               And p.Sn_Via_Acesso = 'N')
       And Not Exists (Select 1
              From Dbaps.Guia_Web_Erros Gw
             Where Gw.Nr_Guia_Soul = Lp.Nr_Guia
               And Gw.Cd_Lote_Web_Parametros = Lp.Cd_Lote
               And Gw.Ds_Erro Like '%US021%');

  -- INICIO CH2209-5400 TRAVA PARA C�DIGOS RACIONALIZA��O SEM AUTORIZACAO
  Cursor Ccodracionalizacaosemautoriza Is
    Select Distinct Nvl(g.Nr_Carteira_Beneficiario, g.Nr_Carteira_Utilizada) As Carteira,
                    Regexp_Replace(g.Nr_Guia_Prestador, '[^[:digit:]]+') Nr_Guia_Prestador,
                    Regexp_Replace(g.Nr_Guia, '[^[:digit:]]+') Nr_Guia_Operadora,
                    Nvl(g.Cd_Prestador_Executor, g.Cd_Prestador) Cd_Prestador,
                    Substr(Nvl(g.Ds_Destino_Cortesia, u.Nm_Segurado), 1, 70) Nm_Beneficiario,
                    
                    Regexp_Replace(Nvl(g.Nr_Senha_Autorizacao, g.Nr_Guia),
                                   '[^[:digit:]]+') Nr_Senha_Autorizacao,
                    It.Cd_Procedimento
    
      From Dbaps.Guia                     g,
           Dbaps.Usuario                  u,
           Dbaps.Lote_Guia_Web_Parametros Lp,
           Dbaps.Itguia                   It
    
     Where g.Cd_Matricula = u.Cd_Matricula(+)
       And g.Nr_Guia = It.Nr_Guia
       And Lp.Cd_Lote = Pcd_Lote_Autweb
       And Lp.Nr_Guia = g.Nr_Guia
       And (g.Nr_Guia Is Null Or g.Nr_Guia = 0)
       And Exists
     (Select 1
              From Dbaps.Procedimento p, Dbaps.Grupo_Procedimento Gp
             Where p.Cd_Grupo_Procedimento = Gp.Cd_Grupo_Procedimento
               And p.Cd_Procedimento = It.Cd_Procedimento
               And Gp.Tp_Gru_Pro In ('SD', 'SP')
               And Not Exists
             (Select 2
                      From Dbaps.Procedimento_Baixo_Risco Pbr
                     Where Pbr.Cd_Procedimento = p.Cd_Procedimento
                       And To_Date(Pbr.Dt_Vigencia, 'DD/MM/YYYY') <=
                           To_Date(Sysdate, 'DD/MM/YYYY')))
       And Not Exists (Select 1
              From Dbaps.Guia_Web_Erros Gw
             Where Gw.Nr_Guia_Soul = Lp.Nr_Guia
               And Gw.Cd_Lote_Web_Parametros = Lp.Cd_Lote
               And Gw.Ds_Erro Like '%US022%');

  Cursor Cviaacesso Is
    Select Distinct Nvl(g.Nr_Carteira_Beneficiario, g.Nr_Carteira_Utilizada) As Carteira,
                    Regexp_Replace(g.Nr_Guia_Prestador, '[^[:digit:]]+') Nr_Guia_Prestador,
                    Regexp_Replace(g.Nr_Guia, '[^[:digit:]]+') Nr_Guia_Operadora,
                    Nvl(g.Cd_Prestador_Executor, g.Cd_Prestador) Cd_Prestador,
                    Substr(Nvl(g.Ds_Destino_Cortesia, u.Nm_Segurado), 1, 70) Nm_Beneficiario,
                    
                    Regexp_Replace(Nvl(g.Nr_Senha_Autorizacao, g.Nr_Guia),
                                   '[^[:digit:]]+') Nr_Senha_Autorizacao,
                    It.Cd_Procedimento
      From Dbaps.Guia                     g,
           Dbaps.Usuario                  u,
           Dbaps.Lote_Guia_Web_Parametros Lp,
           Dbaps.Itguia                   It
    
     Where g.Cd_Matricula = u.Cd_Matricula(+)
       And g.Nr_Guia = It.Nr_Guia
       And Lp.Cd_Lote = Pcd_Lote_Autweb
       And Lp.Nr_Guia(+) = g.Nr_Guia
       And (It.Cd_Procedimento = '41001133' And It.Cd_Via_Acesso <> 1)
          
       And Not Exists (Select 1
              From Dbaps.Guia_Web_Erros Gw
             Where Gw.Nr_Guia_Soul = Lp.Nr_Guia
               And Gw.Cd_Lote_Web_Parametros = Lp.Cd_Lote
               And Gw.Ds_Erro Like '%US027%');

  Cursor Ctipoatendimentotisscod Is
    Select Distinct Nvl(g.Nr_Carteira_Beneficiario, g.Nr_Carteira_Utilizada) As Carteira,
                    Regexp_Replace(g.Nr_Guia_Prestador, '[^[:digit:]]+') Nr_Guia_Prestador,
                    Regexp_Replace(g.Nr_Guia, '[^[:digit:]]+') Nr_Guia_Operadora,
                    Nvl(g.Cd_Prestador_Executor, g.Cd_Prestador) Cd_Prestador,
                    Substr(Nvl(g.Ds_Destino_Cortesia, u.Nm_Segurado), 1, 70) Nm_Beneficiario,
                    
                    Regexp_Replace(Nvl(g.Nr_Senha_Autorizacao, g.Nr_Guia),
                                   '[^[:digit:]]+') Nr_Senha_Autorizacao,
                    It.Cd_Procedimento
      From Dbaps.Guia                     g,
           Dbaps.Usuario                  u,
           Dbaps.Lote_Guia_Web_Parametros Lp,
           Dbaps.Itguia                   It
    
     Where g.Cd_Matricula = u.Cd_Matricula(+)
       And g.Nr_Guia = It.Nr_Guia
       And Lp.Cd_Lote = Pcd_Lote_Autweb
       And Lp.Nr_Guia(+) = g.Nr_Guia
       And (It.Cd_Procedimento = '10101063' And
           g.Cd_Tipo_Atendimento_Tiss <> 23)
          
       And Not Exists (Select 1
              From Dbaps.Guia_Web_Erros Gw
             Where Gw.Nr_Guia_Soul = Lp.Nr_Guia
               And Gw.Cd_Lote_Web_Parametros = Lp.Cd_Lote
               And Gw.Ds_Erro Like '%US029%');

  Cursor Csadttratseriadoblock Is
    Select Distinct Nvl(g.Nr_Carteira_Beneficiario, g.Nr_Carteira_Utilizada) As Carteira,
                    Regexp_Replace(g.Nr_Guia_Prestador, '[^[:digit:]]+') Nr_Guia_Prestador,
                    Regexp_Replace(g.Nr_Guia, '[^[:digit:]]+') Nr_Guia_Operadora,
                    Nvl(g.Cd_Prestador_Executor, g.Cd_Prestador) Cd_Prestador,
                    Substr(Nvl(g.Ds_Destino_Cortesia, u.Nm_Segurado), 1, 70) Nm_Beneficiario,
                    
                    Regexp_Replace(Nvl(g.Nr_Senha_Autorizacao, g.Nr_Guia),
                                   '[^[:digit:]]+') Nr_Senha_Autorizacao,
                    It.Cd_Procedimento
      From Dbaps.Guia                     g,
           Dbaps.Usuario                  u,
           Dbaps.Lote_Guia_Web_Parametros Lp,
           Dbaps.Itguia                   It
    
     Where g.Cd_Matricula = u.Cd_Matricula(+)
       And g.Nr_Guia = It.Nr_Guia
       And Lp.Cd_Lote = Pcd_Lote_Autweb
       And Lp.Nr_Guia(+) = g.Nr_Guia
       And g.Cd_Tipo_Atendimento = 2
       And (It.Qt_Exec <> 1 Or It.Qt_Exec Is Null)
       And Exists (Select 1
              From Custom.Procedimento_Block_Aut_Web Pweb
             Where Pweb.Cd_Procedimento = It.Cd_Procedimento)
       And Not Exists (Select 1
              From Dbaps.Guia_Web_Erros Gw
             Where Gw.Nr_Guia_Soul = Lp.Nr_Guia
               And Gw.Cd_Lote_Web_Parametros = Lp.Cd_Lote
               And Gw.Ds_Erro Like '%US030%');

  Cursor Creducaoacrescimo Is
    Select Distinct Nvl(g.Nr_Carteira_Beneficiario, g.Nr_Carteira_Utilizada) As Carteira,
                    Regexp_Replace(g.Nr_Guia_Prestador, '[^[:digit:]]+') Nr_Guia_Prestador,
                    Regexp_Replace(g.Nr_Guia, '[^[:digit:]]+') Nr_Guia_Operadora,
                    Nvl(g.Cd_Prestador_Executor, g.Cd_Prestador) Cd_Prestador,
                    Substr(Nvl(g.Ds_Destino_Cortesia, u.Nm_Segurado), 1, 70) Nm_Beneficiario,
                    
                    Regexp_Replace(Nvl(g.Nr_Senha_Autorizacao, g.Nr_Guia),
                                   '[^[:digit:]]+') Nr_Senha_Autorizacao,
                    It.Cd_Procedimento,
                    It.Nr_Fator_Reducao_Acrescimo
      From Dbaps.Guia                     g,
           Dbaps.Usuario                  u,
           Dbaps.Lote_Guia_Web_Parametros Lp,
           Dbaps.Itguia                   It
    
     Where g.Cd_Matricula = u.Cd_Matricula(+)
       And g.Nr_Guia = It.Nr_Guia
       And Lp.Cd_Lote = Pcd_Lote_Autweb
       And Lp.Nr_Guia(+) = g.Nr_Guia
          
       And Exists
     (Select 1
              From Dbaps.Procedimento p, Dbaps.Grupo_Procedimento Gp
             Where p.Cd_Grupo_Procedimento = Gp.Cd_Grupo_Procedimento
               And p.Cd_Procedimento = It.Cd_Procedimento
               And Gp.Tp_Gru_Pro In ('SP', 'SD'))
       And (It.Nr_Fator_Reducao_Acrescimo Is Null Or
           It.Nr_Fator_Reducao_Acrescimo Not In
           (0.5, 0.70, 0.80, 1.0, 1.30, 1.60)
           
           )
       And Not Exists (Select 1
              From Dbaps.Guia_Web_Erros Gw
             Where Gw.Nr_Guia_Soul = Lp.Nr_Guia
               And Gw.Cd_Lote_Web_Parametros = Lp.Cd_Lote
               And Gw.Ds_Erro Like '%US032%')
    
    Union All ---MD, MT, OP, DI, TX         
    Select Distinct Nvl(g.Nr_Carteira_Beneficiario, g.Nr_Carteira_Utilizada) As Carteira,
                    Regexp_Replace(g.Nr_Guia_Prestador, '[^[:digit:]]+') Nr_Guia_Prestador,
                    Regexp_Replace(g.Nr_Guia, '[^[:digit:]]+') Nr_Guia_Operadora,
                    Nvl(g.Cd_Prestador_Executor, g.Cd_Prestador) Cd_Prestador,
                    Substr(Nvl(g.Ds_Destino_Cortesia, u.Nm_Segurado), 1, 70) Nm_Beneficiario,
                    
                    Regexp_Replace(Nvl(g.Nr_Senha_Autorizacao, g.Nr_Guia),
                                   '[^[:digit:]]+') Nr_Senha_Autorizacao,
                    It.Cd_Procedimento,
                    It.Nr_Fator_Reducao_Acrescimo
      From Dbaps.Guia                     g,
           Dbaps.Usuario                  u,
           Dbaps.Lote_Guia_Web_Parametros Lp,
           Dbaps.Itguia                   It
    
     Where g.Cd_Matricula = u.Cd_Matricula(+)
       And g.Nr_Guia = It.Nr_Guia
       And Lp.Cd_Lote = Pcd_Lote_Autweb
       And Lp.Nr_Guia(+) = g.Nr_Guia
       And Exists
     (Select 1
              From Dbaps.Procedimento p, Dbaps.Grupo_Procedimento Gp
             Where p.Cd_Grupo_Procedimento = Gp.Cd_Grupo_Procedimento
               And p.Cd_Procedimento = It.Cd_Procedimento
               And Gp.Tp_Gru_Pro In ('MD', 'MT', 'OP', 'DI', 'TX'))
       And (It.Nr_Fator_Reducao_Acrescimo Is Null Or
           It.Nr_Fator_Reducao_Acrescimo <> 1.0)
       And Not Exists (Select 1
              From Dbaps.Guia_Web_Erros Gw
             Where Gw.Nr_Guia_Soul = Lp.Nr_Guia
               And Gw.Cd_Lote_Web_Parametros = Lp.Cd_Lote
               And Gw.Ds_Erro Like '%US032%');

  --Variaveis

  Vguiavencida                  Cguiavencida%Rowtype;
  Vguiaexecucaoduplicada        Cguiaexecucaoduplicada%Rowtype;
  Vguiasduplicidadasconsulta    Cguiasduplicidadasconsulta%Rowtype;
  Vguiasduplicidadassadt        Cguiasduplicidadassadt%Rowtype;
  Vguiasduplicidadasinternacao  Cguiasduplicidadasinternacao%Rowtype;
  Vguiaexecucao70dias           Cguiaexecucao70dias%Rowtype;
  Vprazoexcecidoportal          Cprazoexcecidoportal%Rowtype;
  Vlimitetaxa                   Climitetaxa%Rowtype;
  Vvalorzerado                  Cvalorzerado%Rowtype;
  Vc_Guia_Interna_Como_Externa  c_Guia_Interna_Como_Externa%Rowtype;
  Vc_Dt_Realizado_Is_Null       c_Dt_Realizado_Is_Null%Rowtype;
  Vprocedimentoviaacesso        Cprocedimentoviaacesso%Rowtype;
  Vcodracionalizacaosemautoriza Ccodracionalizacaosemautoriza%Rowtype;
  Vviaacesso                    Cviaacesso%Rowtype;
  Vtipoatendimentotisscod       Ctipoatendimentotisscod%Rowtype;
  Vsadttratseriadoblock         Csadttratseriadoblock%Rowtype;
  vreducaoacrescimo             Creducaoacrescimo%Rowtype;

  Vexcecao      Varchar2(200) := '';
  Vexcecaolinha Varchar2(1000) := '';
  Vcoderro      Varchar2(5) := '';

  Procedure Prc_Insere_Log_Erro(p_Numero_Carteira       In Varchar2,
                                p_Numero_Guia_Prestador In Varchar2,
                                p_Numero_Guia_Operadora In Varchar2,
                                p_Numero_Senha          In Varchar2,
                                p_Codigo_Prestador      In Varchar2,
                                p_Nm_Beneficiario       In Varchar2,
                                p_Tipo_Guia             In Varchar2,
                                p_Node_Xml              In Varchar2,
                                p_Node_Xml_Sub          In Varchar2,
                                p_Ds_Erro               In Varchar2,
                                p_Cd_Erro               In Varchar2,
                                p_Tp_Erro               In Varchar2,
                                p_Sn_Guia_Web           In Varchar2 Default 'N',
                                p_Procedimento          In Varchar2 Default Null) Is
    Binsereerro Boolean;
    Nteste      Number;
    Vdescricao  Varchar(4000 Char) := p_Ds_Erro;
  Begin
    -- G -> ERRO DE GUIA - APENAS UMA OCORRENCIA
    -- I -> ERRO DE ITEM DE GUIA - VARIAS OCORRENCIAS
    Binsereerro := True;
    Nteste      := Null;
  
    /*
     - String de apresentA��o para o PDF do PORTAL.:
    '[G001] - SENHA: XXXXXXXXX - GUIA PRESTADOR: XXXXXXXXX - Descricao do Problema.';
    '[P001] - SENHA: XXXXXXXXX - GUIA PRESTADOR: XXXXXXXXX - PROCEDIMENTO - Descricao do Problema.';
     - Para o autorizador a string sera simples!
    '[G001 ou P001] - Descricao do Problema.';
    */
    If (Pcd_Lote_Autweb Is Not Null) Then
      Vdescricao := p_Cd_Erro || ': ' || Vdescricao;
    Else
      If (p_Tp_Erro = 'G') Then
        Vdescricao := p_Cd_Erro || ' - SENHA: ' || p_Numero_Senha ||
                      ' - GUIA PRESTADOR: ' || p_Numero_Guia_Prestador ||
                      ' - ' || Vdescricao;
      Else
        Vdescricao := p_Cd_Erro || ' - SENHA: ' || p_Numero_Senha ||
                      ' - GUIA PRESTADOR: ' || p_Numero_Guia_Prestador ||
                      ' - ' || p_Procedimento || ' - ' || Vdescricao;
      End If;
    End If;
  
    If p_Tp_Erro = 'G' Then
      Open Cexisteerro(p_Cd_Erro,
                       Pcd_Protocolo_Ctamed,
                       p_Numero_Guia_Prestador);
      Fetch Cexisteerro
        Into Nteste;
      If Cexisteerro%Found Then
        Binsereerro := False;
      End If;
      Close Cexisteerro;
    End If;
    If Binsereerro Then
      If (Pcd_Lote_Autweb Is Not Null) Then
        Insert Into Dbaps.Guia_Web_Erros
          (Cd_Guia_Web_Erros,
           Nr_Guia,
           Ds_Erro,
           Cd_Procedimento,
           Nr_Guia_Soul,
           Cd_Lote_Web_Parametros)
        Values
          (Dbaps.Seq_Guia_Web.Nextval,
           Decode(p_Sn_Guia_Web, 'S', p_Numero_Guia_Operadora, Null),
           Vdescricao,
           p_Procedimento,
           Decode(p_Sn_Guia_Web, 'N', p_Numero_Guia_Operadora, Null),
           Pcd_Lote_Autweb);
      
        Commit;
      
      End If;
    End If;
  End;
Begin

  --Valida��es  

  Begin
    -- Duplicidade de Guias [SADT - EXECU��O] [US001]
    If (Custom.Pkg_Conmvs_Tiss_Xml.Fnc_Motivo_Portal(Pcd_Motivo         => 'US004',
                                                     p_Sn_Ativo_Aut_Web => 'S') = 'S') Then
    
      For Vguiaexecucaoduplicada In Cguiaexecucaoduplicada Loop
        Begin
        
          Prc_Insere_Log_Erro(Vguiaexecucaoduplicada.Carteira,
                              Vguiaexecucaoduplicada.Nr_Guia_Prestador,
                              Vguiaexecucaoduplicada.Nr_Guia_Operadora,
                              Vguiaexecucaoduplicada.Nr_Senha_Autorizacao,
                              Vguiaexecucaoduplicada.Cd_Prestador,
                              Vguiaexecucaoduplicada.Nm_Beneficiario,
                              '',
                              '',
                              'Guia: ' ||
                              Vguiaexecucaoduplicada.Nr_Guia_Operadora ||
                              ' J� paga ' || Vexcecao || ' linha do erro: ' ||
                              Vexcecaolinha,
                              Vcoderro,
                              'Esse procedimento j� foi pago na data: ' ||
                              Vguiaexecucaoduplicada.Dt_Realizacao ||
                              ' - COD: US004 - [SADT - EXECU��O]',
                              'S');
        
        End;
      End Loop;
    
    End If;
    If (Cguiaexecucaoduplicada%Isopen) Then
      Close Cguiaexecucaoduplicada;
    End If;
  End;

  --Guias duplicadas --> Consulta [US001]

  Begin
  
    If (Custom.Pkg_Conmvs_Tiss_Xml.Fnc_Motivo_Portal(Pcd_Motivo         => 'US004',
                                                     p_Sn_Ativo_Aut_Web => 'S') = 'S') Then
    
      For Vguiasduplicidadasconsulta In Cguiasduplicidadasconsulta Loop
        Begin
        
          Prc_Insere_Log_Erro(Vguiasduplicidadasconsulta.Carteira,
                              Vguiasduplicidadasconsulta.Nr_Guia_Prestador,
                              Vguiasduplicidadasconsulta.Nr_Guia_Operadora,
                              Vguiasduplicidadasconsulta.Nr_Senha_Autorizacao,
                              Vguiasduplicidadasconsulta.Cd_Prestador,
                              Vguiasduplicidadasconsulta.Nm_Beneficiario,
                              '',
                              '',
                              'Guia: ' ||
                              Vguiasduplicidadasconsulta.Nr_Guia_Operadora ||
                              ' J� paga ' || Vexcecao || ' linha do erro: ' ||
                              Vexcecaolinha,
                              Vcoderro,
                              'Essa Guia j� foi Paga! - COD: US004 - [CONSULTA]',
                              'S');
        End;
      End Loop;
    End If;
    If (Cguiasduplicidadasconsulta%Isopen) Then
      Close Cguiasduplicidadasconsulta;
    End If;
  End;

  --Guias duplicadas --> SADT [US004]

  Begin
  
    If (Custom.Pkg_Conmvs_Tiss_Xml.Fnc_Motivo_Portal(Pcd_Motivo         => 'US004',
                                                     p_Sn_Ativo_Aut_Web => 'S') = 'S') Then
    
      For Vguiasduplicidadassadt In Cguiasduplicidadassadt Loop
        Begin
        
          Prc_Insere_Log_Erro(Vguiasduplicidadassadt.Carteira,
                              Vguiasduplicidadassadt.Nr_Guia_Prestador,
                              Vguiasduplicidadassadt.Nr_Guia_Operadora,
                              Vguiasduplicidadassadt.Nr_Senha_Autorizacao,
                              Vguiasduplicidadassadt.Cd_Prestador,
                              Vguiasduplicidadassadt.Nm_Beneficiario,
                              '',
                              '',
                              'Guia: ' ||
                              Vguiasduplicidadassadt.Nr_Guia_Operadora ||
                              ' J� paga ' || Vexcecao || ' linha do erro: ' ||
                              Vexcecaolinha,
                              Vcoderro,
                              'Essa Guia j� foi Paga! - COD: US004 - [SADT]',
                              'S');
        End;
      End Loop;
    
    End If;
  
    If (Cguiasduplicidadassadt%Isopen) Then
      Close Cguiasduplicidadassadt;
    End If;
  
  End;

  --Guias duplicadas --> INTERNA��O [US004]

  Begin
    If (Custom.Pkg_Conmvs_Tiss_Xml.Fnc_Motivo_Portal(Pcd_Motivo         => 'US004',
                                                     p_Sn_Ativo_Aut_Web => 'S') = 'S') Then
      For Vguiasduplicidadasinternacao In Cguiasduplicidadasinternacao Loop
        Begin
        
          Prc_Insere_Log_Erro(Vguiasduplicidadasinternacao.Carteira,
                              Vguiasduplicidadasinternacao.Nr_Guia_Prestador,
                              Vguiasduplicidadasinternacao.Nr_Guia_Operadora,
                              Vguiasduplicidadasinternacao.Nr_Senha_Autorizacao,
                              Vguiasduplicidadasinternacao.Cd_Prestador,
                              Vguiasduplicidadasinternacao.Nm_Beneficiario,
                              '',
                              '',
                              'Guia: ' ||
                              Vguiasduplicidadasinternacao.Nr_Guia_Operadora ||
                              ' J� paga ' || Vexcecao || ' linha do erro: ' ||
                              Vexcecaolinha,
                              Vcoderro,
                              'Essa Guia j� foi Paga! - COD: US004 - [INTERNA��O]',
                              'S');
        End;
      End Loop;
    End If;
  
    If (Cguiasduplicidadasinternacao%Isopen) Then
      Close Cguiasduplicidadasinternacao;
    End If;
  
  End;

  --Execu��o 70 dias

  Begin
    If (Custom.Pkg_Conmvs_Tiss_Xml.Fnc_Motivo_Portal(Pcd_Motivo         => 'US011',
                                                     p_Sn_Ativo_Aut_Web => 'S') = 'S') Then
      For Vguiaexecucao70dias In Cguiaexecucao70dias Loop
        Begin
        
          Prc_Insere_Log_Erro(Vguiaexecucao70dias.Carteira,
                              Vguiaexecucao70dias.Nr_Guia_Prestador,
                              Vguiaexecucao70dias.Nr_Guia_Operadora,
                              Vguiaexecucao70dias.Nr_Senha_Autorizacao,
                              Vguiaexecucao70dias.Cd_Prestador,
                              Vguiaexecucao70dias.Nm_Beneficiario,
                              '',
                              '',
                              'Guia: ' ||
                              Vguiaexecucao70dias.Nr_Guia_Operadora ||
                              ' Est� a 70 dias ap�s vencimento ' ||
                              Vexcecao || ' linha do erro: ' ||
                              Vexcecaolinha,
                              Vcoderro,
                              'Limite de 70 dias ap�s a execu��o desta guia excedido ! - COD: US011 - [LIMITE EXCEDIDO]',
                              'S');
        End;
      
      End Loop;
    End If;
  
    If (Cguiaexecucao70dias%Isopen) Then
      Close Cguiaexecucao70dias;
    End If;
  
  End;

  --Guia vencida

  Begin
  
    If (Custom.Pkg_Conmvs_Tiss_Xml.Fnc_Motivo_Portal(Pcd_Motivo         => 'US006',
                                                     p_Sn_Ativo_Aut_Web => 'S') = 'S') Then
    
      For Vguiavencida In Cguiavencida Loop
        Begin
        
          Prc_Insere_Log_Erro(Vguiavencida.Carteira,
                              Vguiavencida.Nr_Guia_Prestador,
                              Vguiavencida.Nr_Guia_Operadora,
                              Vguiavencida.Nr_Senha_Autorizacao,
                              Vguiavencida.Cd_Prestador,
                              Vguiavencida.Nm_Beneficiario,
                              '',
                              '',
                              'Guia: ' || Vguiavencida.Nr_Guia_Operadora ||
                              ' Vencida ' || Vexcecao || ' linha do erro: ' ||
                              Vexcecaolinha,
                              Vcoderro,
                              'Essa Guia est� vencida! - COD: US006 - [GUIA VENCIDA]',
                              'S');
        End;
      End Loop;
    End If;
    If (Cguiavencida%Isopen) Then
    
      Close Cguiavencida;
    End If;
  
  End;

  -- Prazo execido portal 60 dias ap�s execu��o

  Begin
    If (Custom.Pkg_Conmvs_Tiss_Xml.Fnc_Motivo_Portal(Pcd_Motivo         => 'US009',
                                                     p_Sn_Ativo_Aut_Web => 'S') = 'S') Then
      For Vprazoexcecidoportal In Cprazoexcecidoportal Loop
        Begin
        
          Prc_Insere_Log_Erro(Vprazoexcecidoportal.Carteira,
                              Vprazoexcecidoportal.Nr_Guia_Prestador,
                              Vprazoexcecidoportal.Nr_Guia_Operadora,
                              Vprazoexcecidoportal.Nr_Senha_Autorizacao,
                              Vprazoexcecidoportal.Cd_Prestador,
                              Vprazoexcecidoportal.Nm_Beneficiario,
                              '',
                              '',
                              'Guia: ' ||
                              Vprazoexcecidoportal.Nr_Senha_Autorizacao ||
                              ' Vencida ' || Vexcecao || ' linha do erro: ' ||
                              Vexcecaolinha,
                              Vcoderro,
                              'Prazo limite do portal excedido! (60 dias) ap�s execu��o - COD: US009 - [PRAZO LIMITE PORTAL]',
                              'S');
        End;
      
      End Loop;
    
    End If;
    If (Cprazoexcecidoportal%Isopen) Then
      Close Cprazoexcecidoportal;
    End If;
  
  End;

  --Limite de Taxa

  Begin
    If (Custom.Pkg_Conmvs_Tiss_Xml.Fnc_Motivo_Portal(Pcd_Motivo         => 'US010',
                                                     p_Sn_Ativo_Aut_Web => 'S') = 'S') Then
    
      For Vlimitetaxa In Climitetaxa Loop
        Begin
        
          Prc_Insere_Log_Erro(Vlimitetaxa.Carteira,
                              Vlimitetaxa.Nr_Guia_Prestador,
                              Vlimitetaxa.Nr_Guia_Operadora,
                              Vlimitetaxa.Nr_Senha_Autorizacao,
                              Vlimitetaxa.Cd_Prestador,
                              Vlimitetaxa.Nm_Beneficiario,
                              '',
                              '',
                              'Guia: ' || Vlimitetaxa.Nr_Senha_Autorizacao ||
                              ' Vencida ' || Vexcecao || ' linha do erro: ' ||
                              Vexcecaolinha,
                              Vcoderro,
                              'Quantidade de Taxa na guia Ultrapassada (LIMITE 1) - COD: US010 - [LIMITE DE TAXA]',
                              'S');
        
        End;
      End Loop;
    End If;
    If (Climitetaxa%Isopen) Then
      Close Climitetaxa;
    End If;
  
  End;

  ---Valor zerado
  Begin
    If (Custom.Pkg_Conmvs_Tiss_Xml.Fnc_Motivo_Portal(Pcd_Motivo         => 'US015',
                                                     p_Sn_Ativo_Aut_Web => 'S') = 'S') Then
    
      For Vvalorzerado In Cvalorzerado Loop
        Begin
        
          Prc_Insere_Log_Erro(Vvalorzerado.Carteira,
                              Vvalorzerado.Nr_Guia_Prestador,
                              Vvalorzerado.Nr_Guia_Operadora,
                              Vvalorzerado.Nr_Senha_Autorizacao,
                              Vvalorzerado.Cd_Prestador,
                              Vvalorzerado.Nm_Beneficiario,
                              '',
                              '',
                              'Guia: ' || Vvalorzerado.Nr_Senha_Autorizacao ||
                              ' Vencida ' || Vexcecao || ' linha do erro: ' ||
                              Vexcecaolinha,
                              Vcoderro,
                              'Valor do Procedimento zerado - COD: US015 - [VALOR ZERADO]',
                              'S');
        End;
      End Loop;
    End If;
    If (Cvalorzerado%Isopen) Then
      Close Cvalorzerado;
    End If;
  End;

  --- GUIA INTERNA COMO SENDO GUIA EXTERNA.
  Begin
    If (Custom.Pkg_Conmvs_Tiss_Xml.Fnc_Motivo_Portal(Pcd_Motivo         => 'US018',
                                                     p_Sn_Ativo_Aut_Web => 'S') = 'S') Then
    
      For Vc_Guia_Interna_Como_Externa In c_Guia_Interna_Como_Externa Loop
      
        Begin
        
          Prc_Insere_Log_Erro(Vc_Guia_Interna_Como_Externa.Carteira,
                              Vc_Guia_Interna_Como_Externa.Nr_Guia_Prestador,
                              Vc_Guia_Interna_Como_Externa.Nr_Guia_Operadora,
                              Vc_Guia_Interna_Como_Externa.Nr_Senha_Autorizacao,
                              Vc_Guia_Interna_Como_Externa.Cd_Prestador,
                              Vc_Guia_Interna_Como_Externa.Nm_Beneficiario,
                              '',
                              '',
                              'Guia: ' ||
                              Vc_Guia_Interna_Como_Externa.Nr_Senha_Autorizacao ||
                              '� de origem interna e est� sendo inclusa como externa. ' ||
                              Vexcecao || ' linha do erro: ' ||
                              Vexcecaolinha,
                              Vcoderro,
                              'GUIA INTERNA NAO PODE SER ENVIADA COMO GUIA EXTERNA. COD: US018',
                              'S');
        End;
      End Loop;
    End If;
  
    If (c_Guia_Interna_Como_Externa%Isopen) Then
      Close c_Guia_Interna_Como_Externa;
    End If;
  
  End;

  -- procedimento enviado sem data de realizacao informada. 

  Begin
    If (Custom.Pkg_Conmvs_Tiss_Xml.Fnc_Motivo_Portal(Pcd_Motivo         => 'US019',
                                                     p_Sn_Ativo_Aut_Web => 'S') = 'S') Then
    
      For Vc_Dt_Realizado_Is_Null In c_Dt_Realizado_Is_Null Loop
        Begin
        
          Prc_Insere_Log_Erro(Vc_Dt_Realizado_Is_Null.Carteira,
                              Vc_Dt_Realizado_Is_Null.Nr_Guia_Prestador,
                              Vc_Dt_Realizado_Is_Null.Nr_Guia_Operadora,
                              Vc_Dt_Realizado_Is_Null.Nr_Senha_Autorizacao,
                              Vc_Dt_Realizado_Is_Null.Cd_Prestador,
                              Vc_Dt_Realizado_Is_Null.Nm_Beneficiario,
                              '',
                              '',
                              'Guia: ' ||
                              Vc_Dt_Realizado_Is_Null.Nr_Senha_Autorizacao ||
                              'POSSUI PROCEDIMENTO SEM DATA DE REALIZACAO INFORMADA. ' ||
                              Vexcecao || ' linha do erro: ' ||
                              Vexcecaolinha,
                              Vcoderro,
                              'NAO E PERMITIDO ENVIO DE PROCEDIMENTO SEM DATA DE REALIZACAO INFORMADA. COD: US019',
                              'S');
        
        End;
      End Loop;
    End If;
  
    If (c_Dt_Realizado_Is_Null%Isopen) Then
      Close c_Dt_Realizado_Is_Null;
    End If;
  
  End;

  --PROCEDIMENTO SEM VIA DE ACESSO

  Begin
  
    If (Custom.Pkg_Conmvs_Tiss_Xml.Fnc_Motivo_Portal(Pcd_Motivo         => 'US021',
                                                     p_Sn_Ativo_Aut_Web => 'S') = 'S') Then
    
      For Vprocedimentoviaacesso In Cprocedimentoviaacesso Loop
        Begin
        
          Prc_Insere_Log_Erro(Vprocedimentoviaacesso.Carteira,
                              Vprocedimentoviaacesso.Nr_Guia_Prestador,
                              Vprocedimentoviaacesso.Nr_Guia_Operadora,
                              Vprocedimentoviaacesso.Nr_Senha_Autorizacao,
                              Vprocedimentoviaacesso.Cd_Prestador,
                              Vprocedimentoviaacesso.Nm_Beneficiario,
                              '',
                              '',
                              'Procedimento: ' ||
                              Vprocedimentoviaacesso.Cd_Procedimento ||
                              'N�o possui Via de Acesso na Operadora. ' ||
                              Vexcecao || ' linha do erro: ' ||
                              Vexcecaolinha,
                              Vcoderro,
                              'VIA DE ACESSO N�O PERMITIDA PARA O PROCEDIMENTO: ' ||
                              Vprocedimentoviaacesso.Cd_Procedimento ||
                              ' COD: US021',
                              'S');
        End;
      End Loop;
    End If;
  
    If (Cprocedimentoviaacesso%Isopen) Then
      Close Cprocedimentoviaacesso;
    End If;
  End;

  -- inicio  cCodRacionalizacaoSemAutoriza
  Begin
  
    If (Custom.Pkg_Conmvs_Tiss_Xml.Fnc_Motivo_Portal(Pcd_Motivo         => 'US022',
                                                     p_Sn_Ativo_Aut_Web => 'S') = 'S') Then
    
      For Vcodracionalizacaosemautoriza In Ccodracionalizacaosemautoriza Loop
        Begin
        
          Prc_Insere_Log_Erro(Vcodracionalizacaosemautoriza.Carteira,
                              Vcodracionalizacaosemautoriza.Nr_Guia_Prestador,
                              Vcodracionalizacaosemautoriza.Nr_Guia_Operadora,
                              Vcodracionalizacaosemautoriza.Nr_Senha_Autorizacao,
                              Vcodracionalizacaosemautoriza.Cd_Prestador,
                              Vcodracionalizacaosemautoriza.Nm_Beneficiario,
                              '',
                              '',
                              'Procedimento: ' ||
                              Vcodracionalizacaosemautoriza.Cd_Procedimento ||
                              '� CODIGO DE RACIONALIZA��O E ESTA SEM AUTORIZACAO' ||
                              Vexcecao || ' linha do erro: ' ||
                              Vexcecaolinha,
                              Vcoderro,
                              'CODIGO: ' ||
                              Vcodracionalizacaosemautoriza.Cd_Procedimento ||
                              ' DE RACIONALIZA��O SEM AUTORIZACAO VALIDA: ' ||
                              Vprocedimentoviaacesso.Cd_Procedimento ||
                              ' COD: US022',
                              'S');
        End;
      End Loop;
    End If;
  
    If (Ccodracionalizacaosemautoriza%Isopen) Then
      Close Ccodracionalizacaosemautoriza;
    End If;
  End;
  -- fim cCodRacionalizacaoSemAutoriza  

  --- US027
  Begin
  
    If (Custom.Pkg_Conmvs_Tiss_Xml.Fnc_Motivo_Portal(Pcd_Motivo         => 'US027',
                                                     p_Sn_Ativo_Aut_Web => 'S') = 'S') Then
    
      For Vviaacesso In Cviaacesso Loop
        Begin
        
          Prc_Insere_Log_Erro(Vviaacesso.Carteira,
                              Vviaacesso.Nr_Guia_Prestador,
                              Vviaacesso.Nr_Guia_Operadora,
                              Vviaacesso.Nr_Senha_Autorizacao,
                              Vviaacesso.Cd_Prestador,
                              Vviaacesso.Nm_Beneficiario,
                              '',
                              '',
                              'O Procedimento: ' ||
                              Vviaacesso.Cd_Procedimento ||
                              '� obrigat�rio a via de acesso 1' || Vexcecao ||
                              ' linha do erro: ' || Vexcecaolinha,
                              Vcoderro,
                              'O Procedimento: ' ||
                              Vviaacesso.Cd_Procedimento ||
                              ' � obrigat�rio a via de acesso 1.  COD: US0027',
                              'S');
        End;
      End Loop;
    End If;
  
    If (Cviaacesso%Isopen) Then
      Close Cviaacesso;
    End If;
  End;

  --US029

  Begin
  
    If (Custom.Pkg_Conmvs_Tiss_Xml.Fnc_Motivo_Portal(Pcd_Motivo         => 'US029',
                                                     p_Sn_Ativo_Aut_Web => 'S') = 'S') Then
    
      For Vtipoatendimentotisscod In Ctipoatendimentotisscod Loop
        Begin
        
          Prc_Insere_Log_Erro(Vtipoatendimentotisscod.Carteira,
                              Vtipoatendimentotisscod.Nr_Guia_Prestador,
                              Vtipoatendimentotisscod.Nr_Guia_Operadora,
                              Vtipoatendimentotisscod.Nr_Senha_Autorizacao,
                              Vtipoatendimentotisscod.Cd_Prestador,
                              Vtipoatendimentotisscod.Nm_Beneficiario,
                              '',
                              '',
                              'O Procedimento: ' ||
                              Vtipoatendimentotisscod.Cd_Procedimento ||
                              '� obrigat�rio o TIPO DE ATENDIMENTO TISS 22' ||
                              Vexcecao || ' linha do erro: ' ||
                              Vexcecaolinha,
                              Vcoderro,
                              'O Procedimento: ' ||
                              Vtipoatendimentotisscod.Cd_Procedimento ||
                              ' � obrigat�rio o TIPO DE ATENDIMENTO TISS 22. COD: US0029',
                              'S');
        End;
      End Loop;
    End If;
  
    If (Ctipoatendimentotisscod%Isopen) Then
      Close Ctipoatendimentotisscod;
    End If;
  End;

  --US030 

  Begin
  
    If (Custom.Pkg_Conmvs_Tiss_Xml.Fnc_Motivo_Portal(Pcd_Motivo         => 'US030',
                                                     p_Sn_Ativo_Aut_Web => 'S') = 'S') Then
    
      For Vsadttratseriadoblock In Csadttratseriadoblock Loop
        Begin
        
          Prc_Insere_Log_Erro(Vsadttratseriadoblock.Carteira,
                              Vsadttratseriadoblock.Nr_Guia_Prestador,
                              Vsadttratseriadoblock.Nr_Guia_Operadora,
                              Vsadttratseriadoblock.Nr_Senha_Autorizacao,
                              Vsadttratseriadoblock.Cd_Prestador,
                              Vsadttratseriadoblock.Nm_Beneficiario,
                              '',
                              '',
                              'ATENDIMENTO SERIADO - OBRIGAT�RIO AS SESS�ES POR DATA EXEC' ||
                              Vexcecao || ' linha do erro: ' ||
                              Vexcecaolinha,
                              Vcoderro,
                              'ATENDIMENTO SERIADO - OBRIGAT�RIO AS SESS�ES POR DATA EXEC. COD: US030',
                              'S');
        End;
      End Loop;
    End If;
  
    If (Csadttratseriadoblock%Isopen) Then
      Close Csadttratseriadoblock;
    End If;
  End;  
  
  --US032

  Begin
  
    If (Custom.Pkg_Conmvs_Tiss_Xml.Fnc_Motivo_Portal(Pcd_Motivo         => 'US032',
                                                     p_Sn_Ativo_Aut_Web => 'S') = 'S') Then
    
      For Vreducaoacrescimo In Creducaoacrescimo Loop
        Begin
        
          Prc_Insere_Log_Erro(Vreducaoacrescimo.Carteira,
                              Vreducaoacrescimo.Nr_Guia_Prestador,
                              Vreducaoacrescimo.Nr_Guia_Operadora,
                              Vreducaoacrescimo.Nr_Senha_Autorizacao,
                              Vreducaoacrescimo.Cd_Prestador,
                              Vreducaoacrescimo.Nm_Beneficiario,
                              '',
                              '',
                              'REDUTOR ACR�SCIMO DIVERGENTE ' ||
                              Vexcecao || ' linha do erro: ' ||
                              Vexcecaolinha,
                              Vcoderro,
                              'REDUTOR ACR�SCIMO DIVERGENTE. COD: US032',
                              'S');
        End;
      End Loop;
    End If;
  
    If (Creducaoacrescimo%Isopen) Then
      Close Creducaoacrescimo;
    End If;
  End;

Exception
  When Others Then
    Raise_Application_Error(-20001,
                            'Falha n�o tratada no validador cliente ' ||
                            Sqlerrm);
    

End;
/
