CREATE OR REPLACE NONEDITIONABLE PROCEDURE DBAPS.prc_tiss_envio(P_ID_TISS_MENSAGEM     IN NUMBER,
                                           P_ID_TISS_MENSAGEM_OUT OUT NUMBER) IS
  /**************************************************************
    <objeto>
     <nome>prc_tiss_envio</nome>
     <usuario>Bruno Felix</usuario>
     <alteracao>28/08/2019 11:22</alteracao>
     <ultimaAlteracao>Ajustando glosa do A520 com rela��o a carteira do benefici�rio</ultimaAlteracao>
     <descricao>procedure responsavel pela recepcao do lote de guias xml</descricao>
     <parametro> Entrada:
                 P_ID_TISS_MENSAGEM -
                 --------------------
                 Saida:
                 P_ID_TISS_MENSAGEM_OUT -
     </parametro>
     <tags>guia, analise contratual</tags>
     <versao>1.13</versao>
    </objeto>
  ***************************************************************/
  /**
  * Cursor que verifica se webservice de loteGuias esta ativo (via chave WEBSERVICE_LOTE_GUIA)
  */
  CURSOR cWebserviceAtivo(P_CD_MULTI_EMPRESA IN NUMBER) IS
    SELECT VALOR
      FROM DBAPS.MVS_CONFIGURACAO
     WHERE CHAVE = 'WEBSERVICE_LOTE_GUIA'
       AND CD_MULTI_EMPRESA =
           NVL(P_CD_MULTI_EMPRESA, DBAMV.PKG_MV2000.LE_EMPRESA);
  CURSOR cDadosXML(PCD_PRESTADOR IN NUMBER, PNR_LOTE IN VARCHAR2) IS
    SELECT NM_ARQUIVO, DS_HASH_XML
      FROM DBAPS.PORTAL_LOG_LOTE_GUIA_XML
     WHERE CD_PORTAL_LOG_LOTE_GUIA_XML =
           (SELECT Max(CD_PORTAL_LOG_LOTE_GUIA_XML)
              FROM DBAPS.PORTAL_LOG_LOTE_GUIA_XML
             WHERE CD_PRESTADOR = PCD_PRESTADOR
               AND Trunc(DT_ENVIO) = Trunc(SYSDATE)
               AND NR_LOTE = PNR_LOTE);
  /**
  * Cursor que busca os dados da Mensagem de Lote Guias
  */
  CURSOR cTissMensagem IS
    SELECT TM.NR_REGISTRO_ANS_DESTINO,
           TM.NR_CNPJ_PRESTADOR_OPERADORA,
           TM.NR_CPF_PRESTADOR_OPERADORA,
           TM.CD_PRESTADOR_OPERADORA,
           TM.CD_VERSAO,
           TM.NR_CNPJ_PAGADOR_DESTINO,
           TM.DS_LOGIN_PRESTADOR,
           TM.DS_SENHA_PRESTADOR,
           TLG.ID ID_TISSLOTGUIA,
           TLG.NR_LOTE,
           TLG.TP_LOTE,
           TM.DT_TRANSACAO,
           TM.HR_TRANSACAO,
           TM.NR_REGISTRO_ANS_ORIGEM,
           TM.CD_SEQ_TRANSACAO
    /*,CASE
      WHEN CD_VERSAO <= '2.01.03' THEN
       NVL(TO_DATE(DT_TRANSACAO || ' ' || SubStr(HR_TRANSACAO, 1, 8), 'DD/MM/YYYY HH24:MI'), SYSDATE)
      ELSE
       NVL(TO_DATE(DT_TRANSACAO || ' ' || SubStr(HR_TRANSACAO, 1, 8), 'YYYY-MM-DD HH24:MI:SS'), SYSDATE)
    END DT_TRANSACAO*/
      FROM DBAPS.TISS_MENSAGEM TM, DBAPS.TISS_LOT_GUIA TLG
     WHERE TM.ID = TLG.ID_PAI
       AND TM.ID = P_ID_TISS_MENSAGEM;
  /**
  * Cursor que identifica o tipo de lote a partir do ID do lote
  * (Para vers�es antigas do TISS)
  */
  CURSOR cTipoLote(P_ID_LOT_GUIA IN NUMBER) IS
    SELECT CASE
             WHEN Count(TLGS.ID) > 0 THEN
              'S'
             WHEN Count(TLGRI.ID) > 0 THEN
              'I'
             WHEN Count(TLGH.ID) > 0 THEN
              'H'
             WHEN Count(TLGC.ID) > 0 THEN
              'C'
             WHEN Count(TLGO.ID) > 0 THEN
              'D'
           END TIPO_LOTE
      FROM DBAPS.TISS_LOT_GUIA            TLG,
           DBAPS.TISS_LOT_GUIA_FAT_SADT   TLGS,
           DBAPS.TISS_LOT_GUIA_FAT_RESINT TLGRI,
           DBAPS.TISS_LOT_GUIA_FAT_HONO   TLGH,
           DBAPS.TISS_LOT_GUIA_FAT_CONS   TLGC,
           DBAPS.TISS_LOT_GUIA_FAT_ODON   TLGO
     WHERE TLG.ID = TLGS.ID_PAI(+)
       AND TLG.ID = TLGRI.ID_PAI(+)
       AND TLG.ID = TLGH.ID_PAI(+)
       AND TLG.ID = TLGC.ID_PAI(+)
       AND TLG.ID = TLGO.ID_PAI(+)
       AND TLG.ID = P_ID_LOT_GUIA;
  /**
  * Cursor que calcula o valor total recebido de um lote
  * a partir do tipo de lote
  */
  CURSOR cValorTotalProtocolo(P_CD_PROTOCOLO_CTAMED  IN NUMBER,
                              P_SN_CHAVE_VAL_TOT_XML IN VARCHAR2) IS
    SELECT SUM(DECODE(P_SN_CHAVE_VAL_TOT_XML,
                      'S',
                      VL_TOTAL_PROCEDIMENTO_XML,
                      VL_TOTAL_PROCEDIMENTO))
      FROM DBAPS.V_TISS_LOTE_GUIA
     WHERE CD_PROTOCOLO_CTAMED = P_CD_PROTOCOLO_CTAMED;
  /**
  * Retorna dados das guias de um lote
  */
  CURSOR cGuiasLote(PID_TISSLOTGUIA IN NUMBER) IS
    SELECT NR_GUIA_PRESTADOR,
           NR_GUIA_OPERADORA,
           NR_NUMERO_CARTEIRA,
           NM_BENEFICIARIO,
           NR_CNS,
           NR_IDENTIFICADOR_BENEFICIARIO,
           SN_ATENDIMENTO_RN,
           DT_REALIZACAO
      FROM (SELECT NR_GUIA_PRESTADOR,
                   NR_GUIA_OPERADORA,
                   NR_NUMERO_CARTEIRA,
                   NM_BENEFICIARIO,
                   NR_CNS,
                   NR_IDENTIFICADOR_BENEFICIARIO,
                   SN_ATENDIMENTO_RN,
                   DT_HORA_ATENDIMENTO DT_REALIZACAO
              FROM DBAPS.TISS_LOT_GUIA          TLG,
                   DBAPS.TISS_LOT_GUIA_FAT_SADT TLGS
             WHERE TLGS.ID_PAI = TLG.ID
               AND TLG.ID = PID_TISSLOTGUIA
            UNION ALL
            SELECT NR_GUIA_PRESTADOR,
                   NR_GUIA_OPERADORA,
                   NR_NUMERO_CARTEIRA,
                   NM_BENEFICIARIO,
                   NR_CNS,
                   NR_IDENTIFICADOR_BENEFICIARIO,
                   SN_ATENDIMENTO_RN,
                   DT_ATENDIMENTO DT_REALIZACAO
              FROM DBAPS.TISS_LOT_GUIA TLG, DBAPS.TISS_LOT_GUIA_FAT_CONS TLC
             WHERE TLC.ID_PAI = TLG.ID
               AND TLG.ID = PID_TISSLOTGUIA
            UNION ALL
            SELECT NR_GUIA_PRESTADOR,
                   NR_GUIA_OPERADORA,
                   NR_NUMERO_CARTEIRA,
                   NM_BENEFICIARIO,
                   NR_CNS,
                   NR_IDENTIFICADOR_BENEFICIARIO,
                   SN_ATENDIMENTO_RN,
                   DT_HORA_INTERNACAO DT_REALIZACAO
              FROM DBAPS.TISS_LOT_GUIA            TLG,
                   DBAPS.TISS_LOT_GUIA_FAT_RESINT TLR
             WHERE TLR.ID_PAI = TLG.ID
               AND TLG.ID = PID_TISSLOTGUIA
            UNION ALL
            SELECT NR_GUIA_PRESTADOR,
                   NR_GUIA_OPERADORA,
                   NR_NUMERO_CARTEIRA,
                   NM_BENEFICIARIO,
                   NR_CNS,
                   NR_IDENTIFICADOR_BENEFICIARIO,
                   SN_ATENDIMENTO_RN,
                   TO_CHAR(DT_INICIO_FATURAMENTO, 'YYYY-MM-DD') DT_REALIZACAO
              FROM DBAPS.TISS_LOT_GUIA TLG, DBAPS.TISS_LOT_GUIA_FAT_HONO TLH
             WHERE TLH.ID_PAI = TLG.ID
               AND TLG.ID = PID_TISSLOTGUIA
            UNION ALL
            SELECT NR_GUIA_PRESTADOR,
                   NR_GUIA_OPERADORA,
                   NR_NUMERO_CARTEIRA,
                   NM_BENEFICIARIO,
                   NR_CNS,
                   NR_IDENTIFICADOR_BENEFICIARIO,
                   SN_ATENDIMENTO_RN,
                   DT_HORA_ATENDIMENTO DT_REALIZACAO
              FROM DBAPS.TISS_LOT_GUIA TLG, DBAPS.TISS_LOT_GUIA_FAT_ODON TLO
             WHERE TLO.ID_PAI = TLG.ID
               AND TLG.ID = PID_TISSLOTGUIA);
  /**
  * Retorna dados do prestador a partir do seu c�digo e  multiEmpresa
  */
  CURSOR cPrestador(PCD_PRESTADOR IN NUMBER, P_CD_MULTI_EMPRESA IN NUMBER) IS
    SELECT PRESTADOR.CD_PRESTADOR,
           PRESTADOR.NR_CPF_CGC,
           PRESTADOR.TP_PRESTADOR,
           substr(PRESTADOR.NM_PRESTADOR,0,70) As NM_PRESTADOR,
           ' ' TP_LOGRADOURO_PRESTADOR,
           PRESTADOR.DS_ENDERECO,
           PRESTADOR.NR_ENDERECO,
           PRESTADOR.DS_COMPLEMENTO,
           ' ' CD_CIDADE,
           PRESTADOR.DS_CIDADE,
           PRESTADOR.NM_UF,
           PRESTADOR.NR_CEP,
           NULL NR_CNES,
           PRESTADOR.CD_MULTI_EMPRESA,
           PRESTADOR.SN_INSTANCIA_MV2000
      FROM DBAPS.PRESTADOR
     WHERE (PRESTADOR.CD_INTERNO = TO_CHAR(PCD_PRESTADOR) OR
           PRESTADOR.CD_PRESTADOR = PCD_PRESTADOR)
       AND CD_MULTI_EMPRESA =
           nvl(P_CD_MULTI_EMPRESA, DBAMV.PKG_MV2000.LE_EMPRESA);
  /**
  * Retorna PK da tabela de status de protocolos para o status RECEBIDO
  */
  CURSOR cStatusProtocolo IS
    SELECT CD_STATUS_PROTOCOLO
      FROM DBAPS.STATUS_PROTOCOLO
     WHERE STATUS_PROTOCOLO.CD_TISS = '1';
  /**
  * Retorna PK da tabela de status de protocolos para o status RECEBIDO
  */
  CURSOR cCodStatusProtocolo(PCD_TISS IN VARCHAR2) IS
    SELECT CD_STATUS_PROTOCOLO
      FROM DBAPS.STATUS_PROTOCOLO
     WHERE STATUS_PROTOCOLO.CD_TISS = PCD_TISS
       AND ROWNUM = 1;
  /**
  * Busca o numero de documento referenciado no schema dbamv caso exista
  */
  CURSOR cTissMV2000(PID_TISSLOTGUIA IN NUMBER) IS
    SELECT MVTM.NR_DOCUMENTO
      FROM DBAPS.TISS_LOT_GUIA TLG,
           DBAPS.TISS_MENSAGEM TM,
           DBAMV.TISS_MENSAGEM MVTM
     WHERE TLG.ID = PID_TISSLOTGUIA
       AND TLG.ID_PAI = TM.ID
       AND MVTM.TP_TRANSACAO = 'ENVIO_LOTE_GUIAS'
       AND TM.TP_TRANSACAO = 'ENVIO_LOTE_GUIAS'
       AND TM.CD_SEQ_TRANSACAO = MVTM.CD_SEQ_TRANSACAO;
  /**
  * Verifica se o numero de lote do prestador j� foi informado para o prestador
  */
  CURSOR cVerificaNrLotePrestador(P_NR_LOTE_PRESTADOR IN VARCHAR2,
                                  P_CD_PRESTADOR      IN NUMBER) IS
    SELECT CD_PROTOCOLO_CTAMED
      FROM DBAPS.PROTOCOLO_CTAMED
     WHERE NR_LOTE_PRESTADOR = P_NR_LOTE_PRESTADOR
       AND CD_PRESTADOR = P_CD_PRESTADOR
       AND CD_STATUS_PROTOCOLO NOT IN
           (SELECT CD_STATUS_PROTOCOLO
              FROM DBAPS.STATUS_PROTOCOLO
             WHERE CD_TISS = '4')
       AND ROWNUM = 1;

  CURSOR cLeUnimed(PCD_MULTI_EMPRESA NUMBER) IS
    SELECT DECODE(CD_UNIMED, NULL, 'N', 'S') SN_UNIMED
      FROM DBAMV.MULTI_EMPRESAS_MV_SAUDE
     WHERE CD_MULTI_EMPRESA =
           NVL(PCD_MULTI_EMPRESA, NVL(DBAMV.PKG_MV2000.LE_EMPRESA, 1));
  CURSOR cIsPrestadorUnimed(PCD_MULTI_EMPRESA NUMBER, PCD_PRESTADOR NUMBER) IS
    SELECT 'S'
      FROM DBAPS.PRESTADOR P, DBAPS.PTU_UNIMED PTU
     WHERE P.CD_PRESTADOR = PTU.CD_PRESTADOR
       AND P.CD_PRESTADOR = PCD_PRESTADOR
       AND P.CD_MULTI_EMPRESA = PCD_MULTI_EMPRESA
       AND ROWNUM = 1;
  /**
  * Obtem o valor de uma chave
  */

  CURSOR cMvsConfiguracao(P_CHAVE IN VARCHAR2, PCD_MULTI_EMPRESA IN NUMBER) IS
    SELECT VALOR
      FROM DBAPS.MVS_CONFIGURACAO
     WHERE CHAVE = P_CHAVE
       AND CD_MULTI_EMPRESA = PCD_MULTI_EMPRESA;

  /**
  * Verifica competencia contabil
  * PDT_COMPETENCIA  - YYYYMM
  */
  CURSOR cLoteContabil(PDT_COMPETENCIA   IN VARCHAR2,
                       PCD_MULTI_EMPRESA IN NUMBER) IS
    SELECT 'X', CD_LOTE
      FROM dbamv.lote
     WHERE ds_lote LIKE '%DSP%'
       AND cd_multi_empresa = PCD_MULTI_EMPRESA
       AND To_Char(dt_inicial_lcto, 'YYYYMM') IN (PDT_COMPETENCIA);
  --
  -- VARIAVEIS DOS CURSORES
  rTissMensagem            cTissMensagem%ROWTYPE;
  rLoteContabil            cLoteContabil%ROWTYPE;
  rPrestador               cPrestador%ROWTYPE;
  rVerificaNrLotePrestador cVerificaNrLotePrestador%ROWTYPE;
  -- VARIAVEIS DE USO GERAL
  cCdVersao             VARCHAR2(100);
  cNrDocumento          VARCHAR2(2000);
  dDtTransacao          VARCHAR2(100);
  dRhTransacao          VARCHAR2(100);
  nRegAnsOrigem         NUMBER(6);
  vVersaoTiss           VARCHAR2(10);
  vSnUnimed             VARCHAR2(1);
  vSnPrestUnimed        VARCHAR2(1);
  vSnA520               VARCHAR2(1);
  vSnChaveValTotXML     VARCHAR2(1);
  cCdOrigem             DBAPS.TISS_MENSAGEM.CD_ORIGEM%TYPE;
  cNrRegistroAnsDestino DBAPS.TISS_MENSAGEM.NR_REGISTRO_ANS_DESTINO%TYPE;
  cNrCPFCNPJPrestador   DBAPS.TISS_MENSAGEM.NR_CPF_PRESTADOR_OPERADORA%TYPE;
  cDsMsgErro            DBAPS.TISS_MENSAGEM.DS_MSG_ERRO%TYPE;
  cCdPrestadorOperadora DBAPS.TISS_MENSAGEM.CD_PRESTADOR_OPERADORA%TYPE;
  cCdCGCDestino         DBAPS.TISS_MENSAGEM.CD_CGC_DESTINO%TYPE;
  cCdCPFDestino         DBAPS.TISS_MENSAGEM.CD_CPF_DESTINO%TYPE;
  -- Variaveis
  nIdTissMensagem         DBAPS.TISS_MENSAGEM.ID%TYPE;
  nIdTissProtReceb        DBAPS.TISS_PROT_RECEB.ID%TYPE;
  nIdTissProtRecebDetalhe DBAPS.TISS_PROT_RECEB_DETALHE.ID%TYPE;
  nIdTissProtRecebGuia    DBAPS.TISS_PROT_RECEB_GUIA.ID%TYPE;
  nNrProtocolo            DBAPS.LOTE.CD_LOTE%TYPE;
  nCdStatusProtocolo      DBAPS.STATUS_PROTOCOLO.CD_STATUS_PROTOCOLO%TYPE;
  rDadosXML               cDadosXML%ROWTYPE;
  bPossuiBenefInexistente BOOLEAN;
  vStatusEncerrado        VARCHAR2(1);
  vCdGlosaLote            VARCHAR2(10);
  vDsGlosaLote            VARCHAR2(500);
  nValorTotalProtocolo    NUMBER;
  vTipoLote               VARCHAR2(1);
  vExcecao                VARCHAR2(1000);
  vExcecaoLinha           VARCHAR2(1000);
  nIdTissMensagemLog      NUMBER;
  vWebServiceAtivo        VARCHAR2(1);
  dDataTransacaoPrestador DATE;
  --Armazena variaveis de retorno do cabecalho
  nCdPrestadorNaOperadora NUMBER;
  nNrCnpjPrestador        VARCHAR2(20);
  nNrCpfPrestador         VARCHAR2(20);
  nCdMultiEmpresaOrigem   NUMBER;
  nNrRegistroAnsOrigem    NUMBER;
  vDtTransacao            VARCHAR2(30);
  vRhTransacao            VARCHAR2(30);
  nRegAnsOrigem           NUMBER(6);
  vDsOperadora            VARCHAR2(4000);
  nCnpjOperadora          VARCHAR2(14);
  vCdGlosa                VARCHAR2(10);
  vDsGlosa                VARCHAR2(500);
  vPrestadorbloqueio      varchar2(1) := 'N';

  /**
  * Grava uma Mensagem de Resposta de PROTOCOLO_RECEBIMENTO
  */
  FUNCTION gravarResposta(P_ID_TISSLOTGUIA         IN NUMBER,
                          P_DT_TRANSACAO           IN VARCHAR2,
                          P_HR_TRANSACAO           IN VARCHAR2,
                          P_CD_VERSAO              IN VARCHAR2,
                          P_NR_REGISTRO_ANS        IN VARCHAR2, --REG ANS DA OPERADORA
                          P_NR_CNPJ_OPERADORA      IN VARCHAR2, --CNPJ DA OPERADORA
                          P_DS_OPERADORA           IN VARCHAR2,
                          P_CD_PRESTADOR_OPERADORA IN VARCHAR2,
                          P_NR_CNPJ_PRESTADOR      IN VARCHAR2,
                          P_NR_CPF_PRESTADOR       IN VARCHAR2,
                          P_CD_GLOSA               IN VARCHAR2,
                          P_DS_GLOSA               IN VARCHAR2,
                          P_NR_LOTE                IN VARCHAR2,
                          P_CD_STATUS_PROTOCOLO    IN NUMBER,
                          P_TP_LOTE                IN VARCHAR2,
                          P_DT_ENVIO_LOTE          IN DATE,
                          P_CD_MULTI_EMPRESA       IN NUMBER,
                          P_NR_ANS_ORIGEM          IN VARCHAR2) RETURN NUMBER IS
    --cursor de configuracoes
    CURSOR cConfig IS
      SELECT TP_PROTOCOLO_XML,
             CD_TIP_CALLCENTER_PROT_XML,
             CD_SERVICO_CALL_CENTER
        FROM DBAPS.AUTWEB_CONFIG
       WHERE CD_MULTI_EMPRESA =
             Nvl(P_CD_MULTI_EMPRESA, DBAMV.PKG_MV2000.LE_EMPRESA);
    --
    rConfig               cConfig%rowtype;
    vDsProtocolo          VARCHAR2(4000);
    nRetornoCdPrestador   number;
    nRetornoCNPJPrestador number;
    nRetornoCPFPrestador  number;
  BEGIN
    -- INSERE NA TISS MENSAGEM
    nIdTissMensagem := DBAPS.FNC_TISS_INSERE_CABECALHO(P_ID_TISS_MENSAGEM --P_ID_MENSAGEM_ENVIO
                                                      ,
                                                       'PROTOCOLO_RECEBIMENTO' --P_TP_TRANSACAO
                                                      ,
                                                       'protocoloRecebimento' --P_NM_XML
                                                      ,
                                                       P_NR_REGISTRO_ANS --P_NR_REGISTRO_ANS
                                                      ,
                                                       P_NR_CNPJ_OPERADORA --P_NR_CNPJ_OPERADORA
                                                      ,
                                                       P_CD_VERSAO --P_CD_VERSAO
                                                      ,
                                                       P_CD_PRESTADOR_OPERADORA --P_CD_PRESTADOR_OPERADORA
                                                      ,
                                                       P_NR_CNPJ_PRESTADOR --P_NR_CNPJ_PRESTADOR
                                                      ,
                                                       P_NR_CPF_PRESTADOR --P_NR_CPF_PRESTADOR
                                                      ,
                                                       P_CD_GLOSA --P_CD_GLOSA
                                                      ,
                                                       P_DS_GLOSA --P_DS_GLOSA
                                                      ,
                                                       P_DS_GLOSA --P_DS_MSG_ERRO
                                                      ,
                                                       P_DT_TRANSACAO --P_DT_TRANSACAO
                                                      ,
                                                       P_HR_TRANSACAO --P_HR_TRANSACAO
                                                      ,
                                                       P_NR_ANS_ORIGEM --P_NR_REGISTRO_ANS_DESTINO
                                                       );
    --Inserindo mensagem Protocolo Recebimento
    SELECT DBAPS.SEQ_TISS_MENSAGEM.NEXTVAL
      INTO nIdTissProtReceb
      FROM SYS.DUAL;
    /**
    * CABECALHO DA MENSAGEM COM GLOSA
    */
    IF P_CD_GLOSA IS NOT NULL THEN
      -- SE HOUVE GLOSA NO CABECALHO DA MENSAGEM
      INSERT INTO DBAPS.TISS_PROT_RECEB
        (ID, ID_PAI, CD_MOTIVO_GLOSA, DS_MOTIVO_GLOSA, CD_ENVIO_LOTE_GUIA)
      VALUES
        (nIdTissProtReceb -- ID
        ,
         nIdTissMensagem -- ID_PAI
        ,
         P_CD_GLOSA,
         P_DS_GLOSA,
         P_ID_TISS_MENSAGEM --CD_ENVIO_LOTE_GUIA
         );
    ELSE
      vSnChaveValTotXML := 'N';
      OPEN cMvsConfiguracao('CONTMED_IMPORTAR_VALOR_TOT_XML',
                            P_CD_MULTI_EMPRESA);
      FETCH cMvsConfiguracao
        INTO vSnChaveValTotXML;
      CLOSE cMvsConfiguracao;
      OPEN cPrestador(P_CD_PRESTADOR_OPERADORA, P_CD_MULTI_EMPRESA);
      FETCH cPrestador
        INTO rPrestador;
      CLOSE cPrestador;
      IF NVL(rPrestador.SN_INSTANCIA_MV2000, 'N') = 'S' THEN
        OPEN cTissMV2000(P_ID_TISSLOTGUIA);
        FETCH cTissMV2000
          INTO cNrDocumento;
        CLOSE cTissMV2000;
      END IF;
    
      -- Inserindo protocolo de contas m�dicas
      SELECT DBAPS.SEQ_PROTOCOLO_CTAMED.NEXTVAL
        INTO nNrProtocolo
        FROM SYS.DUAL;
      OPEN cLeUnimed(P_CD_MULTI_EMPRESA);
      FETCH cLeUnimed
        INTO vSnUnimed;
      IF cLeUnimed%NOTFOUND THEN
        vSnUnimed := 'N';
      END IF;
      CLOSE cLeUnimed;
      OPEN cIsPrestadorUnimed(P_CD_MULTI_EMPRESA, P_CD_PRESTADOR_OPERADORA);
      FETCH cIsPrestadorUnimed
        INTO vSnPrestUnimed;
      IF cIsPrestadorUnimed%NOTFOUND THEN
        vSnPrestUnimed := 'N';
      END IF;
      CLOSE cIsPrestadorUnimed;
      vSnA520 := 'N';
      IF NVL(vSnUnimed, 'N') = 'S' AND NVL(vSnPrestUnimed, 'N') = 'S' THEN
        vSnA520 := 'S';
      END IF;
      OPEN cConfig;
      FETCH cConfig
        INTO rConfig;
      CLOSE cConfig;
      --
      /* CC- CALL CENTER
        CM - CONTA MEDICA (DEFAULT)
      */
      IF rConfig.TP_PROTOCOLO_XML IN ('CC') AND vSnA520 = 'N' THEN
        /* Ps: o 9020 � para evitar uma exception por nullPointer no envio do XML...salve com 9020 para a operadora ajustar depois */
        vDsProtocolo := DBAPS.FNC_PROTOCOLO_ANS(Nvl(rConfig.CD_TIP_CALLCENTER_PROT_XML,
                                                    9020),
                                                nNrProtocolo,
                                                null,
                                                NULL,
                                                P_CD_PRESTADOR_OPERADORA,
                                                P_CD_MULTI_EMPRESA,
                                                'XML',
                                                rConfig.CD_SERVICO_CALL_CENTER);
        nNrProtocolo := vDsProtocolo;
      ELSE
        --default � CM - conta medica/protocolo ctamed
        vDsProtocolo := nNrProtocolo;
      END IF;
      /* INSERIR PROTOCOLO CTAMED */
      INSERT INTO DBAPS.PROTOCOLO_CTAMED
        (CD_PROTOCOLO_CTAMED,
         CD_PRESTADOR,
         NR_LOTE_PRESTADOR,
         CD_STATUS_PROTOCOLO,
         ID_TISSLOTGUIA,
         CD_MULTI_EMPRESA,
         DT_ENVIO_LOTE,
         NR_REMESSA_MV2000,
         SN_AVISO_PTU_A520,
         DS_PROTOCOLO,
         CD_ATEND_CALL_CENTER)
      VALUES
        (nNrProtocolo,
         P_CD_PRESTADOR_OPERADORA,
         P_NR_LOTE,
         P_CD_STATUS_PROTOCOLO,
         P_ID_TISSLOTGUIA,
         nvl(P_CD_MULTI_EMPRESA, DBAMV.PKG_MV2000.LE_EMPRESA), --CD_MULTI_EMPRESA
         Decode(rConfig.TP_PROTOCOLO_XML, 'CC', SYSDATE, P_DT_ENVIO_LOTE), --DT_ENVIO_LOTE
         cNrDocumento, --NR_REMESSA_MV2000
         NVL(vSnA520, 'N'), --SN_AVISO_PTU_A520
         vDsProtocolo, --DS_PROTOCOLO
         Decode(rConfig.TP_PROTOCOLO_XML, 'CC', vDsProtocolo, NULL) --CD_ATEND_CALL_CENTER
         );
      nRetornoCdPrestador   := NULL;
      nRetornoCNPJPrestador := NULL;
      nRetornoCPFPrestador  := NULL;
      IF P_CD_PRESTADOR_OPERADORA IS NOT NULL THEN
        nRetornoCdPrestador := P_CD_PRESTADOR_OPERADORA;
      ELSIF P_CD_PRESTADOR_OPERADORA IS NULL AND
            rPrestador.TP_PRESTADOR IN ('J', 'L') THEN
        nRetornoCNPJPrestador := rPrestador.NR_CPF_CGC;
      ELSIF P_CD_PRESTADOR_OPERADORA IS NULL AND
            rPrestador.TP_PRESTADOR IN ('F') THEN
        nRetornoCPFPrestador := rPrestador.NR_CPF_CGC;
      END IF;
      -- Inserindo protocoloRecebimento
      INSERT INTO DBAPS.TISS_PROT_RECEB
        (ID,
         ID_PAI,
         NR_REGISTRO_ANS,
         DS_OPERADORA,
         NR_CNPJ_OPERADORA,
         NR_CNPJ_PRESTADOR,
         NR_CPF_PRESTADOR,
         CD_PRESTADOR,
         DS_PRESTADOR,
         NR_CNES_PRESTADOR,
         DT_ENVIO_LOTE,
         NR_LOTE,
         DS_MENSAGEM_ERRO,
         CD_ENVIO_LOTE_GUIA)
      VALUES
        (nIdTissProtReceb -- ID
        ,
         nIdTissMensagem -- ID_PAI
        ,
         TO_CHAR(P_NR_REGISTRO_ANS) -- NR_REGISTRO_ANS
        ,
         fnc_remove_acento(P_DS_OPERADORA) -- DS_OPERADORA
        ,
         P_NR_CNPJ_OPERADORA -- NR_CNPJ_OPERADORA
        ,
         nRetornoCNPJPrestador -- NR_CNPJ_PRESTADOR
        ,
         nRetornoCPFPrestador -- NR_CPF_PRESTADOR
        ,
         nRetornoCdPrestador -- CD_PRESTADOR
        ,
         substr(fnc_remove_acento(rPrestador.NM_PRESTADOR),0,70) -- DS_PRESTADOR
        ,
         rPrestador.NR_CNES -- NR_CNES_PRESTADOR
        ,
         DECODE(P_CD_VERSAO,
                '2.01.03',
                TO_CHAR(SYSDATE, 'DD/MM/YYYY'),
                '2.01.02',
                TO_CHAR(SYSDATE, 'DD/MM/YYYY'),
                TO_CHAR(SYSDATE, 'YYYY-MM-DD')) -- DT_ENVIO_LOTE
        ,
         P_NR_LOTE -- NR_LOTE
        ,
         P_DS_GLOSA -- P_DS_MSG_ERRO
        ,
         P_ID_TISS_MENSAGEM -- CD_ENVIO_LOTE_GUIA
         );
      -- CASO NAO VENHA O TIPO DE LOTE PELO WEBSERVICE (LEGADO: 2.02.03 E ANTERIORES)
      IF P_TP_LOTE IS NULL THEN
        OPEN cTipoLote(P_ID_TISSLOTGUIA);
        FETCH cTipoLote
          INTO vTipoLote;
        CLOSE cTipoLote;
        IF P_ID_TISSLOTGUIA IS NOT NULL AND vTipoLote IS NOT NULL THEN
          UPDATE DBAPS.TISS_LOT_GUIA
             SET TP_LOTE = vTipoLote
           WHERE ID = P_ID_TISSLOTGUIA;
        END IF;
      ELSE
        vTipoLote := P_TP_LOTE;
      END if;
      --Identificando valor total do protocolo
      OPEN cValorTotalProtocolo(nNrProtocolo, vSnChaveValTotXML);
      FETCH cValorTotalProtocolo
        INTO nValorTotalProtocolo;
      CLOSE cValorTotalProtocolo;
      --Inserindo mensagem Protocolo Recebimento detalhe
      SELECT DBAPS.SEQ_TISS_MENSAGEM.NEXTVAL
        INTO nIdTissProtRecebDetalhe
        FROM SYS.DUAL;
    
      INSERT INTO DBAPS.TISS_PROT_RECEB_DETALHE
        (ID, ID_PAI, NR_PROTOCOLO, NR_PROTOCOLO_RECEBIMENTO, VL_PROTOCOLO)
      VALUES
        (nIdTissProtRecebDetalhe -- ID
        ,
         nIdTissProtReceb -- ID_PAI
        ,
         nNrProtocolo -- NR_PROTOCOLO
        ,
         nNrProtocolo -- NR_PROTOCOLO_RECEBIMENTO
        ,
         nvl(Trunc(nValorTotalProtocolo, 2), 0));
      -- Inserindo dadosGuiasProtocolo - guias do lote do prestador
      FOR rGuias IN cGuiasLote(P_ID_TISSLOTGUIA) LOOP
        SELECT DBAPS.SEQ_TISS_MENSAGEM.NEXTVAL
          INTO nIdTissProtRecebGuia
          FROM SYS.DUAL;
        INSERT INTO DBAPS.TISS_PROT_RECEB_GUIA
          (ID,
           ID_PAI,
           NR_GUIA_PRESTADOR,
           NR_GUIA_OPERADORA,
           NR_NUMERO_CARTEIRA,
           SN_ATENDIMENTO_RN,
           NM_BENEFICIARIO,
           NR_CNS,
           NR_IDENTIFICADOR_BENEFICIARIO,
           DT_REALIZACAO,
           VL_PROCESSADO_GUIA,
           VL_GLOSA_GUIA,
           VL_LIBERADO_GUIA)
        VALUES
          (nIdTissProtRecebGuia,
           nIdTissProtRecebDetalhe,
           rGuias.NR_GUIA_PRESTADOR,
           rGuias.NR_GUIA_OPERADORA,
           rGuias.NR_NUMERO_CARTEIRA,
           Nvl(rGuias.SN_ATENDIMENTO_RN, 'N'),
           fnc_remove_acento(rGuias.NM_BENEFICIARIO),
           rGuias.NR_CNS,
           rGuias.NR_IDENTIFICADOR_BENEFICIARIO,
           rGuias.DT_REALIZACAO,
           0,
           0,
           0);
        -- REGRA A520/525 - VALIDAR BENEFICIARIO INEXISTENTE (UNICA GLOSA VERIFICAVEL NO RECEB XML
        IF vSnA520 = 'S' AND
           DBAPS.FNC_TISS_USUARIO(DBAPS.FNC_AJUSTA_CARTEIRA_BENEF(rGuias.NR_NUMERO_CARTEIRA,
                                                                  vSnA520),
                                  NULL,
                                  'N') = -1 THEN
          bPossuiBenefInexistente := true;
          INSERT INTO DBAPS.TISS_PROT_RECEB_GUIA_GL
            (ID, ID_PAI, CD_MOTIVO_GLOSA, DS_MOTIVO_GLOSA)
          VALUES
            (DBAPS.SEQ_TISS_MENSAGEM.NEXTVAL,
             nIdTissProtRecebGuia,
             1001,
             'NUMERO DE CARTEIRA INVALIDO - BENEFICIARIO INEXISTENTE');
        END IF; --end if a525
      --
      END LOOP; --ENDLOOP cGuiasLote5
      --A525 - GLOSAR PROTOCOLO
      IF bPossuiBenefInexistente AND vSnA520 = 'S' THEN
        OPEN cCodStatusProtocolo('4');
        FETCH cCodStatusProtocolo
          INTO vStatusEncerrado;
        CLOSE cCodStatusProtocolo;
        --
        UPDATE DBAPS.PROTOCOLO_CTAMED
           SET CD_STATUS_PROTOCOLO = vStatusEncerrado
         WHERE CD_PROTOCOLO_CTAMED = nNrProtocolo;
        --
      END IF;
      OPEN cDadosXML(P_CD_PRESTADOR_OPERADORA, rTissMensagem.NR_LOTE);
      FETCH cDadosXML
        INTO rDadosXML;
      CLOSE cDadosXML;
      --INSERIR NA MVTISS
      INSERT INTO DBAPS.MV_TISS
        (CD_MV_TISS,
         CD_PRESTADOR,
         CD_TISS_MENSAGEM,
         DT_ENVIO,
         CD_RETORNO_TISS_MENSAGEM,
         NR_PROTOCOLO,
         CD_XML_HASH,
         DS_ARQUIVO_XML)
      VALUES
        (DBAPS.SEQ_ENVIO_TISS_MVS.NEXTVAL,
         P_CD_PRESTADOR_OPERADORA,
         P_ID_TISS_MENSAGEM,
         SYSDATE,
         nIdTissMensagem,
         nNrProtocolo,
         rDadosXML.DS_HASH_XML,
         Nvl(rDadosXML.NM_ARQUIVO, 'ORIGEM: WEBSERVICE'));
      COMMIT;
      /* Importar A520 - para evitar esperar pelo JOB */
      IF vSnA520 = 'S' THEN
        OPEN cTissMensagem;
        FETCH cTissMensagem
          INTO rTissMensagem;
        IF cTissMensagem%FOUND THEN
          UPDATE DBAPS.TISS_MENSAGEM
             SET CD_SEQ_TRANSACAO_ORIGEM = rTissMensagem.CD_SEQ_TRANSACAO,
                 DT_TRANSACAO            = rTissMensagem.DT_TRANSACAO,
                 HR_TRANSACAO            = rTissMensagem.HR_TRANSACAO
           WHERE ID = nIdTissMensagem;
        END IF;
        CLOSE cTissMensagem;
        DBAPS.PRC_IMPORTA_A520_AUTOMATICO(nNrProtocolo);
      END IF;
    END IF;
    -- retornando id da tissMensagem
    return nIdTissMensagem;
  end;
BEGIN
  -- BUSCANDO DADOS DA TISS_MENSAGEM
  OPEN cTissMensagem;
  FETCH cTissMensagem
    INTO rTissMensagem;
  CLOSE cTissMensagem;
  /*****************************************************************************
  * Validando cabecalho da mensagem TISS
  ***************************************************************************/
  dbaps.prc_tiss_valida_cabecalho(P_ID_TISS_MENSAGEM,
                                  nCdPrestadorNaOperadora, -- codigo do prestador
                                  nNrRegistroAnsOrigem,
                                  nCdMultiEmpresaOrigem,
                                  nCnpjOperadora,
                                  vDsOperadora,
                                  vCdGlosa,
                                  vDsGlosa);
  /*****************************************************************************
  * Validacoes Adicionais especificas para Lote - devem retornar como MensagemErro
  ***************************************************************************/
  IF vCdGlosa IS NULL THEN
    -- Atribuindo multiEmpresa
    DBAMV.PKG_MV2000.ATRIBUI_EMPRESA(nCdMultiEmpresaOrigem);
    OPEN cStatusProtocolo;
    FETCH cStatusProtocolo
      INTO nCdStatusProtocolo;
    IF cStatusProtocolo%NOTFOUND THEN
      vCdGlosa := 1099;
      vDsGlosa := 'O Status 1 - RECEBIDO nao esta cadastrado. Entre em contato com a operadora. Opcao: ANS/TISS/Tabelas de Dominio/Status do Protocolo. ';
    END IF;
    CLOSE cStatusProtocolo;
  END IF;
  /* Valida se WebService esta ativo */
  OPEN cWebserviceAtivo(nCdMultiEmpresaOrigem);
  FETCH cWebserviceAtivo
    INTO vWebServiceAtivo;
  CLOSE cWebserviceAtivo;
  --
  IF vCdGlosa IS NULL and UPPER(nvl(vWebServiceAtivo, 'N')) = 'N' THEN
    vCdGlosa := '5013';
    vDsGlosa := 'WEB SERVICE LOTE DE GUIAS NAO esta ATIVO - ENTRE EM CONTATO COM A OPERADORA';
  END IF;
  /* Verifica se foi informado numero de lote do prestador */
  IF vCdGlosa IS NULL and rTissMensagem.NR_LOTE IS NULL THEN
    vCdGlosa := '5013';
    vDsGlosa := 'NUMERO DE LOTE DE GUIAS NAO INFORMADO';
  END IF;

  /*****************************************************************************
  * Montando resposta
  ***************************************************************************/
  IF rTissMensagem.CD_VERSAO = '2.01.03' THEN
    vDtTransacao := TO_CHAR(SYSDATE, 'DD/MM/YYYY');
    vRhTransacao := TO_CHAR(SYSDATE, 'HH24:MI');
  ELSE
    vDtTransacao := TO_CHAR(SYSDATE, 'YYYY-MM-DD');
    vRhTransacao := TO_CHAR(SYSDATE, 'HH24:MI:SS');
  END IF;
  /*  Se NAO retornou CODigo do prestador na operadora
  *  busque os dados da mensagem original */
  IF nCdPrestadorNaOperadora IS NULL THEN
    nCdPrestadorNaOperadora := rTissMensagem.CD_PRESTADOR_OPERADORA;
    nNrCnpjPrestador        := rTissMensagem.NR_CNPJ_PRESTADOR_OPERADORA;
    nNrCpfPrestador         := rTissMensagem.NR_CPF_PRESTADOR_OPERADORA;
  END IF;

  OPEN cLeUnimed(nCdMultiEmpresaOrigem);
  FETCH cLeUnimed
    INTO vSnUnimed;
  IF cLeUnimed%NOTFOUND THEN
    vSnUnimed := 'N';
  END IF;
  CLOSE cLeUnimed;

  OPEN cIsPrestadorUnimed(nCdMultiEmpresaOrigem, nCdPrestadorNaOperadora);
  FETCH cIsPrestadorUnimed
    INTO vSnPrestUnimed;
  IF cIsPrestadorUnimed%NOTFOUND THEN
    vSnPrestUnimed := 'N';
  END IF;
  CLOSE cIsPrestadorUnimed;
  vSnA520 := 'N';
  IF NVL(vSnUnimed, 'N') = 'S' AND NVL(vSnPrestUnimed, 'N') = 'S' THEN
    vSnA520 := 'S';
  END IF;

  /* Verifica se numero de lote JA foi informado para este prestador */
  IF vCdGlosa IS NULL AND vSnA520 = 'N' THEN
    OPEN cVerificaNrLotePrestador(rTissMensagem.NR_LOTE,
                                  nCdPrestadorNaOperadora);
    FETCH cVerificaNrLotePrestador
      INTO rVerificaNrLotePrestador;
    IF cVerificaNrLotePrestador%FOUND THEN
      vCdGlosa := '5013';
      vDsGlosa := 'NUMERO DE LOTE DE GUIAS (' || rTissMensagem.NR_LOTE ||
                  ') JA INFORMADO EM PROTOCOLOS ANTERIORES [CODIGO CTAMED: ' ||
                  rVerificaNrLotePrestador.CD_PROTOCOLO_CTAMED ||
                  '] . POR FAVOR INFORME UM NOVO NUMERO';
    END IF;
    CLOSE cVerificaNrLotePrestador;
  END IF;
  -- convertendo data de transacao do prestador
  IF rTissMensagem.DT_TRANSACAO IS NOT NULL AND
     rTissMensagem.HR_TRANSACAO IS NOT NULL THEN
    BEGIN
      IF rTissMensagem.CD_VERSAO <= '2.01.03' THEN
        dDataTransacaoPrestador := TO_DATE(rTissMensagem.DT_TRANSACAO || ' ' ||
                                           SubStr(rTissMensagem.HR_TRANSACAO,
                                                  1,
                                                  8),
                                           'DD/MM/YYYY HH24:MI');
      ELSE
        dDataTransacaoPrestador := TO_DATE(rTissMensagem.DT_TRANSACAO || ' ' ||
                                           SubStr(rTissMensagem.HR_TRANSACAO,
                                                  1,
                                                  8),
                                           'YYYY-MM-DD HH24:MI:SS');
      END IF;
    EXCEPTION
      WHEN OTHERS THEN
        dDataTransacaoPrestador := sysdate;
    END;
  END IF;

  --
  IF vCdGlosa IS NULL AND vSnA520 = 'S' THEN
    /* validar competencia contabil - dbamv.lote */
    NULL;
    OPEN cLoteContabil(To_Char(dDataTransacaoPrestador, 'YYYYMM'),
                       nCdMultiEmpresaOrigem);
    FETCH cLoteContabil
      INTO rLoteContabil;
  
    IF cLoteContabil%FOUND THEN
      vCdGlosa := '5013';
      vDsGlosa := 'COMPET�NCIA CONT�BIL FECHADA PARA A DATA DE TRANSA�AO INFORMADA: ' ||
                  To_Char(dDataTransacaoPrestador, 'YYYYMM');
    END IF;
    CLOSE cLoteContabil;
  
  END IF;
  
 /* If(nCdPrestadorNaOperadora = 300100) Then
      vCdGlosa := '5013';
      vDsGlosa := 'TESTE MOISES 300100: ' ||
                  To_Char(dDataTransacaoPrestador, 'YYYYMM');
                  
  End If;                                                     
 */
  --
  -- Resposta do WebService  
  
 /* If(nCdPrestadorNaOperadora = 300100) Then
     prc_valida_prot_tiss_tes(nNrProtocolo);
     
     vCdGlosa := '5013';
     vDsGlosa := vDsGlosa || 'TESTE MOISES 300100: ' ||
     To_Char(dDataTransacaoPrestador, 'YYYYMM');
  End If;
*/  
  
  P_ID_TISS_MENSAGEM_OUT := gravarResposta(rTissMensagem.ID_TISSLOTGUIA,
                                           vDtTransacao,
                                           vRhTransacao,
                                           rTissMensagem.CD_VERSAO,
                                           Nvl(nNrRegistroAnsOrigem,
                                               nvl(rTissMensagem.NR_REGISTRO_ANS_DESTINO,
                                                   999999)), -- DADOS DA OPERADORA
                                           nCnpjOperadora, -- DADOS DA OPERADORA
                                           vDsOperadora, -- DADOS DA OPERADORA
                                           nCdPrestadorNaOperadora,
                                           nNrCnpjPrestador, --CNPJ NA ORIGEM
                                           nNrCpfPrestador, --CPF NA ORIGEM
                                           vCdGlosa,
                                           vDsGlosa,
                                           rTissMensagem.NR_LOTE,
                                           nCdStatusProtocolo,
                                           rTissMensagem.TP_LOTE,
                                           dDataTransacaoPrestador,
                                           nCdMultiEmpresaOrigem,
                                           rTissMensagem.NR_REGISTRO_ANS_ORIGEM -- REG ANS ORIGEM
                                           );

/*Begin
  Select 'S'
    Into Vprestadorbloqueio
    From Dbaps.Prestador p
   Where p.Cd_Prestador = Ncdprestadornaoperadora
        --solicitado pela fabiana colocar exce��o do Santa Lucinda - 300011
        --AND P.CD_PRESTADOR NOT IN ('300100', '300011');
        
        -- CH2105-3023 Trava XML - Funda��o S�o Paulo
        -- Obj.: Habilitar a valida��o para o prestador 300011
        -- CH2110-6265: Efraim solicitou para aplicar a valida��o para o 300100    
     And p.Cd_Prestador <> '300100'
     And p.Cd_Tip_Prestador <> 0;
  -- Or P.CD_PRESTADOR  = 300100

Exception
  When No_Data_Found Then
    Vprestadorbloqueio := 'N';
End;*/
/* --unidade de medida
  if nCdPrestadorNaOperadora = 300077 then
   prc_valida_prot_tiss_uni018(nNrProtocolo);
  end if;*/


/*If (Rtissmensagem.Cd_Versao In ('3.02.00',
                                '3.02.01',
                                '3.02.02',
                                '3.03.00',
                                '3.03.01',
                                '3.03.02',
                                '3.03.03') ) Then*/
 
 --ponto de entrada cliente (moises)
 If(rDadosXML.Nm_Arquivo Not Like '%WEBSERVICE%') Then
 -- If(nCdPrestadorNaOperadora Not In (300100,1001553)) Then
     
   Prc_Valida_Prot_Tiss_Tes(Nnrprotocolo);   --ponto de entrada para o PORTAL TISS 
  
 -- End If;

End If;

Commit;

EXCEPTION
  WHEN OTHERS THEN
    vExcecao      := SQLERRM;
    vExcecaoLinha := DBMS_UTILITY.FORMAT_ERROR_BACKTRACE;
    SELECT DBAPS.SEQ_TISS_MENSAGEM.NEXTVAL
      INTO nIdTissProtReceb
      FROM SYS.DUAL;
    SELECT DBAPS.SEQ_TISS_MENSAGEM_LOG.NEXTVAL
      INTO nIdTissMensagemLog
      FROM DUAL;
    -- INSERINDO NO LOG DE ERROS
    INSERT INTO DBAPS.TISS_MENSAGEM_LOG
      (CD_TISS_MENSAGEM_LOG, CD_TISS_MENSAGEM, DT_LOG, DS_LOG)
    VALUES
      (nIdTissMensagemLog,
       P_ID_TISS_MENSAGEM,
       SYSDATE,
       'ERRO: ' || vExcecao || ' LINHA DO ERRO: ' || vExcecaoLinha);
    -- BUSCANDO VERSAO ATUAL DO TISS - VALORES IGUAIS PARA QUALQUER MULTIEMPRESA
    SELECT valor
      into vVersaoTiss
      FROM DBAPS.MVS_CONFIGURACAO
     WHERE CHAVE = 'VERSAO_TISS'
       AND CD_MULTI_EMPRESA = DBAMV.PKG_MV2000.LE_EMPRESA
       AND ROWNUM = 1;
    -- Inserindo cabecalho da resposta
    P_ID_TISS_MENSAGEM_OUT := dbaps.FNC_TISS_INSERE_CABECALHO(P_ID_TISS_MENSAGEM,
                                                              'PROTOCOLO_RECEBIMENTO',
                                                              'protocoloRecebimento',
                                                              '999999',
                                                              NULL,
                                                              vVersaoTiss,
                                                              '999999',
                                                              NULL,
                                                              NULL,
                                                              '5013',
                                                              'OCORREU UM ERRO NO PROCESSAMENTO DA SUA REQUISICAO. ERRO COD: ' ||
                                                              nIdTissMensagemLog,
                                                              'OCORREU UM ERRO NO PROCESSAMENTO DA SUA REQUISICAO. ERRO COD: ' ||
                                                              nIdTissMensagemLog);
    INSERT INTO DBAPS.TISS_PROT_RECEB
      (ID, ID_PAI, CD_MOTIVO_GLOSA, DS_MOTIVO_GLOSA, CD_ENVIO_LOTE_GUIA)
    VALUES
      (nIdTissProtReceb -- CD_TISS_RECEBIMENTO_RECURSO
      ,
       P_ID_TISS_MENSAGEM_OUT -- CD_PAI
      ,
       '5013' -- CD_MOTIVO_GLOSA
      ,
       'OCORREU UM ERRO NO PROCESSAMENTO DA SUA REQUISICAO. ERRO COD: ' ||
       nIdTissMensagemLog,
       P_ID_TISS_MENSAGEM);
END;
/
