Select 'Alter' || ' ' || Decode(a.Object_Type,
                                'PACKAGE BODY',
                                'PACKAGE',
                                'SYNONYM',
                                'PUBLIC SYNONYM',
                                a.Object_Type) || ' ' ||
       Decode(a.Owner, 'PUBLIC', Null, a.Owner || '.') || a.Object_Name || ' ' ||
       'COMPILE;' Objeto_Compile
  From All_Objects a
 Where a.Status <> 'VALID'
      --And a.Object_Type = 'SYNONYM'
      
   And Not Exists (Select 1
          From All_Source Al
         Where Al.Name = a.Object_Name
           And (Upper(Al.Text) Like '%@ORCOOP%' Or
               Upper(Al.Text) Like '%@ORMVGH%' Or
               Upper(Al.Text) Like '%@ORSAT%' Or
               Upper(Al.Text) Like '%@FARM%' Or
               Upper(Al.Text) Like '%CUSTOM.%')
        
        )
   And a.Object_Type <> 'VIEW'
   And a.Owner Not In ('CUSTOM')
   And a.Object_Name Not Like 'FN%'
   And a.Object_Name Not Like 'PR%'
                                         
   ---VIEW 
 Select 'Alter' || ' ' ||
        Decode(a.Object_Type, 'PACKAGE BODY', 'PACKAGE', a.Object_Type) || ' ' ||
        a.Owner || '.' || a.Object_Name || ' ' || 'COMPILE;' Objeto_Compile
   From All_Objects a
  Where a.Status <> 'VALID'
   And a.Object_Type <> 'SYNONYM'
   And A.owner <> 'CUSTOM'   
    And Exists (Select 1
           From All_Views Av
          Where Av.View_Name = a.Object_Name
            And (Upper(Av.Text_Vc) Not Like '%@ORCOOP%' And
                Upper(Av.Text_Vc) Not Like '%@ORMVGH%' And
                Upper(Av.Text_Vc) Not Like '%@ORSAT%' And
                Upper(Av.Text_Vc) Not Like '%@FARM%')
         )
          
         
 --CUSTOM
 
 
 Select 'Alter' || ' ' ||
       Decode(a.Object_Type, 'PACKAGE BODY', 'PACKAGE', a.Object_Type) || ' ' ||
       a.Owner || '.' || a.Object_Name || ' ' || 'COMPILE;' Objeto_Compile
  From All_Objects a
 Where a.Status <> 'VALID'
   And a.Object_Type <> 'SYNONYM'
      
   And Not Exists (Select 1
          From All_Source Al
         Where Al.Name = a.Object_Name
           And (Upper(Al.Text) Like '%@ORCOOP%' Or
               Upper(Al.Text) Like '%@ORMVGH%' Or
               Upper(Al.Text) Like '%@ORSAT%' Or
               Upper(Al.Text) Like '%@FARM%' Or
               Upper(Al.Text) Like '%EMAIL%' Or
               Upper(Al.Text) Like '%TOTVS%' )
        
        )
   And a.Object_Type <> 'VIEW'
   And a.Owner = 'CUSTOM'
   And a.object_name Not In ('FN_RETORNA_PLANOS_USUARIO_CON', 'FN_RETORNA_PLAN_USU_CON_POR_P')     
   
   ------ VIEW CUSTOM
   
   
  Select 'Alter' || ' ' ||
         Decode(a.Object_Type, 'PACKAGE BODY', 'PACKAGE', a.Object_Type) || ' ' ||
         a.Owner || '.' || a.Object_Name || ' ' || 'COMPILE;' Objeto_Compile
    From All_Objects a
   Where a.Status <> 'VALID'
    And Not Exists
   (Select 1
            From All_Views Av
           Where upper(Av.View_Name) = upper(a.Object_Name)
             And (Upper(Av.Text_Vc) Like Upper('%ORCOOP%') And
                 Upper(Av.Text_Vc)  Like Upper('%ORMVGH%') And
                 Upper(Av.Text_Vc)  Like Upper('%ORSAT%') And
                 Upper(Av.Text_Vc)  Like Upper('%FARM%') And
                 Upper(Av.Text_Vc)  Like Upper('%TOTVS%')))
     And a.Object_Type <> 'SYNONYM'
     And a.Owner = 'CUSTOM'
  And a.Object_Name = Upper('VW_GERAL_DADOS_GUIA_MEDICO')
    
        
     And a.Object_Name Not In ('VW_WEB_SUF_UTILIZACAO',
                               'VW_CHECK_LIST_RE_SUMARIZADO',
                               'VW_CHECK_LIST_RE',
                               'TESTE_RELATORIO')    
                               
    
