Select Rowid, m.* From DBAMV.MENU_SOUL m
Where cd_modulo Is Null
And chave_pai Is Null;
