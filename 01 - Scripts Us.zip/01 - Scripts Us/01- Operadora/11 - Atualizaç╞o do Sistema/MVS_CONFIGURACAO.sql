--[17:56] Rafael Otavio Pinto Vidal
Select o.*, Rowid From mvs_configuracao o
Where o.valor Like '%192.168%'

