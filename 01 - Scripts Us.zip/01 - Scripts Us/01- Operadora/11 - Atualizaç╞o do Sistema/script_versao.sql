Select *
  From Dbamv.Gcm_Script i
 Where 1 = 1
   --And i.cd_status <> '0'
   And i.Cd_Ambiente = 'CS1'
   And Trunc(i.Dh_Execucao) >= '03/06/2023'
 Order By i.Dh_Execucao Desc;
--Select * From dbamv.gcm_versao


                      
Select *
  From Dbamv.Gcm_Script i
 Where 1 = 1
   And i.cd_status <> '0'
   And i.Cd_Ambiente = 'CS1'
   And Trunc(i.Dh_Execucao) >= '03/06/2023' 
   And (i.cd_status Not Like '%955%' 
   And i.cd_status Not Like '%2260%'
   And i.cd_status Not Like '%2275%'
   And i.cd_status Not Like '%1430%'
   And i.cd_status Not Like '%1%'
   And i.cd_status Not Like '%2264%'
   )
 Order By i.Dh_Execucao Desc; 
 
 

Select Cd_Item As "SIGLA PRODUTO",
       Decode(Cd_Item,
              'SOULMV-WI5',
              'WORKSPACE',
              'SOULMV-O5',
              'PLANO',
              Null) As Produto,
       Ds_Versao As Versao,
       Count(*) As "SCRIPTS EXECUTADOS"
  From Dbamv.Gcm_Script
 Where Trunc(Dh_Execucao) >= '03/06/2023'  
 --And cd_item = 'SOULMV-O5'
 Group By Ds_Versao, Cd_Item
 Order By 3 Desc;
 
 Select * From Dbamv.Gcm_versao;

