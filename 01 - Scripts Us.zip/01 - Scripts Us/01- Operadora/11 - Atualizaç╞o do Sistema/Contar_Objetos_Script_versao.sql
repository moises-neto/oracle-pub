SELECT ds_versao, Count(*) FROM DBAMV.GCM_SCRIPT 
Where  Trunc(dh_execucao) >= '26/04/2023'   
GROUP BY ds_versao
Order By 1 Desc;


