Select *
  From Dbamv.Gcm_Script i
 Where 1 = 1
   --And i.cd_status <> '0'
   And i.Cd_Ambiente = 'SML'
   And Trunc(i.Dh_Execucao) >= '26/04/2023'
 Order By i.Dh_Execucao Desc;
--Select * From dbamv.gcm_versao


                      
Select *
  From Dbamv.Gcm_Script i
 Where 1 = 1
   And i.cd_status <> '0'
   And i.Cd_Ambiente = 'SML'
   And Trunc(i.Dh_Execucao) >= '26/04/2023' 
   And (i.cd_status Not Like '%955%' 
   And i.cd_status Not Like '%2260%'
   And i.cd_status Not Like '%2275%'
   And i.cd_status Not Like '%1430%'
   And i.cd_status Not Like '%1%'
   And i.cd_status Not Like '%2264%'
   )
 Order By i.Dh_Execucao Desc;


