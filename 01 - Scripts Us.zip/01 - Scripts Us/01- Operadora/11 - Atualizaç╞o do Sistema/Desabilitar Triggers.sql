--rodar antes da atualiza��o, e pegar as trigger s� que est�o habilitadas 

--DISABLED

SELECT 'ALTER TRIGGER inf$rpl.' || t.TRIGGER_NAME || ' DISABLE;'
  From All_Triggers t
 Where t.OWNER = upper('inf$rpl')
And t.STATUS = 'ENABLED'
 
 Union All
 
 
  Select 'ALTER TRIGGER custom.' || t.TRIGGER_NAME || ' DISABLE;'
  From All_Triggers t
 Where t.OWNER = upper('custom') 
 And t.STATUS = 'ENABLED'


 ---ENABLE 
SELECT 'ALTER TRIGGER inf$rpl.' || t.TRIGGER_NAME || ' ENABLE;'
  From All_Triggers t
 Where t.OWNER = upper('inf$rpl')
And t.STATUS = 'ENABLED'
 
 
 Union All
 
  Select 'ALTER TRIGGER custom.' || t.TRIGGER_NAME || ' ENABLE;'
  From All_Triggers t
 Where t.OWNER = upper('custom') 
 And t.STATUS = 'ENABLED'; 
 

 
