Select 'Alter' || ' ' ||
       Decode(a.Object_Type, 'PACKAGE BODY', 'PACKAGE', a.Object_Type) || ' ' ||
       a.Owner || '.' || a.Object_Name || ' ' || 'COMPILE;' Objeto_Compile
  From All_Objects a
 Where a.Status <> 'VALID' 
 --And a.owner Not In ('CUSTOM', 'DBAPS')
 And a.OBJECT_TYPE <> 'SYNONYM'
 And a.object_name Not Like 'FN%'
 And a.object_name Not Like 'PR%'
 
 Select Count(*)
  From All_Objects a
 Where a.Status <> 'VALID'
 And a.OBJECT_TYPE <> 'SYNONYM';     


Begin
    dbaps.recompile();
End;


 


