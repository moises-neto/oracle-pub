Declare
  Cursor Cconfmvs Is
    Select p.Cd_Produto                 As Cd_Produto_Atual,
           p.Ds_Url_Servidor            As Ds_Url_Servidor_Atual,
           p.Ds_Url_Serv_Relatorio      As Ds_Url_Serv_Relatorio_Atual,
           p.Ds_Url_Servidor_Html       As Ds_Url_Servidor_Html_Atual,
           p.Ds_Url_Serv_Relatorio_Html As Ds_Url_Serv_Relatorio_Html_Atu,
           p.Ds_Url_Servidor_Flex       As Ds_Url_Servidor_Flex_Atual,
           p.Ds_Url_Serv_Relatorio_Flex As Ds_Url_Serv_Relatorio_Flex_Atu,
           s.cd_produto,
           s.Ds_Produto,
           s.Ds_Url_Servidor,
           s.Ds_Url_Serv_Relatorio,
           s.Ds_Url_Servidor_Html,
           s.Ds_Url_Serv_Relatorio_Html,
           s.Ds_Url_Servidor_Flex,
           s.Ds_Url_Serv_Relatorio_Flex
      From Dbasgu.Produto_Sistema p, Custom.Conf_Mvs_Sml s --buscar no BANCO PRD a table Custom.Conf_Mvs_Sml 
     Where p.Cd_Produto = s.Cd_Produto
       And (p.Ds_Url_Serv_Relatorio <> s.Ds_Url_Serv_Relatorio Or
           p.Ds_Url_Serv_Relatorio_Flex <> s.Ds_Url_Serv_Relatorio_Flex Or
           p.Ds_Url_Serv_Relatorio_Html <> s.Ds_Url_Serv_Relatorio_Html Or
           p.Ds_Url_Servidor <> s.Ds_Url_Servidor Or
           p.Ds_Url_Servidor_Flex <> s.Ds_Url_Servidor_Flex Or
           p.Ds_Url_Servidor_Html <> s.Ds_Url_Servidor_Html);

Begin

  For i In Cconfmvs Loop
    Begin
      Update Dbasgu.Produto_Sistema p
         Set p.Ds_Url_Serv_Relatorio      = i.Ds_Url_Serv_Relatorio,
             p.Ds_Url_Serv_Relatorio_Flex = i.Ds_Url_Serv_Relatorio_Flex,
             p.Ds_Url_Serv_Relatorio_Html = i.Ds_Url_Serv_Relatorio_Html,
             p.Ds_Url_Servidor            = i.Ds_Url_Servidor,
             p.Ds_Url_Servidor_Flex       = i.Ds_Url_Servidor_Flex,
             p.Ds_Url_Servidor_Html       = i.Ds_Url_Servidor_Html
       Where p.Cd_Produto = i.Cd_Produto;
    
    End;
  End Loop;

End;
