
---MUDAR OS ENDERE�OS PARA souloperadora:80
Select Rowid,
       p.Nm_Produto,
       p.Ds_Produto,
       p.Tp_Plataforma,
       p.Ds_Url_Servidor,
       Replace(p.Ds_Url_Servidor, 'souloperadora:80', '172.16.24.171:81') As Ds_Url_Servidor_New,
       p.Ds_Url_Serv_Relatorio,
       Replace(p.Ds_Url_Serv_Relatorio, 'souloperadora:80', '172.16.24.171:81') As Ds_Url_Serv_Relatorio_New,
       p.Ds_Url_Servidor_Html,
       Replace(p.Ds_Url_Servidor_Html, 'souloperadora:80', '172.16.24.171:81') As Ds_Url_Servidor_Html_New,
       p.Ds_Url_Serv_Relatorio_Html,
       Replace(p.Ds_Url_Serv_Relatorio_Html,
               'souloperadora:80',
               '172.16.24.171:81') As Ds_Url_Serv_Relatorio_Html_New,
       p.Ds_Url_Servidor_Flex,
       Replace(p.Ds_Url_Servidor_Flex, 'souloperadora:80', '172.16.24.171:81') As Ds_Url_Servidor_Flex_New,
       p.Ds_Url_Serv_Relatorio_Flex,
       Replace(p.Ds_Url_Serv_Relatorio_Flex,
               'souloperadora:80',
               '172.16.24.171:81') As Ds_Url_Serv_Relatorio_Flex_New,
               Rowid
  From Dbasgu.Produto_Sistema p
 Where (p.Ds_Url_Servidor Is Not Null Or
       p.Ds_Url_Serv_Relatorio_Flex Is Not Null Or
       p.Ds_Url_Serv_Relatorio_Html Is Not Null Or
       p.Ds_Url_Servidor Is Not Null Or p.Ds_Url_Servidor_Flex Is Not Null Or
       p.Ds_Url_Servidor_Html Is Not Null)
 Order By 2;

Select c.Cd_Sistema,
       c.Chave,
       c.Valor,
       Replace(c.Valor, 'souloperadora:80', '172.16.24.171:81') As Valor_New,
       c.Sn_Somente_Leitura,
       c.Cd_Configuracao,
       c.Cd_Configuracao_Processo,
       c.Ds_Configuracao,
       c.Cd_Multi_Empresa,
       Rowid
  From Dbamv.Configuracao c
--Where UPPER(c.valor) Like '%SOUL%'
 Where c.Chave = 'URL_NOVO_REPORT_SOUL';
