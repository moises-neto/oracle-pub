Declare

  l_Http_Req Utl_Http.req;
  l_Http_Resp Utl_Http.Resp;
  l_Vc_Header_Name Varchar2(256);
  l_Vc_Header_Value Varchar2(1024);
  l_Vc_Html Varchar2(32767);
Begin

  l_Http_Req := Utl_Http.Begin_Request('http://coo-swps02:8003/mvsaudews/app/cliente-ptu/pedido-autorizacao/658847789');

  Dbms_Output.Put_Line('Request URL: ' || l_Http_Req.Url);

  Dbms_Output.Put_Line('Request Method: ' || l_Http_Req.Method);

  Dbms_Output.Put_Line('Request Version: ' || l_Http_Req.Http_Version);

  Utl_Http.Set_Header(l_Http_Req, 'Header #1', 'Chrome V.52.X');

  l_Http_Resp := Utl_Http.Get_Response(l_Http_Req);

  Dbms_Output.Put_Line('Response Status Code: ' || l_Http_Resp.Status_Code);

  Dbms_Output.Put_Line('Response Reason: ' || l_Http_Resp.Reason_Phrase);

  Dbms_Output.Put_Line('Response Version: ' || l_Http_Resp.Http_Version);


End;


Request URL: http://coo-swps02:8003/mvsaudews/app/cliente-ptu/pedido-autorizacao/658847789
Request Method: GET
Request Version: 
Response Status Code: 200
Response Reason: OK
Response Version: HTTP/1.1
---Header Count Starts---


