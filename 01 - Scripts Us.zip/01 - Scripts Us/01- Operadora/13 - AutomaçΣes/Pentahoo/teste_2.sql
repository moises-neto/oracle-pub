

select * From custom.import_pentahoo;

Select * from custom.import_pentahoo_erros;
