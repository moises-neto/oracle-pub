Create table custom.Import_Pentahoo
(nome varchar2(30) not null,
idade int not null
);

select p.*, rowid From custom.Import_Pentahoo p

truncate table custom.Import_Pentahoo



