Declare
  -- Variable
                                                                                                                        
  Type v_Tabdata Is Table Of Teste%Rowtype;
  v_Tabbulk v_Tabdata;
  x    Number := 0;

  Cursor C1 Is
    Select a.Codigo, a.Descricao From Teste a;

Begin
  -- Trunca a tabela
  Dbms_Output.Put_Line('Truncando a tabela...');
  Dbms_Utility.Exec_Ddl_Statement('TRUNCATE TABLE teste2');

  Open C1;
  Loop
    Dbms_Output.Put_Line('Iniciando leitura...');
  
    -- Fetch Collection
    Fetch C1 Bulk Collect
      Into v_Tabbulk;
  
    Dbms_Output.Put_Line('Registro(s) a serem processados: ' ||
                         v_Tabbulk.Count);
  
    -- Verifica se h� registros
    If v_Tabbulk.Count > 0 Then
      Forall x In 1 .. v_Tabbulk.Count
        Insert Into Teste2 Values v_Tabbulk (x);
      Dbms_Output.Put_Line('Registros processados...');
    
    End If;
  
    Exit When C1%Notfound;
    Commit;
  
  End Loop;

  -- N�o esque�a de fechar o seu cursor :)

  Close C1;

  Dbms_Output.Put_Line('Fim do processo...');

Exception
  When Others Then
    Dbms_Output.Put_Line('[ ERRO ] ' || Dbms_Utility.Format_Error_Stack);
  
    If Sql%Isopen Then
      -- N�o esque�a de fechar o seu cursor :)
      Close C1;
    
    End If;
  
End;
