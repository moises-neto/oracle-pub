Select * from dbasgu.modulos m
where m.cd_modulo like '%GUIA%'  
