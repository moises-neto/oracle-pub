select * from ITLANCAMENTO_HORA t
where t.cd_lancamento_hora = 93
and t.cd_prestador = 63352

select * from dbamv.guia@ormvgh ghosp
where ghosp.nr_guia = '63834949'


