Select Distinct Trim(Lower(Substr(c.Ds_Email, Instr(c.Ds_Email, '@'), 1000))) As Dominio_Email
  From Contrato c
 Where c.Ds_Email Is Not Null
   And c.Tp_Contrato = 'E';


