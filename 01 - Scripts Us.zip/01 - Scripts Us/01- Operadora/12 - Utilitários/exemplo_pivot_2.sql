Select X.CD_PROCEDIMENTO AS PROCEDIMENTO,  X."'FI'" AS FI, X."'CO'" AS CO, X."'HM'" AS HM
  from (Select C.CD_PROCEDIMENTO, c.tp_pagamento As TP_Pagamento, c.vl_unit_pago as valor_Total
          From dbaps.v_ctas_medicas c
        
         Where c.dt_competencia = '202104'
           And (c.Cd_Prestador = '300015' OR c.Cd_Prestador is null)
           And (c.cd_procedimento = '40805026' OR c.cd_procedimento IS NULL))

Pivot(sum(valor_Total)
   for TP_Pagamento in('FI', 'CO', 'HM')) X
