
-- Total de Utiliza��o do contrato por usu�rio
Select 'Totvs' "Sistema", --1
       g.Nrcontrato As "Nr. Contrato", --2
       To_Char(g.Nrperiodo_Compet) As "Per�odo de Compet�ncia", --3
       g.Nrarea_Acao || '.' || g.Nrcontrato || '.' ||
       Lpad(g.Nrfamilia, 6, '0') || '.' || g.Tpusuario || g.Nrdigito As "C�d. Usu�rio", --4
       g.Nopessoa As "Nome do Benefici�rio", --5 
       g.Dtnascimento As "Data Nascimento", --6
       g.Ds_Parentesco, --7
       g.Nrcgc_Cpf As "Nr. CPF", --8
       g.Genero, --9
       g.Tpplano Acomodacao, --10
       g.Titular "Nome do Titular", --11
       s.Cdservico As "C�d. Procedimento",
       s.Noservico As "Descri��o do Procedimento",
       s.Dtrealizacao As "Data de Realiza��o",
       To_Number(Nvl(s.Vlpg_Pr_Pago, 0) + Nvl(s.Vlpg_Ex_Pago, 0)) As "Valor",
       s.Qtservico As "Quantidade",
       To_Number(g.Cod_Prest) "Cod. Prestador",
       g.Nome_Prest Prestador,
       g.Esp_Prest "Especialidade do Prestador",
       Decode(Cdtipo_Guia, '1', 'CONSULTA', '2', 'SADT', '3', 'INTERNACAO') Tipo,
       g.Lotacao "Lota��o",
       g.Dtinicio,
       g.Dtexclusao
  From (Select s.*,
               Sr.Noservico,
               Se.Cdsituacao_Pagto,
               (Select Nvl(Sum(Dpp.Vlpago + Dpp.Vlpago_Filme), 0)
                  From Detalhe_Pagamento@Orcoop Dpp
                 Where Se.Nrservico_Evento = Dpp.Nrservico_Evento
                   And Dpp.Aomovimento = 'P'
                   And Dpp.Cdoperacao = 'PG'
                   And Dpp.Nrmovimento_Origem Is Null) Vlpg_Pr_Pago,
               (Select Nvl(Sum(Dpe.Vlpago + Dpe.Vlpago_Filme), 0)
                  From Detalhe_Pagamento@Orcoop Dpe
                 Where Se.Nrservico_Evento = Dpe.Nrservico_Evento
                   And Dpe.Aomovimento = 'E'
                   And Dpe.Cdoperacao = 'PG'
                   And Dpe.Nrmovimento_Origem Is Null) Vlpg_Ex_Pago
          From Servico_Da_Guia@Orcoop s,
               Servico_Evento@Orcoop  Se,
               Servico@Orcoop         Sr
         Where s.Nrsequencial_Servico = Se.Nrsequencial_Servico
           And Sr.Cdservico = s.Cdservico) s,
       (Select *
          From (Select g.Cdtipo_Guia,
                       Eg.Nrperiodo Nrperiodo_Compet,
                       Eg.Nrarea_Acao,
                       Eg.Nrcontrato,
                       Eg.Nrfamilia,
                       Eg.Tpusuario,
                       g.Cdserie_Guia,
                       g.Nrguia,
                       g.Nrdigito,
                       g.Dtatendimento,
                       p.Nopessoa,
                       p.Dtnascimento,
                       p.Nrcgc_Cpf,
                       p.Cdsexo,
                       Decode(p.Cdsexo,
                              'F',
                              'Feminino',
                              'M',
                              'Masculino',
                              'Outros') Genero,
                       u.Tpplano,
                       Vu.Nopessoa Titular,
                       Vp.Cdprestador Cod_Prest,
                       Vp.Nopessoa Nome_Prest,
                       e.Noespecialidade Esp_Prest,
                       (Select Fa.Cdlotacao
                          From Familia@Orcoop Fa
                         Where Fa.Nrregistro = u.Nrregistro
                           And Fa.Nrcontrato = u.Nrcontrato
                           And Fa.Nrfamilia = u.Nrfamilia) Lotacao,
                       u.Dtinicio,
                       u.Dtexclusao,
                       Case
                         When Tu.Notipusu Is Null Then
                          Case
                            When u.Tpusuario = '00' Then
                             'TITULAR'
                            Else
                             'NAO ENCONTRATO O GRAU'
                          End
                         Else
                          Tu.Notipusu
                       End Ds_Parentesco
                  From Guia_De_Servico@Orcoop             g,
                       Evento_Guia@Orcoop                 Eg,
                       Usuario@Orcoop                     u,
                       Pessoa@Orcoop                      p,
                       v_Prestador@Orcoop                 Vp,
                       Especialidade@Orcoop               e,
                       v_Pessoa_Usuario@Orcoop            Vu,
                       Dbamv.De_Para_Unicoo_Mv_Serie_Guia Gsx,
                       Tipo_De_Usuario@Orcoop             Tu
                 Where g.Cdserie_Guia = Eg.Cdserie_Guia
                   And g.Nrguia = Eg.Nrguia
                   And g.Nrcontrato = u.Nrcontrato
                   And g.Nrfamilia = u.Nrfamilia
                   And g.Tpusuario = u.Tpusuario
                   And g.Nrdigito = u.Nrdigitoct
                      
                   And u.Tpusuario = Tu.Tpusuario(+)
                      
                   And u.Nrregistro_Usuario = p.Nrregistro
                   And Vp.Cdprestador = g.Cdprestador
                   And e.Cdespecialidade(+) = Vp.Cdespecial_Predom
                   And Vu.Nrcontrato = u.Nrcontrato
                   And Vu.Nrfamilia = u.Nrfamilia
                   And Vu.Tpusuario = '00'
                   And Gsx.Cd_Serie_Guia_Unicoo = g.Cdserie_Guia) a
         Where a.Nrcontrato In
               (Select Regexp_Substr(&< Name = "N�mero do Contrato"
                                     Hint =
                                     "Se houver mais de um, separ�-los por v�rgula"
                                     Type = "string" >,
                                     '[^,]+',
                                     1,
                                     Level)
                  From Dual
                Connect By Regexp_Substr(&< Name = "N�mero do Contrato"
                                         Hint =
                                         "Se houver mais de um, separ�-los por v�rgula"
                                         Type = "string" >,
                                         '[^,]+',
                                         1,
                                         Level) Is Not Null)
           And Nrperiodo_Compet Between &< Name = "Data Inicial"
         Hint = "Data Inicial - Formato AAAAMM" Type = Date > And &<
         Name = "Data Final" Hint = "Data Inicial - Formato AAAAMM"
         Type = Date >
           And a.Nrarea_Acao = '018'
           And Exists (Select '1'
                  From Categoria_De_Usuario@Orcoop c,
                       Tipo_De_Usuario@Orcoop      t
                 Where c.Cdusucateg = t.Cdusucateg(+)
                   And t.Tpusuario(+) = a.Tpusuario
                   And (c.Cdusucateg = '*' Or '*' = '*'))) g
 Where g.Cdserie_Guia = s.Cdserie_Guia
   And g.Nrguia = s.Nrguia
   And Nrperiodo_Compet <= 201709
   
  -- And 1=2
   
Union All
Select 'MV' "Sistema", --1
       r.Cd_Contrato_Interno, --2
       r.Dt_Competencia, --3
       u.Cd_Mat_Alternativa Cd_Carteira, --4
       u.Nm_Segurado Nm_Benef, --5
       u.Dt_Nascimento, --6
       Case 
         When  Gp.Ds_Parentesco Is Null Then
           Case 
             When u.tp_usuario = 'T' Then
               'TITULAR'
             Else
                'NAO ENCONTRATO O GRAU'
             End 
         Else
           Gp.Ds_Parentesco
       End Ds_Parentesco, --7
       To_Char(u.Nr_Cpf) As "Nr. CPF",
       p.Tp_Sexo,
       v.Tpplano Acomodacao,
       Case
         When u.Tp_Usuario = 'T' Then
          u.Nm_Segurado
         Else
          (Select Nvl(Us.Nm_Segurado, u.Nm_Segurado)
             From Dbaps.Usuario Us
            Where Us.Cd_Matricula = u.Cd_Matricula_Tem
              And Us.Tp_Usuario = 'T')
       End Pessoa_Tit,
       r.Cd_Procedimento,
       r.Ds_Procedimento,
       r.Dt_Realizado,
       r.Vl_Total_Pago,
       r.Qt_Pago,
       r.Cd_Prestador_Pagamento,
       (Select Pp.Nm_Prestador
          From Dbaps.Prestador Pp
         Where Pp.Cd_Prestador = r.Cd_Prestador_Pagamento) Nm_Prestador,
       (Select Ee.Ds_Especialidade
          From Dbaps.Especialidade Ee, Dbaps.Especialidade_Prestador Ep
         Where Ee.Cd_Especialidade = Ep.Cd_Especialidade
           And Ep.Cd_Prestador = r.Cd_Prestador_Pagamento
           And Ep.Sn_Principal = 'S'
           And Ep.Sn_Divulga = 'S'
           And Rownum = 1) Ds_Especialidade,
       Decode(r.Cd_Tipo_Atendimento,
              '1',
              'CONSULTA',
              '2',
              'SADT',
              '3',
              'INTERNACAO') Tp_Atendimento,
       (Select Replace(Replace(Substr(Em.Ds_Empresa,
                                      Instr(Em.Ds_Empresa, '(') - 0,
                                      10),
                               '(',
                               ''),
                       ')')
          From Dbaps.Empresa Em
         Where Em.Cd_Empresa = u.Cd_Empresa
           And Instr(Em.Ds_Empresa, '(') > 1
           And Em.Cd_Empresa_Tem Is Not Null) Ds_Lotacao,
       v.Dt_Ini_Usuario,
       v.Dtexclusao
  From Custom.Utilizacao_Mv_Relatorio r,
       Dbaps.Usuario                  u,
       Dbaps.Pessoa                   p,
       Dbaps.v_Usuario                v,
       Dbaps.Grau_Parentesco          Gp
 Where r.Cd_Matricula = u.Cd_Matricula
   And u.Cd_Pessoa = p.Cd_Pessoa
   And u.Cd_Matricula = v.Nrsequencial_Usuario
   And r.Tp_Situacao In ('AA')
   And r.Dt_Competencia >= 201710
   --   And 1=2
   And u.Cd_Parentesco = Gp.Cd_Parentesco(+)
      
   And Substr(r.Nr_Carteira_Beneficiario, 4, 4) In
       (Select Regexp_Substr(&< Name = "N�mero do Contrato"
                             Hint =
                             "Se houver mais de um, separ�-los por v�rgula"
                             Type = "string" >,
                             '[^,]+',
                             1,
                             Level)
          From Dual
        Connect By Regexp_Substr(&< Name = "N�mero do Contrato"
                                 Hint =
                                 "Se houver mais de um, separ�-los por v�rgula"
                                 Type = "string" >,
                                 '[^,]+',
                                 1,
                                 Level) Is Not Null)
   And r.Dt_Competencia Between &< Name = "Data Inicial"
 Hint = "Data Inicial - Formato AAAAMM" Type = Date > And &<
 Name = "Data Final" Hint = "Data Inicial - Formato AAAAMM"
 Type = Date >
 Order By 11, 1
