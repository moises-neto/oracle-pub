select x.*,y.*
  from (Select  --CONCAT(to_char(dt_emissao, 'HH24'),':00') as DATA_HORA, 
               to_char(dt_emissao, 'HH24') DATA_HORA_PIVOT
          from dbaps.guia
         where cd_usuario_emissao = 'GAMARO'
           and trunc(dt_emissao) = '01/03/2021')

pivot(count(DATA_HORA_PIVOT)
   for DATA_HORA_PIVOT IN(05,
                          06,
                          07,
                          08,
                          09,
                          10,
                          11,
                          12,
                          13,
                          14,
                          15,
                          16,
                          17,
                          18,
                          19,
                          20))x, 
                          
(Select count(g.nr_guia) as total
          from dbaps.guia g
         where g.cd_usuario_emissao = 'GAMARO'
           and trunc(dt_emissao) = '01/03/2021') y   
           
           
           Select g.nr_guia,g.cd_usuario_emissao, g.dt_emissao
             from dbaps.guia g
            where g.cd_usuario_emissao = 'GAMARO'
              and trunc(dt_emissao) = '01/03/2021'
            
            
  
  
