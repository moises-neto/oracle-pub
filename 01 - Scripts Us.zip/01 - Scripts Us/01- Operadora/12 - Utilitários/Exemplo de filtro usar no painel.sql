 SELECT NVL((Select 'SIM'
             From dbaps.plano_contrato pc, dbaps.plano p
            where p.cd_plano = pc.cd_plano
              And pc.cd_contrato = Co.cd_contrato
              And p.tp_natureza_juridica = 1),
           'N�O') as Plano_Particular,
       us.dt_cadastro_sistema as Data_Cadastro,
       us.dt_cadastro as Data_Adesao,
       Co.Cd_Contrato_INterno Nr_Contrato,
       Co.Cd_Contrato contrato_mv,
       us.nm_segurado
  FROM Dbaps.Usuario Us, Dbaps.Contrato Co, Dbaps.Usuario_Observacao Uo
 WHERE Us.Cd_Contrato = Co.Cd_Contrato
   And Uo.Cd_Matricula = us.cd_matricula
   And UPPER(Uo.Ds_Usuario_Observacao) IN
       ('IMPORTA��O DE EMPRESA VIA LAYOUT PLANIUM')
   and (Co.tp_contrato <> 'U') --or
      -- (Co.tp_contrato = 'A' and Co.sn_demitido_aposentado_obito = 'S')) --s� PF */
   AND co.Sn_Demitido_Aposentado_Obito = 'N'
   And us.sn_titular in (#SN#)
   AND CO.CD_CONTRATO_INTERNO = to_char(#CONTRATO_INTERNO#)
   AND US.dt_cadastro_sistema BETWEEN #DATA_INICIAL# AND #DATA_FINAL# 


UNION


SELECT NVL((Select 'SIM'
             From dbaps.plano_contrato pc, dbaps.plano p
            where p.cd_plano = pc.cd_plano
              And pc.cd_contrato = Co.cd_contrato
              And p.tp_natureza_juridica = 1),
           'N�O') as Plano_Particular,
       us.dt_cadastro_sistema as Data_Cadastro,
       us.dt_cadastro as Data_Adesao,
       Co.Cd_Contrato_INterno Nr_Contrato,
       Co.Cd_Contrato contrato_mv,
       us.nm_segurado
  FROM Dbaps.Usuario Us, Dbaps.Contrato Co, Dbaps.Usuario_Observacao Uo
 WHERE Us.Cd_Contrato = Co.Cd_Contrato
   And Uo.Cd_Matricula = us.cd_matricula
   And UPPER(Uo.Ds_Usuario_Observacao) IN
       ('IMPORTA��O DE EMPRESA VIA LAYOUT PLANIUM')
   and (Co.tp_contrato <> 'U') --or
      -- (Co.tp_contrato = 'A' and Co.sn_demitido_aposentado_obito = 'S')) --s� PF */
   AND co.Sn_Demitido_Aposentado_Obito = 'N'
   And us.sn_titular in (#SN#)
   AND US.dt_cadastro_sistema BETWEEN #DATA_INICIAL# AND #DATA_FINAL# 
   AND (to_char(#CONTRATO_INTERNO#) IS NULL) 
