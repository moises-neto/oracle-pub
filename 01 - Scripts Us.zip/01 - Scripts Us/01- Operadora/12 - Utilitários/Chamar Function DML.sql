DECLARE
   v_retorno VARCHAR2(10);

BEGIN
  Begin
  Dbamv.Pkg_Mv2000.Atribui_Empresa('1');
End;

   EXECUTE IMMEDIATE
   'CALL DBAPS.fnc_mvs_geracao_ptu_a500_xml(P_CD_CHAVE => 17944) INTO :v_retorno'
   USING OUT v_retorno;

  -- DBMS_OUTPUT.put_line('Retorno: '|| v_retorno);

END;
