Create Sequence custom.seq_nome_tabela

Start With 1
Increment By 1
Nocache
Nocycle
Minvalue 1
Maxvalue 999999999999999999999999999;


Grant All On Pkg_Integracao_Usuario_Soul To DBAMV;
Grant All On Pkg_Integracao_Usuario_Soul To DBAPS;
Grant All On Pkg_Integracao_Usuario_Soul To DBASGU;
