select u.nm_segurado As Beneficiario,
       Case (u.tp_usuario)
         When 'T' Then
          'Titular'
         When 'D' Then
          'Dependente'
         When 'A' Then
          'Agregado'
         else
          'Verificar'
       end Tipo_Beneficiario,
       u.cd_plano,
       p.ds_plano,
       u.cd_na_empresa,
       c.cd_contrato_interno As Contrato_Interno,
       c.cd_contrato,
       u.cd_empresa,
       c.nm_responsavel_financeiro AS Empresa,
       nvl(u.cd_mat_alternativa, u.cd_matricula_tem) As Carteira,
       (rank()
        over(PARTITION BY u.cd_na_empresa ORDER BY u.cd_dependencia) - 1) Titular_Dependente,
       u.sn_titular
  from dbaps.usuario u, dbaps.contrato c, DBAPS.PLANO p
 where u.cd_contrato = c.cd_contrato
   and p.cd_plano = u.cd_plano
   and c.cd_contrato_interno = '2021'
   And c.sn_ativo = 'S'
   And u.sn_ativo = 'S'
