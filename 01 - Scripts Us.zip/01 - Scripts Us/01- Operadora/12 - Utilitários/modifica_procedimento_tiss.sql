/*
CH2102-2790 - transação 633207266

A Fesp não ta conseguindo trafegar a resposta via WSD do código 40324788
pois estamos solicitando com tipo de "tabela 00"
quando o certo seria trafegar como tipo de "tabela 22"
*/


select null DT_INI_VIGENCIA,
       null DT_FIM_VIGENCIA,
       null DT_FIM_IMPLANTACAO,
       
       pr.cd_procedimento,
       
       -- confirmar o padrão
       22092 cd_grupo_procedimento,
       
       0 CD_GRU_CARENCIA,
       0 CD_GRU_DIREITO,
       null CD_PORTE_ANESTESICO,
        pr.ds_procedimento,
       'A' TP_SEXO,
       null TP_GUIA,
       null NR_AUXILIAR,
       null NR_INCIDENCIAS,
       null TP_FILME,
       null DS_UNIDADE,
       null NR_DIAS_INTERNACAO,
       pr.nr_nivel_autorizacao,
       pr.cd_item_despesa,
       null CD_APRESENTACAO,
       null TP_PARTO_SIP,
       null CD_ROL_PROCEDIMENTOS_ANS,
       pr.tp_natureza,
       null NR_IDADE_MINIMA,
       null NR_IDADE_MAXIMA,
       null QT_MAXIMA_SOLIC,
       null QT_MAXIMA_DIA,
       null QT_MAXIMA_MES,
       null QT_MAXIMA_ANO,
       null QT_MAXIMA_PERMITIDA,
       null NR_DIAS_INTERVALO,
       null CD_SIH_MS,
       null NR_PROCEDIMENTO,
       null DT_INATIVACAO,
       pr.ds_procedimento_completa,
       null CD_GRUPO_CO_CP,
       null TP_ORIGEM,
       null TP_TABELA,
       null TP_ATO,
       null CD_UNIDADE,
       null VL_APRESENTACAO,
       null NR_ANVISA,
       null CD_MATERIAL_FABRICANTE,
       null NR_AUTORIZACAO_FUNCIONAMENTO,
       null CD_FABRICANTE_OPME_MVS,
       null CD_PROCEDIMENTO_TUSS,
       user CD_USUARIO_INCLUSAO,
       sysdate DT_INCLUSAO,
       'I' TP_FORMA_ENVIO,
       null CD_GRUPO,
       'N' SN_EXIGE_DENTE,
       'N' SN_EXIGE_FACE,
       'N' SN_EXIGE_REGIAO
  from dbaps.procedimento pr
 where pr.cd_procedimento in (40324788);

select t.*, rowid
  from dbaps.tiss_instalacao_tabela_22 t
 where t.cd_procedimento in (40324788, 40323684);
