select * from custom.sms_envio e
Where e.num_telefone like '%97331384%'
and trunc(e.data_envio) between '01/01/2021' and sysdate 
