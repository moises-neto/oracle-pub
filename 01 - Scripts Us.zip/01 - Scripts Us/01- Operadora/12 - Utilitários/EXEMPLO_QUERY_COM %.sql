select

 codUsuario       As "C�d. Usu�rio", --*
 nm_beneficiario  As "Nome do Benefici�rio", --*
 dtnascimento     As "Data Nascimento", --*
 cpf              As "Nr. CPF", --*              
 codprocedimento  As "C�d. Procedimento", --*
 descprocedimento As "Descri��o do Procedimento", --*
 dtrealizacao     As "Data de Realiza��o", --*
 Valor            As "Valor" --,  

  from (Select g.Nrarea_Acao || '.' || g.Nrcontrato || '.' ||
               Lpad(g.Nrfamilia, 6, '0') || '.' || g.Tpusuario || g.Nrdigito codUsuario, --*
               g.Nopessoa nm_beneficiario, --*
               g.Dtnascimento dtnascimento, --*
               g.Nrcgc_Cpf cpf, --*              
               s.Cdservico codprocedimento, --*
               s.Noservico descprocedimento, --*
               trunc(s.Dtrealizacao) dtrealizacao, --*
               Round(To_Number(Nvl(s.Vlpg_Pr_Pago, 0) +
                               Nvl(s.Vlpg_Ex_Pago, 0)),
                     2) Valor --,      
          From (Select s.*,
                       Sr.Noservico,
                       Se.Cdsituacao_Pagto,
                       (Select Nvl(Sum(Dpp.Vlpago + Dpp.Vlpago_Filme), 0)
                          From Detalhe_Pagamento@Orcoop Dpp
                         Where Se.Nrservico_Evento = Dpp.Nrservico_Evento
                           And Dpp.Aomovimento = 'P'
                           And Dpp.Cdoperacao = 'PG'
                           And Dpp.Nrmovimento_Origem Is Null) Vlpg_Pr_Pago,
                       (Select Nvl(Sum(Dpe.Vlpago + Dpe.Vlpago_Filme), 0)
                          From Detalhe_Pagamento@Orcoop Dpe
                         Where Se.Nrservico_Evento = Dpe.Nrservico_Evento
                           And Dpe.Aomovimento = 'E'
                           And Dpe.Cdoperacao = 'PG'
                           And Dpe.Nrmovimento_Origem Is Null) Vlpg_Ex_Pago
                  From Servico_Da_Guia@Orcoop s,
                       Servico_Evento@Orcoop  Se,
                       Servico@Orcoop         Sr
                 Where s.Nrsequencial_Servico = Se.Nrsequencial_Servico
                   And Sr.Cdservico = s.Cdservico) s,
               (Select *
                  From (Select g.Cdtipo_Guia,
                               Eg.Nrperiodo Nrperiodo_Compet,
                               Eg.Nrarea_Acao,
                               Eg.Nrcontrato,
                               Eg.Nrfamilia,
                               Eg.Tpusuario,
                               g.Cdserie_Guia,
                               g.Nrguia,
                               g.Nrdigito,
                               g.Dtatendimento,
                               p.Nopessoa,
                               p.Dtnascimento,
                               p.Nrcgc_Cpf,
                               p.Cdsexo,
                               Decode(p.Cdsexo,
                                      'F',
                                      'Feminino',
                                      'M',
                                      'Masculino',
                                      'Outros') Genero,
                               u.Tpplano,
                               Vu.Nopessoa Titular,
                               Vp.Cdprestador Cod_Prest,
                               Vp.Nopessoa Nome_Prest,
                               e.Noespecialidade Esp_Prest,
                               (Select Fa.Cdlotacao
                                  From Familia@Orcoop Fa
                                 Where Fa.Nrregistro = u.Nrregistro
                                   And Fa.Nrcontrato = u.Nrcontrato
                                   And Fa.Nrfamilia = u.Nrfamilia) Lotacao,
                               u.Dtinicio,
                               u.Dtexclusao
                          From Guia_De_Servico@Orcoop             g,
                               Evento_Guia@Orcoop                 Eg,
                               Usuario@Orcoop                     u,
                               Pessoa@Orcoop                      p,
                               v_Prestador@Orcoop                 Vp,
                               Especialidade@Orcoop               e,
                               v_Pessoa_Usuario@Orcoop            Vu,
                               Dbamv.De_Para_Unicoo_Mv_Serie_Guia Gsx
                         Where g.Cdserie_Guia = Eg.Cdserie_Guia
                           And g.Nrguia = Eg.Nrguia
                           And g.Nrcontrato = u.Nrcontrato
                           And g.Nrfamilia = u.Nrfamilia
                           And g.Tpusuario = u.Tpusuario
                           And g.Nrdigito = u.Nrdigitoct
                           And u.Nrregistro_Usuario = p.Nrregistro
                           And Vp.Cdprestador = g.Cdprestador
                           And e.Cdespecialidade(+) = Vp.Cdespecial_Predom
                           And Vu.Nrcontrato = u.Nrcontrato
                           And Vu.Nrfamilia = u.Nrfamilia
                           And Vu.Tpusuario = '00'
                           And Gsx.Cd_Serie_Guia_Unicoo = g.Cdserie_Guia
                           And p.Nopessoa Like
                               Upper(&< Name = "Nome" Type = "string" Default = "%"
                                                                               Ifempty = "%" >)
                           And lpad(p.Nrcgc_Cpf, 11, '0') Like &<
                         Name = "CPF" Type = "string" Default = "%"
                         Ifempty = "%" >
                        
                        ) a
                 Where a.Nrarea_Acao = '018'
                   And Exists
                 (Select '1'
                          From Categoria_De_Usuario@Orcoop c,
                               Tipo_De_Usuario@Orcoop      t
                         Where c.Cdusucateg = t.Cdusucateg(+)
                           And t.Tpusuario(+) = a.Tpusuario
                           And (c.Cdusucateg = '*' Or '*' = '*'))) g
         Where g.Cdserie_Guia = s.Cdserie_Guia
           And g.Nrguia = s.Nrguia
           And Nrperiodo_Compet <= 201709
        Union All
        Select u.Cd_Mat_Alternativa Cd_Carteira,
               u.Nm_Segurado Nm_Benef,
               u.Dt_Nascimento,
               To_Char(u.Nr_Cpf) As "Nr. CPF",
               
               r.Cd_Procedimento,
               r.Ds_Procedimento,
               trunc(r.Dt_Realizado) Dt_Realizado,
               Round(r.Vl_Total_Pago, 2) Vl_Total_Pago --,
        
          From Custom.Utilizacao_Mv_Relatorio r,
               Dbaps.Usuario                  u,
               Dbaps.Pessoa                   p,
               Dbaps.v_Usuario                v
         Where r.Cd_Matricula = u.Cd_Matricula
           And u.Cd_Pessoa = p.Cd_Pessoa
           And u.Cd_Matricula = v.Nrsequencial_Usuario
           And r.Tp_Situacao In ('AA')
           And r.Dt_Competencia >= 201710
           And u.Nm_Segurado Like
               Upper(&< Name = "Nome" Type = "string" Default = "%"
                                                               Ifempty = "%" >)
           And Lpad(u.Nr_Cpf, 11, '0') Like &< Name = "CPF"
         Type = "string" Default = "%" Ifempty = "%" >
        
        )
 Order By codUsuario, dtrealizacao, descprocedimento
