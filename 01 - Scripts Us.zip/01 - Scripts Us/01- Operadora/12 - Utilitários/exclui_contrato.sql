Select rowid, c.* From contrato c
where c.cd_contrato = 1016673;


Select p.*, rowid From PLANO_CONTRATO p
where p.cd_contrato = 1016673;

Select f.*, rowid From MVS_CONTRATO_FRANQUIA f
where f.cd_contrato = 1016673;


Select c.*, rowid From CONTRATO_MAIORIDADE c
where c.cd_contrato = 1016673;

Select l.*, rowid From LOG_GER_LOTE_ERRO l
where l.cd_contrato = 1016673;

Select * from dbaps.usuario u 
where u.cd_contrato = 1016673;

