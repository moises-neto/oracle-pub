select M.SN_HTML5, M.*, rowid from dbasgu.modulos m
where m.cd_modulo =  'M_SOLICITACAO_WEB'
