SELECT cd_fatura,
       nm_prestador,
       nvl(disponibilidade, 0) disponibilidade,
       nvl(fds, 0) fds,
       nvl(semana, 0) semana,
       nm_setor
  FROM (SELECT x.cd_prestador,
               x.nm_prestador,
               SUM(x.nr_horas) nr_horas,
               x.nm_setor,
               x.tipo,
               x.cd_fatura
          FROM (
                
                SELECT p.cd_prestador,
                        p.nm_prestador,
                        l.dt_inicio,
                        l.dt_fim,
                        (l.nr_horas) nr_horas,
                        l.vl_horas,
                        l.cd_tipo_hora,
                        s.nm_setor,
                        CASE
                          WHEN to_char(l.dt_inicio, 'D') IN ('7', '1') THEN
                           'FDS'
                          ELSE
                           'SEMANA'
                        END tipo,
                        l.cd_lancamento_hora,
                        ll.cd_fatura
                  FROM itlancamento_hora l,
                        dbamv.setor       s,
                        prestador         p,
                        lancamento_hora   ll
                 WHERE to_char(ll.cd_fatura) = '24028'
                   AND s.cd_setor = l.cd_setor
                   AND p.cd_prestador = l.cd_prestador
                   AND l.cd_lancamento_hora = ll.cd_lancamento_hora
                   AND l.dt_fim IS NOT NULL
                   AND l.ds_observacao NOT LIKE '%Plant�o a Dist�ncia%'
                UNION ALL
                SELECT p.cd_prestador,
                        p.nm_prestador,
                        l.dt_inicio,
                        l.dt_fim,
                        (l.nr_horas) nr_horas,
                        l.vl_horas,
                        l.cd_tipo_hora,
                        s.nm_setor,
                        'DISPONIBILIDADE' hn,
                        l.cd_lancamento_hora,
                        ll.cd_fatura
                  FROM itlancamento_hora l,
                        dbamv.setor       s,
                        prestador         p,
                        lancamento_hora   ll
                 WHERE to_char(ll.cd_fatura) = '24028'
                   AND s.cd_setor = l.cd_setor
                   AND p.cd_prestador = l.cd_prestador
                   AND l.dt_fim IS NOT NULL
                   AND l.ds_observacao LIKE '%Plant�o a Dist�ncia%') x
        
         GROUP BY x.cd_prestador,
                  x.nm_prestador,
                  x.nm_setor,
                  x.tipo,
                  x.cd_fatura)

pivot(SUM(nr_horas)
   FOR tipo IN('DISPONIBILIDADE' disponibilidade,
               'FDS' fds,
               'SEMANA' semana,
               'NM_SETOR' setor))
 ORDER BY nm_prestador, nm_setor
