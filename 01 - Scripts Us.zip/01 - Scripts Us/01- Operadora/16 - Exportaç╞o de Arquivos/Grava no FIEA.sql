Declare

  v_Output_File1 Utl_File.File_Type;

Begin

  v_Output_File1 := Utl_File.Fopen('FIEA', 'teste25.txt', 'a');

  Utl_File .Put_Line(v_Output_File1, 'funcionou a geracao do arquivo!!');

  Utl_File.Fclose_All;

Exception
  When Utl_File.Invalid_Operation Then
    Dbms_Output.Put_Line('Opera��o inv�lida no arquivo.' || Sqlerrm);
    Utl_File.Fclose(v_Output_File1);
  
  When Utl_File.Write_Error Then
    Dbms_Output.Put_Line(' Erro de grava��o no arquivo. ' || Sqlerrm);
    Utl_File.Fclose(v_Output_File1);
  
  When Utl_File.Invalid_Path Then
    Dbms_Output.Put_Line('Diret�rio inv�lido. Erro: ' || Sqlerrm);
    Utl_File.Fclose(v_Output_File1);
  
  When Others Then
    Dbms_Output.Put_Line('Problemas na grava��o do arquivo. Erro: ' ||
                         Sqlerrm);
    Utl_File.Fclose(v_Output_File1);
  
End;

/


Select  *From all_directories
