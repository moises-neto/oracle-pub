-----------------------INICIO EXPORTA ARQUIVO CSV------------------------------------
Declare
  Vdelimitador Char(1);
  Vnomearquivo Varchar2(4000);
  Varquivo     Utl_File.File_Type;
  Vheader      Varchar2(4000);
  Vlinha       Varchar2(4000);

Select * From all_directories a
Where a.directory_name = 'DIR_EXPORTACAO_CUSTOM_PLANO'

Begin

  Vdelimitador := ';';
  Vnomearquivo := 'LEVANTAMENTO_CH2211-2018.CSV';
  Varquivo     := Utl_File.Fopen('DIR_EXPORTACAO_CUSTOM_PLANO',
                                 Vnomearquivo,
                                 'W',
                                 32767);
  Vheader      := 'UNIMED' || Vdelimitador || 'DT_COMPETENCIA' ||
                  Vdelimitador || 'CD_PRESTADOR' || Vdelimitador ||
                  'NM_PRESTADOR' || Vdelimitador || 'ESPECIALIDADE' ||
                  Vdelimitador || 'GUIA' || Vdelimitador || 'LOTE' ||
                  Vdelimitador || 'FATURA' || Vdelimitador || 'CARTEIRA' ||
                  Vdelimitador || 'NOME' || Vdelimitador || 'IDADE' ||
                  Vdelimitador || 'PLANO' || Vdelimitador || 'DR_REALIZADO' ||
                  Vdelimitador || 'COD_SERVICO' || Vdelimitador ||
                  'SERVICO' || Vdelimitador || 'QUANTIDADE' || Vdelimitador ||
                  'VALOR' || Vdelimitador || 'VALOR_REFER';

  Utl_File.Put_Line(Varquivo, Vheader);

  For r In (Select t.Unimed,
                   t.Dt_Competencia,
                   t.Cd_Prestador,
                   t.Nm_Prestador,
                   t.Ds_Especialidade,
                   t.Guia,
                   t.Cd_Lote,
                   t.Cd_Fatura,
                   t.Carteira,
                   t.Nome,
                   t.Idade,
                   t.Plano,
                   t.Dt_Realizado,
                   t.Cod_Servico,
                   t.Servico,
                   t.Qtde,
                   t.Valor,
                   t.Valor_Refer
              From Dbaps.Temp_Contas_Rede_Final t
             Order By 2, 6, 14
            
            ) Loop
  
    Vlinha := r.Unimed || Vdelimitador || r.Dt_Competencia || Vdelimitador ||
              r.Cd_Prestador || Vdelimitador || r.Nm_Prestador ||
              Vdelimitador || r.Ds_Especialidade || Vdelimitador || r.Guia ||
              Vdelimitador || r.Cd_Lote || Vdelimitador || r.Cd_Fatura ||
              Vdelimitador || r.Carteira || Vdelimitador || r.Nome ||
              Vdelimitador || r.Idade || Vdelimitador || r.Plano ||
              Vdelimitador || r.Dt_Realizado || Vdelimitador ||
              r.Cod_Servico || Vdelimitador || r.Servico || Vdelimitador ||
              r.Qtde || Vdelimitador || r.Valor || Vdelimitador ||
              r.Valor_Refer || Vdelimitador;
    Utl_File.Put_Line(Varquivo, Vlinha);
  
  End Loop;

  Utl_File.Fclose(Varquivo);
  Dbms_Output.Put_Line('Arquivo Gerado com Sucesso!');

Exception

  When Utl_File.Invalid_Operation Then
    Dbms_Output.Put_Line('Opera��o inv�lida no arquivo.' || Sqlerrm);
    Utl_File.Fclose(Varquivo);
  
  When Utl_File.Write_Error Then
    Dbms_Output.Put_Line(' Erro de grava��o no arquivo. ' || Sqlerrm);
    Utl_File.Fclose(Varquivo);
  
  When Utl_File.Invalid_Path Then
    Dbms_Output.Put_Line('Diret�rio inv�lido. Erro: ' || Sqlerrm);
    Utl_File.Fclose(Varquivo);
  
  When Others Then
    Dbms_Output.Put_Line('Problemas na grava��o do arquivo. Erro: ' ||
                         Sqlerrm);
    Utl_File.Fclose(Varquivo);
  
End;
------------------------FIM EXPORTA ARQUIVO CSV--------------------------------------
