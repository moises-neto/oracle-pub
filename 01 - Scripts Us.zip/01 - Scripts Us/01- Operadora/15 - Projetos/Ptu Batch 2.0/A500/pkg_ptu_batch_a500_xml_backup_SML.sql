CREATE OR REPLACE PACKAGE DBAPS.pkg_ptu_batch_a500_xml IS
    /**************************************************************
    <objeto>
      <nome>pkg_ptu_batch_a500_xml</nome>
      <usuario>Samuel Sales</usuario>
      <alteracao>29/03/2022 16:17</alteracao>
      <ultimaAlteracao>
          FDLA - 29/03/22 - Ajuste no prof Solicitante de Internacao (buscar da guia)
          FDLA - limite autorizacao a 10 digitos
          SMOS - 16/03/22 Ajuste nos cursores cGuiaConsulta, cGuiaSadt, cGuiaResInt, cGuiaHono, nos campos CD_UNIMED, ID_BENEF e CD_UNI_BENEF.
          SMOS - 16/03/22 Ajuste no cursor cAutorizacao no campo CD_UNI_AUTORIZA.
          FDLA - 14/03/22 Modificacao na rotina FNC_PTU_AGRUPA_ITEM_UNICO (adicionado qt_cobrado)
          AMES - 13/03/2022 Ajuste item ?nico e agrupamento em cServico e em cEquipe. (Allison Magno)
          Ajuste em internacao na prestador solicitante (Salomao)
          PLANO-15113 -Adicionar Quantidade Cobrada Interc?mbio
          FDLA - 27-02-22 Ajuste nas guias de intenracao (retornar guia I e P de Prorrogacao)
          FDLA - 25-02-22 Priorizado dt_inclusao ao invs de dt_envio_lote na dt_protocolo (problemas de data maior)
          FDLA - 19-02-22 AJUSTE NO TAMANHO DO NOME PROF SOLIC PARA NO MA 60 CARACTERES
      </ultimaAlteracao>
      <descricao>Package responsavel por gerar o ptu A500</descricao>
      <parametro></parametro>
      <versao>1.45</versao>
      <tags>PTU, A500</tags>
      <soul>PLANO-01-156</soul>
    </objeto>
  ***************************************************************/
  --
  FUNCTION FNC_RETORNA_PREST_A400(PCD_PRESTADOR IN VARCHAR2) RETURN VARCHAR2;
  FUNCTION FNC_RET_DADOS_REAPRESENTACAO(P_MENS_CONTRATO            IN VARCHAR2,
                                      P_CD_PTU_REMESSA_RETORNO   IN VARCHAR2,
                                      P_NR_DOCUMENTO_1           IN VARCHAR2,
                                      PCD_EXCECAO                IN VARCHAR2,
                                      PNR_NOTA                   IN VARCHAR2,
                                      PNR_LOTE                   IN VARCHAR2,
                                      PNR_LOTE_GLOSADO           IN VARCHAR2,
                                      PCD_CONTA_MEDICA_ORIGEM    IN VARCHAR2,
                                      PNR_DOC_GLOSADO            OUT VARCHAR2
                                      ) RETURN BOOLEAN;

  FUNCTION FNC_RET_CONTA_MEDICA_REF(P_NR_GUIA_TISS_OPERADORA       IN VARCHAR2,
                                  P_NR_GUIA_TEM                  IN VARCHAR2,
                                  P_TP_NOTA                      IN VARCHAR2,
                                  P_ID_NOTA_PRINCIPAL            IN VARCHAR2) RETURN NUMBER;

  FUNCTION FNC_DT_CONHECIMENTO_A520(P_ID_AVISO                     IN VARCHAR2,
                                  P_DT_CONHECIMENTO                IN DATE DEFAULT NULL,
                                  P_CD_PTU_REMESSA_RETORNO_A520    IN VARCHAR2) RETURN DATE;

  FUNCTION FNC_RETORNA_FATOR_INTERCAMBIO(PCD_PROC_PCT IN VARCHAR2, PCD_PROC_PCT_ITEM IN VARCHAR2) RETURN NUMBER;
  PROCEDURE PRC_INSERE_LOG_PTU(P_MENS_CONTRATO      IN NUMBER,
                             P_ERRO                IN VARCHAR2,
                             P_CD_PTU_REMESSA_RETORNO IN NUMBER DEFAULT NULL);
  PROCEDURE PRC_INSERE_AUTORIZACAO(P_MENS_CONTRATO         IN NUMBER,
                                 P_CD_LOTE               IN NUMBER,
                                 P_CD_CONTA_MEDICA       IN NUMBER,
                                 PCD_PTU_A500_SADT       IN NUMBER DEFAULT NULL,
                                 PCD_PTU_A500_INTERNACAO IN NUMBER DEFAULT NULL,
                                 PCD_PTU_A500_HONORARIO  IN NUMBER DEFAULT NULL,
                                 PCD_PTU_A500_CONSULTA   IN NUMBER DEFAULT NULL );
  FUNCTION FNC_RET_UF_TO_TISS(P_CD_UF IN VARCHAR2) RETURN VARCHAR2;
  FUNCTION FNC_RET_INSERE_PREST_EVENTUAL(P_CD_PREST                IN VARCHAR2,
                                       P_CD_UNI_PRE              IN VARCHAR2,
                                       P_CD_UNI_ORI_COD          IN VARCHAR2,
                                       P_TP_PESSOA               IN VARCHAR2,
                                       P_NR_CNPJ_CPF             IN VARCHAR2,
                                       P_NM_PREST                IN VARCHAR2,
                                       P_NM_PROF_PREST           IN VARCHAR2,
                                       P_TP_PREST_EXEC           IN VARCHAR2,
                                       P_ID_REC_PROPRIO          IN VARCHAR2,
                                       P_NR_CONS_PROF_PREST      IN VARCHAR2 DEFAULT NULL,
                                       P_SG_CONS_PROF_PREST      IN VARCHAR2 DEFAULT NULL,
                                       P_SG_UF_CONS_PREST        IN VARCHAR2 DEFAULT NULL) RETURN NUMBER;
  TYPE ROW_PTU_A500_CONS IS RECORD (
    CD_UNIMED                 DBAPS.V_CTAS_MEDICAS_FATURA.CD_UNIMED_ORIGEM%TYPE,
    ID_BENEF                  VARCHAR2(13),
    NM_BENEF                  DBAPS.V_CTAS_MEDICAS_FATURA.NM_BENEFICIARIO%TYPE,
    ID_RN                     DBAPS.V_CTAS_MEDICAS_FATURA.SN_ATENDIMENTO_RN%TYPE,
    TP_PACIENTE               VARCHAR2(1),
    CD_UNI_PRE                DBAPS.V_CTAS_MEDICAS_FATURA.CD_UNIMED_EXECUTORA%TYPE,
    CD_PREST                  DBAPS.V_CTAS_MEDICAS_FATURA.CD_PRESTADOR%TYPE,
    NM_PREST                  VARCHAR(100),
    CD_CPF                    VARCHAR(14),
    CD_CNPJ                   VARCHAR(14),
    CD_CNES_CONT_EXEC         VARCHAR2(10),
    CD_MUNIC_CONT_EXEC        NUMBER,
    TIPO_REDE_MIN             VARCHAR(1),
    TP_PREST_EXEC             DBAPS.TIP_PRESTADOR.CD_PTU_TIPO_PRESTADOR%TYPE,
    ID_REC_PROPRIO            VARCHAR(1),
    CD_PROF_UNI_PRE           DBAPS.V_CTAS_MEDICAS_FATURA.CD_UNIMED_EXECUTORA%TYPE,
    CD_PROF_PREST             DBAPS.V_CTAS_MEDICAS_FATURA.CD_PRESTADOR%TYPE,
    NM_PROF_PREST             DBAPS.PRESTADOR.NM_PRESTADOR%TYPE,
    SG_CONS_PROF_PREST        VARCHAR2(10),
    NR_CONS_PROF_PREST        DBAPS.PRESTADOR.DS_COD_CONSELHO%TYPE,
    SG_UF_CONS_PREST          DBAPS.PRESTADOR.UF_CONSELHO%TYPE,
    NR_CBO                    DBAPS.ESPECIALIDADE.NR_CBOS%TYPE,
    NR_VER_TISS               DBAPS.V_CTAS_MEDICAS_FATURA.CD_VERSAO_TISS%TYPE,
    TP_CONSULTA               DBAPS.V_CTAS_MEDICAS_FATURA.CD_TIPO_CONSULTA%TYPE,
    NR_LOTEPREST              DBAPS.V_CTAS_MEDICAS_FATURA.CD_LOTE%TYPE,
    DT_PROTOCOLO              DATE,
    DT_CONHECIMENTO           DATE,
    NR_GUIA_TISS_PRESTADOR    DBAPS.V_CTAS_MEDICAS_FATURA.CD_GUIA_EXTERNA%TYPE,
    NR_GUIA_TISS_OPERADORA    DBAPS.V_CTAS_MEDICAS_FATURA.CD_GUIA_EXTERNA%TYPE,
    TP_IND_ACIDENTE           DBAPS.INDICADOR_ACIDENTE.CD_PTU%TYPE,
    DT_ATEND                  DATE,
    ID_LIMINAR                DBAPS.V_CTAS_MEDICAS_FATURA.SN_LIMINAR%TYPE,
    ID_CONTINUADO             VARCHAR(1),
    ID_AVISO                  VARCHAR(1),
    CD_EXCECAO                VARCHAR(1),
    ID_GLOSATOTAL             VARCHAR(1),
    NR_AUTORIZ                VARCHAR(40),
    DT_AUTORIZ                DATE,
    DT_SOLICITACAO            DATE,
    CD_UNIAUTORIZADORA        DBAPS.V_CTAS_MEDICAS_FATURA.CD_UNIMED_ORIGEM%TYPE,
    TP_AUTORIZ                DBAPS.GUIA.TP_AUTORIZACAO_PTU%TYPE,
    TP_REGCPL                 VARCHAR(1),
    NM_DESCCOMPLEMENTO        VARCHAR(4000),
    SEQ_ITEM                  NUMBER,
    ID_ITEMUNICO              VARCHAR(200),
    ID_AVISO_ITEM             VARCHAR(1),
    TP_TABELA                 VARCHAR(2),
    CD_PROCEDIMENTO           DBAPS.V_CTAS_MEDICAS_FATURA.CD_PROCEDIMENTO%TYPE,
    VL_SERV_COB               DBAPS.V_CTAS_MEDICAS_FATURA.VL_TOTAL_COBRADO%TYPE,
    VL_ADIC_SER               DBAPS.V_CTAS_MEDICAS_FATURA.VL_TOTAL_TAXA_COBRADO_PTU%TYPE,
    CD_ATO                    VARCHAR(1),
    CD_CONTA_MEDICA_ORIGEM         DBAPS.V_CTAS_MEDICAS_FATURA.CD_CONTA_MEDICA_ORIGEM%TYPE,
    NR_LOTE_GLOSADO                DBAPS.V_CTAS_MEDICAS_FATURA.NR_LOTE_REFERENCIA%TYPE,
    NR_NOTA_GLOSADA                DBAPS.V_CTAS_MEDICAS_FATURA.NR_NOTA_REFERENCIA%TYPE,
    NR_DOC_1_GLOSADO               DBAPS.PTU_A500_CABECALHO.NR_DOCUMENTO_1%TYPE,
    NR_DOC_2_GLOSADO               DBAPS.PTU_A500_CABECALHO.NR_DOCUMENTO_2%TYPE,
    CD_MATRICULA                   DBAPS.V_CTAS_MEDICAS_FATURA.CD_MATRICULA%TYPE,
    NR_CARTEIRA_BENEFICIARIO       DBAPS.V_CTAS_MEDICAS_FATURA.NR_CARTEIRA_BENEFICIARIO%TYPE,
    CD_MULTI_EMPRESA               DBAPS.V_CTAS_MEDICAS_FATURA.CD_MULTI_EMPRESA%TYPE,
    CD_PTU_REMESSA_RETORNO_A520    DBAPS.V_CTAS_MEDICAS_FATURA.CD_PTU_REMESSA_RETORNO_A520%TYPE,
    CD_LANCAMENTO                  NUMBER

  );
  TYPE TABLE_PTU_A500_CONS IS TABLE OF ROW_PTU_A500_CONS;
  FUNCTION GET_TABLE_PTU_A500_CONS(PCD_MENS_CONTRATO          IN NUMBER
                                  ,P_ID_AVISO                 IN VARCHAR2
                                  ,P_CD_LOTE                  IN NUMBER
                                  ,P_CD_CONTA_MEDICA          IN NUMBER) RETURN TABLE_PTU_A500_CONS PIPELINED;
  TYPE ROW_PTU_A500_SADT IS RECORD (
    CD_FATURA                      NUMBER,
    NR_LOTE_PRESTADOR              DBAPS.V_CTAS_MEDICAS_FATURA.CD_LOTE%TYPE,
    NR_GUIA_TISS_PRESTADOR         DBAPS.V_CTAS_MEDICAS_FATURA.CD_CONTA_MEDICA%TYPE,
    NR_GUIA_TISS_OPERADORA         VARCHAR2(200),
    NR_GUIA_TISS_PRINCIPAL         VARCHAR2(200),
    CD_UNI_BENEF                   VARCHAR2(100),
    ID_BENEF                       VARCHAR2(100),
    NM_BENEF                       VARCHAR2(400),
    ID_RN                          DBAPS.V_CTAS_MEDICAS_FATURA.SN_ATENDIMENTO_RN%TYPE,
    TP_PACIENTE                    VARCHAR2(3),
    CD_EXCECAO                     VARCHAR2(3),
    TP_ATENDIMENTO                 VARCHAR2(3),
    DT_ATEND                       DATE,
    NR_VER_TISS                    DBAPS.V_CTAS_MEDICAS_FATURA.CD_VERSAO_TISS%TYPE,
    TP_IND_ACIDENTE                VARCHAR(1),
    DT_ULTIMA_AUTORIZ              DATE,
    TP_CONSULTA                    VARCHAR2(3),
    ID_LIMINAR                     VARCHAR2(1),
    DT_PROTOCOLO                   DATE,
    ID_AVISO                       VARCHAR2(1),
    ID_CONTINUADO                  VARCHAR2(1),
    DT_CONHECIMENTO                DATE,
    MOTIVO_ENCERRAM                VARCHAR2(10),
    ID_GUIA_PRINCIPAL              VARCHAR2(1),
    ID_GLOSA_TOTAL                 VARCHAR2(1),
    TP_CARATER_ATEND               VARCHAR2(1),
    /*Prestador Executante*/
    CD_UNI_CONT_EXEC               DBAPS.V_CTAS_MEDICAS_FATURA.CD_UNIMED_EXECUTORA%TYPE,
    CD_PREST_CONT_EXEC             VARCHAR2(100),
    NM_CONT_EXEC                   VARCHAR2(400),
    TP_PRESTADOR_CONT_EXEC         DBAPS.TIP_PRESTADOR.CD_PTU_TIPO_PRESTADOR%TYPE,
    ID_RECPROPRIO_CONT_EXEC        VARCHAR2(1),
    NR_CPF_CONT_EXEC               VARCHAR2(14),
    NR_CNPJ_CONT_EXEC              VARCHAR2(14),
    NR_CNES_CONT_EXEC              DBAPS.PRESTADOR.CD_CNES%TYPE,
    CD_MUNICIPIO_CONT_EXEC         NUMBER,
    TP_REDEMIN_CONT_EXEC           VARCHAR2(1),
    /*Prestador Solicitante*/
    NR_CPF_CONT_SOLICI             VARCHAR2(14),
    NR_CNPJ_CONT_SOLICI            VARCHAR2(14),
    CD_UNI_CONT_SOLICI             DBAPS.V_CTAS_MEDICAS_FATURA.CD_UNIMED_EXECUTORA%TYPE,
    CD_PREST_CONT_SOLICI           VARCHAR2(100),
    NM_CONT_SOLICI                 VARCHAR2(400),
    NM_PROF_SOLICI                 VARCHAR2(400),
    CD_CONSELHO_PROF_SOLICI        VARCHAR2(10),
    NR_CONSELHO_PROF_SOLICI        DBAPS.V_CTAS_MEDICAS_FATURA.NR_CONSELHO_PROF_SOLIC%TYPE,
    CD_UF_PROF_SOLICI              DBAPS.V_CTAS_MEDICAS_FATURA.CD_UF_CONSELHO_PROF_SOLIC%TYPE,
    NR_CBO_PROF_SOLICI             DBAPS.V_CTAS_MEDICAS_FATURA.CD_CBOS_PROF_SOLIC%TYPE,
    CD_CONTA_MEDICA_ORIGEM         DBAPS.V_CTAS_MEDICAS_FATURA.CD_CONTA_MEDICA_ORIGEM%TYPE,
    NR_LOTE_GLOSADO                DBAPS.V_CTAS_MEDICAS_FATURA.NR_LOTE_REFERENCIA%TYPE,
    NR_NOTA_GLOSADA                DBAPS.V_CTAS_MEDICAS_FATURA.NR_NOTA_REFERENCIA%TYPE,
    NR_DOC_1_GLOSADO               DBAPS.PTU_A500_CABECALHO.NR_DOCUMENTO_1%TYPE,
    NR_DOC_2_GLOSADO               DBAPS.PTU_A500_CABECALHO.NR_DOCUMENTO_2%TYPE,
    CD_MATRICULA                   DBAPS.V_CTAS_MEDICAS_FATURA.CD_MATRICULA%TYPE,
    NR_CARTEIRA_BENEFICIARIO       DBAPS.V_CTAS_MEDICAS_FATURA.NR_CARTEIRA_BENEFICIARIO%TYPE,
    CD_MULTI_EMPRESA               DBAPS.V_CTAS_MEDICAS_FATURA.CD_MULTI_EMPRESA%TYPE,
    CD_PTU_REMESSA_RETORNO_A520    DBAPS.V_CTAS_MEDICAS_FATURA.CD_PTU_REMESSA_RETORNO_A520%TYPE
  );
  TYPE TABLE_PTU_A500_SADT IS TABLE OF ROW_PTU_A500_SADT;
  FUNCTION GET_TABLE_PTU_A500_SADT(PCD_MENS_CONTRATO          IN NUMBER DEFAULT NULL
                                  ,P_ID_AVISO                 IN VARCHAR2
                                  ,P_CD_LOTE                  IN NUMBER
                                  ,P_CD_CONTA_MEDICA          IN NUMBER) RETURN TABLE_PTU_A500_SADT PIPELINED;

  TYPE ROW_PTU_A500_RES_INT IS RECORD (
    CD_UNI_BENEF                      VARCHAR2(100),
    ID_BENEF                          VARCHAR2(100),
    NM_BENEF                          VARCHAR2(400),
    ID_RN                             VARCHAR2(1),
    TP_PACIENTE                       VARCHAR2(3),
    NR_CPF_CONT_SOLICI                VARCHAR2(14),
    NR_CNPJ_CONT_SOLICI               VARCHAR2(14),
    CD_UNI_CONT_SOLICI                DBAPS.V_CTAS_MEDICAS_FATURA.CD_UNIMED_EXECUTORA%TYPE,
    CD_PREST_CONT_SOLICI              VARCHAR2(100),
    NM_CONT_SOLICI                    VARCHAR2(400),
    NM_PROF_SOLICI                    VARCHAR2(400),
    CD_CONSELHO_PROF_SOLICI           VARCHAR2(10),
    NR_CONSELHO_PROF_SOLICI           DBAPS.V_CTAS_MEDICAS_FATURA.NR_CONSELHO_PROF_SOLIC%TYPE,
    CD_UF_PROF_SOLICI                 DBAPS.V_CTAS_MEDICAS_FATURA.CD_UF_CONSELHO_PROF_SOLIC%TYPE,
    NR_CBO_PROF_SOLICI                DBAPS.V_CTAS_MEDICAS_FATURA.CD_CBOS_PROF_SOLIC%TYPE,
    CD_UNI_CONT_EXEC                  DBAPS.V_CTAS_MEDICAS_FATURA.CD_UNIMED_EXECUTORA%TYPE,
    CD_PREST_CONT_EXEC                VARCHAR2(100),
    NM_CONT_EXEC                      VARCHAR2(400),
    TP_PRESTADOR_CONT_EXEC            DBAPS.TIP_PRESTADOR.CD_PTU_TIPO_PRESTADOR%TYPE,
    ID_RECPROPRIO_CONT_EXEC           VARCHAR2(1),
    NR_CNPJ_CONT_EXEC                 VARCHAR2(14),
    NR_CNES_CONT_EXEC                 DBAPS.PRESTADOR.CD_CNES%TYPE,
    CD_MUNICIPIO_CONT_EXEC            NUMBER,
    TP_REDEMIN_CONT_EXEC              VARCHAR2(1),
    TP_ACOMODACAO                     VARCHAR2(3),
    FT_MULT_AMB                       VARCHAR2(10),
    TP_INTERNACAO                     VARCHAR2(1),
    REG_INTERNACAO                    VARCHAR2(1),
    TP_CARATER_ATEND                  VARCHAR2(1),
    TP_FATURAMENTO                    VARCHAR2(1),
    DT_INI_FATURAMENTO                DATE,
    DT_FIM_FATURAMENTO                DATE,
    TP_IND_ACIDENTE                   VARCHAR2(1),
    MOTIVO_ENCERRAM                   VARCHAR2(10),
    CD_CID                            VARCHAR2(10),
    NM_MEDICO_AUDITOR                 VARCHAR2(400),
    NR_CRM_AUDITOR                    VARCHAR2(50),
    CD_UF_CRM                         VARCHAR2(10),
    NM_ENFER_AUDITOR                  VARCHAR2(400),
    NR_COREN_AUDITOR                  VARCHAR2(50),
    CD_UF_COREN                       VARCHAR2(10),
    NR_VER_TISS                       DBAPS.V_CTAS_MEDICAS_FATURA.CD_VERSAO_TISS%TYPE,
    NR_LOTE_PRESTADOR                 DBAPS.V_CTAS_MEDICAS_FATURA.CD_LOTE%TYPE,
    DT_PROTOCOLO                      DATE,
    DT_CONHECIMENTO                   DATE,
    NR_GUIA_TISS_PRESTADOR            DBAPS.V_CTAS_MEDICAS_FATURA.CD_CONTA_MEDICA%TYPE,
    NR_GUIA_TISS_OPERADORA            VARCHAR2(50),
    NR_GUIA_TISS_PRINCIPAL            VARCHAR2(50),
    DT_ATEND                          DATE,
    ID_LIMINAR                        VARCHAR2(1),
    ID_CONTINUADO                     VARCHAR2(1),
    ID_AVISO                          VARCHAR2(1),
    CD_EXCECAO                        VARCHAR2(1),
    ID_GLOSA_TOTAL                    VARCHAR2(1),
    DT_ULTIMA_AUTORIZ                 DATE,
    CD_CONTA_MEDICA_ORIGEM         DBAPS.V_CTAS_MEDICAS_FATURA.CD_CONTA_MEDICA_ORIGEM%TYPE,
    NR_LOTE_GLOSADO                DBAPS.V_CTAS_MEDICAS_FATURA.NR_LOTE_REFERENCIA%TYPE,
    NR_NOTA_GLOSADA                DBAPS.V_CTAS_MEDICAS_FATURA.NR_NOTA_REFERENCIA%TYPE,
    NR_DOC_1_GLOSADO               DBAPS.PTU_A500_CABECALHO.NR_DOCUMENTO_1%TYPE,
    NR_DOC_2_GLOSADO               DBAPS.PTU_A500_CABECALHO.NR_DOCUMENTO_2%TYPE,
    CD_MATRICULA                   DBAPS.V_CTAS_MEDICAS_FATURA.CD_MATRICULA%TYPE,
    NR_CARTEIRA_BENEFICIARIO       DBAPS.V_CTAS_MEDICAS_FATURA.NR_CARTEIRA_BENEFICIARIO%TYPE,
    CD_MULTI_EMPRESA               DBAPS.V_CTAS_MEDICAS_FATURA.CD_MULTI_EMPRESA%TYPE,
    CD_PTU_REMESSA_RETORNO_A520    DBAPS.V_CTAS_MEDICAS_FATURA.CD_PTU_REMESSA_RETORNO_A520%TYPE
  );
  TYPE TABLE_PTU_A500_RES_INT IS TABLE OF ROW_PTU_A500_RES_INT;
  FUNCTION GET_TABLE_PTU_A500_RES_INT(PCD_MENS_CONTRATO           IN NUMBER
                                      ,P_ID_AVISO                 IN VARCHAR2
                                      ,P_CD_LOTE                  IN NUMBER
                                      ,P_CD_CONTA_MEDICA          IN NUMBER) RETURN TABLE_PTU_A500_RES_INT PIPELINED;

  TYPE ROW_PTU_A500_HONO IS RECORD (
    CD_UNI_BENEF                   VARCHAR2(100),
    ID_BENEF                       VARCHAR2(100),
    NM_BENEF                       VARCHAR2(400),
    ID_RN                          VARCHAR2(1),
    TP_PACIENTE                    VARCHAR2(3),
    CD_UNI_CONT_HOSP               DBAPS.V_CTAS_MEDICAS_FATURA.CD_UNIMED_EXECUTORA%TYPE,
    CD_PREST_CONT_HOSP             VARCHAR2(100),
    NM_CONT_HOSP                   VARCHAR2(400),
    NR_CNPJ_CONT_HOSP              VARCHAR2(14),
    NR_CNES_CONT_HOSP              VARCHAR2(10),
    CD_UNI_CONT_EXEC               DBAPS.V_CTAS_MEDICAS_FATURA.CD_UNIMED_EXECUTORA%TYPE,
    CD_PREST_CONT_EXEC             VARCHAR2(100),
    NM_CONT_EXEC                   VARCHAR2(400),
    NR_CPF_CONT_EXEC               VARCHAR2(14),
    NR_CNPJ_CONT_EXEC              VARCHAR2(14),
    NR_CNES_CONT_EXEC              VARCHAR2(10),
    TP_PRESTADOR_CONT_EXEC         VARCHAR2(10),
    CD_MUNICIPIO_CONT_EXEC         NUMBER,
    ID_RECPROPRIO_CONT_EXEC        VARCHAR2(1),
    TP_REDEMIN_CONT_EXEC           VARCHAR2(10),
    DT_INI_FATURAMENTO             DATE,
    DT_FIM_FATURAMENTO             DATE,
    NR_VER_TISS                    VARCHAR2(20),
    NR_LOTE_PRESTADOR              VARCHAR2(50),
    DT_PROTOCOLO                   DATE,
    DT_CONHECIMENTO                DATE,
    NR_GUIA_TISS_PRESTADOR         VARCHAR2(50),
    NR_GUIA_TISS_OPERADORA         VARCHAR2(50),
    NR_GUIA_TISS_PRINCIPAL         VARCHAR2(50),
    DT_ATEND                       DATE,
    ID_LIMINAR                     VARCHAR2(1),
    ID_CONTINUADO                  VARCHAR2(1),
    ID_AVISO                       VARCHAR2(1),
    CD_EXCECAO                     VARCHAR2(1),
    ID_GLOSA_TOTAL                 VARCHAR2(1),
    DT_ULTIMA_AUTORIZ              DATE,
    CD_CONTA_MEDICA_ORIGEM         DBAPS.V_CTAS_MEDICAS_FATURA.CD_CONTA_MEDICA_ORIGEM%TYPE,
    NR_LOTE_GLOSADO                DBAPS.V_CTAS_MEDICAS_FATURA.NR_LOTE_REFERENCIA%TYPE,
    NR_NOTA_GLOSADA                DBAPS.V_CTAS_MEDICAS_FATURA.NR_NOTA_REFERENCIA%TYPE,
    NR_DOC_1_GLOSADO               DBAPS.PTU_A500_CABECALHO.NR_DOCUMENTO_1%TYPE,
    NR_DOC_2_GLOSADO               DBAPS.PTU_A500_CABECALHO.NR_DOCUMENTO_2%TYPE,
    CD_MATRICULA                   DBAPS.V_CTAS_MEDICAS_FATURA.CD_MATRICULA%TYPE,
    NR_CARTEIRA_BENEFICIARIO       DBAPS.V_CTAS_MEDICAS_FATURA.NR_CARTEIRA_BENEFICIARIO%TYPE,
    CD_MULTI_EMPRESA               DBAPS.V_CTAS_MEDICAS_FATURA.CD_MULTI_EMPRESA%TYPE,
    CD_PTU_REMESSA_RETORNO_A520    DBAPS.V_CTAS_MEDICAS_FATURA.CD_PTU_REMESSA_RETORNO_A520%TYPE
  );
  TYPE TABLE_PTU_A500_HONO IS TABLE OF ROW_PTU_A500_HONO;
  FUNCTION GET_TABLE_PTU_A500_HONO(PCD_MENS_CONTRATO           IN NUMBER
                                  ,P_ID_AVISO                 IN VARCHAR2
                                  ,P_CD_LOTE                  IN NUMBER
                                  ,P_CD_CONTA_MEDICA          IN NUMBER) RETURN TABLE_PTU_A500_HONO PIPELINED;

  TYPE ROW_PTU_A500_COMPL IS RECORD (
    TP_REG_CPL VARCHAR2(1),
    NM_DESC_CPL VARCHAR2(100)
  );
  TYPE TABLE_PTU_A500_COMPL IS TABLE OF ROW_PTU_A500_COMPL;
  FUNCTION GET_TABLE_PTU_A500_COMPL(PCD_MENS_CONTRATO IN NUMBER, PCD_LOTE IN NUMBER, PCD_CONTA_MEDICA IN NUMBER) RETURN TABLE_PTU_A500_COMPL PIPELINED;

  TYPE ROW_PTU_A500_DECL IS RECORD (
       DS_DECLARACAO_NASCIDO                          DBAPS.CONTA_HOSPITALAR_DECLARACAO.DS_DECLARACAO_NASCIDO%TYPE,
       DS_DIAGNOSTICO_OBITO                           DBAPS.CONTA_HOSPITALAR_DECLARACAO.DS_DIAGNOSTICO_OBITO%TYPE,
       DS_DECLARACAO_OBITO                            DBAPS.CONTA_HOSPITALAR_DECLARACAO.DS_DECLARACAO_OBITO%TYPE,
       SN_INDICADOR_DORN                              DBAPS.CONTA_HOSPITALAR_DECLARACAO.SN_INDICADOR_DORN%TYPE
  );
  TYPE TABLE_PTU_A500_DECL IS TABLE OF ROW_PTU_A500_DECL;
  FUNCTION GET_TABLE_PTU_A500_DECL(PCD_CONTA_MEDICA IN NUMBER) RETURN TABLE_PTU_A500_DECL PIPELINED;

  TYPE ROW_PTU_A500_PROC IS RECORD (
    DT_EXECUCAO                    DATE,
    HR_INICIAL                     VARCHAR2(80),
    HR_FINAL                       VARCHAR2(80),
    SEQ_ITEM                       NUMBER,
    ID_ITEMUNICO                   VARCHAR(50),
    TP_TABELA                      VARCHAR(2),
    CD_SERVICO                     DBAPS.V_CTAS_MEDICAS_FATURA.CD_PROCEDIMENTO%TYPE,
    DS_SERVICO                     DBAPS.V_CTAS_MEDICAS_FATURA.DS_PROCEDIMENTO%TYPE,
    QT_COBRADA                     NUMBER,
    CD_VIA_ACESSO                  DBAPS.V_CTAS_MEDICAS_FATURA.CD_VIA_ACESSO%TYPE,
    TEC_UTILIZADA                  NUMBER,
    FAT_MULT_SERV                  NUMBER,
    ID_ACRESCIMO                   VARCHAR2(1),
    VL_SERV_COB                    DBAPS.V_CTAS_MEDICAS_FATURA.VL_TOTAL_COBRADO%TYPE,
    VL_ADIC_SER                    DBAPS.V_CTAS_MEDICAS_FATURA.VL_TOTAL_TAXA_COBRADO_PTU%TYPE,
    VL_FILME_COB                   DBAPS.V_CTAS_MEDICAS_FATURA.VL_TOTAL_COBRADO%TYPE,
    VL_ADIC_FILME                  DBAPS.V_CTAS_MEDICAS_FATURA.VL_TOTAL_TAXA_COBRADO_PTU%TYPE,
    VL_CO_COB                      DBAPS.V_CTAS_MEDICAS_FATURA.VL_TOTAL_COBRADO%TYPE,
    VL_ADIC_CO                     DBAPS.V_CTAS_MEDICAS_FATURA.VL_TOTAL_TAXA_COBRADO_PTU%TYPE,
    UN_MEDIDA                      DBAPS.MVS_UNIDADE_MEDIDA.CD_PTU%TYPE,
    ID_AVISO_ITEM                  VARCHAR2(1),
    ID_PACOTE                      DBAPS.V_CTAS_MEDICAS_FATURA.SN_PACOTE_MANUAL%TYPE,
    CD_PACOTE                      DBAPS.V_CTAS_MEDICAS_FATURA.CD_PROCEDIMENTO%TYPE,
    CD_PORTE_ANE                   DBAPS.POR_ANE.DS_PORTE_ANESTESICO%TYPE,
    NR_CPF_CNPJ_FORNECEDOR         DBAPS.PRESTADOR.NR_CPF_CGC%TYPE,
    NM_FORNECEDOR                  DBAPS.PRESTADOR.NM_PRESTADOR%TYPE,
    NR_NOTA_FISCAL_FORN            NUMBER,
    CD_REF_MATERIAL_FAB            DBAPS.V_CTAS_MEDICAS_FATURA.CD_REF_MATERIAL%TYPE,
    DET_REG_ANVISA                 VARCHAR2(50),
    NR_REG_ANVISA                  DBAPS.V_CTAS_MEDICAS_FATURA.NR_REGISTRO_ANVISA%TYPE,
    CD_ATO                         VARCHAR2(1),
    DT_SOLICITACAO                 DBAPS.V_CTAS_MEDICAS_FATURA.DT_REALIZADO%TYPE,
    CD_UNI_AUTORIZA                VARCHAR2(3),
    NR_AUTORIZ                     VARCHAR2(10),
    DT_AUTORIZ                     DBAPS.V_CTAS_MEDICAS_FATURA.DT_REALIZADO%TYPE,
    TP_AUTORIZ                     DBAPS.GUIA.TP_AUTORIZACAO_PTU%TYPE,
    TP_FATURAMENTO                 VARCHAR2(4),
    TIPO_PROCEDIMENTO              VARCHAR2(2)
  );
  TYPE TABLE_PTU_A500_PROC IS TABLE OF ROW_PTU_A500_PROC;
  FUNCTION GET_TABLE_PTU_A500_PROC(PCD_MENS_CONTRATO IN NUMBER, PCD_LOTE IN NUMBER, PCD_CONTA_MEDICA IN NUMBER) RETURN TABLE_PTU_A500_PROC PIPELINED;

   TYPE ROW_PTU_A500_EQP IS RECORD (
    TP_PARTICIPACAO      VARCHAR(2),
    CD_UNI_PREST         VARCHAR(4),
    CD_PREST             VARCHAR(50),
    NM_PROFISSIONAL      VARCHAR(200),
    CD_CPF               VARCHAR(14),
    SG_CONSELHO          VARCHAR(20),
    NR_CONSELHO          VARCHAR(20),
    UF                   VARCHAR(2),
    CBO                  VARCHAR(10),
    CD_PROCEDIMENTO      VARCHAR(10)
  );
  TYPE TABLE_PTU_A500_EQP IS TABLE OF ROW_PTU_A500_EQP;
  FUNCTION GET_TABLE_PTU_A500_PROC_EQP(PCD_MENS_CONTRATO IN NUMBER, PCD_LOTE IN NUMBER, PCD_CONTA_MEDICA IN NUMBER, PID_ITEM_UNICO IN VARCHAR2,PTP_GUIA IN VARCHAR2) RETURN TABLE_PTU_A500_EQP PIPELINED;
  FUNCTION GET_TABLE_PTU_A500_PROC_EQP2(PCD_MENS_CONTRATO IN NUMBER, PCD_LOTE IN NUMBER, PCD_CONTA_MEDICA IN NUMBER, PID_ITEM_UNICO IN VARCHAR2,PTP_GUIA IN VARCHAR2) RETURN TABLE_PTU_A500_EQP PIPELINED;
END PKG_PTU_BATCH_A500_XML;
/
CREATE OR REPLACE PACKAGE BODY DBAPS.pkg_ptu_batch_a500_xml IS

FUNCTION FNC_RETORNA_FATOR_INTERCAMBIO(PCD_PROC_PCT          IN VARCHAR2,
                                                         PCD_PROC_PCT_ITEM IN VARCHAR2) RETURN NUMBER IS
    nRet NUMBER;
BEGIN
  SELECT T.NR_FATOR_INT
  INTO nRet
  FROM DBAPS.PACOTE T
       WHERE T.CD_PROCEDIMENTO = PCD_PROC_PCT
       AND T.CD_ITEM_PROCEDIMENTO = PCD_PROC_PCT_ITEM;

  RETURN nRet;
END;

FUNCTION FNC_RETORNA_PREST_A400(PCD_PRESTADOR IN VARCHAR2) RETURN VARCHAR2 IS
  nRet VARCHAR2(4000);
BEGIN

  BEGIN

    SELECT Nvl(To_Char(P.NR_CODIGO_PREST_A400),
               CASE
                 WHEN PTP.CD_PTU_TIPO_PRESTADOR IN ('01', '05', '03') THEN
                  REGEXP_REPLACE(P.DS_COD_CONSELHO, '[^[:digit:]]+')
                 ELSE
                  TO_CHAR(P.CD_PRESTADOR)
               END) CD_PREST
      INTO nRet
      FROM DBAPS.PRESTADOR          P,
           DBAPS.TIP_PRESTADOR      TPP,
           DBAPS.PTU_TIPO_PRESTADOR PTP
     WHERE P.CD_PRESTADOR = PCD_PRESTADOR
       AND P.CD_TIP_PRESTADOR = TPP.CD_TIP_PRESTADOR
       AND TPP.CD_PTU_TIPO_PRESTADOR = PTP.CD_PTU_TIPO_PRESTADOR (+)
       AND P.SN_ENVIA_A400 = 'S';

  EXCEPTION
    WHEN OTHERS THEN
      nRet := NULL;
  END;

  RETURN nRet;
END;

FUNCTION FNC_RET_DADOS_REAPRESENTACAO(P_MENS_CONTRATO            IN VARCHAR2,
                                      P_CD_PTU_REMESSA_RETORNO   IN VARCHAR2,
                                      P_NR_DOCUMENTO_1           IN VARCHAR2,
                                      PCD_EXCECAO                IN VARCHAR2,
                                      PNR_NOTA                   IN VARCHAR2,
                                      PNR_LOTE                   IN VARCHAR2,
                                      PNR_LOTE_GLOSADO           IN VARCHAR2,
                                      PCD_CONTA_MEDICA_ORIGEM    IN VARCHAR2,
                                      PNR_DOC_GLOSADO            OUT VARCHAR2
                                      ) RETURN BOOLEAN IS

  CURSOR cRefaturamento(PCD_LOTE_REFERENCIA NUMBER, PCD_CONTA_MEDICA_ORIGEM NUMBER) IS
    SELECT DISTINCT Nvl(NF.NR_NOTA_FISCAL_ELETRONICA, VCMF.CD_MENS_CONTRATO) NR_DOC_1_GLOSADO, VCMF.CD_MENS_CONTRATO
      FROM DBAPS.V_CTAS_MEDICAS_FATURA VCMF,
            DBAPS.MENS_CONTRATO MC,
            DBAPS.NOTA_FISCAL_MVS NF
     WHERE VCMF.CD_LOTE = PCD_LOTE_REFERENCIA
       AND VCMF.CD_CONTA_MEDICA = PCD_CONTA_MEDICA_ORIGEM
       AND VCMF.CD_MENS_CONTRATO = MC.CD_MENS_CONTRATO (+)
       AND MC.CD_NOTA_FISCAL = NF.CD_NOTA_FISCAL (+);

  nRet                  BOOLEAN := FALSE;
  nrDoc1Glosado         VARCHAR(30);
  cdMensContratoGlosado VARCHAR(30);
BEGIN

    -- REFATURAMENTO
    --Quando for nota de refaturamento enviar lote e conta medica da origem
    nrDoc1Glosado := NULL;

    IF PCD_EXCECAO = 'J' THEN
      OPEN cRefaturamento(PNR_LOTE_GLOSADO, PCD_CONTA_MEDICA_ORIGEM);
      FETCH cRefaturamento INTO nrDoc1Glosado, cdMensContratoGlosado;
      CLOSE cRefaturamento;

      INSERT INTO DBAPS.NOTAS_REFATURADAS_GERACAO_A500 (
        NR_NOTA,
        NR_LOTE,
        NR_NOTA_ORIGEM,
        NR_LOTE_ORIGEM,
        NR_DOCUMENTO_1,
        NR_DOCUMENTO_1_ORIGEM,
        CD_MENS_CONTRATO,
        CD_MENS_CONTRATO_ORIGEM,
        CD_PTU_REMESSA_RETORNO
      ) VALUES (
        PNR_NOTA,
        PNR_LOTE,
        PCD_CONTA_MEDICA_ORIGEM,
        PNR_LOTE_GLOSADO,
        P_NR_DOCUMENTO_1,
        nrDoc1Glosado,
        P_MENS_CONTRATO,
        cdMensContratoGlosado,
        P_CD_PTU_REMESSA_RETORNO
      );

      nRet := TRUE;

      PNR_DOC_GLOSADO := nrDoc1Glosado;

    END IF;

  RETURN nRet;
END;

FUNCTION FNC_RET_CONTA_MEDICA_REF(P_NR_GUIA_TISS_OPERADORA       IN VARCHAR2,
                                  P_NR_GUIA_TEM                  IN VARCHAR2,
                                  P_TP_NOTA                      IN VARCHAR2,
                                  P_ID_NOTA_PRINCIPAL            IN VARCHAR2) RETURN NUMBER IS

 CURSOR cContaMedicaReferenciaG(PNR_GUIA_TEM VARCHAR2) IS
    SELECT DISTINCT VCM.CD_CONTA_MEDICA
      FROM DBAPS.V_CTAS_MEDICAS VCM
     WHERE NR_GUIA = PNR_GUIA_TEM
       AND VCM.NR_GUIA_TEM IS NULL;

  CURSOR cContaMedicaReferenciaGE(PNR_GUIA_TEM VARCHAR2) IS
    SELECT DISTINCT VCM.CD_CONTA_MEDICA
      FROM DBAPS.V_CTAS_MEDICAS VCM
     WHERE CD_GUIA_EXTERNA = PNR_GUIA_TEM
       AND VCM.NR_GUIA_TEM IS NULL;

  CURSOR cContaMedicaReferenciaGP(PNR_GUIA_TEM VARCHAR2) IS
    SELECT DISTINCT VCM.CD_CONTA_MEDICA
      FROM DBAPS.V_CTAS_MEDICAS VCM
     WHERE NR_GUIA_PRESTADOR = PNR_GUIA_TEM
       AND VCM.NR_GUIA_TEM IS NULL;

  CURSOR cPtuMensagemDestinoReferencia(PNR_GUIA_TEM VARCHAR2) IS
    SELECT DISTINCT G.CD_PTU_MENSAGEM_DESTINO
      FROM DBAPS.GUIA G
     WHERE NR_GUIA = PNR_GUIA_TEM
       AND G.NR_GUIA_TEM IS NULL;

  nCdContaMedicaReferencia NUMBER := NULL;
BEGIN

    -- RECUPERA O NUMERO DA CONTA MEDICA REFERENCIA
    IF ((Nvl(P_NR_GUIA_TISS_OPERADORA, '0') <> Nvl(To_Char(P_NR_GUIA_TEM), '0')) OR (P_TP_NOTA = 'H')) AND
       (P_NR_GUIA_TEM IS NOT NULL AND P_NR_GUIA_TEM <> '0') AND
       (P_ID_NOTA_PRINCIPAL = 'N') /*AND (rNotaCobranca.CD_EXCECAO <> 'J')*/ THEN

      OPEN cContaMedicaReferenciaG(P_NR_GUIA_TEM);
      FETCH cContaMedicaReferenciaG INTO nCdContaMedicaReferencia;
      CLOSE cContaMedicaReferenciaG;

      IF (nCdContaMedicaReferencia IS NULL) THEN
        OPEN cContaMedicaReferenciaGE(P_NR_GUIA_TEM);
        FETCH cContaMedicaReferenciaGE INTO nCdContaMedicaReferencia;
        CLOSE cContaMedicaReferenciaGE;
      END IF;

      IF (nCdContaMedicaReferencia IS NULL) THEN
        OPEN cContaMedicaReferenciaGP(P_NR_GUIA_TEM);
        FETCH cContaMedicaReferenciaGP INTO nCdContaMedicaReferencia;
        CLOSE cContaMedicaReferenciaGP;
      END IF;

      IF (nCdContaMedicaReferencia IS NULL) THEN
        OPEN cPtuMensagemDestinoReferencia(P_NR_GUIA_TEM);
        FETCH cPtuMensagemDestinoReferencia INTO nCdContaMedicaReferencia;
        CLOSE cPtuMensagemDestinoReferencia;
      END IF;
    END IF;

  RETURN nCdContaMedicaReferencia;
END;

FUNCTION FNC_DT_CONHECIMENTO_A520(P_ID_AVISO                       IN VARCHAR2,
                                  P_DT_CONHECIMENTO                IN DATE DEFAULT NULL,
                                  P_CD_PTU_REMESSA_RETORNO_A520    IN VARCHAR2) RETURN DATE IS

  CURSOR cDadosPtuA520(P_CD_PTU_REMESSA_RETORNO_A520 IN NUMBER) IS
    SELECT To_Date(PM.DT_TRANSACAO, 'YYYY-MM-DD') DT_TRANSACAO
      FROM DBAPS.PTU_REMESSA_RETORNO PRR,
           DBAPS.TISS_MENSAGEM PM
     WHERE PRR.CD_PTU_REMESSA_RETORNO = P_CD_PTU_REMESSA_RETORNO_A520
       AND PRR.CD_TISS_MENSAGEM = PM.ID;

  dDataConhecimento DATE;
BEGIN

  dDataConhecimento := P_DT_CONHECIMENTO;

    IF (P_ID_AVISO = 'S' AND P_DT_CONHECIMENTO IS NULL) THEN
      OPEN cDadosPtuA520(P_CD_PTU_REMESSA_RETORNO_A520);
      FETCH cDadosPtuA520 INTO dDataConhecimento;
      CLOSE cDadosPtuA520;
    END IF;

  RETURN dDataConhecimento;
END;

PROCEDURE PRC_INSERE_LOG_PTU(P_MENS_CONTRATO      IN NUMBER,
                             P_ERRO                IN VARCHAR2,
                             P_CD_PTU_REMESSA_RETORNO IN NUMBER DEFAULT NULL) IS

  PRAGMA AUTONOMOUS_TRANSACTION;
BEGIN
  INSERT INTO DBAPS.LOG_PTU_GERACAO_A500_ERRO
  VALUES
    (DBAPS.SEQ_LOG_PTU_GERACAO_A500_ERRO.NEXTVAL,
     P_MENS_CONTRATO,
     SYSDATE,
     P_ERRO,
     P_CD_PTU_REMESSA_RETORNO);
  COMMIT;
END;

PROCEDURE PRC_INSERE_AUTORIZACAO(P_MENS_CONTRATO         IN NUMBER,
                                 P_CD_LOTE               IN NUMBER,
                                 P_CD_CONTA_MEDICA       IN NUMBER,
                                 PCD_PTU_A500_SADT       IN NUMBER DEFAULT NULL,
                                 PCD_PTU_A500_INTERNACAO IN NUMBER DEFAULT NULL,
                                 PCD_PTU_A500_HONORARIO  IN NUMBER DEFAULT NULL,
                                 PCD_PTU_A500_CONSULTA   IN NUMBER DEFAULT NULL ) IS

  CURSOR cAutorizacao IS
    SELECT  Trunc(Nvl(Nvl(PM.DT_TRANSACAO, G.DT_EMISSAO),VCMF.DT_REALIZADO)) DT_SOLICITACAO,
            Decode(VCMF.TP_BENEFICIARIO, 'RE', '999', NVL(G.CD_UNIMED_ORIGEM, VCMF.CD_UNIMED_ORIGEM)) CD_UNI_AUTORIZA,
            CASE
              WHEN VCMF.NR_SENHA_GAT IS NOT NULL AND
                   LENGTH(REGEXP_REPLACE(VCMF.NR_SENHA_GAT,'[^[:digit:]]+')) <= 10 THEN
               REGEXP_REPLACE(VCMF.NR_SENHA_GAT,'[^[:digit:]]+')
              When g.cd_ptu_mensagem_decurso_prazo Is Not Null Then
                to_char(g.Cd_Ptu_Mensagem_Destino)  --Mois�s (29/04/2022) --> Alterado a pedido da Daiana, seguindo manual do PTU. ALTERADO NOVAMENTE CH2209-2051 
               
              WHEN (DECODE(VCMF.NR_GUIA, NULL, '0', 'L') = 'L') OR
                   (TA.TP_GUIA = 'H' AND VCMF.NR_GUIA_TEM IS NOT NULL) OR
                   (G_TEM.SN_VALIDA_REST_CARENCIA = 'S') THEN
               NVL(TO_CHAR(Nvl(NVL(G.NR_SENHA_AVULSA,
                                   G.CD_PTU_MENSAGEM_DESTINO),
                               Decode(G_TEM.NR_GUIA_TEM,
                                      NULL,
                                      NVL(G_TEM.NR_SENHA_AVULSA,
                                          G_TEM.CD_PTU_MENSAGEM_DESTINO),
                                      NULL))),
                   NVL(G.NR_GUIA_EXTERNA,
                       NVL(VCMF.NR_SENHA_GAT,
                           NVL(TO_CHAR(VCMF.NR_GUIA), VCMF.CD_GUIA_EXTERNA))))
              ELSE
               NULL
            END NR_AUTORIZ,
            Nvl(G.DT_AUTORIZACAO, VCMF.DT_REALIZADO) DT_AUTORIZ,
            Decode (G.TP_AUTORIZACAO_PTU,2,2,1) TP_AUTORIZ
      FROM DBAPS.V_CTAS_MEDICAS_FATURA VCMF
      INNER JOIN DBAPS.TIPO_ATENDIMENTO       TA ON VCMF.CD_TIPO_ATENDIMENTO = TA.CD_TIPO_ATENDIMENTO
      LEFT JOIN DBAPS.GUIA                    G ON VCMF.NR_GUIA = G.NR_GUIA
      LEFT JOIN DBAPS.GUIA                    G_TEM ON Nvl(G.NR_GUIA_TEM, VCMF.NR_GUIA_TEM) = G_TEM.NR_GUIA
      LEFT JOIN DBAPS.PTU_MENSAGEM            PM ON G.CD_PTU_MENSAGEM_ORIGEM = PM.CD_PTU_MENSAGEM
      WHERE VCMF.CD_MENS_CONTRATO = P_MENS_CONTRATO
        AND VCMF.CD_LOTE = P_CD_LOTE
        AND VCMF.CD_CONTA_MEDICA = P_CD_CONTA_MEDICA;

BEGIN
 /*Vamos atualizar o registro dos procedimentos da guia.*/
 FOR rAutor IN cAutorizacao LOOP
   IF rAutor.NR_AUTORIZ IS NOT NULL THEN

     IF PCD_PTU_A500_SADT IS NOT NULL THEN

         UPDATE DBAPS.PTU_A500_PROC P SET DT_SOLICITACAO = rAutor.DT_SOLICITACAO,
                                           NR_AUTORIZACAO   = SubStr(rAutor.NR_AUTORIZ,1,10),
                                           CD_UNI_AUTORIZADORA = rAutor.CD_UNI_AUTORIZA,
                                           DT_AUTORIZACAO = rAutor.DT_AUTORIZ,
                                           TP_AUTORIZACAO = rAutor.TP_AUTORIZ
            WHERE P.CD_PTU_A500_SADT = PCD_PTU_A500_SADT;

     ELSIF PCD_PTU_A500_INTERNACAO IS NOT NULL THEN

         UPDATE DBAPS.PTU_A500_PROC P SET DT_SOLICITACAO = rAutor.DT_SOLICITACAO,
                                           NR_AUTORIZACAO   = rAutor.NR_AUTORIZ,
                                           CD_UNI_AUTORIZADORA = rAutor.CD_UNI_AUTORIZA,
                                           DT_AUTORIZACAO = rAutor.DT_AUTORIZ,
                                           TP_AUTORIZACAO = rAutor.TP_AUTORIZ
            WHERE P.CD_PTU_A500_INTERNACAO = PCD_PTU_A500_INTERNACAO;


     ELSIF PCD_PTU_A500_HONORARIO IS NOT NULL THEN

         UPDATE DBAPS.PTU_A500_PROC P SET DT_SOLICITACAO = rAutor.DT_SOLICITACAO,
                                           NR_AUTORIZACAO   = rAutor.NR_AUTORIZ,
                                           CD_UNI_AUTORIZADORA = rAutor.CD_UNI_AUTORIZA,
                                           DT_AUTORIZACAO = rAutor.DT_AUTORIZ,
                                           TP_AUTORIZACAO = rAutor.TP_AUTORIZ
            WHERE P.CD_PTU_A500_HONORARIO = PCD_PTU_A500_HONORARIO;

     ELSIF PCD_PTU_A500_CONSULTA IS NOT NULL THEN

           UPDATE DBAPS.PTU_A500_CONSULTA P SET DT_SOLICITACAO = rAutor.DT_SOLICITACAO,
                                               NR_AUTORIZACAO   = rAutor.NR_AUTORIZ,
                                               CD_UNI_AUTORIZADORA = rAutor.CD_UNI_AUTORIZA,
                                               DT_AUTORIZACAO = rAutor.DT_AUTORIZ,
                                               TP_AUTORIZACAO = rAutor.TP_AUTORIZ
            WHERE P.CD_PTU_A500_CONSULTA = PCD_PTU_A500_CONSULTA;

     END IF;

   END IF;
 END LOOP;

END;

FUNCTION FNC_RET_UF_TO_TISS(P_CD_UF IN VARCHAR2) RETURN VARCHAR2 IS

  CURSOR cTissToUF(P_CD_UF IN VARCHAR2) IS
    SELECT LPAD(CD_TISS,2,'0') CD_TISS
      FROM DBAPS.UNIDADE_FEDERACAO
     WHERE (TRIM(CD_UF) = TRIM(P_CD_UF) OR LPAD(CD_TISS,2,'0') = TRIM(P_CD_UF))
       AND ROWNUM = 1;

  cCdTiss VARCHAR2(10);
BEGIN

    IF (P_CD_UF IS NOT NULL) THEN
      OPEN cTissToUF(P_CD_UF);
      FETCH cTissToUF INTO cCdTiss;
      CLOSE cTissToUF;
    END IF;

  RETURN cCdTiss;
END;

PROCEDURE PRC_INSERE_PRESTADOR_EVENTUAL(P_CD_SEQUENCE        IN NUMBER,
                                          P_CD_UNIMED          IN NUMBER,
                                          P_NR_CODIGO          IN VARCHAR2,
                                          P_DS_NOME            IN VARCHAR2,
                                          P_TP_PESSOA          IN VARCHAR2,
                                          P_NR_DOCUMENTO       IN VARCHAR2,
                                          P_TP_PRESTADOR       IN VARCHAR2,
                                          P_DS_COD_CONSELHO    IN VARCHAR2,
                                          P_DS_CONSELHO        IN VARCHAR2,
                                          P_DS_CODIGO_CONSELHO IN VARCHAR2,
                                          P_DS_UF_CONSELHO     IN VARCHAR2,
                                          P_SN_RECURSO_PROPRIO IN VARCHAR2) IS
  BEGIN
    INSERT INTO DBAPS.PRESTADOR_EVENTUAL
      (CD_PRESTADOR_EVENTUAL,
       CD_UNIMED,
       NR_CODIGO,
       DS_NOME,
       NR_CNPJ_CEI,
       NR_CPF,
       TP_PRESTADOR,
       CD_USUARIO_INCLUSAO,
       DT_INCLUSAO,
       DS_COD_CONSELHO,
       DS_CONSELHO,
       DS_CODIGO_CONSELHO,
       DS_UF_CONSELHO,
       SN_RECURSO_PROPRIO)
    VALUES
      (P_CD_SEQUENCE,
       LPad(P_CD_UNIMED, 3, '0'),
       P_NR_CODIGO,
       P_DS_NOME,
       Decode(P_TP_PESSOA, 'J', P_NR_DOCUMENTO, NULL),
       Decode(P_TP_PESSOA, 'F', P_NR_DOCUMENTO, NULL),
       P_TP_PRESTADOR,
       USER,
       SYSDATE,
       P_DS_COD_CONSELHO,
       P_DS_CONSELHO,
       P_DS_CODIGO_CONSELHO,
       P_DS_UF_CONSELHO,
       P_SN_RECURSO_PROPRIO);
  END;

FUNCTION FNC_RET_INSERE_PREST_EVENTUAL(P_CD_PREST                IN VARCHAR2,
                                       P_CD_UNI_PRE              IN VARCHAR2,
                                       P_CD_UNI_ORI_COD          IN VARCHAR2,
                                       P_TP_PESSOA               IN VARCHAR2,
                                       P_NR_CNPJ_CPF             IN VARCHAR2,
                                       P_NM_PREST                IN VARCHAR2,
                                       P_NM_PROF_PREST           IN VARCHAR2,
                                       P_TP_PREST_EXEC           IN VARCHAR2,
                                       P_ID_REC_PROPRIO          IN VARCHAR2,
                                       P_NR_CONS_PROF_PREST      IN VARCHAR2 DEFAULT NULL,
                                       P_SG_CONS_PROF_PREST      IN VARCHAR2 DEFAULT NULL,
                                       P_SG_UF_CONS_PREST        IN VARCHAR2 DEFAULT NULL) RETURN NUMBER IS

  /**
  * Retorna codigo do prestador eventual buscando pelo codigo original
  */
  CURSOR cPrestadorEventualCodigo(P_CD_CODIGO        IN VARCHAR2,
                                  P_CD_UNIMED_ORIGEM IN NUMBER) IS
    SELECT CD_PRESTADOR_EVENTUAL
      FROM DBAPS.PRESTADOR_EVENTUAL PE
     WHERE PE.CD_UNIMED = LPad(P_CD_UNIMED_ORIGEM, 3, '0')
       AND PE.NR_CODIGO = P_CD_CODIGO;

  /**
  * Retorna codigo do prestador eventual buscando pelo codigo original
  */
  CURSOR cPrestadorEventual(P_CD_UNIMED_ORIGEM IN NUMBER,
                            P_TP_PESSOA        IN VARCHAR2,
                            P_NR_DOCUMENTO     IN VARCHAR2,
                            P_DS_NOME          IN VARCHAR2) IS
    SELECT CD_PRESTADOR_EVENTUAL
      FROM DBAPS.PRESTADOR_EVENTUAL PE
     WHERE PE.CD_UNIMED = LPad(P_CD_UNIMED_ORIGEM, 3, '0')
       AND ((PE.NR_CNPJ_CEI = P_NR_DOCUMENTO AND P_TP_PESSOA = 'J') OR
           (PE.NR_CPF = P_NR_DOCUMENTO AND P_TP_PESSOA = 'F'))
       AND PE.DS_NOME = P_DS_NOME
       AND PE.NR_CODIGO IS NULL;

  vCdPrestadorEventual NUMBER;
BEGIN

    IF (Nvl(To_Number(P_CD_PREST), 0) <> 0) THEN
        OPEN cPrestadorEventualCodigo(P_CD_PREST,
                                      P_CD_UNI_PRE);
        FETCH cPrestadorEventualCodigo INTO vCdPrestadorEventual;
        CLOSE cPrestadorEventualCodigo;
      ELSE
        OPEN cPrestadorEventual(P_CD_UNI_ORI_COD,
                                P_TP_PESSOA,
                                P_NR_CNPJ_CPF,
                                P_NM_PREST);
        FETCH cPrestadorEventual INTO vCdPrestadorEventual;
        CLOSE cPrestadorEventual;
      END IF;

      IF (vCdPrestadorEventual IS NULL) THEN
        SELECT DBAPS.SEQ_PRESTADOR_EVENTUAL.NEXTVAL
          INTO vCdPrestadorEventual
          FROM SYS.DUAL;

        IF (Nvl(To_Number(P_CD_PREST), 0) <> 0) AND (Nvl(To_Number(P_CD_UNI_PRE), 0) <> 0) THEN
          PRC_INSERE_PRESTADOR_EVENTUAL(vCdPrestadorEventual,
                                        P_CD_UNI_PRE,
                                        P_CD_PREST,
                                        Nvl(P_NM_PROF_PREST, P_NM_PREST),
                                        P_TP_PESSOA,
                                        P_NR_CNPJ_CPF,
                                        P_TP_PREST_EXEC,
                                        P_NR_CONS_PROF_PREST,
                                        P_NR_CONS_PROF_PREST,
                                        P_SG_CONS_PROF_PREST,
                                        P_SG_UF_CONS_PREST,
                                        P_ID_REC_PROPRIO);
        ELSE
          PRC_INSERE_PRESTADOR_EVENTUAL(vCdPrestadorEventual,
                                        P_CD_UNI_ORI_COD,
                                        NULL,
                                        P_NM_PREST,
                                        P_TP_PESSOA,
                                        P_NR_CNPJ_CPF,
                                        P_TP_PREST_EXEC,
                                        NULL,
                                        NULL,
                                        NULL,
                                        NULL,
                                        P_ID_REC_PROPRIO);
        END IF;
      END IF;
  RETURN vCdPrestadorEventual;
END;


  FUNCTION GET_TABLE_PTU_A500_CONS(PCD_MENS_CONTRATO          IN NUMBER
                                  ,P_ID_AVISO                 IN VARCHAR2
                                  ,P_CD_LOTE                  IN NUMBER
                                  ,P_CD_CONTA_MEDICA          IN NUMBER) RETURN TABLE_PTU_A500_CONS PIPELINED IS
    CURSOR cGuiaConsulta(P_CD_MENS_CONTRATO         NUMBER
                        ,P_ID_AVISO                 VARCHAR2
                        ,P_CD_LOTE                  NUMBER
                        ,P_CD_CONTA_MEDICA          NUMBER) IS
      SELECT DISTINCT
       VCMF.CD_LOTE                                                                                                  NR_LOTEPREST,
       VCMF.CD_CONTA_MEDICA                                                                                          NR_GUIA_TISS_PRESTADOR,
       DECODE(VCMF.TP_BENEFICIARIO, 'RE', SubStr(VCMF.NR_CARTEIRA_BENEFICIARIO,1,3), VCMF.CD_UNIMED_ORIGEM)          CD_UNIMED,
       SUBSTR(DECODE(VCMF.TP_BENEFICIARIO, 'RE', LPad(VCMF.NR_CARTEIRA_BENEFICIARIO,16,'0')/*U.NR_CARTEIRA_RECIPROCIDADE*/, LPad(VCMF.NR_CARTEIRA_BENEFICIARIO,16,'0')), 4, 16) ID_BENEF,
       SUBSTR(NVL(NVL(VCMF.NM_BENEFICIARIO, BT.NM_SEGURADO), 'NAO INFORMADO'),1,25)                                  NM_BENEF,
       NVL(VCMF.SN_ATENDIMENTO_RN, 'N')                                                                              ID_RN,
       CASE
        WHEN TAT.CD_TISS IN ('12', '14', '15', '16', '17', '18', '19', '20', '21') THEN  -- SAUDE OCUPACIONAL
          '9'
        ELSE
          '1'
       END                                                                                                           TP_PACIENTE,
       VCMF.CD_UNIMED_EXECUTORA                                                                                      CD_UNI_PRE,
       VCMF.CD_PRESTADOR                                                                                             CD_PREST,
       SUBSTR(PSO.NM_PRESTADOR, 0, 60)                                                                              NM_PREST,
       NVL(DECODE(LENGTH(PSO.NR_CPF_CGC),10,'0'||PSO.NR_CPF_CGC,NULL),DECODE(LENGTH(PSO.NR_CPF_CGC),11,PSO.NR_CPF_CGC,NULL)) CD_CPF,
       DECODE(LENGTH(PSO.NR_CPF_CGC),14,PSO.NR_CPF_CGC,NULL)                                                         CD_CNPJ,
       NVL(PSO.CD_CNES, '9999999')                                                                                   CD_CNES_CONT_EXEC,
       PE.CD_MUNICIPIO                                                                                               CD_MUNIC_CONT_EXEC,
       DECODE(PSO.TP_REDE_MIN, 'B', 1, 'E', 2, 'M', 3)                                                               TIPO_REDE_MIN,
       TP.CD_PTU_TIPO_PRESTADOR                                                                                      TP_PREST_EXEC,
       DECODE(PSO.TP_CREDENCIAMENTO, 'D', 'S', DECODE(PSO.TP_CREDENCIAMENTO, 'P', 'S', 'N'))                         ID_REC_PROPRIO,
       VCMF.CD_UNIMED_EXECUTORA                                                                                      CD_PROF_UNI_PRE,
       VCMF.CD_PRESTADOR                                                                                             CD_PROF_PREST,
       SUBSTR(PSO.NM_PRESTADOR, 0, 60)                                                                                              NM_PROF_PREST,
       Decode(LPad(CP.CD_TISS, 2, '0'), '02', 'COREN', '01', 'CRESS', '05', 'CREFITO', '03', 'CRF', '04', 'CREFONO', '06', 'CRM', '07', 'CRN', '08', 'CRO', '09', 'CRP', '10', 'OUT','11','CRFA', '12','CRBM', NULL) SG_CONS_PROF_PREST,
       PSO.DS_COD_CONSELHO                                                                                           NR_CONS_PROF_PREST,
       FNC_RET_UF_TO_TISS(PSO.UF_CONSELHO)                                                                           SG_UF_CONS_PREST,
       NVL(E.NR_CBOS,999999)                                                                                         NR_CBO,
       NVL(VCMF.CD_VERSAO_TISS,'3.05.00')                                                                            NR_VER_TISS,
       NVL(VCMF.CD_TIPO_CONSULTA,1)                                                                                  TP_CONSULTA,
       Nvl(VCMF.dt_apresentacao_conta_medica,PC.DT_INCLUSAO)                                                                   DT_PROTOCOLO,
       Nvl(VCMF.dt_apresentacao_conta_medica,PC.DT_INCLUSAO)                                                                   DT_CONHECIMENTO,
       Nvl(NVL(TO_CHAR(VCMF.NR_GUIA), VCMF.CD_GUIA_EXTERNA), SubStr(VCMF.CD_LOTE||'-'||VCMF.CD_CONTA_MEDICA,1,20)) NR_GUIA_TISS_OPERADORA,
       NVL(IA.CD_TISS, 9)                                                                                             TP_IND_ACIDENTE,
       MIN(TO_DATE(TO_CHAR(VCMF.DT_REALIZADO, 'DD/MM/YYYY') || NVL(TO_CHAR(VCMF.HR_INICIAL,'HH24:MI:SS'), '00:00:00'),'DD/MM/YYYY HH24:MI:SS')) DT_ATEND,
       VCMF.SN_LIMINAR                                                                                               ID_LIMINAR,
       VCMF.CD_TIPO_ATENDIMENTO_INTERMED                                                                             ID_CONTINUADO,
       DECODE(VCMF.CD_PTU_REMESSA_RETORNO_A520, NULL, 'N', 'S')                                                      ID_AVISO,
       CASE
          WHEN P_ID_AVISO = 'S' THEN
            'A'
          WHEN VCMF.CD_EXCECAO = 'I' THEN
            'I'
          WHEN VCMF.SN_REFATURAR = 'S' AND VCMF.CD_EXCECAO = 'L' THEN
            'L'
          WHEN VCMF.SN_REFATURAR = 'S' AND VCMF.CD_EXCECAO <> 'L' THEN
            'J'
          WHEN VCMF.NR_SENHA_GAT IS NOT NULL THEN
            'L'
          WHEN (TA.TP_GUIA = 'H' AND VCMF.NR_GUIA_TEM IS NOT NULL) THEN
            'L'
          WHEN (G_PAI.SN_VALIDA_REST_CARENCIA = 'S') THEN
            'L'
          WHEN DECODE(VCMF.NR_GUIA, NULL, '0', 'L') = '0' THEN
            '0'
          WHEN DECODE(VCMF.NR_GUIA, NULL, '0', 'L') = 'L' THEN
            'L'
        END                                                                                                          CD_EXCECAO,
        'N'                                                                                                          ID_GLOSATOTAL,
        /*CASE
        WHEN VCMF.NR_SENHA_GAT IS NOT NULL AND LENGTH(VCMF.NR_SENHA_GAT)<=10 THEN
          VCMF.NR_SENHA_GAT
        WHEN (DECODE(VCMF.NR_GUIA, NULL, '0', 'L') = 'L') OR (TA.TP_GUIA = 'H' AND VCMF.NR_GUIA_TEM IS NOT NULL) OR (G_TEM.SN_VALIDA_REST_CARENCIA = 'S') THEN
          NVL(TO_CHAR(Nvl(NVL(G.NR_SENHA_AVULSA,G.CD_PTU_MENSAGEM_DESTINO),Decode(G_TEM.NR_GUIA_TEM, NULL, NVL(G_TEM.NR_SENHA_AVULSA,G_TEM.CD_PTU_MENSAGEM_DESTINO), NULL))), NVL(G.NR_GUIA_EXTERNA, NVL(VCMF.NR_SENHA_GAT, NVL(TO_CHAR(VCMF.NR_GUIA), VCMF.CD_GUIA_EXTERNA))))
        ELSE
          NULL
        END                                                                                                           NR_AUTORIZ,*/
       -- Nvl(G.DT_AUTORIZACAO, VCMF.DT_REALIZADO)                                                                      DT_AUTORIZ,
       -- Trunc(Nvl(Nvl(PM.DT_TRANSACAO,G.DT_EMISSAO), VCMF.DT_REALIZADO))                                              DT_SOLICITACAO,
       -- VCMF.CD_UNIMED_ORIGEM                                                                                         CD_UNIAUTORIZADORA,
       -- NVL(G.TP_AUTORIZACAO_PTU, 1)                                                                                  TP_AUTORIZ,
       CASE
          WHEN NVL(TAT.CD_TISS,'04') IN('02','03','08','09', '10') THEN
            2
          ELSE
            NULL
          END TP_REGCPL,
        NULL                                                                                                          NM_DESCCOMPLEMENTO,
        1                                                                                                             SEQ_ITEM,
        VCMF.ID_ITEM_UNICO                                                                                            ID_ITEMUNICO,
        DECODE(VCMF.CD_PTU_REMESSA_RETORNO_A520, NULL, 'N', 'S')                                                      ID_AVISO_ITEM,
        DBAPS.FNC_TABELA_TUSS(VCMF.CD_PROCEDIMENTO)                                                                   TP_TABELA,
        VCMF.CD_PROCEDIMENTO                                                                                          CD_PROCEDIMENTO,
        VCMF.VL_TOTAL_COBRADO                                                                                         VL_SERV_COB,
        VCMF.VL_TOTAL_TAXA_COBRADO_PTU                                                                                VL_ADIC_SER,
        DECODE(TP.TP_TIP_PRESTADOR,6, '1', '3')                                                                       CD_ATO,
        /*Dados Para Refaturamento*/
        VCMF.CD_CONTA_MEDICA_ORIGEM                                                                                    CD_CONTA_MEDICA_ORIGEM,
        VCMF.NR_LOTE_REFERENCIA                                                                                        NR_LOTE_GLOSADO,
        VCMF.NR_NOTA_REFERENCIA                                                                                        NR_NOTA_GLOSADA,
        NULL                                                                                                           NR_DOC_1_GLOSADO,
        NULL                                                                                                          NR_DOC_2_GLOSADO,
        VCMF.CD_MATRICULA                                                                                             CD_MATRICULA,
        VCMF.NR_CARTEIRA_BENEFICIARIO                                                                                 NR_CARTEIRA_BENEFICIARIO,
        VCMF.CD_MULTI_EMPRESA                                                                                         CD_MULTI_EMPRESA,
        VCMF.CD_PTU_REMESSA_RETORNO_A520                                                                              CD_PTU_REMESSA_RETORNO_A520,
        VCMF.CD_LANCAMENTO                                                                                            CD_LANCAMENTO
    FROM DBAPS.V_CTAS_MEDICAS_FATURA  VCMF
       INNER JOIN DBAPS.TIPO_ATENDIMENTO TA       ON VCMF.CD_TIPO_ATENDIMENTO = TA.CD_TIPO_ATENDIMENTO
       LEFT JOIN DBAPS.TIPO_ATENDIMENTO_TISS TAT  ON VCMF.CD_TIPO_ATENDIMENTO_TISS = TAT.CD_TIPO_ATENDIMENTO
       LEFT JOIN DBAPS.GUIA G                     ON VCMF.NR_GUIA = G.NR_GUIA
       LEFT JOIN DBAPS.GUIA G_PAI                 ON Nvl(VCMF.NR_GUIA_TEM, G.NR_GUIA_TEM) = G_PAI.NR_GUIA
       LEFT JOIN DBAPS.PROTOCOLO_CTAMED PC        ON VCMF.CD_PROTOCOLO_CTAMED = PC.CD_PROTOCOLO_CTAMED
       LEFT JOIN DBAPS.INDICADOR_ACIDENTE IA      ON VCMF.CD_INDICADOR_ACIDENTE = IA.CD_INDICADOR_ACIDENTE
       LEFT JOIN DBAPS.MOTIVO_ALTA MA             ON VCMF.CD_MOTIVO_ALTA = MA.CD_MOTIVO_ALTA
       LEFT JOIN DBAPS.PRESTADOR PSO              ON Nvl(VCMF.CD_PRESTADOR_PTU,VCMF.CD_PRESTADOR) = PSO.CD_PRESTADOR
       LEFT JOIN DBAPS.CONSELHO_PROFISSIONAL CP   ON PSO.CD_CONSELHO_PROFISSIONAL = CP.CD_CONSELHO_PROFISSIONAL
       LEFT JOIN DBAPS.ESPECIALIDADE_PRESTADOR EP ON PSO.CD_PRESTADOR = EP.CD_PRESTADOR
       INNER JOIN DBAPS.TIP_PRESTADOR TP          ON PSO.CD_TIP_PRESTADOR = TP.CD_TIP_PRESTADOR
       INNER JOIN DBAPS.ESPECIALIDADE E           ON EP.CD_ESPECIALIDADE = E.CD_ESPECIALIDADE
       LEFT JOIN DBAPS.PRESTADOR_ENDERECO PE      ON PSO.CD_PRESTADOR = PE.CD_PRESTADOR
       LEFT JOIN DBAPS.BENEFICIARIO_TRANSITO BT   ON VCMF.NR_CARTEIRA_BENEFICIARIO = BT.CD_MATRICULA
       LEFT JOIN DBAPS.USUARIO U                  ON VCMF.NR_CARTEIRA_BENEFICIARIO = U.CD_MAT_ALTERNATIVA
       LEFT JOIN DBAPS.PTU_MENSAGEM PM            ON G.CD_PTU_MENSAGEM_ORIGEM = PM.CD_PTU_MENSAGEM
       LEFT JOIN DBAPS.GUIA G_TEM                 ON Nvl(G.NR_GUIA_TEM, VCMF.NR_GUIA_TEM) = G_TEM.NR_GUIA
    WHERE TA.TP_GUIA = 'C'
    AND PE.SN_PRINCIPAL = 'S' -- ENDERECO PRINCIPAL
    AND EP.SN_PRINCIPAL = 'S'
    AND EP.CD_ESPECIALIDADE = (SELECT EP2.CD_ESPECIALIDADE
                                FROM DBAPS.ESPECIALIDADE_PRESTADOR EP2
                                WHERE EP.CD_PRESTADOR = EP2.CD_PRESTADOR
                                  AND EP2.SN_PRINCIPAL = 'S'
                                  AND ROWNUM = 1)
    AND VCMF.CD_MENS_CONTRATO = P_CD_MENS_CONTRATO
    AND (P_ID_AVISO = 'S'
        AND VCMF.CD_LOTE = P_CD_LOTE
        AND VCMF.CD_CONTA_MEDICA = P_CD_CONTA_MEDICA
         OR P_ID_AVISO = 'N')
    GROUP BY
        VCMF.CD_LOTE                                                                                                 ,
       VCMF.CD_CONTA_MEDICA                                                                                   ,
       DECODE(VCMF.TP_BENEFICIARIO, 'RE', SUBSTR(VCMF.NR_CARTEIRA_BENEFICIARIO, 1,3), VCMF.CD_UNIMED_ORIGEM),
       SUBSTR(DECODE(VCMF.TP_BENEFICIARIO, 'RE', LPad(VCMF.NR_CARTEIRA_BENEFICIARIO,16,'0')/*U.NR_CARTEIRA_RECIPROCIDADE*/, LPad(VCMF.NR_CARTEIRA_BENEFICIARIO,16,'0')), 4, 16) ,
       NVL(NVL(VCMF.NM_BENEFICIARIO, BT.NM_SEGURADO), 'NAO INFORMADO')                                               ,
       NVL(VCMF.SN_ATENDIMENTO_RN, 'N')                                                                              ,
       CASE
        WHEN TAT.CD_TISS IN ('12', '14', '15', '16', '17', '18', '19', '20', '21') THEN  -- SAUDE OCUPACIONAL
          '9'
        ELSE
          '1'
       END                                                                                                           ,
       VCMF.CD_UNIMED_EXECUTORA                                                                                      ,
       VCMF.CD_PRESTADOR                                                                                             ,
       SUBSTR(PSO.NM_PRESTADOR, 0, 60)                                                                              ,
       NVL(DECODE(LENGTH(PSO.NR_CPF_CGC),10,'0'||PSO.NR_CPF_CGC,NULL),DECODE(LENGTH(PSO.NR_CPF_CGC),11,PSO.NR_CPF_CGC,NULL)) ,
       DECODE(LENGTH(PSO.NR_CPF_CGC),14,PSO.NR_CPF_CGC,NULL)                                                         ,
       NVL(PSO.CD_CNES, '9999999')                                                                                   ,
       PE.CD_MUNICIPIO                                                                                               ,
       DECODE(PSO.TP_REDE_MIN, 'B', 1, 'E', 2, 'M', 3)                                                               ,
       TP.CD_PTU_TIPO_PRESTADOR                                                                                      ,
       DECODE(TP.TP_TIP_PRESTADOR, 6, 'S', DECODE(PSO.TP_CREDENCIAMENTO, 'P', 'S', 'N'))                             ,
       SUBSTR(PSO.NM_PRESTADOR, 0, 60)                                                                                              ,
       Decode(LPad(CP.CD_TISS, 2, '0'), '02', 'COREN', '01', 'CRESS', '05', 'CREFITO', '03', 'CRF', '04', 'CREFONO', '06', 'CRM', '07', 'CRN', '08', 'CRO', '09', 'CRP', '10', 'OUT','11','CRFA', '12','CRBM', NULL),
       PSO.DS_COD_CONSELHO                                                                                           ,
       PSO.UF_CONSELHO                                                                                               ,
       NVL(E.NR_CBOS,999999)                                                                                         ,
       VCMF.CD_VERSAO_TISS                                                                                           ,
       VCMF.CD_TIPO_CONSULTA                                                                                         ,
       Nvl(PC.NR_LOTE_PRESTADOR, VCMF.CD_LOTE)                                                                       ,
       Nvl(VCMF.dt_apresentacao_conta_medica, PC.DT_INCLUSAO)                                                        ,                                                                    
       NVL(TO_CHAR(VCMF.NR_GUIA), VCMF.CD_GUIA_EXTERNA)                                                              ,
       NVL(TO_CHAR(VCMF.NR_GUIA), VCMF.CD_GUIA_EXTERNA)                                                              ,
       NVL(IA.CD_PTU, 9)                                                                                             ,
       VCMF.SN_LIMINAR                                                                                               ,
       VCMF.CD_TIPO_ATENDIMENTO_INTERMED                                                                             ,
       DECODE(VCMF.CD_PTU_REMESSA_RETORNO_A520, NULL, 'N', 'S')                                                      ,
       CASE
          WHEN P_ID_AVISO = 'S' THEN
            'A'
          WHEN VCMF.CD_EXCECAO = 'I' THEN
            'I'
          WHEN VCMF.SN_REFATURAR = 'S' AND VCMF.CD_EXCECAO = 'L' THEN
            'L'
          WHEN VCMF.SN_REFATURAR = 'S' AND VCMF.CD_EXCECAO <> 'L' THEN
            'J'
          WHEN VCMF.NR_SENHA_GAT IS NOT NULL THEN
            'L'
          WHEN (TA.TP_GUIA = 'H' AND VCMF.NR_GUIA_TEM IS NOT NULL) THEN
            'L'
          WHEN (G_PAI.SN_VALIDA_REST_CARENCIA = 'S') THEN
            'L'
          WHEN DECODE(VCMF.NR_GUIA, NULL, '0', 'L') = '0' THEN
            '0'
          WHEN DECODE(VCMF.NR_GUIA, NULL, '0', 'L') = 'L' THEN
            'L'
        END                                                                                                          ,
        'N'                                                                                                          ,
        CASE
          WHEN NVL(TAT.CD_TISS,'04') IN('02','03','08','09', '10') THEN
            2
          ELSE
            NULL
          END ,
        /*CASE
        WHEN VCMF.NR_SENHA_GAT IS NOT NULL AND LENGTH(VCMF.NR_SENHA_GAT)<=10 THEN
          VCMF.NR_SENHA_GAT
        WHEN (DECODE(VCMF.NR_GUIA, NULL, '0', 'L') = 'L') OR (TA.TP_GUIA = 'H' AND VCMF.NR_GUIA_TEM IS NOT NULL) OR (G_TEM.SN_VALIDA_REST_CARENCIA = 'S') THEN
          NVL(TO_CHAR(Nvl(NVL(G.NR_SENHA_AVULSA,G.CD_PTU_MENSAGEM_DESTINO),Decode(G_TEM.NR_GUIA_TEM, NULL, NVL(G_TEM.NR_SENHA_AVULSA,G_TEM.CD_PTU_MENSAGEM_DESTINO), NULL))), NVL(G.NR_GUIA_EXTERNA, NVL(VCMF.NR_SENHA_GAT, NVL(TO_CHAR(VCMF.NR_GUIA), VCMF.CD_GUIA_EXTERNA))))
        ELSE
          NULL
        END                                                                                                           ,
        Nvl(G.DT_AUTORIZACAO, VCMF.DT_REALIZADO)                                                                      ,
        Trunc(Nvl(Nvl(PM.DT_TRANSACAO,G.DT_EMISSAO), VCMF.DT_REALIZADO))                                              ,
        VCMF.CD_UNIMED_ORIGEM                                                                                         ,
        NVL(G.TP_AUTORIZACAO_PTU, 1)                                                                                  ,*/
        VCMF.CD_PROCEDIMENTO,
        VCMF.VL_TOTAL_COBRADO,
        VCMF.VL_TOTAL_TAXA_COBRADO_PTU,
        DECODE(TP.TP_TIP_PRESTADOR,6, '1', '3'),
        VCMF.CD_CONTA_MEDICA_ORIGEM,
        VCMF.NR_LOTE_REFERENCIA,
        VCMF.NR_NOTA_REFERENCIA,
        VCMF.CD_MATRICULA,
        VCMF.NR_CARTEIRA_BENEFICIARIO,
        VCMF.CD_MULTI_EMPRESA,
        VCMF.CD_PTU_REMESSA_RETORNO_A520,
        VCMF.ID_ITEM_UNICO,
        NVL(IA.CD_TISS, 9),
        PSO.TP_CREDENCIAMENTO,
        VCMF.CD_LANCAMENTO,
        VCMF.TP_BENEFICIARIO,
        VCMF.CD_UNIMED_ORIGEM,
        VCMF.CD_EXCECAO,
        VCMF.SN_REFATURAR,
        VCMF.NR_SENHA_GAT,
        TA.TP_GUIA,
        VCMF.NR_GUIA_TEM,
        G_PAI.SN_VALIDA_REST_CARENCIA,
        VCMF.NR_GUIA;
    rowPtuA500Cons ROW_PTU_A500_CONS;
  BEGIN
    FOR r IN cGuiaConsulta(PCD_MENS_CONTRATO,P_ID_AVISO,P_CD_LOTE,P_CD_CONTA_MEDICA) LOOP
      rowPtuA500Cons.CD_UNIMED                := r.CD_UNIMED;
      rowPtuA500Cons.ID_BENEF                 := r.ID_BENEF;
      rowPtuA500Cons.NM_BENEF                 := DBAPS.PKG_PTU_BATCH.FNC_AJUSTA_DADO_PTU('ANS',r.NM_BENEF);
      rowPtuA500Cons.ID_RN                    := r.ID_RN;
      rowPtuA500Cons.TP_PACIENTE              := r.TP_PACIENTE;
      rowPtuA500Cons.CD_UNI_PRE               := r.CD_UNI_PRE;
      rowPtuA500Cons.CD_PREST                 := r.CD_PREST;
      rowPtuA500Cons.NM_PREST                 := DBAPS.PKG_PTU_BATCH.FNC_AJUSTA_DADO_PTU('ANS',r.NM_PREST);
      rowPtuA500Cons.CD_CPF                   := r.CD_CPF;
      rowPtuA500Cons.CD_CNPJ                  := r.CD_CNPJ;
      rowPtuA500Cons.CD_CNES_CONT_EXEC        := r.CD_CNES_CONT_EXEC;
      rowPtuA500Cons.CD_MUNIC_CONT_EXEC       := DBAPS.FNC_CALCULA_CODIGO_IBGE(r.CD_MUNIC_CONT_EXEC);
      rowPtuA500Cons.TIPO_REDE_MIN            := r.TIPO_REDE_MIN;
      rowPtuA500Cons.TP_PREST_EXEC            := r.TP_PREST_EXEC;
      rowPtuA500Cons.ID_REC_PROPRIO           := r.ID_REC_PROPRIO;
      rowPtuA500Cons.CD_PROF_UNI_PRE          := r.CD_PROF_UNI_PRE;
      rowPtuA500Cons.CD_PROF_PREST            := r.CD_PROF_PREST;
      rowPtuA500Cons.NM_PROF_PREST            := DBAPS.PKG_PTU_BATCH.FNC_AJUSTA_DADO_PTU('ANS',r.NM_PROF_PREST);
      rowPtuA500Cons.SG_CONS_PROF_PREST       := r.SG_CONS_PROF_PREST;
      rowPtuA500Cons.NR_CONS_PROF_PREST       := r.NR_CONS_PROF_PREST;
      rowPtuA500Cons.SG_UF_CONS_PREST         := r.SG_UF_CONS_PREST;
      rowPtuA500Cons.NR_CBO                   := r.NR_CBO;
      rowPtuA500Cons.NR_VER_TISS              := r.NR_VER_TISS;
      rowPtuA500Cons.TP_CONSULTA              := r.TP_CONSULTA;
      rowPtuA500Cons.NR_LOTEPREST             := r.NR_LOTEPREST;
      rowPtuA500Cons.DT_PROTOCOLO             := r.DT_PROTOCOLO;
      rowPtuA500Cons.DT_CONHECIMENTO          := r.DT_CONHECIMENTO;
      rowPtuA500Cons.NR_GUIA_TISS_PRESTADOR   := r.NR_GUIA_TISS_PRESTADOR;
      rowPtuA500Cons.NR_GUIA_TISS_OPERADORA   := r.NR_GUIA_TISS_OPERADORA;
      rowPtuA500Cons.TP_IND_ACIDENTE          := r.TP_IND_ACIDENTE;
      rowPtuA500Cons.DT_ATEND                 := r.DT_ATEND;
      rowPtuA500Cons.ID_LIMINAR               := r.ID_LIMINAR;
      rowPtuA500Cons.ID_CONTINUADO            := r.ID_CONTINUADO;
      rowPtuA500Cons.ID_AVISO                 := r.ID_AVISO;
      rowPtuA500Cons.CD_EXCECAO               := r.CD_EXCECAO;
      rowPtuA500Cons.ID_GLOSATOTAL            := r.ID_GLOSATOTAL;
      /*rowPtuA500Cons.NR_AUTORIZ               := r.NR_AUTORIZ;
      rowPtuA500Cons.DT_AUTORIZ               := r.DT_AUTORIZ;
      rowPtuA500Cons.DT_SOLICITACAO           := r.DT_SOLICITACAO;
      rowPtuA500Cons.CD_UNIAUTORIZADORA       := r.CD_UNIAUTORIZADORA;
      rowPtuA500Cons.TP_AUTORIZ               := r.TP_AUTORIZ;*/
      rowPtuA500Cons.TP_REGCPL                := r.TP_REGCPL;
      rowPtuA500Cons.NM_DESCCOMPLEMENTO       := DBAPS.PKG_PTU_BATCH.FNC_AJUSTA_DADO_PTU('ANS',r.NM_DESCCOMPLEMENTO);
      rowPtuA500Cons.SEQ_ITEM                 := r.SEQ_ITEM;
      rowPtuA500Cons.ID_ITEMUNICO             := r.ID_ITEMUNICO;
      rowPtuA500Cons.ID_AVISO_ITEM            := r.ID_AVISO_ITEM;
      rowPtuA500Cons.TP_TABELA                := r.TP_TABELA;
      rowPtuA500Cons.CD_PROCEDIMENTO          := r.CD_PROCEDIMENTO;
      rowPtuA500Cons.VL_SERV_COB              := r.VL_SERV_COB;
      rowPtuA500Cons.VL_ADIC_SER              := r.VL_ADIC_SER;
      rowPtuA500Cons.CD_ATO                   := r.CD_ATO;
      rowPtuA500Cons.CD_CONTA_MEDICA_ORIGEM   := r.CD_CONTA_MEDICA_ORIGEM;
      rowPtuA500Cons.NR_LOTE_GLOSADO          := r.NR_LOTE_GLOSADO;
      rowPtuA500Cons.NR_NOTA_GLOSADA          := r.NR_NOTA_GLOSADA;
      rowPtuA500Cons.NR_DOC_1_GLOSADO         := r.NR_DOC_1_GLOSADO;
      rowPtuA500Cons.NR_DOC_2_GLOSADO         := r.NR_DOC_2_GLOSADO;
      rowPtuA500Cons.CD_MATRICULA                := r.CD_MATRICULA;
      rowPtuA500Cons.NR_CARTEIRA_BENEFICIARIO    := r.NR_CARTEIRA_BENEFICIARIO;
      rowPtuA500Cons.CD_MULTI_EMPRESA            := r.CD_MULTI_EMPRESA;
      rowPtuA500Cons.CD_PTU_REMESSA_RETORNO_A520 := r.CD_PTU_REMESSA_RETORNO_A520;
      rowPtuA500Cons.CD_LANCAMENTO := r.CD_LANCAMENTO;

      PIPE ROW(rowPtuA500Cons);
    END LOOP;
    RETURN;
  END;
  FUNCTION GET_TABLE_PTU_A500_SADT(PCD_MENS_CONTRATO          IN NUMBER DEFAULT NULL
                                  ,P_ID_AVISO                 IN VARCHAR2
                                  ,P_CD_LOTE                  IN NUMBER
                                  ,P_CD_CONTA_MEDICA          IN NUMBER) RETURN TABLE_PTU_A500_SADT PIPELINED IS
    CURSOR cGuiaSadt(P_CD_MENS_CONTRATO         NUMBER
                    ,P_ID_AVISO                 VARCHAR2
                    ,P_CD_LOTE                  NUMBER
                    ,P_CD_CONTA_MEDICA          NUMBER) IS
      SELECT DISTINCT VCMF.CD_FATURA,
                VCMF.CD_LOTE NR_LOTE_PRESTADOR,
                VCMF.CD_CONTA_MEDICA NR_GUIA_TISS_PRESTADOR,
                Nvl(NVL(TO_CHAR(VCMF.NR_GUIA), VCMF.CD_GUIA_EXTERNA), SubStr(VCMF.CD_LOTE||'-'||VCMF.CD_CONTA_MEDICA,1,20)) NR_GUIA_TISS_OPERADORA,
                NVL(TO_CHAR(VCMF.NR_GUIA_TEM), VCMF.CD_GUIA_EXTERNA) NR_GUIA_TISS_PRINCIPAL,
                DECODE(VCMF.TP_BENEFICIARIO,'RE',SUBSTR(VCMF.NR_CARTEIRA_BENEFICIARIO, 1,3)/*'999'*/,VCMF.CD_UNIMED_ORIGEM) CD_UNI_BENEF,
                SUBSTR(DECODE(VCMF.TP_BENEFICIARIO,
                              'RE',
                               /*U.NR_CARTEIRA_RECIPROCIDADE*/
                              LPad(VCMF.NR_CARTEIRA_BENEFICIARIO,16,'0'),
                              LPad(VCMF.NR_CARTEIRA_BENEFICIARIO,16,'0')),
                       4,
                       16) ID_BENEF,
                SUBSTR(NVL(NVL(VCMF.NM_BENEFICIARIO, BT.NM_SEGURADO), 'NAO INFORMADO'),1,25)                                  NM_BENEF,
                NVL(VCMF.SN_ATENDIMENTO_RN, 'N') ID_RN,
                CASE
                  WHEN TAT.CD_TISS IN
                       ('12', '14', '15', '16', '17', '18', '19', '20', '21') THEN -- SAUDE OCUPACIONAL
                   '9'
                  ELSE
                   '1'
                END TP_PACIENTE,
                CASE
                  WHEN VCMF.CD_EXCECAO = 'I' THEN
                   'I'
                  WHEN VCMF.SN_REFATURAR = 'S' AND VCMF.CD_EXCECAO = 'L' THEN
                   'L'
                  WHEN VCMF.SN_REFATURAR = 'S' AND VCMF.CD_EXCECAO <> 'L' THEN
                   'J'
                  WHEN VCMF.NR_SENHA_GAT IS NOT NULL THEN
                   'L'
                  WHEN (TA.TP_GUIA = 'H' AND VCMF.NR_GUIA_TEM IS NOT NULL) THEN
                   'L'
                  WHEN (G_PAI.SN_VALIDA_REST_CARENCIA = 'S') THEN
                   'L'
                  WHEN DECODE(VCMF.NR_GUIA, NULL, '0', 'L') = '0' THEN
                   '0'
                  WHEN DECODE(VCMF.NR_GUIA, NULL, '0', 'L') = 'L' THEN
                   'L'
                END CD_EXCECAO,
               CASE
                WHEN NVL(TO_CHAR(VCMF.NR_GUIA_TEM), VCMF.CD_GUIA_EXTERNA) IS NULL AND NVL(TAT.CD_TISS,'04') = '07' THEN
                '05'
                ELSE
                NVL(TAT.CD_TISS,'04')
                END TP_ATENDIMENTO,
                --MIN(TO_DATE(TO_CHAR(VCMF.DT_REALIZADO, 'DD/MM/YYYY') || NVL(TO_CHAR(VCMF.HR_INICIAL,'HH24:MI:SS'), '00:00:00'),'DD/MM/YYYY HH24:MI:SS')) DT_ATEND,
                NVL(VCMF.CD_VERSAO_TISS,'3.05.00') NR_VER_TISS,
                NVL(IA.CD_TISS, 9) TP_IND_ACIDENTE,
                 --Customiza��o Unimed Sorocaba (Mois�s) (Dt_Ultima_Autoriz)
                      Case
                        When Vcmf.Cd_Excecao = 'E' Then
                         Nvl(g.Dt_Ultima_Autorizacao, g.Dt_Autorizacao)
                         
                         -- In�cio CH2207-5120 - ERRO PTU DT ULTIMA AUTORIZA��O REFATURAMENTO - Guia Externa
                         When (Vcmf.Tp_Conta = 'A' And 
                               Vcmf.Nr_Guia Is Null And                               
                                (Trunc(Sysdate) - Trunc(Min(Vcmf.Dt_Realizado))) >= 91) Then         
                            Custom.Fnc_Dt_Ultima_Autorizacao_Opme(p_Cd_Conta  => Vcmf.cd_conta_medica,
                                                                  p_Tp_Conta => 'A')
                         -- Fim CH2207-5120 - ERRO PTU DT ULTIMA AUTORIZA��O REFATURAMENTO - Guia Externa 
                      
                        When (Vcmf.Tp_Conta = 'A' And
                             (Trunc(Sysdate) -
                             Trunc(Min(Vcmf.Dt_Realizado))) >= 91) Then
                        
                         Custom.Fnc_Dt_Ultima_Autorizacao(p_Nr_Guia  => Vcmf.Nr_Guia,
                                                          p_Tp_Conta => 'A')
                        Else
                         Null
                      End Dt_Ultima_Autoriz,
                CASE
                  WHEN (LPAD(TAT.CD_TISS, 2, '0') IN ('04', '22')) THEN
                   NVL(TO_CHAR(VCMF.CD_TIPO_CONSULTA), '1')
                  ELSE
                   ''
                END TP_CONSULTA,
                VCMF.SN_LIMINAR ID_LIMINAR,
                Nvl(VCMF.dt_apresentacao_conta_medica, PC.DT_INCLUSAO) DT_PROTOCOLO,
                DECODE(VCMF.CD_PTU_REMESSA_RETORNO_A520, NULL, 'N', 'S') ID_AVISO,
                VCMF.CD_TIPO_ATENDIMENTO_INTERMED ID_CONTINUADO,
                Nvl(VCMF.dt_apresentacao_conta_medica, PC.DT_INCLUSAO) DT_CONHECIMENTO,
                DECODE(DECODE(TA.TP_GUIA, 'C', 1, 'S', 2, 'I', 3, 'H', 4),
                       3,
                       NVL(MA.CD_TISS, 12),
                       NULL) MOTIVO_ENCERRAM,
                CASE
                  WHEN VCMF.NR_GUIA_TEM IS NULL THEN
                   'S'
                  WHEN VCMF.NR_GUIA_TEM IS NOT NULL THEN
                   'N'
                END ID_GUIA_PRINCIPAL,
                       CASE
                        WHEN NVL(TAT.CD_TISS,'04') IN('02','03','08','09', '10') THEN
                          2
                        ELSE
                          NULL
                        END TP_REGCPL,
                'N' ID_GLOSA_TOTAL,
                DECODE(DECODE(TA.TP_GUIA, 'C', 1, 'S', 2, 'I', 3, 'H', 4),
                       1,
                       '',
                       4,
                       '',
                       DECODE(NVL(VCMF.TP_CARATER_INTERNACAO, 'E'),
                              'E',
                              1,
                              'U',
                              2)) TP_CARATER_ATEND,
                /*Prestador Executante*/
                VCMF.CD_UNIMED_EXECUTORA  CD_UNI_CONT_EXEC,
                /* Caruaru - Gabriel */
                DECODE(TP.CD_PTU_TIPO_PRESTADOR,'08',NULL,PSO.CD_PRESTADOR) CD_PREST_CONT_EXEC,
                SUBSTR(PSO.NM_PRESTADOR, 0, 60) NM_CONT_EXEC,
                TP.CD_PTU_TIPO_PRESTADOR TP_PRESTADOR_CONT_EXEC,
                DECODE(TP.TP_TIP_PRESTADOR,
                       6,
                       'S',
                       DECODE(PSO.TP_CREDENCIAMENTO, 'P', 'S', 'N')) ID_RECPROPRIO_CONT_EXEC,
                DECODE(PSO.TP_PRESTADOR, 'F', DECODE(LENGTH(PSO.NR_CPF_CGC),10,'0'||PSO.NR_CPF_CGC, PSO.NR_CPF_CGC), NULL) NR_CPF_CONT_EXEC,
                DECODE(PSO.TP_PRESTADOR, 'J', PSO.NR_CPF_CGC, NULL) NR_CNPJ_CONT_EXEC,
                NVL(PSO.CD_CNES, '9999999') NR_CNES_CONT_EXEC,
                PE.CD_MUNICIPIO CD_MUNICIPIO_CONT_EXEC,
                DECODE(PSO.TP_REDE_MIN, 'B', 1, 'E', 2, 'M', 3) TP_REDEMIN_CONT_EXEC,
                /*Prestador Solicitante*/
                DECODE(LENGTH(NVL(PREST_SOLI.NR_CPF_CGC, PSO.NR_CPF_CGC)),
                       14,
                       NULL,
                       NVL(DECODE(LENGTH(PREST_SOLI.NR_CPF_CGC),10,'0'||PREST_SOLI.NR_CPF_CGC,PREST_SOLI.NR_CPF_CGC), DECODE(LENGTH(PSO.NR_CPF_CGC),10,'0'||PSO.NR_CPF_CGC,PSO.NR_CPF_CGC))) NR_CPF_CONT_SOLICI, -- Validacao para checkar se o cpf tem 11 digitos
                DECODE(LENGTH(NVL(PREST_SOLI.NR_CPF_CGC, PSO.NR_CPF_CGC)),
                       14,
                       NVL(PREST_SOLI.NR_CPF_CGC, PSO.NR_CPF_CGC),
                       NULL) NR_CNPJ_CONT_SOLICI,
                VCMF.CD_UNIMED_EXECUTORA CD_UNI_CONT_SOLICI,
                NVL(PREST_SOLI.CD_PRESTADOR, PSO.CD_PRESTADOR) CD_PREST_CONT_SOLICI,
                SUBSTR(NVL(PREST_SOLI.NM_PRESTADOR, PSO.NM_PRESTADOR),0,60) NM_CONT_SOLICI,
                SubStr(NVL(VCMF.NM_PROF_SOLIC ,NVL(PREST_SOLI.NM_PRESTADOR, PSO.NM_PRESTADOR)),0,60) NM_PROF_SOLICI,
                Decode(LPad(Nvl(VCMF.DS_SIGLA_CONSELHO_PROF_SOLIC,
                                Nvl(G.CD_TISS_CONSELHO_PROF_SOL,
                                    Nvl(Nvl(CP_SOLI.CD_TISS,
                                            G_PAI.CD_TISS_CONSELHO_PROF_SOL),
                                        CP.CD_TISS))),
                            2,
                            '0'),
                       '02',
                       'COREN',
                       '01',
                       'CRESS',
                       '05',
                       'CREFITO',
                       '03',
                       'CRF',
                       '04',
                       'CREFONO',
                       '06',
                       'CRM',
                       '07',
                       'CRN',
                       '08',
                       'CRO',
                       '09',
                       'CRP',
                       '10',
                       'OUT',
					   '11','CRFA', '12','CRBM',
                       NULL) CD_CONSELHO_PROF_SOLICI,
                 --customiza��o Unimed Sorocaba (Mois�s) Remover acentua��o e deixar o valor 0 na frente quando necess�rio      
                 custom.fnc_ajusta_numero(Nvl(Vcmf.Nr_Conselho_Prof_Solic,
                                         Nvl(g.Nr_Reg_Conselho_Prof_Solic,
                                             Nvl(Nvl(Prest_Soli.Ds_Cod_Conselho,
                                                     g_Pai.Nr_Reg_Conselho_Prof_Solic),
                                    
                                                 Pso.Ds_Cod_Conselho)))) Nr_Conselho_Prof_Solici,
                FNC_RET_UF_TO_TISS(Nvl(VCMF.CD_UF_CONSELHO_PROF_SOLIC,
                    Nvl(G.UF_CONSELHO_PROF_SOLC,
                        NVL(Nvl(PREST_SOLI.UF_CONSELHO,
                                G_PAI.UF_CONSELHO_PROF_SOLC),
                            PSO.UF_CONSELHO)))) CD_UF_PROF_SOLICI,
                NVL(Nvl(VCMF.CD_CBOS_PROF_SOLIC,
                        Nvl(E_SOLI.NR_CBOS, E.NR_CBOS)),
                    999999) NR_CBO_PROF_SOLICI,
              /*Dados Para Refaturamento*/
              VCMF.CD_CONTA_MEDICA_ORIGEM                                                                      CD_CONTA_MEDICA_ORIGEM,
              VCMF.NR_LOTE_REFERENCIA                                                                          NR_LOTE_GLOSADO,
              VCMF.NR_NOTA_REFERENCIA                                                                          NR_NOTA_GLOSADA,
              NULL                                                                                             NR_DOC_1_GLOSADO,
              NULL                                                                                             NR_DOC_2_GLOSADO,
              VCMF.CD_MATRICULA                                                                                CD_MATRICULA,
              VCMF.NR_CARTEIRA_BENEFICIARIO                                                                    NR_CARTEIRA_BENEFICIARIO,
              VCMF.CD_MULTI_EMPRESA                                                                            CD_MULTI_EMPRESA,
              VCMF.CD_PTU_REMESSA_RETORNO_A520                                                                 CD_PTU_REMESSA_RETORNO_A520
  FROM DBAPS.V_CTAS_MEDICAS_FATURA VCMF
 INNER JOIN DBAPS.TIPO_ATENDIMENTO TA ON VCMF.CD_TIPO_ATENDIMENTO = TA.CD_TIPO_ATENDIMENTO
  LEFT JOIN DBAPS.TIPO_ATENDIMENTO_TISS TAT ON VCMF.CD_TIPO_ATENDIMENTO_TISS = TAT.CD_TIPO_ATENDIMENTO
  LEFT JOIN DBAPS.GUIA G  ON VCMF.NR_GUIA = G.NR_GUIA
  LEFT JOIN DBAPS.GUIA G_PAI ON Nvl(VCMF.NR_GUIA_TEM, G.NR_GUIA_TEM) = G_PAI.NR_GUIA
  LEFT JOIN DBAPS.PROTOCOLO_CTAMED PC ON VCMF.CD_PROTOCOLO_CTAMED = PC.CD_PROTOCOLO_CTAMED
  LEFT JOIN DBAPS.INDICADOR_ACIDENTE IA ON VCMF.CD_INDICADOR_ACIDENTE = IA.CD_INDICADOR_ACIDENTE
  LEFT JOIN DBAPS.MOTIVO_ALTA MA ON VCMF.CD_MOTIVO_ALTA = MA.CD_MOTIVO_ALTA
  LEFT JOIN DBAPS.PRESTADOR PREST_SOLI ON Nvl(VCMF.CD_PRESTADOR_SOLICITANTE,
           Nvl(G.CD_PRESTADOR, G_PAI.CD_PRESTADOR)) =
       PREST_SOLI.CD_PRESTADOR --) OR (G.CD_PRESTADOR = PREST_SOLI.CD_PRESTADOR) OR (G_PAI.CD_PRESTADOR = PREST_SOLI.CD_PRESTADOR))
  LEFT JOIN DBAPS.CONSELHO_PROFISSIONAL CP_SOLI ON PREST_SOLI.CD_CONSELHO_PROFISSIONAL =
       CP_SOLI.CD_CONSELHO_PROFISSIONAL
  LEFT JOIN DBAPS.PRESTADOR PSO  ON VCMF.CD_PRESTADOR_PRINCIPAL = PSO.CD_PRESTADOR
  LEFT JOIN DBAPS.CONSELHO_PROFISSIONAL CP  ON PSO.CD_CONSELHO_PROFISSIONAL = CP.CD_CONSELHO_PROFISSIONAL
  LEFT JOIN DBAPS.ESPECIALIDADE_PRESTADOR EP   ON PSO.CD_PRESTADOR = EP.CD_PRESTADOR
  LEFT JOIN DBAPS.ESPECIALIDADE_PRESTADOR EP_SOLI   ON PREST_SOLI.CD_PRESTADOR = EP_SOLI.CD_PRESTADOR
 INNER JOIN DBAPS.TIP_PRESTADOR TP ON PSO.CD_TIP_PRESTADOR = TP.CD_TIP_PRESTADOR
 INNER JOIN DBAPS.ESPECIALIDADE E ON EP.CD_ESPECIALIDADE = E.CD_ESPECIALIDADE
  LEFT JOIN DBAPS.PRESTADOR_ENDERECO PE ON PSO.CD_PRESTADOR = PE.CD_PRESTADOR
  LEFT JOIN DBAPS.ESPECIALIDADE E_SOLI ON Nvl(G.CD_ESPECIALIDADE_SOLICITANTE,
           Nvl(G_PAI.CD_ESPECIALIDADE_SOLICITANTE, EP_SOLI.CD_ESPECIALIDADE)) =  E_SOLI.CD_ESPECIALIDADE
  LEFT JOIN DBAPS.BENEFICIARIO_TRANSITO BT ON VCMF.NR_CARTEIRA_BENEFICIARIO = BT.CD_MATRICULA
  LEFT JOIN DBAPS.USUARIO U  ON VCMF.NR_CARTEIRA_BENEFICIARIO = U.CD_MAT_ALTERNATIVA
 WHERE TA.TP_GUIA IN ('S','L')
   AND PE.SN_PRINCIPAL = 'S' -- ENDERECO PRINCIPAL
   AND EP.SN_PRINCIPAL = 'S'
   AND (EP_SOLI.CD_ESPECIALIDADE IS NULL OR EP_SOLI.SN_PRINCIPAL = 'S')
   AND EP.CD_ESPECIALIDADE = (SELECT EP2.CD_ESPECIALIDADE
                                FROM DBAPS.ESPECIALIDADE_PRESTADOR EP2
                               WHERE EP.CD_PRESTADOR = EP2.CD_PRESTADOR
                                 AND EP2.SN_PRINCIPAL = 'S'
                                 AND ROWNUM = 1)
   AND (EP_SOLI.CD_ESPECIALIDADE IS NULL OR EP_SOLI.CD_ESPECIALIDADE =
       (SELECT EP2.CD_ESPECIALIDADE
           FROM DBAPS.ESPECIALIDADE_PRESTADOR EP2
          WHERE EP_SOLI.CD_PRESTADOR = EP2.CD_PRESTADOR
            AND EP2.SN_PRINCIPAL = 'S'
            AND ROWNUM = 1))
   AND VCMF.CD_MENS_CONTRATO = P_CD_MENS_CONTRATO
   AND (P_ID_AVISO = 'S'
        AND VCMF.CD_LOTE = P_CD_LOTE
        AND VCMF.CD_CONTA_MEDICA = P_CD_CONTA_MEDICA
         OR P_ID_AVISO = 'N')
 GROUP BY   VCMF.CD_FATURA,
              VCMF.CD_LOTE ,
                VCMF.CD_CONTA_MEDICA ,
                NVL(TO_CHAR(VCMF.NR_GUIA), VCMF.CD_GUIA_EXTERNA) ,
                NVL(TO_CHAR(VCMF.NR_GUIA_TEM), VCMF.CD_GUIA_EXTERNA),
                DECODE(VCMF.TP_BENEFICIARIO,'RE',SUBSTR(VCMF.NR_CARTEIRA_BENEFICIARIO, 1,3)/*'999'*/,VCMF.CD_UNIMED_ORIGEM),
                SUBSTR(DECODE(VCMF.TP_BENEFICIARIO,
                              'RE',
                              /*U.NR_CARTEIRA_RECIPROCIDADE*/
                              LPad(VCMF.NR_CARTEIRA_BENEFICIARIO,16,'0'),
                              LPad(VCMF.NR_CARTEIRA_BENEFICIARIO,16,'0')),
                       4,
                       16) ,
                NVL(NVL(VCMF.NM_BENEFICIARIO, BT.NM_SEGURADO),
                    'NAO INFORMADO') ,
                NVL(VCMF.SN_ATENDIMENTO_RN, 'N') ,
                CASE
                  WHEN TAT.CD_TISS IN
                       ('12', '14', '15', '16', '17', '18', '19', '20', '21') THEN -- SAUDE OCUPACIONAL
                   '9'
                  ELSE
                   '1'
                END ,
                CASE
                  WHEN VCMF.CD_EXCECAO = 'I' THEN
                   'I'
                  WHEN VCMF.SN_REFATURAR = 'S' AND VCMF.CD_EXCECAO = 'L' THEN
                   'L'
                  WHEN VCMF.SN_REFATURAR = 'S' AND VCMF.CD_EXCECAO <> 'L' THEN
                   'J'
                  WHEN VCMF.NR_SENHA_GAT IS NOT NULL THEN
                   'L'
                  WHEN (TA.TP_GUIA = 'H' AND VCMF.NR_GUIA_TEM IS NOT NULL) THEN
                   'L'
                  WHEN (G_PAI.SN_VALIDA_REST_CARENCIA = 'S') THEN
                   'L'
                  WHEN DECODE(VCMF.NR_GUIA, NULL, '0', 'L') = '0' THEN
                   '0'
                  WHEN DECODE(VCMF.NR_GUIA, NULL, '0', 'L') = 'L' THEN
                   'L'
                END ,
                TAT.CD_TISS,
                VCMF.CD_VERSAO_TISS ,
                NVL(IA.CD_PTU, 9) ,
                CASE
                  WHEN (LPAD(TAT.CD_TISS, 2, '0') IN ('04', '22')) THEN
                   NVL(TO_CHAR(VCMF.CD_TIPO_CONSULTA), '1')
                  ELSE
                   ''
                END ,
                VCMF.SN_LIMINAR ,
                VCMF.DT_APRESENTACAO_CONTA_MEDICA ,
                DECODE(VCMF.CD_PTU_REMESSA_RETORNO_A520, NULL, 'N', 'S') ,
                VCMF.CD_TIPO_ATENDIMENTO_INTERMED ,
                Nvl(VCMF.dt_apresentacao_conta_medica, PC.DT_INCLUSAO),
                DECODE(DECODE(TA.TP_GUIA, 'C', 1, 'S', 2, 'I', 3, 'H', 4),
                       3,
                       NVL(MA.CD_TISS, 12),
                       NULL) ,
                CASE
                  WHEN VCMF.NR_GUIA_TEM IS NULL THEN
                   'S'
                  WHEN VCMF.NR_GUIA_TEM IS NOT NULL THEN
                   'N'
                END ,
                CASE
                        WHEN NVL(TAT.CD_TISS,'04') IN('02','03','08','09', '10') THEN
                          2
                        ELSE
                          NULL
                        END,
                'N' ,
                DECODE(DECODE(TA.TP_GUIA, 'C', 1, 'S', 2, 'I', 3, 'H', 4),
                       1,
                       '',
                       4,
                       '',
                       DECODE(NVL(VCMF.TP_CARATER_INTERNACAO, 'E'),
                              'E',
                              1,
                              'U',
                              2)) ,
                /*Prestador Executante*/
                VCMF.CD_UNIMED_EXECUTORA ,
                /* Gabriel */
                DECODE(TP.CD_PTU_TIPO_PRESTADOR,
                      '08',
                      NULL,
                      PSO.CD_PRESTADOR),
                SUBSTR(PSO.NM_PRESTADOR, 0, 60) ,
                TP.CD_PTU_TIPO_PRESTADOR ,
                DECODE(TP.TP_TIP_PRESTADOR,
                       6,
                       'S',
                       DECODE(PSO.TP_CREDENCIAMENTO, 'P', 'S', 'N')) ,
                DECODE(PSO.TP_PRESTADOR, 'F', DECODE(LENGTH(PSO.NR_CPF_CGC),10,'0'||PSO.NR_CPF_CGC, PSO.NR_CPF_CGC), NULL),
                DECODE(PSO.TP_PRESTADOR, 'J', PSO.NR_CPF_CGC, NULL),
                NVL(PSO.CD_CNES, '9999999') ,
                PE.CD_MUNICIPIO ,
                DECODE(PSO.TP_REDE_MIN, 'B', 1, 'E', 2, 'M', 3) ,
                /*Prestador Solicitante*/
                DECODE(LENGTH(NVL(PREST_SOLI.NR_CPF_CGC, PSO.NR_CPF_CGC)),
                       14,
                       NULL,
                       NVL(DECODE(LENGTH(PREST_SOLI.NR_CPF_CGC),10,'0'||PREST_SOLI.NR_CPF_CGC,PREST_SOLI.NR_CPF_CGC), DECODE(LENGTH(PSO.NR_CPF_CGC),10,'0'||PSO.NR_CPF_CGC,PSO.NR_CPF_CGC))),
                DECODE(LENGTH(NVL(PREST_SOLI.NR_CPF_CGC, PSO.NR_CPF_CGC)),
                       14,
                       NVL(PREST_SOLI.NR_CPF_CGC, PSO.NR_CPF_CGC),
                       NULL) ,
                VCMF.CD_UNIMED_EXECUTORA ,
                NVL(PREST_SOLI.CD_PRESTADOR, PSO.CD_PRESTADOR) ,
                SUBSTR(NVL(PREST_SOLI.NM_PRESTADOR, PSO.NM_PRESTADOR),0,60) ,
                NVL(VCMF.NM_PROF_SOLIC ,NVL(PREST_SOLI.NM_PRESTADOR, PSO.NM_PRESTADOR)),
                Decode(LPad(Nvl(VCMF.DS_SIGLA_CONSELHO_PROF_SOLIC,
                                Nvl(G.CD_TISS_CONSELHO_PROF_SOL,
                                    Nvl(Nvl(CP_SOLI.CD_TISS,
                                            G_PAI.CD_TISS_CONSELHO_PROF_SOL),
                                        CP.CD_TISS))),
                            2,
                            '0'),
                       '02',
                       'COREN',
                       '01',
                       'CRESS',
                       '05',
                       'CREFITO',
                       '03',
                       'CRF',
                       '04',
                       'CREFONO',
                       '06',
                       'CRM',
                       '07',
                       'CRN',
                       '08',
                       'CRO',
                       '09',
                       'CRP',
                       '10',
                       'OUT',
						'11','CRFA', '12','CRBM',
                       NULL) ,
                Nvl(VCMF.NR_CONSELHO_PROF_SOLIC,
                    Nvl(G.NR_REG_CONSELHO_PROF_SOLIC,
                        NVL(Nvl(PREST_SOLI.DS_COD_CONSELHO,
                                G_PAI.NR_REG_CONSELHO_PROF_SOLIC),
                            PSO.DS_COD_CONSELHO))) ,
                FNC_RET_UF_TO_TISS(Nvl(VCMF.CD_UF_CONSELHO_PROF_SOLIC,
                    Nvl(G.UF_CONSELHO_PROF_SOLC,
                        NVL(Nvl(PREST_SOLI.UF_CONSELHO,
                                G_PAI.UF_CONSELHO_PROF_SOLC),
                            PSO.UF_CONSELHO)))),
                NVL(Nvl(VCMF.CD_CBOS_PROF_SOLIC,
                        Nvl(E_SOLI.NR_CBOS, E.NR_CBOS)),
                    999999),
                VCMF.CD_CONTA_MEDICA_ORIGEM,
                VCMF.NR_LOTE_REFERENCIA,
                VCMF.NR_NOTA_REFERENCIA,
                VCMF.CD_MATRICULA,
                VCMF.NR_CARTEIRA_BENEFICIARIO,
                VCMF.CD_MULTI_EMPRESA,
                VCMF.CD_PTU_REMESSA_RETORNO_A520,
                NVL(IA.CD_TISS, 9),
                G.DT_AUTORIZACAO,
                Custom.Fnc_Ajusta_Numero(Nvl(Vcmf.Nr_Conselho_Prof_Solic,
                    Nvl(g.Nr_Reg_Conselho_Prof_Solic,
                        Nvl(Nvl(Prest_Soli.Ds_Cod_Conselho,
                                g_Pai.Nr_Reg_Conselho_Prof_Solic),
                            Pso.Ds_Cod_Conselho)))),
                 Nvl(g.Dt_Ultima_Autorizacao, g.Dt_Autorizacao),
                 Vcmf.Cd_Excecao,
                 Vcmf.Tp_Conta,
                 Vcmf.Nr_Guia;
    rowPtuA500Sadt ROW_PTU_A500_SADT;
  BEGIN
    FOR r IN cGuiaSadt(PCD_MENS_CONTRATO,P_ID_AVISO,P_CD_LOTE,P_CD_CONTA_MEDICA) LOOP

      rowPtuA500Sadt.CD_FATURA                      := r.CD_FATURA;
      rowPtuA500Sadt.NR_LOTE_PRESTADOR              := r.NR_LOTE_PRESTADOR      ;
      rowPtuA500Sadt.NR_GUIA_TISS_PRESTADOR         := r.NR_GUIA_TISS_PRESTADOR ;
      rowPtuA500Sadt.NR_GUIA_TISS_OPERADORA         := r.NR_GUIA_TISS_OPERADORA ;
      rowPtuA500Sadt.NR_GUIA_TISS_PRINCIPAL         := r.NR_GUIA_TISS_PRINCIPAL ;
      rowPtuA500Sadt.CD_UNI_BENEF                   := r.CD_UNI_BENEF           ;
      rowPtuA500Sadt.ID_BENEF                       := r.ID_BENEF               ;
      rowPtuA500Sadt.NM_BENEF                       := DBAPS.PKG_PTU_BATCH.FNC_AJUSTA_DADO_PTU('ANS',r.NM_BENEF);
      rowPtuA500Sadt.ID_RN                          := r.ID_RN                  ;
      rowPtuA500Sadt.TP_PACIENTE                    := r.TP_PACIENTE            ;
      rowPtuA500Sadt.CD_EXCECAO                     := r.CD_EXCECAO             ;
      rowPtuA500Sadt.TP_ATENDIMENTO                 := r.TP_ATENDIMENTO         ;

      --rowPtuA500Sadt.DT_ATEND                       := r.DT_ATEND               ;
      rowPtuA500Sadt.DT_ULTIMA_AUTORIZ              := r.DT_ULTIMA_AUTORIZ      ;

      rowPtuA500Sadt.NR_VER_TISS                    := r.NR_VER_TISS            ;
      rowPtuA500Sadt.TP_IND_ACIDENTE                := r.TP_IND_ACIDENTE        ;
      rowPtuA500Sadt.TP_CONSULTA                    := r.TP_CONSULTA            ;
      rowPtuA500Sadt.ID_LIMINAR                     := r.ID_LIMINAR             ;
      rowPtuA500Sadt.DT_PROTOCOLO                   := r.DT_PROTOCOLO           ;
      rowPtuA500Sadt.ID_AVISO                       := r.ID_AVISO               ;
      rowPtuA500Sadt.ID_CONTINUADO                  := r.ID_CONTINUADO          ;
      rowPtuA500Sadt.DT_CONHECIMENTO                := r.DT_CONHECIMENTO        ;
      rowPtuA500Sadt.MOTIVO_ENCERRAM                := r.MOTIVO_ENCERRAM        ;
      rowPtuA500Sadt.ID_GUIA_PRINCIPAL              := r.ID_GUIA_PRINCIPAL      ;
      rowPtuA500Sadt.ID_GLOSA_TOTAL                 := r.ID_GLOSA_TOTAL         ;
      rowPtuA500Sadt.TP_CARATER_ATEND               := r.TP_CARATER_ATEND       ;
      rowPtuA500Sadt.CD_UNI_CONT_EXEC               := r.CD_UNI_CONT_EXEC       ;
      rowPtuA500Sadt.CD_PREST_CONT_EXEC             := r.CD_PREST_CONT_EXEC     ;
      rowPtuA500Sadt.NM_CONT_EXEC                   := DBAPS.PKG_PTU_BATCH.FNC_AJUSTA_DADO_PTU('ANS',r.NM_CONT_EXEC);
      rowPtuA500Sadt.TP_PRESTADOR_CONT_EXEC         := r.TP_PRESTADOR_CONT_EXEC ;
      rowPtuA500Sadt.ID_RECPROPRIO_CONT_EXEC        := r.ID_RECPROPRIO_CONT_EXEC;
      rowPtuA500Sadt.NR_CPF_CONT_EXEC               := r.NR_CPF_CONT_EXEC       ;
      rowPtuA500Sadt.NR_CNPJ_CONT_EXEC              := r.NR_CNPJ_CONT_EXEC      ;
      rowPtuA500Sadt.NR_CNES_CONT_EXEC              := r.NR_CNES_CONT_EXEC      ;
      rowPtuA500Sadt.CD_MUNICIPIO_CONT_EXEC         := DBAPS.FNC_CALCULA_CODIGO_IBGE(r.CD_MUNICIPIO_CONT_EXEC) ;
      rowPtuA500Sadt.TP_REDEMIN_CONT_EXEC           := r.TP_REDEMIN_CONT_EXEC   ;
      rowPtuA500Sadt.NR_CPF_CONT_SOLICI             := r.NR_CPF_CONT_SOLICI     ;
      rowPtuA500Sadt.NR_CNPJ_CONT_SOLICI            := r.NR_CNPJ_CONT_SOLICI    ;
      rowPtuA500Sadt.CD_UNI_CONT_SOLICI             := r.CD_UNI_CONT_SOLICI     ;
      rowPtuA500Sadt.CD_PREST_CONT_SOLICI           := r.CD_PREST_CONT_SOLICI   ;
      rowPtuA500Sadt.NM_CONT_SOLICI                 := DBAPS.PKG_PTU_BATCH.FNC_AJUSTA_DADO_PTU('ANS',r.NM_CONT_SOLICI);
      rowPtuA500Sadt.NM_PROF_SOLICI                 := DBAPS.PKG_PTU_BATCH.FNC_AJUSTA_DADO_PTU('ANS',r.NM_PROF_SOLICI);
      rowPtuA500Sadt.CD_CONSELHO_PROF_SOLICI        := r.CD_CONSELHO_PROF_SOLICI;
      rowPtuA500Sadt.NR_CONSELHO_PROF_SOLICI        := DBAPS.PKG_PTU_BATCH.FNC_AJUSTA_DADO_PTU('AN',r.NR_CONSELHO_PROF_SOLICI);
      rowPtuA500Sadt.CD_UF_PROF_SOLICI              := r.CD_UF_PROF_SOLICI      ;
      rowPtuA500Sadt.NR_CBO_PROF_SOLICI             := r.NR_CBO_PROF_SOLICI     ;
      rowPtuA500Sadt.CD_CONTA_MEDICA_ORIGEM         := r.CD_CONTA_MEDICA_ORIGEM;
      rowPtuA500Sadt.NR_LOTE_GLOSADO                := r.NR_LOTE_GLOSADO;
      rowPtuA500Sadt.NR_NOTA_GLOSADA                := r.NR_NOTA_GLOSADA;
      rowPtuA500Sadt.NR_DOC_1_GLOSADO               := r.NR_DOC_1_GLOSADO;
      rowPtuA500Sadt.NR_DOC_2_GLOSADO               := r.NR_DOC_2_GLOSADO;
      rowPtuA500Sadt.CD_MATRICULA                := r.CD_MATRICULA;
      rowPtuA500Sadt.NR_CARTEIRA_BENEFICIARIO    := r.NR_CARTEIRA_BENEFICIARIO;
      rowPtuA500Sadt.CD_MULTI_EMPRESA            := r.CD_MULTI_EMPRESA;
      rowPtuA500Sadt.CD_PTU_REMESSA_RETORNO_A520 := r.CD_PTU_REMESSA_RETORNO_A520;

      PIPE ROW(rowPtuA500Sadt);
    END LOOP;
    RETURN;
  END;

  FUNCTION GET_TABLE_PTU_A500_RES_INT(PCD_MENS_CONTRATO          IN NUMBER
                                      ,P_ID_AVISO                 IN VARCHAR2
                                      ,P_CD_LOTE                  IN NUMBER
                                      ,P_CD_CONTA_MEDICA          IN NUMBER) RETURN TABLE_PTU_A500_RES_INT PIPELINED IS
    CURSOR cGuiaResInt(P_CD_MENS_CONTRATO         NUMBER
                      ,P_ID_AVISO                 VARCHAR2
                      ,P_CD_LOTE                  NUMBER
                      ,P_CD_CONTA_MEDICA          NUMBER) IS
      SELECT DISTINCT /*Beneficiario*/
                DECODE(VCMF.TP_BENEFICIARIO,'RE',SUBSTR(VCMF.NR_CARTEIRA_BENEFICIARIO, 1,3),VCMF.CD_UNIMED_ORIGEM) CD_UNI_BENEF,
                SUBSTR(DECODE(VCMF.TP_BENEFICIARIO,
                              'RE',
                              /*U.NR_CARTEIRA_RECIPROCIDADE*/
                              LPad(VCMF.NR_CARTEIRA_BENEFICIARIO,16,'0'),
                              LPad(VCMF.NR_CARTEIRA_BENEFICIARIO,16,'0')),
                       4,
                       16) ID_BENEF,
                SUBSTR(NVL(NVL(VCMF.NM_BENEFICIARIO, BT.NM_SEGURADO), 'NAO INFORMADO'),1,25)                                  NM_BENEF,
                NVL(VCMF.SN_ATENDIMENTO_RN, 'N') ID_RN,
                CASE
                  WHEN TAT.CD_TISS IN
                       ('12', '14', '15', '16', '17', '18', '19', '20', '21') THEN -- SAUDE OCUPACIONAL
                   '9'
                  ELSE
                   '1'
                END TP_PACIENTE,
                /*Prestador Solicitante*/
                /*DECODE(LENGTH(NVL(PREST_SOLI.NR_CPF_CGC, PSO.NR_CPF_CGC)),
                       14,
                       NULL,
                       NVL(PREST_SOLI.NR_CPF_CGC, PSO.NR_CPF_CGC)) NR_CPF_CONT_SOLICI,*/
                
                      --Customiza��o Unimed Sorocaba (Mois�s) --> Nr_Cpf_Cont_Solici
                      --N�o estava considerando o "Zero" inicial.
                      /*Decode(Length(Nvl(Prest_Soli.Nr_Cpf_Cgc,
                                        Pso.Nr_Cpf_Cgc)),
                             14,
                             Null,
                             10,
                             '0' || Prest_Soli.Nr_Cpf_Cgc,
                             Prest_Soli.Nr_Cpf_Cgc) Nr_Cpf_Cont_Solici, */
                             
                Case When NVL(PREST_SOLI.CD_PRESTADOR, PSO.CD_PRESTADOR) = '0' Then
                  Null
                        
                      Else  
                      Decode(Length(Nvl(Prest_Soli.Nr_Cpf_Cgc,
                                        Pso.Nr_Cpf_Cgc)),
                             14,
                             Null,
                             10,
                             '0' || Prest_Soli.Nr_Cpf_Cgc,
                             Prest_Soli.Nr_Cpf_Cgc)
                              End Nr_Cpf_Cont_Solici,                  
                       
                DECODE(LENGTH(NVL(PREST_SOLI.NR_CPF_CGC, PSO.NR_CPF_CGC)),
                       14,
                       NVL(PREST_SOLI.NR_CPF_CGC, PSO.NR_CPF_CGC),
                       NULL) NR_CNPJ_CONT_SOLICI,
                VCMF.CD_UNIMED_EXECUTORA CD_UNI_CONT_SOLICI,
                NVL(PREST_SOLI.CD_PRESTADOR, PSO.CD_PRESTADOR) CD_PREST_CONT_SOLICI,
                
                Dbaps.Fnc_Remove_Acento(SubStr(NVL(PREST_SOLI.NM_PRESTADOR, PSO.NM_PRESTADOR),0,60)) NM_CONT_SOLICI,
                --profissional solicitante
                Dbaps.Fnc_Remove_Acento(SubStr(Nvl(G.NM_PROFISSIONAL_SOLICITANTE, NVL(PREST_SOLI.NM_PRESTADOR, PSO.NM_PRESTADOR)),0,60)) NM_PROF_SOLICI,
                Decode(LPad(Nvl(G.CD_TISS_CONSELHO_PROF_SOL,
                                    Nvl(Nvl(G_PAI.CD_TISS_CONSELHO_PROF_SOL,
                                            CP_SOLI.CD_TISS),
                                        CP.CD_TISS)),
                            2,
                            '0'),
                       '02',
                       'COREN',
                       '01',
                       'CRESS',
                       '05',
                       'CREFITO',
                       '03',
                       'CRF',
                       '04',
                       'CREFONO',
                       '06',
                       'CRM',
                       '07',
                       'CRN',
                       '08',
                       'CRO',
                       '09',
                       'CRP',
                       '10',
                       'OUT',
					   '11','CRFA', '12','CRBM',
                       NULL) CD_CONSELHO_PROF_SOLICI,
                 --Customiza��o Unimed Sorocaba (Mois�s) --> (Nr_Conselho_Prof_Solici)        
                      Custom.Fnc_Ajusta_Numero(Nvl(G.NR_REG_CONSELHO_PROF_SOLIC,
                        NVL(Nvl(PREST_SOLI.DS_COD_CONSELHO,
                                G_PAI.NR_REG_CONSELHO_PROF_SOLIC),
                            PSO.DS_COD_CONSELHO))) NR_CONSELHO_PROF_SOLICI,
                FNC_RET_UF_TO_TISS(Nvl(G.UF_CONSELHO_PROF_SOLC,
                        NVL(Nvl(PREST_SOLI.UF_CONSELHO,
                                G_PAI.UF_CONSELHO_PROF_SOLC),
                            PSO.UF_CONSELHO))) CD_UF_PROF_SOLICI,
                --especialidade prof solicitante
                Nvl(NVL(E_SOLI.NR_CBOS, E.NR_CBOS),999999) NR_CBO_PROF_SOLICI,
                /*Prestador Executante*/
                DECODE(TP.CD_PTU_TIPO_PRESTADOR,
                       '08',
                       NULL,
                       VCMF.CD_UNIMED_EXECUTORA) CD_UNI_CONT_EXEC,
                DECODE(TP.CD_PTU_TIPO_PRESTADOR,
                       '08',
                       NULL,
                       PSO.CD_PRESTADOR) CD_PREST_CONT_EXEC,
                SUBSTR(PSO.NM_PRESTADOR, 0, 100) NM_CONT_EXEC,
                TP.CD_PTU_TIPO_PRESTADOR TP_PRESTADOR_CONT_EXEC,
                DECODE(TP.TP_TIP_PRESTADOR,
                       6,
                       'S',
                       DECODE(PSO.TP_CREDENCIAMENTO, 'P', 'S', 'N')) ID_RECPROPRIO_CONT_EXEC,
                DECODE(PSO.TP_PRESTADOR, 'J', PSO.NR_CPF_CGC, NULL) NR_CNPJ_CONT_EXEC,
                NVL(PSO.CD_CNES, '9999999') NR_CNES_CONT_EXEC,
                PE.CD_MUNICIPIO CD_MUNICIPIO_CONT_EXEC,
                DECODE(PSO.TP_REDE_MIN, 'B', 1, 'E', 2, 'M', 3) TP_REDEMIN_CONT_EXEC,
                /*Dados InternacAo*/
                NVL(TAC.CD_PTU, 'A') TP_ACOMODACAO,
                DECODE(Nvl(TAC.CD_PTU, 'A'), 'A', 1, 'B', 2, 1) FT_MULT_AMB,
                DECODE(VCMF.TP_INTERNACAO,
                       'N',
                       1,
                       'C',
                       2,
                       'O',
                       3,
                       'P',
                       4,
                       'S',
                       5) TP_INTERNACAO,
                DECODE(RI.CD_TISS, '1', 1, '2', 2, '3', 3, 1) REG_INTERNACAO,
                DECODE(NVL(VCMF.TP_CARATER_INTERNACAO, 'E'), 'E', 1, 'U', 2) TP_CARATER_ATEND,
                DECODE(VCMF.CD_TIPO_FATURAMENTO,
                       'P',
                       2,
                       'F',
                       3,
                       'C',
                       4,
                       'T',
                       1,
                       NULL) TP_FATURAMENTO,
                MIN(VCMF.DT_ENTRADA) DT_INI_FATURAMENTO,
                VCMF.DT_SAIDA DT_FIM_FATURAMENTO,
                /*Dados Saida Intercacao*/
                NVL(IA.CD_TISS, 9)  TP_IND_ACIDENTE,
                NVL(MA.CD_TISS, 12) MOTIVO_ENCERRAM,
                VCMF.CD_CID        CD_CID,
                /*Dados Auditoria*/
                AM.NM_AUTORIZADOR              NM_MEDICO_AUDITOR, -- ESSA ESTRUTURA SERA CRIADA PARA CHAPECO
                AM.NR_CONSELHO_PROFISSIONAL    NR_CRM_AUDITOR,
                UF.CD_TISS                     CD_UF_CRM,
                AE.NM_AUTORIZADOR              NM_ENFER_AUDITOR,
                AE.NR_CONSELHO_PROFISSIONAL    NR_COREN_AUDITOR,
                UF.CD_TISS                     CD_UF_COREN,
                /*Dados Guia*/
                NVL(VCMF.CD_VERSAO_TISS,'3.05.00') NR_VER_TISS,
                VCMF.CD_LOTE NR_LOTE_PRESTADOR,
                 --Customiza��o Unimed Sorocaba (Mois�s) --> (Dt_Protocolo)
                      Vcmf.dt_apresentacao_conta_medica Dt_Protocolo,
                      -- Nvl(Pc.Dt_Inclusao, Vcmf.Dt_Apresentacao) Dt_Protocolo,
                      
                      --Customiza��o Unimed Sorocaba (Mois�s) --> (Dt_Conhecimento)
                      Nvl(Vcmf.dt_apresentacao_conta_medica,
                         Pc.Dt_Envio_Lote) Dt_Conhecimento,
                      --Nvl(Pc.Dt_Inclusao, Vcmf.Dt_Apresentacao) Dt_Conhecimento,
                VCMF.CD_CONTA_MEDICA NR_GUIA_TISS_PRESTADOR,
                Nvl(NVL(TO_CHAR(VCMF.NR_GUIA), VCMF.CD_GUIA_EXTERNA), SubStr(VCMF.CD_LOTE||'-'||VCMF.CD_CONTA_MEDICA,1,20)) NR_GUIA_TISS_OPERADORA,
                NVL(NVL(TO_CHAR(VCMF.NR_GUIA_TEM), VCMF.CD_GUIA_EXTERNA),TO_CHAR(VCMF.NR_GUIA)) NR_GUIA_TISS_PRINCIPAL,
                MIN(VCMF.DT_ENTRADA) DT_ATEND,
                 CASE
                        WHEN NVL(TAT.CD_TISS,'04') IN('02','03','08','09', '10') THEN
                          2
                        ELSE
                          NULL
                        END TP_REGCPL,
                VCMF.SN_LIMINAR ID_LIMINAR,
                VCMF.CD_TIPO_ATENDIMENTO_INTERMED ID_CONTINUADO,
                DECODE(VCMF.CD_PTU_REMESSA_RETORNO_A520, NULL, 'N', 'S') ID_AVISO,
                Case
                  When Vcmf.Cd_Excecao = 'E' And
                             Vcmf.Sn_Refaturar = 'N' Then
                         'E'
                  WHEN VCMF.CD_EXCECAO = 'I' THEN
                   'I'
                  WHEN VCMF.SN_REFATURAR = 'S' AND VCMF.CD_EXCECAO = 'L' THEN
                   'L'
                  WHEN VCMF.SN_REFATURAR = 'S' AND VCMF.CD_EXCECAO <> 'L' THEN
                   'J'
                  WHEN VCMF.NR_SENHA_GAT IS NOT NULL THEN
                   'L'
                  WHEN (G_PAI.SN_VALIDA_REST_CARENCIA = 'S') THEN
                   'L'
                  WHEN DECODE(VCMF.NR_GUIA, NULL, '0', 'L') = '0' THEN
                   '0'
                  WHEN DECODE(VCMF.NR_GUIA, NULL, '0', 'L') = 'L' THEN
                   'L'
                END CD_EXCECAO,
                'N' ID_GLOSA_TOTAL,
                --Customiza��o Unimed Sorocaba (Mois�s) --> (Dt_Ultima_Autoriz)
                      Case
                        When Vcmf.Cd_Excecao = 'E' Then
                         Nvl(g.Dt_Ultima_Autorizacao, g.Dt_Autorizacao)
                         
                         -- In�cio CH2207-5120 - ERRO PTU DT ULTIMA AUTORIZA��O REFATURAMENTO - Guia Externa
                         When (Vcmf.Tp_Conta = 'I' And 
                                Vcmf.Nr_Guia Is Null And
                                Vcmf.Nr_Guia_Tem Is Null And 
                                (Trunc(Sysdate) - Trunc(Min(Vcmf.Dt_Saida))) >= 91) Then
                            Custom.Fnc_Dt_Ultima_Autorizacao_Opme(p_Cd_Conta  => Vcmf.cd_conta_medica,
                                                                  p_Tp_Conta => 'I')
                         -- Fim CH2207-5120 - ERRO PTU DT ULTIMA AUTORIZA��O REFATURAMENTO - Guia Externa
                      
                        When (Vcmf.Tp_Conta = 'I' And
                             (Trunc(Sysdate) - Trunc(Min(Vcmf.Dt_Saida))) >= 91) Then
                         Custom.Fnc_Dt_Ultima_Autorizacao(p_Nr_Guia  => nvl(Vcmf.nr_guia_tem,Vcmf.Nr_Guia),
                                                          p_Tp_Conta => 'I')
                                                         
                         -- In�cio CH2207-5120 - ERRO PTU DT ULTIMA AUTORIZA��O REFATURAMENTO - Guia Externa
                         When (Vcmf.Tp_Conta = 'A' And 
                               Vcmf.Nr_Guia Is Null And                               
                                (Trunc(Sysdate) - Trunc(Min(Vcmf.Dt_Realizado))) >= 91) Then         
                            Custom.Fnc_Dt_Ultima_Autorizacao_Opme(p_Cd_Conta  => Vcmf.cd_conta_medica,
                                                                  p_Tp_Conta => 'A')
                         -- Fim CH2207-5120 - ERRO PTU DT ULTIMA AUTORIZA��O REFATURAMENTO - Guia Externa  
                      
                        When (Vcmf.Tp_Conta = 'A' And
                             (Trunc(Sysdate) -
                             Trunc(Min(Vcmf.Dt_Realizado))) >= 91) Then
                        
                         Custom.Fnc_Dt_Ultima_Autorizacao(p_Nr_Guia  => Vcmf.Nr_Guia,
                                                          p_Tp_Conta => 'A') --ACRESCENTADO EM 10/02/2022 por Mois�s, pegar a ultima autoriza��o da guia de inter
                      
                      /*  When Vcmf.Cd_Excecao <> 'E' and Vcmf.Tp_Conta = 'I' and vcmf.nr_guia is not null Then
                      CUSTOM.Fnc_Dt_Ultima_Autorizacao(P_nr_guia => vcmf.nr_guia)*/
                        Else
                         Null
                      End Dt_Ultima_Autoriz,
                      -- Nvl(g.Dt_Autorizacao, Vcmf.Dt_Realizado) Dt_Ultima_Autoriz,
                /*Dados Para Refaturamento*/
                VCMF.CD_CONTA_MEDICA_ORIGEM                                                                      CD_CONTA_MEDICA_ORIGEM,
                VCMF.NR_LOTE_REFERENCIA                                                                          NR_LOTE_GLOSADO,
                VCMF.NR_NOTA_REFERENCIA                                                                          NR_NOTA_GLOSADA,
                NULL                                                                                             NR_DOC_1_GLOSADO,
                NULL                                                                                             NR_DOC_2_GLOSADO,
                VCMF.CD_MATRICULA                                                                                CD_MATRICULA,
                VCMF.NR_CARTEIRA_BENEFICIARIO                                                                    NR_CARTEIRA_BENEFICIARIO,
                VCMF.CD_MULTI_EMPRESA                                                                            CD_MULTI_EMPRESA,
                VCMF.CD_PTU_REMESSA_RETORNO_A520                                                                 CD_PTU_REMESSA_RETORNO_A520
  FROM DBAPS.V_CTAS_MEDICAS_FATURA VCMF
 INNER JOIN DBAPS.TIPO_ATENDIMENTO TA
    ON VCMF.CD_TIPO_ATENDIMENTO = TA.CD_TIPO_ATENDIMENTO
  LEFT JOIN DBAPS.TIPO_ATENDIMENTO_TISS TAT
    ON VCMF.CD_TIPO_ATENDIMENTO_TISS = TAT.CD_TIPO_ATENDIMENTO
  LEFT JOIN DBAPS.GUIA G
    ON VCMF.NR_GUIA = G.NR_GUIA
  LEFT JOIN DBAPS.GUIA G_PAI
    ON Nvl(VCMF.NR_GUIA_TEM, G.NR_GUIA_TEM) = G_PAI.NR_GUIA
  LEFT JOIN DBAPS.PROTOCOLO_CTAMED PC
    ON VCMF.CD_PROTOCOLO_CTAMED = PC.CD_PROTOCOLO_CTAMED
  LEFT JOIN DBAPS.INDICADOR_ACIDENTE IA
    ON VCMF.CD_INDICADOR_ACIDENTE = IA.CD_INDICADOR_ACIDENTE
  LEFT JOIN DBAPS.MOTIVO_ALTA MA
    ON VCMF.CD_MOTIVO_ALTA = MA.CD_MOTIVO_ALTA
  LEFT JOIN DBAPS.PRESTADOR PREST_SOLI
    ON Nvl(VCMF.CD_PRESTADOR_SOLICITANTE,
          NVL(G.CD_PRESTADOR_SOLICITANTE,
            Nvl(G.CD_PRESTADOR, G_PAI.CD_PRESTADOR))) =
       PREST_SOLI.CD_PRESTADOR
  LEFT JOIN DBAPS.CONSELHO_PROFISSIONAL CP_SOLI
    ON PREST_SOLI.CD_CONSELHO_PROFISSIONAL =
       CP_SOLI.CD_CONSELHO_PROFISSIONAL
  LEFT JOIN DBAPS.PRESTADOR PSO
    ON VCMF.CD_PRESTADOR_PRINCIPAL = PSO.CD_PRESTADOR
  LEFT JOIN DBAPS.CONSELHO_PROFISSIONAL CP
    ON PSO.CD_CONSELHO_PROFISSIONAL = CP.CD_CONSELHO_PROFISSIONAL
  LEFT JOIN DBAPS.ESPECIALIDADE_PRESTADOR EP
    ON PSO.CD_PRESTADOR = EP.CD_PRESTADOR
  LEFT JOIN DBAPS.ESPECIALIDADE_PRESTADOR EP_SOLI
    ON PREST_SOLI.CD_PRESTADOR = EP_SOLI.CD_PRESTADOR
 INNER JOIN DBAPS.TIP_PRESTADOR TP
    ON PSO.CD_TIP_PRESTADOR = TP.CD_TIP_PRESTADOR
 INNER JOIN DBAPS.ESPECIALIDADE E
    ON EP.CD_ESPECIALIDADE = E.CD_ESPECIALIDADE
  LEFT JOIN DBAPS.PRESTADOR_ENDERECO PE
    ON PSO.CD_PRESTADOR = PE.CD_PRESTADOR
  LEFT JOIN DBAPS.ESPECIALIDADE E_SOLI
    ON Nvl(G.CD_ESPECIALIDADE_SOLICITANTE,
           Nvl(G_PAI.CD_ESPECIALIDADE_SOLICITANTE, EP_SOLI.CD_ESPECIALIDADE)) =
       E_SOLI.CD_ESPECIALIDADE
  LEFT JOIN DBAPS.BENEFICIARIO_TRANSITO BT
    ON VCMF.NR_CARTEIRA_BENEFICIARIO = BT.CD_MATRICULA
  LEFT JOIN DBAPS.USUARIO U
    ON VCMF.NR_CARTEIRA_BENEFICIARIO = U.CD_MAT_ALTERNATIVA
  LEFT JOIN DBAPS.REGIME_INTERNACAO RI
    ON VCMF.CD_REGIME_INTERNACAO = RI.CD_REGIME_INTERNACAO
  LEFT JOIN DBAPS.AUTORIZADOR AM
    ON VCMF.CD_AUDITORIA_MEDICA = AM.CD_AUTORIZADOR
  LEFT JOIN DBAPS.AUTORIZADOR AE
    ON VCMF.CD_AUDITORIA_ENFERMAGEM = AE.CD_AUTORIZADOR
  LEFT JOIN DBAPS.TIP_ACOMODACAO TAC
    ON VCMF.TP_ACOMODACAO = TAC.CD_TIP_ACOMODACAO
  LEFT JOIN DBAPS.UNIDADE_FEDERACAO UF
    ON AE.CD_UF_CONSELHO_PROFISISONAL = UF.CD_UF
 WHERE TA.TP_GUIA IN ('I', 'P')
   AND PE.SN_PRINCIPAL = 'S' -- ENDERECO PRINCIPAL
   AND EP.SN_PRINCIPAL = 'S'
   AND (EP_SOLI.CD_ESPECIALIDADE IS NULL OR EP_SOLI.SN_PRINCIPAL = 'S')
   AND EP.CD_ESPECIALIDADE = (SELECT EP2.CD_ESPECIALIDADE
                                FROM DBAPS.ESPECIALIDADE_PRESTADOR EP2
                               WHERE EP.CD_PRESTADOR = EP2.CD_PRESTADOR
                                 AND EP2.SN_PRINCIPAL = 'S'
                                 AND ROWNUM = 1)
   AND (EP_SOLI.CD_ESPECIALIDADE IS NULL OR
       EP_SOLI.CD_ESPECIALIDADE =
       (SELECT EP2.CD_ESPECIALIDADE
           FROM DBAPS.ESPECIALIDADE_PRESTADOR EP2
          WHERE EP_SOLI.CD_PRESTADOR = EP2.CD_PRESTADOR
            AND EP2.SN_PRINCIPAL = 'S'
            AND ROWNUM = 1))
   And VCMF.CD_MENS_CONTRATO = P_CD_MENS_CONTRATO
   AND (P_ID_AVISO = 'S'
        AND VCMF.CD_LOTE = P_CD_LOTE
        AND VCMF.CD_CONTA_MEDICA = P_CD_CONTA_MEDICA
         OR P_ID_AVISO = 'N')
 GROUP BY /*Beneficiario*/
          DECODE(VCMF.TP_BENEFICIARIO,'RE',SUBSTR(VCMF.NR_CARTEIRA_BENEFICIARIO, 1,3),VCMF.CD_UNIMED_ORIGEM),
                SUBSTR(DECODE(VCMF.TP_BENEFICIARIO,
                              'RE',
                              /*U.NR_CARTEIRA_RECIPROCIDADE*/
                              LPad(VCMF.NR_CARTEIRA_BENEFICIARIO,16,'0'),
                              LPad(VCMF.NR_CARTEIRA_BENEFICIARIO,16,'0')),
                       4,
                       16),
          SUBSTR(NVL(NVL(VCMF.NM_BENEFICIARIO, BT.NM_SEGURADO), 'NAO INFORMADO'),1,25),
          NVL(VCMF.SN_ATENDIMENTO_RN, 'N'),
          CASE
            WHEN TAT.CD_TISS IN
                 ('12', '14', '15', '16', '17', '18', '19', '20', '21') THEN
             '9'
            ELSE
             '1'
          END,
          /*Prestador Solicitante*/
          DECODE(LENGTH(NVL(PREST_SOLI.NR_CPF_CGC, PSO.NR_CPF_CGC)),
                 14,
                 NULL,
                 NVL(PREST_SOLI.NR_CPF_CGC, PSO.NR_CPF_CGC)),
          DECODE(LENGTH(NVL(PREST_SOLI.NR_CPF_CGC, PSO.NR_CPF_CGC)),
                 14,
                 NVL(PREST_SOLI.NR_CPF_CGC, PSO.NR_CPF_CGC),
                 NULL),
          VCMF.CD_UNIMED_EXECUTORA,
          NVL(PREST_SOLI.CD_PRESTADOR, PSO.CD_PRESTADOR),
          NVL(PREST_SOLI.NM_PRESTADOR, PSO.NM_PRESTADOR),
          Nvl(G.NM_PROFISSIONAL_SOLICITANTE, NVL(PREST_SOLI.NM_PRESTADOR, PSO.NM_PRESTADOR)),
          Decode(LPad(Nvl(G.CD_TISS_CONSELHO_PROF_SOL,
                              Nvl(Nvl(G_PAI.CD_TISS_CONSELHO_PROF_SOL,
                                      CP_SOLI.CD_TISS),
                                  CP.CD_TISS)),
                      2,
                      '0'),
                 '02',
                 'COREN',
                 '01',
                 'CRESS',
                 '05',
                 'CREFITO',
                 '03',
                 'CRF',
                 '04',
                 'CREFONO',
                 '06',
                 'CRM',
                 '07',
                 'CRN',
                 '08',
                 'CRO',
                 '09',
                 'CRP',
                 '10',
                 'OUT',
				 '11','CRFA', '12','CRBM',
                 NULL),
               Custom.Fnc_Ajusta_Numero(Nvl(G.NR_REG_CONSELHO_PROF_SOLIC,
                  NVL(Nvl(PREST_SOLI.DS_COD_CONSELHO,
                          G_PAI.NR_REG_CONSELHO_PROF_SOLIC),
                      PSO.DS_COD_CONSELHO))),
          FNC_RET_UF_TO_TISS(Nvl(G.UF_CONSELHO_PROF_SOLC,
                        NVL(Nvl(PREST_SOLI.UF_CONSELHO,
                                G_PAI.UF_CONSELHO_PROF_SOLC),
                            PSO.UF_CONSELHO))),
          Nvl(NVL(E_SOLI.NR_CBOS, E.NR_CBOS),999999),
          -- Prestador Executante
          DECODE(TP.CD_PTU_TIPO_PRESTADOR,
                 '08',
                 NULL,
                 VCMF.CD_UNIMED_EXECUTORA),
          DECODE(TP.CD_PTU_TIPO_PRESTADOR, '08', NULL, PSO.CD_PRESTADOR),
          SUBSTR(PSO.NM_PRESTADOR, 0, 100),
          TP.CD_PTU_TIPO_PRESTADOR,
          DECODE(TP.TP_TIP_PRESTADOR,
                 6,
                 'S',
                 DECODE(PSO.TP_CREDENCIAMENTO, 'P', 'S', 'N')),
          DECODE(PSO.TP_PRESTADOR, 'J', PSO.NR_CPF_CGC, NULL),
          NVL(PSO.CD_CNES, '9999999'),
          PE.CD_MUNICIPIO,
          DECODE(PSO.TP_REDE_MIN, 'B', 1, 'E', 2, 'M', 3),
          /*Dados InternacAo*/
          NVL(TAC.CD_PTU, 'A'),
          DECODE(Nvl(TAC.CD_PTU, 'A'), 'A', 1, 'B', 2, 1),
          DECODE(VCMF.TP_INTERNACAO, 'N', 1, 'C', 2, 'O', 3, 'P', 4, 'S', 5),
          DECODE(RI.CD_TISS, '1', 1, '2', 2, '3', 3, 1),
          DECODE(NVL(VCMF.TP_CARATER_INTERNACAO, 'E'), 'E', 1, 'U', 2),
          DECODE(VCMF.CD_TIPO_FATURAMENTO,
                 'P',
                 2,
                 'F',
                 3,
                 'C',
                 4,
                 'T',
                 1,
                 NULL),
          VCMF.DT_SAIDA,
          /*Dados Saida Intercacao*/
          NVL(IA.CD_PTU, 9),
          NVL(MA.CD_TISS, 12),
          VCMF.CD_CID,
          /*Dados Auditoria*/
          AM.NM_AUTORIZADOR, -- ESSA ESTRUTURA SERA CRIADA PARA CHAPECO
          AM.NR_CONSELHO_PROFISSIONAL,
          UF.CD_TISS,
          AE.NM_AUTORIZADOR,
          AE.NR_CONSELHO_PROFISSIONAL,
          UF.CD_TISS,
          /*Dados Guia*/
          VCMF.CD_VERSAO_TISS,
          VCMF.CD_LOTE,
          Vcmf.dt_apresentacao_conta_medica,
          Nvl(Vcmf.dt_apresentacao_conta_medica,Pc.Dt_Envio_Lote),
          VCMF.CD_CONTA_MEDICA,
          NVL(TO_CHAR(VCMF.NR_GUIA), VCMF.CD_GUIA_EXTERNA),
          NVL(NVL(TO_CHAR(VCMF.NR_GUIA_TEM), VCMF.CD_GUIA_EXTERNA),TO_CHAR(VCMF.NR_GUIA)),
           CASE
                        WHEN NVL(TAT.CD_TISS,'04') IN('02','03','08','09', '10') THEN
                          2
                        ELSE
                          NULL
                        END,
          VCMF.SN_LIMINAR,
          VCMF.CD_TIPO_ATENDIMENTO_INTERMED,
          DECODE(VCMF.CD_PTU_REMESSA_RETORNO_A520, NULL, 'N', 'S'),
          Case
                  When Vcmf.Cd_Excecao = 'E' And
                             Vcmf.Sn_Refaturar = 'N' Then
                         'E'
                  WHEN VCMF.CD_EXCECAO = 'I' THEN
                   'I'
                  WHEN VCMF.SN_REFATURAR = 'S' AND VCMF.CD_EXCECAO = 'L' THEN
                   'L'
                  WHEN VCMF.SN_REFATURAR = 'S' AND VCMF.CD_EXCECAO <> 'L' THEN
                   'J'
                  WHEN VCMF.NR_SENHA_GAT IS NOT NULL THEN
                   'L'
                  WHEN (G_PAI.SN_VALIDA_REST_CARENCIA = 'S') THEN
                   'L'
                  WHEN DECODE(VCMF.NR_GUIA, NULL, '0', 'L') = '0' THEN
                   '0'
                  WHEN DECODE(VCMF.NR_GUIA, NULL, '0', 'L') = 'L' THEN
                   'L'
                END,
          'N',
          VCMF.CD_CONTA_MEDICA_ORIGEM,
          VCMF.NR_LOTE_REFERENCIA,
          VCMF.NR_NOTA_REFERENCIA,
          VCMF.CD_MATRICULA,
          VCMF.NR_CARTEIRA_BENEFICIARIO,
          VCMF.CD_MULTI_EMPRESA,
          VCMF.CD_PTU_REMESSA_RETORNO_A520,
          VCMF.DT_ENTRADA,
          PSO.TP_PRESTADOR,
          PSO.NR_CPF_CGC,
          NVL(IA.CD_TISS, 9),
           -- Nvl(g.Dt_Autorizacao, Vcmf.Dt_Realizado),
          Nvl(g.Dt_Ultima_Autorizacao, g.Dt_Autorizacao),
          Prest_Soli.Nr_Cpf_Cgc,
          Pc.Dt_Envio_Lote,
          Vcmf.Cd_Excecao,
          Vcmf.Sn_Refaturar,
          Vcmf.Tp_Conta,
          Vcmf.Nr_Guia,
          Vcmf.nr_guia_tem;
    rowPtuA500ResInt ROW_PTU_A500_RES_INT;
  BEGIN
    FOR r IN cGuiaResInt(PCD_MENS_CONTRATO,P_ID_AVISO,P_CD_LOTE,P_CD_CONTA_MEDICA) LOOP

      rowPtuA500ResInt.CD_UNI_BENEF                      :=  r.CD_UNI_BENEF;
      rowPtuA500ResInt.ID_BENEF                          :=  r.ID_BENEF;
      rowPtuA500ResInt.NM_BENEF                          :=  DBAPS.PKG_PTU_BATCH.FNC_AJUSTA_DADO_PTU('ANS',r.NM_BENEF);
      rowPtuA500ResInt.ID_RN                             :=  r.ID_RN;
      rowPtuA500ResInt.TP_PACIENTE                       :=  r.TP_PACIENTE;
      rowPtuA500ResInt.NR_CPF_CONT_SOLICI                :=  r.NR_CPF_CONT_SOLICI;
      rowPtuA500ResInt.NR_CNPJ_CONT_SOLICI               :=  r.NR_CNPJ_CONT_SOLICI;
      rowPtuA500ResInt.CD_UNI_CONT_SOLICI                :=  r.CD_UNI_CONT_SOLICI;
      rowPtuA500ResInt.CD_PREST_CONT_SOLICI              :=  r.CD_PREST_CONT_SOLICI;
      rowPtuA500ResInt.NM_CONT_SOLICI                    :=  r.NM_CONT_SOLICI;
      rowPtuA500ResInt.NM_PROF_SOLICI                    :=  r.NM_PROF_SOLICI;
      rowPtuA500ResInt.CD_CONSELHO_PROF_SOLICI           :=  r.CD_CONSELHO_PROF_SOLICI;
      rowPtuA500ResInt.NR_CONSELHO_PROF_SOLICI           :=   DBAPS.PKG_PTU_BATCH.FNC_AJUSTA_DADO_PTU('AN',r.NR_CONSELHO_PROF_SOLICI);
      rowPtuA500ResInt.CD_UF_PROF_SOLICI                 :=  r.CD_UF_PROF_SOLICI;
      rowPtuA500ResInt.NR_CBO_PROF_SOLICI                :=  r.NR_CBO_PROF_SOLICI;
      rowPtuA500ResInt.CD_UNI_CONT_EXEC                  :=  r.CD_UNI_CONT_EXEC;
      rowPtuA500ResInt.CD_PREST_CONT_EXEC                :=  r.CD_PREST_CONT_EXEC;
      rowPtuA500ResInt.NM_CONT_EXEC                      :=  r.NM_CONT_EXEC;
      rowPtuA500ResInt.TP_PRESTADOR_CONT_EXEC            :=  r.TP_PRESTADOR_CONT_EXEC;
      rowPtuA500ResInt.ID_RECPROPRIO_CONT_EXEC           :=  r.ID_RECPROPRIO_CONT_EXEC;
      rowPtuA500ResInt.NR_CNPJ_CONT_EXEC                 :=  r.NR_CNPJ_CONT_EXEC;
      rowPtuA500ResInt.NR_CNES_CONT_EXEC                 :=  r.NR_CNES_CONT_EXEC;
      rowPtuA500ResInt.CD_MUNICIPIO_CONT_EXEC            :=  DBAPS.FNC_CALCULA_CODIGO_IBGE(r.CD_MUNICIPIO_CONT_EXEC);
      rowPtuA500ResInt.TP_REDEMIN_CONT_EXEC              :=  r.TP_REDEMIN_CONT_EXEC;
      rowPtuA500ResInt.TP_ACOMODACAO                     :=  r.TP_ACOMODACAO;
      rowPtuA500ResInt.FT_MULT_AMB                       :=  r.FT_MULT_AMB;
      rowPtuA500ResInt.TP_INTERNACAO                     :=  r.TP_INTERNACAO;
      rowPtuA500ResInt.REG_INTERNACAO                    :=  r.REG_INTERNACAO;
      rowPtuA500ResInt.TP_CARATER_ATEND                  :=  r.TP_CARATER_ATEND;
      rowPtuA500ResInt.TP_FATURAMENTO                    :=  r.TP_FATURAMENTO;
      rowPtuA500ResInt.DT_INI_FATURAMENTO                :=  r.DT_INI_FATURAMENTO;
      rowPtuA500ResInt.DT_FIM_FATURAMENTO                :=  r.DT_FIM_FATURAMENTO;
      rowPtuA500ResInt.TP_IND_ACIDENTE                   :=  r.TP_IND_ACIDENTE;
      rowPtuA500ResInt.MOTIVO_ENCERRAM                   :=  r.MOTIVO_ENCERRAM;
      rowPtuA500ResInt.CD_CID                            :=  r.CD_CID;
      rowPtuA500ResInt.NM_MEDICO_AUDITOR                 :=  r.NM_MEDICO_AUDITOR;
      rowPtuA500ResInt.NR_CRM_AUDITOR                    :=  r.NR_CRM_AUDITOR;
      rowPtuA500ResInt.CD_UF_CRM                         :=  r.CD_UF_CRM;
      rowPtuA500ResInt.NM_ENFER_AUDITOR                  :=  r.NM_ENFER_AUDITOR;
      rowPtuA500ResInt.NR_COREN_AUDITOR                  :=  r.NR_COREN_AUDITOR;
      rowPtuA500ResInt.CD_UF_COREN                       :=  r.CD_UF_COREN;
      rowPtuA500ResInt.NR_VER_TISS                       :=  r.NR_VER_TISS;
      rowPtuA500ResInt.NR_LOTE_PRESTADOR                 :=  r.NR_LOTE_PRESTADOR;
      rowPtuA500ResInt.DT_PROTOCOLO                      :=  r.DT_PROTOCOLO;
      rowPtuA500ResInt.DT_CONHECIMENTO                   :=  r.DT_CONHECIMENTO;
      rowPtuA500ResInt.NR_GUIA_TISS_PRESTADOR            :=  r.NR_GUIA_TISS_PRESTADOR;
      rowPtuA500ResInt.NR_GUIA_TISS_OPERADORA            :=  r.NR_GUIA_TISS_OPERADORA;
      rowPtuA500ResInt.NR_GUIA_TISS_PRINCIPAL            :=  r.NR_GUIA_TISS_PRINCIPAL;
      rowPtuA500ResInt.DT_ATEND                          :=  r.DT_ATEND;
      rowPtuA500ResInt.ID_LIMINAR                        :=  r.ID_LIMINAR;
      rowPtuA500ResInt.ID_CONTINUADO                     :=  r.ID_CONTINUADO;
      rowPtuA500ResInt.ID_AVISO                          :=  r.ID_AVISO;
      rowPtuA500ResInt.CD_EXCECAO                        :=  r.CD_EXCECAO;
      rowPtuA500ResInt.ID_GLOSA_TOTAL                    :=  r.ID_GLOSA_TOTAL;
      rowPtuA500ResInt.DT_ULTIMA_AUTORIZ                 :=  r.DT_ULTIMA_AUTORIZ;
      rowPtuA500ResInt.CD_CONTA_MEDICA_ORIGEM            := r.CD_CONTA_MEDICA_ORIGEM;
      rowPtuA500ResInt.NR_LOTE_GLOSADO                   := r.NR_LOTE_GLOSADO;
      rowPtuA500ResInt.NR_NOTA_GLOSADA                   := r.NR_NOTA_GLOSADA;
      rowPtuA500ResInt.NR_DOC_1_GLOSADO                  := r.NR_DOC_1_GLOSADO;
      rowPtuA500ResInt.NR_DOC_2_GLOSADO                  := r.NR_DOC_2_GLOSADO;
      rowPtuA500ResInt.CD_MATRICULA                := r.CD_MATRICULA;
      rowPtuA500ResInt.NR_CARTEIRA_BENEFICIARIO    := r.NR_CARTEIRA_BENEFICIARIO;
      rowPtuA500ResInt.CD_MULTI_EMPRESA            := r.CD_MULTI_EMPRESA;
      rowPtuA500ResInt.CD_PTU_REMESSA_RETORNO_A520 := r.CD_PTU_REMESSA_RETORNO_A520;

      PIPE ROW(rowPtuA500ResInt);
    END LOOP;
    RETURN;
  END;

  FUNCTION GET_TABLE_PTU_A500_HONO(PCD_MENS_CONTRATO          IN NUMBER
                                  ,P_ID_AVISO                 IN VARCHAR2
                                  ,P_CD_LOTE                  IN NUMBER
                                  ,P_CD_CONTA_MEDICA          IN NUMBER) RETURN TABLE_PTU_A500_HONO PIPELINED IS
    CURSOR cGuiaHono(P_CD_MENS_CONTRATO         NUMBER
                    ,P_ID_AVISO                 VARCHAR2
                    ,P_CD_LOTE                  NUMBER
                    ,P_CD_CONTA_MEDICA          NUMBER) IS
      SELECT DISTINCT /*Beneficiario*/
                DECODE(VCMF.TP_BENEFICIARIO,'RE',SUBSTR(VCMF.NR_CARTEIRA_BENEFICIARIO, 1,3),VCMF.CD_UNIMED_ORIGEM) CD_UNI_BENEF,
                SUBSTR(DECODE(VCMF.TP_BENEFICIARIO,
                              'RE',
                              /*U.NR_CARTEIRA_RECIPROCIDADE*/
                              LPad(VCMF.NR_CARTEIRA_BENEFICIARIO,16,'0'),
                              LPad(VCMF.NR_CARTEIRA_BENEFICIARIO,16,'0')),
                       4,
                       16) ID_BENEF,
                SUBSTR(NVL(NVL(VCMF.NM_BENEFICIARIO, BT.NM_SEGURADO), 'NAO INFORMADO'),1,25)                                  NM_BENEF,
                NVL(VCMF.SN_ATENDIMENTO_RN, 'N') ID_RN,
                CASE
                  WHEN TAT.CD_TISS IN
                       ('12', '14', '15', '16', '17', '18', '19', '20', '21') THEN -- SAUDE OCUPACIONAL
                   '9'
                  ELSE
                   '1'
                END TP_PACIENTE,
                /*Dados Hospital*/
                DECODE(TP.CD_PTU_TIPO_PRESTADOR,
                       '08',
                       NULL,
                       VCMF.CD_UNIMED_EXECUTORA) CD_UNI_CONT_HOSP,
                DECODE(TP.CD_PTU_TIPO_PRESTADOR,
                       '08',
                       NULL,
                       Nvl(PRSLT.CD_PRESTADOR,PSO.CD_PRESTADOR)) CD_PREST_CONT_HOSP,
                Nvl(SUBSTR(PRSLT.NM_PRESTADOR, 0, 100),SUBSTR(PSO.NM_PRESTADOR, 0, 100)) NM_CONT_HOSP,
                Nvl(PRSLT.NR_CPF_CGC,PSO.NR_CPF_CGC) NR_CNPJ_CONT_HOSP,
                Nvl(PRSLT.CD_CNES,NVL(PSO.CD_CNES, '9999999')) NR_CNES_CONT_HOSP,
                /*Dados Executante*/
                DECODE(TP.CD_PTU_TIPO_PRESTADOR,
                       '08',
                       NULL,
                       VCMF.CD_UNIMED_EXECUTORA) CD_UNI_CONT_EXEC,
                DECODE(TP.CD_PTU_TIPO_PRESTADOR,
                       '08',
                       NULL,
                       PREST_EXEC.CD_PRESTADOR) CD_PREST_CONT_EXEC,
                SUBSTR(PREST_EXEC.NM_PRESTADOR, 0, 100) NM_CONT_EXEC,
                /*DECODE(PREST_EXEC.TP_PRESTADOR,
                       'F',
                       PREST_EXEC.NR_CPF_CGC,
                       NULL) NR_CPF_CONT_EXEC,*/
                 --Customiza��o Unimed Sorocaba (Mois�s) --> (Nr_Cpf_Cont_Exec)
                      Decode(Length(Decode(Prest_Exec.Tp_Prestador,
                                           'F',
                                           Prest_Exec.Nr_Cpf_Cgc,
                                           Null)),
                             10,
                             '0' || Prest_Exec.Nr_Cpf_Cgc,
                             Prest_Exec.Nr_Cpf_Cgc) Nr_Cpf_Cont_Exec,      
                       
                DECODE(PREST_EXEC.TP_PRESTADOR,
                       'J',
                       PREST_EXEC.NR_CPF_CGC,
                       NULL) NR_CNPJ_CONT_EXEC,
                NVL(PREST_EXEC.CD_CNES, '9999999') NR_CNES_CONT_EXEC,
                TP.CD_PTU_TIPO_PRESTADOR TP_PRESTADOR_CONT_EXEC,
                PE.CD_MUNICIPIO CD_MUNICIPIO_CONT_EXEC,
                DECODE(TP.TP_TIP_PRESTADOR,
                       6,
                       'S',
                       DECODE(PREST_EXEC.TP_CREDENCIAMENTO, 'P', 'S', 'N')) ID_RECPROPRIO_CONT_EXEC,
                DECODE(PREST_EXEC.TP_REDE_MIN, 'B', 1, 'E', 2, 'M', 3) TP_REDEMIN_CONT_EXEC,
                /*Data Faturamento*/
                VCMF.DT_ENTRADA DT_INI_FATURAMENTO,
                VCMF.DT_SAIDA DT_FIM_FATURAMENTO,
                /*Dados Guia*/
                NVL(VCMF.CD_VERSAO_TISS,'3.05.00') NR_VER_TISS,
                VCMF.CD_LOTE NR_LOTE_PRESTADOR,
                -- Customiza��o Unimed Sorocaba (Mois�s) --> (Dt_Protocolo e Dt_Conhecimento)  
                      Vcmf.dt_apresentacao_conta_medica Dt_Protocolo,
                      Nvl(Vcmf.dt_apresentacao_conta_medica,
                          Pc.Dt_Envio_Lote) Dt_Conhecimento,
                      
                      /*Nvl(Pc.Dt_Inclusao, Vcmf.Dt_Apresentacao) Dt_Protocolo,
                      Nvl(Pc.Dt_Inclusao, Vcmf.Dt_Apresentacao) Dt_Conhecimento, */
                VCMF.CD_CONTA_MEDICA NR_GUIA_TISS_PRESTADOR,
                Nvl(NVL(TO_CHAR(VCMF.NR_GUIA), VCMF.CD_GUIA_EXTERNA), SubStr(VCMF.CD_LOTE||'-'||VCMF.CD_CONTA_MEDICA,1,20)) NR_GUIA_TISS_OPERADORA,
                NVL(NVL(TO_CHAR(VCMF.NR_GUIA_TEM), VCMF.CD_GUIA_EXTERNA),TO_CHAR(VCMF.NR_GUIA)) NR_GUIA_TISS_PRINCIPAL,
                VCMF.DT_ENTRADA DT_ATEND,
                --MIN(TO_DATE(TO_CHAR(VCMF.DT_ATENDIMENTO, 'DD/MM/YYYY') || NVL(TO_CHAR(VCMF.HR_INICIAL,'HH24:MI:SS'), '00:00:00'),'DD/MM/YYYY HH24:MI:SS')) DT_ATEND,
                 CASE
                        WHEN NVL(TAT.CD_TISS,'04') IN('02','03','08','09', '10') THEN
                          2
                        ELSE
                          NULL
                        END TP_REGCPL,
                VCMF.SN_LIMINAR ID_LIMINAR,
                VCMF.CD_TIPO_ATENDIMENTO_INTERMED ID_CONTINUADO,
                DECODE(VCMF.CD_PTU_REMESSA_RETORNO_A520, NULL, 'N', 'S') ID_AVISO,
                CASE
                  WHEN VCMF.CD_EXCECAO = 'I' THEN
                   'I'
                  WHEN VCMF.SN_REFATURAR = 'S' AND VCMF.CD_EXCECAO = 'L' THEN
                   'L'
                  WHEN VCMF.SN_REFATURAR = 'S' AND VCMF.CD_EXCECAO <> 'L' THEN
                   'J'
                  WHEN VCMF.NR_SENHA_GAT IS NOT NULL THEN
                   'L'
                  WHEN (TA.TP_GUIA = 'H' AND VCMF.NR_GUIA_TEM IS NOT NULL) THEN
                   'L'
                  WHEN (G_PAI.SN_VALIDA_REST_CARENCIA = 'S') THEN
                   'L'
                  WHEN DECODE(VCMF.NR_GUIA, NULL, '0', 'L') = '0' THEN
                   '0'
                  WHEN DECODE(VCMF.NR_GUIA, NULL, '0', 'L') = 'L' THEN
                   'L'
                END CD_EXCECAO,
                'N' ID_GLOSA_TOTAL,
               -- Nvl(G.DT_AUTORIZACAO, VCMF.DT_ENTRADA) DT_ULTIMA_AUTORIZ,  
                 Null Dt_Ultima_Autoriz,
                /*Dados Para Refaturamento*/
                VCMF.CD_CONTA_MEDICA_ORIGEM                                                                      CD_CONTA_MEDICA_ORIGEM,
                VCMF.NR_LOTE_REFERENCIA                                                                          NR_LOTE_GLOSADO,
                VCMF.NR_NOTA_REFERENCIA                                                                          NR_NOTA_GLOSADA,
                NULL                                                                                             NR_DOC_1_GLOSADO,
                NULL                                                                                             NR_DOC_2_GLOSADO,
                VCMF.CD_MATRICULA                                                                                CD_MATRICULA,
                VCMF.NR_CARTEIRA_BENEFICIARIO                                                                    NR_CARTEIRA_BENEFICIARIO,
                VCMF.CD_MULTI_EMPRESA                                                                            CD_MULTI_EMPRESA,
                VCMF.CD_PTU_REMESSA_RETORNO_A520                                                                 CD_PTU_REMESSA_RETORNO_A520
  FROM DBAPS.V_CTAS_MEDICAS_FATURA VCMF
 INNER JOIN DBAPS.TIPO_ATENDIMENTO TA
    ON VCMF.CD_TIPO_ATENDIMENTO = TA.CD_TIPO_ATENDIMENTO
  LEFT JOIN DBAPS.TIPO_ATENDIMENTO_TISS TAT
    ON VCMF.CD_TIPO_ATENDIMENTO_TISS = TAT.CD_TIPO_ATENDIMENTO
  LEFT JOIN DBAPS.GUIA G
    ON VCMF.NR_GUIA = G.NR_GUIA
  LEFT JOIN DBAPS.GUIA G_PAI
    ON Nvl(VCMF.NR_GUIA_TEM, G.NR_GUIA_TEM) = G_PAI.NR_GUIA
  LEFT JOIN DBAPS.PROTOCOLO_CTAMED PC
    ON VCMF.CD_PROTOCOLO_CTAMED = PC.CD_PROTOCOLO_CTAMED
  LEFT JOIN DBAPS.INDICADOR_ACIDENTE IA
    ON VCMF.CD_INDICADOR_ACIDENTE = IA.CD_INDICADOR_ACIDENTE
  LEFT JOIN DBAPS.MOTIVO_ALTA MA
    ON VCMF.CD_MOTIVO_ALTA = MA.CD_MOTIVO_ALTA
  LEFT JOIN DBAPS.PRESTADOR PREST_EXEC
    ON Nvl(VCMF.CD_PRESTADOR_PTU, Nvl(VCMF.CD_PRESTADOR, Nvl(G.CD_PRESTADOR, G_PAI.CD_PRESTADOR))) =
       PREST_EXEC.CD_PRESTADOR
  LEFT JOIN DBAPS.CONSELHO_PROFISSIONAL CP_SOLI
    ON PREST_EXEC.CD_CONSELHO_PROFISSIONAL =
       CP_SOLI.CD_CONSELHO_PROFISSIONAL
  LEFT JOIN DBAPS.PRESTADOR PSO
    ON VCMF.CD_PRESTADOR_PRINCIPAL = PSO.CD_PRESTADOR
  LEFT JOIN DBAPS.CONSELHO_PROFISSIONAL CP
    ON PSO.CD_CONSELHO_PROFISSIONAL = CP.CD_CONSELHO_PROFISSIONAL
  LEFT JOIN DBAPS.ESPECIALIDADE_PRESTADOR EP
    ON PSO.CD_PRESTADOR = EP.CD_PRESTADOR
  LEFT JOIN DBAPS.ESPECIALIDADE_PRESTADOR EP_SOLI
    ON PREST_EXEC.CD_PRESTADOR = EP_SOLI.CD_PRESTADOR
 INNER JOIN DBAPS.TIP_PRESTADOR TP
    ON PSO.CD_TIP_PRESTADOR = TP.CD_TIP_PRESTADOR
 INNER JOIN DBAPS.ESPECIALIDADE E
    ON EP.CD_ESPECIALIDADE = E.CD_ESPECIALIDADE
  LEFT JOIN DBAPS.PRESTADOR_ENDERECO PE
    ON PSO.CD_PRESTADOR = PE.CD_PRESTADOR
  LEFT JOIN DBAPS.ESPECIALIDADE E_SOLI
    ON Nvl(G.CD_ESPECIALIDADE_SOLICITANTE,
           Nvl(G_PAI.CD_ESPECIALIDADE_SOLICITANTE, EP_SOLI.CD_ESPECIALIDADE)) =
       E_SOLI.CD_ESPECIALIDADE
  LEFT JOIN DBAPS.BENEFICIARIO_TRANSITO BT
    ON VCMF.NR_CARTEIRA_BENEFICIARIO = BT.CD_MATRICULA
  LEFT JOIN DBAPS.USUARIO U
    ON VCMF.NR_CARTEIRA_BENEFICIARIO = U.CD_MAT_ALTERNATIVA
  LEFT JOIN DBAPS.REGIME_INTERNACAO RI
    ON VCMF.CD_REGIME_INTERNACAO = RI.CD_REGIME_INTERNACAO
  LEFT JOIN DBAPS.AUTORIZADOR AM
    ON VCMF.CD_AUDITORIA_MEDICA = AM.CD_AUTORIZADOR
  LEFT JOIN DBAPS.AUTORIZADOR AE
    ON VCMF.CD_AUDITORIA_ENFERMAGEM = AE.CD_AUTORIZADOR
  LEFT JOIN DBAPS.TIP_ACOMODACAO TAC
    ON VCMF.TP_ACOMODACAO = TAC.CD_TIP_ACOMODACAO
  LEFT JOIN DBAPS.Lote LT
    ON VCMF.CD_LOTE = LT.CD_LOTE
  LEFT JOIN DBAPS.PRESTADOR PRSLT
    ON LT.CD_PRESTADOR = PRSLT.CD_PRESTADOR
 WHERE TA.TP_GUIA = 'H'
   AND PE.SN_PRINCIPAL = 'S' -- ENDERECO PRINCIPAL
   AND EP.SN_PRINCIPAL = 'S'
   AND (EP_SOLI.CD_ESPECIALIDADE IS NULL OR EP_SOLI.SN_PRINCIPAL = 'S')
   AND EP.CD_ESPECIALIDADE = (SELECT EP2.CD_ESPECIALIDADE
                                FROM DBAPS.ESPECIALIDADE_PRESTADOR EP2
                               WHERE EP.CD_PRESTADOR = EP2.CD_PRESTADOR
                                 AND EP2.SN_PRINCIPAL = 'S'
                                 AND ROWNUM = 1)
   AND (EP_SOLI.CD_ESPECIALIDADE IS NULL OR
       EP_SOLI.CD_ESPECIALIDADE =
       (SELECT EP2.CD_ESPECIALIDADE
           FROM DBAPS.ESPECIALIDADE_PRESTADOR EP2
          WHERE EP_SOLI.CD_PRESTADOR = EP2.CD_PRESTADOR
            AND EP2.SN_PRINCIPAL = 'S'
            AND ROWNUM = 1))
   And VCMF.CD_MENS_CONTRATo = P_CD_MENS_CONTRATO
   AND (P_ID_AVISO = 'S'
        AND VCMF.CD_LOTE = P_CD_LOTE
        AND VCMF.CD_CONTA_MEDICA = P_CD_CONTA_MEDICA
         OR P_ID_AVISO = 'N')
 GROUP BY DECODE(VCMF.TP_BENEFICIARIO,'RE',SUBSTR(VCMF.NR_CARTEIRA_BENEFICIARIO, 1,3),VCMF.CD_UNIMED_ORIGEM),
                SUBSTR(DECODE(VCMF.TP_BENEFICIARIO,
                              'RE',
                              /*U.NR_CARTEIRA_RECIPROCIDADE*/
                              LPad(VCMF.NR_CARTEIRA_BENEFICIARIO,16,'0'),
                              LPad(VCMF.NR_CARTEIRA_BENEFICIARIO,16,'0')),
                       4,
                       16),
          NVL(NVL(VCMF.NM_BENEFICIARIO, BT.NM_SEGURADO), 'NAO INFORMADO'),
          NVL(VCMF.SN_ATENDIMENTO_RN, 'N'),
          CASE
            WHEN TAT.CD_TISS IN
                 ('12', '14', '15', '16', '17', '18', '19', '20', '21') THEN -- SAUDE OCUPACIONAL
             '9'
            ELSE
             '1'
          END,
          /*Dados Hospital*/
          DECODE(TP.CD_PTU_TIPO_PRESTADOR,
                 '08',
                 NULL,
                 VCMF.CD_UNIMED_EXECUTORA),
          DECODE(TP.CD_PTU_TIPO_PRESTADOR, '08', NULL, Nvl(PRSLT.CD_PRESTADOR,PSO.CD_PRESTADOR)),
          Nvl(SUBSTR(PRSLT.NM_PRESTADOR, 0, 100),SUBSTR(PSO.NM_PRESTADOR, 0, 100)),
          Nvl(PRSLT.NR_CPF_CGC,PSO.NR_CPF_CGC),
          Nvl(PRSLT.CD_CNES,NVL(PSO.CD_CNES, '9999999')),
          /*Dados Executante*/
          DECODE(TP.CD_PTU_TIPO_PRESTADOR,
                 '08',
                 NULL,
                 VCMF.CD_UNIMED_EXECUTORA),
          DECODE(TP.CD_PTU_TIPO_PRESTADOR,
                 '08',
                 NULL,
                 PREST_EXEC.CD_PRESTADOR),
          SUBSTR(PREST_EXEC.NM_PRESTADOR, 0, 100),
          DECODE(PREST_EXEC.TP_PRESTADOR,
                       'F',
                       PREST_EXEC.NR_CPF_CGC,
                       NULL),
          DECODE(PREST_EXEC.TP_PRESTADOR,
                       'J',
                       PREST_EXEC.NR_CPF_CGC,
                       NULL),
          NVL(PREST_EXEC.CD_CNES, '9999999'),
          TP.CD_PTU_TIPO_PRESTADOR,
          PE.CD_MUNICIPIO,
          DECODE(TP.TP_TIP_PRESTADOR,
                 6,
                 'S',
                 DECODE(PREST_EXEC.TP_CREDENCIAMENTO, 'P', 'S', 'N')),
          DECODE(PREST_EXEC.TP_REDE_MIN, 'B', 1, 'E', 2, 'M', 3),
          /*Data Faturamento*/
          VCMF.DT_ENTRADA,
          VCMF.DT_SAIDA,
          /*Dados Guia*/
          VCMF.CD_VERSAO_TISS,
          VCMF.CD_LOTE,
          Vcmf.dt_apresentacao_conta_medica,
          Nvl(Vcmf.dt_apresentacao_conta_medica,Pc.Dt_Envio_Lote),
          VCMF.CD_CONTA_MEDICA,
          NVL(TO_CHAR(VCMF.NR_GUIA), VCMF.CD_GUIA_EXTERNA),
          NVL(NVL(TO_CHAR(VCMF.NR_GUIA_TEM), VCMF.CD_GUIA_EXTERNA),TO_CHAR(VCMF.NR_GUIA)),
           CASE
                        WHEN NVL(TAT.CD_TISS,'04') IN('02','03','08','09', '10') THEN
                          2
                        ELSE
                          NULL
                        END,
          VCMF.SN_LIMINAR,
          VCMF.CD_TIPO_ATENDIMENTO_INTERMED,
          DECODE(VCMF.CD_PTU_REMESSA_RETORNO_A520, NULL, 'N', 'S'),
          CASE
            WHEN VCMF.CD_EXCECAO = 'I' THEN
             'I'
            WHEN VCMF.SN_REFATURAR = 'S' AND VCMF.CD_EXCECAO = 'L' THEN
             'L'
            WHEN VCMF.SN_REFATURAR = 'S' AND VCMF.CD_EXCECAO <> 'L' THEN
             'J'
            WHEN VCMF.NR_SENHA_GAT IS NOT NULL THEN
             'L'
            WHEN (TA.TP_GUIA = 'H' AND VCMF.NR_GUIA_TEM IS NOT NULL) THEN
             'L'
            WHEN (G_PAI.SN_VALIDA_REST_CARENCIA = 'S') THEN
             'L'
            WHEN DECODE(VCMF.NR_GUIA, NULL, '0', 'L') = '0' THEN
             '0'
            WHEN DECODE(VCMF.NR_GUIA, NULL, '0', 'L') = 'L' THEN
             'L'
          END,
          'N',
          VCMF.CD_CONTA_MEDICA_ORIGEM,
          VCMF.NR_LOTE_REFERENCIA,
          VCMF.NR_NOTA_REFERENCIA,
          VCMF.CD_MATRICULA,
          VCMF.NR_CARTEIRA_BENEFICIARIO,
          VCMF.CD_MULTI_EMPRESA,
          VCMF.CD_PTU_REMESSA_RETORNO_A520,
           --Nvl(g.Dt_Autorizacao, Vcmf.Dt_Realizado),
                Decode(Length(Decode(Prest_Exec.Tp_Prestador,
                                     'F',
                                     Prest_Exec.Nr_Cpf_Cgc,
                                     Null)),
                       10,
                       '0' || Prest_Exec.Nr_Cpf_Cgc,
                       Prest_Exec.Nr_Cpf_Cgc),
                        Nvl(Pc.Dt_Envio_Lote,
                          Vcmf.Dt_Apresentacao_Conta_Medica);
    rowPtuA500Hono ROW_PTU_A500_HONO;
  BEGIN
    FOR r IN cGuiaHono(PCD_MENS_CONTRATO,P_ID_AVISO,P_CD_LOTE,P_CD_CONTA_MEDICA) LOOP

      rowPtuA500Hono.CD_UNI_BENEF       := r.CD_UNI_BENEF;
      rowPtuA500Hono.ID_BENEF         := r.ID_BENEF;
      rowPtuA500Hono.NM_BENEF          := DBAPS.PKG_PTU_BATCH.FNC_AJUSTA_DADO_PTU('ANS',r.NM_BENEF);
      rowPtuA500Hono.ID_RN          := r.ID_RN;
      rowPtuA500Hono.TP_PACIENTE        := r.TP_PACIENTE;
      rowPtuA500Hono.CD_UNI_CONT_HOSP     := r.CD_UNI_CONT_HOSP;
      rowPtuA500Hono.CD_PREST_CONT_HOSP   := r.CD_PREST_CONT_HOSP;
      rowPtuA500Hono.NM_CONT_HOSP       := r.NM_CONT_HOSP;
      rowPtuA500Hono.NR_CNPJ_CONT_HOSP    := r.NR_CNPJ_CONT_HOSP;
      rowPtuA500Hono.NR_CNES_CONT_HOSP    := r.NR_CNES_CONT_HOSP;
      rowPtuA500Hono.CD_UNI_CONT_EXEC     := r.CD_UNI_CONT_EXEC;
      rowPtuA500Hono.CD_PREST_CONT_EXEC   := r.CD_PREST_CONT_EXEC;
      rowPtuA500Hono.NM_CONT_EXEC       := r.NM_CONT_EXEC;
      rowPtuA500Hono.NR_CPF_CONT_EXEC     := r.NR_CPF_CONT_EXEC;
      rowPtuA500Hono.NR_CNPJ_CONT_EXEC    := r.NR_CNPJ_CONT_EXEC;
      rowPtuA500Hono.NR_CNES_CONT_EXEC    := r.NR_CNES_CONT_EXEC;
      rowPtuA500Hono.TP_PRESTADOR_CONT_EXEC := r.TP_PRESTADOR_CONT_EXEC;
      rowPtuA500Hono.CD_MUNICIPIO_CONT_EXEC := DBAPS.FNC_CALCULA_CODIGO_IBGE(r.CD_MUNICIPIO_CONT_EXEC);
      rowPtuA500Hono.ID_RECPROPRIO_CONT_EXEC  := r.ID_RECPROPRIO_CONT_EXEC;
      rowPtuA500Hono.TP_REDEMIN_CONT_EXEC   := r.TP_REDEMIN_CONT_EXEC;
      rowPtuA500Hono.DT_INI_FATURAMENTO   := r.DT_INI_FATURAMENTO;
      rowPtuA500Hono.DT_FIM_FATURAMENTO   := r.DT_FIM_FATURAMENTO;
      rowPtuA500Hono.NR_VER_TISS        := r.NR_VER_TISS;
      rowPtuA500Hono.NR_LOTE_PRESTADOR    := r.NR_LOTE_PRESTADOR;
      rowPtuA500Hono.DT_PROTOCOLO       := r.DT_PROTOCOLO;
      rowPtuA500Hono.DT_CONHECIMENTO      := r.DT_CONHECIMENTO;
      rowPtuA500Hono.NR_GUIA_TISS_PRESTADOR := r.NR_GUIA_TISS_PRESTADOR;
      rowPtuA500Hono.NR_GUIA_TISS_OPERADORA := r.NR_GUIA_TISS_OPERADORA;
      rowPtuA500Hono.NR_GUIA_TISS_PRINCIPAL := r.NR_GUIA_TISS_PRINCIPAL;
      rowPtuA500Hono.DT_ATEND         := r.DT_ATEND;
      rowPtuA500Hono.ID_LIMINAR       := r.ID_LIMINAR;
      rowPtuA500Hono.ID_CONTINUADO      := r.ID_CONTINUADO;
      rowPtuA500Hono.ID_AVISO         := r.ID_AVISO;
      rowPtuA500Hono.CD_EXCECAO       := r.CD_EXCECAO;
      rowPtuA500Hono.ID_GLOSA_TOTAL     := r.ID_GLOSA_TOTAL;
      rowPtuA500Hono.DT_ULTIMA_AUTORIZ        := r.DT_ULTIMA_AUTORIZ;
      rowPtuA500Hono.CD_CONTA_MEDICA_ORIGEM            := r.CD_CONTA_MEDICA_ORIGEM;
      rowPtuA500Hono.NR_LOTE_GLOSADO                   := r.NR_LOTE_GLOSADO;
      rowPtuA500Hono.NR_NOTA_GLOSADA                   := r.NR_NOTA_GLOSADA;
      rowPtuA500Hono.NR_DOC_1_GLOSADO                  := r.NR_DOC_1_GLOSADO;
      rowPtuA500Hono.NR_DOC_2_GLOSADO                  := r.NR_DOC_2_GLOSADO;
      rowPtuA500Hono.CD_MATRICULA                := r.CD_MATRICULA;
      rowPtuA500Hono.NR_CARTEIRA_BENEFICIARIO    := r.NR_CARTEIRA_BENEFICIARIO;
      rowPtuA500Hono.CD_MULTI_EMPRESA            := r.CD_MULTI_EMPRESA;
      rowPtuA500Hono.CD_PTU_REMESSA_RETORNO_A520 := r.CD_PTU_REMESSA_RETORNO_A520;

      PIPE ROW(rowPtuA500Hono);
    END LOOP;
    RETURN;
  END;

  Function Get_Table_Ptu_A500_Compl(Pcd_Mens_Contrato In Number,
                                    Pcd_Lote          In Number,
                                    Pcd_Conta_Medica  In Number)
    Return Table_Ptu_A500_Compl
    Pipelined Is
  
    Cursor Cverificaatendimento Is
      Select Nvl(Tat.Cd_Tiss, '04') Cd_Tiss
        From Dbaps.v_Ctas_Medicas_Fatura Vcmf,
             Dbaps.Tipo_Atendimento_Tiss Tat
       Where Vcmf.Cd_Tipo_Atendimento_Tiss = Tat.Cd_Tipo_Atendimento(+)
         And Vcmf.Cd_Lote = Pcd_Lote
         And Vcmf.Cd_Conta_Medica = Pcd_Conta_Medica;
         
     -- Cursores TESTE US -- Contingencia PCR
     Cursor cProcedimentoPCR Is
      Select 'S'
        From Dbaps.v_Ctas_Medicas_Fatura Vcmf
       Where Vcmf.Cd_Lote = Pcd_Lote
         And Vcmf.Cd_Conta_Medica = Pcd_Conta_Medica
         And vcmf.cd_procedimento In ('40314618', '40324788', '40324796');   
         
    Cursor Ctextoindicacao(Plinha Number) Is
    Select Texto
      From (Select a.Sintoma || ', ' || b.Sintoma  || ', ' || c.sintoma Texto, Rownum Linha
              From Temp_Indicao_Clinica_Pcr a, Temp_Indicao_Clinica_Pcr b, Temp_Indicao_Clinica_Pcr c
              Where a.sintoma <> b.sintoma
              And c.sintoma <> a.sintoma
              And c.sintoma <> b.sintoma)
     Where Linha = Plinha
       And Rownum = 1;
       
    -- Fim Cursores TESTE US -- Contingencia PCR
  
    Cursor Ccomplemento Is
    /*Select Nvl(Tp_Reg_Cpl, '2') Tp_Reg_Cpl,
                         Dbaps.Pkg_Ptu_Batch.Fnc_Ajusta_Dado_Ptu('ANS', Nm_Desc_Cpl) Nm_Desc_Cpl
                    From (Select '1' Tp_Reg_Cpl,
                                 Nvl(g.Ds_Diagnostico, Vcmf.Ds_Indicacao_Clinica) Nm_Desc_Cpl
                            From Dbaps.v_Ctas_Medicas_Fatura Vcmf, Dbaps.Guia g
                           Where Vcmf.Nr_Guia = g.Nr_Guia(+)
                             And Nvl(Vcmf.Cd_Mens_Contrato, 0) =
                                 Nvl(Pcd_Mens_Contrato, Nvl(Vcmf.Cd_Mens_Contrato, 0))
                             And Vcmf.Cd_Lote = Pcd_Lote
                             And Vcmf.Cd_Conta_Medica = Pcd_Conta_Medica
                             And Nvl(g.Ds_Diagnostico, Vcmf.Ds_Indicacao_Clinica) Is Not Null
                          Union
                          Select '2' Tp_Reg_Cpl, Vcmf.Ds_Observacao_Conta Nm_Desc_Cpl
                            From Dbaps.v_Ctas_Medicas_Fatura Vcmf,
                                 Dbaps.Guia                  g,
                                 Dbaps.Tipo_Atendimento      Ta
                           Where Vcmf.Nr_Guia = g.Nr_Guia(+)
                             And Nvl(Vcmf.Cd_Mens_Contrato, 0) =
                                 Nvl(Pcd_Mens_Contrato, Nvl(Vcmf.Cd_Mens_Contrato, 0))
                             And Vcmf.Cd_Lote = Pcd_Lote
                             And Vcmf.Cd_Conta_Medica = Pcd_Conta_Medica
                             And Vcmf.Ds_Observacao_Conta Is Not Null
                          Union
                          Select '3' Tp_Reg_Cpl, g.Ds_Justificativa_Tecnica Nm_Desc_Cpl
                            From Dbaps.v_Ctas_Medicas_Fatura Vcmf, Dbaps.Guia g
                           Where Vcmf.Nr_Guia = g.Nr_Guia(+)
                             And Nvl(Vcmf.Cd_Mens_Contrato, 0) =
                                 Nvl(Pcd_Mens_Contrato, Nvl(Vcmf.Cd_Mens_Contrato, 0))
                             And Vcmf.Cd_Lote = Pcd_Lote
                             And Vcmf.Cd_Conta_Medica = Pcd_Conta_Medica
                             And g.Ds_Justificativa_Tecnica Is Not Null
                          Union
                          Select '4' Tp_Reg_Cpl, g.Ds_Especificacao_Material Nm_Desc_Cpl
                            From Dbaps.v_Ctas_Medicas_Fatura Vcmf, Dbaps.Guia g
                           Where Vcmf.Nr_Guia = g.Nr_Guia(+)
                             And Nvl(Vcmf.Cd_Mens_Contrato, 0) =
                                 Nvl(Pcd_Mens_Contrato, Nvl(Vcmf.Cd_Mens_Contrato, 0))
                             And Vcmf.Cd_Lote = Pcd_Lote
                             And Vcmf.Cd_Conta_Medica = Pcd_Conta_Medica
                             And g.Ds_Especificacao_Material Is Not Null)
                   Order By Tp_Reg_Cpl;*/
    
    /*Customiza��o Unimed Sorocaba (Mois�s) */
      Select Tp_Reg_Cpl,
             Dbaps.Pkg_Ptu_Batch.Fnc_Ajusta_Dado_Ptu('ANS', Nm_Desc_Cpl) Nm_Desc_Cpl
        From (Select Distinct '1' Tp_Reg_Cpl,
                     coalesce(g.Cd_Cid, Vcmf.Cd_Cid,
                             Vcmf.Ds_Indicacao_Clinica,
                         g.Ds_Diagnostico, vcmf.cd_indicacao_clinica) Nm_Desc_Cpl
                From -- Mois�s 07/03/2022 --> Comentei essa view para otimiza��o de performance
                     --Dbaps.v_Ctas_Medicas_Fatura Vcmf, 
                      (Select Rp.Ds_Indicacao_Clinica,
                              rp.cd_indicacao_clinica,
                              Ipf.Cd_Mens_Contrato,
                              Rp.Nr_Guia,
                              Rp.Cd_Lote,
                              Rp.Cd_Cid,
                              Rp.Cd_Remessa As Cd_Conta_Medica
                         From Dbaps.Remessa_Prestador          Rp,
                              Dbaps.Itremessa_Prestador_Fatura Ipf
                        Where Rp.Cd_Remessa = Ipf.Cd_Remessa
                       
                       Union All
                       
                       Select Ch.Ds_Indicacao_Clinica,
                              ch.cd_indicacao_clinica,
                              Ihf.Cd_Mens_Contrato,
                              Ch.Nr_Guia,
                              Ch.Cd_Lote,
                              Ch.Cd_Cid,
                              Ch.Cd_Conta_Hospitalar As Cd_Conta_Medica
                         From Dbaps.Conta_Hospitalar          Ch,
                              Dbaps.Itconta_Hospitalar_Fatura Ihf
                        Where Ch.Cd_Conta_Hospitalar = Ihf.Cd_Conta_Hospitalar) Vcmf,
                     Dbaps.Guia g
               Where Vcmf.Nr_Guia = g.Nr_Guia(+)
                    --RAFAEL VIDAL - 10-02-2022
                    --COMENTEI ESSE NVL QUE ESTAVA NOS ASSASSINANDO EM PERFORMANCE
                    --ESTAMOS COM MUITO VALOR PARADO, TIRANDO ISSO PARA TESTAR
                    --And Nvl(Vcmf.Cd_Mens_Contrato, 0) =
                    --    Nvl(Pcd_Mens_Contrato, Nvl(Vcmf.Cd_Mens_Contrato, 0))
                 And Vcmf.Cd_Mens_Contrato = Pcd_Mens_Contrato
                 And Vcmf.Cd_Lote = Pcd_Lote
                 And Vcmf.Cd_Conta_Medica = Pcd_Conta_Medica
                 And coalesce(g.Ds_Diagnostico, Vcmf.Ds_Indicacao_Clinica,g.Cd_Cid, vcmf.cd_cid, vcmf.cd_indicacao_clinica) Is Not Null
              Union
              Select '2' Tp_Reg_Cpl,
                     Nvl(Vcmf.Ds_Observacao_Conta, g.Ds_Observacao) Nm_Desc_Cpl
                From -- Mois�s 07/03/2022 --> Comentei essa view para otimiza��o de performance
                     --Dbaps.v_Ctas_Medicas_Fatura Vcmf, 
                      (Select Rp.Ds_Observacao     As Ds_Observacao_Conta,
                              Ipf.Cd_Mens_Contrato,
                              Rp.Nr_Guia,
                              Rp.Cd_Lote,
                              Rp.Cd_Remessa        As Cd_Conta_Medica
                         From Dbaps.Remessa_Prestador          Rp,
                              Dbaps.Itremessa_Prestador_Fatura Ipf
                        Where Rp.Cd_Remessa = Ipf.Cd_Remessa
                       
                       Union All
                       
                       Select Ch.Ds_Observacao       As Ds_Observacao_Conta,
                              Ihf.Cd_Mens_Contrato,
                              Ch.Nr_Guia,
                              Ch.Cd_Lote,
                              Ch.Cd_Conta_Hospitalar As Cd_Conta_Medica
                         From Dbaps.Conta_Hospitalar          Ch,
                              Dbaps.Itconta_Hospitalar_Fatura Ihf
                        Where Ch.Cd_Conta_Hospitalar = Ihf.Cd_Conta_Hospitalar) Vcmf,
                     Dbaps.Guia g,
                     Dbaps.Tipo_Atendimento Ta
               Where Vcmf.Nr_Guia = g.Nr_Guia(+)
                    --RAFAEL VIDAL - 10-02-2022
                    --COMENTEI ESSE NVL QUE ESTAVA NOS ASSASSINANDO EM PERFORMANCE
                    --ESTAMOS COM MUITO VALOR PARADO, TIRANDO ISSO PARA TESTAR
                    --And Nvl(Vcmf.Cd_Mens_Contrato, 0) =
                    --    Nvl(Pcd_Mens_Contrato, Nvl(Vcmf.Cd_Mens_Contrato, 0))
                 And Vcmf.Cd_Mens_Contrato = Pcd_Mens_Contrato
                 And Vcmf.Cd_Lote = Pcd_Lote
                 And Vcmf.Cd_Conta_Medica = Pcd_Conta_Medica
                 And (Vcmf.Ds_Observacao_Conta Is Not Null Or
                     g.Ds_Observacao Is Not Null)
              
              Union
              
              Select '3' Tp_Reg_Cpl, g.Ds_Justificativa_Tecnica Nm_Desc_Cpl
                From -- Mois�s 07/03/2022 --> Comentei essa view para otimiza��o de performance
                     --Dbaps.v_Ctas_Medicas_Fatura Vcmf, 
                      (Select Ipf.Cd_Mens_Contrato,
                              Rp.Nr_Guia,
                              Rp.Cd_Lote,
                              Rp.Cd_Remessa As Cd_Conta_Medica
                         From Dbaps.Remessa_Prestador          Rp,
                              Dbaps.Itremessa_Prestador_Fatura Ipf
                        Where Rp.Cd_Remessa = Ipf.Cd_Remessa
                       
                       Union All
                       
                       Select Ihf.Cd_Mens_Contrato,
                              Ch.Nr_Guia,
                              Ch.Cd_Lote,
                              Ch.Cd_Conta_Hospitalar As Cd_Conta_Medica
                         From Dbaps.Conta_Hospitalar          Ch,
                              Dbaps.Itconta_Hospitalar_Fatura Ihf
                        Where Ch.Cd_Conta_Hospitalar = Ihf.Cd_Conta_Hospitalar) Vcmf,
                     Dbaps.Guia g
               Where Vcmf.Nr_Guia = g.Nr_Guia(+)
                    --RAFAEL VIDAL - 10-02-2022
                    --COMENTEI ESSE NVL QUE ESTAVA NOS ASSASSINANDO EM PERFORMANCE
                    --ESTAMOS COM MUITO VALOR PARADO, TIRANDO ISSO PARA TESTAR
                    --And Nvl(Vcmf.Cd_Mens_Contrato, 0) =
                    --    Nvl(Pcd_Mens_Contrato, Nvl(Vcmf.Cd_Mens_Contrato, 0))
                 And Vcmf.Cd_Mens_Contrato = Pcd_Mens_Contrato
                 And Vcmf.Cd_Lote = Pcd_Lote
                 And Vcmf.Cd_Conta_Medica = Pcd_Conta_Medica
                 And g.Ds_Justificativa_Tecnica Is Not Null
              Union
              Select '4' Tp_Reg_Cpl, g.Ds_Especificacao_Material Nm_Desc_Cpl
                From -- Mois�s 07/03/2022 --> Comentei essa view para otimiza��o de performance
                     --Dbaps.v_Ctas_Medicas_Fatura Vcmf, Dbaps.v_Ctas_Medicas_Fatura Vcmf, 
                      (Select Ipf.Cd_Mens_Contrato,
                              Rp.Nr_Guia,
                              Rp.Cd_Lote,
                              Rp.Cd_Remessa As Cd_Conta_Medica
                         From Dbaps.Remessa_Prestador          Rp,
                              Dbaps.Itremessa_Prestador_Fatura Ipf
                        Where Rp.Cd_Remessa = Ipf.Cd_Remessa
                       
                       Union All
                       
                       Select Ihf.Cd_Mens_Contrato,
                              Ch.Nr_Guia,
                              Ch.Cd_Lote,
                              Ch.Cd_Conta_Hospitalar As Cd_Conta_Medica
                         From Dbaps.Conta_Hospitalar          Ch,
                              Dbaps.Itconta_Hospitalar_Fatura Ihf
                        Where Ch.Cd_Conta_Hospitalar = Ihf.Cd_Conta_Hospitalar) Vcmf,
                     Dbaps.Guia g
               Where Vcmf.Nr_Guia = g.Nr_Guia(+)
                    --RAFAEL VIDAL - 10-02-2022
                    --COMENTEI ESSE NVL QUE ESTAVA NOS ASSASSINANDO EM PERFORMANCE
                    --ESTAMOS COM MUITO VALOR PARADO, TIRANDO ISSO PARA TESTAR
                    --And Nvl(Vcmf.Cd_Mens_Contrato, 0) =
                    --    Nvl(Pcd_Mens_Contrato, Nvl(Vcmf.Cd_Mens_Contrato, 0))
                 And Vcmf.Cd_Mens_Contrato = Pcd_Mens_Contrato
                 And Vcmf.Cd_Lote = Pcd_Lote
                 And Vcmf.Cd_Conta_Medica = Pcd_Conta_Medica
                 And g.Ds_Especificacao_Material Is Not Null)
       Order By Tp_Reg_Cpl;
  
    Vcdatendimento Varchar(2);
    Ncount         Number;
    
    -- VAR TESTE US
    v_Sn_Pcr Char(1) := 'N';
  v_Seq    Number := 0;
  v_Texto  Varchar2(1000);
    -- FIM VAR TESTE US
  
    Rowptua500compl Row_Ptu_A500_Compl;

  BEGIN
   nCount:=0;
   vCdAtendimento:= NULL;
      OPEN cVerificaAtendimento;
      FETCH cVerificaAtendimento INTO vCdAtendimento;
      CLOSE cVerificaAtendimento;
      
      Open cProcedimentoPCR;
      Fetch cProcedimentoPCR Into v_Sn_Pcr;
      Close cProcedimentoPCR;

    FOR r IN cComplemento LOOP
     nCount := cComplemento%ROWCOUNT;
        IF r.TP_REG_CPL IS NOT NULL Then
        Begin
        
         -- TESTE US          -- Conting�ncia PCR
           If v_Sn_Pcr = 'S' And r.TP_REG_CPL = 1 And r.NM_DESC_CPL = '0'
             Then
                While v_Texto Is Null Loop  
                    Begin                    
                      v_Seq := Round(Dbms_Random.Value(1, 336));
                    
                      Open Ctextoindicacao(v_Seq);
                      Fetch Ctextoindicacao
                        Into v_Texto;
                      Close Ctextoindicacao;
                    
                    End;
                  End Loop; -- FIM DO WHILE
                
                  If v_Texto Is Not Null Then
                     r.NM_DESC_CPL := v_Texto;
                  End If;
      
            End If;
            Exception
              When Others Then
                Raise_Application_Error(-20002, ' TESTE Pcd_Lote: ' || Pcd_Lote || ' Pcd_Conta_Medica: ' || Pcd_Conta_Medica || ' TP_REG_CPL: ' || r.TP_REG_CPL || ' NM_DESC_CPL ' || r.NM_DESC_CPL
                || ' v_Sn_Pcr: ' || v_Sn_Pcr);
            End;
         -- FIM TESTE US          -- Conting�ncia PCR  
        
          rowPtuA500Compl.TP_REG_CPL := r.TP_REG_CPL;
          rowPtuA500Compl.NM_DESC_CPL := REPLACE(REPLACE(SUBSTR(DBAPS.PKG_PTU_BATCH.FNC_AJUSTA_DADO_PTU('ANS', r.NM_DESC_CPL), 0, 100), CHR(10)), CHR(13));
         
         ELSE
           IF Nvl(vCdAtendimento, '00') IN('02','03','08','09', '10') THEN
             rowPtuA500Compl.TP_REG_CPL := '1';
             rowPtuA500Compl.NM_DESC_CPL := 'EM ANEXO';
           END IF;
        END IF;
      PIPE ROW(rowPtuA500Compl);
    END LOOP;
    
    IF nCount = 0 AND  Nvl(vCdAtendimento, '00') IN('02','03','08','09', '10') THEN
      rowPtuA500Compl.TP_REG_CPL := '1';
      rowPtuA500Compl.NM_DESC_CPL := 'EM ANEXO';
    END IF;
    
    -- TESTE US -- CONTING�NCIA PCR
    If ( nCount = 0 And v_Sn_Pcr = 'S') Then
      While v_Texto Is Null Loop  
                    Begin                    
                      v_Seq := Round(Dbms_Random.Value(1, 336));
                    
                      Open Ctextoindicacao(v_Seq);
                      Fetch Ctextoindicacao
                        Into v_Texto;
                      Close Ctextoindicacao;
                    
                    End;
                  End Loop; -- FIM DO WHILE
                
                  If v_Texto Is Not Null Then
                     rowPtuA500Compl.TP_REG_CPL := '1';
                     rowPtuA500Compl.NM_DESC_CPL := v_Texto;
                  End If;
    End If;
    
    -- FIM TESTE US -- CONTING�NCIA PCR

    RETURN;
  END;

  FUNCTION GET_TABLE_PTU_A500_DECL(PCD_CONTA_MEDICA IN NUMBER) RETURN TABLE_PTU_A500_DECL PIPELINED IS

    CURSOR cDeclaracao IS
      SELECT
       D.DS_DECLARACAO_NASCIDO,
       D.DS_DIAGNOSTICO_OBITO,
       D.DS_DECLARACAO_OBITO,
       D.SN_INDICADOR_DORN
      FROM DBAPS.CONTA_HOSPITALAR_DECLARACAO D
     WHERE D.CD_CONTA_HOSPITALAR = PCD_CONTA_MEDICA;
    rowPtuA500Decl ROW_PTU_A500_DECL;
  BEGIN
    FOR r IN cDeclaracao LOOP
      rowPtuA500Decl.DS_DECLARACAO_NASCIDO  := r.DS_DECLARACAO_NASCIDO;
      rowPtuA500Decl.DS_DIAGNOSTICO_OBITO   := r.DS_DIAGNOSTICO_OBITO;
      rowPtuA500Decl.DS_DECLARACAO_OBITO    := r.DS_DECLARACAO_OBITO;
      rowPtuA500Decl.SN_INDICADOR_DORN      := r.SN_INDICADOR_DORN;
      PIPE ROW(rowPtuA500Decl);
    END LOOP;
    RETURN;
  END;

  FUNCTION GET_TABLE_PTU_A500_PROC(PCD_MENS_CONTRATO IN NUMBER, PCD_LOTE IN NUMBER, PCD_CONTA_MEDICA IN NUMBER) RETURN TABLE_PTU_A500_PROC PIPELINED IS
    CURSOR cServico IS
    SELECT
      DT_EXECUCAO,
      HR_INICIAL,
      HR_FINAL,
      SEQ_ITEM,
      ID_ITEMUNICO,
      TP_TABELA,
      -- Caruaru - solicitado remocao do de/para de codigo de procedimentos e pacotes
      --usar o de/para realizado a partir do procedimento principal apenas no JOIN
      CD_SERVICO,
      DBAPS.FNC_REMOVE_ACENTO(DS_SERVICO) DS_SERVICO,
      QT_COBRADA,
      CD_VIA_ACESSO,
      TEC_UTILIZADA,
      FAT_MULT_SERV,
      ID_ACRESCIMO,
      -- HM
      SUM(VL_SERV_COB) VL_SERV_COB,
      SUM(VL_ADIC_SER) VL_ADIC_SER,
      -- FI
      SUM(VL_FILME_COB) VL_FILME_COB,
      SUM(VL_ADIC_FILME) VL_ADIC_FILME,
      -- CO
      SUM(VL_CO_COB) VL_CO_COB,
      SUM(VL_ADIC_CO) VL_ADIC_CO,
      UN_MEDIDA,
      ID_AVISO_ITEM,
      ID_PACOTE,
      CD_PACOTE,
      --OPME
      NR_CPF_CNPJ_FORNECEDOR,
      NM_FORNECEDOR,
      NR_NOTA_FISCAL_FORN,
      CD_REF_MATERIAL_FAB,
      DET_REG_ANVISA,
      NR_REG_ANVISA,
      CD_ATO
    FROM
    (SELECT
        VCMF.CD_LOTE,
        VCMF.CD_CONTA_MEDICA,
        VCMF.CD_MENS_CONTRATO,
        VCMF.DT_REALIZADO DT_EXECUCAO,
        CASE NVL(DECODE(VCMF.TP_CARATER_INTERNACAO, 'E', 'N', 'U', 'S'), 'N')
          WHEN 'S' THEN
            NVL(TO_CHAR(VCMF.HR_INICIAL, 'HH24:MI:SS'), '00:00:00')
          WHEN 'N' THEN
            DECODE(TA.TP_GUIA, 'C', NULL, TO_CHAR(VCMF.HR_INICIAL, 'HH24:MI:SS'))
        END HR_INICIAL,
        CASE NVL(DECODE(VCMF.TP_CARATER_INTERNACAO, 'E', 'N', 'U', 'S'), 'N')
          WHEN 'S' THEN
            NVL(TO_CHAR(VCMF.HR_FINAL, 'HH24:MI:SS'), '00:00:00')
          WHEN 'N' THEN
            DECODE(TA.TP_GUIA, 'C', NULL, TO_CHAR(VCMF.HR_FINAL, 'HH24:MI:SS'))
        END HR_FINAL,
        NULL SEQ_ITEM,
        --AMES - 13/03/2022 - CAMPO ALTERADO PARA AGRUPAMENTO PTU XML 1.1
        VCMF.ID_ITEM_UNICO ID_ITEMUNICO,
        DBAPS.FNC_TABELA_TUSS(PRO.CD_PROCEDIMENTO)  TP_TABELA,
        --Customiza��o Unimed Sorocaba (Mois�s) DE-PARA PROCEDIMENTO PTU - UNIMED SOROCABA 
                Case When (Nvl((Select 1
                             From Dbaps.Tmp_De_Para_Procedimento_Ptu p
                            Where p.De_Cd_Procedimento = Pro.Cd_Procedimento),
                           0) > 0) Then
                  (Select p.Para_Cd_Procedimento
                     From Dbaps.Tmp_De_Para_Procedimento_Ptu p
                    Where p.De_Cd_Procedimento = Pro.Cd_Procedimento)
               
               -- TESTE US        
               -- De-para Consulta M�dico da Fam�lia - Nais -> Fesp
                 When Vcmf.Cd_Unimed_Origem = '970' And
                      Vcmf.Cd_Procedimento = '10101047' Then
                  '10162020'
                  Else
                  Pro.Cd_Procedimento
                  End CD_SERVICO,  
                  --PRO.CD_PROCEDIMENTO CD_SERVICO,
        SUBSTR(UPPER(REGEXP_REPLACE(TRIM(NVL(VCMF.DS_PROCEDIMENTO, Nvl(PRO.DS_PROCEDIMENTO, 'PROCEDIMENTO'))),'[^[:alnum:] ]+')),0,79) DS_SERVICO,
        Nvl(NVL(VCMF.QT_COBRADO_INTERCAMBIO, VCMF.QT_PAGO), 1) QT_COBRADA,
        DECODE(VA.CD_TISS, '1', '0', '2', '1', '3', '2') CD_VIA_ACESSO,
        Decode(TU.CD_TISS, '1', 1, '2', 2, '3', 3) TEC_UTILIZADA,
       
     --original mv
     --  Nvl(DBAPS.FNC_RET_PERCENTUAL_INTERCAMBIO(VCMF.TP_CONTA, VCMF.CD_CONTA_MEDICA, VCMF.CD_LANCAMENTO), 1) FAT_MULT_SERV,  
        Case When 
          To_char(vcmf.hr_inicial, 'hh24:mi') 
          Between '07:01' And '18:59' 
          And vcmf.cd_procedimento = '10101039' 
          And VCMF.cd_tipo_atendimento_tiss = 11 Then
            1
          Else
            
        Nvl(DBAPS.FNC_RET_PERCENTUAL_INTERCAMBIO(VCMF.TP_CONTA, VCMF.CD_CONTA_MEDICA, VCMF.CD_LANCAMENTO), 1) 
        End FAT_MULT_SERV,
 
       /*DECODE(NVL(VCMF.TP_CARATER_INTERNACAO, 'E'),
                      'E',
                      'N',
                      'U',
                      'S') ID_ACRESCIMO,*/
                      
       --customiza��o Unimed Sorocaba (Mois�s --> 01/04/2022 ( S  Quando o procedimento for executado entre 07:00 � 19:00)
       --CH2209-2044 customiza��o Unimed Sorocaba (JOSIEL --> 16/09/2022 ( S  Quando o procedimento for  10101039)
       CASE WHEN vcmf.cd_procedimento = '10101039' AND G.TP_CARATER_SOLIC_INTER = 'U' Then
         'S'
         Else
       DECODE(NVL(VCMF.TP_CARATER_INTERNACAO, 'E'),
                      'E',
                      'N',
                      'U',
                      'S')
                      End  ID_ACRESCIMO,              
        -- HM
        DECODE(VCMF.TP_FATURAMENTO,
                    'HM',
                    VCMF.VL_TOTAL_COBRADO,
                    NULL) VL_SERV_COB,
        DECODE(VCMF.TP_FATURAMENTO,
                    'HM',
                    VCMF.VL_TOTAL_TAXA_COBRADO_PTU,
                    NULL) VL_ADIC_SER,
        --FI
        DECODE(VCMF.TP_FATURAMENTO,
                    'FI',
                    VCMF.VL_TOTAL_COBRADO,
                    NULL) VL_FILME_COB,
        DECODE(VCMF.TP_FATURAMENTO,
                    'FI',
                    VCMF.VL_TOTAL_TAXA_COBRADO_PTU,
                    NULL) VL_ADIC_FILME,
        -- CO
        DECODE(VCMF.TP_FATURAMENTO,
                    'CO',
                    VCMF.VL_TOTAL_COBRADO,
                    NULL) VL_CO_COB,
        DECODE(VCMF.TP_FATURAMENTO,
                    'CO',
                    VCMF.VL_TOTAL_TAXA_COBRADO_PTU,
                    NULL) VL_ADIC_CO,
        LPad(Nvl(VCMF.CD_UNIDADE_MEDIDA_PTU, MUM.CD_PTU),3,'0') UN_MEDIDA,
        DECODE(VCMF.CD_PTU_REMESSA_RETORNO_A520, NULL, 'N', 'S') ID_AVISO_ITEM,
        DECODE(PRO.SN_PACOTE,
                  'S',
                  PRO.SN_PACOTE,
                  VCMF.SN_PACOTE_MANUAL) ID_PACOTE,
        --AJUSTE PARA VALIDAR SE E PACOTE, SE TEM ITEM NO PACOTE E SE TEM ITEM PRINCIPAL NO PACOTE
        NULL CD_PACOTE,
        --OPME
        --<element name="Pago_Fornecedor" type="ptu:ct_PagoOPME_Fornecedor" minOccurs="0"/>
        --DECODE(GRP.TP_GRU_PRO, 'OP', PEX.NR_CPF_CGC, NULL) NR_CPF_CNPJ_FORNECEDOR,
        --Decode(GRP.TP_GRU_PRO, 'OP', PEXP.NM_PRESTADOR, NULL) NM_FORNECEDOR,
        --NULL NR_NOTA_FISCAL_FORN,
        NULL NR_CPF_CNPJ_FORNECEDOR,
        NULL NM_FORNECEDOR,
        NULL NR_NOTA_FISCAL_FORN,
        -- PRO.TP_CLASSIF_SIMPRO IS NOT NULL POIS ALGUMAS UNIMEDS NAO PODEM COLOCAR GRUPO DE PROCEDIMDENTO
        -- COMO OPME DEVIDO SUAS REGRAS DE PAGAMENTO = FLUXO ALTERNATIVO
        CASE
        WHEN (GRP.TP_GRU_PRO IN ('OP')
              OR PRO.TP_CLASSIF_SIMPRO  IN ('ME', 'OT', 'PT')) THEN
          Decode(DBAPS.FNC_TABELA_TUSS(PRO.CD_PROCEDIMENTO),
                      '19',
                      NULL,
                      Decode(Nvl(PRO.TP_CODIFICACAO, 2),
                              2,
                              REGEXP_REPLACE(TRIM(NVL(VCMF.CD_REF_MATERIAL,
                                                      Nvl(PRO.CD_MATERIAL_FABRICANTE, PRO_DE.CD_MATERIAL_FABRICANTE))),
                                            '[^[:alnum:] ]+'),
                              NULL))
        ELSE
          NULL
        END  CD_REF_MATERIAL_FAB,
        CASE
        WHEN (GRP.TP_GRU_PRO IN ('OP')
              OR PRO.TP_CLASSIF_SIMPRO  IN ('ME', 'OT', 'PT')) THEN
            Decode(VCMF.CD_PROCEDIMENTO,
                  '99999943',
                  'EMPRESA DETENTORA',
                  DBAPS.PKG_PTU_BATCH.FNC_AJUSTA_DADO_PTU('ANS', SubStr(Nvl(PRO.DS_DET_REG_ANVISA, PRO_DE.DS_DET_REG_ANVISA),1,50))
                  )
        ELSE
          NULL
        END DET_REG_ANVISA,
        -- FORMAS DE DETECTAR OPME - PELO GRUPO PROCEDIMENTO
        --OU O PROCEDIMENTO TER REIGSTRO ANVISA
        CASE
        WHEN (GRP.TP_GRU_PRO IN ('OP')
              OR PRO.TP_CLASSIF_SIMPRO  IN ('ME', 'OT', 'PT')) THEN
            REGEXP_REPLACE(Nvl(VCMF.NR_REGISTRO_ANVISA,
                                  Nvl(PRO.NR_ANVISA, PRO_DE.NR_ANVISA)),
                              '[^[:digit:]]+')
        ELSE
          NULL
        END NR_REG_ANVISA,
        DBAPS.FNC_RET_MAX_CD_ATO(VCMF.ID_ITEM_UNICO) CD_ATO,
        VCMF.CD_PRESTADOR_PRINCIPAL                                                      CD_PRE_REQ,
        VCMF.CD_MULTI_EMPRESA,
        GRP.TP_GRU_PRO TIPO_PROCEDIMENTO
    FROM DBAPS.V_CTAS_MEDICAS_FATURA VCMF
      INNER JOIN DBAPS.PRESTADOR              PEX ON Nvl(VCMF.CD_PRESTADOR_PTU, VCMF.CD_PRESTADOR) = PEX.CD_PRESTADOR
      INNER JOIN DBAPS.PRESTADOR              PEXP ON VCMF.CD_PRESTADOR_PRINCIPAL = PEXP.CD_PRESTADOR
      LEFT JOIN DBAPS.ATI_MED                 AM ON VCMF.CD_ATIVIDADE_MEDICA = AM.CD_ATI_MED
      LEFT JOIN DBAPS.GRAU_PARTICIPACAO       GP ON AM.CD_GRAU_PARTICIPACAO = GP.CD_GRAU_PARTICIPACAO
      LEFT JOIN DBAPS.CONSELHO_PROFISSIONAL   CP ON PEX.CD_CONSELHO_PROFISSIONAL = CP.CD_CONSELHO_PROFISSIONAL
      LEFT JOIN DBAPS.PROCEDIMENTO            PRO ON DBAPS.FNC_PROCEDIMENTO_ANALISE(VCMF.CD_PROCEDIMENTO, VCMF.CD_PRESTADOR_PRINCIPAL, 'C') = PRO.CD_PROCEDIMENTO
      LEFT JOIN DBAPS.PROCEDIMENTO            PRO_DE ON VCMF.CD_PROCEDIMENTO = PRO_DE.CD_PROCEDIMENTO
      LEFT JOIN DBAPS.GRUPO_PROCEDIMENTO      GRP ON PRO.CD_GRUPO_PROCEDIMENTO = GRP.CD_GRUPO_PROCEDIMENTO
      LEFT JOIN DBAPS.TECNICA_UTILIZADA       TU ON VCMF.CD_TECNICA = TU.CD_TISS
      LEFT JOIN DBAPS.MVS_UNIDADE_MEDIDA      MUM ON VCMF.CD_UNIDADE_MEDIDA = MUM.CD_TERMO
      LEFT JOIN DBAPS.GUIA                    G ON VCMF.NR_GUIA = G.NR_GUIA
      LEFT JOIN DBAPS.GUIA                    G_TEM ON Nvl(G.NR_GUIA_TEM, VCMF.NR_GUIA_TEM) = G_TEM.NR_GUIA
      INNER JOIN DBAPS.TIPO_ATENDIMENTO       TA ON VCMF.CD_TIPO_ATENDIMENTO = TA.CD_TIPO_ATENDIMENTO
      LEFT JOIN DBAPS.PTU_MENSAGEM            PM ON G.CD_PTU_MENSAGEM_ORIGEM = PM.CD_PTU_MENSAGEM
      LEFT JOIN DBAPS.VIA_ACESSO              VA ON VCMF.CD_VIA_ACESSO = VA.CD_TISS
    WHERE 1 = 1
     And VCMF.CD_MENS_CONTRATO = PCD_MENS_CONTRATO
      AND CD_LOTE = PCD_LOTE
      AND CD_CONTA_MEDICA = PCD_CONTA_MEDICA
    ) SERVICO
      --AND servico.cd_servico = '89990031'
    GROUP BY DT_EXECUCAO,
              HR_INICIAL,
              HR_FINAL,
              SEQ_ITEM,
              ID_ITEMUNICO,
              TP_TABELA,
              DBAPS.FNC_PROCEDIMENTO_ANALISE(CD_SERVICO, CD_PRE_REQ, 'C'),
              DS_SERVICO,
              QT_COBRADA,
              CD_VIA_ACESSO,
              TEC_UTILIZADA,
              FAT_MULT_SERV,
              ID_ACRESCIMO,
              UN_MEDIDA,
              ID_AVISO_ITEM,
              ID_PACOTE,
              CD_PACOTE,
              NR_CPF_CNPJ_FORNECEDOR,
              NM_FORNECEDOR,
              NR_NOTA_FISCAL_FORN,
              CD_REF_MATERIAL_FAB,
              DET_REG_ANVISA,
              NR_REG_ANVISA,
              CD_ATO,
              CD_MULTI_EMPRESA,
              CD_SERVICO,
              TIPO_PROCEDIMENTO;

    rowPtuA500Proc ROW_PTU_A500_Proc;
  BEGIN
    FOR r IN cServico LOOP

     rowPtuA500Proc.DT_EXECUCAO := r.DT_EXECUCAO;
     rowPtuA500Proc.HR_INICIAL := r.HR_INICIAL;
     rowPtuA500Proc.HR_FINAL := r.HR_FINAL;
     rowPtuA500Proc.SEQ_ITEM := r.SEQ_ITEM;
     rowPtuA500Proc.ID_ITEMUNICO := r.ID_ITEMUNICO;
     rowPtuA500Proc.TP_TABELA := r.TP_TABELA;
     rowPtuA500Proc.CD_SERVICO := r.CD_SERVICO;
     rowPtuA500Proc.DS_SERVICO := r.DS_SERVICO;
     rowPtuA500Proc.QT_COBRADA := r.QT_COBRADA;
     rowPtuA500Proc.CD_VIA_ACESSO := r.CD_VIA_ACESSO;
     rowPtuA500Proc.TEC_UTILIZADA := r.TEC_UTILIZADA;
     rowPtuA500Proc.FAT_MULT_SERV := r.FAT_MULT_SERV;
     rowPtuA500Proc.ID_ACRESCIMO := r.ID_ACRESCIMO;
     rowPtuA500Proc.VL_SERV_COB := r.VL_SERV_COB;
     rowPtuA500Proc.VL_ADIC_SER := r.VL_ADIC_SER;
     rowPtuA500Proc.VL_FILME_COB := r.VL_FILME_COB;
     rowPtuA500Proc.VL_ADIC_FILME := r.VL_ADIC_FILME;
     rowPtuA500Proc.VL_CO_COB := r.VL_CO_COB;
     rowPtuA500Proc.VL_ADIC_CO := r.VL_ADIC_CO;
     rowPtuA500Proc.UN_MEDIDA := r.UN_MEDIDA;
     rowPtuA500Proc.ID_AVISO_ITEM := r.ID_AVISO_ITEM;
     rowPtuA500Proc.ID_PACOTE := r.ID_PACOTE;
     rowPtuA500Proc.CD_PACOTE := r.CD_PACOTE;
    -- rowPtuA500Proc.CD_PORTE_ANE := r.CD_PORTE_ANE;
     rowPtuA500Proc.NR_CPF_CNPJ_FORNECEDOR := r.NR_CPF_CNPJ_FORNECEDOR;
     rowPtuA500Proc.NM_FORNECEDOR := r.NM_FORNECEDOR;
     rowPtuA500Proc.NR_NOTA_FISCAL_FORN := r.NR_NOTA_FISCAL_FORN;
     rowPtuA500Proc.CD_REF_MATERIAL_FAB := r.CD_REF_MATERIAL_FAB;
     rowPtuA500Proc.DET_REG_ANVISA := r.DET_REG_ANVISA;
     rowPtuA500Proc.NR_REG_ANVISA := r.NR_REG_ANVISA;
     rowPtuA500Proc.CD_ATO := r.CD_ATO;
     --rowPtuA500Proc.TP_FATURAMENTO := r.TP_FATURAMENTO;

     /*
     rowPtuA500Proc.DT_SOLICITACAO := r.DT_SOLICITACAO;
     rowPtuA500Proc.CD_UNI_AUTORIZA := r.CD_UNI_AUTORIZA;
     rowPtuA500Proc.NR_AUTORIZ := r.NR_AUTORIZ;
     rowPtuA500Proc.DT_AUTORIZ := r.DT_AUTORIZ;
     rowPtuA500Proc.TP_AUTORIZ := r.TP_AUTORIZ;
     */

      PIPE ROW(rowPtuA500Proc);
    END LOOP;
    RETURN;
  EXCEPTION
    WHEN NO_DATA_NEEDED THEN NULL;
    WHEN OTHERS THEN
      Raise_Application_Error(-20001, 'Erro na package A500 (GET_TABLE_PTU_A500_PROC): ' || SQLERRM || '. Detalhe: ' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
  END;

  FUNCTION GET_TABLE_PTU_A500_PROC_EQP(PCD_MENS_CONTRATO IN NUMBER, PCD_LOTE IN NUMBER, PCD_CONTA_MEDICA IN NUMBER, PID_ITEM_UNICO IN VARCHAR2, PTP_GUIA IN VARCHAR2) RETURN TABLE_PTU_A500_EQP PIPELINED IS
    CURSOR cEquipe IS
           SELECT DISTINCT
                    ---Customiza��o Unimed Sorocaba (Mois�s) Tp_participa��o                         
                       Case
                         When Vcmf.Cd_Tipo_Atendimento = 3 And
                             /*
                             10103015  Atendimento ao rec�m-nascido em ber��rio 
                             10103023  Atendimento ao rec�m-nascido em sala de parto (parto normal ou operat�rio de baixo risco) 
                             10103031  Atendimento ao rec�m-nascido em sala de parto (parto normal ou operat�rio de alto risco)
                             */
                              Vcmf.Cd_Procedimento In
                              (10103015, 10103023, 10103031) Then
                          Null
                         Else
                          Decode(Pgrupo.Tp_Gru_Pro,
                                 'MD',
                                 Null,
                                 'TX',
                                 Null,
                                 'MT',
                                 Null,
                                 'SD',
                                 Null,
                                 'DI',
                                 Null,
                                 Decode(Gp.Cd_Tiss, '92', '12', Gp.Cd_Tiss))
                       End Tp_Participacao,
                   VCMF.CD_UNIMED_EXECUTORA CD_UNI_PREST,
                   NVL(P.CD_PRESTADOR, VCMF.CD_PRESTADOR)  CD_PREST, /* PRIORIZAR CD_PRESTADOR_PTU antes do prestador da conta */
                   DBAPS.PKG_PTU_BATCH.FNC_AJUSTA_DADO_PTU('ANS', SubStr(P.NM_PRESTADOR,1,60)) NM_PROFISSIONAL,
                   DECODE(PTP_GUIA,'SADT',DECODE(P.TP_PRESTADOR,'J',NULL, DECODE(LENGTH(P.NR_CPF_CGC),10,'0'||P.NR_CPF_CGC, P.NR_CPF_CGC)),
                          DECODE(LENGTH(P.NR_CPF_CGC),10,'0'||P.NR_CPF_CGC, P.NR_CPF_CGC)) CD_CPF,
                   Decode(LPad(CP.CD_TISS,
                                        2,
                                        '0'),
                                   '02',
                                   'COREN',
                                   '01',
                                   'CRESS',
                                   '05',
                                   'CREFITO',
                                   '03',
                                   'CRF',
                                   '04',
                                   'CREFONO',
                                   '06',
                                   'CRM',
                                   '07',
                                   'CRN',
                                   '08',
                                   'CRO',
                                   '09',
                                   'CRP',
                                   '10',
                                   'OUT',
								   '11','CRFA', '12','CRBM',
                                   NULL)SG_CONSELHO,
                   REGEXP_REPLACE(P.DS_COD_CONSELHO, '[^[:alnum:] ]+') NR_CONSELHO,
                   FNC_RET_UF_TO_TISS(P.UF_CONSELHO) UF,
                   NVL(E.NR_CBOS,999999) CBO,
                   VCMF.CD_PROCEDIMENTO
            FROM DBAPS.V_CTAS_MEDICAS_FATURA VCMF
            INNER JOIN DBAPS.PRESTADOR P ON P.CD_PRESTADOR = NVL(VCMF.CD_PRESTADOR_PTU,VCMF.CD_PRESTADOR)
            LEFT JOIN DBAPS.PRESTADOR PPSADT ON PPSADT.CD_PRESTADOR = Decode(PTP_GUIA,'SADT',VCMF.CD_PRESTADOR_PRINCIPAL,NULL)
            LEFT JOIN DBAPS.TIP_PRESTADOR       TPPSADT ON PPSADT.CD_TIP_PRESTADOR = TPPSADT.CD_TIP_PRESTADOR
            LEFT JOIN DBAPS.ESPECIALIDADE_PRESTADOR EP ON EP.CD_PRESTADOR = P.CD_PRESTADOR
            INNER JOIN DBAPS.ESPECIALIDADE E           ON E.CD_ESPECIALIDADE = NVL(VCMF.CD_ESPECIALIDADE_PRESTADOR, EP.CD_ESPECIALIDADE)
            LEFT JOIN DBAPS.CONSELHO_PROFISSIONAL CP  ON P.CD_CONSELHO_PROFISSIONAL = CP.CD_CONSELHO_PROFISSIONAL
            LEFT JOIN DBAPS.ATI_MED                 AM ON VCMF.CD_ATIVIDADE_MEDICA = AM.CD_ATI_MED
            LEFT JOIN DBAPS.GRAU_PARTICIPACAO       GP ON AM.CD_GRAU_PARTICIPACAO = GP.CD_GRAU_PARTICIPACAO
            LEFT JOIN DBAPS.TIP_PRESTADOR       TP ON P.CD_TIP_PRESTADOR = TP.CD_TIP_PRESTADOR
             --incluido em 27/01/2022 by Mois�s, corrigir participa��o
        Left Join Dbaps.Procedimento Proc
          On Nvl(Vcmf.Cd_Procedimento, Vcmf.Cd_Procedimento_Digitado) =
             Proc.Cd_Procedimento
        Left Join Dbaps.Grupo_Procedimento Pgrupo
          On Proc.Cd_Grupo_Procedimento = Pgrupo.Cd_Grupo_Procedimento
          
            WHERE VCMF.CD_MENS_CONTRATO = PCD_MENS_CONTRATO
              AND VCMF.CD_LOTE = PCD_LOTE
              AND VCMF.CD_CONTA_MEDICA = PCD_CONTA_MEDICA
              AND VCMF.TP_FATURAMENTO = 'HM'
              AND P.TP_PRESTADOR = Decode(P.TP_PRESTADOR,'J',Decode(PTP_GUIA,'SADT','J','F'), 'F')
              AND VCMF.ID_ITEM_UNICO = PID_ITEM_UNICO
              /*--AMES - 13/03/2022 - AJUSTE PARA PEGAR AGRUPAMENTO DO ITEM UNICO QUANDO INTERNACAO COM PRESTADOR NA FATURA SENDO PJ
              AND ((VCMF.TP_CONTA = 'I'
                AND VCMF.ID_ITEM_UNICO IN (
                  DBAPS.FNC_PTU_AGRUPA_ITEM_UNICO(VCMF.CD_LOTE, VCMF.CD_CONTA_MEDICA, VCMF.CD_PROCEDIMENTO, P.CD_PRESTADOR, PID_ITEM_UNICO, 'CEQUIPE', VCMF.DT_REALIZADO, VCMF.HR_INICIAL, VCMF.HR_FINAL,NVL(VCMF.QT_COBRADO_INTERCAMBIO, VCMF.QT_PAGO)))
                  )
                    OR (VCMF.TP_CONTA = 'A' AND VCMF.ID_ITEM_UNICO = PID_ITEM_UNICO))  */
              --AND GP.CD_TIPO_PARTICIPACAO <> '0' -- Ajuste temporario, pois a participacao 0 nao existe mais no XML.
              AND (VCMF.CD_ESPECIALIDADE_PRESTADOR IS NOT NULL OR EP.CD_ESPECIALIDADE = (SELECT EP2.CD_ESPECIALIDADE
                                         FROM DBAPS.ESPECIALIDADE_PRESTADOR EP2
                                        WHERE EP.CD_PRESTADOR = EP2.CD_PRESTADOR
                                          AND EP2.SN_PRINCIPAL = 'S'
                                          AND ROWNUM = 1));

    rowPtuA500Equipe ROW_PTU_A500_EQP;
  BEGIN
    FOR r IN cEquipe LOOP

    rowPtuA500Equipe.TP_PARTICIPACAO := r.TP_PARTICIPACAO;
    rowPtuA500Equipe.CD_UNI_PREST    := r.CD_UNI_PREST;
    rowPtuA500Equipe.CD_PREST        := r.CD_PREST;
    rowPtuA500Equipe.NM_PROFISSIONAL := r.NM_PROFISSIONAL;
    rowPtuA500Equipe.CD_CPF          := r.CD_CPF;
    rowPtuA500Equipe.SG_CONSELHO     := r.SG_CONSELHO;
    rowPtuA500Equipe.NR_CONSELHO     :=  DBAPS.PKG_PTU_BATCH.FNC_AJUSTA_DADO_PTU('AN',r.NR_CONSELHO);
    rowPtuA500Equipe.UF              := r.UF;
    rowPtuA500Equipe.CBO             := r.CBO;
    rowPtuA500Equipe.CD_PROCEDIMENTO := r.CD_PROCEDIMENTO;

      PIPE ROW(rowPtuA500Equipe);
    END LOOP;
    RETURN;
  EXCEPTION
    WHEN NO_DATA_NEEDED THEN NULL;
    WHEN OTHERS THEN
      Raise_Application_Error(-20001, 'Erro na package A500 (GET_TABLE_PTU_A500_PROC_EQP): ' || SQLERRM || '. Detalhe: ' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
  END;

 /* equipes simplificada - dados apenas do cd_prestador_ptu */
 FUNCTION GET_TABLE_PTU_A500_PROC_EQP2(PCD_MENS_CONTRATO IN NUMBER, PCD_LOTE IN NUMBER, PCD_CONTA_MEDICA IN NUMBER, PID_ITEM_UNICO IN VARCHAR2, PTP_GUIA IN VARCHAR2) RETURN TABLE_PTU_A500_EQP PIPELINED IS
    CURSOR cEquipe IS
           SELECT DISTINCT
                   DECODE(PTP_GUIA,'SADT',
                          DECODE(TP.CD_PTU_TIPO_PRESTADOR, '08', NULL, DECODE(GP.CD_TISS,'92','12', GP.CD_TISS)),
                                 DECODE(GP.CD_TISS,'92','12',GP.CD_TISS))TP_PARTICIPACAO,
                   VCMF.CD_UNIMED_EXECUTORA CD_UNI_PREST,
                   NVL(P.CD_PRESTADOR, VCMF.CD_PRESTADOR)  CD_PREST, /* PRIORIZAR CD_PRESTADOR_PTU antes do prestador da conta */
                   SubStr(P.NM_PRESTADOR,1,60) NM_PROFISSIONAL,
                   DECODE(PTP_GUIA,'SADT',DECODE(P.TP_PRESTADOR,'J',NULL, DECODE(LENGTH(P.NR_CPF_CGC),10,'0'||P.NR_CPF_CGC, P.NR_CPF_CGC)),
                          DECODE(LENGTH(P.NR_CPF_CGC),10,'0'||P.NR_CPF_CGC, P.NR_CPF_CGC)) CD_CPF,
                   Decode(LPad(CP.CD_TISS,
                                        2,
                                        '0'),
                                   '02',
                                   'COREN',
                                   '01',
                                   'CRESS',
                                   '05',
                                   'CREFITO',
                                   '03',
                                   'CRF',
                                   '04',
                                   'CREFONO',
                                   '06',
                                   'CRM',
                                   '07',
                                   'CRN',
                                   '08',
                                   'CRO',
                                   '09',
                                   'CRP',
                                   '10',
                                   'OUT',
								   '11','CRFA', '12','CRBM',
                                   NULL)SG_CONSELHO,
                   REGEXP_REPLACE(P.DS_COD_CONSELHO, '[^[:alnum:] ]+') NR_CONSELHO,
                   FNC_RET_UF_TO_TISS(P.UF_CONSELHO) UF,
                   NVL((SELECT nr_cbos FROM DBAPS.ESPECIALIDADE
                        WHERE CD_ESPECIALIDADE = VCMF.CD_ESPECIALIDADE_PRESTADOR),999999) CBO,
                   VCMF.CD_PROCEDIMENTO
            FROM DBAPS.V_CTAS_MEDICAS_FATURA VCMF
            INNER JOIN DBAPS.PRESTADOR P ON P.CD_PRESTADOR = NVL(VCMF.CD_PRESTADOR_PTU,VCMF.CD_PRESTADOR)
            LEFT JOIN DBAPS.TIP_PRESTADOR       TP ON P.CD_TIP_PRESTADOR = TP.CD_TIP_PRESTADOR
            LEFT JOIN DBAPS.CONSELHO_PROFISSIONAL CP  ON P.CD_CONSELHO_PROFISSIONAL = CP.CD_CONSELHO_PROFISSIONAL
            LEFT JOIN DBAPS.ATI_MED                 AM ON VCMF.CD_ATIVIDADE_MEDICA = AM.CD_ATI_MED
            LEFT JOIN DBAPS.GRAU_PARTICIPACAO       GP ON AM.CD_GRAU_PARTICIPACAO = GP.CD_GRAU_PARTICIPACAO
            WHERE VCMF.CD_MENS_CONTRATO = PCD_MENS_CONTRATO
              AND VCMF.CD_LOTE = PCD_LOTE
              AND VCMF.CD_CONTA_MEDICA = PCD_CONTA_MEDICA
              --AND VCMF.TP_FATURAMENTO = 'HM' /* Em taubate envia equipe para CO...*/
              AND VCMF.ID_ITEM_UNICO = PID_ITEM_UNICO;

    rowPtuA500Equipe ROW_PTU_A500_EQP;
  BEGIN
    FOR r IN cEquipe LOOP

    rowPtuA500Equipe.TP_PARTICIPACAO := r.TP_PARTICIPACAO;
    rowPtuA500Equipe.CD_UNI_PREST    := r.CD_UNI_PREST;
    rowPtuA500Equipe.CD_PREST        := r.CD_PREST;
    rowPtuA500Equipe.NM_PROFISSIONAL := r.NM_PROFISSIONAL;
    rowPtuA500Equipe.CD_CPF          := r.CD_CPF;
    rowPtuA500Equipe.SG_CONSELHO     := r.SG_CONSELHO;
    rowPtuA500Equipe.NR_CONSELHO     := DBAPS.PKG_PTU_BATCH.FNC_AJUSTA_DADO_PTU('AN',r.NR_CONSELHO);
    rowPtuA500Equipe.UF              := r.UF;
    rowPtuA500Equipe.CBO             := r.CBO;
    rowPtuA500Equipe.CD_PROCEDIMENTO := r.CD_PROCEDIMENTO;

      PIPE ROW(rowPtuA500Equipe);
    END LOOP;
    RETURN;
  EXCEPTION
    WHEN NO_DATA_NEEDED THEN NULL;
    WHEN OTHERS THEN
      Raise_Application_Error(-20001, 'Erro na package A500 (GET_TABLE_PTU_A500_PROC_EQP2): ' || SQLERRM || '. Detalhe: ' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
  END;


END;
/
