Create Or Replace Noneditionable Package Custom.Pkg_Rn507 Is

  Procedure Prc_Calc_Prest_Acred_Ps_Internacao;

  Procedure Prc_Apaga_Registros(p_Delete_Informacao In Varchar2);

  Function Fnc_Get_Db_Link Return Varchar2;
  Function Fnc_Get_Dados_Ps_Hms Return Number;
End Pkg_Rn507;
/
Create Or Replace Noneditionable Package Body Custom.Pkg_Rn507

 Is
  Procedure Prc_Calc_Prest_Acred_Ps_Internacao Is
    Vchave  Varchar2(50) := 'PREST_ACREDITACAO_PS';
    Vreturn Number;
  Begin
    Prc_Apaga_Registros(p_Delete_Informacao => Vchave);
  
    Vreturn := Fnc_Get_Dados_Ps_Hms(); --PUXANDO DADOS DE CONSULTA DO HMS
  
    Insert Into Custom.Rn507_Acreditacao_Prest_Ps_Internacao
      (Select x.Competencia,
              x.Nr_Ano As Ano,
              x.Mes,
              x.Total_Consulta + x.Total_Internacao As Total,
              x.Nivel
         From (Select a.*, b.Total_Internacao, 'Acreditado' As Nivel
                 From (Select f.Nr_Ano || f.Nr_Mes As Competencia,
                              f.Nr_Ano,
                              Custom.Fnc_Mes_Por_Extenso(p_Mes => f.Nr_Mes) As Mes,
                              Count(Distinct Rp.Nr_Guia) As Total_Consulta
                       
                         From Dbaps.Remessa_Prestador          Rp,
                              Dbaps.Itremessa_Prestador        Ip,
                              Dbaps.Itremessa_Prestador_Equipe Ipe,
                              Dbaps.Lote                       l,
                              Dbaps.Fatura                     f,
                              Dbaps.Prestador                  p
                       
                        Where f.Cd_Fatura = l.Cd_Fatura
                          And l.Cd_Lote = Rp.Cd_Lote
                          And Rp.Cd_Remessa = Ip.Cd_Remessa
                          And Ip.Cd_Remessa = Ipe.Cd_Remessa
                          And Ip.Cd_Lancamento = Ipe.Cd_Lancamento
                          And p.Cd_Prestador = l.Cd_Prestador --PRESTADOR QUE ENVIOU O LOTE GUIAS (LOCAL DO ATENDIMENTO).
                          And l.Cd_Prestador <> 300100 --DESCONSIDERANDO CALCULO DO HMS, POIS IREMOS PUXAR DADOS DO PR�PRIO HMS  
                          And f.Nr_Ano >= '2022'
                          And f.Tp_Fatura = 'P'
                             
                          And Exists
                        (Select 1
                                 From Dbaps.Prestador_Acreditacao Pa
                                Where Pa.Cd_Prestador = p.Cd_Prestador
                                  And Pa.Tp_Nivel_Acreditacao = 3)
                          And p.Cd_Grupo_Prestador In (2, 19)
                          And (Ipe.Cd_Motivo <> 24 Or Ipe.Cd_Motivo Is Null) --glosa de duplicidade 
                          And Nvl(Ip.Cd_Procedimento, Ip.Cd_Proc_Digita) =
                              '10101039'
                        Group By f.Nr_Ano,
                                 f.Nr_Ano || f.Nr_Mes,
                                 Custom.Fnc_Mes_Por_Extenso(p_Mes => f.Nr_Mes)
                       
                       Union All -- dados CONSULTA do HMS. 
                       --comentado em 14/04/2023.
                       --Motivo: Camila da rede credenciada informou que os dados ser�o computados iguais ao do AD (HMS). Ent�o aqui n�o olharemos o contas.
                       --chamado:  CH2304-0247
                       
                       /* Select f.Nr_Ano || f.Nr_Mes As Competencia,
                             f.Nr_Ano,
                             Custom.Fnc_Mes_Por_Extenso(p_Mes => f.Nr_Mes) As Mes,
                             Count(Distinct Rp.Nr_Guia) As Total_Consulta
                       
                        From Dbaps.Remessa_Prestador             Rp,
                             Dbaps.Itremessa_Prestador           Ip,
                             Dbaps.Itremessa_Prestador_Equipe    Ipe,
                             Dbaps.Lote                          l,
                             Dbaps.Fatura                        f,
                             Dbaps.Prestador                     p,
                             Custom.Rn507_Rede_Cred_Dados_Ps_Hms Rhms
                       
                       Where f.Cd_Fatura = l.Cd_Fatura
                         And l.Cd_Lote = Rp.Cd_Lote
                         And Rp.Cd_Remessa = Ip.Cd_Remessa
                         And Ip.Cd_Remessa = Ipe.Cd_Remessa
                         And Ip.Cd_Lancamento = Ipe.Cd_Lancamento
                         And p.Cd_Prestador = l.Cd_Prestador --PRESTADOR QUE ENVIOU O LOTE GUIAS (LOCAL DO ATENDIMENTO). 
                            -- And (TRIM(Rhms.Nr_Guia) = TO_CHAR(Rp.Nr_Guia) Or TRIM(Rhms.Nr_Guia) = Rp.Cd_Guia_Externa)
                         And Trim(Rhms.Nr_Guia) = To_Char(Rp.Nr_Guia)
                         And l.Cd_Prestador = 300100 --CONSIDERANDO CALCULO DO HMS
                         And f.Nr_Ano >= '2022'
                         And f.Tp_Fatura = 'P'
                            
                         And Exists
                       (Select 1
                                From Dbaps.Prestador_Acreditacao Pa
                               Where Pa.Cd_Prestador = p.Cd_Prestador
                                 And Pa.Tp_Nivel_Acreditacao = 3)
                         And p.Cd_Grupo_Prestador In (2, 19)
                         And (Ipe.Cd_Motivo <> 24 Or Ipe.Cd_Motivo Is Null) --glosa de duplicidade 
                         And Nvl(Ip.Cd_Procedimento, Ip.Cd_Proc_Digita) =
                             '10101039'
                       Group By f.Nr_Ano,
                                f.Nr_Ano || f.Nr_Mes,
                                Custom.Fnc_Mes_Por_Extenso(p_Mes => f.Nr_Mes)*/
                       Select To_Char(Rhms.Dt_Atendimento, 'YYYYMM') As Competencia,
                              
                              To_Char(Rhms.Dt_Atendimento, 'YYYY') As Nr_Ano,
                              Custom.Fnc_Mes_Por_Extenso(p_Mes => To_Char(Rhms.Dt_Atendimento,
                                                                          'MM')) As Mes,
                              Count(Rhms.Nr_Guia) As Total_Consulta
                         From Custom.Rn507_Rede_Cred_Dados_Ps_Hms Rhms
                       
                        Group By To_Char(Rhms.Dt_Atendimento, 'YYYYMM'),
                                 To_Char(Rhms.Dt_Atendimento, 'YYYY'),
                                 To_Char(Rhms.Dt_Atendimento, 'MM')) a,
                      
                      --Total de utiliza��o em hospital Acreditado em n�vel m�ximo - INTERNA��O
                      (Select f.Nr_Ano || f.Nr_Mes As Competencia,
                              f.Nr_Ano,
                              Custom.Fnc_Mes_Por_Extenso(p_Mes => f.Nr_Mes) As Mes,
                              Count(Distinct Ch.Nr_Guia) As Total_Internacao
                       
                         From Dbaps.Conta_Hospitalar   Ch,
                              Dbaps.Itconta_Hospitalar Ih,
                              Dbaps.Itconta_Med        Im,
                              Dbaps.Lote               l,
                              Dbaps.Fatura             f,
                              Dbaps.Prestador          p
                       
                        Where f.Cd_Fatura = l.Cd_Fatura
                          And l.Cd_Lote = Ch.Cd_Lote
                          And Ch.Cd_Conta_Hospitalar = Ih.Cd_Conta_Hospitalar
                          And Ih.Cd_Conta_Hospitalar = Im.Cd_Conta_Hospitalar
                          And Ih.Cd_Lancamento = Im.Cd_Lancamento
                          And p.Cd_Prestador = l.Cd_Prestador --PRESTADOR QUE ENVIOU O LOTE GUIAS (LOCAL DO ATENDIMENTO).
                             
                          And f.Nr_Ano >= '2022'
                          And f.Tp_Fatura = 'P'
                          And f.Sn_Refaturar = 'N'
                             
                          And (Ih.Cd_Motivo <> 24 Or Ih.Cd_Motivo Is Null) --Glosa de duplicidade 
                          And Exists
                        (Select 1
                                 From Dbaps.Prestador_Acreditacao Pa
                                Where Pa.Cd_Prestador = p.Cd_Prestador
                                  And Pa.Tp_Nivel_Acreditacao = 3)
                          And p.Cd_Grupo_Prestador In (2, 19)
                          And l.Cd_Tipo_Atendimento = 3 -- SOMENTE INTERNA��O  
                        Group By f.Nr_Ano,
                                 f.Nr_Ano || f.Nr_Mes,
                                 Custom.Fnc_Mes_Por_Extenso(p_Mes => f.Nr_Mes)) b
                Where a.Competencia = b.Competencia
               
               Union All ---Total de utiliza��o em hospital n�o acreditado -- CONSULTA.  
               
               Select a.*, b.Total_Internacao, 'N�o Acreditado' As Nivel
                 From (Select f.Nr_Ano || f.Nr_Mes As Competencia,
                              f.Nr_Ano,
                              Custom.Fnc_Mes_Por_Extenso(p_Mes => f.Nr_Mes) As Mes,
                              Count(Distinct Rp.Nr_Guia) As Total_Consulta
                       
                         From Dbaps.Remessa_Prestador          Rp,
                              Dbaps.Itremessa_Prestador        Ip,
                              Dbaps.Itremessa_Prestador_Equipe Ipe,
                              Dbaps.Lote                       l,
                              Dbaps.Fatura                     f,
                              Dbaps.Prestador                  p
                       
                        Where f.Cd_Fatura = l.Cd_Fatura
                          And l.Cd_Lote = Rp.Cd_Lote
                          And Rp.Cd_Remessa = Ip.Cd_Remessa
                          And Ip.Cd_Remessa = Ipe.Cd_Remessa
                          And Ip.Cd_Lancamento = Ipe.Cd_Lancamento
                             
                          And p.Cd_Prestador = l.Cd_Prestador --PRESTADOR QUE ENVIOU O LOTE GUIAS (LOCAL DO ATENDIMENTO).
                             
                          And f.Nr_Ano >= '2022'
                          And f.Tp_Fatura = 'P'
                          And f.Sn_Refaturar = 'N'
                          And (Ipe.Cd_Motivo <> 24 Or Ipe.Cd_Motivo Is Null) --glosa de duplicidade 
                          And Not Exists
                        (Select 1
                                 From Dbaps.Prestador_Acreditacao Pa
                                Where Pa.Cd_Prestador = p.Cd_Prestador
                                  And Pa.Tp_Nivel_Acreditacao = 3)
                          And p.Cd_Grupo_Prestador In (2, 19)
                          And Nvl(Ip.Cd_Procedimento, Ip.Cd_Proc_Digita) =
                              '10101039'
                        Group By f.Nr_Ano,
                                 f.Nr_Ano || f.Nr_Mes,
                                 Custom.Fnc_Mes_Por_Extenso(p_Mes => f.Nr_Mes)) a,
                      
                      ---Total de utiliza��o em hospital n�o acreditado -- INTERNA��O.
                      
                      (Select f.Nr_Ano || f.Nr_Mes As Competencia,
                              f.Nr_Ano,
                              Custom.Fnc_Mes_Por_Extenso(p_Mes => f.Nr_Mes) As Mes,
                              Count(Distinct Ch.Nr_Guia) As Total_Internacao
                         From Dbaps.Conta_Hospitalar   Ch,
                              Dbaps.Itconta_Hospitalar Ih,
                              Dbaps.Itconta_Med        Im,
                              Dbaps.Lote               l,
                              Dbaps.Fatura             f,
                              Dbaps.Prestador          p
                       
                        Where f.Cd_Fatura = l.Cd_Fatura
                          And l.Cd_Lote = Ch.Cd_Lote
                          And Ch.Cd_Conta_Hospitalar = Ih.Cd_Conta_Hospitalar
                          And Ih.Cd_Conta_Hospitalar = Im.Cd_Conta_Hospitalar
                          And Ih.Cd_Lancamento = Im.Cd_Lancamento
                          And p.Cd_Prestador = l.Cd_Prestador --PRESTADOR QUE ENVIOU O LOTE GUIAS (LOCAL DO ATENDIMENTO).
                             
                          And f.Nr_Ano >= '2022'
                          And f.Tp_Fatura = 'P'
                          And (Ih.Cd_Motivo <> 24 Or Ih.Cd_Motivo Is Null) --glosa de duplicidade 
                             
                          And Not Exists
                        (Select 1
                                 From Dbaps.Prestador_Acreditacao Pa
                                Where Pa.Cd_Prestador = p.Cd_Prestador
                                  And Pa.Tp_Nivel_Acreditacao = 3)
                          And p.Cd_Grupo_Prestador In (2, 19)
                          And l.Cd_Tipo_Atendimento = 3 -- SOMENTE INTERNA��O
                        Group By f.Nr_Ano,
                                 f.Nr_Ano || f.Nr_Mes,
                                 Custom.Fnc_Mes_Por_Extenso(p_Mes => f.Nr_Mes)) b
                Where a.Competencia = b.Competencia) x
        Where Not Exists (Select 1
                 From Custom.Rn507_Acreditacao_Prest_Ps_Internacao Ra
                Where Ra.Competencia = x.Competencia));
    Commit;
  End Prc_Calc_Prest_Acred_Ps_Internacao;

  Procedure Prc_Apaga_Registros(p_Delete_Informacao In Varchar2) Is
  Begin
  
    If (p_Delete_Informacao = 'PREST_ACREDITACAO_PS') Then
      Delete From Custom.Rn507_Acreditacao_Prest_Ps_Internacao Ra
       Where Ra.Competencia Between To_Char(Sysdate, 'YYYYMM') - 3 And
             To_Char(Sysdate, 'YYYYMM') + 1;
      Commit;
    End If;
  
  End Prc_Apaga_Registros;

  Function Fnc_Get_Db_Link Return Varchar2
  
   Is
    Vexisteconexacaohms Char(1) := 'N';
  Begin
  
    Select 'S'
      Into Vexisteconexacaohms
      From Global_Name@Ormvgh.Unimed.Com.Br;
    Return Vexisteconexacaohms;
  
  Exception
    When Others Then
      Vexisteconexacaohms := 'N';
    
  End Fnc_Get_Db_Link;

  Function Fnc_Get_Dados_Ps_Hms Return Number
  
   Is
    Vconectahms Char(1) := 'N';
    Vreturn     Number := 0;
  Begin
    Vconectahms := Fnc_Get_Db_Link();
  
    If (Vconectahms = 'S') Then
      Vreturn := 1;
    
      Insert Into Custom.Rn507_Rede_Cred_Dados_Ps_Hms
        (Select x.Cd_Paciente,
                x.Nm_Paciente,
                x.Nr_Guia,
                x.Nr_Carteira,
                x.Cd_Atendimento,
                x.Nr_Cpf,
                x.Dt_Atendimento,
                Sysdate As Dt_Log
           From (Select To_Date(To_Char(a.Dt_Atendimento, 'DD/MM/YYYY') ||
                                To_Char(a.Hr_Atendimento, 'HH24:MI:SS'),
                                'DD/MM/YYYY HH24:MI:SS') As Dt_Atendimento,
                        a.Cd_Atendimento As Cd_Atendimento,
                        a.Nr_Carteira As Nr_Carteira,
                        p.Cd_Paciente As Cd_Paciente,
                        p.Nr_Cpf As Nr_Cpf,
                        p.Nm_Paciente As Nm_Paciente,
                        Coalesce(a.Nr_Guia,
                                 (Select Max(g.Nr_Guia)
                                    From Guia@Ormvgh.Unimed.Com.Br g
                                   Where a.Cd_Atendimento = g.Cd_Atendimento)) As Nr_Guia
                   From Dbamv.Paciente@Ormvgh p, Dbamv.Atendime@Ormvgh a
                  Where p.Cd_Paciente = a.Cd_Paciente
                    And a.Cd_Ori_Ate In
                        (Select Oa.Cd_Ori_Ate
                           From Ori_Ate@Ormvgh Oa
                          Where Oa.Tp_Origem = 'U'
                            And Oa.Ds_Ori_Ate Not Like '%ZN%'
                            And Oa.Cd_Multi_Empresa = 1)
                    And a.Tp_Atendimento = 'U'
                    And a.Dt_Atendimento >= '01/01/2022'
                    And a.Cd_Pro_Int = '10101039') x
          Where x.Nr_Guia Is Not Null
            And Not Exists
          (Select 1
                   From Custom.Rn507_Rede_Cred_Dados_Ps_Hms Rhms
                  Where Rhms.Cd_Atendimento = x.Cd_Atendimento)
         
         );
      Commit;
      Return Vreturn;
    End If;
  End Fnc_Get_Dados_Ps_Hms;

End Pkg_Rn507;
/
