select * from CUSTOM.VW_PAINEL_AJIUS v
Where Trunc(v.Dh_Geracao) Between '01/04/2022' And '30/04/2022'
And v.Ds_Arquivo = 'NC1_1800109.865' ;


Select pc.*
  From Ptu_A500 p, Ptu_Remessa_Retorno Pr, Ptu_A500_Cabecalho Pc
 Where p.Cd_Ptu_Remessa_Retorno = Pr.Cd_Ptu_Remessa_Retorno
   And Pc.Cd_Ptu_A500 = p.Cd_Ptu_A500
   And Pr.Tp_Status = 'E'
   And Pr.Ds_Arquivo Like '%1800109%' 
   
   
   Select * From Dbaps.Ptu_A550_Cabecalho 
   
   vl_tot_pago_doc_1

