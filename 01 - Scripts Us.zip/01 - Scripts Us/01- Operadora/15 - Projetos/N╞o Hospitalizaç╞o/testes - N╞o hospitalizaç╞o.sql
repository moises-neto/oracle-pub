Delete From Custom.Itguia_Integracao_Hms;
Delete From Custom.guia_integracao_hms;

Select * From Custom.Itguia_Integracao_Hms;
Select *  From custom.guia_integracao_hms;

Select * from CUSTOM.LOG_PROCESS_INTEGRA_GUIA_HMS
Order By 1 Desc;



Call custom.pkg_integracao_guia_ope_hms.Prc_Exec_Integracao();


Delete From guia g
Where g.nr_guia In(112620699,112620689)



    Select *
        From Table(custom.pkg_integracao_guia_ope_hms.Fnc_Get_Table_Prestador(p_Cpf_Cnpj => 1002398))

      
    Select * From ITGUIA IT
    Where IT.nr_guia In(112578249,112578239)    
    
    
