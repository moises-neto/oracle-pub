Call Custom.Prc_Integracao_Guia_Ope_Hms();



Declare
  Vret Varchar2(100);
Begin
  Vret := Custom.Pkg_Integracao_Guia_Ope_Hms.Fnc_Seq_Protocolo_Ans(p_Nr_Guia => 110997259, 
                                                                   p_Cd_Matricula => 8650003283920018);

  Dbms_Output.Put_Line('Sequence: ' || Vret);
End;
        


Declare
        vnr Varchar2(100);
        Begin
            vnr := DBAPS.FNC_GERAR_NR_TRANSACAO_GUIA();
            dbms_output.put_line(vnr);
  End;
