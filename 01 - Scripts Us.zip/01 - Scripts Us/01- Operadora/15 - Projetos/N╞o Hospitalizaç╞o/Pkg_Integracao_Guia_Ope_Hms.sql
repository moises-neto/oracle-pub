Create Or Replace Noneditionable Package Custom.Pkg_Integracao_Guia_Ope_Hms Is

  /******************************************************************************************************
  * OBJETO: CUSTOM.PKG_INTEGRACAO_GUIA_OPE_HMS                                                        * 
  *****************************************************************************************************
  * M�DULO: SOUL MV - PLANO DE SA�DE (Guias - GUIA                                                    * 
  * OBJETIVO: ATRAVES DO DOCUMENTO PREENCHIDO NO PEP - CADASTRAR UMA GUIA NA OPERADORA                *
  *****************************************************************************************************
  |---------------------------------------------------------------------------------------------------|
  |  CHAMADO   |     DATA   |   SOLICITANTE    |   RESPONS�VEL     |  VERS�O  | ALTERA��O             |
  |------------+------------+------------------+-------------------+----------------------------------|
  |CH2301-5219 | 23/02/2023 | FERNANDA TREVISAN| MOIS�S DE SOUZA   |  1.0     | CRIA��O PACKAGE       |
  |------------+------------+------------------+-------------------+----------+-----------------------|
  ****************************************************************************************************/

  --BLOCO DE FUNCTION CABE�ALHO
  Function Fnc_Get_Seq_Guia Return Number;
  Function Fnc_Get_Seq_Itguia Return Number;
  Function Fnc_Get_Seq_Nr_Transacao Return Varchar2;
  Function Fnc_Get_Seq_Protocolo_Ans(p_Nr_Guia      In Number,
                                     p_Cd_Matricula In Number Default Null)
    Return Number;
  Function Fnc_Get_Dblink Return Number;

  Function Fnc_Insere_Guia(p_Tp_Sexo                   In Char,
                           p_Cd_Cid                    In Varchar2,
                           p_Sn_Atendimento_Recem_Nato In Char Default 'N',
                           p_Nr_Dd_Sms                 In Varchar2,
                           p_Nr_Celular_Sms            In Varchar2,
                           p_Ds_Email_Beneficiario     In Varchar2,
                           p_Nr_Carteira_Utilizada     In Varchar2,
                           p_Nm_Beneficiario           In Varchar2,
                           p_Cpf_Cnpj_Prestador_Exec   In Varchar2,
                           p_Cpf_Cnpj_Prestador_Solic  In Varchar2)
    Return Number;

  --BLOCO DE FUNCTION TABLE E RECORD CABE�ALHO  
  Type Rowprestador Is Record(
    Cd_Prestador             Dbaps.Prestador.Cd_Prestador%Type,
    Nm_Prestador             Dbaps.Prestador.Nm_Prestador%Type,
    Ds_Cod_Conselho          Dbaps.Prestador.Ds_Cod_Conselho%Type,
    Uf_Conselho              Dbaps.Prestador.Uf_Conselho%Type,
    Cd_Conselho_Profissional Dbaps.Prestador.Cd_Conselho_Profissional%Type);

  Type Get_Table_Prestador Is Table Of Rowprestador;

  Function Fnc_Get_Table_Prestador(p_Cpf_Cnpj In Varchar2)
    Return Get_Table_Prestador
    Pipelined;

  Type Rowbeneficiario Is Record(
    Cd_Matricula             Dbaps.Usuario.Cd_Matricula%Type,
    Cd_Beneficiario_Transito Dbaps.Beneficiario_Transito.Cd_Beneficiario_Transito%Type,
    Carteira                 Dbaps.Usuario.Cd_Mat_Alternativa%Type,
    Nm_Segurado              Dbaps.Usuario.Nm_Segurado%Type,
    Cd_Contrato              Dbaps.Usuario.Cd_Contrato%Type,
    Cd_Plano                 Dbaps.Usuario.Cd_Plano%Type,
    Cd_Tip_Acomodacao        Dbaps.Plano.Cd_Tip_Acomodacao%Type);

  Type Get_Table_Beneficiario Is Table Of Rowbeneficiario;

  Function Fnc_Get_Table_Beneficiario(p_Nr_Carteira In Varchar2)
    Return Get_Table_Beneficiario
    Pipelined;

  Type r_Guia_Padrao Is Record(
    Dt_Vencimento            Dbaps.Guia.Dt_Vencimento%Type Default Sysdate,
    Dt_Emissao               Dbaps.Guia.Dt_Emissao%Type Default Sysdate,
    Dt_Prev_Execucao         Dbaps.Guia.Dt_Prev_Execucao%Type Default Sysdate,
    Sn_Valida_Rest_Carencia  Dbaps.Guia.Sn_Valida_Rest_Carencia%Type Default 'N',
    Cd_Autorizador           Dbaps.Guia.Cd_Autorizador%Type Default 1704,
    Cd_Id_Usuario            Dbaps.Guia.Cd_Id_Usuario%Type Default 109,
    Tp_Origem                Dbaps.Guia.Tp_Origem%Type Default 'MVS',
    Tp_Carater_Solic_Inter   Dbaps.Guia.Tp_Carater_Solic_Inter%Type Default 'E',
    Cd_Multi_Empresa         Dbaps.Guia.Cd_Multi_Empresa%Type Default 1,
    Cd_Indicador_Acidente    Dbaps.Guia.Cd_Indicador_Acidente%Type Default 4,
    Cd_Unimed_Executora      Dbaps.Guia.Cd_Unimed_Executora%Type Default '018',
    Cd_Unimed_Solicitante    Dbaps.Guia.Cd_Unimed_Solicitante%Type Default '018',
    Tp_Fluxo_Ptu_Ws          Dbaps.Guia.Tp_Fluxo_Ptu_Ws%Type,
    Tp_Autorizacao_Ptu       Dbaps.Guia.Tp_Autorizacao_Ptu%Type Default 1,
    Cd_Etapa_Autorizacao     Dbaps.Guia.Cd_Etapa_Autorizacao%Type Default 1,
    Cd_Tipo_Atendimento      Dbaps.Guia.Cd_Tipo_Atendimento%Type Default 2,
    Cd_Matricula             Dbaps.Guia.Cd_Matricula%Type,
    Cd_Beneficiario_Transito Dbaps.Guia.Cd_Beneficiario_Transito%Type,
    Ds_Destino_Cortesia      Dbaps.Guia.Ds_Destino_Cortesia%Type,
    Cd_Contrato              Dbaps.Guia.Cd_Contrato%Type,
    Cd_Plano                 Dbaps.Guia.Cd_Plano%Type,
    Nm_Prestador             Dbaps.Guia.Nm_Prestador%Type,
    Cd_Prestador             Dbaps.Guia.Cd_Prestador%Type,
    Cd_Prestador_Executor    Dbaps.Guia.Cd_Prestador_Executor%Type,
    Cd_Prestador_Solicitante Dbaps.Guia.Cd_Prestador_Solicitante%Type,
    Nr_Transacao             Dbaps.Guia.Nr_Transacao%Type,
    Nr_Guia                  Dbaps.Guia.Nr_Guia%Type,
    Nr_Protocolo_Ans         Dbaps.Guia.Nr_Protocolo%Type,
    Cd_Tip_Acomodacao        Dbaps.Guia.Cd_Tip_Acomodacao%Type,
    Cd_Cortesia              Dbaps.Guia.Cd_Cortesia%Type,
    Nr_Carteira_Beneficiario Dbaps.Guia.Nr_Carteira_Beneficiario%Type);

  Type r_Itguia_Padrao Is Record(
    Cd_Procedimento     Dbaps.Itguia.Cd_Procedimento%Type,
    Cd_Procedimento_Ptu Dbaps.Itguia.Cd_Procedimento_Ptu%Type,
    Vl_Procedimento     Dbaps.Itguia.Vl_Procedimento%Type,
    Qt_Solic_Prest      Dbaps.Itguia.Qt_Solic_Prest%Type,
    Vl_Servico          Dbaps.Itguia.Vl_Servico%Type,
    Nr_Anvisa           Dbaps.Itguia.Nr_Anvisa%Type,
    Nr_Sq_Item_Tiss     Dbaps.Itguia.Nr_Sq_Item_Tiss%Type,
    Nr_Guia             Dbaps.Itguia.Nr_Guia%Type,
    Cd_Itguia           Dbaps.Itguia.Cd_Itguia%Type);

  --BLOCO DE PROCEDURE CABE�ALHO
  Procedure Prc_Insere_Log_Process(p_Objeto Varchar2, p_Ds_Log Varchar2);
  Procedure Prc_Exec_Integracao;
  Procedure Prc_Insere_Autorizacao;
  Procedure Prc_Insere_Itguia(p_Nr_Guia             In Number,
                              p_Cd_Procedimento     In Varchar2,
                              p_Cd_Procedimento_Ptu In Varchar2,
                              p_Nr_Anvisa           In Number,
                              p_Nr_Sq_Item_Tiss     In Number,
                              p_Qt_Solic_Prest      In Number,
                              p_Vl_Procedimento     In Number,
                              p_Vl_Servico          In Number);
End;
/
Create Or Replace Noneditionable Package Body Custom.Pkg_Integracao_Guia_Ope_Hms Is
  /******************************************************************************************************
  * OBJETO: CUSTOM.PKG_INTEGRACAO_GUIA_OPE_HMS                                                        * 
  *****************************************************************************************************
  * M�DULO: SOUL MV - PLANO DE SA�DE (Guias - GUIA                                                    * 
  * OBJETIVO: ATRAVES DO DOCUMENTO PREENCHIDO NO PEP - CADASTRAR UMA GUIA NA OPERADORA                *
  *****************************************************************************************************
  |---------------------------------------------------------------------------------------------------|
  |  CHAMADO   |     DATA   |   SOLICITANTE    |   RESPONS�VEL     |  VERS�O  | ALTERA��O             |
  |------------+------------+------------------+-------------------+----------------------------------|
  |CH2301-5219 | 23/02/2023 | FERNANDA TREVISAN| MOIS�S DE SOUZA   |  1.0     | CRIA��O PACKAGE BODY  |
  |------------+------------+------------------+-------------------+----------+-----------------------|
  ****************************************************************************************************/

  /*BLOCO DE FUNCTIONS*/

  /*Seq GUIA*/

  Function Fnc_Get_Seq_Guia Return Number
  
   Is
    Vreturnguia Number := 0;
    Vdigitoguia Constant Pls_Integer := 9;
  
  Begin
  
    Select Dbaps.Seq_Guia.Nextval Into Vreturnguia From Dual;
    Vreturnguia := Vreturnguia || Vdigitoguia;
  
    Return Vreturnguia;
    Dbms_Output.Put_Line('Seq GUIA: ' || Vreturnguia);
  
  End Fnc_Get_Seq_Guia;
  /*Seq ITGUIA*/

  Function Fnc_Get_Seq_Itguia Return Number
  
   Is
    Vreturnitguia Number := 0;
  
  Begin
    Select Dbaps.Seq_Cd_Itguia.Nextval Into Vreturnitguia From Dual;
  
    Return Vreturnitguia;
    Dbms_Output.Put_Line('Seq ITGUIA: ' || Vreturnitguia);
  End Fnc_Get_Seq_Itguia;

  Function Fnc_Get_Seq_Nr_Transacao Return Varchar2 Is
    Vreturntransacao Varchar2(100);
  Begin
    Vreturntransacao := Dbaps.Fnc_Gerar_Nr_Transacao_Guia();
  
    Return Vreturntransacao;
  
  End Fnc_Get_Seq_Nr_Transacao;

  Function Fnc_Get_Seq_Protocolo_Ans(p_Nr_Guia      In Number,
                                     p_Cd_Matricula In Number Default Null)
  
   Return Number Is
    Nprotocoloans Number;
  Begin
  
    Nprotocoloans := Dbaps.Fnc_Protocolo_Ans(Nvl(Dbaps.Fnc_Mvs_Retorna_Valor_Config('ATEND_PROTANS_MOTIVO_PADRAO',
                                                                                    1),
                                                 9020),
                                             p_Nr_Guia,
                                             p_Cd_Matricula,
                                             Null,
                                             Null,
                                             1);
  
    Return Nprotocoloans;
  
    --PROTOCOLO ANS
  End Fnc_Get_Seq_Protocolo_Ans;

  Function Fnc_Get_Dblink Return Number Is
  
    Vreturn Number := 0;
  Begin
    Begin
      Select 1 Into Vreturn From Global_Name@Ormvgh.Unimed.Com.Br; --TESTANDO DBLINK ormvgh
    Exception
      When Others Then
        Vreturn := 0;
    End;
  
    Return Vreturn;
  End Fnc_Get_Dblink;

  Function Fnc_Get_Table_Prestador(p_Cpf_Cnpj In Varchar2)
    Return Get_Table_Prestador
    Pipelined Is
    Cursor Cdadosprestadorsolic Is
    
      Select p.Cd_Prestador,
             p.Nm_Prestador,
             p.Ds_Cod_Conselho,
             p.Uf_Conselho,
             p.Cd_Conselho_Profissional
        From Dbaps.Prestador p
      
       Where p.Nr_Cpf_Cgc = p_Cpf_Cnpj
       
      Union All
      
       Select p.Cd_Prestador,
             p.Nm_Prestador,
             p.Ds_Cod_Conselho,
             p.Uf_Conselho,
             p.Cd_Conselho_Profissional
        From Dbaps.Prestador p
      
       Where p.cd_prestador = p_Cpf_Cnpj;
  
    Rowgetprestador Rowprestador;
  Begin
    For i In Cdadosprestadorsolic Loop
      Rowgetprestador.Cd_Prestador             := i.Cd_Prestador;
      Rowgetprestador.Nm_Prestador             := i.Nm_Prestador;
      Rowgetprestador.Ds_Cod_Conselho          := i.Ds_Cod_Conselho;
      Rowgetprestador.Cd_Conselho_Profissional := i.Cd_Conselho_Profissional;
      Pipe Row(Rowgetprestador);
    End Loop;
    Return;
  Exception
    When Others Then
      Raise_Application_Error(-20999,
                              'Falha na Fnc_Get_Table_Prestador: ' ||
                              Sqlerrm);
  End Fnc_Get_Table_Prestador;

  Function Fnc_Get_Table_Beneficiario(p_Nr_Carteira In Varchar2)
    Return Get_Table_Beneficiario
    Pipelined Is
    Cursor Cbeneficiario Is
      Select u.Cd_Matricula,
             Null                 As Cd_Beneficiario_Transito,
             u.Cd_Mat_Alternativa As Carteira,
             u.Nm_Segurado,
             u.Cd_Contrato,
             p.Cd_Plano,
             p.Cd_Tip_Acomodacao
        From Dbaps.Usuario u, Dbaps.Plano p
       Where u.Cd_Plano = p.Cd_Plano
         And u.Cd_Mat_Alternativa = p_Nr_Carteira
         And u.Sn_Ativo = 'S'
      
      Union All
      
      Select Null                        As Cd_Matricula,
             Bt.Cd_Beneficiario_Transito As Cd_Beneficiario_Transito,
             Bt.Cd_Matricula             As Carteira,
             Bt.Nm_Segurado,
             Null                        As Cd_Contrato,
             Null                        As Cd_Plano,
             Null                        As Cd_Tip_Acomodacao
        From Dbaps.Beneficiario_Transito Bt
       Where Bt.Cd_Matricula = p_Nr_Carteira;
  
    Rowgetbeneficiario Rowbeneficiario;
  Begin
    For i In Cbeneficiario Loop
      Rowgetbeneficiario.Cd_Matricula             := i.Cd_Matricula;
      Rowgetbeneficiario.Carteira                 := i.Carteira;
      Rowgetbeneficiario.Nm_Segurado              := i.Nm_Segurado;
      Rowgetbeneficiario.Cd_Contrato              := i.Cd_Contrato;
      Rowgetbeneficiario.Cd_Plano                 := i.Cd_Plano;
      Rowgetbeneficiario.Cd_Tip_Acomodacao        := i.Cd_Tip_Acomodacao;
      Rowgetbeneficiario.Cd_Beneficiario_Transito := i.Cd_Beneficiario_Transito;
      Pipe Row(Rowgetbeneficiario);
    End Loop;
    Return;
  Exception
    When Others Then
      Raise_Application_Error(-20999,
                              'Falha na get_Table_beneficiario: ' ||
                              Sqlerrm);
  End Fnc_Get_Table_Beneficiario;

  Function Fnc_Insere_Guia(p_Tp_Sexo                   In Char,
                           p_Cd_Cid                    In Varchar2,
                           p_Sn_Atendimento_Recem_Nato In Char Default 'N',
                           p_Nr_Dd_Sms                 In Varchar2,
                           p_Nr_Celular_Sms            In Varchar2,
                           p_Ds_Email_Beneficiario     In Varchar2,
                           p_Nr_Carteira_Utilizada     In Varchar2,
                           p_Nm_Beneficiario           In Varchar2,
                           p_Cpf_Cnpj_Prestador_Exec   In Varchar2,
                           p_Cpf_Cnpj_Prestador_Solic  In Varchar2)
    Return Number Is
  
    -- declare a record
    r_Guia r_Guia_Padrao;
  
    --variaveis 
    v_Cd_Tipo_Atendimento_Tiss Pls_Integer := Null;
    v_Cd_Versao_Tiss           Varchar2(10);
    v_Cd_Versao_Ptu            Varchar2(5);
    v_Cd_Unimed_Origem         Char(3);
    v_Nr_Dias_Vencimento_Guia  Pls_Integer := Null;
  
    /*  v_Nm_Prestador               Varchar2(500) := Null;
       v_Nr_Reg_Conselho_Prof_Solic Varchar2(15) := Null;
       v_Uf_Conselho_Prof_Solc      Varchar2(2) := Null;
       v_Cd_Tiss_Conselho_Prof_Sol  Pls_Integer := Null;
    */
  
    Vreturnguia Number := 0;
    --cursores 
  
    Cursor Cregrasdinamicas Is
      Select --Decode(p_Cd_Prestador_Executor, 1001553, 13, 1002398, 6) As Cd_Atendimento_Tiss,
       Substr(p_Nr_Carteira_Utilizada, 0, 3) As Cd_Unimed_Origem,
       (Select m.Valor
          From Dbaps.Mvs_Configuracao m
         Where m.Chave = 'VERSAO_TISS') As Versao_Tiss,
       (Select m.Valor
          From Dbaps.Mvs_Configuracao m
         Where m.Chave = 'VERSAO_PTU_ONLINE') As Versao_Ptu_Onine,
       (Select Me.Nr_Dias_Vencimento_Da_Guia
          From Dbamv.Multi_Empresas_Mv_Saude Me
         Where Me.Cd_Multi_Empresa = 1) As v_Nr_Dias_Vencimento_Guia
      
        From Dual;
  
    Cursor Cgetbeneficiario Is
      Select *
        From Table(Fnc_Get_Table_Beneficiario(p_Nr_Carteira => p_Nr_Carteira_Utilizada));
  
    Cursor Cgetprestadorsolicitante Is
    
      Select *
        From Table(Fnc_Get_Table_Prestador(p_Cpf_Cnpj => p_Cpf_Cnpj_Prestador_Solic));
  
    Cursor Cgetprestadorexec Is
    
      Select *
        From Table(Fnc_Get_Table_Prestador(p_Cpf_Cnpj => p_Cpf_Cnpj_Prestador_Exec));
  Begin
  
    If (1 = 1) Then
    
      Prc_Insere_Log_Process(p_Objeto => 'Fnc_Insere_Guia',
                             p_Ds_Log => 'INICIANDO A AN�LISE DOS DADOS');
      Open Cregrasdinamicas;
      Fetch Cregrasdinamicas
        Into v_Cd_Unimed_Origem,
             v_Cd_Versao_Tiss,
             v_Cd_Versao_Ptu,
             v_Nr_Dias_Vencimento_Guia;
      Close Cregrasdinamicas;
    
      For Beneficiario In Cgetbeneficiario Loop
        Begin
          r_Guia.Cd_Matricula      := Beneficiario.Cd_Matricula;
          r_Guia.Cd_Contrato       := Beneficiario.Cd_Contrato;
          r_Guia.Cd_Plano          := Beneficiario.Cd_Plano;
          r_Guia.Cd_Tip_Acomodacao := Beneficiario.Cd_Tip_Acomodacao;
        
          Prc_Insere_Log_Process(p_Objeto => 'Fnc_Insere_Guia',
                                 p_Ds_Log => 'Carregou o Cdadosbeneficiario e incluiu os dados na TYPE r_Guia: ' ||
                                            
                                             Chr(10) ||
                                             'Beneficiario Sorocaba: ' ||
                                             Chr(10) || 'Cd_Matricula: ' ||
                                             r_Guia.Cd_Matricula || Chr(10) ||
                                             'Cd_Contrato: ' ||
                                             r_Guia.Cd_Contrato || Chr(10) ||
                                             'Cd_Plano: ' || r_Guia.Cd_Plano ||
                                             Chr(10) ||
                                             'Cd_Tip_Acomodacao: ' ||
                                             r_Guia.Cd_Tip_Acomodacao);
        
          If (v_Cd_Unimed_Origem <> '018') Then
            r_Guia.Cd_Beneficiario_Transito := Beneficiario.Cd_Beneficiario_Transito;
            r_Guia.Nr_Carteira_Beneficiario := Nvl(p_Nr_Carteira_Utilizada,
                                                   Beneficiario.Carteira);
            r_Guia.Ds_Destino_Cortesia      := Nvl(Beneficiario.Nm_Segurado,
                                                   p_Nm_Beneficiario);
            r_Guia.Cd_Cortesia              := 9000;
            r_Guia.Tp_Fluxo_Ptu_Ws          := 'CLIENT';
          
            Prc_Insere_Log_Process(p_Objeto => 'Fnc_Insere_Guia',
                                   p_Ds_Log => 'Carregou o Cdadosbeneficiario e incluiu os dados na TYPE r_Guia: ' ||
                                               Chr(10) ||
                                               'Beneficiario Interc�mbio: ' ||
                                               Chr(10) ||
                                               'Cd_Beneficiario_Transito: ' ||
                                               r_Guia.Cd_Beneficiario_Transito ||
                                               Chr(10) ||
                                               'Nr_Carteira_Beneficiario: ' ||
                                               r_Guia.Nr_Carteira_Beneficiario ||
                                               Chr(10) ||
                                               'Ds_Destino_Cortesia: ' ||
                                               r_Guia.Ds_Destino_Cortesia ||
                                               Chr(10) || 'Cd_Cortesia: ' ||
                                               r_Guia.Cd_Cortesia || Chr(10) ||
                                               'Tp_Fluxo_Ptu_Ws: ' ||
                                               r_Guia.Tp_Fluxo_Ptu_Ws);
          
          End If;
        Exception
          When Others Then
            Vreturnguia := 0;
            Raise_Application_Error(-20001,
                                    'Erro ao carregar CGetbeneficiario: ' ||
                                    Sqlerrm);
        End;
      
      End Loop;
    
      For Prestadorsolic In Cgetprestadorsolicitante Loop
      
        Begin
          r_Guia.Nm_Prestador := Prestadorsolic.Nm_Prestador;
          r_Guia.Cd_Prestador := Prestadorsolic.Cd_Prestador;
          Prc_Insere_Log_Process(p_Objeto => 'Fnc_Insere_Guia',
                                 p_Ds_Log => 'Carregou o cGetPrestadorSolicitante e incluiu os dados na TYPE r_Guia: ' ||
                                             Chr(10) || 'Nm_Prestador: ' ||
                                             r_Guia.Nm_Prestador || Chr(10) ||
                                             'Cd_Prestador: ' ||
                                             r_Guia.Cd_Prestador);
        
        Exception
          When Others Then
            Vreturnguia := 0;
            Raise_Application_Error(-20001,
                                    'Erro ao carregar Cgetprestadorsolicitante: ' ||
                                    Sqlerrm);
        End;
      
      End Loop;
    
      For Prestadorexec In Cgetprestadorexec Loop
      
        Begin
          r_Guia.Cd_Prestador_Executor := Prestadorexec.Cd_Prestador;
        
          If (r_Guia.Cd_Prestador_Executor = 1001553) Then
            v_Cd_Tipo_Atendimento_Tiss := 13;
          Elsif (r_Guia.Cd_Prestador_Executor = 1002398) Then
            v_Cd_Tipo_Atendimento_Tiss := 6;
          Else
            v_Cd_Tipo_Atendimento_Tiss := Null;
          End If;
        
          Prc_Insere_Log_Process(p_Objeto => 'Fnc_Insere_Guia',
                                 p_Ds_Log => 'Carregou o Cgetprestadorexec e incluiu os dados na TYPE r_Guia: ' ||
                                             Chr(10) || 'Cd_Prestador: ' ||
                                             r_Guia.Cd_Prestador_Executor);
        
        Exception
          When Others Then
            Vreturnguia := 0;
            Raise_Application_Error(-20001,
                                    'Erro ao carregar cGetPrestadorExec: ' ||
                                    Sqlerrm);
        End;
      
      End Loop;
    
      --ATRIBUINDO AS SEQUENCES
    
      r_Guia.Nr_Transacao     := Fnc_Get_Seq_Nr_Transacao();
      r_Guia.Nr_Guia          := Fnc_Get_Seq_Guia();
      r_Guia.Nr_Protocolo_Ans := Fnc_Get_Seq_Protocolo_Ans(p_Nr_Guia => r_Guia.Nr_Guia);
    
      Prc_Insere_Log_Process(p_Objeto => 'Fnc_Insere_Guia',
                             p_Ds_Log => 'Carregou as sequencias na TYPE r_Guia: ' ||
                                         Chr(10) || 'Transa��o: ' ||
                                         r_Guia.Nr_Transacao || Chr(10) ||
                                         'Guia: ' || r_Guia.Nr_Guia ||
                                         Chr(10) || 'Protocolo ANS: ' ||
                                         r_Guia.Nr_Protocolo_Ans || Chr(10));
    
      ---Variaveis dinamicas:
      Prc_Insere_Log_Process(p_Objeto => 'Fnc_Insere_Guia',
                             p_Ds_Log => 'Carregou todas as vari�veis din�micas: ' ||
                                         Chr(10) ||
                                         'v_Cd_Tipo_Atendimento_Tiss: ' ||
                                         v_Cd_Tipo_Atendimento_Tiss ||
                                         Chr(10) || 'v_Cd_Versao_Tiss: ' ||
                                         v_Cd_Versao_Tiss || Chr(10) ||
                                         'v_Cd_Versao_Ptu: ' ||
                                         v_Cd_Versao_Ptu || Chr(10) ||
                                         'v_Cd_Unimed_Origem: ' ||
                                         v_Cd_Unimed_Origem || Chr(10) ||
                                         'v_Nr_Dias_Vencimento_Guia: ' ||
                                         v_Nr_Dias_Vencimento_Guia);
    
      Insert Into Dbaps.Guia
        (Nr_Guia,
         Cd_Matricula,
         Cd_Prestador,
         Cd_Prestador_Executor,
         Dt_Emissao,
         Dt_Vencimento,
         Cd_Autorizador,
         Dt_Prev_Execucao,
         Cd_Cortesia,
         Ds_Destino_Cortesia,
         Sn_Valida_Rest_Carencia,
         Cd_Tipo_Atendimento,
         Cd_Id_Usuario,
         Cd_Tip_Acomodacao,
         Cd_Prestador_Solicitante,
         Cd_Plano,
         Cd_Cid,
         Tp_Origem,
         Tp_Sexo,
         Tp_Carater_Solic_Inter,
         Cd_Multi_Empresa,
         Cd_Indicador_Acidente,
         Cd_Tipo_Atendimento_Tiss,
         Cd_Prestador_Solicitado,
         Sn_Atendimento_Recem_Nato,
         Cd_Versao_Tiss,
         Ds_Email_Profissional,
         Nr_Telefone_Profissional,
         Nm_Profissional_Solicitante,
         Nr_Protocolo,
         Nm_Prestador_Solicitante,
         Cd_Beneficiario_Transito,
         Cd_Versao_Ptu,
         Cd_Unimed_Executora,
         Cd_Unimed_Origem,
         Cd_Unimed_Solicitante,
         Nr_Carteira_Beneficiario,
         Tp_Fluxo_Ptu_Ws,
         Nr_Ddd_Sms,
         Nr_Celular_Sms,
         Nr_Transacao,
         Nm_Prestador,
         Ds_Email_Beneficiario,
         Nr_Carteira_Utilizada,
         Nr_Reg_Conselho_Prof_Solic,
         Uf_Conselho_Prof_Solc,
         Cd_Tiss_Conselho_Prof_Sol,
         Cd_Etapa_Autorizacao,
         Cd_Contrato)
      
      Values
        (r_Guia.Nr_Guia,
         r_Guia.Cd_Matricula,
         r_Guia.Cd_Prestador,
         r_Guia.Cd_Prestador_Executor,
         r_Guia.Dt_Emissao,
         r_Guia.Dt_Vencimento + v_Nr_Dias_Vencimento_Guia,
         r_Guia.Cd_Autorizador,
         r_Guia.Dt_Prev_Execucao,
         r_Guia.Cd_Cortesia,
         r_Guia.Ds_Destino_Cortesia,
         r_Guia.Sn_Valida_Rest_Carencia,
         r_Guia.Cd_Tipo_Atendimento,
         r_Guia.Cd_Id_Usuario,
         r_Guia.Cd_Tip_Acomodacao,
         Null, --r_Guia.Cd_Prestador_Solicitante,
         r_Guia.Cd_Plano,
         p_Cd_Cid,
         r_Guia.Tp_Origem,
         p_Tp_Sexo, --r_Guia.Tp_Sexo,
         r_Guia.Tp_Carater_Solic_Inter,
         r_Guia.Cd_Multi_Empresa,
         r_Guia.Cd_Indicador_Acidente,
         v_Cd_Tipo_Atendimento_Tiss, -- r_Guia.Cd_Tipo_Atendimento_Tiss,
         Null, -- r_Guia.Cd_Prestador_Solicitado,
         p_Sn_Atendimento_Recem_Nato, --r_Guia.Sn_Atendimento_Recem_Nato,
         v_Cd_Versao_Tiss, --r_Guia.Cd_Versao_Tiss,
         Null, --r_Guia.Ds_Email_Profissional,
         Null, --r_Guia.Nr_Telefone_Profissional,
         Null, -- r_Guia.Nm_Profissional_Solicitante,
         r_Guia.Nr_Protocolo_Ans,
         Null, --r_Guia.Nm_Prestador_Solicitante,
         r_Guia.Cd_Beneficiario_Transito,
         v_Cd_Versao_Ptu, --r_Guia.Cd_Versao_Ptu,
         r_Guia.Cd_Unimed_Executora,
         v_Cd_Unimed_Origem, --r_Guia.Cd_Unimed_Origem,
         r_Guia.Cd_Unimed_Solicitante,
         r_Guia.Nr_Carteira_Beneficiario,
         r_Guia.Tp_Fluxo_Ptu_Ws,
         p_Nr_Dd_Sms, --r_Guia.Nr_Ddd_Sms,
         p_Nr_Celular_Sms, --r_Guia.Nr_Celular_Sms,
         r_Guia.Nr_Transacao,
         r_Guia.Nm_Prestador,
         p_Ds_Email_Beneficiario, --r_Guia.Ds_Email_Beneficiario,
         p_Nr_Carteira_Utilizada, --r_Guia.Nr_Carteira_Utilizada,
         Null, --r_Guia.Nr_Reg_Conselho_Prof_Solic,
         Null, --r_Guia.Uf_Conselho_Prof_Solc,
         Null, --r_Guia.Cd_Tiss_Conselho_Prof_Sol,
         r_Guia.Cd_Etapa_Autorizacao,
         r_Guia.Cd_Contrato);
      Commit;
      Prc_Insere_Log_Process(p_Objeto => 'Fnc_Insere_Guia',
                             p_Ds_Log => 'Conseguiu incluir a Guia: ' ||
                                         r_Guia.Nr_Guia);
      Vreturnguia := r_Guia.Nr_Guia;
      Return(Vreturnguia);
    
    End If;
  Exception
    When Others Then
    
      Vreturnguia := 0;
      Raise_Application_Error(-20999, 'Erro ao INSERIR GUIA: ' || Sqlerrm);
  End Fnc_Insere_Guia;

  Procedure Prc_Insere_Itguia(p_Nr_Guia             In Number,
                              p_Cd_Procedimento     In Varchar2,
                              p_Cd_Procedimento_Ptu In Varchar2,
                              p_Nr_Anvisa           In Number,
                              p_Nr_Sq_Item_Tiss     In Number,
                              p_Qt_Solic_Prest      In Number,
                              p_Vl_Procedimento     In Number,
                              p_Vl_Servico          In Number) Is
  
    --records
    r_Itguia r_Itguia_Padrao;
  
    --CURSORES
  
    --Vari�veis
  
  Begin
    Prc_Insere_Log_Process(p_Objeto => 'Prc_Insere_Itguia',
                           p_Ds_Log => 'INICIANDO A INCLUS�O DOS ITENS DA GUIA');
  
    r_Itguia.Cd_Itguia           := Fnc_Get_Seq_Itguia();
    r_Itguia.Nr_Guia             := p_Nr_Guia;
    r_Itguia.Cd_Procedimento     := p_Cd_Procedimento;
    r_Itguia.Cd_Procedimento_Ptu := p_Cd_Procedimento_Ptu;
    r_Itguia.Nr_Anvisa           := p_Nr_Anvisa;
    r_Itguia.Nr_Sq_Item_Tiss     := p_Nr_Sq_Item_Tiss;
    r_Itguia.Qt_Solic_Prest      := p_Qt_Solic_Prest;
    r_Itguia.Vl_Procedimento     := p_Vl_Procedimento;
    r_Itguia.Vl_Servico          := p_Vl_Servico;
  
    Prc_Insere_Log_Process(p_Objeto => 'Prc_Insere_Itguia',
                           p_Ds_Log => 'Dados Itens da Guia: ' || Chr(10) ||
                                       'Cd_Itguia: ' || r_Itguia.Cd_Itguia ||
                                       Chr(10) || 'Nr_Guia: ' ||
                                       r_Itguia.Nr_Guia || Chr(10) ||
                                       'Cd_Procedimento: ' ||
                                       r_Itguia.Cd_Procedimento || Chr(10) ||
                                       'Cd_Procedimento_Ptu: ' ||
                                       r_Itguia.Cd_Procedimento_Ptu ||
                                       Chr(10) || 'Nr_Anvisa: ' ||
                                       r_Itguia.Nr_Anvisa || Chr(10) ||
                                       'Nr_Sq_Item_Tiss: ' ||
                                       r_Itguia.Nr_Sq_Item_Tiss || Chr(10) ||
                                       'Qt_Solic_Prest: ' ||
                                       r_Itguia.Qt_Solic_Prest || Chr(10) ||
                                       'Vl_Procedimento: ' ||
                                       r_Itguia.Vl_Procedimento || Chr(10) ||
                                       'Vl_Servico: ' || r_Itguia.Vl_Servico);
  
    Insert Into Dbaps.Itguia
      (Cd_Itguia,
       Nr_Guia,
       Cd_Procedimento,
       Cd_Procedimento_Ptu,
       Nr_Anvisa,
       Nr_Sq_Item_Tiss,
       Qt_Solic_Prest,
       Qt_Solicitado,
       Vl_Procedimento,
       Vl_Servico,
       Vl_Franquia)
    
    Values
      (r_Itguia.Cd_Itguia,
       r_Itguia.Nr_Guia,
       r_Itguia.Cd_Procedimento,
       r_Itguia.Cd_Procedimento_Ptu,
       r_Itguia.Nr_Anvisa,
       r_Itguia.Nr_Sq_Item_Tiss,
       r_Itguia.Qt_Solic_Prest,
       1,
       r_Itguia.Vl_Procedimento,
       r_Itguia.Vl_Servico,
       0);
  
    Prc_Insere_Log_Process(p_Objeto => 'Prc_Insere_Itguia',
                           p_Ds_Log => 'TERMINOU A INCLUS�O DOS ITENS DA GUIA');
  
  Exception
    When Others Then
      Prc_Insere_Log_Process(p_Objeto => 'Prc_Insere_Itguia',
                             p_Ds_Log => 'FALHA NA INCLUS�O DOS ITENS DA GUIA: ' ||
                                         Chr(10) || 'GUIA: ' ||
                                         r_Itguia.Nr_Guia || Chr(10) ||
                                         Sqlerrm);
  End Prc_Insere_Itguia;

  /*FIM BLOCO DE FUNCTIONS*/

  /*BLOCO DE PROCEDURES*/

  Procedure Prc_Insere_Log_Process(p_Objeto Varchar2, p_Ds_Log Varchar2) Is
  
  Begin
    Insert Into Log_Process_Integra_Guia_Hms
      (Cd_Log_Process_Integra_Guia_Hms, Objeto, Ds_Log, Dt_Log)
    Values
      (Seq_Log_Process_Integra_Guia_Hms.Nextval,
       p_Objeto,
       p_Ds_Log,
       Sysdate);
  
    Commit;
  
  Exception
    When Others Then
      Raise_Application_Error(-20999,
                              'Erro ao INSERIR LOG DE PROCESSO: ' ||
                              Sqlerrm);
    
  End Prc_Insere_Log_Process;

  Procedure Prc_Exec_Integracao Is
    --cursores
    Cursor Cgetdadosguiahms Is
    
      Select *
        From Custom.Ti_Projeto_Nao_Hospitalizacao_Guia@Ormvgh.Unimed.Com.Br Th
       Where Not Exists
       (Select 1
                From Custom.Guia_Integracao_Hms Gh
               Where Gh.Cd_Atendimento = Th.Cd_Atendimento
                 And Gh.Cd_Paciente = Th.Cd_Paciente
                 And Gh.Cd_Editor_Registro = Th.Cd_Editor_Registro); ---tabela cabe�alho guia do hospital  
  
    Cursor Cgetdadositguiahms Is
    
      Select *
        From Custom.Ti_Projeto_Nao_Hospitalizacao_Guia_Itens@Ormvgh.Unimed.Com.Br Thi
      
       Where Not Exists
       (Select 1
                From Custom.Itguia_Integracao_Hms Ith
               Where Ith.Cd_Atendimento = Thi.Cd_Atendimento
                 And Ith.Cd_Paciente = Thi.Cd_Paciente
                 And Ith.Cd_Editor_Registro = Thi.Cd_Editor_Registro); ---tabela itens da guia do hospital
  
    --variaveis
    v_Contador_Guia   Pls_Integer := 0;
    v_Contador_Itguia Pls_Integer := 0;
    v_Contadorgeral   Number := 0;
  Begin
    Prc_Insere_Log_Process(p_Objeto => 'Prc_Exec_Integracao',
                           p_Ds_Log => 'INICIOU A QUERY PARA PEGAR OS DADOS DA BASE HOSPITALAR!');
  
    For i In Cgetdadosguiahms Loop
      v_Contador_Guia := v_Contador_Guia + 1;
      v_Contadorgeral := v_Contadorgeral + 1;
    
      Begin
        --Guia (Cabe�alho)  
        Prc_Insere_Log_Process(p_Objeto => 'Prc_Exec_Integracao',
                               p_Ds_Log => 'Iniciou a inser��o dos dados da base hospitalar nas tabelas de integra��o ');
        Insert Into Guia_Integracao_Hms
          (Cd_Integracao_Guia_Hms,
           Nr_Guia,
           Cd_Atendimento,
           Cd_Paciente,
           Cd_Editor_Registro,
           Nm_Paciente,
           Nr_Carteira_Utilizada,
           Sn_Atendimento_Rn,
           Tp_Sexo,
           Cd_Cid,
           Nr_Dd_Sms,
           Nr_Celular_Sms,
           Ds_Email_Beneficiario,
           Crm_Solic,
           Cpf_Cnpj_Prestador_Exec,
           Cpf_Cnpj_Prestador_Solic,
           Dt_Log_Integrado)
        Values
          (Seq_Guia_Integracao_Hms.Nextval,
           Null,
           i.Cd_Atendimento,
           i.Cd_Paciente,
           i.Cd_Editor_Registro,
           i.Nm_Paciente,
           i.Nr_Carteira_Utilizada,
           i.Sn_Atendimento_Recem_Nato,
           i.Tp_Sexo,
           i.Cd_Cid,
           i.Nr_Ddd_Celular,
           i.Nr_Celular,
           i.Ds_Email,
           i.Nr_Crm_Solicitante,
           i.Nr_Cnjp_Executante,
           i.Nr_Cpf_Solicitante,
           Sysdate);
      
        If (v_Contador_Guia >= 10) Then
          Commit;
          v_Contador_Guia := 0;
        
        End If;
      End;
    End Loop;
    For i In Cgetdadositguiahms Loop
    
      Begin
        Insert Into Itguia_Integracao_Hms
          (Cd_Itguia_Integracao_Hms,
           Nr_Guia,
           Cd_Paciente,
           Cd_Atendimento,
           Cd_Editor_Registro,
           Cd_Procedimento,
           Vl_Procedimento,
           Qt_Solic_Prest,
           Vl_Servico,
           Nr_Anvisa,
           Nr_Sq_Item_Tiss,
           Cd_Procedimento_Ptu,
           Dt_Log_Integrado)
        Values
          (Seq_Itguia_Integracao_Hms.Nextval,
           Null,
           i.Cd_Paciente,
           i.Cd_Atendimento,
           i.Cd_Editor_Registro,
           i.Cd_Procedimento,
           i.Vl_Procedimento,
           i.Qt_Solic_Prest,
           i.Vl_Servico,
           i.Nr_Anvisa,
           i.Nr_Sq_Item_Tiss,
           Null,
           Sysdate);
      
      End;
    
      If (v_Contador_Itguia >= 10) Then
        Commit;
        v_Contador_Itguia := 0;
      End If;
    End Loop;
  
    Commit;
    Prc_Insere_Log_Process(p_Objeto => 'Prc_Exec_Integracao',
                           p_Ds_Log => 'Terminou de inserir os dados da base hospitalar nas tabelas de integra��o!' ||
                                       Chr(10) ||
                                       ' Quantidade de Atendimentos: ' ||
                                       v_Contadorgeral);
  
    If (v_Contadorgeral >= 1) Then
      Prc_Insere_Autorizacao();
    End If;
  
  Exception
    When Others Then
      Prc_Insere_Log_Process(p_Objeto => 'Prc_Exec_Integracao',
                             p_Ds_Log => 'Falha ao consultar os dados da base hospitalar!' ||
                                         Chr(10) || Sqlerrm);
  End Prc_Exec_Integracao;

  Procedure Prc_Insere_Autorizacao Is
  
    Cursor Cgetdadosintegraguia Is
      Select * From Guia_Integracao_Hms Gh Where Gh.Nr_Guia Is Null;
  
    Cursor Cgetdadosintegraitguia(p_Cd_Atendimento     In Number,
                                  p_Cd_Editor_Registro In Number) Is
      Select *
        From Itguia_Integracao_Hms It
       Where It.Nr_Guia Is Null
         And It.Cd_Editor_Registro = p_Cd_Editor_Registro
         And It.Cd_Atendimento = p_Cd_Atendimento;
  
    Vreturnrguia Number := 0;
    Vconexacao   Number := 0;
    Vresult      Number := Null;
  Begin
  
    Vconexacao := Fnc_Get_Dblink();
  
    If (Vconexacao = 1) Then
      --verifica se existe conex�o com a base hospitalar
      Prc_Insere_Log_Process(p_Objeto => 'Prc_Insere_Autorizacao',
                             p_Ds_Log => 'Consegui me conectar com a base hospitalar!');
    
      Prc_Insere_Log_Process(p_Objeto => 'Prc_Insere_Autorizacao',
                             p_Ds_Log => 'Iniciando o processo de inclus�o das guias');
    
      For i In Cgetdadosintegraguia Loop
        Vreturnrguia := 0;
        Vreturnrguia := Fnc_Insere_Guia(p_Tp_Sexo                   => i.Tp_Sexo,
                                        p_Cd_Cid                    => i.Cd_Cid,
                                        p_Sn_Atendimento_Recem_Nato => i.Sn_Atendimento_Rn,
                                        p_Nr_Dd_Sms                 => i.Nr_Dd_Sms,
                                        p_Nr_Celular_Sms            => i.Nr_Celular_Sms,
                                        p_Ds_Email_Beneficiario     => i.Ds_Email_Beneficiario,
                                        p_Nr_Carteira_Utilizada     => i.Nr_Carteira_Utilizada,
                                        p_Nm_Beneficiario           => i.Nm_Paciente,
                                        p_Cpf_Cnpj_Prestador_Exec   => i.Cpf_Cnpj_Prestador_Exec,
                                        p_Cpf_Cnpj_Prestador_Solic  => i.Cpf_Cnpj_Prestador_Solic);
      
        Prc_Insere_Log_Process(p_Objeto => 'Prc_Insere_Autorizacao',
                               p_Ds_Log => 'Finalizou a chamada da Fnc_Insere_Guia');
      
        --INSERINDO NA LOG AUTORIZA
        Custom.Pkg_Rotinas_Atendmvs.Prc_Insere_Autoriza(p_Nr_Guia           => Vreturnrguia,
                                                        p_Ds_Funcionalidade => '[I] GUIA CADASTRADA - Rotina de Integra��o com HMS');
      
        --INSERINDO OCORRENCIA
        Custom.Pkg_Rotinas_Atendmvs.Prc_Insere_Ocorrencia(Pnr_Guia             => Vreturnrguia,
                                                          Pcd_Ocorrencia       => 255,
                                                          Pcd_Usuario_Inclusao => 'CUSTOM',
                                                          Pds_Observacao       => 'PROJETO N�O HOSPITALIZA��O');
      
        If (Vreturnrguia <> 0) Then
        
          Update Guia_Integracao_Hms g
             Set g.Nr_Guia = Vreturnrguia
           Where g.Cd_Atendimento = i.Cd_Atendimento
             And g.Cd_Editor_Registro = i.Cd_Editor_Registro
             And g.Nr_Carteira_Utilizada = i.Nr_Carteira_Utilizada;
        
          Prc_Insere_Log_Process(p_Objeto => 'Prc_Insere_Autorizacao',
                                 p_Ds_Log => 'Atualizou a tabela Guia_Integracao_Hms ');
        
          For j In Cgetdadosintegraitguia(p_Cd_Atendimento     => i.Cd_Atendimento,
                                          p_Cd_Editor_Registro => i.Cd_Editor_Registro) Loop
             If (Substr(i.Nr_Carteira_Utilizada, 0, 3) <> '018') Then 
          
           Prc_Insere_Itguia(p_Nr_Guia             => Vreturnrguia,
                              p_Cd_Procedimento     => j.Cd_Procedimento,
                              p_Cd_Procedimento_Ptu => j.Cd_Procedimento,
                              p_Nr_Anvisa           => j.Nr_Anvisa,
                              p_Nr_Sq_Item_Tiss     => j.Nr_Sq_Item_Tiss,
                              p_Qt_Solic_Prest      => j.Qt_Solic_Prest,
                              p_Vl_Procedimento     => j.Vl_Procedimento,
                              p_Vl_Servico          => j.Vl_Servico);
          
           Else
             Prc_Insere_Itguia(p_Nr_Guia             => Vreturnrguia,
                              p_Cd_Procedimento     => j.Cd_Procedimento,
                              p_Cd_Procedimento_Ptu => Null,
                              p_Nr_Anvisa           => j.Nr_Anvisa,
                              p_Nr_Sq_Item_Tiss     => j.Nr_Sq_Item_Tiss,
                              p_Qt_Solic_Prest      => j.Qt_Solic_Prest,
                              p_Vl_Procedimento     => j.Vl_Procedimento,
                              p_Vl_Servico          => j.Vl_Servico); 
          
          End If;
           Prc_Insere_Log_Process(p_Objeto => 'Prc_Insere_Autorizacao',
                                   p_Ds_Log => 'Finalizou a inser��o dos itens na guia ');
            Update Itguia_Integracao_Hms Gh
               Set Gh.Nr_Guia = Vreturnrguia
             Where Gh.Cd_Atendimento = i.Cd_Atendimento
               And Gh.Cd_Editor_Registro = i.Cd_Editor_Registro;
          
          End Loop;
        
          If (Substr(i.Nr_Carteira_Utilizada, 0, 3) = '018') Then
          
            Vresult := Dbaps.Fnc_Analisar_Guia(Pnr_Guia             => Vreturnrguia,
                                               Psq_Guia_Prorrogacao => 0,
                                               Psn_Prorrogacao      => 'N');
          
            Prc_Insere_Log_Process(p_Objeto => 'Prc_Insere_Autorizacao',
                                   p_Ds_Log => 'Finalizou a AN�LISE DA GUIA ');
          
          End If;
        
        End If;
      
      End Loop;
    
    End If;
  
  Exception
    When Others Then
      Prc_Insere_Log_Process(p_Objeto => 'Prc_Insere_Autorizacao',
                             p_Ds_Log => 'Falha ao Executar a Integra��o' ||
                                         Chr(10) || 'Guia: ' || Vreturnrguia ||
                                         Chr(10) || Sqlerrm);
  End Prc_Insere_Autorizacao;

/*FIM BLOCO DE PROCEDURES*/

End Pkg_Integracao_Guia_Ope_Hms;
/
