
-- CUSTOM.PRC_INTEGRACAO_GUIA_OPE_HMS 

 CUSTOM.PRC_INTEGRACAO_GUIA_OPE_HMS 

---modelo de guia sorocaba
Select 'SOROCABA' As Tp_Beneficiario,
       Nr_Guia, --gerar sequence
       Cd_Matricula, -- pegar dos dados do usu�rio interno
       Cd_Prestador, --M�dico que prescreveu o procedimento no HMS
       Cd_Prestador_Executor, --1001553 � NAIS ou 1002398 � CONFORMED Regra: Quando acamado e/ou aplica��o fora do hor�rio comercial CONFORMED, caso contr�rio NAIS.
       Sysdate As Dt_Emissao,
       Sysdate + 120 As Dt_Vencimento,
       Sysdate As Dt_Prev_Execucao,
       1704 As Cd_Autorizador, --HOSPITAL UNIMED SOROCABA 
       'N' As Sn_Valida_Rest_Carencia, -- PADR�O N,
       2 As Cd_Tipo_Atendimento, -- TIPO DE GUIA - SADT
       109 As Cd_Id_Usuario, --DBAPS
       Cd_Plano, --pegar dados do usu�rio
       'WS' As Tp_Origem, --ORIGEM WEB SERVICE
       Tp_Sexo, --PEGAR DO HMS
       Cd_Cid, --vai ser preciso pegar do HMS.
       'E' As Tp_Carater_Solic_Inter, --ELETIVO 
       1 As Cd_Multi_Empresa,
       4 As Cd_Indicador_Acidente,
       Decode(Cd_Prestador_Executor, 1001553, 13, 1002398, 06, Null) As Cd_Tipo_Atendimento_Tiss,
       Sn_Atendimento_Recem_Nato, --vai ser preciso pegar do HMS.
       '3.04.00' As Cd_Versao_Tiss,
       Nr_Protocolo, --GERAR SEQUENCE
       '090' As Cd_Versao_Ptu,
       '018' As Cd_Unimed_Executora,
       '018' As Cd_Unimed_Origem,
       '018' As Cd_Unimed_Solicitante,
       Nr_Carteira_Beneficiario, --VAI SER PRECISO PEGAR DO HMS
       Nr_Ddd_Sms, --VAI SER PRECISO PEGAR DO HMS
       Nr_Celular_Sms, --VAI SER PRECISO PEGAR DO HMS
       Nr_Transacao, --gerar sequence
       Nm_Prestador, --VAI SER PRECISO PEGAR DO HMS
       Ds_Email_Beneficiario, --VAI SER PRECISO PEGAR DO HMS
       Nr_Carteira_Utilizada, --VAI SER PRECISO PEGAR DO HMS
       Nr_Reg_Conselho_Prof_Solic, --VAI SER PRECISO PEGAR DO HMS
       Uf_Conselho_Prof_Solc, --VAI SER PRECISO PEGAR DO HMS
       Cd_Tiss_Conselho_Prof_Sol, --VAI SER PRECISO PEGAR DO HMS 
       1 As Cd_Etapa_Autorizacao,
       Cd_Contrato -- PEGAR Dos dados do beneficiario
  From Dbaps.Guia g
 Where g.Nr_Guia In (108151729, 108748039, 108769809);

--BENEFICIARIO INTERCAMBIO
Select 'INTERCAMBIO' As Tp_Beneficiario,
       Nr_Guia, --GERAR SEQUENCE
       Cd_Prestador, --VAI SER PRECISO PEGAR DO HMS  
       Cd_Prestador_Executor, --VAI SER PRECISO PEGAR DO HMS 
       Sysdate As Dt_Emissao,
       Sysdate + 120 As Dt_Vencimento,
       Sysdate As Dt_Prev_Execucao,
       1704 As Cd_Autorizador, --HOSPITAL UNIMED SOROCABA 
       9000 As Cd_Cortesia,
       Ds_Destino_Cortesia, ----VAI SER PRECISO PEGAR DO HMS 
       'N' As Sn_Valida_Rest_Carencia,
       2 As Cd_Tipo_Atendimento, --SADT
       109 As Cd_Id_Usuario, --dbaps
       Cd_Prestador_Solicitante, ---M�dico que prescreveu o procedimento no HMS
       'PTU' As Tp_Origem,
       Tp_Sexo, ---VAI SER PRECISO PEGAR DO HMS 
       Cd_Cid, ---VAI SER PRECISO PEGAR DO HMS 
       'E' As Tp_Carater_Solic_Inter, ---VAI SER PRECISO PEGAR DO HMS 
       1 As Cd_Multi_Empresa,
       4 As Cd_Indicador_Acidente,
       Decode(Cd_Prestador_Executor, 1001553, 13, 1002398, 06, Null) As Cd_Tipo_Atendimento_Tiss,
       Sn_Atendimento_Recem_Nato, ---VAI SER PRECISO PEGAR DO HMS 
       '3.04.00' As Cd_Versao_Tiss,
       Nr_Protocolo, --gerar sequence
       Cd_Beneficiario_Transito, --pegar do cursor
       '090' As Cd_Versao_Ptu,
       '018' As Cd_Unimed_Executora,
       Cd_Unimed_Origem, --VAI SER PRECISO PEGAR DO HMS
       '018' As Cd_Unimed_Solicitante,
       Nr_Carteira_Beneficiario, --VAI SER PRECISO PEGAR DO HMS
       'CLIENT' As Tp_Fluxo_Ptu_Ws,
       Nr_Ddd_Sms, --VAI SER PRECISO PEGAR DO HMS
       Nr_Celular_Sms, --VAI SER PRECISO PEGAR DO HMS
       Nr_Transacao, --GERAR SEQUENCE
       Nm_Prestador, --VAI SER PRECISO PEGAR DO HMS
       1 As Tp_Autorizacao_Ptu,
       Ds_Email_Beneficiario, --VAI SER PRECISO PEGAR DO HMS
       Nr_Reg_Conselho_Prof_Solic, --VAI SER PRECISO PEGAR DO HMS
       Uf_Conselho_Prof_Solc, --VAI SER PRECISO PEGAR DO HMS
       Cd_Tiss_Conselho_Prof_Sol, --VAI SER PRECISO PEGAR DO HMS
       1 As Cd_Etapa_Autorizacao --VAI SER PRECISO PEGAR DO HMS
  From Dbaps.Guia g
 Where g.Nr_Guia In (108127459, 108461299);

------- modelo de item guia

Select Decode(It.Cd_Procedimento_Ptu, Null, 'SOROCABA', 'INTERC�MBIO') As Tp_Beneficiario,
       It.Nr_Guia, -- pegar da sequence
       It.Cd_Procedimento, --pegar do hospital
       It.Qt_Solicitado, --pegar do hospital (qtd autorizada)
       It.Vl_Procedimento, -- pegar do hospital
       0 As Vl_Franquia,
       It.Qt_Solic_Prest,  --pegar do hospital (qtd autorizada)
       It.Cd_Itguia, --sequence
       It.Vl_Servico, --pegar do hms
       It.Nr_Anvisa, --pegar do hms
       It.Nr_Sq_Item_Tiss, --pegar do hms
       It.Cd_Procedimento_Ptu  -- para origem <> 018
  From Dbaps.Itguia It
 Where It.Nr_Guia In
       (108151729, 108748039, 108769809, 108127459, 108461299);
    

 
/*SELECT DBAPS.SEQ_GUIA.NEXTVAL
          INTO nRet
          FROM DUAL;
        nRet := nRet || '9';*/

/*
            Declare
        vnr Varchar2(100);
        Begin
            vnr := DBAPS.FNC_GERAR_NR_TRANSACAO_GUIA();
            dbms_output.put_line(vnr);
        End;
            */

/*
        
          nProtocoloAns := DBAPS.FNC_PROTOCOLO_ANS(Nvl(dbaps.fnc_mvs_retorna_valor_config('ATEND_PROTANS_MOTIVO_PADRAO'
                                                                                       ,RegUsuario.CD_MULTI_EMPRESA)
                                                    ,9020)
                                                ,nNR_GUIA
                                                ,RegUsuario.CD_MATRICULA
                                                ,NULL
                                                ,NULL
                                                ,Nvl(RegPrestador.CD_MULTI_EMPRESA
                                                    ,RegUsuario.CD_MULTI_EMPRESA));
        */

/*DBAPS.FNC_ANALISAR_GUIA*/ --SOROCABA

/*DBAPS.fnc_ptu_pedido_autorizacao_v9*/

/*  SELECT *
        FROM TABLE(DBAPS.PKG_UNIMED_v9.GUIA_TO_PTU(108461299));*/   
        
        
/*SEQUENCE ITGUIA

DBAPS.SEQ_CD_ITGUIA.NEXTVAL        
  */      

Create Table Custom.Integracao_Guia_Hospitalar(
                                               
                                               );


