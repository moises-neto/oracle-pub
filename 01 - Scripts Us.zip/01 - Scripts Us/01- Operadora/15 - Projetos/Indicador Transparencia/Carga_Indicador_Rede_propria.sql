CREATE OR REPLACE Procedure CUSTOM.Prc_Carga_Gestao_Transparencia Is
 /*
   ***************************************************************************************************
   * Objeto   : Custom.Carga_Gestao_Transparencia                                                    *
   ***************************************************************************************************
   * Módulo   : Rede Credenciada                                                                     *
   * Objetivo : Realizar a carga dos protocolos referente a rede própria para a atender a demanda do *
   *            Indicador da Gestão de Transparência da Unimed do Brasil.                            *
   * Houve a Necessidade pois a rotina do WebService puxa dados da View V_CTAS_MEDICAS entretanto o  *
   * Nosso repasse para a rede própria (300100) tem muitos dados, e estava dando TimeOut.            *
   ***************************************************************************************************
   |-------------------------------------------------------------------------------------------------|
   | Data      |   Chamado   |     Solicitante    | Responsável     | Versão  | Alteração            |
   |-----------+-------------+--------------------+-----------------+---------+----------------------|
   |09/11/2021 | CH2107-4696 |  Fabíola Ambrosio  | Moisés de Souza |   1.0   |      Criação         |
   |-----------+-------------+--------------------+-----------------+---------+----------------------|
  */

  Cursor cDados is
  --CONSULTA REALIZADA PELO ERICK ANDRADE MV e Moisés Souza (Unimed Sorocaba)
    Select * From Custom.Vw_Dados_Gestao_Transparencia;


  v_sqlErrm     varchar2(100);
  v_DadosCommit varchar2(10) := 0;
Begin

  For i in cDados Loop
    
    IF (v_DadosCommit = 100) Then
      Commit;
      Dbms_Output.put_line('Uhuull Commitou no protocolo ' || i.nr_protocolo);
      v_DadosCommit := 0;
    End IF;
    v_DadosCommit := v_DadosCommit + 1;
    
    Begin
      INSERT INTO DBAPS.REPASSE_PRESTADOR_PROTOCOLO
        (CD_REPASSE_PRESTADOR,
         DT_PROTOCOLO,
         NR_PROTOCOLO,
         NR_LOTE,
         VL_INFORMADO,
         VL_LIBERADO,
         VL_GLOSA)
      VALUES
        (I.CD_REPASSE_PRESTADOR,
         I.DT_PROTOCOLO,
         I.NR_PROTOCOLO,
         I.NR_LOTE,
         I.VL_INFORMADO,
         I.VL_LIBERADO,
         I.VL_GLOSA);
    
    Exception
      When Others Then
        Begin
          v_sqlErrm := sqlerrm;
          Insert Into Custom.Log_Erros_Transparencia
            (Cd_Log_Erro,
             Dt_Log,
             Cd_Usuario_Exec,
             DS_ERRO_ORA,
             Tp_Operacao)
          Values
            (custom.seq_log_err_transp.nextval,
             sysdate,
             user,
             v_sqlErrm,
             'I');
          COMMIT;
        End;
    End;
  End Loop;
  COMMIT;
End;
