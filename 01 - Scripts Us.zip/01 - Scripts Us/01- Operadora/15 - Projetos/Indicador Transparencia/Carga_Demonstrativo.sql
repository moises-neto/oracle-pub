INSERT INTO DBAPS.REPASSE_PRESTADOR_PROTOCOLO 
  SELECT CTA.CD_REPASSE_PRESTADOR,
         NVL(PRO.DT_ENVIO_LOTE, LOT.DT_LOTE) DT_PROTOCOLO,
         NVL(LOT.CD_PROTOCOLO_CTAMED, LOT.CD_LOTE) NR_PROTOCOLO,
         NVL(PRO.NR_LOTE_PRESTADOR, LOT.CD_LOTE) NR_LOTE,
         NVL((SELECT SUM(FNC_CHAR2NUMBER(V.VL_TOTAL_PROCEDIMENTO))
               FROM DBAPS.V_TISS_LOTE_GUIA V
              WHERE V.CD_PROTOCOLO_CTAMED = PRO.CD_PROTOCOLO_CTAMED),
             SUM(CTA.VL_TOTAL_PAGO)) VL_INFORMADO,
         SUM(CTA.VL_TOTAL_PAGO) VL_LIBERADO,
         SUM(CTA.VL_TOTAL_GLOSADO) VL_GLOSA
    FROM DBAPS.REPASSE_PRESTADOR RP,
         DBAPS.LOTE              LOT,
         DBAPS.PROTOCOLO_CTAMED  PRO,
         DBAPS.V_CTAS_MEDICAS    CTA
   WHERE RP.CD_REPASSE_PRESTADOR = CTA.CD_REPASSE_PRESTADOR
     AND CTA.CD_LOTE = LOT.CD_LOTE
     AND LOT.CD_PROTOCOLO_CTAMED = PRO.CD_PROTOCOLO_CTAMED(+)
     AND CTA.CD_REPASSE_PRESTADOR IN
         (SELECT CD_REPASSE_PRESTADOR
            FROM DBAPS.REPASSE_PRESTADOR
           WHERE CD_PRESTADOR IN
                 (SELECT CD_PRESTADOR
                    FROM DBAPS.PRESTADOR
                   WHERE TP_CREDENCIAMENTO = 'P')
             AND DT_LANCAMENTO >= TO_DATE('01/08/2021', 'DD/MM/YYYY')
             AND DT_LANCAMENTO <= TO_DATE('01/11/2021', 'DD/MM/YYYY')) 
             
             And Not Exists (Select 1 From DBAPS.REPASSE_PRESTADOR_PROTOCOLO p
                            Where p.cd_repasse_prestador = CTA.CD_REPASSE_PRESTADOR
                            And p.nr_protocolo =  NVL(LOT.CD_PROTOCOLO_CTAMED, LOT.CD_LOTE))
                            
   GROUP BY CTA.CD_REPASSE_PRESTADOR,
            PRO.DT_ENVIO_LOTE,
            LOT.CD_PROTOCOLO_CTAMED,
            LOT.CD_LOTE,
            LOT.DT_LOTE,
            PRO.CD_PROTOCOLO_CTAMED,
            PRO.NR_LOTE_PRESTADOR,
            RP.CD_REPASSE_PRESTADOR;
            
            
                    Select * From DBAPS.REPASSE_PRESTADOR_PROTOCOLO rp where trunc(rp.dt_protocolo) between '01/08/2021' and sysdate
           Select  r.cd_repasse_prestador,
                      r.dt_protocolo,
                      r.nr_protocolo,
                      r.nr_lote,
                      r.vl_informado,
                      r.vl_liberado,
                   r.vl_glosa, count(*)  From DBAPS.REPASSE_PRESTADOR_PROTOCOLO r
             Where trunc(r.dt_protocolo) between '01/08/2021' and sysdate
             Group by r.cd_repasse_prestador,
                      r.dt_protocolo,
                      r.nr_protocolo,
                      r.nr_lote,
                      r.vl_informado,
                      r.vl_liberado,
                   r.vl_glosa
                                
            Having count(*) > 1    
            
            select * From DBAPS.REPASSE_PRESTADOR_PROTOCOLO r
             
          
            
            Select Max(pct.cd_protocolo_ctamed)  From  DBAPS.PROTOCOLO_CTAMED pct;
            
            select * From DBAPS.PROTOCOLO_CTAMED pct where pct.cd_protocolo_ctamed = 456719;
         
