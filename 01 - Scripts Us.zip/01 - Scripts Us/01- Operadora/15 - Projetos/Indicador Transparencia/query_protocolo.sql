select * from  DBAPS.PROTOCOLO_CTAMED p
where p.cd_protocolo_ctamed = 348295
p.cd_prestador = 300100
