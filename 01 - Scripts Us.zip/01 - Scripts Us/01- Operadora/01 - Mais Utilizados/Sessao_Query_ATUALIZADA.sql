Select w.Inst_Id w_Inst_Id,
       w.Sid w_Sid,
       w.Serial# w_Serial#,
       w.Username w_Username,
       (Select u.ds_observacao From Dbasgu.Usuarios u Where u.cd_usuario = w.USERNAME) Setor,
       w.Osuser w_Osuser,
       Nvl(w.Module, w.Program) w_Program,
       Nvl(w.Machine, w.Terminal) w_Machine,
       w.Action w_Action,
       w.Sql_Id w_Sql_Id,       
       To_Char(Trunc(w.Last_Call_Et / 86400), '009') || 'D' ||
       To_Char(Trunc(Mod(w.Last_Call_Et, 86400) / 3600), '09') || 'h:' ||
       To_Char(Trunc(Mod(w.Last_Call_Et, 3600) / 60), '09') || 'mi:' ||
       To_Char(Mod(Mod(w.Last_Call_Et, 3600), 60), '09') || 'ss' "W_TEMPO",
       '<####>',
       b.Inst_Id b_Inst_Id,
       b.Sid b_Sid,
       b.Serial# b_Serial#a,
       b.Username b_Username,
       b.Osuser b_Osuser,
       Nvl(b.Module, b.Program) b_Program,
       Nvl(b.Machine, b.Terminal) b_Machine,
       b.Action b_Action,
       b.Status b_Status,
       b.Sql_Id b_Sql_Id,
       To_Char(Trunc(b.Last_Call_Et / 86400), '009') || 'D' ||
       To_Char(Trunc(Mod(b.Last_Call_Et, 86400) / 3600), '09') || 'h:' ||
       To_Char(Trunc(Mod(b.Last_Call_Et, 3600) / 60), '09') || 'mi:' ||
       To_Char(Mod(Mod(b.Last_Call_Et, 3600), 60), '09') || 'ss' "B_TEMPO",
       (Select Owner || '.' || Object_Name
          From Dba_Objects o
         Where o.Object_Id = w.Row_Wait_Obj#) Object,
       b.Event,
       'alter system kill session ''' || w.Sid || ',' ||w.Serial# || ',@' ||
       w.Inst_Id || ''' immediate;' Sessao_Sendo_Travada,
       
       'alter system kill session ''' || b.Sid || ',' || b.Serial# || ',@' ||
       b.Inst_Id || ''' immediate;' Sessao_Travando
       
  From Gv$session w, Gv$session b
 Where w.Blocking_Session Is Not Null
   And w.Blocking_Instance = b.Inst_Id
   And w.Blocking_Session = b.Sid
                         
