 SELECT /*+RULE*/
       CASE
          WHEN substr(c.cd_contrato_interno, 1, 4) IN
               ('7797', '7798', '7500','2020') THEN
               'Individual Familiar - Cooperado'
          WHEN substr(c.cd_contrato_interno, 1, 4) IN
               ('5996', '5997', '5998', '5999','2021') THEN
               'Coletivo Empresarial - Funcion�rio'
          WHEN p.tp_natureza_juridica IN (3)  THEN
               'Coletivo por Ades�o'
          WHEN c.tp_mensalidade = 'C' THEN
               'Custo Operacional'
          WHEN p.tp_natureza_juridica = 1 THEN
               'Individual Familiar'
          WHEN p.tp_natureza_juridica IN ( 4, 5, 6) THEN
               'Coletivo Empresarial'
          ELSE
               'Outros'
       END tp_contrato,
       COUNT(*) QUANTIDADE,
       Decode(p.cd_tip_acomodacao, 7, 'Apartamento', 1, 'Enfermaria', null) Tipo_Acomodacao,
       'PJ' Tipo_Contrato
FROM   dbaps.contrato       c,
       dbaps.usuario        u,
       dbaps.plano_contrato pc,
       dbaps.plano          p
WHERE  c.cd_contrato = u.cd_contrato
AND    c.cd_contrato = pc.cd_contrato
AND    pc.cd_plano = p.cd_plano
AND    u.cd_plano = p.cd_plano
AND    dbaps.fn_situacao_usuario(u.cd_matricula, to_date('03/03/2022','DD/MM/YYYY')) = 'S' -- alterar aqui
AND    c.tp_contrato <> 'U'
/*and  c.sn_demitido_aposentado_obito = 'S'
 And c.tp_contrato in('A','E') */

GROUP  BY
       CASE
          WHEN substr(c.cd_contrato_interno, 1, 4) IN
               ('7797', '7798', '7500','2020') THEN
               'Individual Familiar - Cooperado'
          WHEN substr(c.cd_contrato_interno, 1, 4) IN
               ('5996', '5997', '5998', '5999','2021') THEN
               'Coletivo Empresarial - Funcion�rio'
          WHEN p.tp_natureza_juridica IN (3)  THEN
               'Coletivo por Ades�o'
          WHEN c.tp_mensalidade = 'C' THEN
               'Custo Operacional'
          WHEN p.tp_natureza_juridica = 1 THEN
               'Individual Familiar'
          WHEN p.tp_natureza_juridica IN ( 4, 5, 6) THEN
               'Coletivo Empresarial'
          ELSE
               'Outros'
       END,
       p.cd_tip_acomodacao
union All

 SELECT /*+RULE*/
       CASE
          WHEN substr(c.cd_contrato_interno, 1, 4) IN
               ('7797', '7798', '7500','2020') THEN
               'Individual Familiar - Cooperado'
          WHEN substr(c.cd_contrato_interno, 1, 4) IN
               ('5996', '5997', '5998', '5999','2021') THEN
               'Coletivo Empresarial - Funcion�rio'
          WHEN p.tp_natureza_juridica IN (3)  THEN
               'Coletivo por Ades�o'
          WHEN c.tp_mensalidade = 'C' THEN
               'Custo Operacional'
          WHEN p.tp_natureza_juridica = 1 THEN
               'Individual Familiar'
          WHEN p.tp_natureza_juridica IN ( 4, 5, 6) THEN
               'Coletivo Empresarial'
          ELSE
               'Outros'
       END tp_contrato,
       COUNT(*) QUANTIDADE,
       Decode(p.cd_tip_acomodacao, 7, 'Apartamento', 1, 'Enfermaria', null) Tipo_Acomodacao,
       'PF' Tipo_Contrato
FROM   dbaps.contrato       c,
       dbaps.usuario        u,
       dbaps.plano_contrato pc,
       dbaps.plano          p
WHERE  c.cd_contrato = u.cd_contrato
AND    c.cd_contrato = pc.cd_contrato
AND    pc.cd_plano = p.cd_plano
AND    u.cd_plano = p.cd_plano
AND    dbaps.fn_situacao_usuario(u.cd_matricula,to_date('03/03/2022','DD/MM/YYYY')) = 'S' -- alterar aqui
AND    c.tp_contrato <> 'U'
and (c.tp_contrato = 'I' or
        (c.tp_contrato = 'A' and c.sn_demitido_aposentado_obito = 'S')) 

GROUP  BY
       CASE
          WHEN substr(c.cd_contrato_interno, 1, 4) IN
               ('7797', '7798', '7500','2020') THEN
               'Individual Familiar - Cooperado'
          WHEN substr(c.cd_contrato_interno, 1, 4) IN
               ('5996', '5997', '5998', '5999','2021') THEN
               'Coletivo Empresarial - Funcion�rio'
          WHEN p.tp_natureza_juridica IN (3)  THEN
               'Coletivo por Ades�o'
          WHEN c.tp_mensalidade = 'C' THEN
               'Custo Operacional'
          WHEN p.tp_natureza_juridica = 1 THEN
               'Individual Familiar'
          WHEN p.tp_natureza_juridica IN ( 4, 5, 6) THEN
               'Coletivo Empresarial'
          ELSE
               'Outros'
       END,
       p.cd_tip_acomodacao
ORDER  BY 1





