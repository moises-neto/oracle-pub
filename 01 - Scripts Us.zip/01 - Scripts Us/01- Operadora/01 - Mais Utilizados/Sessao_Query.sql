
Select --s.inst_id,
-- s.sid,
-- s.serial#, 

 (Select Sql_Text Full
    From Gv$sql
   Where Sql_Id = s.Sql_Id
     And Rownum < 2) Sql_Text,
 (Select Sql_Fulltext
    From Gv$sql
   Where Sql_Id = s.Sql_Id
     And Rownum < 2) Sql_Text,
 s.Machine,
 Trunc(Mod(s.Last_Call_Et / 3600, 60)) || 'h:' ||
 Trunc(Mod((s.Last_Call_Et / 60), 60)) || 'mim:' ||
 Trunc(Mod(s.Last_Call_Et, 60)) || 's' "LAST_CALL_ET",
 
 'alter system kill session ''' || s.Sid || ',' || s.Serial# ||
 ''' immediate' Comando,
 'alter system kill session ''' || s.Sid || ',' || s.Serial# || ',@' ||
 s.Inst_Id || ''' immediate;' Comando_Rac,
 
 -- p.spid,
 s.Username As Usuario,
 (Select u.Nm_Usuario From Dbasgu.Usuarios u Where u.Cd_Usuario = s.Username) As Nome,
 (Select u.Ds_Observacao
    From Dbasgu.Usuarios u
   Where u.Cd_Usuario = s.Username) Setor,
 s.Action,
 s.Module As Tela

  From Gv$session s, Gv$process p
 Where s.Inst_Id = p.Inst_Id
   And s.Paddr = p.Addr
   And s.Username Not In ('SYS', 'SYSTEM')
   And s.Username Is Not Null
   And s.Status = 'ACTIVE'
   And (s.Sid, s.Inst_Id) Not In
       (Select Sid, Instance_Number
          From V$mystat, V$instance
         Where Rownum = 1)
-- AND S.USERNAME = 'CENTRAL'
--AND s.USERNAME = 'ABAENA'
--AND  s.username = 'MNETO' 
--And s.machine = 'UNIMED\MOISES-PC'
--And s.ACTION = 'RECALCULO VALOR PROCEDIMENTO - 4'
--AND p.spid = 17220
--AND action = 'SOULMV/MVSAUDE/M_CALL_CENTER'
 Order By s.Last_Call_Et Desc;

/



/*-- DBAPS.LIVRO_SALDO_EVENT_LIQUIDAR 
  Select b.Username As Usuario,
         (Select u.Nm_Usuario
            From Dbasgu.Usuarios u
           Where u.Cd_Usuario = b.Username) As Nome,
         (Select u.Ds_Observacao
            From Dbasgu.Usuarios u
           Where u.Cd_Usuario = b.Username) Setor,
         --c.owner,
         c.Object_Name,
         c.Object_Type,
         (Select Sql_Text Full
            From Gv$sql
           Where Sql_Id = b.Sql_Id
             And Rownum < 2) Sql_Text,
         -- b.sid,
         -- b.serial#,
         b.Status,
         b.Osuser As Server,
         b.Machine As Maquina,
         b.Module As Tela,
         'alter system kill session ''' || b.Sid || ',' || b.Serial# ||
         ''' immediate ; ' Comando
    From V$locked_Object a, V$session b, Dba_Objects c
   Where b.Sid = a.Session_Id
     And a.Object_Id = c.Object_Id;*/
                 
