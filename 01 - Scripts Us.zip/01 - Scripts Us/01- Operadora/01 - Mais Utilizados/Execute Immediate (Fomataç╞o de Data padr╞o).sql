 EXECUTE IMMEDIATE 'ALTER SESSION SET NLS_DATE_LANGUAGE      = "BRAZILIAN PORTUGUESE"

                                        NLS_NUMERIC_CHARACTERS = ",."
                                        NLS_DATE_FORMAT        = "DD/MM/YYYY"
                                        NLS_LANGUAGE           = "BRAZILIAN PORTUGUESE"
                                        NLS_SORT               = "BINARY"
                                        NLS_TIME_FORMAT        = "HH24:MI:SS"
                                        NLS_COMP               = "BINARY"'; 
