--INSERT
  Select Distinct A.OWNER,
       A.name,
       A.OWNER || '.' || A.NAME As OBJETO_OWNER,
       A.TYPE
  From dba_Source a
 Where Upper(a.text) Like Upper('%1514%')
 And A.OWNER <> 'CUSTOM'
 
                            DBAPS.PRC_ANALISA_CONTA_AMB_CLIENTE
DBAPS.FNC_SALVAR_BENEF_TRANSITO
  
DBAPS.FNC_INSERE_BENEF_INTERCAMBIO
                          DBAPS.PRC_IMP_INSERE_CONTAMEDICA
 
-- And Upper(a.Text) Like Upper('%ERRO%') 
-- And  A.name  Like '%Cadastro%'
 And a.owner = 'CUSTOM' 
 And A.type = 'PROCEDURE' 
 
 DBAPS.PRC_MVS_VALIDA_PROTOCOLO_TISS
 
DBAPS.PACK_SGPS
                     DBAPS.FNC_MVS_ANALISA_CONTA_AMB
 
DBAPS.FNC_MVS_ANALISA_CONTA_AMB  
                            
DBAPS.FNC_MVS_ANALISA_CONTA_AMB
 
 DBAPS.PRC_PROCEDIMENTO_EXECUCAO
 
 DBAPS.FNC_VERIFICA_CRITERIO
DBAPS.FNC_VERIFICA_PESO_CRITERIO


DBAPS.fnc_guias

 
 dbamv.caught_errors        
                   DBAPS.PRC_GERA_FAT_CONTA_MEDICA
 
 Select * From DBAMV.CAUGHT_ERRORS
 Order By 1 Desc
                              DBAMV.TRG_TISS_SOL_GUI_VERIFICA_GUIA
 
DBAPS.PRC_TISS_ENVIO
                       DBAPS.TRG_USUARIO_REG_ALTER

--DELETE 
  Select * From All_Source a Where Upper(a.Text) Like Upper('%Ptu_A500_Proc%');
                                 PRC_INSERE_DEBUG_LOG_CLIENTE
 --AUTORIZA��O PROCESSO PTU ONLINE
 --WEB SERVICE CHAMA A 
 FNC_PTU_PROT_RECEB_V9
 -- DEPOIS ANALISA O TIPO DE REQUISI��O, SE FOR  00600, CHAMA A 
 DBAPS.prc_ptu_autorizador_v9
 --DEPOIS CHAMA A
 DBAPS.AUTORIZA_GUIA
 -- VALIDA CHAMANDO A 
 DBAPS.FNC_ANALISAR_GUIA
 -- QUE DENTRO DELA CHAMA CLIENTE
 DBAPS.PRC_ANALISAR_GUIA_CLIENTE
 --E CHAMA A
 DBAPS.FNC_PTU_PEDIDO_AUTORIZACAO_V9
                 DBAMV.TRG_AVISO_CIRURGIA_PACIENTE     
 
                     FNC_GUIAS_PROC_A500

Fnc_Mvs_Geracao_Ptu_A500_Xml --1                
Fnc_Ptu_A500_Cabecalho --2
Fnc_Insere_Ptu_A500_Guias --3
Fnc_Guias_Consultas_A500 --4
--dentro da  FNC_GUIAS_CONSULTAS_A500 chama a PKG_PTU_BATCH_A500_XML 
FNC_GUIAS_PROC_A500
FNC_GUIAS_PROC_EQP_A500
Prc_Gera_Item_Unico;
Prc_Gera_Fat_Conta_Medica;
Fnc_Mvs_Analisa_Conta_Amb;
Fnc_Atualiza_Itmens_Contrato; 
Fnc_Guias_Honorario_A500; 
Fnc_Guias_Proc_A500;
Fnc_Guias_Proc_Eqp_A500; 
Prc_Gera_Fat_Conta_Medica;
Fnc_Guias_Consultas_A500;
Fnc_Tiss_Importa_Lot_Guia;
Prc_Mvs_Ptu_Efetiva_A500_Xml;
Fnc_Ptu_A500_Cabecalho;
Prc_Mvs_Ptu_Efetiva_A500_Xml;
Dbaps.Fnc_Guias_Spsadt_A500;

dbaps.
Prc_Geracao_Mensalidade_A500;
Prc_Efetiva_Ptua550_Custom;
Fnc_Guias_Proc_A500;
Fnc_Guias_Spsadt_A500; Fnc_Mvs_Geracao_Ptu_A500_Xml;
Pack_Sgps
                      
