Select p.Cd_Prestador,
       p.Portal_Cd_Login_Alternativo,
       p.Portal_Ds_Senha_Alternativa
  From Prestador p
 Where p.Cd_Prestador = 300005;
 
Select  p.*
  From empresa p
 Where p.CD_EMPRESA = 128; 
 
 
 Select * From TIPO_ATENDIMENTO_TISS 
 
 Select  *From guia g
 Where g.nr_guia = 119599489
