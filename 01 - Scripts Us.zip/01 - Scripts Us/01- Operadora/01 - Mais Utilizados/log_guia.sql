Select  g.CD_PRESTADOR, g.CD_PRESTADOR_EXECUTOR, g.cd_prestador_executor_pf, g.tp_origem, g.*
  from inf$rpl.lg$_guia g
 where g.nr_guia = 119868589
 ORDER BY G.NRSEQUENCIA$$;
 
 CD_PRESTADOR_EXECUTOR_PF
 
 Select g.cd_tipo_atendimento_tiss, g.* From inf$rpl.lg$_guia g
 Where g.nr_transacao = '2306000064024'
 ORDER BY G.NRSEQUENCIA$$
 


-- V: valor velho
-- A: Valor atual.

Select p.tp_situacao,  p.* From inf$rpl.lg$_prestador p
Where p.cd_prestador =  1003726 
Order By 2 Desc
                                

Select * From inf$rpl.lg$_
Where l.cd_fatura = 40330 

--ordenar por NRSEQUENCIA$$

select c.cd_nota_fiscal, c.* From inf$rpl.lg$_mens_contrato c
Where c.cd_mens_contrato in (2265107)


Select * From inf$rpl.lg$_itguia it
Where it.nr_guia = 113859709
and it.cd_procedimento = 31403360
order by it.nrsequencia$$;


Select * From inf$rpl.lg$_con_pag c
Where c.cd_con_pag = 521825


Select * From inf$rpl.lg$_itguia it
Where it.nr_guia In(100158769)
--and it.cd_procedimento = 40202038
order by it.nrsequencia$$;
DBAPS.ITGUIA

--GUIA

Select g.sn_valida_rest_carencia, G.NR_GUIA_TEM, g.* From inf$rpl.lg$_guia G
Where g.nr_guia = 84134349 
--and it.cd_procedimento = 40202038
order by g.nrsequencia$$;


Select * From  inf$rpl.lg$_usuario u
where u.cd_matricula = 2332430037

Select * From inf$rpl.lg$_repasse_prest_intercambio r;


select * From inf$rpl.lg$_fatura f
where f.cd_fatura = 33487
Order by 2 desc;

Select * From inf$rpl.lg$_prestador p
where p.cd_prestador = 1002393


Select * From inf$rpl.lg$_lote p
Where p.cd_lote = 612389
ORDER BY NRSEQUENCIA$$


