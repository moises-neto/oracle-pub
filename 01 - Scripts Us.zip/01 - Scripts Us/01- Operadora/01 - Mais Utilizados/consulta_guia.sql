select g.nr_guia As Guia,
       g.cd_tipo_atendimento,
       g.nr_transacao As Transacao,
       g.cd_ptu_mensagem_origem AS PTU_Origem,
       g.cd_ptu_mensagem_destino As PTU_Destino,  
       g.tp_origem As Origem_Guia,
       dbaps.fnc_status_guia(g.nr_guia) as Status,
       nvl(u.nm_segurado, bt.nm_segurado) AS Beneficiario,
       it.cd_procedimento,
       p.ds_procedimento,
       g.dt_emissao
  from dbaps.guia g,  dbaps.usuario u, dbaps.beneficiario_transito bt, dbaps.itguia it , dbaps.procedimento p
 where g.cd_matricula = u.cd_matricula(+)                                             
 And it.nr_guia = g.nr_guia                                                                                  
 and p.cd_procedimento = it.cd_procedimento      
 And g.cd_beneficiario_transito = bt.cd_beneficiario_transito(+)
 -- and g.nr_guia = '65513649'     
 and g.nr_transacao IN (2110000184344) --('2103000077907','2103000076148','2103000075918', '2103000075920', '2103000076146')
  
--2108000017336
 
 /*                                   !
 and g.dt_emissao like sysdate     
 and  g.cd_tipo_atendimento = 3
 and dbaps.fnc_status_guia(g.nr_guia) = 'Autorizado [2]'
 */
   
   
