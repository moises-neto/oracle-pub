-- reabilitar job antigo com estado broken:
BEGIN
  dbms_job.broken('6083',FALSE);   
END;

Select *
  from all_source
 where upper(text) like upper('%Prc_Efetiva_Ptua550_Custom%');

  Select a.*
          from dba_jobs a
         --where a.JOB = 5043
         where upper(what) like upper('%GESTAO%')
        -- where a.job in (6164, 5883)
                         CUSTOM.Prc_Carga_Gestao_Transparencia   
       
 -- excluindo o job
begin  
   DBMS_JOB.Remove(); -- Coloca aqui o numero do JOB.
end;

-- Recria o Job
DECLARE
  --Declare vari�vel que recebe n�mero do JOB.
  JOB_NUM BINARY_INTEGER;
BEGIN
  --Cria o JOB no banco e retorna o n�mero dele job_num       ---- Colocar aqui a data da proxima execu��o
  --DBMS_JOB.SUBMIT(JOB_NUM, 'BEGIN Prc_Envio_Job_Broken; END;', TO_DATE('04/11/2020, 15:00', 'dd/mm/yyyy hh24:mi'), 'sysdate + 1/24');
  DBMS_JOB.submit(JOB_NUM,
                  what      => 'begin PRC_ANALISE_CTAS_CUSTOM; end;',
                  next_date => TO_DATE('19/01/2022, 02:00', 'dd/mm/yyyy hh24:mi'),
                  interval  => 'TRUNC(SYSDATE + 1) + 2/24');
  DBMS_OUTPUT.put_line('Job criado: ' || JOB_NUM);
END;

--Altera next date :
  CALL DBMS_JOB.NEXT_DATE(5503, sysdate + 8/24); 
  
Select sysdate + 1/24 from dual;

declare
cont integer;
BEGIN
DBMS_JOB.submit (cont,what =>'',next_date=>'1/2/2009 08:30:00',interval=>'TRUNC(LAST_DAY(SYSDATE)) + 1 + 8/24 + 30/1440');

END;
