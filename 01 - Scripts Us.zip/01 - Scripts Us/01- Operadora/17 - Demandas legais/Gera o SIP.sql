Call DBAPS.PKG_MVS_SIP.PRC_GERA_RECONHECIMENTO(pCD_SIP_PERIODO => 22,
                                          PDATAINICIAL    => '01/07/2022',
                                          PDATAFINAL      => '01/09/2022');
                                          
Select Ft.Cd_Fatura, Ft.Cd_Sip_Periodo
  From Dbaps.Fatura Ft
 Where Ft.Nr_Ano || Ft.Nr_Mes Between
       To_Char(To_Date('01/07/2022'), 'YYYYMM') And
       To_Char(To_Date('01/09/2022'), 'YYYYMM')
   And Ft.Sn_Fechado = 'S'
   And Ft.Tp_Fatura Not In ('R')
   And Ft.Cd_Multi_Empresa = 1
   And Nvl(Ft.Cd_Sip_Periodo, 22) = 22;
         
         
         
         
ORA-20001: Erro na package SIP (PRC_GERA_RECONHECIMENTO): ORA-01422: a extra��o exata retorna mais do que o n�mero solicitado de linhas
ORA-06512: em "DBAPS.TRG_FAT_CUSTOM", line 88
ORA-04088: erro durante a execu��o do gatilho 'DBAPS.TRG_FAT_CUSTOM'. Detalhe: ORA-06512: em "DBAPS.TRG_FAT_CUSTOM", line 88
ORA-06512: em "DBAPS.PKG_MVS_SIP", line 1328
ORA-06512: em "DBAPS.PKG_MVS_SIP", line 1384

View program sources of error stack?
