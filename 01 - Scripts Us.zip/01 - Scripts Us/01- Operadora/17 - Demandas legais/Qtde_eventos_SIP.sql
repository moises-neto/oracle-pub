 SELECT *
        FROM (SELECT SUM(sip_informacao.qt_evento) TOTAL_EVENTO,
                     sip_ocorrencia.dt_inicial,
                     sip_ocorrencia.dt_final,
                     sip_ocorrencia.tp_trimestre,
                     sip_ocorrencia.nr_ano,
                     sip_ocorrencia.cd_sip_ocorrencia,
                     sip_informacao.cd_uf,
                     sip_informacao.tp_forma_contratacao
                FROM DBAPS.SIP_OCORRENCIA,
                     DBAPS.SIP_INFORMACAO,
                     DBAPS.SIP_ITEM_ASSIST
               WHERE sip_ocorrencia.cd_sip_periodo = 22 
               And sip_item_assist.cd_sip_item_assist In(29)
                 AND sip_informacao.cd_sip_ocorrencia = SIP_OCORRENCIA.cd_sip_ocorrencia
                 AND sip_informacao.cd_sip_item_assist = SIP_ITEM_ASSIST.cd_sip_item_assist
                -- AND instr(pDsItemXml, ',' || sip_item_assist.DS_ITEM_XML || ',') > 0
               GROUP BY sip_ocorrencia.dt_inicial,
                        sip_ocorrencia.dt_final,
                        sip_ocorrencia.tp_trimestre,
                        sip_ocorrencia.nr_ano,
                        sip_ocorrencia.cd_sip_ocorrencia,
                        sip_informacao.cd_uf,
                        sip_informacao.tp_forma_contratacao)
       WHERE TOTAL_EVENTO > 0;
