--28215
Select Sum(v.Quantidade),
       v.Cd_Conta_Medica,
       v.Cd_Lote,
       v.Cd_Procedimento,
       v.Cd_Lancamento
  From (Select Nvl(Qt_Pago, 0) Quantidade,
               Vcm.Cd_Conta_Medica,
               Vcm.Cd_Lote,
               Vcm.Cd_Procedimento,
               Vcm.Cd_Lancamento
        
          From Dbaps.v_Ctas_Medicas Vcm,
               Dbaps.Usuario        Usu,
               Dbaps.Plano          Pla,
               Dbaps.Procedimento   Pro,
               Dbaps.Pacote         Pct,
               Dbaps.Contrato       c,
               Dbaps.Plano_Contrato Pc
         Where Vcm.Cd_Matricula = Usu.Cd_Matricula
           And Vcm.Sn_Fatura_Fechada = 'S'
              --- And Vcm.Cd_Procedimento Like '4110%'
           And Vcm.Tp_Origem = '2'
              -- And vcm.sn_refaturar = 'N'
           And Vcm.Tp_Conta = 'A'
           And Vcm.Tp_Situacao_Conta In ('AA', 'AT')
           And Vcm.Tp_Situacao_Itconta In ('AA', 'AT')
           And Vcm.Tp_Situacao_Equipe In ('AA', 'AT')
          And Vcm.Tp_Beneficiario Not In ('EV', 'RC', 'RD', 'RP') --BENEFICIARIOS DE OUTRAS OPERADORAS
          -- And Vcm.Cd_Unimed_Origem = 018
           And Vcm.Tp_Pagcob In ('CP', 'PN')
              
           And Pro.Cd_Procedimento = Vcm.Cd_Procedimento(+)
              --teste Vania (Ajuste pois n�o esta gerando devido ao pacote)
           And Pct.Cd_Procedimento(+) = Pro.Cd_Procedimento --(+)
           And Usu.Cd_Plano = Pla.Cd_Plano
           And c.Cd_Contrato = Pc.Cd_Contrato
           And Pla.Cd_Plano = Pc.Cd_Plano
           And Usu.Cd_Contrato = c.Cd_Contrato
           And Pla.Sn_Sip = 'S'
           And Nvl(c.Sn_Sip, 'S') = 'S'
           And Vcm.Tp_Fatura <> 'R'
           And Vcm.Vl_Total_Pago > 0
           And vcm.dt_competencia Between '202207' And '202209'
          /* And Vcm.Dt_Entrada >= '01/07/2022'
           And Vcm.Dt_Entrada <= '01/09/2022'*/
              --  And Vcm.Cd_Conta_Medica = 12463838
              --And Vcm.Cd_Sip_Periodo = 22
              -- And Vcm.Dt_Competencia Between '202207' And '202209'
              /*  And Exists
              (Select 1
                       From Sip_Itassist_Proced Sp
                      Where Sp.Cd_Sip_Item_Assist = 61
                        And Sp.Cd_Procedimento = Vcm.Cd_Procedimento)*/
           And nvl(Vcm.Cd_Procedimento,vcm.cd_procedimento_digitado) In ('10101039', '99910073')
        
         Group By Vcm.Tp_Conta,
                  Vcm.Dt_Competencia,
                  Vcm.Cd_Lote,
                  Vcm.Cd_Fatura,
                  Vcm.Cd_Tipo_Atendimento,
                  Vcm.Cd_Prestador_Principal,
                  Decode(Nvl(Vcm.Cd_Atividade_Medica, 0),
                         0,
                         Vcm.Cd_Prestador,
                         Vcm.Cd_Prestador_Principal),
                  Vcm.Cd_Especialidade,
                  Vcm.Cd_Conta_Medica,
                  Vcm.Cd_Lancamento,
                  Vcm.Cd_Lancamento_Filho,
                  Vcm.Cd_Matricula,
                  Vcm.Nr_Guia,
                  Vcm.Cd_Guia_Externa,
                  Vcm.Dt_Realizado,
                  Vcm.Dt_Lancamento,
                  Vcm.Cd_Motivo,
                  Vcm.Cd_Procedimento,
                  Vcm.Cd_Procedimento_Principal,
                  Vcm.Cd_Procedimento_Digitado,
                  Vcm.Cd_Procedimento_Digi_Principal,
                  Vcm.Tp_Situacao,
                  Vcm.Tp_Origem,
                  Case
                    When To_Char(Vcm.Dt_Entrada, 'YYYY') < 2010 Then
                     Vcm.Dt_Apresentacao
                    Else
                     Vcm.Dt_Entrada
                  End,
                  Vcm.Dt_Saida,
                  Vcm.Cd_Cid,
                  Vcm.Tp_Internacao,
                  Vcm.Qt_Nascido_Prematuro,
                  Vcm.Qt_Nascido_Termo,
                  Vcm.Qt_Nascido_Morto,
                  Vcm.Sn_Fatura_Fechada,
                  Vcm.Sn_Lote_Fechado,
                  Vcm.Cd_Sip_Periodo,
                  Vcm.Cd_Multi_Empresa,
                  Pla.Cd_Plano,
                  Vcm.Qt_Cobrado,
                  Vcm.Qt_Pago,
                  Vcm.Qt_Glosada,
                  Sn_Pacote,
                  Cd_Item_Procedimento,
                  Pct.Qt_Padrao,
                  Pro.Cd_Procedimento) v

 Group By v.Cd_Conta_Medica, v.Cd_Lote, v.Cd_Procedimento, v.Cd_Lancamento;

--16321
Select m.Cd_Lote,
       m.Cd_Conta_Medica,
       m.Cd_Lancamento,
       m.Cd_Procedimento,
       m.Qt_Pago,
       Trunc(m.Dt_Entrada),
       m.Dt_Competencia
  From Sip_Conta_Medica m
 Where m.Cd_Sip_Periodo = 22
      /*  And (m.Cd_Sip_Item_Assist Is Null Or m.Cd_Sip_Item_Assist <> 61)
      And Not Exists (Select 1
             From Dbaps.Sip_Informacao o
            Where o.Cd_Sip_Informacao = m.Cd_Sip_Informacao)*/
   And m.Vl_Total_Pago > 0
   And Trunc(m.Dt_Entrada) >= '01/07/2022'
   And m.Tp_Conta = 'A'
   And m.Cd_Sip_Item_Assist = 61
/*And Exists (Select 1
 From Sip_Itassist_Proced Sp
Where Sp.Cd_Sip_Item_Assist = (61)
  And Sp.Cd_Procedimento = m.Cd_Procedimento)*/
--------------------------------------------------------------------------------------
--16313 
  Select m.cd_conta_medica, m.qt_pago, m.Vl_Total_Pago, m.Cd_Procedimento, m.cd_sip_informacao, m.cd_sip_item_assist
          From Sip_Conta_Medica m
         Where m.Cd_Sip_Periodo = 22
          -- And m.Cd_Sip_Item_Assist = 61
           And m.Tp_Conta = 'A'
          And m.Vl_Total_Pago > 0
          -- And m.Dt_Entrada < '01/07/2022'
           And m.Cd_Procedimento In ('99910073')
              
           And Not Exists
         (Select 1
                  From Dbaps.v_Ctas_Medicas Vcm,
                       Dbaps.Usuario        Usu,
                       Dbaps.Plano          Pla,
                       Dbaps.Procedimento   Pro,
                       Dbaps.Pacote         Pct,
                       Dbaps.Contrato       c,
                       Dbaps.Plano_Contrato Pc
                 Where Vcm.Cd_Matricula = Usu.Cd_Matricula
                   And Vcm.Sn_Fatura_Fechada = 'S'
                      --- And Vcm.Cd_Procedimento Like '4110%'
                   And Vcm.Tp_Origem = '2'
                      -- And vcm.sn_refaturar = 'N'
                   And Vcm.Tp_Conta = 'A'
                   And Vcm.Tp_Situacao_Conta In ('AA', 'AT')
                   And Vcm.Tp_Situacao_Itconta In ('AA', 'AT')
                   And Vcm.Tp_Situacao_Equipe In ('AA', 'AT')
                      -- And Vcm.Tp_Beneficiario Not In ('EV', 'RC', 'RD', 'RP') --BENEFICIARIOS DE OUTRAS OPERADORAS
                   And Vcm.Cd_Unimed_Origem = 018
                   And Vcm.Tp_Pagcob In ('CP', 'PN')
                   And Pro.Cd_Procedimento = Vcm.Cd_Procedimento(+)
                      --teste Vania (Ajuste pois n�o esta gerando devido ao pacote)
                   And Pct.Cd_Procedimento(+) = Pro.Cd_Procedimento --(+) 
                   And Vcm.Cd_Sip_Periodo = 22
                   And Usu.Cd_Plano = Pla.Cd_Plano
                   And c.Cd_Contrato = Pc.Cd_Contrato
                   And Pla.Cd_Plano = Pc.Cd_Plano
                   And Usu.Cd_Contrato = c.Cd_Contrato
                   And Pla.Sn_Sip = 'S'
                   And Nvl(c.Sn_Sip, 'S') = 'S'
                   And Vcm.Tp_Fatura <> 'R'
                   And Vcm.Vl_Total_Pago > 0
                      --  And Vcm.Cd_Conta_Medica = 12463838
                      --And Vcm.Cd_Sip_Periodo = 22
                   And Vcm.Dt_Competencia Between '202207' And '202209'
                   And Vcm.Cd_Conta_Medica = m.Cd_Conta_Medica
                   And Vcm.Cd_Procedimento = m.Cd_Procedimento)
