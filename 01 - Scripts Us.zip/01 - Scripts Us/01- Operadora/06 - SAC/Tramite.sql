Select * from dbaps.atend_call_center_ocorrencia C
WHERE c.cd_atend_call_center = 851516


select * from dbaps.atend_call_center c
where c.cd_prestador = '91578'
-- 
Select * from dbaps.Sac_Setor
select * from dbaps.atend_call_center_ocorrencia

SELECT * FROM PRESTADOR P WHERE P.NM_PRESTADOR LIKE 'DANIELE DELFINA MARTINS%'

SELECT *
  FROM TRAMITE_PROTOCOLO_CALL_CENTER t
 WHERE t.cd_atend_call_center = 851516

Select * from dbaps.autorizador a
where a.nm_autorizador like 'DANIELE DELFINA MARTINS%'

select t.cd_atend_call_center As Ocorrencia,
       t.cd_tramite_protocolo As Protocolo,
       a.nm_autorizador       AS Reponsavel,
       t.dt_inicio_tramite    As Data_Inicio,
       t.cd_usuario_rejeicao  As Usuario_Transfente
  from dbaps.tramite_protocolo_call_center t, dbaps.autorizador a
 Where t.cd_autorizador_tramite = a.cd_autorizador
   And t.cd_autorizador_tramite = 974
   order by ocorrencia, protocolo, 3
