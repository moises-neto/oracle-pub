update dbaps.tramite_protocolo_call_center t
   set t.dt_final_tramite = sysdate
 where t.cd_atend_call_center = --'851516'  --ocorrencia
 and t.cd_autorizador_tramite = --23   --autorizador de fechamento
