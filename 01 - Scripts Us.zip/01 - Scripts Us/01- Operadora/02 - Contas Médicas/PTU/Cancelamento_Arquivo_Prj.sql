Create Table custom.cnt_alter_status_arq_ptu
(cd_cnt_alter_status_arq_ptu Number(8),
cd_ptu_remessa_retorno Number,
nm_arquivo Varchar2(25),
Tp_arquivo Varchar2(6),
dt_geracao date,
dt_cancelamento_old Date,
cd_usuario_cancelamento_old Varchar2(30),
ds_motivo_cancelamento_old Varchar(4000),
tp_status_old Char(1) Not Null,
tp_status_new Char(1) Not Null,

Dt_log Date Default Sysdate,

Constraint PK_cd_cnt_alter_status_arq_ptu Primary Key (cd_cnt_alter_status_arq_ptu)
);

Grant All On cnt_alter_status_arq_ptu To Dbaps;
Create Sequence seq_cnt_alter_status_arq_ptu
Start With 1
Increment By 1;

Grant All On seq_cnt_alter_status_arq_ptu To Dbaps;
