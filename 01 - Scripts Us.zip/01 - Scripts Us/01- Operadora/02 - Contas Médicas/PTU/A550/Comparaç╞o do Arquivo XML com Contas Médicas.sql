  
-- Olhando os procedimentos que foram inclusos no XML.  
Select aq.nr_nota, aq.nr_lote, qp.*
  From dbaps.ptu_a550_cabecalho  ac,
       dbaps.ptu_a550_quest      aq,
       dbaps.ptu_a550_quest_proc qp
 Where ac.cd_ptu_a550 = aq.cd_ptu_a550
   And aq.cd_ptu_a550_quest = qp.cd_ptu_a550_quest
   And ac.nr_doc_1_a500 = '12102860'; --BUSCAR A TAG dentro do arquivo A550 XML.
 
 --- Comparando os procedimentos que foram inclusos dentro do contas.
 Select * From v_ctas_medicas v
 Where TO_number(v.nr_nota_referencia) = 2148062002 --NR_NOTA --> dbaps.ptu_a550_quest   
                                                                     
   
 --TXT
   Select r504.*/*r504.vl_adic_co/100,
          r504.vl_adic_filme/100,
          r504.vl_adic_ser/100,
          r504.vl_co_cob/100,
          r504.vl_filme_cob/100,
          r504.vl_pago_prest/100,
          r504.vl_serv_cob/100,
          r504.cd_servico,
          r504.tp_tabela*/
     From dbaps.ptu_a500_r504 r504
    where r504.cd_ptu_remessa_retorno = 453926
      and r504.cd_servico = 30733049;
