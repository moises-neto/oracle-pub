

/*data de efetiva��o dos 61 arquivos A550 de 01/08 a 03/08 para 31/07/2022.*/

Update 
   Dbaps.Ptu_Remessa_Retorno Rp
  Set rp.dh_geracao = '18/08/2022'
 Where Trunc(Rp.Dh_Geracao) ='29/09/2022' --Between '01/08/2022' And '03/08/2022'
   And Rp.Tp_Arquivo = 'A550'
   And Substr(RP.DS_ARQUIVO,0,3) = 'NC1'
   And RP.CD_UNIMED_ORIGEM <> 018
                                  
   
   
   Select * From  Dbaps.Ptu_Remessa_Retorno Rp
 --- Set rp.dh_geracao = '18/08/2022'
 Where Trunc(Rp.Dh_Geracao) ='29/09/2022' --Between '01/08/2022' And '03/08/2022'
   And Rp.Tp_Arquivo = 'A550'
   And Substr(RP.DS_ARQUIVO,0,3) = 'NC1'
   And RP.CD_UNIMED_ORIGEM <> 018
