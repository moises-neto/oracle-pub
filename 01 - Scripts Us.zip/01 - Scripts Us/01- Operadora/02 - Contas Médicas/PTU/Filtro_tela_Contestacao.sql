Select Pci.Tp_Arquivo,
       Prr.Tp_Arquivo Tp_Arq,
       Prr.Ds_Arquivo,
       Vcm.Nr_Fatura_Referencia Nr_Fatura,
       Pci.Cd_Conpag,
       Mc.Cd_Con_Rec Cd_Con_Rec,
       Pci.Cd_Mens_Contrato_Acordado,
       Max(To_Date(Vcm.Dt_Competencia, 'YYYY/MM')) Dt_Competencia,
       Pci.Dt_Inclusao Dt_Inclusao,
       Sum(Vcm.Vl_Total_Adicional_Cobrado) Vl_Total_Fatura,
       Pci.Vl_Total_Acordo_Arquivo Vl_Total_Acordo_Arquivo,
       Sum(Decode(Vcm.Dt_Contestacao,
                  Null,
                  0,
                  Vcm.Vl_Total_Adic_Glosado_Original)) Vl_Total_Contestado,
       Case
         When Pci.Tp_Arquivo In (4, 6, 8) Then
          'P'
         When Pci.Tp_Arquivo In (3, 5, 7) Then
          'R'
       End Tp_Pagamento,
       Vcm.Cd_Unimed_Executora Cd_Unimed_Origem,
       Vcm.Cd_Unimed_Origem Cd_Unimed_Destino,
       Pci.Cd_Ptu_Controle_Intercambio
  From Dbaps.v_Ctas_Medicas           Vcm,
       Dbaps.Fatura                   f,
       Dbaps.Ptu_Controle_Intercambio Pci,
       Dbaps.Ptu_Remessa_Retorno      Prr,
       Dbaps.Mens_Contrato            Mc
 Where Vcm.Cd_Fatura = Pci.Cd_Fatura
   And Vcm.Cd_Fatura = f.Cd_Fatura
   And Pci.Cd_Ptu_Remessa_Retorno = Prr.Cd_Ptu_Remessa_Retorno
   And Pci.Cd_Mens_Contrato_Acordado = Mc.Cd_Mens_Contrato(+)
   And Pci.Tp_Ptu_Status_Intercambio In (3, 5, 6, 9)
   And vcm.cd_fatura In (35882,37843)
/*   And (f.Nr_Ano || f.Nr_Mes) >=
       Nvl(To_Char(To_Date(:Pdt_Competencia, 'DD/MM/YYYY'), 'YYYYMM'),
           (f.Nr_Ano || f.Nr_Mes))
   And (f.Nr_Ano || f.Nr_Mes) <=
       Nvl(To_Char(To_Date(:Pdt_Competencia_Fim, 'DD/MM/YYYY'), 'YYYYMM'),
           (f.Nr_Ano || f.Nr_Mes))
   And Vcm.Cd_Fatura = Nvl(:Pnr_Fatura, Vcm.Cd_Fatura)
   And Vcm.Cd_Unimed_Executora =
       Nvl(:Pcd_Unimed_Origem, Vcm.Cd_Unimed_Executora)
   And Vcm.Cd_Unimed_Origem =
       Nvl(:Pcd_Unimed_Destino, Vcm.Cd_Unimed_Origem)
   And Pci.Tp_Arquivo = Nvl(:Ptp_Arquivo, Pci.Tp_Arquivo)
   And Pci.Dt_Inclusao =
       (Select Max(Pci2.Dt_Inclusao)
          From Dbaps.Ptu_Controle_Intercambio Pci2
         Where Pci2.Cd_Fatura = Pci.Cd_Fatura
           And Pci2.Tp_Ptu_Status_Intercambio =
               Pci.Tp_Ptu_Status_Intercambio
           And Pci2.Tp_Arquivo = Pci.Tp_Arquivo)
   And (Pci.Cd_Mens_Contrato_Acordado Is Not Null Or
       Pci.Cd_Conpag Is Not Null)
   And Pci.Dt_Cancelamento Is Null*/
 Group By Pci.Tp_Arquivo,
          Prr.Tp_Arquivo,
          Prr.Ds_Arquivo,
          Pci.Cd_Conpag,
          Mc.Cd_Con_Rec,
          Pci.Cd_Mens_Contrato_Acordado,
          Pci.Vl_Total_Acordo_Arquivo,
          Pci.Tp_Ptu_Status_Intercambio,
          Vcm.Nr_Fatura_Referencia,
          Pci.Dt_Inclusao,
          Case
            When Pci.Tp_Ptu_Status_Intercambio In (4, 6, 8) Then
             'P'
            When Pci.Tp_Ptu_Status_Intercambio In (3, 5, 7) Then
             'R'
          End,
          Vcm.Cd_Unimed_Executora,
          Vcm.Cd_Unimed_Origem,
          Pci.Cd_Ptu_Controle_Intercambio
 Order By Vcm.Nr_Fatura_Referencia,
          Tp_Ptu_Status_Intercambio,
          Dt_Inclusao,
          Nr_Fatura,
          Tp_Arquivo
          
          
          
         /* Select * From ptu_remessa_retorno pr
          Where pr.ds_arquivo Like '%4605639%'*/
          
          
