Select * From dbaps.ptu_remessa_retorno pe
where upper(pe.ds_arquivo) like upper('%N1757780_018%');

-- F --> Efetivou (recebeu importou e efetivou)
-- E --> Exportou (Exportar e enviar).


select * From ptu_a500_r501 r
where r.cd_ptu_remessa_retorno = 463348;


select * From ptu_a500_r504 r504
where r504.cd_ptu_remessa_retorno = 463348
and r504.nr_seq in (13,14,15,22,23,24)

