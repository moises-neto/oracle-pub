Select v.cd_fatura,
       v.cd_lote,
       v.cd_conta_medica,
       substr(v.nr_carteira_beneficiario, 0, 3)
  From Dbaps.V_ctas_medicas v
 Where v.dt_competencia = '202201'
      
   And Exists (Select 1
          From dbaps.lote l
         where l.cd_lote = v.cd_lote
           AND l.tp_lote IN ('P'))
      
   and Exists (Select 1
          From CUSTOM.TABELA_1037_ROL rol
         Where rol.procedimento = v.cd_procedimento)
      
   And not Exists (Select 1
          From ITCONTA_HOSPITALAR_FATURA i
         Where i.cd_conta_hospitalar = v.cd_conta_medica
           and i.cd_mens_contrato is not null)
      
   And not Exists
 (Select 1
          From ITREMESSA_PRESTADOR_fatura P
         Where p.cd_remessa = v.cd_conta_medica
           and p.cd_mens_contrato is not null)
      
   And substr(v.nr_carteira_beneficiario, 0, 3) <> 018

Union

Select v.cd_fatura,
       v.cd_lote,
       v.cd_conta_medica,
       substr(v.nr_carteira_beneficiario, 0, 3)
  From Dbaps.V_ctas_medicas v
 Where v.dt_competencia = '202201'
      
   And Exists (Select 1
          From dbaps.lote l
         where l.cd_lote = v.cd_lote
           and l.tp_lote IN ('P'))
      
   and Exists (Select 1
          From CUSTOM.TABELA_1036_ROL rol
         Where rol.procedimento = v.cd_procedimento)
      
   And not Exists (Select 1
          From ITCONTA_HOSPITALAR_FATURA i
         Where i.cd_conta_hospitalar = v.cd_conta_medica
           and i.cd_mens_contrato is not null)
      
   And not Exists
 (Select 1
          From ITREMESSA_PRESTADOR_fatura P
         Where p.cd_remessa = v.cd_conta_medica
           and p.cd_mens_contrato is not null)
      
   And substr(v.nr_carteira_beneficiario, 0, 3) <> 018
   
   
   
   --Select p.cd_mens_contrato From dbaps.itremessa_prestador_fatura p where p.cd_remessa = 10219230
