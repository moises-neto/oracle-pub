select distinct sum(v.vl_total_adicional_cobrado) as valor,
                to_char(v.cd_conta_medica),
                v.cd_procedimento
  From v_ctas_medicas_fatura v
 where v.cd_mens_contrato = 2230515
 --and v.cd_conta_medica = 10229208
-- and v.cd_procedimento = 30306027
 Group by  to_char(v.cd_conta_medica),  v.cd_procedimento
         --2099,2
minus    --997,73

Select sum(r504.vl_serv_cob + 
           r504.vl_co_cob + r504.vl_filme_cob + r504.vl_adic_ser +
       r504.vl_adic_co + r504.vl_adic_filme) / 100 as valor,
       r504.nr_nota,
       r504.cd_servico
  From ptu_a500_r504 r504
 where r504.cd_ptu_remessa_retorno = 463637
 /*and r504.nr_nota = 10229208
 and r504.cd_servico = 30306027*/
 Group by r504.nr_nota, r504.cd_servico
/*Select distinct r504.nr_nota
  From ptu_a500_r504 r504
 where r504.cd_ptu_remessa_retorno = 463637*/
 
 
  Select sum(r504.vl_serv_cob + r504.vl_co_cob + r504.vl_filme_cob + r504.vl_adic_ser +
       r504.vl_adic_co + r504.vl_adic_filme) / 100 as valor,
       r504.nr_nota
  From ptu_a500_r504 r504
 where r504.cd_ptu_remessa_retorno = 463637
 Group by r504.nr_nota  
 
 Select v.cd_lote From v_ctas_medicas v
 where v.cd_conta_medica = 10229208
