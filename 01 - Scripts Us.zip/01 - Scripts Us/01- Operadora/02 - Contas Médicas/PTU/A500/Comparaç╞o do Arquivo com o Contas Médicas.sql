
Select * From dbaps.ptu_remessa_retorno pr
--where pr.ds_arquivo like '%N1773670%'
where pr.ds_arquivo Like '%1790776%';


Select * From dbaps.ptu_remessa_retorno pr
--wHERE TRUNC(PR.DH_GERACAO) BETWEEN '15/02/2022' AND SYSDATE
where PR.DS_ARQUIVO like '%N2462462%';

Select c.nr_documento_1 From dbaps.ptu_a500_cabecalho c, dbaps.ptu_a500 p
where c.cd_ptu_a500 = p.cd_ptu_a500
and p.cd_ptu_remessa_retorno = 473641




/********************* HONORARIO ************************/

Select h.nr_lote_prestador,
       h.cd_ptu_a500_honorario,
       -- i.nr_lote_prestador_xml,
       -- i.nr_lote,
       c.nr_documento_1,
       h.nr_guia_tiss_prestador,
       h.nr_guia_tiss_operadora,
       -- i.nr_guia_tiss_prestador_xml,
       h.nr_guia_tiss_principal,
       p.nr_autorizacao,
       p.cd_servico,
       p.tp_tabela,
       p.vl_serv_cobrado,
       p.vl_filme_cobrado,
       p.vl_co_cobrado,
       a.cd_ptu_remessa_retorno,
      pqp.tp_participacao,
      p.cd_ptu_a500_proc
  From Dbaps.Ptu_A500_Honorario h,
       Dbaps.ptu_a500           a,
       Dbaps.Ptu_A500_Cabecalho c,
       Dbaps.Ptu_A500_Proc      p,
       Dbaps.Ptu_A500_Proc_Eqp  pqp

 Where a.cd_ptu_a500 = c.cd_ptu_a500
   And c.cd_ptu_a500 = h.cd_ptu_a500
   And h.cd_ptu_a500_honorario = p.cd_ptu_a500_honorario
   And p.cd_ptu_a500_proc = pqp.cd_ptu_a500_proc(+)
   --And c.nr_documento_1 = 812795
   And a.cd_ptu_remessa_retorno = 475455
   --And h.nr_lote_prestador = 362359 
   
;   
 -- --- Comparando os procedimentos que foram inclusos dentro do contas.  
 
 
 Select v.nr_lote_referencia,
         v.cd_lote
        v.nr_guia,
        v.nr_guia_prestador,
        v.cd_procedimento,
       v.vl_calculado,
       v.vl_unit_cobrado,
       v.vl_unit_acordado,
       v.vl_unit_contestado,
       v.vl_taxa_calculado,
       v.vl_unit_taxa_cobrado,
       v.vl_unit_taxa_acordado,
       v.vl_unit_taxa_contestado,
       v.vl_total_calculado,
       v.vl_total_cobrado,
       v.vl_percentual,
       v.vl_total_adicional_cobrado,
       v.vl_unit_taxa_cobrado_ptu,
       v.vl_total_taxa_cobrado_ptu,
       v.vl_total_contestado,
       v.vl_total_acordado,
       v.vl_total_adicional_contestado,
       v.vl_total_adicional_acordado,
       v.vl_ato_principal,
       v.vl_ato_auxiliar,
       v.vl_ato_nao_coop,
       v.vl_ato_principal_tx_adm,
       v.vl_ato_auxiliar_tx_adm,
       v.vl_ato_nao_coop_tx_adm,
       v.vl_fator_urgencia
   From v_ctas_medicas_fatura v
  Where --TO_number(v.cd_lote) = 361802 --NR_LOTE_PRESTADOR --> dbaps.Ptu_A500_Honorario
  --And 
   Nvl(to_char(v.nr_guia), v.nr_guia_prestador)  = '82646829' --> NR_GUIA_TISS_OPERADORA --> dbaps.Ptu_A500_Honorario
                     
; 

/********************* INTERNA��O ************************/

Select i.nr_lote_prestador,
       -- i.nr_lote_prestador_xml,
       -- i.nr_lote,
       i.nr_guia_tiss_prestador,
       i.nr_guia_tiss_operadora,
       -- i.nr_guia_tiss_prestador_xml,
       i.nr_guia_tiss_principal,
       p.cd_servico,
       p.tp_tabela,
       p.vl_serv_cobrado,
       p.vl_filme_cobrado,
       p.vl_co_cobrado,
       I.DT_ULTIMA_AUTORIZACAO
  From dbaps.ptu_a500_cabecalho  c,
       Dbaps.Ptu_A500_Internacao I,
       dbaps.ptu_a500_proc       p,
       dbaps.ptu_a500            a
 Where a.cd_ptu_a500 = c.cd_ptu_a500
   And c.cd_ptu_a500 = i.cd_ptu_a500
   and p.cd_ptu_a500_internacao = i.cd_ptu_a500_internacao
   -- And c.nr_documento_1 = 1765727
   And a.cd_ptu_remessa_retorno = 475455
    
  -- And p.cd_servico = 10102019
; 
 --- Comparando os procedimentos que foram inclusos dentro do contas.
 Select v.nr_lote_referencia,
         v.cd_lote
        v.nr_guia,
        v.nr_guia_prestador,
        v.cd_procedimento,
       v.vl_calculado,
       v.vl_unit_cobrado,
       v.vl_unit_acordado,
       v.vl_unit_contestado,
       v.vl_taxa_calculado,
       v.vl_unit_taxa_cobrado,
       v.vl_unit_taxa_acordado,
       v.vl_unit_taxa_contestado,
       v.vl_total_calculado,
       v.vl_total_cobrado,
       v.vl_percentual,
       v.vl_total_adicional_cobrado,
       v.vl_unit_taxa_cobrado_ptu,
       v.vl_total_taxa_cobrado_ptu,
       v.vl_total_contestado,
       v.vl_total_acordado,
       v.vl_total_adicional_contestado,
       v.vl_total_adicional_acordado,
       v.vl_ato_principal,
       v.vl_ato_auxiliar,
       v.vl_ato_nao_coop,
       v.vl_ato_principal_tx_adm,
       v.vl_ato_auxiliar_tx_adm,
       v.vl_ato_nao_coop_tx_adm,
       v.vl_fator_urgencia
   From v_ctas_medicas_fatura v
  Where TO_number(v.cd_lote) = 361800 --NR_LOTE_PRESTADOR --> dbaps.Ptu_A500_Internacao
  And Nvl(to_char(v.nr_guia), v.nr_guia_prestador)  = '81191149'
  --And v.cd_procedimento = 10102019                                                                    
  
/********************* CONSULTA ************************/

Select c.Nr_Lote_Prestador,
       c.Nr_Lote_Txt,
       c.Nr_Lote_Prestador_Xml,
       c.nr_guia_tiss_prestador,
       c.nr_guia_tiss_operadora,
       c.nr_guia_tiss_principal,
       c.nr_guia_tiss_prestador_xml,
       (Select g.nr_guia
          From dbaps.guia g
         where nvl(g.cd_ptu_mensagem_origem, g.cd_ptu_mensagem_destino) =
               c.nr_autorizacao) as Guia_Contas,
       c.nr_autorizacao,
       c.cd_servico,
       c.vl_serv_cobrado

  From Dbaps.Ptu_A500_Consulta  c,
       dbaps.ptu_a500_cabecalho ca,
       Dbaps.Ptu_a500           a
 Where c.cd_ptu_a500 = ca.cd_ptu_a500
   And a.cd_ptu_a500 = ca.cd_ptu_a500
   And a.cd_ptu_remessa_retorno = 475455       
;   
  -- --- Comparando os procedimentos que foram inclusos dentro do contas.
  
 Select  v.nr_lote_referencia,
         v.cd_lote
        v.nr_guia,
        v.nr_guia_prestador,
        v.cd_procedimento,
       v.vl_calculado,
       v.vl_unit_cobrado,
       v.vl_unit_acordado,
       v.vl_unit_contestado,
       v.vl_taxa_calculado,
       v.vl_unit_taxa_cobrado,
       v.vl_unit_taxa_acordado,
       v.vl_unit_taxa_contestado,
       v.vl_total_calculado,
       v.vl_total_cobrado,
       v.vl_percentual,
       v.vl_total_adicional_cobrado,
       v.vl_unit_taxa_cobrado_ptu,
       v.vl_total_taxa_cobrado_ptu,
       v.vl_total_contestado,
       v.vl_total_acordado,
       v.vl_total_adicional_contestado,
       v.vl_total_adicional_acordado,
       v.vl_ato_principal,
       v.vl_ato_auxiliar,
       v.vl_ato_nao_coop,
       v.vl_ato_principal_tx_adm,
       v.vl_ato_auxiliar_tx_adm,
       v.vl_ato_nao_coop_tx_adm,
       v.vl_fator_urgencia
   From v_ctas_medicas_fatura v
  Where v.nr_guia = 82646829; -- GUIA_CONTAS       
;  

/********************* SADT ************************/


Select s.nr_lote_prestador,
       -- i.nr_lote_prestador_xml,
       -- i.nr_lote,
       s.nr_guia_tiss_prestador,
       s.nr_guia_tiss_operadora,
       -- i.nr_guia_tiss_prestador_xml,
       s.nr_guia_tiss_principal,
       p.cd_servico,
       p.tp_tabela,
       p.vl_serv_cobrado,
       p.vl_filme_cobrado,
       p.vl_co_cobrado,
       a.cd_ptu_remessa_retorno,
       S.CD_PTU_A500_SADT,
      eq.cd_cpf,
      p.cd_ptu_a500_proc
  From
       Dbaps.Ptu_A500           A,
       Dbaps.Ptu_A500_Cabecalho C,
       Dbaps.Ptu_A500_Proc P, 
       dbaps.ptu_a500_sadt s,
       Dbaps.Ptu_A500_Proc_Eqp eq

Where a.cd_ptu_a500 = c.cd_ptu_a500
And c.cd_ptu_a500 = s.cd_ptu_a500
And s.cd_ptu_a500_sadt = p.cd_ptu_a500_sadt
and eq.cd_ptu_a500_proc = p.cd_ptu_a500_proc
--And c.nr_documento_1 = 1765727
   And a.cd_ptu_remessa_retorno = 475455;

 -- --- Comparando os procedimentos que foram inclusos dentro do contas.
 Select /*v.nr_lote_referencia,
         v.cd_lote
        v.nr_guia,
        v.nr_guia_prestador,
        v.cd_procedimento,
       v.vl_calculado,
       v.vl_unit_cobrado,
       v.vl_unit_acordado,
       v.vl_unit_contestado,
       v.vl_taxa_calculado,
       v.vl_unit_taxa_cobrado,
       v.vl_unit_taxa_acordado,
       v.vl_unit_taxa_contestado,
       v.vl_total_calculado,
       v.vl_total_cobrado,
       v.vl_percentual,
       v.vl_total_adicional_cobrado,
       v.vl_unit_taxa_cobrado_ptu,
       v.vl_total_taxa_cobrado_ptu,
       v.vl_total_contestado,
       v.vl_total_acordado,
       v.vl_total_adicional_contestado,
       v.vl_total_adicional_acordado,
       v.vl_ato_principal,
       v.vl_ato_auxiliar,
       v.vl_ato_nao_coop,
       v.vl_ato_principal_tx_adm,
       v.vl_ato_auxiliar_tx_adm,
       v.vl_ato_nao_coop_tx_adm,
       v.vl_fator_urgencia*/
       Sum(v.vl_total_cobrado)
   From v_ctas_medicas_fatura v
  Where --TO_number(v.cd_lote) = 355470 --NR_LOTE_PRESTADOR --> dbaps.ptu_a500_sadt
--  And  
  
  --Nvl(to_char(v.nr_guia), v.nr_guia_prestador)  = '82646829'
; 
 

   
