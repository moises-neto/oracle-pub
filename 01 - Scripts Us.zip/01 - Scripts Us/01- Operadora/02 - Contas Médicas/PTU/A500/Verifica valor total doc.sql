Select c.vl_tot_doc_1 From dbaps.ptu_a500_cabecalho c
where c.cd_ptu_a500 = 436;

select * From ptu_a500_internacao s where s.cd_ptu_a500 =  436;

select * From tiss_instalacao_tabela_18 t
where t.cd_procedimento = 60023384

select  s.*
        From ptu_a500_honorario s where s.cd_ptu_a500 =  512;
        
        select * from dbaps.ptu_a500_internacao i where i.cd_ptu_a500 = 500;
        
        select * From dbaps.ptu_a500_sadt s
        where s.cd_ptu_a500 = 532

select  Coalesce(h.nr_lote_prestador, s.nr_lote_prestador, i.nr_lote_prestador) as lote,
       Coalesce(h.nr_guia_tiss_operadora, s.nr_guia_tiss_operadora, i.nr_guia_tiss_operadora) as Guia,
       p.cd_servico,
       p.vl_co_cobrado,
       p.vl_serv_cobrado,
      
       p.tp_tabela
  From ptu_a500_proc p, dbaps.ptu_a500_honorario h, DBAPS.Ptu_A500_Sadt s, dbaps.ptu_a500_internacao i
 where p.cd_ptu_a500_honorario = h.cd_ptu_a500_honorario(+)
 and p.cd_ptu_a500_sadt = s.cd_ptu_a500_sadt(+)
 And p.cd_ptu_a500_internacao = i.cd_ptu_a500_internacao (+)
   and (s.cd_ptu_a500 = 545 or 
        h.cd_ptu_a500 = 545 or 
        i.cd_ptu_a500_internacao = 545)
   

-- or p.cd_ptu_a500_internacao in (428) 
 select * from dbaps.ptu_a500_proc p
 where p.cd_ptu_a500_sadt 
 
 
Select * From dbaps.ptu_a500 a
where a.cd_ptu_remessa_retorno = 466073;


Select * From dbaps.ptu_remessa_retorno r
Where r.cd_ptu_remessa_retorno = 465798;


Select * From dbaps.ptu_remessa_retorno r
Where r.ds_arquivo like '%1765727%'
order by 1 desc;




