
-- ex.: lote 330545 e conta 101731

Select 'I' Tp_Conta,
       Ch.Cd_Lote,
       Ch.Cd_Conta_Hospitalar Cd_Conta_Medica,
       Ich.Cd_Lancamento

  From Dbaps.Lote               l,
       Dbaps.Conta_Hospitalar   Ch,
       Dbaps.Itconta_Hospitalar Ich
 Where l.Cd_Lote = Ch.Cd_Lote
   And Ch.Cd_Conta_Hospitalar = Ich.Cd_Conta_Hospitalar
      --    AND L.CD_PROTOCOLO_CTAMED = PCD_PROTOCOLO_CTAMED
   And Ch.Cd_Prestador = 300100;

Select Im.Cd_Ati_Med, Im.*
  From Dbaps.Itconta_Med Im
 Where Im.Cd_Conta_Hospitalar = 101731
   And Im.Cd_Lancamento = 1;

-- 1� descobrir prestadores pagamento da conta     
Select Distinct Itm.Cd_Prestador_Pagamento,
                Pr.Cd_Tip_Prestador,
                Pr.Tp_Prestador
  From Dbaps.Itconta_Hospitalar It,
       Dbaps.Itconta_Med        Itm,
       Dbaps.Prestador          Pr
 Where Itm.Cd_Conta_Hospitalar = It.Cd_Conta_Hospitalar
   And Itm.Cd_Lancamento = It.Cd_Lancamento
   And Pr.Cd_Prestador = Itm.Cd_Prestador_Pagamento
   And Pr.Tp_Prestador = 'F'
   And Exists
 (Select 1
          From Dbaps.Itconta_Hospitalar Ic, Dbaps.Itconta_Med Ii
         Where Ii.Cd_Conta_Hospitalar = Ic.Cd_Conta_Hospitalar
           And Ic.Cd_Procedimento = It.Cd_Procedimento
           And Ic.Dt_Lancamento = It.Dt_Lancamento
           And Ic.Hr_Inicial = Ic.Hr_Inicial
           And Itm.Cd_Ati_Med <> Ii.Cd_Ati_Med
           And Itm.Cd_Prestador_Pagamento <> Ii.Cd_Prestador_Pagamento)
   And It.Cd_Conta_Hospitalar = 101731
   And It.Cd_Procedimento = '30502349';

-- 2� Descobrir os itens vinculados ao prestador: Itconta_Hospitalar

Select It.*
  From Dbaps.Itconta_Hospitalar It, Dbaps.Itconta_Med Itm
 Where Itm.Cd_Conta_Hospitalar = It.Cd_Conta_Hospitalar
   And Itm.Cd_Lancamento = It.Cd_Lancamento
   And It.Cd_Conta_Hospitalar = 101731
   And Itm.Cd_Prestador_Pagamento In
       (Select Distinct Itm.Cd_Prestador_Pagamento
          From Dbaps.Itconta_Hospitalar It,
               Dbaps.Itconta_Med        Itm,
               Dbaps.Prestador          Pr
         Where Itm.Cd_Conta_Hospitalar = It.Cd_Conta_Hospitalar
           And Itm.Cd_Lancamento = It.Cd_Lancamento
           And Pr.Cd_Prestador = Itm.Cd_Prestador_Pagamento
           And Pr.Tp_Prestador = 'F'
           And Exists
         (Select 1
                  From Dbaps.Itconta_Hospitalar Ic, Dbaps.Itconta_Med Ii
                 Where Ii.Cd_Conta_Hospitalar = Ic.Cd_Conta_Hospitalar
                   And Ic.Cd_Procedimento = It.Cd_Procedimento
                   And Ic.Dt_Lancamento = It.Dt_Lancamento
                   And Ic.Hr_Inicial = Ic.Hr_Inicial
                   And Itm.Cd_Ati_Med <> Ii.Cd_Ati_Med
                   And Itm.Cd_Prestador_Pagamento <>
                       Ii.Cd_Prestador_Pagamento)
           And It.Cd_Conta_Hospitalar = 101731
           And It.Cd_Procedimento = '30502349')
 Order By 1, 2;

-- 3� Descobrir os itens vinculados ao prestador: Itconta_Med

Select Itm.*
  From Dbaps.Itconta_Hospitalar It, Dbaps.Itconta_Med Itm
 Where Itm.Cd_Conta_Hospitalar = It.Cd_Conta_Hospitalar
   And Itm.Cd_Lancamento = It.Cd_Lancamento
   And It.Cd_Conta_Hospitalar = 101731
   And Itm.Cd_Prestador_Pagamento In
       (Select Distinct Itm.Cd_Prestador_Pagamento
          From Dbaps.Itconta_Hospitalar It,
               Dbaps.Itconta_Med        Itm,
               Dbaps.Prestador          Pr
         Where Itm.Cd_Conta_Hospitalar = It.Cd_Conta_Hospitalar
           And Itm.Cd_Lancamento = It.Cd_Lancamento
           And Pr.Cd_Prestador = Itm.Cd_Prestador_Pagamento
           And Pr.Tp_Prestador = 'F'
           And Exists
         (Select 1
                  From Dbaps.Itconta_Hospitalar Ic, Dbaps.Itconta_Med Ii
                 Where Ii.Cd_Conta_Hospitalar = Ic.Cd_Conta_Hospitalar
                   And Ic.Cd_Procedimento = It.Cd_Procedimento
                   And Ic.Dt_Lancamento = It.Dt_Lancamento
                   And Ic.Hr_Inicial = Ic.Hr_Inicial
                   And Itm.Cd_Ati_Med <> Ii.Cd_Ati_Med
                   And Itm.Cd_Prestador_Pagamento <>
                       Ii.Cd_Prestador_Pagamento)
           And It.Cd_Conta_Hospitalar = 101731
           And It.Cd_Procedimento = '30502349')
 Order By 1, 2;
 
 
Select l.cd_protocolo_ctamed From dbaps.conta_hospitalar ch, dbaps.lote l
Where l.cd_lote = ch.cd_lote
And ch.Cd_Conta_Hospitalar = 101731;



-- 1� descobrir prestadores pagamento por protocolo    
Select Distinct Itm.Cd_Prestador_Pagamento,
                Pr.Cd_Tip_Prestador,
                Pr.Tp_Prestador
  From Dbaps.Itconta_Hospitalar It,
       Dbaps.Itconta_Med        Itm,
       Dbaps.Prestador          Pr,
       Dbaps.Conta_Hospitalar   Ch,
       Dbaps.Lote               l
 Where l.Cd_Lote = Ch.Cd_Lote 
   And It.Cd_Conta_Hospitalar = Ch.Cd_Conta_Hospitalar
   And Itm.Cd_Conta_Hospitalar = It.Cd_Conta_Hospitalar
   And Itm.Cd_Lancamento = It.Cd_Lancamento
   
   And Pr.Cd_Prestador = Itm.Cd_Prestador_Pagamento
   
   And Pr.Tp_Prestador = 'F'
   And Exists
 (Select 1
          From Dbaps.Itconta_Hospitalar Ic, Dbaps.Itconta_Med Ii
         Where Ii.Cd_Conta_Hospitalar = Ic.Cd_Conta_Hospitalar
           And Ic.Cd_Procedimento = It.Cd_Procedimento
           And Ic.Dt_Lancamento = It.Dt_Lancamento
           And Ic.Hr_Inicial = Ic.Hr_Inicial
           And Itm.Cd_Ati_Med <> Ii.Cd_Ati_Med
           And Itm.Cd_Prestador_Pagamento <> Ii.Cd_Prestador_Pagamento)
   And l.Cd_Protocolo_Ctamed = 441975;


Select Distinct l.cd_tipo_atendimento, ta.ds_tipo_atendimento From dbaps.lote l, dbaps.tipo_atendimento ta
Where ta.cd_tipo_atendimento = l.cd_tipo_atendimento
Order By 1;


Select Vc.Cd_Lote, Vc.Cd_Conta_Medica, Vc.Cd_Prestador_Principal
  From Dbaps.v_Ctas_Medicas Vc, Dbaps.Lote l
 Where l.Cd_Lote = Vc.Cd_Lote
   And l.Cd_Tipo_Atendimento = 4
   And Vc.Dt_Competencia = '202110';

Select * From dbaps.lote l
Where l.cd_lote = 340995;



-- 6� Pegar os itens da conta com pagamento ao prestador do lote: itconta_hospitalar_fatura???
Select * From dbaps.itconta_hospitalar_fatura itf
Where Exists
(Select 1 From Dbaps.Itconta_Hospitalar It, Dbaps.Itconta_Med Itm
 Where Itm.Cd_Conta_Hospitalar = It.Cd_Conta_Hospitalar
   And Itm.Cd_Lancamento = It.Cd_Lancamento
   And itf.cd_conta_hospitalar = It.Cd_Conta_Hospitalar
   And itf.cd_lancamento = it.cd_lancamento
   And itf.cd_prestador = itm.cd_prestador_pagamento
   And It.Cd_Conta_Hospitalar = 101731
   And Itm.Cd_Prestador_Pagamento = 80768);
   
/*   
-- PR_MIGRA_CONTAS_MEDICAS_SEMIMP
-- PRC_GERA_FAT_CONTA_MEDICA
Select * From All_Source a
Where upper(a.TEXT) Like Upper('%INSERT%itconta_hospitalar_fatura%');

Select * From All_Source a
Where upper(a.TEXT) Like Upper('%PRC_GERA_FAT_CONTA_MEDICA%');
*/
