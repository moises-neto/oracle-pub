
Select ch.cd_tip_acomodacao, ch.* From dbaps.lote l, dbaps.conta_hospitalar ch
Where l.cd_protocolo_ctamed = 454898
And ch.cd_lote = l.cd_lote;

Select *
      From Dbaps.Tmp_Sincroniza_Alt_Honorario t
     Where t.Sn_Sincronizado = 'N';


--Select Sysdate, sysdate + 5/1440, sysdate + 3/1440, sysdate + 1/1440, SYSDATE + 60/1400  From dual;

Select * From All_Jobs;

/*begin
	DBMS_JOB.Remove(5743);
end;*/
