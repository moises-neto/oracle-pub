Create Procedure Prc_Copia_Guia_Honorario(Pcd_Lote         In Number,
                                          Pcd_Conta_Medica In Number,
                                          Pcd_Prestador    In Number) Is

  --- Curores

  Cursor Cdadoslote Is
  -- Pegar os dados do Lote Atual (Resumo)
    Select
    -- cd_lote -- sequence,
     l.Cd_Fatura,
     l.Ds_Lote || ' - ' || ' Guia de Honor�rio do Prestador: ' ||
     Pcd_Prestador Ds_Lote,
     l.Dt_Lote,
     l.Sn_Fechado,
     4 Cd_Tipo_Atendimento,
     l.Cd_Protocolo_Ctamed,
     l.Cd_Usuario_Inclusao,
     l.Dt_Inclusao,
     Pcd_Prestador Cd_Prestador,
     l.Tp_Lote,
     l.Tp_Origem,
     l.Cd_Multi_Empresa,
     l.Cd_Versao_Tiss,
     l.Tp_Pagcob
      From Dbaps.Lote l
     Where l.Cd_Lote = Pcd_Lote;

  -- Vari�veis Cursores
  Rcontashonorario Ccontashonorario%Type;

  -- Var�aveis Sequence
  v_Seq_Lote Number;

  -- Var�aveis de Controle
  v_InsertLoteOk Boolean;

Begin

  Open Ccontashonorario;
  Fetch Ccontashonorario
    Into Rcontashonorario;
  Close Ccontashonorario;

  Begin
  
    v_Seq_Lote := Dbaps.Seq_Lote.Nextval;
  
    Insert Into Dbaps.Lote
      (Cd_Lote,
       Cd_Fatura,
       Ds_Lote,
       Dt_Lote,
       Sn_Fechado,
       Cd_Tipo_Atendimento,
       Cd_Protocolo_Ctamed,
       Cd_Usuario_Inclusao,
       Dt_Inclusao,
       Cd_Prestador,
       Tp_Lote,
       Tp_Origem,
       Cd_Multi_Empresa,
       Cd_Versao_Tiss,
       Tp_Pagcob)
    Values
      (v_Seq_Lote,
       Rcontashonorario.Cd_Fatura,
       Rcontashonorario.Ds_Lote,
       Rcontashonorario.Dt_Lote,
       Rcontashonorario.Sn_Fechado,
       Rcontashonorario.Cd_Tipo_Atendimento,
       Rcontashonorario.Cd_Protocolo_Ctamed,
       Rcontashonorario.Cd_Usuario_Inclusao,
       Rcontashonorario.Dt_Inclusao,
       Rcontashonorario.Cd_Prestador,
       Rcontashonorario.Tp_Lote,
       Rcontashonorario.Tp_Origem,
       Rcontashonorario.Cd_Multi_Empresa,
       Rcontashonorario.Cd_Versao_Tiss,
       Rcontashonorario.Tp_Pagcob);
       
       v_InsertLoteOk := True;
  
  Exception
  
    When Others Then
      v_InsertLoteOk := False;
      Rollback;
      Raise_Application_Error(-20002,
                              'Falha: ' || Sqlerrm || 'cid: ' ||
                              Ix.Cd_Contrato);
  End;
  
  
  

End;
