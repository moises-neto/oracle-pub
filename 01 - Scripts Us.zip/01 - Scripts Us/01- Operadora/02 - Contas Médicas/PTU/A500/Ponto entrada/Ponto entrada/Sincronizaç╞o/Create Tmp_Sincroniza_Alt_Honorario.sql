-- Create table
create table TMP_SINCRONIZA_ALT_HONORARIO
(
  cd_fatura                    NUMBER(8),
  cd_lote                      NUMBER(8),
  cd_conta_medica              NUMBER(12),
  cd_tip_acomodacao_old        NUMBER(2),
  cd_tip_acomodacao_new        NUMBER(2),
  autorizador_audit_medico_old NUMBER(8),
  autorizador_audit_medico_new NUMBER(8),
  autorizador_audit_enferm_old NUMBER(8),
  autorizador_audit_enferm_new NUMBER(8),
  ds_observacao                VARCHAR2(4000),
  dt_inclusao                  DATE,
  sn_sincronizado              VARCHAR2(1) default 'N'
)
