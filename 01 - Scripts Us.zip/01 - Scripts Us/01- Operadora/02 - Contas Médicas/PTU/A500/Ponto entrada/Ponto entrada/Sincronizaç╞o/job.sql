

declare
--Declare vari�vel que recebe n�mero do JOB.
job_num binary_integer;
begin
--Cria o JOB no banco e retorna o n�mero dele job_num
dbms_job.submit(job_num,
'begin Dbaps.Prc_Replica_Dados_Honorario; end; ',
to_date('10/12/2021, 15:18', 'dd/mm/yyyy hh24:mi'),
'sysdate + 1/1440');
end;
/
