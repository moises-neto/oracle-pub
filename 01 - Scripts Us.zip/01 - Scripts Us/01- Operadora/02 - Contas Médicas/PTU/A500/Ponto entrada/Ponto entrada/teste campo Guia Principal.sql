/*
ORA-20002: Esta atualiza��o n�o ser� poss�vel porque a conta a pagar para fatura/prestador: 30375/1001153 j� foi gerada para o financeiro. Contas a Pagar: 455272
ORA-06512: em "DBAPS.PRC_MVS_VERIFICA_LCTO", line 127
ORA-06512: em "DBAPS.TRG_CONTA_HOSPITALAR", line 65
ORA-04088: erro durante a execu��o do gatilho 'DBAPS.TRG_CONTA_HOSPITALAR'

View program sources of error stack?

*/

-- teste campo Guia Principal
Select ch.nr_guia_tem, ch.*, Rowid From dbaps.conta_hospitalar ch
Where ch.cd_conta_hospitalar = 101731;
