
dbaps.ptu_a500
dbaps.ptu_a500_cabecalho
dbaps.ptu_a500_complemento
dbaps.ptu_a500_consulta
dbaps.ptu_a500_sadt
dbaps.ptu_a500_internacao
dbaps.ptu_a500_honorario
dbaps.ptu_a500_proc
dbaps.ptu_a500_proc_eqp
dbaps.ptu_a500_internacao_dec
