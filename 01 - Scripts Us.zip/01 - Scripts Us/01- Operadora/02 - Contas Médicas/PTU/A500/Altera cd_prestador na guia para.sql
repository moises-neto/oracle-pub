Declare

Begin
  For i In (Select Distinct v.Nr_Guia
              From Dbaps.v_Ctas_Medicas v
             Where v.dt_competencia = '202208'
               And Exists (Select 1
                      From Dbaps.Guia g
                     Where g.Nr_Guia = v.Nr_Guia
                       And g.Cd_Unimed_Origem <> 018
                       And g.Cd_Prestador_Executor = 300100
                       And g.Cd_Prestador_Solicitado = 0)) Loop
  
    Begin
      Update Dbaps.Guia g
         Set g.Cd_Prestador = 300100, g.Cd_Prestador_Solicitado = 300100
       Where g.Nr_Guia = i.Nr_Guia;
                       
    End;
        dbms_output.put_line('Guia: ' || i.nr_guia);
  End Loop;

End;
