Update Dbaps.Itremessa_Prestador_Fatura f
   Set f.Vl_Unit_Taxa_Cobrado = 0
 Where Exists (Select 1
          From Dbaps.v_Ctas_Medicas v
         Where v.Cd_Conta_Medica = f.Cd_Remessa
           And v.Cd_Lancamento = f.Cd_Lancamento
           And v.Cd_Fatura = 37264);

Update Dbaps.Itconta_Hospitalar_Fatura f
   Set f.Vl_Unit_Taxa_Cobrado = 0
 Where Exists (Select 1
          From Dbaps.v_Ctas_Medicas v
         Where v.Cd_Conta_Medica = f.Cd_Conta_Hospitalar
           And v.Cd_Lancamento = f.Cd_Lancamento
           And v.Cd_Fatura = 37264)

 Update Dbaps.Itconta_Hospitalar_Fatura f Set
 f.Cd_Mens_Contrato = Null
 Where Exists (Select 1
          From Dbaps.v_Ctas_Medicas v
         Where v.Cd_Conta_Medica = f.Cd_Conta_Hospitalar
           And v.Cd_Lancamento = f.Cd_Lancamento
           And v.Cd_Fatura = 37280);

Update Dbaps.Conta_Hospitalar f
   Set f.Cd_Mens_Contrato = Null
 Where Exists (Select 1
          From Dbaps.v_Ctas_Medicas v
         Where v.Cd_Conta_Medica = f.Cd_Conta_Hospitalar
           And v.Cd_Lancamento = f.Cd_Lancamento
           And v.Cd_Fatura = 37280)
