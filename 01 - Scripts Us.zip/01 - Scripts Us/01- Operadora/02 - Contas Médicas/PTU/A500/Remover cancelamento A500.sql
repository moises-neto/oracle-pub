
-- Remover cancelamento A500

/*
Ex.:
CH2106-2879 - CANCELAMENTO A500 INDEVIDO
Por gentileza alterar o status do A500 1640570 ID 406675
PARA EXPORTADO pois o mesmo foi cancelado indevidamente .

*/
-- tp_status de C para E
-- limpa cd_usuario_cancelamento e ds_motivo_cancelamento
select pr.tp_status, pr.cd_usuario_cancelamento, pr.ds_motivo_cancelamento, pr.*, rowid from dbaps.ptu_remessa_retorno pr
where pr.cd_ptu_remessa_retorno = 472317; 

-- limpa dt_cancelamento
select pi.dt_cancelamento, pi.*, ROWID from dbaps.ptu_controle_intercambio pi
where pi.cd_ptu_remessa_retorno = 472317;


   select f.*, rowid From dbaps.fatura f
         where f.cd_fatura in (35216,34927,34784);
         TP_PTU_STATUS_INTERCAMBIO
          
         DBAPS.V_PTU_STATUS_INTERCAMBIO

         
         
Call CUSTOM.PKG_CONMVS_PTU_BATCH.Prc_Altera_Status_Arq_Ptu(p_Id_Arquivo => 567340, p_Nr_Chamado => 'CH2301-0247');

  

