Select *
  From (Select Cd_Mens_Contrato,
               Cd_Lote,
               Cd_Conta_Medica,
               Id_Itemunico,
               Dbaps.Fnc_Procedimento_Analise(Cd_Servico, Cd_Pre_Req, 'C') Cd_Servico,
               Dbaps.Fnc_Remove_Acento(Ds_Servico) Ds_Servico,
               Qt_Cobrada,
               /* HM */
               Sum(Nvl(Vl_Serv_Cob, 0) + Nvl(Vl_Adic_Ser, 0) +
                   Nvl(Vl_Filme_Cob, 0) + Nvl(Vl_Adic_Filme, 0) +
                   Nvl(Vl_Co_Cob, 0) + Nvl(Vl_Adic_Co, 0)) As Valor,
               Lancamento
        
          From (Select /* DISTINCT comentando em 13/03/2022 FDLA E AMES para poder somar valores de linhas iguais */
                Distinct Vcmf.Cd_Lote,
                         Vcmf.Cd_Conta_Medica,
                         Vcmf.Cd_Mens_Contrato,
                         Vcmf.Cd_Prestador_Principal Cd_Pre_Req,
                         Vcmf.Cd_Lancamento          As Lancamento,
                         --AMES - 13/03/2022 - CAMPO ALTERADO PARA AGRUPAMENTO PTU XML 1.1
                         --VCMF.ID_ITEM_UNICO ID_ITEMUNICO,
                         Case
                           When (Vcmf.Tp_Conta = 'I' /*CONTA DE RESUMO DE INTERNA��O*/
                                And Pex.Tp_Prestador = 'J' /*PF DEVE VIR EM OUTRA GUIA DE HONORARIO(TISS)*/
                                ) Then
                           --AMES - 13/03/2022 AGRUPAMENTO DO ITEM UNICO
                            Dbaps.Fnc_Ptu_Agrupa_Item_Unico(Vcmf.Cd_Lote,
                                                            Vcmf.Cd_Conta_Medica,
                                                            Vcmf.Cd_Procedimento,
                                                            Pex.Cd_Prestador,
                                                            Vcmf.Id_Item_Unico,
                                                            'CSERVICO',
                                                            Vcmf.Dt_Realizado,
                                                            Vcmf.Hr_Inicial,
                                                            Vcmf.Hr_Final)
                           Else
                           --AMES - 13/03/2022 MAX ITEM UNICO PARA CASOS COM FATURA COM DIFERENTES ITENS UNICOS PARA MESMO CD_LANCAMENTO
                            Dbaps.Fnc_Ptu_Max_Item_Unico(Vcmf.Cd_Lote,
                                                         Vcmf.Cd_Conta_Medica,
                                                         Vcmf.Cd_Lancamento)
                         End Id_Itemunico,
                         
                         Case
                           When (Pro.Sn_Pacote = 'S' And
                                Pct.Cd_Item_Procedimento Is Not Null And
                                Pcv.Sn_Honorario = 'S' And
                                Pct.Sn_Principal = 'S') Or
                                (Pro.Sn_Pacote = 'S' And
                                Pct.Cd_Item_Procedimento Is Not Null And
                                Grp_Pacote.Tp_Gru_Pro = 'OP') Then
                            Pct.Cd_Item_Procedimento
                         --Customiza��o Unimed Sorocaba (Mois�s) DE-PARA PROCEDIMENTO PTU - UNIMED SOROCABA 
                           When (Nvl((Select 1
                                       From Dbaps.Tmp_De_Para_Procedimento_Ptu p
                                      Where p.De_Cd_Procedimento =
                                            Pro.Cd_Procedimento),
                                     0) > 0) Then
                            (Select p.Para_Cd_Procedimento
                               From Dbaps.Tmp_De_Para_Procedimento_Ptu p
                              Where p.De_Cd_Procedimento = Pro.Cd_Procedimento)
                         
                         -- TESTE US        
                         -- De-para Consulta M�dico da Fam�lia - Nais -> Fesp
                           When Vcmf.Cd_Unimed_Origem = '970' And
                                Vcmf.Cd_Procedimento = '10101047' Then
                            '10162020'
                         
                           Else
                            Pro.Cd_Procedimento
                         End Cd_Servico,
                         
                         Substr(Upper(Regexp_Replace(Trim(Case
                                                            When (Pro.Sn_Pacote = 'S' And
                                                                 Pct.Cd_Item_Procedimento Is Not Null And
                                                                 Pcv.Sn_Honorario = 'S' And
                                                                 Pct.Sn_Principal = 'S') Or
                                                                 (Pro.Sn_Pacote = 'S' And
                                                                 Pct.Cd_Item_Procedimento Is Not Null And
                                                                 Grp_Pacote.Tp_Gru_Pro = 'OP') Then
                                                             Proc_Pacote.Ds_Procedimento
                                                            Else
                                                             Nvl(Pro.Ds_Procedimento, 'PROCEDIMENTO') /* 14/03/22 - nao usamos VCMF.DS_PROCEDIMENTO pois prestador pode enviar errado */
                                                          End),
                                                     '[^[:alnum:] ]+')),
                                0,
                                79) Ds_Servico,
                         Nvl(Nvl(Vcmf.Qt_Cobrado_Intercambio, Vcmf.Qt_Pago),
                             1) Qt_Cobrada,
                         
                         /* HM */
                         Decode(Vcmf.Tp_Faturamento,
                                'HM',
                                Case
                                  When (Pro.Sn_Pacote = 'S' And
                                       Pct.Cd_Item_Procedimento Is Not Null And
                                       Pcv.Sn_Honorario = 'S' And
                                       Pct.Sn_Principal = 'S') Or
                                       (Pro.Sn_Pacote = 'S' And
                                       Pct.Cd_Item_Procedimento Is Not Null And
                                       Grp_Pacote.Tp_Gru_Pro = 'OP') Then
                                   Null
                                  Else
                                   Vcmf.Vl_Total_Cobrado
                                End,
                                Null) Vl_Serv_Cob,
                         Decode(Vcmf.Tp_Faturamento,
                                'HM',
                                Case
                                  When (Pro.Sn_Pacote = 'S' And
                                       Pct.Cd_Item_Procedimento Is Not Null And
                                       Pcv.Sn_Honorario = 'S' And
                                       Pct.Sn_Principal = 'S') Or
                                       (Pro.Sn_Pacote = 'S' And
                                       Pct.Cd_Item_Procedimento Is Not Null And
                                       Grp_Pacote.Tp_Gru_Pro = 'OP') Then
                                   Null
                                  Else
                                   Vcmf.Vl_Total_Taxa_Cobrado_Ptu
                                End,
                                Null) Vl_Adic_Ser,
                         /* FI */
                         Decode(Vcmf.Tp_Faturamento,
                                'FI',
                                Case
                                  When (Pro.Sn_Pacote = 'S' And
                                       Pct.Cd_Item_Procedimento Is Not Null And
                                       Pcv.Sn_Honorario = 'S' And
                                       Pct.Sn_Principal = 'S') Or
                                       (Pro.Sn_Pacote = 'S' And
                                       Pct.Cd_Item_Procedimento Is Not Null And
                                       Grp_Pacote.Tp_Gru_Pro = 'OP') Then
                                   Null
                                  Else
                                   Vcmf.Vl_Total_Cobrado
                                End,
                                Null) Vl_Filme_Cob,
                         Decode(Vcmf.Tp_Faturamento,
                                'FI',
                                Case
                                  When (Pro.Sn_Pacote = 'S' And
                                       Pct.Cd_Item_Procedimento Is Not Null And
                                       Pcv.Sn_Honorario = 'S' And
                                       Pct.Sn_Principal = 'S') Or
                                       (Pro.Sn_Pacote = 'S' And
                                       Pct.Cd_Item_Procedimento Is Not Null And
                                       Grp_Pacote.Tp_Gru_Pro = 'OP') Then
                                   Null
                                  Else
                                   Vcmf.Vl_Total_Taxa_Cobrado_Ptu
                                End,
                                Null) Vl_Adic_Filme,
                         /* CO */
                         Decode(Vcmf.Tp_Faturamento,
                                'CO',
                                Case
                                  When (Pro.Sn_Pacote = 'S' And
                                       Pct.Cd_Item_Procedimento Is Not Null And
                                       Pcv.Sn_Honorario = 'S' And
                                       Pct.Sn_Principal = 'S') Or
                                       (Pro.Sn_Pacote = 'S' And
                                       Pct.Cd_Item_Procedimento Is Not Null And
                                       Grp_Pacote.Tp_Gru_Pro = 'OP') Then
                                   Null
                                  Else
                                   Vcmf.Vl_Total_Cobrado
                                End,
                                Null) Vl_Co_Cob,
                         Decode(Vcmf.Tp_Faturamento,
                                'CO',
                                Case
                                  When (Pro.Sn_Pacote = 'S' And
                                       Pct.Cd_Item_Procedimento Is Not Null And
                                       Pcv.Sn_Honorario = 'S' And
                                       Pct.Sn_Principal = 'S') Or
                                       (Pro.Sn_Pacote = 'S' And
                                       Pct.Cd_Item_Procedimento Is Not Null And
                                       Grp_Pacote.Tp_Gru_Pro = 'OP') Then
                                   Null
                                  Else
                                   Vcmf.Vl_Total_Taxa_Cobrado_Ptu
                                End,
                                Null) Vl_Adic_Co
                
                  From Dbaps.v_Ctas_Medicas_Fatura Vcmf
                 Inner Join Dbaps.Prestador Pex
                    On Nvl(Vcmf.Cd_Prestador_Ptu, Vcmf.Cd_Prestador) =
                       Pex.Cd_Prestador
                 Inner Join Dbaps.Prestador Pexp
                    On Vcmf.Cd_Prestador_Principal = Pexp.Cd_Prestador
                  Left Join Dbaps.Ati_Med Am
                    On Vcmf.Cd_Atividade_Medica = Am.Cd_Ati_Med
                  Left Join Dbaps.Grau_Participacao Gp
                    On Am.Cd_Grau_Participacao = Gp.Cd_Grau_Participacao
                  Left Join Dbaps.Conselho_Profissional Cp
                    On Pex.Cd_Conselho_Profissional =
                       Cp.Cd_Conselho_Profissional
                  Left Join Dbaps.Procedimento Pro
                    On Dbaps.Fnc_Procedimento_Analise(Vcmf.Cd_Procedimento,
                                                      Vcmf.Cd_Prestador_Principal,
                                                      'C') =
                       Pro.Cd_Procedimento
                  Left Join Dbaps.Procedimento Pro_De
                    On Vcmf.Cd_Procedimento = Pro_De.Cd_Procedimento
                  Left Join Dbaps.Pacote Pct
                    On Pro.Cd_Procedimento = Pct.Cd_Procedimento
                  Left Join Dbaps.Procedimento Proc_Pacote
                    On Pct.Cd_Item_Procedimento = Proc_Pacote.Cd_Procedimento
                  Left Join Dbaps.Grupo_Procedimento Grp_Pacote
                    On Proc_Pacote.Cd_Grupo_Procedimento =
                       Grp_Pacote.Cd_Grupo_Procedimento
                  Left Join Dbaps.Grupo_Procedimento Grp
                    On Pro.Cd_Grupo_Procedimento = Grp.Cd_Grupo_Procedimento
                  Left Join Dbaps.Tecnica_Utilizada Tu
                    On Vcmf.Cd_Tecnica = Tu.Cd_Tiss
                  Left Join Dbaps.Mvs_Unidade_Medida Mum
                    On Vcmf.Cd_Unidade_Medida = Mum.Cd_Termo
                  Left Join Dbaps.Guia g
                    On Vcmf.Nr_Guia = g.Nr_Guia
                  Left Join Dbaps.Guia g_Tem
                    On Nvl(g.Nr_Guia_Tem, Vcmf.Nr_Guia_Tem) = g_Tem.Nr_Guia
                 Inner Join Dbaps.Tipo_Atendimento Ta
                    On Vcmf.Cd_Tipo_Atendimento = Ta.Cd_Tipo_Atendimento
                
                  Left Join Dbaps.Ptu_Mensagem Pm
                    On g.Cd_Ptu_Mensagem_Origem = Pm.Cd_Ptu_Mensagem
                  Left Join Dbaps.Via_Acesso Va
                    On Vcmf.Cd_Via_Acesso = Va.Cd_Tiss
                  Left Join Dbaps.Pacote_Vigencia Pcv
                    On Pct.Cd_Procedimento = Pcv.Cd_Procedimento
                   And Pcv.Dt_Inicio_Vigencia <= Vcmf.Dt_Realizado
                   And Nvl(Pcv.Dt_Fim_Vigencia, Sysdate) >= Vcmf.Dt_Realizado
                 Where 1 = 1
                
                ) Servico
         Where Servico.Cd_fatura = 40407
         Group By Id_Itemunico,
                  Ds_Servico,
                  Qt_Cobrada,
                  Cd_Pre_Req,
                  Cd_Servico,
                  Cd_Mens_Contrato,
                  Cd_Lote,
                  Cd_Conta_Medica,
                  Lancamento) a,
       
       (Select v.Cd_Mens_Contrato,
               v.Cd_Lote,
               v.Cd_Conta_Medica,
               v.Cd_Procedimento,
               Sum(v.Vl_Total_Adicional_Cobrado) As Valor_Contas,
               v.Cd_Lancamento As Lancamento
          From Dbaps.v_Ctas_Medicas_Fatura v
         Where v.Cd_fatura = 40407
         Group By v.Cd_Mens_Contrato,
                  v.Cd_Lote,
                  v.Cd_Conta_Medica,
                  v.Cd_Procedimento,
                  v.Cd_Lancamento) b

 Where a.Cd_Conta_Medica = b.Cd_Conta_Medica
   And a.Cd_Servico = b.Cd_Procedimento
   And a.Lancamento = b.Lancamento
   And a.Valor <> b.Valor_Contas;
/*
And a.cd_conta_medica = 10354190
And a.cd_servico = 00637602; 
*/

Select Sum(f.Vl_Total_Cobrado + f.Vl_Total_Taxa_Cobrado_Ptu)
  From v_Ctas_Medicas_Fatura f
 Where f.Cd_fatura = 40407
 --200487,1
 --200487,10  
 
 
 --445909,1

Select p.Vl_Tot_Doc_1
  From Dbaps.Ptu_A500_Cabecalho  p,
       Dbaps.Ptu_A500            a,
       Dbaps.Ptu_Remessa_Retorno Pr
 Where p.Cd_Ptu_A500 = a.Cd_Ptu_A500
   And Pr.Cd_Ptu_Remessa_Retorno = a.Cd_Ptu_Remessa_Retorno
   And f.Cd_fatura = 40407
          
          ---OLHAR SE TEM PROCEDIMENTOS NA CONTA  QUE N�O ENTRARAM NAS TABELAS DO XML.
          
            Select v.Cd_Lote,
                   v.Cd_Conta_Medica,
                   v.Cd_Procedimento,
                   v.Cd_Lancamento,
                   v.Id_Item_Unico,
                   v.Vl_Total_Cobrado
              From Dbaps.v_Ctas_Medicas_Fatura v
             Where v.Cd_fatura = 40407
               And v.Id_Item_Unico Not In
                   ( --sadt
                    Select Prc.Id_Item_Unico
                      From Dbaps.Ptu_A500_Cabecalho  p,
                            Dbaps.Ptu_A500            a,
                            Dbaps.Ptu_Remessa_Retorno Pr,
                            Dbaps.Ptu_A500_Sadt       s,
                            Dbaps.Ptu_A500_Proc       Prc
                     Where p.Cd_Ptu_A500 = a.Cd_Ptu_A500
                       And Pr.Cd_Ptu_Remessa_Retorno =
                           a.Cd_Ptu_Remessa_Retorno
                       And s.Cd_Ptu_A500 = a.Cd_Ptu_A500
                       And s.Cd_Ptu_A500_Sadt = Prc.Cd_Ptu_A500_Sadt
                       And PRC.ID_ITEM_UNICO = v.Id_Item_Unico
                    --And Pr.Cd_Ptu_Remessa_Retorno = 478698
                    
                    Union All
                    --internacao
                    Select Prc.Id_Item_Unico
                      From Dbaps.Ptu_A500_Cabecalho  p,
                            Dbaps.Ptu_A500            a,
                            Dbaps.Ptu_Remessa_Retorno Pr,
                            Dbaps.Ptu_A500_Internacao i,
                            Dbaps.Ptu_A500_Proc       Prc
                     Where p.Cd_Ptu_A500 = a.Cd_Ptu_A500
                       And Pr.Cd_Ptu_Remessa_Retorno =
                           a.Cd_Ptu_Remessa_Retorno
                       And i.Cd_Ptu_A500 = a.Cd_Ptu_A500
                       And i.Cd_Ptu_A500_Internacao =
                           Prc.Cd_Ptu_A500_Internacao
                             And PRC.ID_ITEM_UNICO = v.Id_Item_Unico
                    --And Pr.Cd_Ptu_Remessa_Retorno = 478698
                    
                    Union All ---Honorario
                    
                    Select Prc.Id_Item_Unico
                      From Dbaps.Ptu_A500_Cabecalho  p,
                            Dbaps.Ptu_A500            a,
                            Dbaps.Ptu_Remessa_Retorno Pr,
                            Dbaps.Ptu_A500_Honorario  h,
                            Dbaps.Ptu_A500_Proc       Prc
                     Where p.Cd_Ptu_A500 = a.Cd_Ptu_A500
                       And Pr.Cd_Ptu_Remessa_Retorno =
                           a.Cd_Ptu_Remessa_Retorno
                       And h.Cd_Ptu_A500 = a.Cd_Ptu_A500
                       And h.Cd_Ptu_A500_Honorario =
                           Prc.Cd_Ptu_A500_Honorario
                             And PRC.ID_ITEM_UNICO = v.Id_Item_Unico
                    -- And Pr.Cd_Ptu_Remessa_Retorno = 478698
                    
                    Union All -- Consulta
                    
                    Select c.Id_Item_Unico
                      From Dbaps.Ptu_A500_Cabecalho  p,
                            Dbaps.Ptu_A500            a,
                            Dbaps.Ptu_Remessa_Retorno Pr,
                            Dbaps.Ptu_A500_Consulta   c
                    
                     Where p.Cd_Ptu_A500 = a.Cd_Ptu_A500
                       And Pr.Cd_Ptu_Remessa_Retorno =
                           a.Cd_Ptu_Remessa_Retorno
                       And c.Cd_Ptu_A500 = a.Cd_Ptu_A500
                         And c.id_item_unico = v.Id_Item_Unico
                    -- And Pr.Cd_Ptu_Remessa_Retorno = 478698
                    )
            
              Select *
                      From Ptu_Remessa_Retorno p
                     Where p.Cd_Mens_Contrato = '2333412'
