

Update Mens_Contrato m
   Set m.Dt_Vencimento          = '01/01/2023',
       m.Dt_Vencimento_Original = '01/01/2023',
       m.Dt_Emissao             = '01/12/2022'
 Where m.Cd_Mens_Contrato In
       (2367029, 2367030, 2367169, 2367140, 2367204, 2367141, 2367037)
