Select Distinct f.Cd_Prestador_Principal,
                (Select 'S'
                   From Dbaps.Especialidade_Prestador Ep
                  Where Ep.Cd_Prestador = f.Cd_Prestador_Principal
                    And Ep.Sn_Principal = 'S'
                    And Rownum = 1) As Esp_Prestador_Principal,
                (Select 'S'
                   From Dbaps.Especialidade_Prestador Ep
                  Where Ep.Cd_Prestador = f.Cd_Prestador
                    And Ep.Sn_Principal = 'S'
                    
                    And Rownum = 1) As Esp_Prestador_Exec,
                
                (Select 'S'
                   From Dbaps.Especialidade_Prestador Ep
                  Where Ep.Cd_Prestador = f.cd_prestador_ptu
                    And Ep.Sn_Principal = 'S' 
                    And f.cd_prestador_ptu Is not Null
                    And Rownum = 1) As Esp_Prestador_ptu
  From Dbaps.v_Ctas_Medicas_Fatura f
 Where f.Cd_Fatura = 40407
