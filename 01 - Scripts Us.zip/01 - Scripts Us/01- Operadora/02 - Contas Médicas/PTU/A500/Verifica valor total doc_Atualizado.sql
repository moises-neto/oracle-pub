Select v.Cd_Lote, v.Cd_Conta_Medica, v.Cd_Procedimento, v.Cd_Lancamento
  From v_Ctas_Medicas_Fatura v
 Where v.Id_Item_Unico Not In
       (Select Id_Itemunico
        
          From (Select Distinct Vcmf.Cd_Mens_Contrato,
                                Vcmf.Id_Item_Unico Id_Itemunico
                  From Dbaps.v_Ctas_Medicas_Fatura Vcmf
                 Inner Join Dbaps.Prestador Pex
                    On Nvl(Vcmf.Cd_Prestador_Ptu, Vcmf.Cd_Prestador) =
                       Pex.Cd_Prestador
                 Inner Join Dbaps.Prestador Pexp
                    On Vcmf.Cd_Prestador_Principal = Pexp.Cd_Prestador
                  Left Join Dbaps.Ati_Med Am
                    On Vcmf.Cd_Atividade_Medica = Am.Cd_Ati_Med
                  Left Join Dbaps.Grau_Participacao Gp
                    On Am.Cd_Grau_Participacao = Gp.Cd_Grau_Participacao
                  Left Join Dbaps.Conselho_Profissional Cp
                    On Pex.Cd_Conselho_Profissional =
                       Cp.Cd_Conselho_Profissional
                  Left Join Dbaps.Procedimento Pro
                    On Dbaps.Fnc_Procedimento_Analise(Vcmf.Cd_Procedimento,
                                                      Vcmf.Cd_Prestador_Principal,
                                                      'C') =
                       Pro.Cd_Procedimento
                  Left Join Dbaps.Procedimento Pro_De
                    On Vcmf.Cd_Procedimento = Pro_De.Cd_Procedimento
                  Left Join Dbaps.Grupo_Procedimento Grp
                    On Pro.Cd_Grupo_Procedimento = Grp.Cd_Grupo_Procedimento
                  Left Join Dbaps.Tecnica_Utilizada Tu
                    On Vcmf.Cd_Tecnica = Tu.Cd_Tiss
                  Left Join Dbaps.Mvs_Unidade_Medida Mum
                    On Vcmf.Cd_Unidade_Medida = Mum.Cd_Termo
                  Left Join Dbaps.Guia g
                    On Vcmf.Nr_Guia = g.Nr_Guia
                  Left Join Dbaps.Guia g_Tem
                    On Nvl(g.Nr_Guia_Tem, Vcmf.Nr_Guia_Tem) = g_Tem.Nr_Guia
                 Inner Join Dbaps.Tipo_Atendimento Ta
                    On Vcmf.Cd_Tipo_Atendimento = Ta.Cd_Tipo_Atendimento
                  Left Join Dbaps.Ptu_Mensagem Pm
                    On g.Cd_Ptu_Mensagem_Origem = Pm.Cd_Ptu_Mensagem
                  Left Join Dbaps.Via_Acesso Va
                    On Vcmf.Cd_Via_Acesso = Va.Cd_Tiss
                -- And vcmf.Cd_Mens_Contrato = 2318797  
                ) Servico
        --2318459,2318797 e 2318797
         Where Servico.Cd_Mens_Contrato = 2430677)
   And v.Cd_Mens_Contrato = 2430677

--2318459,2318797 e 2318797
