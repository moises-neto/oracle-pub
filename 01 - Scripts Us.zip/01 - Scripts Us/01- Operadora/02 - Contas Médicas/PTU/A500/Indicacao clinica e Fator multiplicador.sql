/*
ID 463642 - LOTE 353313 CONTA 10001108 INDICA��O CLINICA INVESTIGACAO CARCINOMA BASOCELULAR;
ID 463643 - LOTE 350896 CONTA 9878384 FATOR MULTIPLICADOR 70%;
ID 463650 - LOTE 348520 CONTA 9773734 INDICA��O CLINICA PO DE MIOSEITE ENFECCIOSA EM QUADRIL.
*/
 --INDICA��O CLINICA
Select r505.*, rowid From dbaps.ptu_a500_r505 r505
where r505.cd_ptu_remessa_retorno = 463935
and r505.tp_reg_cpl = 1;

--nr fator multiplicador

select r504.*, rowid from dbaps.ptu_a500_r504 r504
where r504.cd_ptu_remessa_retorno = 463643
and r504.nr_nota =  9878384

 
