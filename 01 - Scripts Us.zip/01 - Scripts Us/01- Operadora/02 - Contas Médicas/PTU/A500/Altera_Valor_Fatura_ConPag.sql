DBAMV.TRG_CON_PAG_LANCA_FINANC

Select r.*, Rowid From repasse_prestador_intercambio r

where r.cd_fatura in(37223);    
  

                                         
Select (Select r.Cd_Fatura
          From Repasse_Prestador_Intercambio r
         Where r.Cd_Con_Pag = p.Cd_Con_Pag) As Fatura,
       (Select r.Vl_a_Pagar
          From Repasse_Prestador_Intercambio r
         Where r.Cd_Con_Pag = p.Cd_Con_Pag) As Valor_Correto,
       p.Vl_Bruto_Conta,
       p.Vl_Base_Irrf,
       p.Vl_Base_Inss,
       p.Vl_Desconto,
       p.Vl_Acrescimo,
       p.Vl_Moeda,
       p.Vl_Moeda_Desc,
       p.Vl_Moeda_Acres,
       p.Vl_Cambio,
       p.Vl_Aliq_Iva,
       p.Vl_Iva,
       p.Vl_Base_Iss,
       p.Vl_Desconto_Comercial,
       Rowid
  From Dbamv.Con_Pag p
 Where p.Cd_Con_Pag In (530245);

Select (Select r.Cd_Fatura
          From Repasse_Prestador_Intercambio r
         Where r.Cd_Con_Pag = It.Cd_Con_Pag) As Fatura,
       (Select r.Vl_a_Pagar
          From Repasse_Prestador_Intercambio r
         Where r.Cd_Con_Pag = it.Cd_Con_Pag) As Valor_Correto,
       It.*,
       Rowid
  From Dbamv.Itcon_Pag It
 Where It.Cd_Con_Pag In (530245);

Select (Select r.Cd_Fatura
          From Repasse_Prestador_Intercambio r
         Where r.Cd_Con_Pag = Rc.Cd_Con_Pag) As Fatura,
       (Select r.Vl_a_Pagar
          From Repasse_Prestador_Intercambio r
         Where r.Cd_Con_Pag = rc.Cd_Con_Pag) As Valor_Correto,
       Rc.*,
       Rowid
  From Dbamv.Ratcon_Pag Rc
 Where Rc.Cd_Con_Pag In (530245);
