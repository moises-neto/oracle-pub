sELECT ROWID, P.nr_cbo_exec
  fROM PTU_A500_R504 P
 WHERE P.CD_PTU_REMESSA_RETORNO = 452417
   AND P.NR_NOTA = '9509098'
   AND P.NR_SEQ = 9;

select (select a.nm_autorizador
          from autorizador a
         where a.cd_autorizador = c.cd_autorizador_tramite) as nome,
       c.*
  From tramite_protocolo_call_center c
 where c.cd_atend_call_center = 940773

--223605
