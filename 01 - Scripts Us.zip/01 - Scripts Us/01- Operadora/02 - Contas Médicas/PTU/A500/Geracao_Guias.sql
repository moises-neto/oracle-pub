--35569

--INTERNA��O
SELECT *
  FROM TABLE(DBAPS.PKG_PTU_BATCH_A500_XML.GET_TABLE_PTU_A500_RES_INT(Pcd_Mens_Contrato => 2283268,
                                                                     p_Id_Aviso => 'N',
                                                                     p_Cd_Lote => 367971,
                                                                     p_Cd_Conta_Medica => 116418
                                                                     ));

--SADT
SELECT *
  FROM TABLE(DBAPS.PKG_PTU_BATCH_A500_XML.GET_TABLE_PTU_A500_SADT(Pcd_Mens_Contrato   => 2282738,
                                                                  p_Id_Aviso        => 'N',
                                                                  p_Cd_Lote         => 368310,
                                                                  p_Cd_Conta_Medica => 10618739));
SELECT *
  FROM TABLE(DBAPS.PKG_PTU_BATCH_A500_XML.GET_TABLE_PTU_A500_SADT(Pcd_Mens_Contrato   => 2282738,
                                                                  p_Id_Aviso        => 'N',
                                                                  p_Cd_Lote         => NULL,
                                                                  p_Cd_Conta_Medica => NULL));                                                                  

--HONOR�RIO

SELECT *
  FROM TABLE(DBAPS.PKG_PTU_BATCH_A500_XML.GET_TABLE_PTU_A500_HONO(Pcd_Mens_Contrato   => 2279209,
                                                                  p_Id_Aviso        => 'N',
                                                                  p_Cd_Lote         => 368758,
                                                                  p_Cd_Conta_Medica => 116806));


--CONSULTA
SELECT *
  FROM TABLE(DBAPS.PKG_PTU_BATCH_A500_XML.GET_TABLE_PTU_A500_CONS(P_MENS_CONTRATO   => 2282738,
                                                                  P_ID_AVISO        => 'N',
                                                                  P_CD_LOTE         => NULL,
                                                                  P_CD_CONTA_MEDICA =>));
                                                                  
                                                                  
 
   Select distinct f.cd_mens_contrato,
                   f.cd_lote,
                   (select l.cd_tipo_atendimento
                      from dbaps.lote l
                     Where l.cd_lote = f.cd_lote) tp_lote,
                   f.cd_conta_medica
     From v_ctas_medicas_fatura f
    where f.cd_fatura = 35570
