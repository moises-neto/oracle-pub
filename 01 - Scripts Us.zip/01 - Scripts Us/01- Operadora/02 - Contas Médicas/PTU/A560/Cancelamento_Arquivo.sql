/*
CH2112-1323 - CANCELAMENTO - NC1_1734089.052 - UNIMED BARRA MANSA
cancelar o arquivo NC1_1734089.052, 
Unimed origem solicitou cancelamento
ap�s a importa��o do arquivo em sistema.
*/

/*TAB=ARQUIVOS*/
Select Pr.Cd_Fatura, Pr.Cd_Mens_Contrato, Pr.*, rowid
  From Dbaps.Ptu_Remessa_Retorno Pr
 Where pr.cd_ptu_remessa_retorno in (455234,455282)

/*TAB=CANCELAMENTO ARQUIVO*/
Select pr.tp_status, pr.cd_usuario_cancelamento, pr.ds_motivo_cancelamento, pr.*, Rowid From dbaps.ptu_remessa_retorno pr
Where -- pr.cd_mens_contrato = 2257160
--Or 
pr.ds_arquivo like '%1741162%';

Select pi.dt_cancelamento, pi.*, Rowid
  From dbaps.ptu_controle_intercambio pi
 Where pi.cd_ptu_remessa_retorno in (455282, 455234);
    

/*TAB=CONTESTACAO CONTA*/
Select Cm.*, Rowid
  From Dbaps.Conta_Medica_Contestacao Cm
 Where Exists (Select 1
          From Dbaps.v_Ctas_Medicas_Fatura Vf
         Where Vf.Cd_Mens_Contrato = 2193688
           And Cm.Cd_Conta_Medica = Vf.Cd_Conta_Medica
           And Cm.Cd_Lote = Vf.Cd_Lote)
 Order By Cm.Cd_Conta_Medica, Cm.Cd_Lancamento; 
 
 
 select p.ds_arquivo From dbaps.ptu_remessa_retorno p
 where p.cd_ptu_remessa_retorno = 463685
