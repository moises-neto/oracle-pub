Select Pc.Cd_Protocolo_Ctamed, Pc.Nr_Lote_Prestador, Tm.*
  From Dbaps.Tiss_Lot_Guia t, Protocolo_Ctamed Pc, Tiss_Mensagem Tm
 Where t.Id = Pc.Id_Tisslotguia
   And t.Id_Pai = Tm.Id
  -- And tm.id = 202339266   
   And Pc.Cd_Protocolo_Ctamed In (502127);


Select Rowid, tt.ds_msg_erro, tt.* From dbaps.tiss_mensagem tt
Where tt.id = 202339266;

Select * From dbaps.mv_tiss mv
Where mv.nr_protocolo in(502128);


Select Rowid, PC.* From DBAPS.PROTOCOLO_CTAMED PC
Where PC.CD_PROTOCOLO_CTAMED = 498630


Select * From DBAPS.TISS_PROT_RECEB t
Where t.nr_lote In ('01469','1473')
--1473
