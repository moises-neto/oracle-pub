/*

--- 
Create Table backup_PROCED_PATOLOGIA

As Select * From dbaps.proced_patologia;

*/
 ---APENAS INSERINDO NA Dbaps.Proced_Patologia (N�O VAI TRAVAR NADA!!!)
Declare
  Cursor Cdadospatologia Is
    Select Distinct p.Cd_Patologia --, p.cd_procedimento
      From Dbaps.Proced_Patologia p
     Where 1 = 1
       And Not Exists
     (Select 1
              From Proced_Patologia Pp
             Where Pp.Cd_Patologia = p.Cd_Patologia
               And Pp.Cd_Procedimento In (30309997,
                                          30909992,
                                          31099991,
                                          31099990,
                                          31099998,
                                          31009991,
                                          31109990,
                                          40709990,
                                          40709997,
                                          40709998,
                                          40808204,
                                          40808200,
                                          40808205,
                                          40808207,
                                          40819991))
     Order By 1;
  --14235
  -- And p.Cd_Patologia Not In (3, 4);
  -- And p.cd_procedimento = 30309997;

  Cursor Cprocinsert Is
  
    Select Proc.Cd_Procedimento
      From Dbaps.Procedimento Proc
     Where Proc.Cd_Procedimento In (30309997,
                                    30909992,
                                    31099991,
                                    31099990,
                                    31099998,
                                    31009991,
                                    31109990,
                                    40709990,
                                    40709997,
                                    40709998,
                                    40808204,
                                    40808200,
                                    40808205,
                                    40808207,
                                    40819991);

  v_Contador Pls_Integer := 0;

Begin

  For i In Cdadospatologia Loop
    v_Contador := v_Contador + 1;
    Begin
      For j In Cprocinsert Loop
        Begin
          Insert Into Dbaps.Proced_Patologia
            (Cd_Patologia, Cd_Procedimento)
          Values
            (i.Cd_Patologia, j.Cd_Procedimento);
        Exception
          When Dup_Val_On_Index Then
            Null;
          When Others Then
            Raise_Application_Error(-20001,
                                    'Falha n�o tratada! ' || Sqlerrm);
            Rollback;
          
        End;
      
      End Loop;
    
    End;
  
    If (v_Contador >= 10) Then
      v_Contador := 0;
      Commit;
    End If;
  
  End Loop;

  Commit;

Exception
  When Dup_Val_On_Index Then
    Null;
  When Others Then
    Raise_Application_Error(-20001, 'Falha n�o tratada! ' || Sqlerrm);
    Rollback;
  
End;
