 SELECT  Count(*), ins.CD_PRESTADOR, ins.CD_PROCED_PREST, ins.TP_VALOR 
                   fROM Custom.temp_proced_prestador_INS ins
                   Group by ins.CD_PRESTADOR, ins.CD_PROCED_PREST, ins.TP_VALOR 
                   Having Count(*) >1; 
                   
 SELECT * fROM Custom.temp_proced_prestador_INS INS
  WHERE INS.CD_PROCEDIMENTO NOT IN 
  (SELECT 1 FROM DBAPS.PROCEDIMENTO P WHERE P.CD_PROCEDIMENTO =INS.CD_PROCEDIMENTO)
                 
                                 

Declare

  Cursor cDadosInsert is
      SELECT  INS.*  fROM Custom.temp_proced_prestador_INS ins         
   Where Not Exists (Select 1 From dbaps.proced_prestador p 
                    where p.cd_proced_prest = INS.CD_PROCED_PREST
                    AND P.TP_VALOR = INS.TP_VALOR);

  Cursor cDadosDelete is
                 
    Select *
      From custom.temp_proced_prestador_DEL del
     Where Exists
     (Select 1
              From dbaps.proced_prestador p
             where P.CD_PROCED_PREST = del.cd_proced_prest
               and p.tp_valor = del.tp_valor
               And p.CD_PROCED_PRESTADOR = del.CD_PROCED_PRESTADOR);
    
Begin
    --  DBAPS.CNT_PROCED_PRESTADOR_1_UK
  /*For i in cDadosDelete Loop
    Begin 
      Delete dbaps.proced_prestador p  Where P.CD_PROCED_PREST = i.cd_proced_prest
                                       And p.tp_valor = i.tp_valor
                                       And p.CD_PROCED_PRESTADOR = i.CD_PROCED_PRESTADOR;
    
    Exception When Others Then
      Raise_Application_Error(-20001, 'Falha');
      Rollback;
      End;
  End Loop; */
  

    For i in cDadosInsert Loop
    Begin 
      Insert Into dbaps.proced_prestador(cd_prestador,
                                         cd_proced_prest,
                                         ds_proced_prest,
                                         cd_procedimento,
                                         cd_proced_prestador,
                                         cd_usuario_inclusao,
                                         dt_inclusao,
                                         tp_valor,
                                         sn_migrado_unicoo)
                                         
      Values(NULL, 
             i.cd_proced_prest,
             I.ds_proced_prest,
             i.cd_procedimento,
             dbaps.seq_proced_prestador.nextval,
             i.cd_usuario_inclusao,
             i.dt_inclusao,
             i.tp_valor,
             NULL);
      
    /*Exception 
      When Others Then
      Raise_Application_Error(-20001, 'Falha');
      Rollback;*/
      End;
  End Loop;
  
End;
