Create table custom.tabela_1037_rol(
PROCEDIMENTO VARCHAR2(12),
CD_TABELA NUMBER(5),
VIGENCIA DATE,
VALOR_ANTERIOR_HM  NUMBER,
VALOR_ANTERIOR_CO NUMBER,
VALOR_NOVO_HM NUMBER,
VALOR_NOVO_CO NUMBER

)


--SELECT ROWID, T.* FROM CUSTOM.TABELA_1037_ROL T

SELECT ROWID, TT.* FROM CUSTOM.TABELA_1036_ROL TT

-- FAZENDO BACKUP
SELECT *
  fROM DBAPS.VALOR_REF_PROC V
 WHERE EXISTS (SELECT 1
          FROM CUSTOM.TABELA_1036_ROL T
         WHERE T.PROCEDIMENTO = V.CD_PROCEDIMENTO
           AND T.CD_TABELA = V.CD_TABELA
           AND T.VIGENCIA = V.DT_VIGENCIA)

DECLARE
  CURSOR cDadosRol is
    SELECT VROL.PROCEDIMENTO,
           VROL.CD_TABELA,
           VROL.VIGENCIA,
           VROL.VALOR_NOVO_CO,
           VROL.VALOR_NOVO_HM,
           VROL.VALOR_ANTERIOR_HM,
           VROL.VALOR_ANTERIOR_CO
      FROM CUSTOM.TABELA_1037_ROL VROL;

BEGIN

  For i in cDadosRol Loop
    Begin
      Update DBAPS.VALOR_REF_PROC V
         set v.vl_referencia = i.VALOR_ANTERIOR_HM, v.vl_uco = i.VALOR_ANTERIOR_CO
       Where v.cd_procedimento = i.procedimento
         and v.cd_tabela = i.cd_tabela
         and v.dt_vigencia = i.vigencia;
      Dbms_Output.put_line('Procedimento Alterado: ' || i.procedimento ||
                           ' Valor Novo HM ' || i.VALOR_NOVO_HM ||
                           ' Valor Novo CO ' || i.VALOR_NOVO_CO);
    End;
    End loop;
END;
           
           
