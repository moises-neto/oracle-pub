/*
DELETE FROM  tmp_procedimento_uni_med_tnumm;

CREATE TABLE tmp_procedimento_uni_med_tnumm AS
SELECT * FROM  DBAPS.procedimento_uni_med_tnumm pr
WHERE pr.cd_procedimento = 0;
*/

--SELECT * FROM  DBAPS.procedimento_uni_med_tnumm pr;

-- total
Select Count(*) From Tmp_Procedimento_Uni_Med_Tnumm t;

-- j� existe - n�o importar
Select Count(*)
  From Procedimento_Uni_Med_Tnumm p, Tmp_Procedimento_Uni_Med_Tnumm t
 Where t.Cd_Procedimento = p.Cd_Procedimento
   And t.Cd_Termo = p.Cd_Termo
   And t.Dt_Inicio_Vigencia_Arquivo = p.Dt_Inicio_Vigencia_Arquivo;

Select t.Cd_Procedimento,
       t.Cd_Termo,
       (Select Un.Cd_Termo
          From Dbaps.Mvs_Unidade_Medida Un
         Where Upper(Un.Ds_Termo) = Upper(t.Cd_Termo)) Cd_Termo,
       t.Cd_Usu_Inclusao_Manual,
       t.Cd_Usuario_Alteracao,
       t.Cd_Usuario_Inclusao,
       t.Dt_Inclusao_Manual,
       t.Dt_Inicio_Vigencia_Arquivo,
       t.Dt_Usuario_Alteracao,
       t.Dt_Usuario_Inclusao
  From Tmp_Procedimento_Uni_Med_Tnumm t;

/*BEGIN
DBAMV.PKG_MV2000.ATRIBUI_EMPRESA('1');
END;
/*/

Declare
Begin

  For Ix In (Select t.Cd_Procedimento,
                    (Select Un.Cd_Termo
                       From Dbaps.Mvs_Unidade_Medida Un
                      Where Upper(Un.Ds_Termo) = Upper(t.Cd_Termo)) Cd_Termo,
                    t.Cd_Usu_Inclusao_Manual,
                    t.Cd_Usuario_Alteracao,
                    t.Cd_Usuario_Inclusao,
                    t.Dt_Inclusao_Manual,
                    t.Dt_Inicio_Vigencia_Arquivo,
                    t.Dt_Usuario_Alteracao,
                    t.Dt_Usuario_Inclusao
               From Tmp_Procedimento_Uni_Med_Tnumm t;) Loop
  
    Begin
    
      Insert Into Dbaps.Procedimento_Uni_Med_Tnumm Pr
      Values
        (Ix.Cd_Procedimento,
         Ix.Cd_Termo,
         Ix.Cd_Usuario_Inclusao,
         Ix.Dt_Usuario_Inclusao,
         Ix.Cd_Usuario_Alteracao,
         Ix.Dt_Usuario_Alteracao,
         Ix.Dt_Inicio_Vigencia_Arquivo,
         Ix.Cd_Usu_Inclusao_Manual,
         Ix.Dt_Inclusao_Manual);
    
    Exception
      When Others Then
        Rollback;
        Raise_Application_Error(-20002,
                                'Falha: ' || Sqlerrm || 'Procedimento: ' ||
                                Ix.Cd_Procedimento || ' Termo: ' ||
                                Ix.Cd_Termo || ' Vig�ncia: ' ||
                                Ix.Dt_Inicio_Vigencia_Arquivo);
    End;
  End Loop;

Exception
  When Others Then
    Rollback;
    Raise_Application_Error(-20001, 'Falha: ' || Sqlerrm);
End;

/
-- total
  Select Count(*) From Tmp_Procedimento_Uni_Med_Tnumm t;

-- j� existe - n�o importar
Select Count(*)
  From Procedimento_Uni_Med_Tnumm p, Tmp_Procedimento_Uni_Med_Tnumm t
 Where t.Cd_Procedimento = p.Cd_Procedimento
   And t.Cd_Termo = p.Cd_Termo
   And t.Dt_Inicio_Vigencia_Arquivo = p.Dt_Inicio_Vigencia_Arquivo;
