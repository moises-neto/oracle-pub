
 truncate table temp_procedimento_inativar;

/*
create table temp_procedimento_inativar as
select p.cd_procedimento, p.dt_inativacao, p.ds_motivo_ativo_inativo from procedimento p
where p.cd_procedimento = 0;
*/

select count(*) from temp_procedimento_inativar t;

select t.* from temp_procedimento_inativar t
where t.dt_inativacao = '01/12/2021';

select count(*) from procedimento p
where p.cd_procedimento in (select t.cd_procedimento from temp_procedimento_inativar t);


select p.cd_procedimento, p.dt_inativacao, p.ds_motivo_ativo_inativo from procedimento p
where p.cd_procedimento in (select t.cd_procedimento from temp_procedimento_inativar t);


select count(*) from temp_procedimento_inativar t
where not exists 
(select 1  from procedimento p
where p.cd_procedimento = t.cd_procedimento);

--qtde total inativacao

select count(*) from temp_procedimento_inativar t
where exists 
(select 1  from procedimento p
where p.cd_procedimento = t.cd_procedimento
and p.dt_inativacao is null)
and t.dt_inativacao = '01/12/2021';

/*TAB=procedimento_nao_encontrado*/
select t.* from temp_procedimento_inativar t
where not exists 
(select 1  from procedimento p
where p.cd_procedimento = t.cd_procedimento);



 Call Custom.Prc_Inativa_Procedimento();
 
 select p.dt_inativacao From procedimento p
 where p.cd_procedimento in(80088937,80088945,80088953)



/

select p.cd_procedimento, p.dt_inativacao, p.ds_motivo_ativo_inativo, p.* from procedimento p
where p.cd_procedimento in (select t.cd_procedimento from temp_procedimento_inativar t);


