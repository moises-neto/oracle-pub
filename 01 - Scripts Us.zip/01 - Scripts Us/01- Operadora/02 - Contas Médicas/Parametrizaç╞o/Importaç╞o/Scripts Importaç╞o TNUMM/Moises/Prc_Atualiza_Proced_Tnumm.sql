Create Or Replace Procedure Custom.Prc_Atualiza_Proced_Tnumm Is

  Vcontador Pls_Integer;
Begin
  For i In (Select t.Cd_Procedimento,
                   t.Cd_Grupo_Procedimento,
                   Substr(t.Ds_Procedimento, 0, 500) As Ds_Procedimento,
                   t.Ds_Unidade,
                   t.Dt_Inativacao,
                   t.Ds_Procedimento_Completa,
                   t.Tp_Tabela,
                   t.Nr_Anvisa,
                   t.Sn_Alto_Custo,
                   t.Sn_Restrito_Hospitalar,
                   t.Sn_Generico,
                   t.Tp_Codificacao,
                   t.Dt_Inicio_Vigencia,
                   t.Dt_Fim_Implantacao,
                   t.Ds_Produto,
                   t.Ds_Especialidade,
                   t.Ds_Classe,
                   t.Ds_Princ_Ativo,
                   t.Ds_Gru_Farma,
                   t.Ds_Cla_Farma,
                   t.Ds_For_Farma,
                   t.Ds_Det_Reg_Anvisa,
                   t.Nr_Cnpj
              From Temp_Procedimento_Atualizar t
             Where Not Exists
             (Select 1
                      From Log_Procedimento_Atualiza l
                     Where l.Cd_Procedimento = t.Cd_Procedimento
                       )
                       ) Loop
    Vcontador := Vcontador + 1;
    Insert Into Custom.Log_Procedimento_Atualiza
      (Cd_Log, Cd_Procedimento, Dt_Log)
    Values
      (Seq_Log_Procedimento_Atualiza.Nextval, i.Cd_Procedimento, Sysdate);
  
    Begin
      Update Dbaps.Procedimento p
         Set p.Cd_Procedimento          = i.Cd_Procedimento,
             p.Cd_Grupo_Procedimento    = i.Cd_Grupo_Procedimento,
             p.Ds_Procedimento          = i.Ds_Procedimento,
             p.Ds_Unidade               = i.Ds_Unidade,
             p.Dt_Inativacao            = i.Dt_Inativacao,
             p.Ds_Procedimento_Completa = i.Ds_Procedimento_Completa,
             p.Tp_Tabela                = i.Tp_Tabela,
             p.Nr_Anvisa                = i.Nr_Anvisa,
             p.Sn_Alto_Custo            = i.Sn_Alto_Custo,
             p.Sn_Restrito_Hospitalar   = i.Sn_Restrito_Hospitalar,
             p.Sn_Generico              = i.Sn_Generico,
             p.Tp_Codificacao           = i.Tp_Codificacao,
             p.Dt_Inicio_Vigencia       = i.Dt_Inicio_Vigencia,
             p.Dt_Fim_Implantacao       = i.Dt_Fim_Implantacao,
             p.Ds_Produto               = i.Ds_Produto,
             p.Ds_Especialidade         = i.Ds_Especialidade,
             p.Ds_Classe                = i.Ds_Classe,
             p.Ds_Princ_Ativo           = i.Ds_Princ_Ativo,
             p.Ds_Gru_Farma             = i.Ds_Gru_Farma,
             p.Ds_Cla_Farma             = i.Ds_Cla_Farma,
             p.Ds_For_Farma             = i.Ds_For_Farma,
             p.Ds_Det_Reg_Anvisa        = i.Ds_Det_Reg_Anvisa,
             p.Nr_Cnpj                  = i.Nr_Cnpj
      
       Where p.Cd_Procedimento = i.Cd_Procedimento;
    End;
  
    If (Vcontador >= 10) Then
    
      Commit;
      Vcontador := 0;
    End If;
  
  End Loop;

End;
/
