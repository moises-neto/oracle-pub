--truncate table dbaps.temp_procedimento;

/*TAB=JA_EXISTE*/

select count(*)
          from dbaps.temp_procedimento t
          
select *
  from dbaps.procedimento p
 where exists (select 1
          from dbaps.temp_procedimento t
         where p.cd_procedimento = t.cd_procedimento);
         
         
/*TAB=N�O_EXISTE*/
select count(*)
  from dbaps.temp_procedimento t
 where not exists (select 1
          from dbaps.procedimento p
         where p.cd_procedimento = t.cd_procedimento);

select *
  from dbaps.temp_procedimento t
 where not exists (select 1
          from dbaps.procedimento p
         where p.cd_procedimento = t.cd_procedimento);



Call CUSTOM.Prc_Importa_Procedimento();

  select *
    from dbaps.temp_procedimento t
   where not exists (select 1
            from dbaps.procedimento p
           where p.cd_procedimento = t.cd_procedimento);


select count(*)
  from dbaps.procedimento p
 where exists (select 1
          from dbaps.temp_procedimento t
         where p.cd_procedimento = t.cd_procedimento);
