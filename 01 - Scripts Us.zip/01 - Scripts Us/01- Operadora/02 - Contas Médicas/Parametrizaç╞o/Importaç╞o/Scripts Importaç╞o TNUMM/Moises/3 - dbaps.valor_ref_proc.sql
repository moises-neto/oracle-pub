/*
-- 2145726
select dbaps.seq_valor_ref_proc.nextval from dual;
-- 2145725
select max(d.cd_valor_ref_proc)  from dbaps.valor_ref_proc d;
*/

--delete from temp_valor_ref_proc;

/*create table temp_valor_ref_proc as
select * from dbaps.valor_ref_proc v
where v.cd_tabela = 0
and v.cd_procedimento = 0
;
*/

select count(*)
  from temp_valor_ref_proc t;
  
--select vf.*, rowid from temp_valor_ref_proc vf;


-- valor_ref_proc - N�O INCLU�DOS - Procedimento n�o cadastrado
select t.*
  from temp_valor_ref_proc t
 where not exists (select 1
          from dbaps.procedimento pr
         where pr.cd_procedimento = t.cd_procedimento);


-- incluir
select count(*)
  from temp_valor_ref_proc t
 where not exists (select 1
          from dbaps.valor_ref_proc v
         where v.cd_tabela = t.cd_tabela
           and v.cd_procedimento = t.cd_procedimento)
  and exists (select 1
          from dbaps.procedimento pr
         where pr.cd_procedimento = t.cd_procedimento);

-- n�o incluir
select count(*)
  from temp_valor_ref_proc t
 where exists (select 1
          from dbaps.valor_ref_proc v
         where v.cd_tabela = t.cd_tabela
           and v.cd_procedimento = t.cd_procedimento);

-- inclu�dos
select count(*)
  from temp_valor_ref_proc t, dbaps.valor_ref_proc v
 where t.cd_tabela = v.cd_tabela
   and t.cd_procedimento = v.cd_procedimento
   and trunc(t.dt_vigencia) = trunc(v.dt_vigencia);


select *
  from dbaps.valor_ref_proc v
 where v.cd_tabela = 15
   and v.cd_procedimento = 90038630;

select *
  from dbaps.valor_ref_proc v
 where v.cd_tabela = 16
   and v.cd_procedimento = 00719463;

--dbaps.seq_valor_ref_proc

/*BEGIN
DBAMV.PKG_MV2000.ATRIBUI_EMPRESA('1');
END;
/*/


CALL CUSTOM.Prc_Importa_valor_ref_proc();

-- incluir
select count(*)
  from temp_valor_ref_proc t
 where not exists (select 1
          from dbaps.valor_ref_proc v
         where v.cd_tabela = t.cd_tabela
           and v.cd_procedimento = t.cd_procedimento)
  and exists (select 1
          from dbaps.procedimento pr
         where pr.cd_procedimento = t.cd_procedimento);

-- n�o incluir
select count(*)
  from temp_valor_ref_proc t
 where exists (select 1
          from dbaps.valor_ref_proc v
         where v.cd_tabela = t.cd_tabela
           and v.cd_procedimento = t.cd_procedimento);

-- inclu�dos
select count(*)
  from temp_valor_ref_proc t, dbaps.valor_ref_proc v
 where t.cd_tabela = v.cd_tabela
   and t.cd_procedimento = v.cd_procedimento
   and trunc(t.dt_vigencia) = trunc(v.dt_vigencia);


select *
  from dbaps.valor_ref_proc v
 where v.cd_tabela = 15
   and v.cd_procedimento = 90038630
;

select *
  from dbaps.valor_ref_proc v
 where v.cd_tabela = 16
   and v.cd_procedimento = 00719463
;
