-- delete from temp_prcd_unidade_medida t;


--select * from DBAPS.procedimento_unidade_medida T;
--select t.* from temp_prcd_unidade_medida t;

select * From dbaps.procedimento_unidade_medida m
where m.cd_termo in ('COM', 'SACHE', 'ML')

select count(*) from temp_prcd_unidade_medida t;

select t.*, rowid  from temp_prcd_unidade_medida t;

/*TAB=N�O INCLUIR*/
select count(*)
  from temp_prcd_unidade_medida t
 where not exists (select 1
          from dbaps.procedimento pr
         where pr.cd_procedimento = t.cd_procedimento);

/*TAB=ja incluidos*/
select count(*)
  from dbaps.procedimento_unidade_medida pu, temp_prcd_unidade_medida t
 where trunc(pu.dt_inicio_vigencia) = trunc(t.dt_inicio_vigencia)
   and t.cd_procedimento = pu.cd_procedimento;

select count(*) from temp_prcd_unidade_medida t;

/*TAB=ver incluidos*/
select pu.*
  from dbaps.procedimento_unidade_medida pu
 where trunc(pu.dt_inicio_vigencia) = '01/04/2021'
   and exists (select 1
          from temp_prcd_unidade_medida t
         where t.cd_procedimento = pu.cd_procedimento);

/*TAB=qtd sera incluida*/
select count(*)
  from temp_prcd_unidade_medida t
 where not exists
 (select 1
          from dbaps.procedimento_unidade_medida pu
         where pu.cd_procedimento = t.cd_procedimento
           and pu.cd_termo = t.cd_termo
           and pu.dt_inicio_vigencia = t.dt_inicio_vigencia);

/*TAB=INCLUIR*/
select t.*
  from temp_prcd_unidade_medida t
 where not exists (select 1
          from dbaps.procedimento_unidade_medida pu
         where pu.cd_procedimento = t.cd_procedimento
           and pu.cd_termo = t.cd_termo
           and pu.dt_inicio_vigencia = t.dt_inicio_vigencia)
   and exists (select 1
          from dbaps.procedimento pr
         where pr.cd_procedimento = t.cd_procedimento);
         DBAPS.CNT_PROCEDIMENTO_UNID_MED_2_FK
/*BEGIN
DBAMV.PKG_MV2000.ATRIBUI_EMPRESA('1');
END;
/*/

Call CUSTOM.Prc_importa_proc_unid_medida();

select * From procedimento p 
where p.cd_procedimento = 90344545

/

/*TAB=DEPOIS*/
select count(*) from temp_prcd_unidade_medida t;

/*TAB=N�O INCLUIR*/
select count(*)
  from temp_prcd_unidade_medida t
 where not exists (select 1
          from dbaps.procedimento pr
         where pr.cd_procedimento = t.cd_procedimento);

/*TAB=ja inclu�dos*/
select count(*)
  from dbaps.procedimento_unidade_medida pu, temp_prcd_unidade_medida t
 where trunc(pu.dt_inicio_vigencia) = trunc(t.dt_inicio_vigencia)
   and t.cd_procedimento = pu.cd_procedimento;

select count(*) from temp_prcd_unidade_medida t;

/*TAB=ver incluidos*/
select pu.*
  from dbaps.procedimento_unidade_medida pu
 where trunc(pu.dt_inicio_vigencia) = '01/04/2021'
   and exists (select 1
          from temp_prcd_unidade_medida t
         where t.cd_procedimento = pu.cd_procedimento);

/*TAB=qtd sera incluida*/
select count(*)
  from temp_prcd_unidade_medida t
 where not exists
 (select 1
          from dbaps.procedimento_unidade_medida pu
         where pu.cd_procedimento = t.cd_procedimento
           and pu.cd_termo = t.cd_termo
           and pu.dt_inicio_vigencia = t.dt_inicio_vigencia);

/*TAB=INCLUIR*/
select t.*
  from temp_prcd_unidade_medida t
 where not exists (select 1
          from dbaps.procedimento_unidade_medida pu
         where pu.cd_procedimento = t.cd_procedimento
           and pu.cd_termo = t.cd_termo
           and pu.dt_inicio_vigencia = t.dt_inicio_vigencia)
   and exists (select 1
          from dbaps.procedimento pr
         where pr.cd_procedimento = t.cd_procedimento);
