/*
DELETE FROM  tmp_procedimento_uni_med_tnumm;

CREATE TABLE tmp_procedimento_uni_med_tnumm AS
SELECT * FROM  DBAPS.procedimento_uni_med_tnumm pr
WHERE pr.cd_procedimento = 0;
*/

SELECT * FROM  DBAPS.procedimento_uni_med_tnumm pr;

   Select * from Tmp_Procedimento_Uni_Med_Tnumm t
   where t.cd_procedimento = 90284232 ;
-- total
Select Count(*) From Tmp_Procedimento_Uni_Med_Tnumm t;

-- j� existe - n�o importar
Select Count(*)
  From Procedimento_Uni_Med_Tnumm p, Tmp_Procedimento_Uni_Med_Tnumm t
 Where t.Cd_Procedimento = p.Cd_Procedimento
   And t.Cd_Termo = p.Cd_Termo
   And t.Dt_Inicio_Vigencia_Arquivo = p.Dt_Inicio_Vigencia_Arquivo;

Select t.Cd_Procedimento,
       t.Cd_Termo,
       (Select Un.Cd_Termo
          From Dbaps.Mvs_Unidade_Medida Un
         Where Upper(Un.Ds_Termo) = Upper(t.Cd_Termo)) Cd_Termo,
       t.Cd_Usu_Inclusao_Manual,
       t.Cd_Usuario_Alteracao,
       t.Cd_Usuario_Inclusao,
       t.Dt_Inclusao_Manual,
       t.Dt_Inicio_Vigencia_Arquivo,
       t.Dt_Usuario_Alteracao,
       t.Dt_Usuario_Inclusao
  From Tmp_Procedimento_Uni_Med_Tnumm t;

/*BEGIN
DBAMV.PKG_MV2000.ATRIBUI_EMPRESA('1');
END;
/*/


 Call Custom.Prc_Imp_Proc_unid_med_Tnumm();


-- total
  Select Count(*) From Tmp_Procedimento_Uni_Med_Tnumm t;

-- j� existe - n�o importar
Select Count(*)
  From Procedimento_Uni_Med_Tnumm p, Tmp_Procedimento_Uni_Med_Tnumm t
 Where t.Cd_Procedimento = p.Cd_Procedimento
   And t.Cd_Termo = p.Cd_Termo
   And t.Dt_Inicio_Vigencia_Arquivo = p.Dt_Inicio_Vigencia_Arquivo;
