-- delete from temp_prcd_unidade_medida t;


--select * from DBAPS.procedimento_unidade_medida T;
--select t.* from temp_prcd_unidade_medida t;

select count(*) from temp_prcd_unidade_medida t;

/*TAB=N�O INCLUIR*/
select count(*)
  from temp_prcd_unidade_medida t
 where not exists (select 1
          from dbaps.procedimento pr
         where pr.cd_procedimento = t.cd_procedimento);

/*TAB=ja incluidos*/
select count(*)
  from dbaps.procedimento_unidade_medida pu, temp_prcd_unidade_medida t
 where trunc(pu.dt_inicio_vigencia) = trunc(t.dt_inicio_vigencia)
   and t.cd_procedimento = pu.cd_procedimento;

select count(*) from temp_prcd_unidade_medida t;

/*TAB=ver incluidos*/
select pu.*
  from dbaps.procedimento_unidade_medida pu
 where trunc(pu.dt_inicio_vigencia) = '01/04/2021'
   and exists (select 1
          from temp_prcd_unidade_medida t
         where t.cd_procedimento = pu.cd_procedimento);

/*TAB=qtd sera incluida*/
select count(*)
  from temp_prcd_unidade_medida t
 where not exists
 (select 1
          from dbaps.procedimento_unidade_medida pu
         where pu.cd_procedimento = t.cd_procedimento
           and pu.cd_termo = t.cd_termo
           and pu.dt_inicio_vigencia = t.dt_inicio_vigencia);

/*TAB=INCLUIR*/
select t.*
  from temp_prcd_unidade_medida t
 where not exists (select 1
          from dbaps.procedimento_unidade_medida pu
         where pu.cd_procedimento = t.cd_procedimento
           and pu.cd_termo = t.cd_termo
           and pu.dt_inicio_vigencia = t.dt_inicio_vigencia)
   and exists (select 1
          from dbaps.procedimento pr
         where pr.cd_procedimento = t.cd_procedimento);

/*BEGIN
DBAMV.PKG_MV2000.ATRIBUI_EMPRESA('1');
END;
/*/

Declare
Begin

  For Ix In (select t.cd_procedimento,
                    t.cd_termo,
                    t.dt_inicio_vigencia,
                    t.dt_fim_vigencia,
                    t.nr_fator,
                    t.cd_usuario_inclusao,
                    t.dt_usuario_inclusao,
                    t.cd_usuario_alteracao,
                    t.dt_usuario_alteracao
               from temp_prcd_unidade_medida t
              where not exists
              (select 1
                       from dbaps.procedimento_unidade_medida pu
                      where pu.cd_procedimento = t.cd_procedimento
                        and pu.cd_termo = t.cd_termo
                        and pu.dt_inicio_vigencia = t.dt_inicio_vigencia)
                and exists
              (select 1
                       from dbaps.procedimento pr
                      where pr.cd_procedimento = t.cd_procedimento)) Loop
  
    Begin
    
      INSERT INTO DBAPS.procedimento_unidade_medida T
      values
        (IX.cd_procedimento,
         IX.cd_termo,
         IX.dt_inicio_vigencia,
         IX.dt_fim_vigencia,
         IX.nr_fator,
         IX.cd_usuario_inclusao,
         IX.dt_usuario_inclusao,
         IX.cd_usuario_alteracao,
         IX.dt_usuario_alteracao);
    
    Exception
      When Others Then
        Rollback;
        Raise_Application_Error(-20002,
                                'Falha: ' || Sqlerrm || 'Procedimento: ' ||
                                Ix.Cd_Procedimento || ' Termo: ' ||
                                Ix.Cd_Termo || ' Vig�ncia: ' ||
                                Ix.Dt_Inicio_Vigencia);
    End;
  End Loop;

Exception
  When Others Then
    Rollback;
    Raise_Application_Error(-20001, 'Falha: ' || Sqlerrm);
End;

/

/*TAB=DEPOIS*/
select count(*) from temp_prcd_unidade_medida t;

/*TAB=N�O INCLUIR*/
select count(*)
  from temp_prcd_unidade_medida t
 where not exists (select 1
          from dbaps.procedimento pr
         where pr.cd_procedimento = t.cd_procedimento);

/*TAB=ja inclu�dos*/
select count(*)
  from dbaps.procedimento_unidade_medida pu, temp_prcd_unidade_medida t
 where trunc(pu.dt_inicio_vigencia) = trunc(t.dt_inicio_vigencia)
   and t.cd_procedimento = pu.cd_procedimento;

select count(*) from temp_prcd_unidade_medida t;

/*TAB=ver incluidos*/
select pu.*
  from dbaps.procedimento_unidade_medida pu
 where trunc(pu.dt_inicio_vigencia) = '01/04/2021'
   and exists (select 1
          from temp_prcd_unidade_medida t
         where t.cd_procedimento = pu.cd_procedimento);

/*TAB=qtd sera incluida*/
select count(*)
  from temp_prcd_unidade_medida t
 where not exists
 (select 1
          from dbaps.procedimento_unidade_medida pu
         where pu.cd_procedimento = t.cd_procedimento
           and pu.cd_termo = t.cd_termo
           and pu.dt_inicio_vigencia = t.dt_inicio_vigencia);

/*TAB=INCLUIR*/
select t.*
  from temp_prcd_unidade_medida t
 where not exists (select 1
          from dbaps.procedimento_unidade_medida pu
         where pu.cd_procedimento = t.cd_procedimento
           and pu.cd_termo = t.cd_termo
           and pu.dt_inicio_vigencia = t.dt_inicio_vigencia)
   and exists (select 1
          from dbaps.procedimento pr
         where pr.cd_procedimento = t.cd_procedimento);
