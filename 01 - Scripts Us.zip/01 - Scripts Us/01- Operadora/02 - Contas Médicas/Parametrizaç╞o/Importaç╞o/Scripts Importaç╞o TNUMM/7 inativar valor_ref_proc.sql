
select count(*) from temp_procedimento_inativar;

select count(vf.cd_procedimento) from dbaps.valor_ref_proc vf, temp_procedimento_inativar t
where  vf.cd_procedimento = t.cd_procedimento
and vf.dt_vigencia_fim is null
and vf.dt_vigencia = (select max(vff.dt_vigencia) from dbaps.valor_ref_proc vff
where vff.cd_procedimento = vf.cd_procedimento);

/*select tt.*
  from temp_procedimento_inativar tt
 where not exists
 (select 1
          from dbaps.valor_ref_proc vf, temp_procedimento_inativar t
         where vf.cd_procedimento = t.cd_procedimento
           and t.cd_procedimento = tt.cd_procedimento
           and vf.dt_vigencia_fim is null
           and vf.dt_vigencia =
               (select max(vff.dt_vigencia)
                  from dbaps.valor_ref_proc vff
                 where vff.cd_procedimento = vf.cd_procedimento));*/


select vf.cd_procedimento, vf.dt_vigencia, vf.dt_vigencia_fim, t.dt_inativacao, vf.* from dbaps.valor_ref_proc vf, temp_procedimento_inativar t
where  vf.cd_procedimento = t.cd_procedimento
and vf.dt_vigencia_fim is null
and vf.dt_vigencia = (select max(vff.dt_vigencia) from dbaps.valor_ref_proc vff
where vff.cd_procedimento = vf.cd_procedimento);

--create table tmp_fim_vigencia_val_ref_proc as
select vf.cd_procedimento, vf.dt_vigencia, vf.dt_vigencia_fim, t.dt_inativacao from dbaps.valor_ref_proc vf, temp_procedimento_inativar t
where  vf.cd_procedimento = t.cd_procedimento
and vf.dt_vigencia_fim is null
and vf.dt_vigencia = (select max(vff.dt_vigencia) from dbaps.valor_ref_proc vff
where vff.cd_procedimento = vf.cd_procedimento);

/*ORA-20001: Falha: ORA-20002: Falha: ORA-20000: O Registro n�o pode ser modificado!
ORA-06512: em "DBAPS.TRG_VALOR_REF_PROC", line 28
ORA-04088: erro durante a execu��o do gatilho 'DBAPS.TRG_VALOR_REF_PROC'cd_procedimento: 00001147
ORA-06512: em line 36
*/

ALTER TRIGGER DBAPS.TRG_VALOR_REF_PROC DISABLE;

BEGIN
DBAMV.PKG_MV2000.ATRIBUI_EMPRESA('1');
END;
/

Declare

Begin

  For Ix In (
    select t.cd_procedimento,
    t.dt_vigencia,
    t.dt_inativacao
    from tmp_fim_vigencia_val_ref_proc t
    --where t.cd_procedimento = 70685827
) Loop
  
    Begin
    
      UPDATE dbaps.valor_ref_proc p
         SET p.dt_vigencia_fim   = IX.dt_inativacao   
       WHERE p.cd_procedimento = IX.cd_procedimento
       and p.dt_vigencia = Ix.Dt_Vigencia;
    
    Exception
      When Others Then
        Rollback;
        Raise_Application_Error(-20002,
                                'Falha: ' || Sqlerrm || 'cd_procedimento: ' ||
                                Ix.cd_procedimento);
    End;
  End Loop;
 

Exception
  When Others Then
    Rollback;
    Raise_Application_Error(-20001, 'Falha: ' || Sqlerrm);
End;

/

  
alter trigger DBAPS.TRG_VALOR_REF_PROC ENABLE;


select count(*) from temp_procedimento_inativar;

select count(vf.cd_procedimento) from dbaps.valor_ref_proc vf, temp_procedimento_inativar t
where  vf.cd_procedimento = t.cd_procedimento
and vf.dt_vigencia_fim is null
and vf.dt_vigencia = (select max(vff.dt_vigencia) from dbaps.valor_ref_proc vff
where vff.cd_procedimento = vf.cd_procedimento);

select count(vf.cd_procedimento) from dbaps.valor_ref_proc vf, temp_procedimento_inativar t
where  vf.cd_procedimento = t.cd_procedimento
and vf.dt_vigencia_fim is not null
and vf.dt_vigencia = (select max(vff.dt_vigencia) from dbaps.valor_ref_proc vff
where vff.cd_procedimento = vf.cd_procedimento);

--create table tmp_fim_vigencia_val_ref_proc as
select vf.cd_procedimento, vf.dt_vigencia, vf.dt_vigencia_fim, t.dt_inativacao from dbaps.valor_ref_proc vf, temp_procedimento_inativar t
where  vf.cd_procedimento = t.cd_procedimento
and vf.dt_vigencia_fim is null
and vf.dt_vigencia = (select max(vff.dt_vigencia) from dbaps.valor_ref_proc vff
where vff.cd_procedimento = vf.cd_procedimento);

/*TAB=Resultado*/
select vf.cd_procedimento, vf.dt_vigencia, vf.dt_vigencia_fim, t.dt_inativacao from dbaps.valor_ref_proc vf, temp_procedimento_inativar t
where  vf.cd_procedimento = t.cd_procedimento
--and vf.dt_vigencia_fim is null
and vf.dt_vigencia = (select max(vff.dt_vigencia) from dbaps.valor_ref_proc vff
where vff.cd_procedimento = vf.cd_procedimento);

