
-- truncate table temp_procedimento_inativar;

/*
create table temp_procedimento_inativar as
select p.cd_procedimento, p.dt_inativacao, p.ds_motivo_ativo_inativo from procedimento p
where p.cd_procedimento = 0;
*/

select count(*) from temp_procedimento_inativar t;

select t.* from  temp_procedimento_inativar t;

select count(*) from procedimento p
where p.cd_procedimento in (select t.cd_procedimento from temp_procedimento_inativar t);


select p.cd_procedimento, p.dt_inativacao, p.ds_motivo_ativo_inativo from procedimento p
where p.cd_procedimento in (select t.cd_procedimento from temp_procedimento_inativar t);


select count(*) from temp_procedimento_inativar t
where not exists 
(select 1  from procedimento p
where p.cd_procedimento = t.cd_procedimento);

/*TAB=procedimento_nao_encontrado*/
select t.* from temp_procedimento_inativar t
where not exists 
(select 1  from procedimento p
where p.cd_procedimento = t.cd_procedimento);



BEGIN
DBAMV.PKG_MV2000.ATRIBUI_EMPRESA('1');
END;
/

Declare
Begin

  For Ix In (
    select t.cd_procedimento,
    t.dt_inativacao,
    t.ds_motivo_ativo_inativo
    from temp_procedimento_inativar t
    --where t.cd_procedimento = 70685827
) Loop
  
    Begin
    
      UPDATE procedimento p
         SET p.dt_inativacao   = IX.dt_inativacao,
             p.ds_motivo_ativo_inativo = Ix.Ds_Motivo_Ativo_Inativo
       WHERE p.cd_procedimento = IX.cd_procedimento;
    
    Exception
      When Others Then
        Rollback;
        Raise_Application_Error(-20002,
                                'Falha: ' || Sqlerrm || 'cd_procedimento: ' ||
                                Ix.cd_procedimento);
    End;
  End Loop;

Exception
  When Others Then
    Rollback;
    Raise_Application_Error(-20001, 'Falha: ' || Sqlerrm);
End;

/

select p.cd_procedimento, p.dt_inativacao, p.ds_motivo_ativo_inativo, p.* from procedimento p
where p.cd_procedimento in (select t.cd_procedimento from temp_procedimento_inativar t);


