
/*
ORA-20001: Falha: ORA-20002: Falha: ORA-12899: 
valor muito grande para a coluna "DBAPS"."PROCEDIMENTO"."DS_PROCEDIMENTO"
(real: 600, m�ximo: 500)cd_procedimento: 80386016
ORA-06512: em line 152
*/

/*truncate table dbaps.temp_procedimento;*/

/*TAB=JA_EXISTE*/
select *
  from dbaps.procedimento p
 where exists (select 1
          from dbaps.temp_procedimento t
         where p.cd_procedimento = t.cd_procedimento);
         
select count(*)
  from dbaps.procedimento p
 where exists (select 1
          from dbaps.temp_procedimento t
         where p.cd_procedimento = t.cd_procedimento);
         
/*TAB=N�O_EXISTE*/
select count(*)
  from dbaps.temp_procedimento t
 where not exists (select 1
          from dbaps.procedimento p
         where p.cd_procedimento = t.cd_procedimento);

select *
  from dbaps.temp_procedimento t
 where not exists (select 1
          from dbaps.procedimento p
         where p.cd_procedimento = t.cd_procedimento);

/*BEGIN
DBAMV.PKG_MV2000.ATRIBUI_EMPRESA('1');
END;
/

ORA-20001: Falha: ORA-20002: Falha: ORA-00001: restri��o exclusiva (DBAPS.PROCEDIM_PK) violadacd_procedimento: 73920690

select *
            from dbaps.procedimento p
           where p.cd_procedimento = 73920690;
           
         select t.*, rowid from
             dbaps.temp_procedimento t
             where t.cd_procedimento = 73920690;

*/

BEGIN
DBAMV.PKG_MV2000.ATRIBUI_EMPRESA('1');
END;
/

Declare
Begin

  For Ix In (
             
             select SUBSTR(T.DS_PROCEDIMENTO, 1, 500) DS_PROCEDIMENTO_f, t.*
               from dbaps.temp_procedimento t
              where not exists
              (select 1
                       from dbaps.procedimento p
                      where p.cd_procedimento = t.cd_procedimento)
             
             ) Loop
  
    Begin
    
      INSERT INTO DBAPS.PROCEDIMENTO
      VALUES
        (
         
         Ix.cd_procedimento,
         Ix.cd_grupo_procedimento,
         Ix.cd_gru_carencia,
         Ix.cd_gru_direito,
         Ix.cd_porte_anestesico,
         --Ix.ds_procedimento,
         Ix.Ds_Procedimento_f,
         Ix.tp_sexo,
         Ix.tp_guia,
         Ix.nr_auxiliar,
         Ix.nr_incidencias,
         Ix.tp_filme,
         Ix.ds_unidade,
         Ix.nr_dias_internacao,
         Ix.nr_nivel_autorizacao,
         Ix.cd_item_despesa,
         Ix.cd_apresentacao,
         Ix.tp_parto_sip,
         Ix.cd_rol_procedimentos_ans,
         Ix.tp_natureza,
         Ix.nr_idade_minima,
         Ix.nr_idade_maxima,
         Ix.qt_maxima_solic,
         Ix.qt_maxima_dia,
         Ix.qt_maxima_mes,
         Ix.qt_maxima_ano,
         Ix.qt_maxima_permitida,
         Ix.nr_dias_intervalo,
         Ix.cd_sih_ms,
         Ix.nr_procedimento,
         Ix.dt_inativacao,
         Ix.ds_procedimento_completa,
         Ix.cd_grupo_co_cp,
         Ix.tp_origem,
         Ix.tp_tabela,
         Ix.tp_ato,
         Ix.cd_unidade,
         Ix.vl_apresentacao,
         Ix.nr_anvisa,
         Ix.cd_material_fabricante,
         Ix.nr_autorizacao_funcionamento,
         Ix.cd_fabricante_opme_mvs,
         Ix.cd_procedimento_tuss,
         Ix.cd_usuario_inclusao,
         Ix.dt_inclusao,
         Ix.sn_pacote,
         Ix.dh_alteracao,
         Ix.cd_usuario_alteracao,
         Ix.sn_alto_custo,
         Ix.sn_restrito_hospitalar,
         Ix.sn_generico,
         Ix.ds_observacao,
         Ix.sn_rol_ans,
         Ix.cd_tiss,
         Ix.cd_log_importacao_procedimento,
         Ix.ds_procedimento_tuss,
         Ix.ds_procedimento_tuss_completa,
         Ix.sn_proced_universal,
         Ix.tp_codificacao,
         Ix.ds_motivo_ativo_inativo,
         Ix.vl_fabrica,
         Ix.cd_anterior_material,
         Ix.tp_produto,
         Ix.vl_max_intercambio,
         Ix.dt_inicio_vigencia,
         Ix.dt_fim_implantacao,
         Ix.vl_preco_unico,
         Ix.ds_produto,
         Ix.ds_especialidade,
         Ix.ds_classe,
         Ix.cd_anterior_medicamento,
         Ix.ds_princ_ativo,
         Ix.ds_gru_farma,
         Ix.ds_cla_farma,
         Ix.ds_for_farma,
         Ix.ds_det_reg_anvisa,
         Ix.nr_cnpj,
         Ix.tp_valor_pago_padrao,
         Ix.sn_honorario,
         Ix.sn_uco,
         Ix.sn_filme,
         Ix.qt_maxima_contratual,
         Ix.tp_valor_pago_padrao_inter,
         Ix.sn_obriga_anexo,
         Ix.sn_exige_dente,
         Ix.sn_exige_face,
         Ix.sn_exige_regiao,
         Ix.tp_carater_solic_inter,
         Ix.vl_taxa_custo,
         Ix.sn_isento_trib_reembolso,
         Ix.sn_alerta_audit_cm,
         Ix.sn_alerta_audit_cm_interc,
         Ix.qtd_max_exec_dia,
         Ix.qtd_max_exec_item,
         Ix.sn_audit_enf_cm,
         Ix.sn_audit_med_cm,
         Ix.sn_bloquear_intercambio,
         Ix.cd_multi_empresa,
         Ix.sn_obriga_equipe_xml,
         Ix.sn_cirurgico,
         Ix.SN_GRAU_OCULOS,
         Ix.CD_UNIMED_PROCED_TUSS,
         Ix.CD_UNIMED_TABELA_TUSS,
         Ix.CD_UNIMED_PROCED_TUSS_ANTERIOR,
         Ix.SN_VIA_ACESSO,
         Ix.NR_MAX_DIAS_QTD_SOLICIT_REEMB,
         Ix.TP_CLASSIF_SIMPRO,
         Ix.CD_PACOTE_PROC_PRINC_ALTERN,
         Ix.VL_TETO_REEMBOLSO,
         Ix.SN_LIMITE_VALOR_REEMBOLSO,
         Ix.SN_MEDICAMENTO_REEMBOSAVEL,
         Ix.CD_PTU_REMESSA_RETORNO,
         Ix.NM_TECNICO,
         Ix.DS_EQUIV_TECNICA,
         Ix.CD_AMB,
         Ix.QTD_UT_AMB,
         Ix.NR_AUX_AMB,
         Ix.CD_PORTE_ANES_AMB,
         Ix.VL_FILME_AMB,
         Ix.DS_PORTE_ROL,
         Ix.CD_GRUPOS_PLANILHA,
         Ix.TP_CLASS,
         Ix.NR_QUANT,
         Ix.NR_DOC_RAC,
         Ix.QTD_DIAS_PRAZO_EXEC,
         Ix.QTD_DIAS_PRAZO_ORI,
         Ix.QTD_DIAS_PRAZO_TOTAL,
         Ix.DS_PROCEDIMENTO_AMB,
         Ix.VL_HONORARIO_MEDICO,
         Ix.VL_TAXA_VIDEO,
         Ix.VL_UCO,
         Ix.TP_PRODUTO_MED,
         Ix.VL_FATOR_CONVERSAO,
         Ix.SN_CONFAZ,
         Ix.VL_PROC_INTERCAMBIO_NACIONAL,
         Ix.SN_PROCED_MED

         
         );
    
    Exception
      When Others Then
        Rollback;
        Raise_Application_Error(-20002,
                                'Falha: ' || Sqlerrm || 'cd_procedimento: ' ||
                                Ix.cd_procedimento);
    End;
  End Loop;

Exception
  When Others Then
    Rollback;
    Raise_Application_Error(-20001, 'Falha: ' || Sqlerrm);
End;

/

  select *
    from dbaps.temp_procedimento t
   where not exists (select 1
            from dbaps.procedimento p
           where p.cd_procedimento = t.cd_procedimento);

select *
  from dbaps.procedimento p
 where p.cd_procedimento in (
 00797251,
00797260,
00797278,
00797286,
00797294,
00797308,
00797316

);

select count(*)
  from dbaps.procedimento p
 where exists (select 1
          from dbaps.temp_procedimento t
         where p.cd_procedimento = t.cd_procedimento);
