/*
-- 2145726
select dbaps.seq_valor_ref_proc.nextval from dual;
-- 2145725
select max(d.cd_valor_ref_proc)  from dbaps.valor_ref_proc d;
*/

--delete from temp_valor_ref_proc;

/*create table temp_valor_ref_proc as
select * from dbaps.valor_ref_proc v
where v.cd_tabela = 0
and v.cd_procedimento = 0
;
*/

select count(*)
  from temp_valor_ref_proc t;
  
--select vf.*, rowid from temp_valor_ref_proc vf;


-- valor_ref_proc - N�O INCLU�DOS - Procedimento n�o cadastrado
select t.*
  from temp_valor_ref_proc t
 where not exists (select 1
          from dbaps.procedimento pr
         where pr.cd_procedimento = t.cd_procedimento);


-- incluir
select count(*)
  from temp_valor_ref_proc t
 where not exists (select 1
          from dbaps.valor_ref_proc v
         where v.cd_tabela = t.cd_tabela
           and v.cd_procedimento = t.cd_procedimento)
  and exists (select 1
          from dbaps.procedimento pr
         where pr.cd_procedimento = t.cd_procedimento);

-- n�o incluir
select count(*)
  from temp_valor_ref_proc t
 where exists (select 1
          from dbaps.valor_ref_proc v
         where v.cd_tabela = t.cd_tabela
           and v.cd_procedimento = t.cd_procedimento);

-- inclu�dos
select count(*)
  from temp_valor_ref_proc t, dbaps.valor_ref_proc v
 where t.cd_tabela = v.cd_tabela
   and t.cd_procedimento = v.cd_procedimento
   and trunc(t.dt_vigencia) = trunc(v.dt_vigencia);


select *
  from dbaps.valor_ref_proc v
 where v.cd_tabela = 15
   and v.cd_procedimento = 90038630;

select *
  from dbaps.valor_ref_proc v
 where v.cd_tabela = 16
   and v.cd_procedimento = 00719463;

--dbaps.seq_valor_ref_proc

/*BEGIN
DBAMV.PKG_MV2000.ATRIBUI_EMPRESA('1');
END;
/*/

Declare
Begin

  For Ix In (select t.*, rowid
               from temp_valor_ref_proc t
              where not exists
              (select 1
                       from dbaps.valor_ref_proc v
                      where v.cd_tabela = t.cd_tabela
                        and v.cd_procedimento = t.cd_procedimento)
               and exists (select 1
          from dbaps.procedimento pr
         where pr.cd_procedimento = t.cd_procedimento)) Loop
  
    Begin
    
      INSERT INTO dbaps.valor_ref_proc
      values
        (Ix.Cd_Tabela,
         Ix.Cd_Procedimento,
         Ix.Dt_Vigencia,
         Ix.Vl_Referencia,
         Ix.Cd_Import,
         Ix.Vl_Lucro,
         Ix.Vl_Imposto,
         Ix.Vl_Tx_Adm,
         Ix.Cd_Porte_Anestesico,
         Ix.Nr_Auxiliar,
         Ix.Nr_Incidencias,
         Ix.Tp_Filme,
         Ix.Cd_Porte_Medico,
         Ix.Cd_Log_Importacao_Procedimento,
         Ix.Tp_Importacao_Procedimento,
         Ix.Nr_Edicao,
         Ix.Vl_Uco,
         Ix.Vl_Perc_Peso_Porte,
         Ix.Dh_Inclusao,
         Ix.Dh_Alteracao,
         Ix.Cd_Usuario_Inclusao,
         Ix.Cd_Usuario_Alteracao,
         Ix.Cd_Prestador,
         Ix.Cd_Log_Reajuste_Tabela,
         Ix.Dt_Inativacao,
         Ix.Cd_Valor_Ref_Proc,
         Ix.Dt_Vigencia_Fim,
         Ix.Vl_Perc_Banda_Uco,
         Ix.cd_termo,
         Ix.Ds_Observacao);
    
    Exception
      When Others Then
        Rollback;
        Raise_Application_Error(-20002,
                                'Falha: ' || Sqlerrm || 'cd_procedimento: ' ||
                                Ix.cd_procedimento);
    End;
  End Loop;

Exception
  When Others Then
    Rollback;
    Raise_Application_Error(-20001, 'Falha: ' || Sqlerrm);
End;

/

-- incluir
select count(*)
  from temp_valor_ref_proc t
 where not exists (select 1
          from dbaps.valor_ref_proc v
         where v.cd_tabela = t.cd_tabela
           and v.cd_procedimento = t.cd_procedimento)
  and exists (select 1
          from dbaps.procedimento pr
         where pr.cd_procedimento = t.cd_procedimento);

-- n�o incluir
select count(*)
  from temp_valor_ref_proc t
 where exists (select 1
          from dbaps.valor_ref_proc v
         where v.cd_tabela = t.cd_tabela
           and v.cd_procedimento = t.cd_procedimento);

-- inclu�dos
select count(*)
  from temp_valor_ref_proc t, dbaps.valor_ref_proc v
 where t.cd_tabela = v.cd_tabela
   and t.cd_procedimento = v.cd_procedimento
   and trunc(t.dt_vigencia) = trunc(v.dt_vigencia);


select *
  from dbaps.valor_ref_proc v
 where v.cd_tabela = 15
   and v.cd_procedimento = 90038630
;

select *
  from dbaps.valor_ref_proc v
 where v.cd_tabela = 16
   and v.cd_procedimento = 00719463
;
