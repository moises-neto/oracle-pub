-- truncate table temp_proced_tipo_atendimento;

/*TAB=ANTES*/
select t.*
  from temp_proced_tipo_atendimento t
 where exists
 (select 1
          from dbaps.procedimento pr
         where t.cd_procedimento = pr.cd_procedimento
           and pr.cd_procedimento in
               (00797251, 00797260, 00797278, 00797286, 00797294));

/*TAB=ja importados - nao importar*/
select count(*)
  from temp_proced_tipo_atendimento t
 where exists (select 1
          from dbaps.proced_tipo_atendimento p
         where p.cd_procedimento = t.cd_procedimento
           and p.cd_tipo_atendimento = t.cd_tipo_atendimento)
   and exists (select 1
          from dbaps.procedimento pr
         where pr.cd_procedimento = t.cd_procedimento);

/*TAB=nao duplicados - importar*/
select count(*)
  from temp_proced_tipo_atendimento t
 where not exists (select 1
          from dbaps.proced_tipo_atendimento p
         where p.cd_procedimento = t.cd_procedimento
           and p.cd_tipo_atendimento = t.cd_tipo_atendimento)
   and exists (select 1
          from dbaps.procedimento pr
         where pr.cd_procedimento = t.cd_procedimento);

/*TAB=duplicados - ja importados*/
select count(*)
  from temp_proced_tipo_atendimento t
 where exists (select 1
          from dbaps.proced_tipo_atendimento p
         where p.cd_procedimento = t.cd_procedimento
           and p.cd_tipo_atendimento = t.cd_tipo_atendimento);

/*TAB=amostra*/      
select *
  from dbaps.proced_tipo_atendimento p
 where p.cd_procedimento in
       (00797251, 00797260, 00797278, 00797286, 00797294);




BEGIN
DBAMV.PKG_MV2000.ATRIBUI_EMPRESA('1');
END;
/

Declare


Begin

  For Ix In (
             
             -- n�o duplicados
             select t.*
               from temp_proced_tipo_atendimento t
              where not exists
              (select 1
                       from dbaps.proced_tipo_atendimento p
                      where p.cd_procedimento = t.cd_procedimento
                        and p.cd_tipo_atendimento = t.cd_tipo_atendimento)
                and exists
              (select 1
                       from dbaps.procedimento pr
                      where pr.cd_procedimento = t.cd_procedimento)
             
             ) Loop
  
    Begin
    
      INSERT INTO dbaps.proced_tipo_atendimento
      values
        (Ix.Cd_Procedimento,
         Ix.Cd_Tipo_Atendimento,
         Ix.Sn_Autorizacao,
         Ix.Sn_Guia,
         Ix.Sn_Aplica_Redutor,
         Ix.Cd_Nivel_Hierarquico,
         Ix.Sn_Visivel_Web);
    
    Exception
      When Others Then
        Rollback;
        Raise_Application_Error(-20002,
                                'Falha: ' || Sqlerrm || 'cd_procedimento: ' ||
                                Ix.cd_procedimento);
    End;
  End Loop;

Exception
  When Others Then
    Rollback;
    Raise_Application_Error(-20001, 'Falha: ' || Sqlerrm);
End;

/


/*TAB=DEPOIS*/
select t.*
  from temp_proced_tipo_atendimento t
 where exists
 (select 1
          from dbaps.procedimento pr
         where t.cd_procedimento = pr.cd_procedimento
           and pr.cd_procedimento in
               (00797251, 00797260, 00797278, 00797286, 00797294));

/*TAB=ja importados - nao importar*/
select count(*)
  from temp_proced_tipo_atendimento t
 where exists (select 1
          from dbaps.proced_tipo_atendimento p
         where p.cd_procedimento = t.cd_procedimento
           and p.cd_tipo_atendimento = t.cd_tipo_atendimento)
   and exists (select 1
          from dbaps.procedimento pr
         where pr.cd_procedimento = t.cd_procedimento);

/*TAB=nao duplicados - importar*/
select count(*)
  from temp_proced_tipo_atendimento t
 where not exists (select 1
          from dbaps.proced_tipo_atendimento p
         where p.cd_procedimento = t.cd_procedimento
           and p.cd_tipo_atendimento = t.cd_tipo_atendimento)
   and exists (select 1
          from dbaps.procedimento pr
         where pr.cd_procedimento = t.cd_procedimento);

/*TAB=duplicados - ja importados*/
select count(*)
  from temp_proced_tipo_atendimento t
 where exists (select 1
          from dbaps.proced_tipo_atendimento p
         where p.cd_procedimento = t.cd_procedimento
           and p.cd_tipo_atendimento = t.cd_tipo_atendimento);

/*TAB=amostra*/      
select *
  from dbaps.proced_tipo_atendimento p
 where p.cd_procedimento in
       (00797251, 00797260, 00797278, 00797286, 00797294);
