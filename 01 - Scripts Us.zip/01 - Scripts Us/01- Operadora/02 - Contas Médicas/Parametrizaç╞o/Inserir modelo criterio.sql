--prrocedimento

Begin

  For i In (Select Distinct Ip.*,
                            Case
                              When Ip.Cd_Modelo_Criterio = 1255 Then
                               1435
                              When Ip.Cd_Modelo_Criterio = 1256 Then
                               1436
                              When Ip.Cd_Modelo_Criterio = 1282 Then
                               1437
                              When Ip.Cd_Modelo_Criterio = 1283 Then
                               1438
                              When Ip.Cd_Modelo_Criterio = 1251 Then
                               1439
                            
                              When Ip.Cd_Modelo_Criterio = 1252 Then
                               1440
                              When Ip.Cd_Modelo_Criterio = 1253 Then
                               1441
                              When Ip.Cd_Modelo_Criterio = 1254 Then
                               1442
                              When Ip.Cd_Modelo_Criterio = 1245 Then
                               1432
                            
                              Else
                               Null
                            End Cd_Modelo_Criterio_New
              From Itmodelo_Criterio_Procedimento Ip
             Where Ip.Cd_Modelo_Criterio In
                   (1255, 1256, 1282, 1283, 1251, 1252, 1253, 1254, 1245)) Loop
  
    Insert Into Itmodelo_Criterio_Procedimento
      (Cd_Modelo_Criterio,
       Cd_Procedimento,
       Cd_Usuario_Inclusao,
       Dt_Inclusao,
       Cd_Usuario_Alteracao,
       Dt_Alteracao)
    Values
      (i.Cd_Modelo_Criterio_New,
       i.Cd_Procedimento,
       i.Cd_Usuario_Inclusao,
       Sysdate,
       Null,
       Null);
  
  End Loop;
End;

---carteira
Begin
  For i In (Select Distinct Ip.*,
                            Case
                              When Ip.Cd_Modelo_Criterio = 1255 Then
                               1435
                              When Ip.Cd_Modelo_Criterio = 1256 Then
                               1436
                              When Ip.Cd_Modelo_Criterio = 1282 Then
                               1437
                              When Ip.Cd_Modelo_Criterio = 1283 Then
                               1438
                              When Ip.Cd_Modelo_Criterio = 1251 Then
                               1439
                            
                              When Ip.Cd_Modelo_Criterio = 1252 Then
                               1440
                              When Ip.Cd_Modelo_Criterio = 1253 Then
                               1441
                              When Ip.Cd_Modelo_Criterio = 1254 Then
                               1442
                              When Ip.Cd_Modelo_Criterio = 1245 Then
                               1432
                            
                              Else
                               Null
                            End Cd_Modelo_Criterio_New
              From Itmodelo_Criterio_Carteira Ip
             Where Ip.Cd_Modelo_Criterio In
                   (1255, 1256, 1282, 1283, 1251, 1252, 1253, 1254, 1245)) Loop
    Insert Into Dbaps.Itmodelo_Criterio_Carteira
      (Cd_Modelo_Criterio,
       Nr_Carteira,
       Cd_Usuario_Inclusao,
       Dt_Inclusao,
       Cd_Usuario_Alteracao,
       Dt_Alteracao)
    Values
      (i.Cd_Modelo_Criterio_New,
       i.Nr_Carteira,
       i.Cd_Usuario_Inclusao,
       Sysdate,
       Null,
       Null);
  
  End Loop;

End;

---familia
Begin
  For i In (Select Distinct Ip.*,
                            Case
                              When Ip.Cd_Modelo_Criterio = 1255 Then
                               1435
                              When Ip.Cd_Modelo_Criterio = 1256 Then
                               1436
                              When Ip.Cd_Modelo_Criterio = 1282 Then
                               1437
                              When Ip.Cd_Modelo_Criterio = 1283 Then
                               1438
                              When Ip.Cd_Modelo_Criterio = 1251 Then
                               1439
                            
                              When Ip.Cd_Modelo_Criterio = 1252 Then
                               1440
                              When Ip.Cd_Modelo_Criterio = 1253 Then
                               1441
                              When Ip.Cd_Modelo_Criterio = 1254 Then
                               1442
                              When Ip.Cd_Modelo_Criterio = 1245 Then
                               1432
                            
                              Else
                               Null
                            End Cd_Modelo_Criterio_New
              From Itmodelo_Criterio_Familia Ip
             Where Ip.Cd_Modelo_Criterio In
                   (1255, 1256, 1282, 1283, 1251, 1252, 1253, 1254, 1245)) Loop
    Insert Into Dbaps.Itmodelo_Criterio_Familia
      (Cd_Modelo_Criterio,
       Cd_Familia,
       Cd_Usuario_Inclusao,
       Dt_Inclusao,
       Cd_Usuario_Alteracao,
       Dt_Alteracao)
    Values
      (i.Cd_Modelo_Criterio_New,
       i.Cd_Familia,
       i.Cd_Usuario_Inclusao,
       Sysdate,
       Null,
       Null);
  
  End Loop;

End;

select * from DBAPS.ITMODELO_CRITERIO_FAMILIA t
Where t.cd_modelo_criterio = 1432
