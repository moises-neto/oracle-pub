 Call custom.prc_importa_contas(Pcd_Tp_Pagcob => 'CN'); 
      
                 Select * From dbaps.lote l 
                 Where l.cd_fatura = 42592
                 And l.ds_lote Like '%IMPORTA��O%'; 
                 
                  Select * From dbaps.lote l 
                 Where l.cd_fatura = 41649
                 And l.ds_lote Like '%IMPORTA��O%';
                 
                 
                 Delete From remessa_prestador rp Where rp.cd_lote In (477286,477280)
                 
                 Select v.cd_guia_externa, v.* From v_ctas_medicas v Where v.cd_lote In(477280, 477286)


Select v.cd_guia_externa, v.* From v_ctas_medicas v Where v.nr_guia = 97013929 And v.cd_procedimento = 40901076
