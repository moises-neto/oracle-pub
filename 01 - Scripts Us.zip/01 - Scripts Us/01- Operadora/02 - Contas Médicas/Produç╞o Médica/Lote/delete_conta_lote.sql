Begin
  For i In (Select v.Tp_Conta, v.Cd_Conta_Medica
              From Dbaps.v_Ctas_Medicas v
             Where v.Cd_Fatura = 46351
             And v.tp_situacao = 'NA') Loop
    Begin
      If (i.Tp_Conta = 'A') Then
        Delete From Remessa_Prestador Rp
         Where Rp.Cd_Remessa = i.Cd_Conta_Medica;
      
      Else
        Delete From Conta_Hospitalar Ch
         Where Ch.Cd_Conta_Hospitalar = i.Cd_Conta_Medica;
      End If;
    End;
  
  End Loop;

End;

Delete From LOTE L
Where L.CD_FATURA  = 46351
And L.SN_FECHADO = 'N';
