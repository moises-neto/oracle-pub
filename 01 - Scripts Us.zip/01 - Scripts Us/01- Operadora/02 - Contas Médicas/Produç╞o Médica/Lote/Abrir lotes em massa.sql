Declare

Begin
  For i In ( select Distinct v.Cd_Lote
              From Dbaps.v_Ctas_Medicas v
             Where v.Dt_Competencia = '202207'
               And v.Cd_Fatura = 40329
              ) Loop
  
    Begin
      Update Dbaps.Lote l
         Set l.Sn_Fechado = 'N'
       Where l.Cd_Lote = i.Cd_Lote
         And l.Sn_Fechado = 'S';
    
    End;
  
  End Loop;

Exception
  When Others Then
    Raise_Application_Error(-20001, 'Erro: ' || Sqlerrm);
    Rollback;
  
End;


