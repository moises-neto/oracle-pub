Declare
   
Begin
  For i In (Select *
              From (Select Distinct v.Cd_Lote,
                                    Count(Distinct v.Cd_Conta_Medica) Qtde_Contas,
                                    (Select Count(Vv.Cd_Lancamento)
                                       From Dbaps.v_Ctas_Medicas Vv
                                      Where Vv.Cd_Lote = v.Cd_Lote
                                        And Vv.Tp_Situacao_Itconta In
                                            ('NA', 'GA')) As Qtde_Na_Itens,
                                    (Select Count(Vv.Cd_Lancamento)
                                       From Dbaps.v_Ctas_Medicas Vv
                                      Where Vv.Cd_Lote = v.Cd_Lote
                                           
                                        And Vv.Tp_Situacao_Conta In
                                            ('NA', 'GA')) As Qtde_Na_Contas
                    
                      From v_Ctas_Medicas v
                     Where v.Dt_Competencia = '202207'
                       And v.Sn_Lote_Fechado = 'N'
                     
                     
                     Group By v.Cd_Lote)
            
             Where Qtde_Na_Itens = 0
               And Qtde_Na_Contas = 0) Loop
  
    Begin
      Update Dbaps.Lote l
         Set l.Sn_Fechado = 'S'
       Where l.Cd_Lote = i.Cd_Lote
         And l.Sn_Fechado = 'N';
    
    End;
  
  End Loop;

Exception
  When Others Then
    Raise_Application_Error(-20001, 'Erro: ' || Sqlerrm);
    Rollback;
  
End;


