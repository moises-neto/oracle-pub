-- Pagamento
Declare

Begin

  For i In (Select v.*, v.Vl_Unit * v.Qt_Pago As Valor_Total
              From Temp_Atualiza_Valor v)
  
   Loop
  
    Begin
      --Sadt e Consulta
      --  If (i.Tp_Conta = 'A') Then
    
      Update Dbaps.Itremessa_Prestador_Equipe It
         Set It.Vl_Unit_Cobrado = i.Vl_Unit,
             It.Vl_Unit_Pago    = i.Vl_Unit,
             It.Vl_Calculado    = i.Vl_Unit,
             It.Vl_Conta        = i.Valor_Total,
             It.Vl_Pago         = i.Valor_Total
      
       Where It.Cd_Remessa = i.Cd_Conta_Medica
         And It.Cd_Lancamento = i.Cd_Lancamento;
    
      Dbms_Output.Put_Line('Registrando log... Calculando Pagamento: Sadt/Consulta -->' ||
                           ' Atualiza��o de valor --> ' || i.Cd_Conta_Medica ||
                           ' cd_lancamento: ' || i.Cd_Lancamento ||
                           ' Valor Unit�rio: ' || i.Vl_Unit ||
                           ' Valor Total: ' || i.Valor_Total);
      /* Else
      --Interna��o e Honor�rio
      Update Dbaps.Itconta_Med Ih
         Set Ih.Vl_Unit_Cobrado = i.Vl_Unit,
             Ih.Vl_Unit_Pago    = i.Vl_Unit,
             Ih.Vl_Calculado    = i.Vl_Unit,
             Ih.Vl_Conta        = i.Vl_Unit,
             Ih.Vl_Pago         = i.Vl_Unit
      
       Where Ih.Cd_Conta_Hospitalar = i.Cd_Conta
         And Ih.Cd_Lancamento = i.Cd_Lancamento;
      
      Dbms_Output.Put_Line('Calculando Pagamento: Interna��o/Honor�rio -->' ||
                           ' Atualiza��o de valor --> ' || i.Cd_Conta ||
                           ' cd_lancamento: ' || i.Cd_Lancamento ||
                           ' Valor: ' || i.Vl_Unit);  */
      --- End If;
    End;
  
  End Loop;

Exception

  When Others Then
    Raise_Application_Error(-20001, 'Erro: ' || Sqlerrm);
    Rollback;
  
End;

-----Cobran�a  
/
Declare

Begin
  For i In (Select m.Cd_Conta,
                   m.Cd_Lote,
                   m.Cd_Lancamento,
                   m.Cd_Procedimento,
                   m.Vl_Unit,
                   'A' As Tp_Conta
              From Custom.Moises_Prod_06 m
             Where Exists (Select 1
                      From Dbaps.Itremessa_Prestador_Fatura Ie
                     Where Ie.Cd_Remessa = m.Cd_Conta
                       And Ie.Cd_Lancamento = m.Cd_Lancamento
                       And Ie.Vl_Unit_Cobrado <> m.Vl_Unit
                       And Ie.Cd_Mens_Contrato Is Null)
               And Trunc(m.Dt_Reajuste) = '28/06/2022'
               And m.Cd_Conta = 11899772
               And m.Cd_Procedimento = 90137930
            --And m.cd_conta = 11899428
            --And m.cd_lancamento = 2  
            Union All
            Select m.Cd_Conta,
                   m.Cd_Lote,
                   m.Cd_Lancamento,
                   m.Cd_Procedimento,
                   m.Vl_Unit,
                   'I' As Tp_Conta
              From Custom.Moises_Prod_06 m
             Where Exists (Select 1
                      From Dbaps.Itconta_Hospitalar_Fatura Im
                     Where Im.Cd_Conta_Hospitalar = m.Cd_Conta
                       And Im.Cd_Lancamento = m.Cd_Lancamento
                       And Im.Vl_Unit_Cobrado <> m.Vl_Unit
                       And Im.Cd_Mens_Contrato Is Null)
               And Trunc(m.Dt_Reajuste) = '28/06/2022'
               And m.Cd_Conta = 11899772
               And m.Cd_Procedimento = 90137930
            -- And m.cd_conta = 11899428
            --  And m.cd_lancamento = 2      
            ) Loop
    Begin
      --Sadt e Consulta
      If (i.Tp_Conta = 'A') Then
        Update Dbaps.Itremessa_Prestador_Fatura f
           Set f.Vl_Calculado = i.Vl_Unit, f.Vl_Unit_Cobrado = i.Vl_Unit
         Where f.Cd_Remessa = i.Cd_Conta
           And f.Cd_Lancamento = i.Cd_Lancamento;
      
        Dbms_Output.Put_Line('Calculando Cobran�a: Sadt/Consulta -->' ||
                             ' Atualiza��o de valor --> ' || i.Cd_Conta ||
                             ' cd_lancamento: ' || i.Cd_Lancamento ||
                             ' Valor: ' || i.Vl_Unit);
        --Interna��o e Honor�rio
      Else
      
        Update Dbaps.Itconta_Hospitalar_Fatura Ih
           Set Ih.Vl_Calculado = i.Vl_Unit, Ih.Vl_Unit_Cobrado = i.Vl_Unit
         Where Ih.Cd_Conta_Hospitalar = i.Cd_Conta
           And Ih.Cd_Lancamento = i.Cd_Lancamento;
      
        Dbms_Output.Put_Line('Calculando Cobran�a: Interna��o/Honor�rio -->' ||
                             ' Atualiza��o de valor --> ' || i.Cd_Conta ||
                             ' cd_lancamento: ' || i.Cd_Lancamento ||
                             ' Valor: ' || i.Vl_Unit);
      
      End If;
    End;
  End Loop;

End;



/*
 Begin
    Dbamv.Pkg_Mv2000.Atribui_Empresa('1');
  End;

Call   Dbaps.Prc_Recalcula_Valor_Proced_V4(Pcd_Lote          => 419325,
                                          Pcd_Conta_Medica   => 11899772,
                                          Pcd_Lancamento     => 13,
                                          Ptp_Calculo        => 'P',
                                          Psn_Calcula_Equipe => 'S',
                                          Ptp_Regra          => 'P',
                                          Psn_Apenas_Taxa    => 'N');*/
