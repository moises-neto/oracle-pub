Declare

Begin

  For i In (Select v.Cd_Lote, v.Cd_Conta_Medica
              From Dbaps.v_Ctas_Medicas v
             Where v.Dt_Competencia = '202207'
               And v.Cd_Fatura = 40329
               And v.Tp_Situacao_Itconta = 'NA') Loop
  
    Begin
    
      Update Dbaps.Ctamed_Amb_Erros Cae
         Set Cae.Sn_Liberado          = 'S' Cae.Dt_Liberacao = Sysdate,
             Cae.Cd_Usuario_Liberacao = User
       Where Exists (Select 1
                From Dbaps.Remessa_Prestador Rp
               Where Cae.Cd_Remessa_Itremaudit = Rp.Cd_Remessa
                 And Rp.Cd_Lote = i.Cd_Lote
                 And Rp.Cd_Remessa = i.Cd_Conta_Medica)
         And Cae.Dt_Ocorrencia_Manual Is Null;
    End;
  
  End Loop;

Exception
  When Others Then
    Raise_Application_Error(-20001, 'Falhou :( -- >' || Sqlerrm);
    Rollback;
End;
