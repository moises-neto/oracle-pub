Select * From Custom.Vw_Duplicidade_Contas v WHERE v.CD_FATURA NOT IN (43446, 43447);
                            /*
                            43446: ACERTO - COOPERADO
43447: ACERTO - JUR�DICO
                            */

Begin
  For i In (Select lp.*
              From Custom.Log_Altera_Tp_Pagcob Lp, dbaps.temp_contas_moises_ajust t
             Where lp.cd_conta_medica = t.cd_conta
             And lp.cd_lancamento = t.cd_lancamento ) Loop
  
    Begin
      ---ITEM
    
      Update Dbaps.Itremessa_Prestador Ip
         Set Ip.Tp_Situacao = i.Tp_Situacao_Old,
             Ip.Tp_Pagcob   = i.Tp_Pagcob_Old,
             Ip.Cd_Motivo   = i.Cd_Motivo_Old
      
       Where Ip.Cd_Remessa = i.Cd_Conta_Medica
         And Ip.Cd_Lancamento = i.Cd_Lancamento;
    
      --Equipe 
    
      Update Dbaps.Itremessa_Prestador_Equipe Ipe
         Set Ipe.Tp_Situacao = i.Tp_Situacao_Old,
             Ipe.Cd_Motivo   = i.Cd_Motivo_Old
      
       Where Ipe.Cd_Remessa = i.Cd_Conta_Medica
         And Ipe.Cd_Lancamento = i.Cd_Lancamento;
    
    End;
    Dbms_Output.Put_Line('Conta atualizada' || i.Cd_Conta_Medica ||
                         ' Lan�amento: ' || i.Cd_Lancamento);
  End Loop;

End;

--1498


Select * From Custom.Log_Altera_Tp_Pagcob lp Where lp.cd_fatura In (43446, 43447)

Select * From Custom.Vw_Duplicidade_Contas v Where v.NR_GUIA = 102248109 
