Declare

Begin
  For i In (Select Rp.Cd_Remessa, Ip.Cd_Lancamento
              From Dbaps.Remessa_Prestador   Rp,
                   Dbaps.Itremessa_Prestador Ip,
                   Dbaps.Lote                l
             Where Rp.Cd_Lote = l.Cd_Lote
               And Rp.Cd_Remessa = Ip.Cd_Remessa
                  
               And l.Cd_Fatura = 42875
               And Exists
             (Select Ce.Cd_Remessa_Remessa, Ce.Cd_Lancamento_Itremaudit
                      From Dbaps.Ctamed_Amb_Erros Ce
                     Where Ce.Cd_Motivo = 9300
                       And Rp.Cd_Remessa = Ce.Cd_Remessa_Remessa
                       And Ip.Cd_Lancamento = Ce.Cd_Lancamento_Itremaudit)
            
            )
  
   Loop
  
    Begin
    
      Update Dbaps.Itremessa_Prestador_Equipe Ipe
         Set Ipe.Cd_Motivo = 62
       Where Ipe.Cd_Remessa = i.Cd_Remessa
         And Ipe.Cd_Lancamento = i.Cd_Lancamento;
    
      Update Dbaps.Itremessa_Prestador Ip
         Set Ip.Cd_Motivo = 62, Ip.Tp_Pagcob = 'NN'
       Where Ip.Cd_Remessa = i.Cd_Remessa
         And Ip.Cd_Lancamento = i.Cd_Lancamento;
    
      Dbms_Output.Put_Line('Conta Atualizada: ' || i.Cd_Remessa ||
                           ' Lancamento: ' || i.Cd_Lancamento);
    End;
  
  End Loop;
End;
