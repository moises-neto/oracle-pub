/*

* se tem NN sem glosa: exemplo 426733 - lote 12050066 - conta
* conta com a CONTA AA por�m, item NA
* H� item com valor individual cobrado 0,00 ou 0,01 com CP para for�ar valor.
Cuidado com mens contrat, se tiver n�o altera, s� manda relat�rio para cobrarmos certo depois.
* extrair relat�rio da compet�ncia, pagamento CP fora do prazo de 60 dias da execu��o - mostrar para Fernanda antes de pagar

*/
Declare

  Vcontador Pls_Integer := 0;
Begin

  For i In (Select x.*
            
              From (Select v.Cd_Lote,
                           v.Cd_Conta_Medica,
                           v.Cd_Procedimento,
                           v.Cd_Lancamento,
                           v.Tp_Pagcob,
                           v.Tp_Conta,
                           v.Tp_Situacao_Conta,
                           v.Cd_Motivo,
                           v.Cd_Motivo_Alta,
                           v.Cd_Motivo_Conta,
                           v.Cd_Motivo_Itconta,
                           v.Cd_Motivo_Equipe,
                           v.Cd_Prestador,
                           (Select p.Nm_Prestador
                              From Dbaps.Prestador p
                             Where p.Cd_Prestador = v.Cd_Prestador) As Nm_Prestador,
                           (Select Distinct Vf.Cd_Mens_Contrato
                              From Dbaps.v_Ctas_Medicas_Fatura Vf
                             Where Vf.Cd_Lote = v.Cd_Lote
                               And Vf.Cd_Conta_Medica = v.Cd_Conta_Medica
                               And Vf.Cd_Lancamento = v.Cd_Lancamento
                                  
                               And Rownum = 1) As Mens_Contrato
                    
                      From v_Ctas_Medicas v
                     Where v.Dt_Competencia = '202207'
                       And v.Tp_Pagcob = 'NN'
                       And v.Sn_Fatura_Fechada = 'S'
                       And v.Cd_Motivo_Itconta Is Null) x
            
            ) Loop
    Vcontador := Vcontador + 1;
  
    Begin
      If (i.Tp_Conta = 'A') Then
        --sadt equipe
      
        Update Dbaps.Itremessa_Prestador_Equipe Ipe
           Set Ipe.Cd_Motivo = 24, Ipe.Tp_Situacao = 'GT'
         Where Ipe.Cd_Remessa = i.Cd_Conta_Medica
           And Ipe.Cd_Lancamento = i.Cd_Lancamento;
      
        --sadt Itens
        Update Dbaps.Itremessa_Prestador Ipe
           Set Ipe.Cd_Motivo = 24, Ipe.Tp_Situacao = 'GT'
         Where Ipe.Cd_Remessa = i.Cd_Conta_Medica
           And Ipe.Cd_Lancamento = i.Cd_Lancamento;
      
      Else
        --Internacao
        Update Dbaps.Itconta_Med Ip
           Set Ip.Cd_Motivo = 24, Ip.Tp_Situacao = 'GT'
         Where Ip.Cd_Conta_Hospitalar = i.Cd_Conta_Medica
           And Ip.Cd_Lancamento = i.Cd_Lancamento;
      
        Update Dbaps.Itconta_Hospitalar Ip
           Set Ip.Cd_Motivo = 24, Ip.Tp_Situacao = 'GT'
         Where Ip.Cd_Conta_Hospitalar = i.Cd_Conta_Medica
           And Ip.Cd_Lancamento = i.Cd_Lancamento;
      
      End If;
    End;
    If (Vcontador >= 100) Then
    
      Commit;
      Vcontador := 0;
    End If;
  
  End Loop;

End;
