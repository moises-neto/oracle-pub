Declare

Begin

  --desabilitando, necess�rio pois pode ocorrer que o valor pago seja superior ao valor cobrado.
  /* Begin
    Execute Immediate 'Alter Trigger DBAPS.trg_itremessa_prestador_equipe Disable';
    Execute Immediate 'Alter Trigger DBAPS.trg_itconta_med Disable';
  End;
       */

  /*Select Count(Distinct t.cd_conta)
  From Dbaps.Log_Conta_Lote_Recalc t; */ 
  
  ---Delete From Log_Conta_Lote_Recalc
Declare
Begin
  
    Dbamv.Pkg_Mv2000.Atribui_Empresa('1');

  For i In (Select v.Cd_Lote, v.Cd_Conta_Medica, v.Cd_Lancamento
              From temp_contas_audit_202303 v
             Where Not Exists
             (Select 1
                      From Log_Conta_Lote_Recalc l
                     Where l.Cd_Conta = v.Cd_Conta_Medica)) Loop
  
    Begin
      --PAGAMENTO
      Dbaps.Prc_Recalcula_Valor_Proced_V4(Pcd_Lote           => i.Cd_Lote,
                                          Pcd_Conta_Medica   => i.Cd_Conta_Medica,
                                        --  Pcd_Lancamento     => i.Cd_Lancamento,
                                          Ptp_Calculo        => 'P',
                                          Psn_Calcula_Equipe => 'S',
                                          Ptp_Regra          => 'P',
                                          Psn_Apenas_Taxa    => 'N');
    
      Begin
        Insert Into Log_Conta_Lote_Recalc
          (Cd_Lote, Cd_Conta)
        Values
          (i.Cd_Lote, i.Cd_Conta_Medica);
        Commit;
      End;
    
    Exception
      When Others Then
        Raise_Application_Error(-20002,
                                'Erro ao Recalcular: Prc_Recalcula_Valor_Proced_V4 ' ||
                                Sqlerrm);
      
    End;
  
  End Loop;
  --Habilitando
  /*Begin
    Execute Immediate 'Alter Trigger DBAPS.trg_itremessa_prestador_equipe enable';
    Execute Immediate 'Alter Trigger DBAPS.trg_itconta_med enable';
  End;*/

Exception
  When Others Then
    Raise_Application_Error(-20099, 'Erro n�o tratado: ' || Sqlerrm);
End;



--RECALCULO INTERC�MBIO (necess�rio cancelar auditoria interc�mbio antes)


Declare

Begin
  For Ix In (Select v.Cd_Lote, v.Cd_Conta_Medica, v.Cd_Lancamento
               From Temp_Contas_Hosp_Acerto_V2 v) Loop
  
    Begin
      Dbaps.Prc_Gera_Fat_Conta_Medica_v4(Ix.Cd_Lote, Ix.Cd_Conta_Medica, 'T', 'S', 1);
      dbaps.prc_debug_log(v_ds_log => 'entrou ' || Ix.Cd_Conta_Medica);
    End;
  
  End Loop;
End;



