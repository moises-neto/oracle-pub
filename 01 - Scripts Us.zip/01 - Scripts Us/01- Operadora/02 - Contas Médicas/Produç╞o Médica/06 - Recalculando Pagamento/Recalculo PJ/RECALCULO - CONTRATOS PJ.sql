/*
Solicito desenvolvimento de rotina para recalculo quando h� reajuste de contratos PJ.

O filtro dever� ser:
Compet�ncia
Prestador:
Procedimento:
Rotina de recalcular:
*Abrir lote, caso esteja fechado
*cancelar Auditoria de todas as contas do lote
*recalcular valor cobrado (caso o campo I_ITCONTA_HOSPITALAR_FATURA.CD_PRESTADOR esteja em branco >>> se estiver preenchido n�o usar essa condi��o.
* recalcular valor pago
* Auditar todas as contas do lote
* fechar lote
*/

/*ATEN��O: Antes de iniciar, dever� setar o prestador na trigger DBAPS.TRG_ITREMESSA_PRESTADOR_EQUIPE no bloco:
 IF nCdPrestador Not In (300100) THEN
            Raise_Application_Error(-20001,
                                    'TRG ITREMESSA EQP AMB. >> Conta ('||TO_CHAR(:new.cd_remessa)||'), Item ('||TO_CHAR(:new.cd_lancamento)||
                                    '). O valor PAGO ('||TO_CHAR(nValorPago)||') do evento nao pode ser superior ao valor COBRADO ('||TO_CHAR(nValorCobrado)||
                                    '). Corrija os valores de forma que o valor PAGO seja IGUAL ou INFERIOR ao valor COBRADO.!');
          END IF;

E na trigger DBAPS.trg_itconta_med

 IF nCdPrestador <> 300100 THEN
            Raise_Application_Error(-20001,
                                    'TRG ITCONTA EQP HOSP. >> Conta ('||TO_CHAR(:NEW.cd_conta_hospitalar)||', Item ('||TO_CHAR(:NEW.cd_lancamento)||
                                    '. O valor PAGO ('||TO_CHAR(nValorPago)||') do evento nao pode ser superior ao valor COBRADO ('||TO_CHAR(nValorCobrado)||
                                    '). Corrija os valores de forma que o valor PAGO seja IGUAL ou INFERIOR ao valor COBRADO!');
          END IF; 
*/

-- Select p.*, Rowid From  custom.proc_reajuste_pf p

Declare

  Cursor Cdadoscontaprest Is
Select v.Dt_Competencia,
       v.Cd_Fatura,
       v.Cd_Lote,
       v.Cd_Conta_Medica,
       v.Cd_Prestador,
       v.Cd_Lancamento,
       v.Cd_Procedimento,
       v.Dt_Realizado,
       v.Vl_Unit_Pago,
       v.Vl_Total_Pago,
       v.Sn_Lote_Fechado,
       v.Tp_Pagamento,
       v.Tp_Pagcob

  From Dbaps.v_Ctas_Medicas v

 Where v.Dt_Competencia = To_Char(Sysdate, 'YYYYMM')
      
   And Trunc(v.Dt_Realizado) >= '01/06/2023'  
   And v.cd_procedimento Not In('10101012','10101057','10101058')
   And Substr(v.cd_procedimento,1,1) In ('1','2','4','5','6')
   And v.Cd_Prestador_Principal In
       (100013,100023)
      -- And Exists ( Select 1 From proc_moises p Where p.cd_procedimento = v.cd_procedimento)
      
   And v.Tp_Pagcob In ('CP', 'PN')
      
      /*  And Substr(v.Cd_Procedimento, 0, 4) In
          ('2010', '4080', '4060', '4040', '4090', '4110', '4070')
      */
      
      /*  And Exists (Select 1
                From Dbaps.Procedimento p
               Where p.Cd_Procedimento = v.Cd_Procedimento
                 And p.Cd_Grupo_Procedimento In ('1006','1007','1010','1018')
      )*/
      
   And Not Exists (Select 1
          From Custom.Cnt_Recalculo_Pj Crp
         Where Crp.Cd_Conta_Medica = v.Cd_Conta_Medica
           And Crp.Cd_Lancamento = v.Cd_Lancamento
           And trunc(crp.dt_log) = Trunc(Sysdate));

  --And v.Cd_Lancamento = 1;

  Vdadoscontaprest Cdadoscontaprest%Rowtype;

Begin

  --desabilitando, necess�rio pois pode ocorrer que o valor pago seja superior ao valor cobrado.
  Begin
    Execute Immediate 'Alter Trigger DBAPS.trg_itremessa_prestador_equipe Disable';
    Execute Immediate 'Alter Trigger DBAPS.trg_itconta_med Disable';
  End;

  Begin
    Dbamv.Pkg_Mv2000.Atribui_Empresa('1');
  End;
  For i In Cdadoscontaprest Loop
    Begin
      Insert Into Custom.Cnt_Recalculo_Pj
        (Cd_Cnt_Recalculo_Pj,
         Dt_Competencia,
         Cd_Fatura,
         Cd_Lote,
         Cd_Conta_Medica,
         Cd_Prestador_Pag,
         Cd_Prestador_Cob,
         Cd_Lancamento,
         Cd_Procedimento,
         Vl_Unit_Pago_Old,
         Vl_Total_Pago_Old,
         Tp_Pagamento,
         Sn_Lote_Fechado,
         Dt_Log)
      Values
        (Custom.Seq_Cnt_Recalculo_Pj.Nextval,
         i.Dt_Competencia,
         i.Cd_Fatura,
         i.Cd_Lote,
         i.Cd_Conta_Medica,
         i.Cd_Prestador,
         Null,
         i.Cd_Lancamento,
         i.Cd_Procedimento,
         i.Vl_Unit_Pago,
         i.Vl_Total_Pago,
         i.Tp_Pagamento,
         i.Sn_Lote_Fechado,
         Sysdate);
      Commit;
    Exception
      When Others Then
        Raise_Application_Error(-20001,
                                'Erro ao inserir na Custom.Cnt_Recalculo_Pj: ' ||
                                Sqlerrm);
      
    End;
    Commit;
    /* Begin
      --COBRAN�A
      Dbaps.Prc_Recalcula_Valor_Proced_V4(Pcd_Lote           => i.Cd_Lote,
                                          Pcd_Conta_Medica   => i.Cd_Conta_Medica,
                                          Pcd_Lancamento     => i.Cd_Lancamento,
                                          Ptp_Calculo        => 'C',
                                          Psn_Calcula_Equipe => 'S',
                                          Ptp_Regra          => 'P',
                                          Psn_Apenas_Taxa    => 'N');
    Exception
      When Others Then
        Raise_Application_Error(-20002,
                                'Erro ao Recalcular: Prc_Recalcula_Valor_Proced_V4 ' ||
                                Sqlerrm);
      
    End;*/
  
    Begin
      --PAGAMENTO
      Dbaps.prc_recalcula_valor_proced_moises(Pcd_Lote           => i.Cd_Lote,
                                          Pcd_Conta_Medica   => i.Cd_Conta_Medica,
                                          Pcd_Lancamento     => i.Cd_Lancamento,
                                          Ptp_Calculo        => 'P',
                                          Psn_Calcula_Equipe => 'S',
                                          Ptp_Regra          => 'P',
                                          Psn_Apenas_Taxa    => 'N');
    Exception
      When Others Then
        Raise_Application_Error(-20002,
                                'Erro ao Recalcular: Prc_Recalcula_Valor_Proced_V4 ' ||
                                Sqlerrm);
      
    End;
  
  End Loop;
  --Habilitando
  Begin
    Execute Immediate 'Alter Trigger DBAPS.trg_itremessa_prestador_equipe enable';
    Execute Immediate 'Alter Trigger DBAPS.trg_itconta_med enable';
  End;

Exception
  When Others Then
    Raise_Application_Error(-20099, 'Erro n�o tratado: ' || Sqlerrm);
End;

