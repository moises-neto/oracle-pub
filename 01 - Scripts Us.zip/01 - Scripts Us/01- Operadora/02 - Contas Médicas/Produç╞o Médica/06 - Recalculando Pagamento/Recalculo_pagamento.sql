Declare
    
Begin

  For i In (Select v.Cd_Lote,
                   v.Cd_Conta_Medica,
                   v.Cd_Procedimento,
                   v.Cd_Lancamento,
                   v.vl_total_pago_original,
                   v.Tp_Pagcob,
                   v.Tp_Situacao
              From Dbaps.v_Ctas_Medicas v
             Where v.cd_fatura = 40407
               And v.Tp_Pagcob In ('CP', 'PN')
               And v.Tp_Situacao Not In ('GA', 'GT')
               And v.vl_total_pago_original = '0,01'
               
            Union
            
            Select v.Cd_Lote,
                   v.Cd_Conta_Medica,
                   v.Cd_Procedimento,
                   v.Cd_Lancamento,
                   v.vl_total_pago_original,
                   v.Tp_Pagcob,
                   v.Tp_Situacao
              From Dbaps.v_Ctas_Medicas v
             Where v.cd_fatura = 40407
               And v.Tp_Pagcob In ('CP', 'PN')
               And v.Tp_Situacao Not In ('GA', 'GT')
               And v.vl_total_pago_original = '0') Loop
  
    Begin
      Dbaps.Prc_Recalcula_Valor_Proced_V4(Pcd_Lote           => i.Cd_Lote,
                                          Pcd_Conta_Medica   => i.Cd_Conta_Medica,
                                          Pcd_Lancamento     => i.Cd_Lancamento,
                                          Ptp_Calculo        => 'P',
                                          Psn_Calcula_Equipe => 'S',
                                          Ptp_Regra          => 'P');
    
      /*Dbaps.Prc_Recalcula_Valor_Proced(Pcd_Lote           => i.Cd_Lote,
      Pcd_Conta_Medica   => i.Cd_Conta_Medica,
      Pcd_Lancamento     => i.Cd_Lancamento,
      Ptp_Calculo        => 'C',
      Psn_Calcula_Equipe => 'S',
      Ptp_Regra          => 'P',
      Psn_Apenas_Taxa    => 'N'); */
    
    End;
  
  End Loop;
Exception
  When Others Then
    Raise_Application_Error(-20001, 'Falha' || Sqlerrm);
End;
