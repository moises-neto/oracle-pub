

--capa da folha
Select * From pagamento_prestador pp
Where pp.cd_pagamento_prestador = 979;
 --corpo da folha
 Select * From PAGAMENTO_P ip
Where ip.cd_pagamento_prestador = 979
And IP.CD_PRESTADOR = 1004171;

--Repasse da folha
Select * From repasse_prestador rp
Where rp.cd_pagamento_prestador = 995;



---CANCELA A FOLHA E REPASSE DE UM PRESTADOR POR FOLHA.

dbaps.prc_cancela_pag_prestador(PCD_PAGAMENTO_PRESTADOR => ,
                                PCD_PRESTADOR           => );
