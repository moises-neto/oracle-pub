--IMPORTAR TABELA.
Select Rowid, t.*
  From Dbaps.Tmp_Prest_Cred_Deb_Ajuste t
  Where T.CD_PRES_CR_DB = 1
  
 Where t.Nr_Guia Is Not Null
 And t.nr_guia_externa Is Not Null;

Select Count(*) From Dbaps.Tmp_Prest_Cred_Deb_Ajuste t;

Delete  From dbaps.Tmp_Prest_Cred_Deb_Ajuste

--3910
--18

--3889

--IMPORTAR TABELA.
Select t.Cd_Fatura,
       t.Cd_Prestador,
       t.Vl_Lancamento,
       t.Cd_Glosa_Referencia,
       t.Ds_Observacao,
       t.Cd_Item_Despesa,
       t.Nr_Guia,
       t.Cd_Procedimento
  From Dbaps.Tmp_Prest_Cred_Deb_Ajuste t
       
       /*TAB=PROCEDIMENTO_NAO_ENCONTRADO*/
         Select t.Cd_Pres_Cr_Db,
                t.Cd_Fatura,
                t.Cd_Prestador,
                t.Tp_Lancamento,
                t.Vl_Lancamento,
                t.Cd_Glosa_Referencia,
                t.Ds_Observacao,
                t.Cd_Item_Despesa,
                t.Nr_Guia,
                t.Nr_Guia_Externa,
                Custom.Fnc_Limpa_Campo_Numerico(t.Cd_Procedimento) Cd_Procedimento,
                t.Sn_Exibe,
                t.Carteira,
                t.Tp_Auditoria,
                t.Tp_Motivo,
                t.Sn_Rateio
         
           From Tmp_Prest_Cred_Deb_Ajuste t
          Where Not Exists
          (Select 1
                   From Dbaps.Prestador_Credito_Debito Pc
                  Where Pc.Cd_Fatura = t.Cd_Fatura
                    And Pc.Cd_Prestador = t.Cd_Prestador
                    And Pc.Cd_Procedimento =
                        Trim(Custom.Fnc_Limpa_Campo_Numerico(t.Cd_Procedimento))
                    And Pc.Vl_Lancamento = t.Vl_Lancamento
                    And Pc.Cd_Mat_Alternativa = t.Carteira
                    And ((t.Nr_Guia Is Not Null And Pc.Nr_Guia = t.Nr_Guia) Or
                        (t.Nr_Guia_Externa Is Not Null And
                        Pc.Nr_Guia_Externa = t.Nr_Guia_Externa))
                    And Trunc(Pc.Dt_Inclusao) = Trunc(Sysdate))
            And (Not Exists
                 (Select 1
                    From Dbaps.Procedimento Po
                   Where Po.Cd_Procedimento = Trim(t.Cd_Procedimento)) And
                 Trim(t.Cd_Procedimento) Is Not Null);

 /* Guias n�o encontradas*/
 
    ---CONSULTA GUIA
          
          Select t.*
            From Dbaps.Tmp_Prest_Cred_Deb_Ajuste t
           Where 1 = 1
             And t.Nr_Guia Is Not Null
             And t.Nr_Guia_Externa Is Null
             And Not Exists
           (Select 1
                    From dbaps.guia g
                   Where g.Nr_Guia = Trim(t.Nr_Guia))

Begin
  Dbamv.Pkg_Mv2000.Atribui_Empresa('1');
End;

Call Custom.pkg_conmvs_prod_med.Prc_Insere_Desconto_Glosa(p_Usuario => 'DBORBA');

--confe�ncia 
Select Pc.*
  From Dbaps.Prestador_Credito_Debito Pc
 Where Exists
 (Select 1
          From Tmp_Prest_Cred_Deb_Ajuste t
         Where Pc.Cd_Fatura = Custom.Fnc_Limpa_Campo_Numerico(t.Cd_Fatura)
           And Pc.Cd_Prestador =
               Custom.Fnc_Limpa_Campo_Numerico(t.Cd_Prestador)
           And (Pc.Cd_Procedimento =
               Custom.Fnc_Limpa_Campo_Numerico(t.Cd_Procedimento) Or
               (t.Cd_Procedimento Is Null And Pc.Cd_Procedimento Is Null))
           And Pc.Vl_Lancamento = t.Vl_Lancamento
           And Pc.Cd_Mat_Alternativa = t.Carteira
           And ((t.Nr_Guia Is Not Null And Pc.Nr_Guia = t.Nr_Guia) Or
               (t.Nr_Guia_Externa Is Not Null And
               Pc.Nr_Guia_Externa = t.Nr_Guia_Externa) Or
               Pc.Nr_Guia_Externa = t.Nr_Guia)
           And Trunc(Pc.Dt_Inclusao) = Trunc(Sysdate));

--Verifica diverg�ncias
Select t.Cd_Fatura,
       t.Cd_Prestador,
       t.Vl_Lancamento,
       t.Cd_Glosa_Referencia,
       t.Ds_Observacao,
       t.Cd_Item_Despesa,
       t.Nr_Guia,
       t.Cd_Procedimento
  From Dbaps.Tmp_Prest_Cred_Deb_Ajuste t

Minus

Select Pc.Cd_Fatura,
       Pc.Cd_Prestador,
       Pc.Vl_Lancamento,
       Pc.Cd_Glosa_Referencia,
       Pc.Ds_Observacao,
       Pc.Cd_Item_Despesa,
       Pc.Nr_Guia,
       Pc.Cd_Procedimento

  From Dbaps.Prestador_Credito_Debito Pc
 Where Trunc(Pc.Dt_Inclusao) = Trunc(Sysdate);

        
                
--Olha o que entrou 
 

Select Pc.*
  From Dbaps.Prestador_Credito_Debito Pc
 Where Not Exists

 (Select 1
          From Dbaps.Tmp_Prest_Cred_Deb_Ajuste t
         Where t.Cd_Fatura = Pc.Cd_Fatura
           And t.Cd_Prestador = Pc.Cd_Prestador
           And t.Vl_Lancamento = Pc.Vl_Lancamento
           And (t.Nr_Guia = Pc.Nr_Guia Or
               t.Nr_Guia_Externa = Pc.Nr_Guia_Externa)
           And t.Cd_Procedimento = Pc.Cd_Procedimento
        
        )
   And Trunc(Pc.Dt_Inclusao) = Trunc(Sysdate)
   
   
                
                
        
     
