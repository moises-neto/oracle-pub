Select P.*, ROWID From DBAPS.PTU_CONTROLE_INTERCAMBIO p
Where p.cd_ptu_remessa_retorno IN('395117','395119','427095','438975');


select * From DBAPS.PTU_REMESSA_RETORNO pr
Where pr.ds_arquivo like '%NR9_1611338_1%'
oR PR.DS_ARQUIVO like '%NR9_1617953.048%'
oR PR.DS_ARQUIVO like '%NR9_1576197.284%'
oR PR.DS_ARQUIVO like '%NR9_1562260.865%'
And pr.tp_arquivo = 'A550'
