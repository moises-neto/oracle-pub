CREATE OR REPLACE PROCEDURE prc_pag_prestador_param(PCD_PAGAMENTO_PRESTADOR IN NUMBER) IS

  /**************************************************************
    <objeto>
     <nome>PRC_PAG_PRESTADOR_PARAM</nome>
     <usuario>Maikon Oliveira</usuario>
     <alteracao>25/06/2020 08:00</alteracao>
     <ultimaAlteracao>
     Adicionado condicional para numero de nota fiscal de protocolo (Maikon Oliveira)
     </ultimaAlteracao>
     <descricao>PROCEDURE REALIZA PROCESSAMENTO DOS PARAMETROS DA FOLHA DO COOPERADO</descricao>
     <parametro>PCD_PAGAMENTO_PRESTADOR - C�digo da folha de pagamento</parametro>
     <tags>folha, pagamento, prestador, repasse</tags>
     <versao>1.21</versao>
     <soul>PLANO-01-146</soul>
    </objeto>
  ***************************************************************/

  --DADOS DA FOLHA DE PAGAMENTO
  CURSOR cFolhaJaFaturada(PCD_FATURA IN NUMBER, PCD_PRESTADOR IN NUMBER) IS
    SELECT P.CD_PAGAMENTO_PRESTADOR, P.DT_COMPETENCIA, 'FOLHA' TP_PAGAMENTO
      FROM DBAPS.PAGAMENTO_PRESTADOR P, DBAPS.ITPAGAMENTO_PRESTADOR I
     WHERE P.CD_PAGAMENTO_PRESTADOR = I.CD_PAGAMENTO_PRESTADOR
       AND P.CD_PAGAMENTO_PRESTADOR <> PCD_PAGAMENTO_PRESTADOR
       AND I.CD_FATURA = PCD_FATURA
       AND I.CD_PRESTADOR = PCD_PRESTADOR
    UNION ALL
    SELECT CD_REPASSE_PRESTADOR CD_PAGAMENTO_PRESTADOR,
           RP.DT_USUARIO_REPASSE DT_COMPETENCIA,
           'REPASSE' TP_PAGAMENTO
      FROM DBAPS.REPASSE_PRESTADOR RP
     WHERE RP.CD_FATURA = PCD_FATURA
       AND RP.CD_PRESTADOR = PCD_PRESTADOR
       AND RP.CD_CON_PAG IS NOT NULL;

  --
  CURSOR cPagamentoPrestador IS
    SELECT *
      FROM DBAPS.PAGAMENTO_PRESTADOR
     WHERE CD_PAGAMENTO_PRESTADOR = PCD_PAGAMENTO_PRESTADOR;
  --
  CURSOR cTipPrestador(PCD_TIP_PRESTADOR IN NUMBER) IS
    SELECT TP_TIP_PRESTADOR
      FROM dbaps.tip_prestador
     WHERE cd_tip_prestador = PCD_TIP_PRESTADOR;
  --
  CURSOR cExisteContaPagar IS
    SELECT 1
      FROM DBAPS.REPASSE_PRESTADOR
     WHERE CD_PAGAMENTO_PRESTADOR = PCD_PAGAMENTO_PRESTADOR
       AND CD_CON_PAG IS NOT NULL;

  -- busca a nota fiscal vinculada na tela M_NOTA_FISCAL_PROTOCOLO
  CURSOR cNotaFiscalProtocolo(PCD_FATURA    IN NUMBER,
                              PCD_PRESTADOR IN NUMBER) IS
    SELECT NFP.NR_NOTA_FISCAL
      FROM DBAPS.NOTA_FISCAL_PROTOCOLO   NFP,
           DBAPS.ITNOTA_FISCAL_PROTOCOLO INFP
     WHERE NFP.CD_NOTA_FISCAL = INFP.CD_NOTA_FISCAL
       AND INFP.CD_FATURA = PCD_FATURA
       AND NFP.CD_PRESTADOR = PCD_PRESTADOR;

  -- Chave que indica se vai ter rateio para os coperados
  CURSOR cMvsConfiguracao(P_CHAVE IN VARCHAR2, PCD_MULTI_EMPRESA IN NUMBER) IS
    SELECT VALOR
      FROM DBAPS.MVS_CONFIGURACAO
     WHERE CHAVE = P_CHAVE
       AND CD_MULTI_EMPRESA =
           Nvl(PCD_MULTI_EMPRESA, DBAMV.PKG_MV2000.LE_EMPRESA);

  -- Verifica se existe Coperado para esse prestador.
  CURSOR cBuscaCoperados(P_CD_PRESTADOR_PRINCIPAL IN NUMBER) IS
    SELECT P.CD_PRESTADOR
      FROM DBAPS.PRESTADOR_ASSOCIADO PA,
           DBAPS.PRESTADOR           P,
           DBAPS.TIP_PRESTADOR       TIP
     WHERE PA.CD_PRESTADOR = P_CD_PRESTADOR_PRINCIPAL
       AND PA.CD_PRESTADOR_ASSOCIADO = P.CD_PRESTADOR
       AND P.CD_TIP_PRESTADOR = TIP.CD_TIP_PRESTADOR
       AND P.TP_SITUACAO = 'A'
       AND TIP.TP_TIP_PRESTADOR = '6'; -- COPERADO

  -- Verifica se ja existe na tabela de parametros esse prestador.
  CURSOR cVerificaSeJaExistePrestador(P_CD_PRESTADOR IN NUMBER,
                                      P_CD_FATURA    IN NUMBER) IS
    SELECT COUNT(1) QTD
      FROM DBAPS.ITPAGAMENTO_PRESTADOR ITP
     WHERE ITP.CD_FATURA = P_CD_FATURA
       AND ITP.CD_PRESTADOR = P_CD_PRESTADOR;

  -- Verifica se esse prestador est� habilitado para o Rateio entre os coperados
  CURSOR cVerificaPrestadorFlagRateio(P_CD_PRESTADOR IN NUMBER) IS
    SELECT Trim(D.CD_CODIGO_EXTERNO)CD_CODIGO_EXTERNO
      FROM DBAPS.SISTEMA_TERCEIRO      S,
           DBAPS.TIPO_PROCESSO_DE_PARA TP,
           DBAPS.DE_PARA_INTEGRA_TEXTO D
     WHERE S.CD_SISTEMA_TERCEIRO = D.CD_SISTEMA_TERCEIRO
       AND TP.CD_TIPO_PROCESSO_DE_PARA = D.CD_TIPO_PROCESSO_DE_PARA
        AND TP.DS_TIPO_PROCESSO_DE_PARA LIKE 'FOLHA DE PAGAMENTO DO PRESTADOR'
       AND D.CD_CODIGO_SISTEMA = P_CD_PRESTADOR
       AND Trim(D.CD_CODIGO_EXTERNO) = 'S';

  --
  TYPE rPrestadores IS RECORD(
    cd_fatura         NUMBER,
    cd_prestador      NUMBER,
    sn_fechado        VARCHAR2(1),
    tp_credenciamento VARCHAR2(1),
    cd_contrato       NUMBER,
    tipo_folha        VARCHAR2(50));
  --
  TYPE cQueryType IS REF CURSOR;
  --
  cProcessaRepasse cQueryType;
  r                rPrestadores;
  --
  TYPE TFATINVALIDA IS RECORD(
    CD_FATURA NUMBER);
  --
  TYPE TPRESSEMCONTRATO IS RECORD(
    CD_PRESTADOR NUMBER);
  --
  TYPE AFATINVALIDA IS TABLE OF TFATINVALIDA INDEX BY BINARY_INTEGER;
  --
  TYPE APRESSEMCONTRATO IS TABLE OF TPRESSEMCONTRATO INDEX BY BINARY_INTEGER;
  --
  vFaturasInvalidas            AFATINVALIDA;
  vPrestSemContrato            APRESSEMCONTRATO;
  rPagamentoPrestador          cPagamentoPrestador%ROWTYPE;
  rFolhaJaFaturada             cFolhaJaFaturada%ROWTYPE;
  rVerificaSeJaExistePrestador cVerificaSeJaExistePrestador%ROWTYPE;
  vExcecao                     VARCHAR2(32000);
  vExcecaoLinha                VARCHAR2(32000);
  nQtdRegistrosInseridos       NUMBER;
  vTpStatus                    VARCHAR2(1);
  rExisteContaPagar            VARCHAR2(1);
  vDsMensagemAlerta            VARCHAR2(32000);
  iIterator                    NUMBER;
  vQuery                       VARCHAR2(10000);
  vQueryFatura                 VARCHAR2(10000);
  vQueryVencimento             VARCHAR2(10000);
  vQueryCompetencia            VARCHAR2(10000);
  vQueryCompAcrescimo          VARCHAR2(10000);
  vQueryPrestador              VARCHAR2(10000);
  vQueryFechamento             VARCHAR2(10000);
  nContador                    NUMBER;
  nCdMultiEmpresa              NUMBER;
  nNrNotaFiscal                NUMBER;
  nTipoPrestador               NUMBER(3);
  vSnRateio                    VARCHAR2(1);
  vPrestadorTemRateio          VARCHAR2(1);
  --
BEGIN
  IF PCD_PAGAMENTO_PRESTADOR IS NULL THEN
    RAISE_APPLICATION_ERROR(-20999,
                            'INFORME O C�DIGO DO PRESTADOR PAGAMENTO.');
  END IF;
  --
  nCdMultiEmpresa := DBAMV.PKG_MV2000.LE_EMPRESA;
  --
  OPEN cExisteContaPagar;
  FETCH cExisteContaPagar
    INTO rExisteContaPagar;
  --
  IF cExisteContaPagar%FOUND THEN
    Raise_Application_Error(-20999,
                            'ERRO: CONTA A PAGAR J� GERADA PARA ESSA FOLHA, N�O E POSS�VEL PROCESSAR COM A CONTA A PAGAR GERADA.');
  END IF;
  CLOSE cExisteContaPagar;
  --
  DELETE DBAPS.ITPAGAMENTO_PRESTADOR
   WHERE CD_PAGAMENTO_PRESTADOR = PCD_PAGAMENTO_PRESTADOR;
  --
  OPEN cPagamentoPrestador;
  FETCH cPagamentoPrestador
    INTO rPagamentoPrestador;
  CLOSE cPagamentoPrestador;
  --
  nQtdRegistrosInseridos := 0;
  vQuery                 := NULL;
  vQueryFatura           := NULL;
  vQueryPrestador        := NULL;
  vQueryVencimento       := NULL;
  vQueryCompetencia      := NULL;
  vQueryCompAcrescimo    := NULL;
  vQueryFechamento       := NULL;
  --
  vQuery := 'SELECT CD_FATURA,
                    CD_PRESTADOR,
                    SN_FECHADO,
                    TP_CREDENCIAMENTO,
                    CD_CONTRATO,
                    TIPO_FOLHA
               FROM (
                     --PRODUCAO_MEDICA - PF
                     SELECT DISTINCT VCM.CD_FATURA,
                                     VCM.CD_PRESTADOR_PAGAMENTO CD_PRESTADOR,
                                     F.SN_FECHADO,
                                     P.TP_CREDENCIAMENTO,
                                     C.CD_CONTRATO,
                                     ''PRODUCAO_MEDICA'' TIPO_FOLHA
                        FROM DBAPS.V_CTAS_MEDICAS VCM,
                             DBAPS.PRESTADOR      P,
                             DBAPS.CONTRATO       C,
                             DBAPS.FATURA         F,
                             DBAPS.TIP_PRESTADOR  TP
                       WHERE VCM.CD_FATURA = F.CD_FATURA
                         AND P.CD_MULTI_EMPRESA = F.CD_MULTI_EMPRESA
                         AND VCM.CD_PRESTADOR_PAGAMENTO = P.CD_PRESTADOR
                         AND P.CD_TIP_PRESTADOR = TP.CD_TIP_PRESTADOR
                         AND P.CD_PRESTADOR = C.CD_PRESTADOR(+)';

  IF rPagamentoPrestador.cd_fatura IS NOT NULL THEN

    IF INSTR(TRIM(rPagamentoPrestador.cd_fatura), ',') > 0 THEN

      nContador := 0;

      FOR rFaturas IN (SELECT *
                         FROM (SELECT REGEXP_SUBSTR(STR, '[^,]+', 1, ROWNUM) SPLIT
                                 FROM (SELECT '' ||
                                              rPagamentoPrestador.cd_fatura || '' STR
                                         FROM DUAL)
                               CONNECT BY LEVEL <=
                                          LENGTH(REGEXP_REPLACE(STR, '[^,]+')) + 1)
                        WHERE SPLIT IS NOT NULL) LOOP

        IF nContador = 0 THEN
          vQueryFatura := vQueryFatura || ' AND F.CD_FATURA IN (' ||
                          rFaturas.SPLIT;
        ELSIF nContador > 0 THEN
          vQueryFatura := vQueryFatura || ', ' || TO_CHAR(rFaturas.SPLIT);
        END IF;

        nContador := nContador + 1;

      END LOOP;

      IF nContador > 0 THEN
        vQueryFatura := vQueryFatura || ') ';
      END IF;

    ELSE
      vQueryFatura := vQueryFatura || ' AND F.CD_FATURA = ' ||
                      TO_CHAR(rPagamentoPrestador.cd_fatura);
    END IF;

  END IF;

   IF rPagamentoPrestador.CD_FATURA IS NULL AND rPagamentoPrestador.NR_NOTA_FISCAL IS NOT NULL THEN

      vQueryFatura := vQueryFatura || ' AND F.CD_FATURA IN( SELECT IFP.CD_FATURA
                                                            FROM DBAPS.NOTA_FISCAL_PROTOCOLO NFP,
                                                            DBAPS.ITNOTA_FISCAL_PROTOCOLO IFP
                                                            WHERE NFP.CD_NOTA_FISCAL = IFP.CD_NOTA_FISCAL
                                                            AND NFP.NR_NOTA_FISCAL IN('|| TO_CHAR(rPagamentoPrestador.NR_NOTA_FISCAL)  ||')';

    IF rPagamentoPrestador.CD_PRESTADOR IS NOT NULL THEN

     vQueryFatura := vQueryFatura || ' AND NFP.CD_PRESTADOR = ' ||
                       TO_CHAR(rPagamentoPrestador.cd_prestador)||')';
     ELSE

     vQueryFatura := vQueryFatura || ') ';

     END IF;

   END IF;

  vQuery := vQuery || vQueryFatura;

  -- TIPO DA FATURA [PAGAMENTO]
  IF rPagamentoPrestador.TP_FATURA ='P' THEN

  vQuery := vQuery || ' AND F.TP_FATURA = ''P''
                        AND F.SN_REFATURAR = ''N'' ';

  -- TIPO DA FATURA [COBRAN�A]
  ELSIF  rPagamentoPrestador.TP_FATURA ='C' THEN

    vQuery := vQuery || ' AND F.TP_FATURA = ''C''
                          AND F.SN_REFATURAR = ''N''
                          AND(nvl(F.TP_PAGAMENTO, ''P'') = ''P'')
                          AND NOT EXISTS (SELECT 1 FROM DBAPS.REPASSE_PRESTADOR_INTERCAMBIO WHERE CD_FATURA = F.CD_FATURA) ';
  END IF;

  IF rPagamentoPrestador.cd_prestador IS NOT NULL THEN

    vQueryPrestador := vQueryPrestador || ' AND P.CD_PRESTADOR = ' ||
                       TO_CHAR(rPagamentoPrestador.cd_prestador);

  END IF;
  IF rPagamentoPrestador.tp_prestador = 'A' THEN

    vQueryPrestador := vQueryPrestador ||
                       ' AND P.TP_PRESTADOR IN(''F'',''J'',''L'')';

  ELSE
    vQueryPrestador := vQueryPrestador || ' AND P.TP_PRESTADOR = ' ||
                       CHR(39) || rPagamentoPrestador.tp_prestador ||
                       CHR(39);
  END IF;

  IF rPagamentoPrestador.cd_tip_prestador IS NOT NULL THEN

    vQueryPrestador := vQueryPrestador || ' AND TP.CD_TIP_PRESTADOR = ' ||
                       TO_CHAR(rPagamentoPrestador.cd_tip_prestador);

  END IF;

  IF rPagamentoPrestador.dt_comp_inicial IS NOT NULL THEN

    vQueryCompetencia   := vQueryCompetencia ||
                           ' AND TO_DATE((F.NR_ANO||F.NR_MES),''YYYYMM'') >= TO_DATE(' ||
                           CHR(39) || TO_CHAR(rPagamentoPrestador.dt_comp_inicial,
                                              'DD/MM/YYYY') || CHR(39) || ') ';
    vQueryCompAcrescimo := vQueryCompAcrescimo ||
                           ' AND ((PAD.DT_COMPETENCIA >= TO_DATE(' ||
                           CHR(39) || TO_CHAR(rPagamentoPrestador.dt_comp_inicial,
                                              'DD/MM/YYYY') || CHR(39) || ') ';
  END IF;

  IF rPagamentoPrestador.dt_comp_final IS NOT NULL THEN
    vQueryCompetencia := vQueryCompetencia ||
                         ' AND TO_DATE((F.NR_ANO||F.NR_MES),''YYYYMM'') <= TO_DATE(' ||
                         CHR(39) || TO_CHAR(Last_Day(rPagamentoPrestador.dt_comp_final),
                                            'DD/MM/YYYY') || CHR(39) || ') ';

    IF vQueryCompAcrescimo IS NULL THEN
      vQueryCompAcrescimo := ' AND ((';
    ELSE
      vQueryCompAcrescimo := vQueryCompAcrescimo || ' AND ';
    END IF;

    vQueryCompAcrescimo := vQueryCompAcrescimo ||
                           ' PAD.DT_COMPETENCIA <= TO_DATE(' || CHR(39) ||
                           TO_CHAR(LAST_DAY(rPagamentoPrestador.dt_comp_inicial),
                                   'DD/MM/YYYY') || CHR(39) || ')) ';
  ELSE

    IF vQueryCompAcrescimo IS NOT NULL THEN
      vQueryCompAcrescimo := vQueryCompAcrescimo || ') ';
    END IF;

  END IF;

  IF vQueryCompAcrescimo IS NULL THEN
    vQueryCompAcrescimo := ' AND PAD.DT_COMPETENCIA IS NULL ';
  ELSE
    /*
    ALTER��O EM 09/08/2021 - RAFAEL LUCAS - TI SISTEMAS UNIMED SOROCABA
    MOTIVO: PRESTADORES DESLIGADOS COM DESCONTOS PERMANENTES SUSPENSOS ESTAVAM ENTRANDO NA FOLHA COM VALOR ZERADO
    EXEMPLO: PRESTADOR 28811 - DESLIGADO POR OBITO EM 12/07/2020 FOLHA 624 DEMOSTRATIVO NRO 340865
   */
    --vQueryCompAcrescimo := vQueryCompAcrescimo || ' OR PAD.DT_COMPETENCIA IS NULL) ';
    vQueryCompAcrescimo := vQueryCompAcrescimo || ' OR (PAD.DT_COMPETENCIA IS NULL AND NVL(PAD.SN_SUSPENSO,''N'') = ''N''))';   
  END IF;

  IF rPagamentoPrestador.dt_vencimento_inicial IS NOT NULL THEN
    vQueryVencimento := vQueryVencimento ||
                        ' AND F.DT_VENCIMENTO >= TO_DATE(' || CHR(39) ||
                        TO_CHAR(rPagamentoPrestador.dt_vencimento_inicial,
                                'DD/MM/YYYY') || CHR(39) ||
                        ' ,''DD/MM/YYYY'') ';
  END IF;

  IF rPagamentoPrestador.dt_vencimento_final IS NOT NULL THEN
    vQueryVencimento := vQueryVencimento ||
                        ' AND F.DT_VENCIMENTO <= TO_DATE(' || CHR(39) ||
                        TO_CHAR(rPagamentoPrestador.dt_vencimento_final,
                                'DD/MM/YYYY') || CHR(39) ||
                        ' ,''DD/MM/YYYY'') ';
  END IF;

  IF rPagamentoPrestador.dt_fechamento_fatura_inicial IS NOT NULL THEN
    vQueryFechamento := vQueryFechamento ||
                        ' AND TRUNC (F.DT_USUARIO_FECHAR_PAGTO) >= TO_DATE(' ||
                        CHR(39) || TO_CHAR(rPagamentoPrestador.dt_fechamento_fatura_inicial,
                                           'DD/MM/YYYY') || CHR(39) ||
                        ' ,''DD/MM/YYYY'') AND F.SN_FECHADO = ''S'' ';
  END IF;

  IF rPagamentoPrestador.dt_fechamento_fatura_final IS NOT NULL THEN
    vQueryFechamento := vQueryFechamento ||
                        ' AND TRUNC (F.DT_USUARIO_FECHAR_PAGTO) <= TO_DATE(' ||
                        CHR(39) || TO_CHAR(rPagamentoPrestador.dt_fechamento_fatura_final,
                                           'DD/MM/YYYY') || CHR(39) ||
                        ' ,''DD/MM/YYYY'') AND F.SN_FECHADO = ''S'' ';
  END IF;

  vQuery := vQuery || vQueryPrestador || vQueryVencimento ||
            vQueryFechamento || vQueryCompetencia;

  vQuery := vQuery || ' AND F.CD_MULTI_EMPRESA = ' ||
            TO_CHAR(nCdMultiEmpresa);

-- AND VCM.CD_REPASSE_PRESTADOR IS NULL

  vQuery := vQuery || ' AND VCM.TP_PAGCOB IN (''CP'',''PN'')
                      UNION ALL
                      --HORAS_TRABALHADAS
                      SELECT DISTINCT F.CD_FATURA,
                                      P.CD_PRESTADOR,
                                      F.SN_FECHADO,
                                      P.TP_CREDENCIAMENTO,
                                      C.CD_CONTRATO,
                                      ''HORA_TRABALHADA'' TIPO_FOLHA
                        FROM DBAPS.LANCAMENTO_HORA   LH,
                             DBAPS.ITLANCAMENTO_HORA ITH,
                             DBAPS.FATURA            F,
                             DBAPS.PRESTADOR         P,
                             DBAPS.CONTRATO          C,
                             DBAPS.TIP_PRESTADOR     TP
                       WHERE LH.CD_LANCAMENTO_HORA = ITH.CD_LANCAMENTO_HORA
                                              AND ITH.CD_PRESTADOR = P.CD_PRESTADOR
                         AND LH.CD_FATURA = F.CD_FATURA
                         AND P.CD_PRESTADOR = C.CD_PRESTADOR(+)
                         AND P.CD_TIP_PRESTADOR = TP.CD_TIP_PRESTADOR
                         AND F.CD_MULTI_EMPRESA = ' ||
            TO_CHAR(nCdMultiEmpresa);

  vQuery := vQuery || vQueryFatura || vQueryPrestador || vQueryVencimento ||
            vQueryFechamento || vQueryCompetencia;

  vQuery := vQuery || ' AND F.TP_FATURA = ''P''
                        AND F.SN_REFATURAR = ''N'' ';

  IF rPagamentoPrestador.dt_comp_inicial IS NOT NULL THEN

    /* ESSA L�GICA DE BUSCAR TODOS OS ACRESCIMOS E DESCONTOS DE TODOS OS PRESTADORES DA COMPETENCIA
    S� DEVE SER REALIZADA QUANDO INFORMADO NO FILTRO TIPO DE PRESTADOR O VALOR COOPERADOR (6) */
    --    nTipoPrestador := NULL;
        OPEN cTipPrestador(rPagamentoPrestador.CD_TIP_PRESTADOR);
        FETCH cTipPrestador INTO nTipoPrestador;
        CLOSE cTipPrestador;

    -- 6 - cooperado
--    IF Nvl(nTipoPrestador,-1) = 6 THEN

    vQuery := vQuery ||
              'UNION ALL
                        --ACRESCIMOS_DESCONTOS
                        SELECT TO_NUMBER(NULL) CD_FATURA,
                                P.CD_PRESTADOR,
                                ''S'' SN_FECHADO,
                                P.TP_CREDENCIAMENTO,
                                C.CD_CONTRATO,
                                ''ACRESCIMO_DESCONTO'' TIPO_FOLHA
                          FROM DBAPS.PRESTADOR_AC_DC PAD,
                                DBAPS.PRESTADOR       P,
                                DBAPS.CONTRATO        C,
                                DBAPS.TIP_PRESTADOR   TP
                          WHERE PAD.CD_PRESTADOR = P.CD_PRESTADOR
                            AND P.CD_TIP_PRESTADOR = TP.CD_TIP_PRESTADOR
                            AND P.CD_PRESTADOR = C.CD_PRESTADOR(+) ';

    vQuery := vQuery || vQueryPrestador || vQueryCompAcrescimo;

    vQuery := vQuery || ' GROUP BY P.CD_PRESTADOR,
                                 P.TP_CREDENCIAMENTO,
                                 C.CD_CONTRATO ';

--        END IF; --endif Nvl(nTipoPrestador,-1) = '6'

  end if; --ENDIF dt_comp_inicial

  vQuery := vQuery ||
            'UNION ALL
                      --CAPITAL SOCIAL
                      SELECT NULL CD_FATURA,
                             P.CD_PRESTADOR,
                             ''S'' SN_FECHADO,
                             P.TP_CREDENCIAMENTO,
                             C.CD_CONTRATO,
                             ''CAPITAL_SOCIAL'' TIPO_FOLHA
                        FROM DBAPS.PRESTADOR             P,
                             DBAPS.MODELO_CAPITAL_SOCIAL MCS,
                             DBAPS.CONTRATO              C,
                             DBAPS.TIP_PRESTADOR         TP
                       WHERE MCS.CD_MODELO_CAPITAL_SOCIAL = P.CD_MODELO_CAPITAL_SOCIAL
                         AND P.CD_TIP_PRESTADOR = TP.CD_TIP_PRESTADOR
                         AND DBAPS.PKG_UNIMED.LE_UNIMED IS NOT NULL /* @TODO - DESCOBRIR FORMA DE SO RODAR ESSE SELECT SE TIVER CAPITAL SOCIAL */
                         AND P.CD_PRESTADOR = C.CD_PRESTADOR(+) ';

  vQuery := vQuery || vQueryPrestador;

  vQuery := vQuery || ' GROUP BY P.CD_PRESTADOR,
                                 P.TP_CREDENCIAMENTO,
                                 C.CD_CONTRATO
                      UNION ALL
                      --RECURSO GLOSA
                      SELECT RG.CD_FATURA,
                             P.CD_PRESTADOR,
                             F.SN_FECHADO,
                             P.TP_CREDENCIAMENTO,
                             C.CD_CONTRATO,
                             ''RECURSO_GLOSA'' TIPO_FOLHA
                        FROM DBAPS.RECURSO_GLOSA               RG,
                             DBAPS.PRESTADOR                   P,
                             DBAPS.FATURA                      F,
                             DBAPS.TIP_PRESTADOR               TP,
                             DBAPS.CONTRATO          C
                       WHERE RG.CD_PRESTADOR = P.CD_PRESTADOR
                         AND P.CD_TIP_PRESTADOR = TP.CD_TIP_PRESTADOR
                         AND RG.CD_FATURA = F.CD_FATURA
                         AND P.CD_PRESTADOR = C.CD_PRESTADOR(+)
                         AND RG.CD_STATUS_PROTOCOLO IN (SELECT CD_STATUS_PROTOCOLO FROM DBAPS.STATUS_PROTOCOLO WHERE CD_TISS IN (3))
                         AND P.CD_MULTI_EMPRESA = ' ||
            TO_CHAR(nCdMultiEmpresa);

  IF rPagamentoPrestador.dt_vencimento_inicial IS NOT NULL THEN
    vQuery := vQuery || ' AND F.DT_VENCIMENTO >= TO_DATE(' || CHR(39) ||
              TO_CHAR(rPagamentoPrestador.dt_vencimento_inicial,
                      'DD/MM/YYYY') || CHR(39) || ' ,''DD/MM/YYYY'') ';
  END IF;

  IF rPagamentoPrestador.dt_vencimento_final IS NOT NULL THEN
    vQuery := vQuery || ' AND F.DT_VENCIMENTO <= TO_DATE(' || CHR(39) ||
              TO_CHAR(rPagamentoPrestador.dt_vencimento_final, 'DD/MM/YYYY') ||
              CHR(39) || ' ,''DD/MM/YYYY'') ';
  END IF;

  IF rPagamentoPrestador.dt_fechamento_fatura_inicial IS NOT NULL THEN
    vQuery := vQuery ||
              ' AND TRUNC (F.DT_USUARIO_FECHAR_PAGTO) >= TO_DATE(' ||
              CHR(39) || TO_CHAR(rPagamentoPrestador.dt_fechamento_fatura_inicial,
                                 'DD/MM/YYYY') || CHR(39) ||
              ' ,''DD/MM/YYYY'') AND F.SN_FECHADO = ''S'' ';
  END IF;

  IF rPagamentoPrestador.dt_fechamento_fatura_final IS NOT NULL THEN
    vQuery := vQuery ||
              ' AND TRUNC (F.DT_USUARIO_FECHAR_PAGTO) <= TO_DATE(' ||
              CHR(39) || TO_CHAR(rPagamentoPrestador.dt_fechamento_fatura_final,
                                 'DD/MM/YYYY') || CHR(39) ||
              ' ,''DD/MM/YYYY'') AND F.SN_FECHADO = ''S'' ';
  END IF;

  vQuery := vQuery || vQueryFatura || vQueryPrestador;

  vQuery := vQuery || ' GROUP BY P.CD_PRESTADOR,
                                P.TP_CREDENCIAMENTO,
                                C.CD_CONTRATO,
                                RG.CD_FATURA,
                                F.SN_FECHADO
                      UNION ALL
                      --DESCONTO CONTRATO
                      SELECT NULL CD_FATURA,
                             P.CD_PRESTADOR,
                             ''S'' SN_FECHADO,
                             P.TP_CREDENCIAMENTO,
                             C.CD_CONTRATO,
                             ''DESCONTO_CONTRATO'' TIPO_FOLHA
                        FROM DBAPS.MENS_CONTRATO               MS,
                             DBAPS.PROCESS_CB                  PCB,
                             DBAPS.PRESTADOR_DESCONTO_PRODUCAO PDP,
                             DBAPS.PRESTADOR                   P,
                             DBAPS.CONTRATO                    C,
                             DBAPS.TIP_PRESTADOR               TP
                       WHERE PDP.CD_PRESTADOR = P.CD_PRESTADOR
                         AND P.CD_TIP_PRESTADOR = TP.CD_TIP_PRESTADOR
                         AND PDP.CD_CONTRATO = MS.CD_CONTRATO
                         AND DBAPS.PKG_UNIMED.LE_UNIMED IS NOT NULL
                         AND P.CD_MULTI_EMPRESA = ' ||
            TO_CHAR(nCdMultiEmpresa);

  vQuery := vQuery || vQueryPrestador;

  vQuery := vQuery || ' AND MS.CD_PROCESS_CB = PCB.CD_PROCESS_CB(+)
                        AND MS.CD_CONTRATO = C.CD_CONTRATO
                        AND MS.TP_QUITACAO = ''A''
                        AND MS.DT_CANCELAMENTO IS NULL
                        AND C.TP_CONTRATO <> ''P''
                        AND MS.DT_EMISSAO >= PDP.DT_INICIO_VIGENCIA
                        AND MS.DT_EMISSAO <= NVL(PDP.DT_FIM_VIGENCIA, SYSDATE)
                        AND NVL(MS.VL_MENSALIDADE, 0) > 0
                      GROUP BY P.CD_PRESTADOR,
                               P.TP_CREDENCIAMENTO,
                               C.CD_CONTRATO)
               GROUP BY CD_FATURA,
                        CD_PRESTADOR,
                        SN_FECHADO,
                        TP_CREDENCIAMENTO,
                        CD_CONTRATO,
                        TIPO_FOLHA';

--Raise_application_error(-20000, 'sql  '||vQuery);
  OPEN cProcessaRepasse FOR vQuery;
  LOOP

    FETCH cProcessaRepasse
      INTO r;
    EXIT WHEN cProcessaRepasse%NOTFOUND;

    vTpStatus         := 'C'; --status de cada prestador da folha 'Carregado'
    vDsMensagemAlerta := NULL;
    OPEN cFolhaJaFaturada(r.cd_fatura, r.cd_prestador);
    FETCH cFolhaJaFaturada
      INTO rFolhaJaFaturada;
    IF cFolhaJaFaturada%FOUND THEN

      IF rFolhaJaFaturada.TP_PAGAMENTO = 'FOLHA' THEN
        --vInvalidaFatPrestador := 'S'; a partir de 05/02/19 s� avisa mas nao proibe de processar
        vTpStatus         := 'A'; -- ALerta
        vDsMensagemAlerta := 'A FATURA ' || TO_CHAR(r.CD_FATURA) ||
                             ' DO PRESTADOR: ' || TO_CHAR(r.CD_PRESTADOR) ||
                             ' J� FOI PROCESSADA NA FOLHA DE PAGAMENTO DE N�: ' ||
                             TO_CHAR(rFolhaJaFaturada.CD_PAGAMENTO_PRESTADOR) ||
                             ' - COMPET�NCIA: ' ||
                             TO_CHAR(rFolhaJaFaturada.dt_competencia,
                                     'MM/YYYY');

      ELSE
        IF rFolhaJaFaturada.TP_PAGAMENTO = 'REPASSE' THEN

          vDsMensagemAlerta := 'A FATURA ' || TO_CHAR(r.CD_FATURA) ||
                               ' DO PRESTADOR: ' || TO_CHAR(r.CD_PRESTADOR) ||
                               ' J� FOI PROCESSADA NO FORMATO ANTIGO DE REPASSE DE PRESTADORES DE N�: ' ||
                               TO_CHAR(rFolhaJaFaturada.CD_PAGAMENTO_PRESTADOR) ||
                               ' - DATA DO REPASSE: ' ||
                               TO_CHAR(rFolhaJaFaturada.dt_competencia,
                                       'DD/MM/YYYY');
        END IF;
      END IF;
    END IF;
    CLOSE cFolhaJaFaturada;
    /* CONDICOES PARA INVALIDAR UMA FATURA/PRESTADOR
    1) FATURA ABERTA
    2) PRESTADOR COOPERADOR SEM CONTRATO
    3) FATURA JA FOI PROCESSADA EM OUTRA FOLHA PAGAMENTO */
    IF r.sn_fechado = 'N' THEN
      IF NOT vFaturasInvalidas.EXISTS(r.cd_fatura) THEN
        vFaturasInvalidas(r.cd_fatura).cd_fatura := r.cd_fatura;
      END IF;
      vTpStatus := 'I';
    ELSIF (r.TP_CREDENCIAMENTO = 'D' AND r.CD_CONTRATO IS NULL) THEN
      vTpStatus := 'I';
      IF NOT vPrestSemContrato.EXISTS(r.cd_prestador) THEN
        vPrestSemContrato(r.cd_prestador).cd_prestador := r.cd_prestador;
      END IF;
    END IF;
    BEGIN
      IF vFaturasInvalidas.Count > 0 AND
         vFaturasInvalidas.EXISTS(r.cd_fatura) THEN
        vDsMensagemAlerta := vDsMensagemAlerta || 'FATURA ' ||
                             TO_CHAR(vFaturasInvalidas(r.cd_fatura)
                                     .cd_fatura) || ' ESTA ABERTA';
        iIterator         := vFaturasInvalidas.NEXT(iIterator);
      END IF;
      IF vPrestSemContrato.Count > 0 AND
         vPrestSemContrato.EXISTS(r.cd_prestador) THEN
        vDsMensagemAlerta := vDsMensagemAlerta || 'COOPERADO ' ||
                             TO_CHAR(vPrestSemContrato(r.cd_prestador)
                                     .cd_prestador) ||
                             ' N�O POSSUI CONTRATO PARA GERA��O DE SALDO INSUFICIENTE';
      END IF;
      vDsMensagemAlerta := SubStr(vDsMensagemAlerta, 1, 4000);

      nNrNotaFiscal := NULL;

      OPEN cNotaFiscalProtocolo(r.cd_fatura, r.cd_prestador);
      FETCH cNotaFiscalProtocolo
        INTO nNrNotaFiscal;
      CLOSE cNotaFiscalProtocolo;

      INSERT INTO DBAPS.ITPAGAMENTO_PRESTADOR
        (CD_ITPAGAMENTO_PRESTADOR,
         CD_PAGAMENTO_PRESTADOR,
         CD_FATURA,
         CD_PRESTADOR,
         CD_USUARIO_INCLUSAO,
         DT_INCLUSAO,
         TP_STATUS,
         DS_MOTIVO_INVALIDO,
         DS_TIPO_FOLHA,
         NR_NOTA_FISCAL)
      VALUES
        (DBAPS.SEQ_ITPAGAMENTO_PRESTADOR.NEXTVAL, --CD_ITPAGAMENTO_PRESTADOR
         PCD_PAGAMENTO_PRESTADOR, --CD_PAGAMENTO_PRESTADOR
         r.CD_FATURA, --CD_FATURA
         r.CD_PRESTADOR, --CD_PRESTADOR
         USER, --CD_USUARIO_INCLUSAO
         SYSDATE, --DT_INCLUSAO
         nvl(vTpStatus, 'C'), -- I->INVALIDA; C->CARREGADA
         vDsMensagemAlerta, --DS_MOTIVO_INVALIDO (DETALHA O MOTIVO PELA QUAL A FATURA NAO PODE SER PROCESSADA
         r.TIPO_FOLHA, --TP_FOLHA
         nNrNotaFiscal --NR_NOTA_FISCAL
         );

      /*
      * 1 - Verifica se � permitido rateio por meio da chave CONTMED_PRESTADOR_FOLHA_RATEIO
      * 2 - Carrega o grid com os coperados para que seja realizado o seu rapasse.
      * 3 - Rosemere Mota
      */

      -- TICKET PLANO-7869
      --Verifica se existe a chave para verificar se existe RAteio
      BEGIN
        vSnRateio := 'N';
        OPEN cMvsConfiguracao('CONTMED_PRESTADOR_FOLHA_RATEIO',
                              dbamv.pkg_mv2000.Le_Empresa);
        FETCH cMvsConfiguracao
          INTO vSnRateio;
        CLOSE cMvsConfiguracao;
      EXCEPTION
        WHEN OTHERS THEN
          vSnRateio := 'N';
      END;
      --
      --
      IF vSnRateio = 'S' THEN
        --
        BEGIN
          --
          vPrestadorTemRateio := 'N';
          OPEN cVerificaPrestadorFlagRateio(R.cd_prestador);
          FETCH cVerificaPrestadorFlagRateio
            INTO vPrestadorTemRateio;
          CLOSE cVerificaPrestadorFlagRateio;
          --
        EXCEPTION
          WHEN OTHERS THEN
            vPrestadorTemRateio := 'N';
        END;
        --
        --
        IF vPrestadorTemRateio = 'S' THEN
        --
          FOR rBuscaCoperados IN cBuscaCoperados(r.CD_PRESTADOR) LOOP
            --
            -- Verifica se ja existe na tabela.
            OPEN cVerificaSeJaExistePrestador(rBuscaCoperados.CD_PRESTADOR,
                                              r.CD_FATURA);
            FETCH cVerificaSeJaExistePrestador
              INTO rVerificaSeJaExistePrestador;
            --
            IF rVerificaSeJaExistePrestador.Qtd = 0 THEN
              --
              INSERT INTO DBAPS.ITPAGAMENTO_PRESTADOR
                (CD_ITPAGAMENTO_PRESTADOR,
                 CD_PAGAMENTO_PRESTADOR,
                 CD_FATURA,
                 CD_PRESTADOR,
                 CD_USUARIO_INCLUSAO,
                 DT_INCLUSAO,
                 TP_STATUS,
                 DS_MOTIVO_INVALIDO,
                 DS_TIPO_FOLHA,
                 NR_NOTA_FISCAL)
              VALUES
                (DBAPS.SEQ_ITPAGAMENTO_PRESTADOR.NEXTVAL, --CD_ITPAGAMENTO_PRESTADOR
                 PCD_PAGAMENTO_PRESTADOR, --CD_PAGAMENTO_PRESTADOR
                 r.CD_FATURA, --CD_FATURA
                 rBuscaCoperados.CD_PRESTADOR, --CD_PRESTADOR
                 USER, --CD_USUARIO_INCLUSAO
                 SYSDATE, --DT_INCLUSAO
                 nvl(vTpStatus, 'C'), -- I->INVALIDA; C->CARREGADA
                 vDsMensagemAlerta, --DS_MOTIVO_INVALIDO (DETALHA O MOTIVO PELA QUAL A FATURA NAO PODE SER PROCESSADA
                 r.TIPO_FOLHA, --TP_FOLHA
                 nNrNotaFiscal --NR_NOTA_FISCAL
                 );
              --
            END IF; -- IF rVerificaSeJaExistePrestador.Qtd > 0 THEN
            --
            CLOSE cVerificaSeJaExistePrestador;
            --
          --
          END LOOP; --FOR rBuscaCoperados IN cBuscaCoperados(r.CD_PRESTADOR) LOOP
        --
        END IF;

        --
      END IF; --IF rMvsConfiguracao.Valor = 'S' THEN
      --

      COMMIT;
    EXCEPTION
      WHEN DUP_VAL_ON_INDEX THEN

        Dbms_Output.Put_Line('FATURA ' || r.CD_FATURA || ' - PRESTADOR: ' ||
                             r.CD_PRESTADOR || '  DUPLICADA');
    END;
    --
    nQtdRegistrosInseridos := nQtdRegistrosInseridos + 1;
    IF nQtdRegistrosInseridos > 1000 THEN
      nQtdRegistrosInseridos := 0;
      COMMIT;
    END IF;
  END LOOP;
  COMMIT;
EXCEPTION
  WHEN OTHERS THEN
    vExcecao      := SQLERRM;
    vExcecaoLinha := DBMS_UTILITY.FORMAT_ERROR_BACKTRACE;
    Raise_Application_Error(-20999,
                            'ERRO: ' || vExcecao || ' LINHA DO ERRO: ' || vQuery ||
                            vExcecaoLinha);
END;
/
