-- Create table
create table PRESTADOR_ASSOCIADO_AC_DC
(
  cd_prestador_ac_dc_associado NUMBER,
  cd_prestador_ac_dc           NUMBER,
  cd_prestador_origem          NUMBER,
  dt_inclusao                  DATE,
  cd_usuario                   VARCHAR2(50)
)
tablespace TSDCST
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
-- Grant/Revoke object privileges 
grant select, insert, update, delete, references, alter, index, debug on PRESTADOR_ASSOCIADO_AC_DC to DBAPS;


-- Create table
create table PRESTADOR_DESCONTO_CONTRATO
(
  cd_prestador_desconto_contrato NUMBER,
  cd_prestador_desconto_producao NUMBER,
  cd_prestador_desc_prod_origem  NUMBER,
  cd_prestador_origem            NUMBER,
  cd_usuario_inclusao            VARCHAR2(100),
  dt_inclusao                    DATE
)
tablespace TSDCST
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
-- Grant/Revoke object privileges 
grant select on PRESTADOR_DESCONTO_CONTRATO to DBAPS;


CREATE OR REPLACE NONEDITIONABLE TRIGGER TRG_PRESTADOR_AC_DC_COOP_PJ_AF
  AFTER DELETE ON DBAPS.PRESTADOR_AC_DC
  REFERENCING NEW AS NEW OLD AS OLD
  FOR EACH ROW

  /*
  ************************************************************************************************
  Cria��o          : Rafael Lucas Domingues
  Data             : 03/01/2023
  M�dulo Principal : Folha de Pagamento
  M�dulos          :
  Telas            :
  Objetivo         : Verificar se o Prestador esta ativo no modelo Cooperado PJ
                     alterando o prestador pagamento
  Alteracoes
  +----------------------------------------------------------------------------------------------+
  | DATA          | RESPONSAVEL | VERSAO        | PEND�NCIA | ALTERACAO
  |---------------|-------------|---------------|-----------|------------------------------------|
  | 03/01/2023    | Rafael Lucas|               |           | Cria��o do Objeto                  |
  |---------------|-------------|---------------|-----------|------------------------------------|
  */

DECLARE

  CURSOR cExisteCoopPj IS
    SELECT COUNT(*)
      FROM CUSTOM.PRESTADOR_ASSOCIADO_AC_DC P
     WHERE P.CD_PRESTADOR_AC_DC = :OLD.CD_PRESTADOR_AC_DC;

  nExisteCoopPj NUMBER;
  
BEGIN

  nExisteCoopPj := 0;

  OPEN cExisteCoopPj; 
  FETCH cExisteCoopPj
    INTO nExisteCoopPj;
  CLOSE cExisteCoopPj;   

  IF DELETING AND nExisteCoopPj > 0 THEN    
   DELETE CUSTOM.PRESTADOR_ASSOCIADO_AC_DC P
    WHERE P.CD_PRESTADOR_AC_DC = :OLD.CD_PRESTADOR_AC_DC;
  END IF;    
END TRG_PRESTADOR_AC_DC_COOP_PJ_AF;

CREATE OR REPLACE NONEDITIONABLE TRIGGER TRG_PRESTADOR_AC_DC_COOP_PJ_BF
  BEFORE INSERT OR UPDATE ON DBAPS.PRESTADOR_AC_DC
  REFERENCING NEW AS NEW OLD AS OLD
  FOR EACH ROW

  /*
  ************************************************************************************************
  Cria��o          : Rafael Lucas Domingues
  Data             : 03/01/2023
  M�dulo Principal : Folha de Pagamento
  M�dulos          :
  Telas            :
  Objetivo         : Verificar se o Prestador esta ativo no modelo Cooperado PJ
                     alterando o prestador pagamento
  Alteracoes
  +----------------------------------------------------------------------------------------------+
  | DATA          | RESPONSAVEL | VERSAO        | PEND�NCIA | ALTERACAO
  |---------------|-------------|---------------|-----------|------------------------------------|
  | 03/01/2023    | Rafael Lucas|               |           | Cria��o do Objeto                  |
  |---------------|-------------|---------------|-----------|------------------------------------|
  */

DECLARE

  
  CURSOR cExisteCoopPj IS
    SELECT COUNT(*)
      FROM CUSTOM.PRESTADOR_ASSOCIADO_AC_DC P
     WHERE P.CD_PRESTADOR_AC_DC = :OLD.CD_PRESTADOR_AC_DC;

  nExisteCoopPj               NUMBER;
  nCdPrestadoPagamento        NUMBER;
  nSeqPrestadorAcDcAssociado  NUMBER;
  nCdPrestadorAcDcAssociado   NUMBER;

BEGIN

  nExisteCoopPj             := 0;
  nCdPrestadoPagamento      := NULL;
  nCdPrestadorAcDcAssociado := NULL;
  nCdPrestadoPagamento      := custom.pkg_repasse_prestador_cliente.FNC_RETORNA_PREST_PAGAMENTO (:new.cd_prestador);

  IF INSERTING AND nCdPrestadoPagamento IS NOT NULL THEN

    BEGIN
      SELECT custom.seq_prestador_associado_ac_dc.nextval
        INTO nSeqPrestadorAcDcAssociado
        FROM dual;
    EXCEPTION
      WHEN OTHERS THEN
        raise_application_error (-20001,'ERRO AO GERAR SEQUENCIA TABELA CUSTOM.PRESTADOR_ASSOCIADO_AC_DC !' || SQLERRM);
    END;

    INSERT INTO CUSTOM.PRESTADOR_ASSOCIADO_AC_DC
      (cd_prestador_ac_dc_associado,
       cd_prestador_ac_dc,
       cd_prestador_origem,
       dt_inclusao,
       cd_usuario)
    VALUES
      (nSeqPrestadorAcDcAssociado,
      :NEW.CD_PRESTADOR_AC_DC,
      :NEW.CD_PRESTADOR,
      SYSDATE,
      USER);

    :NEW.CD_PRESTADOR := nCdPrestadoPagamento;
    
  ELSIF UPDATING AND nCdPrestadoPagamento IS NOT NULL AND nExisteCoopPj > 0 THEN
    UPDATE CUSTOM.PRESTADOR_ASSOCIADO_AC_DC PA 
       SET PA.CD_PRESTADOR_ORIGEM = :NEW.CD_PRESTADOR,
           PA.CD_USUARIO          = USER,
           PA.DT_INCLUSAO         = SYSDATE
     WHERE PA.CD_PRESTADOR_AC_DC  = nvl(:OLD.CD_PRESTADOR_AC_DC,:NEW.CD_PRESTADOR_AC_DC);        
  END IF;
END TRG_PRESTADOR_AC_DC_COOP_PJ_BF;

CREATE OR REPLACE NONEDITIONABLE PACKAGE PKG_REPASSE_PRESTADOR_CLIENTE IS
  /*
  *************************************************************************************************
  *  Criado por: Rafael Lucas Domingues - Unimed Sorocaba                                         *
  *  Data......: 28/12/2022                                                                       *
  *  Objetivo..: Rotinas de Apoio ao Processo de Fechamento Folha Cooperado PJ da Unimed Sorocaba *
  +------------------------------------------------------------------------------------------------
  */
  -- (01) -> RECALCULO CUSTOMIZADO DA FOLHA DE PRESTADORES (GRUPO 27 - COOPERADO PJ)
  PROCEDURE PRC_REPASSE_PRESTADOR_CLIENTE (PCD_PAGAMENTO_PRESTADOR IN NUMBER);

  -- (02) -> RECALCULO CUSTOMIZADO DO IMPOSTO DA FOLHA DE PRESTADORES (GRUPO 27 - COOPERADO PJ)
  PROCEDURE PRC_RECALC_IMP_REPASSE_CLIENTE (PCD_REPASSE_PRESTADOR IN NUMBER);

  -- (03) -> DESCONTO CAPITAL COOPERADOR PJ
  PROCEDURE PRC_DESCONTO_CAPITAL_SOCIAL (PCD_PAGAMENTO_PRESTADOR   IN NUMBER,
                                         PCD_REPASSE_PRESTADOR     IN NUMBER,
                                         PCD_LOG_REPASSE_PRESTADOR IN NUMBER,
                                         PCD_PRESTADOR             IN NUMBER,
                                         PDT_COMPETENCIA           IN DATE,
                                         PDT_VENCIMENTO            IN DATE,
                                         PVL_CAPITAL_SOCIAL_RET   OUT NUMBER);

  -- (04) -> FUN��O QUE RETORNA O PRESTADOR PAGAMENTO GRUPO 27 - COOPERADO PJ
  FUNCTION FNC_RETORNA_PREST_PAGAMENTO (PCD_PRESTADOR IN NUMBER) RETURN NUMBER;
  
  -- (05) -> MIGRA OS CONTRATOS COM DESCONTO EM PRODU��O NA CADASTRO DE PESSOA FISICA DO COOPERADO PARA O EMPRESA DO COOPERADO PJ
  PROCEDURE PRC_PREST_DESC_PROD_COOP_PJ;
  
  -- (06) -> GERAR LOG CALCULO REPASSE PRESTADOR CLIENTE
  PROCEDURE PRC_LOG_REPASSE_PREST_CLIENTE (PCD_PAGAMENTO_PRESTADOR NUMBER,
                                           PCD_REPASSE_PRESTADOR   NUMBER,
                                           PDS_ETAPA               VARCHAR2,
                                           PDS_MENSAGEM            VARCHAR2,
                                           PDT_INCLUSAO            DATE);
  
END PKG_REPASSE_PRESTADOR_CLIENTE;

CREATE OR REPLACE NONEDITIONABLE PACKAGE BODY PKG_REPASSE_PRESTADOR_CLIENTE IS
  /*
  *************************************************************************************************
  *  Criado por: Rafael Lucas Domingues - Unimed Sorocaba                                         *
  *  Data......: 28/12/2022                                                                       *
  *  Objetivo..: Rotinas de Apoio ao Processo de Fechamento Folha Cooperado PJ da Unimed Sorocaba *
  +------------------------------------------------------------------------------------------------
  */

  -- (01) -> RECALCULO CUSTOMIZADO DA FOLHA DE PRESTADORES (GRUPO 27 - COOPERADO PJ)
  PROCEDURE PRC_REPASSE_PRESTADOR_CLIENTE (PCD_PAGAMENTO_PRESTADOR IN NUMBER) IS

    --************************
    --        Cursores      --
    --************************

    -- Verifica se o Codigo da Folha � do Tipo Prestador 27 - Cooperado PJ
    CURSOR cPagamentoPrestadoCoopPJ IS
      SELECT DECODE(PP.Cd_Tip_Prestador,27,'S','N') SN_COOPERADO_PJ,
             PP.DT_COMPETENCIA,
             PP.DT_VENCIMENTO,
             PP.DS_OBSERVACAO,
             PP.DS_MENSAGEM_EXTERNA,
             PP.CD_TIP_PRESTADOR
        FROM DBAPS.PAGAMENTO_PRESTADOR PP
       WHERE PP.CD_PAGAMENTO_PRESTADOR = PCD_PAGAMENTO_PRESTADOR;

    -- Carrega Repasse Prestador do tipo 27 Cooperado PJ
    CURSOR cRepassePrestador IS
      SELECT RP.CD_REPASSE_PRESTADOR,
             RP.CD_FATURA,
             RP.CD_PRESTADOR,
             RP.CD_CON_PAG,
             RP.DS_ERRO,
             RP.DT_LANCAMENTO,
             RP.CD_EXP_CONTABILIDADE,
             RP.DT_VENCIMENTO_ORIGINAL,
             RP.NR_NOTA_FISCAL,
             RP.CD_USUARIO_REPASSE,
             RP.DT_USUARIO_REPASSE,
             RP.DS_OBSERVACAO,
             RP.SN_FECHADO,
             RP.DS_MENSAGEM_EXTERNA,
             RP.VL_PRODUCAO_MEDICA,
             RP.CD_PAGAMENTO_PRESTADOR,
             RP.VL_ACRESCIMOS,
             RP.VL_DESCONTOS,
             RP.VL_CAPITAL_SOCIAL,
             RP.VL_HORAS_TRABALHADAS,
             RP.VL_IMPOSTOS,
             RP.VL_LIQUIDO,
             RP.VL_SALDO_INSUFICIENTE,
             RP.VL_TOTAL_DIVIDA_QUITADA,
             RP.VL_LIQUIDO_ORIGINAL,
             RP.TP_STATUS_NOTA_FISCAL,
             RP.VL_DESC_CONTRATO,
             RP.VL_FRANQUIA_AVISTA,
             RP.VL_TOTAL_COBRADO_CM,
             RP.VL_RECURSO_GLOSA,
             RP.SN_LIVRO_SALDO,
             RP.DT_VENCIMENTO,
             RP.DT_EMISSAO_CON_PAG,
             RP.NR_SERIE,
             RP.CD_TIP_DOC,
             RP.VL_ADIANTAMENTO,
             PP.DT_COMPETENCIA,
             PP.TP_FOLHA,
             PR.CD_FORNECEDOR,
             CO.CD_CONTRATO,
             CO.NR_DIA_VENCIMENTO,
             NVL((SELECT SUM(PV.VL_LANCAMENTO)
                    FROM DBAPS.PRESTADOR_CREDITO_DEBITO PV,
                         DBAPS.ITPAGAMENTO_PRESTADOR    IP
                   WHERE IP.CD_PRESTADOR                = PV.CD_PRESTADOR
                     AND IP.CD_FATURA                   = PV.CD_FATURA
                     AND IP.CD_PAGAMENTO_PRESTADOR      = RP.CD_PAGAMENTO_PRESTADOR
                     AND PV.CD_PRESTADOR                = RP.CD_PRESTADOR
                     AND PV.CD_REPASSE_PRESTADOR        = RP.CD_REPASSE_PRESTADOR
                     AND PV.CD_ITEM_DESPESA             = 41),0) VL_ACRES_TRIBUTAVEL
        FROM DBAPS.PAGAMENTO_PRESTADOR PP,
             DBAPS.REPASSE_PRESTADOR   RP,
             DBAPS.PRESTADOR           PR,
             DBAPS.CONTRATO            CO
       WHERE PP.CD_PAGAMENTO_PRESTADOR = RP.CD_PAGAMENTO_PRESTADOR
         AND RP.CD_PRESTADOR           = PR.CD_PRESTADOR
         AND PR.CD_PRESTADOR           = CO.CD_PRESTADOR (+)
         AND PP.CD_PAGAMENTO_PRESTADOR = PCD_PAGAMENTO_PRESTADOR
         AND PP.CD_TIP_PRESTADOR       = 27 -- COOPERADO PJ
         AND PR.TP_SITUACAO            = 'A';

    -- Carrega Impostos do Fornecedor
    CURSOR cImpostoFornecedor (PCD_FORNECEDOR IN NUMBER) IS
      SELECT FD.CD_DETALHAMENTO,
             FD.SN_RETEM_SERVICO SN_RETEM,
             TD.CD_ITEM_RES,
             TD.TP_DETALHAMENTO
        FROM DBAMV.FORN_DETALHAMENTO FD,
             DBAMV.TIP_DETALHE       TD
       WHERE FD.CD_DETALHAMENTO      = TD.CD_DETALHAMENTO
         AND FD.CD_FORNECEDOR        = PCD_FORNECEDOR
         AND FD.CD_MULTI_EMPRESA     = 1
         AND FD.SN_RETEM_SERVICO     = 'S'
         AND ((TD.TP_DATA <> 'P' AND Nvl(dbaps.fnc_mvs_retorna_valor_config('CONFIG_IMPOSTFOLHA_TRAVA_PGTO',1),'N') = 'N') OR
             (dbaps.fnc_mvs_retorna_valor_config('CONFIG_IMPOSTFOLHA_TRAVA_PGTO',1) = 'S'));

    --Carrega Fatura de Horas de Plant�es que ser�o pagas para o Cooperado PJ
    CURSOR cFaturaHoraTrabCoopPj (PDT_COMPETENCIA IN DATE,
                                  PCD_PRESTADOR   IN NUMBER) IS
      SELECT X.CD_FATURA,
             X.CD_PRESTADOR_PAGAMENTO,
             X.TP_CREDENCIAMENTO,
             X.TP_STATUS,
             X.SN_FECHADO,
             X.TIPO_FOLHA
        FROM (SELECT DISTINCT F.CD_FATURA,
                     CUSTOM.PKG_REPASSE_PRESTADOR_CLIENTE.FNC_RETORNA_PREST_PAGAMENTO(ITH.CD_PRESTADOR) CD_PRESTADOR_PAGAMENTO,
                     P.TP_CREDENCIAMENTO,
                     DECODE(F.SN_FECHADO, 'S', 'C', 'N', 'I') TP_STATUS,
                     F.SN_FECHADO,
                     'HORA_TRABALHADA' TIPO_FOLHA
                FROM DBAPS.LANCAMENTO_HORA     LH,
                     DBAPS.ITLANCAMENTO_HORA   ITH,
                     DBAPS.FATURA              F,
                     DBAPS.PRESTADOR           P,
                     DBAPS.TIP_PRESTADOR       TP,
                     DBAPS.ITEM_DESPESA        ID,
                     DBAPS.TIPO_HORA           TH,
                     DBAPS.PRESTADOR_ASSOCIADO PA,
                     DBAPS.PRESTADOR           PR
               WHERE LH.CD_LANCAMENTO_HORA     = ITH.CD_LANCAMENTO_HORA
                 AND ITH.CD_PRESTADOR          = P.CD_PRESTADOR
                 AND LH.CD_FATURA              = F.CD_FATURA
                 AND P.CD_TIP_PRESTADOR        = TP.CD_TIP_PRESTADOR
                 AND ITH.CD_TIPO_HORA          = TH.CD_TIPO_HORA
                 AND TH.CD_ITEM_DESPESA        = ID.CD_ITEM_DESPESA
                 AND ITH.CD_PRESTADOR          = PA.CD_PRESTADOR_ASSOCIADO
                 AND PA.CD_PRESTADOR           = PR.CD_PRESTADOR
                 AND (PA.DT_TERMINO             IS NULL OR PA.DT_TERMINO >= TRUNC(SYSDATE))
                 AND PR.CD_TIP_PRESTADOR       = 27  -- TIPO PRESTADOR COOPERADO PJ
                 AND TH.CD_ITEM_DESPESA        = 7   -- NA PRODU��O COOPERADO PJ SER�O PAGAS APENAS HORA DE PLANT�O MEDICO
                 AND PR.TP_SITUACAO            = 'A' -- ATIVO
                 AND ITH.CD_REPASSE_PRESTADOR  IS NULL
                 AND F.CD_MULTI_EMPRESA        = 1
                 AND P.TP_PRESTADOR            IN ('F', 'J', 'L')
                 AND F.TP_FATURA               = 'P'
                 AND F.SN_REFATURAR            = 'N'
                 AND F.NR_ANO || F.NR_MES      = TO_CHAR(PDT_COMPETENCIA, 'YYYYMM')) X
       WHERE X.CD_PRESTADOR_PAGAMENTO = PCD_PRESTADOR;

    --Carrega Horas Trabalhadas de Plant�es que ser�o pagas para o Cooperado PJ
    CURSOR cHoraTrabCoopPj (PDT_COMPETENCIA DATE,
                            PCD_PRESTADOR   NUMBER) IS
      SELECT DISTINCT F.CD_FATURA,
                F.DS_FATURA,
                P.CD_PRESTADOR,
                CUSTOM.PKG_REPASSE_PRESTADOR_CLIENTE.FNC_RETORNA_PREST_PAGAMENTO(ITH.CD_PRESTADOR) CD_PRESTADOR_PAGAMENTO,
                ITH.CD_ITLANCAMENTO_HORA,
                F.SN_FECHADO,
                P.TP_CREDENCIAMENTO,
                (SELECT MIN(CO.CD_CONTRATO)
                   FROM DBAPS.CONTRATO CO
                  WHERE CO.TP_CONTRATO = 'P'
                    AND CO.CD_PRESTADOR = CUSTOM.PKG_REPASSE_PRESTADOR_CLIENTE.FNC_RETORNA_PREST_PAGAMENTO(ITH.CD_PRESTADOR)) CD_CONTRATO,
                'HORA_TRABALHADA' TIPO_FOLHA,
                ITH.VL_HORAS,
                ITH.CD_SETOR,
                TH.CD_ITEM_DESPESA,
                ITH.DT_INICIO,
                ITH.DT_FIM,
                ID.DS_ITEM_DESPESA,
                ITH.DS_OBSERVACAO
        FROM DBAPS.LANCAMENTO_HORA      LH,
             DBAPS.ITLANCAMENTO_HORA    ITH,
             DBAPS.FATURA               F,
             DBAPS.PRESTADOR            P,
             DBAPS.TIP_PRESTADOR        TP,
             DBAPS.ITEM_DESPESA         ID,
             DBAPS.TIPO_HORA            TH,
             DBAPS.PRESTADOR_ASSOCIADO  PA,
             DBAPS.PRESTADOR            PP
       WHERE LH.CD_LANCAMENTO_HORA      = ITH.CD_LANCAMENTO_HORA
         AND ITH.CD_PRESTADOR           = P.CD_PRESTADOR
         AND LH.CD_FATURA               = F.CD_FATURA
         AND P.CD_TIP_PRESTADOR         = TP.CD_TIP_PRESTADOR
         AND ITH.CD_TIPO_HORA           = TH.CD_TIPO_HORA
         AND TH.CD_ITEM_DESPESA         = ID.CD_ITEM_DESPESA
         AND ITH.CD_PRESTADOR           = PA.CD_PRESTADOR_ASSOCIADO
         AND PA.CD_PRESTADOR            = PP.CD_PRESTADOR
         AND ITH.CD_REPASSE_PRESTADOR   IS NULL
         AND TH.CD_ITEM_DESPESA         = 7 -- NA PRODU��O COOPERADO PJ SER�O PAGAS APENAS HORA DE PLANT�O MEDICO
         AND F.CD_MULTI_EMPRESA         = 1
         AND TP.CD_TIP_PRESTADOR        = 0
         AND P.TP_PRESTADOR             IN ('F', 'J', 'L')
         AND F.TP_FATURA                = 'P'
         AND F.SN_REFATURAR             = 'N'
         AND PP.CD_PRESTADOR            = PCD_PRESTADOR
         AND F.DT_INICIAL               >= PDT_COMPETENCIA
         AND F.DT_FINAL                 <= LAST_DAY(PDT_COMPETENCIA);
         
    --Verifica se existe Pagamento Invalidos
    CURSOR cPagamentoInvalido IS
      SELECT COUNT(*)
        FROM DBAPS.ITPAGAMENTO_PRESTADOR
       WHERE CD_PAGAMENTO_PRESTADOR = PCD_PAGAMENTO_PRESTADOR
         AND TP_STATUS = 'I';

    --Carrega Valor Horas Trabalhadas Cooperado PJ
    CURSOR cVlHorasTrabalhadasPj (PCD_REPASSE_PRESTADOR IN NUMBER) IS
      SELECT SUM(NVL(PCD.VL_LANCAMENTO,0))
        FROM DBAPS.PRESTADOR_CREDITO_DEBITO PCD
       WHERE PCD.CD_REPASSE_PRESTADOR = PCD_REPASSE_PRESTADOR
         AND PCD.TP_LANCAMENTO        = 'C'
         AND PCD.CD_ITEM_DESPESA      = 7
         AND INSTR(PCD.DS_OBSERVACAO,'HORAS TRABALHADAS') > 0;

    --Carrega Valor dos Impostos Cooperado PJ
    CURSOR cRepassePrestadorImposto (PCD_REPASSE_PRESTADOR IN NUMBER) IS
      SELECT SUM(NVL(RPI.VL_IMPOSTO,0)) VL_IMPOSTO
        FROM DBAPS.REPASSE_PRESTADOR_IMPOSTO RPI
       WHERE RPI.CD_REPASSE_PRESTADOR = PCD_REPASSE_PRESTADOR;

    --Carrega Valores Repasse Prestador
    CURSOR cVlRepassePrestador (PCD_REPASSE_PRESTADOR IN NUMBER) IS
      SELECT RP.VL_PRODUCAO_MEDICA,
             RP.VL_HORAS_TRABALHADAS,
             RP.VL_ACRESCIMOS,
             RP.VL_DESCONTOS,
             RP.VL_CAPITAL_SOCIAL,
             RP.VL_IMPOSTOS,
             RP.VL_LIQUIDO,
             RP.VL_LIQUIDO_ORIGINAL,
             RP.VL_SALDO_INSUFICIENTE
        FROM DBAPS.REPASSE_PRESTADOR RP
       WHERE RP.CD_REPASSE_PRESTADOR = PCD_REPASSE_PRESTADOR;

    --Carrega Valor Liquido Negativo
    CURSOR cLiquidoNegativo (PCD_REPASSE_PRESTADOR IN NUMBER) IS
      SELECT NVL(RP.VL_SALDO_INSUFICIENTE,0)
        FROM DBAPS.REPASSE_PRESTADOR RP
       WHERE RP.CD_REPASSE_PRESTADOR = PCD_REPASSE_PRESTADOR;

    -- Configura�oes da operadora
    CURSOR cConfigMVS IS
      SELECT CD_ITEM_RES_HMEDICO,
             CD_SETOR_HMEDICO,
             CD_SETOR_IRPF,
             CD_ITEM_RES_IRPF,
             CD_SETOR_IRPJ,
             CD_ITEM_RES_IRPJ,
             CD_SETOR_ISS,
             CD_ITEM_RES_ISS,
             CD_LCTO_MENSALIDADE_PREST_COOP, --Liquido insuficiente
             CD_DESPESA_CAPTATION            --Item de despesas captation
        FROM DBAMV.MULTI_EMPRESAS_MV_SAUDE
       WHERE CD_MULTI_EMPRESA = 1;

    -- Carrega ID Log Repasse Prestador
    CURSOR cLogRepassePrestador (PCD_REPASSE_PRESTADOR IN NUMBER)IS
      SELECT LRP.CD_LOG_REPASSE_PRESTADOR
        FROM DBAPS.LOG_REPASSE_PRESTADOR LRP
       WHERE LRP.CD_REPASSE_PRESTADOR = PCD_REPASSE_PRESTADOR;

    --Cooperados Associados com Capital Social
    CURSOR cCoopAssociadoCapitalSocial (PCD_PRESTADOR_PAGAMENTO IN NUMBER) IS
      SELECT PA.CD_PRESTADOR_ASSOCIADO
        FROM DBAPS.PRESTADOR           P,
             DBAPS.PRESTADOR_ASSOCIADO PA
       WHERE P.CD_PRESTADOR            = PA.CD_PRESTADOR
         AND P.CD_TIP_PRESTADOR        = 27 -- COOPERADO PJ
         AND P.TP_SITUACAO             = 'A' -- ATIVO
         AND PA.CD_PRESTADOR           = PCD_PRESTADOR_PAGAMENTO
         AND EXISTS (SELECT 1
                       FROM DBAPS.PRESTADOR P
                      WHERE P.CD_PRESTADOR = PA.CD_PRESTADOR_ASSOCIADO
                        AND P.CD_MODELO_CAPITAL_SOCIAL IS NOT NULL
                        AND P.DT_SUSPENSAO_CAPITAL_SOCIAL IS NULL);

    --Verifica o Cod. da Fatura de Liquido Insuficiente Gerada pela Rotina Padrao
    CURSOR cMensContratoSaldoInsuficiente (PCD_CONTRATO NUMBER,
                                           PNR_ANO      VARCHAR2,
                                           PNR_MES      VARCHAR2) IS
      SELECT MC.CD_MENS_CONTRATO
        FROM DBAPS.MENS_CONTRATO MC
       WHERE MC.CD_CONTRATO = PCD_CONTRATO
         AND MC.NR_ANO      = PNR_ANO
         AND MC.NR_MES      = PNR_MES
         AND MC.DT_CANCELAMENTO IS NULL
         AND EXISTS (SELECT 1
                       FROM DBAPS.ITMENS_CONTRATO IT
                      WHERE IT.CD_MENS_CONTRATO = MC.CD_MENS_CONTRATO
                        AND IT.CD_LCTO_MENSALIDADE = 81
                        AND NVL(IT.SN_LCTO_RECEBIMENTO,'N') = 'N');
    
    --Verifica se o Cooperado PJ tem Horas Trabalhadas e n�o e tem Repasse
    CURSOR cHoraTrabCoopPjSemRepasse (PDT_COMPETENCIA DATE) IS
      SELECT DISTINCT F.CD_FATURA,
                      P.CD_PRESTADOR,
                      CUSTOM.PKG_REPASSE_PRESTADOR_CLIENTE.FNC_RETORNA_PREST_PAGAMENTO(ITH.CD_PRESTADOR) CD_PRESTADOR_PAGAMENTO,
                      'HORA_TRABALHADA' TIPO_FOLHA
              FROM DBAPS.LANCAMENTO_HORA      LH,
                   DBAPS.ITLANCAMENTO_HORA    ITH,
                   DBAPS.FATURA               F,
                   DBAPS.PRESTADOR            P,
                   DBAPS.TIP_PRESTADOR        TP,
                   DBAPS.ITEM_DESPESA         ID,
                   DBAPS.TIPO_HORA            TH,
                   DBAPS.PRESTADOR_ASSOCIADO  PA,
                   DBAPS.PRESTADOR            PP
             WHERE LH.CD_LANCAMENTO_HORA      = ITH.CD_LANCAMENTO_HORA
               AND ITH.CD_PRESTADOR           = P.CD_PRESTADOR
               AND LH.CD_FATURA               = F.CD_FATURA
               AND P.CD_TIP_PRESTADOR         = TP.CD_TIP_PRESTADOR
               AND ITH.CD_TIPO_HORA           = TH.CD_TIPO_HORA
               AND TH.CD_ITEM_DESPESA         = ID.CD_ITEM_DESPESA
               AND ITH.CD_PRESTADOR           = PA.CD_PRESTADOR_ASSOCIADO
               AND PA.CD_PRESTADOR            = PP.CD_PRESTADOR
               AND ITH.CD_REPASSE_PRESTADOR   IS NULL
               AND TH.CD_ITEM_DESPESA         = 7 -- NA PRODU��O COOPERADO PJ SER�O PAGAS APENAS HORA DE PLANT�O MEDICO
               AND F.CD_MULTI_EMPRESA         = 1
               AND TP.CD_TIP_PRESTADOR        = 0
               AND P.TP_PRESTADOR             IN ('F', 'J', 'L')
               AND F.TP_FATURA                = 'P'
               AND F.SN_REFATURAR             = 'N'
               AND PP.CD_TIP_PRESTADOR        = 27
               AND F.DT_INICIAL               >= PDT_COMPETENCIA
               AND F.DT_FINAL                 <= LAST_DAY(PDT_COMPETENCIA)
               AND NOT EXISTS (SELECT 1 
                                 FROM DBAPS.REPASSE_PRESTADOR RP 
                                WHERE RP.CD_PRESTADOR = PP.CD_PRESTADOR 
                                  AND RP.CD_PAGAMENTO_PRESTADOR = PCD_PAGAMENTO_PRESTADOR);
                                         
    -- Carrega Repasse Zerado
    CURSOR cRepassePrestadorZerado IS
      SELECT RP.CD_REPASSE_PRESTADOR,
             RP.CD_PRESTADOR 
        FROM DBAPS.REPASSE_PRESTADOR RP 
       WHERE RP.CD_PAGAMENTO_PRESTADOR = PCD_PAGAMENTO_PRESTADOR
         AND (RP.VL_PRODUCAO_MEDICA    = 0 AND 
              RP.VL_HORAS_TRABALHADAS  = 0 AND
              RP.VL_ACRESCIMOS         = 0 AND
              RP.VL_DESCONTOS          = 0 AND
              RP.VL_CAPITAL_SOCIAL     = 0);
              
    -- Carrega os Repasse da Folha de Cooperado Pessoa Fisica que esta vinculado a Cooperado PJ
    CURSOR cRepassePrestadorCooperado IS          
      SELECT RP.CD_PAGAMENTO_PRESTADOR,
             RP.CD_REPASSE_PRESTADOR,
             RP.CD_PRESTADOR,
             RP.VL_LIQUIDO,
             RP.VL_CAPITAL_SOCIAL,
             RP.VL_SALDO_INSUFICIENTE
        FROM DBAPS.REPASSE_PRESTADOR RP
       WHERE RP.CD_PAGAMENTO_PRESTADOR = PCD_PAGAMENTO_PRESTADOR
         AND CUSTOM.PKG_REPASSE_PRESTADOR_CLIENTE.FNC_RETORNA_PREST_PAGAMENTO (RP.CD_PRESTADOR) IS NOT NULL;
            
                                            
    --************************
    --        Constante     --
    --************************
    C_VL_MINIMO_LIQUIDO_INSUF CONSTANT NUMBER := 0;

    --************************
    --        Variaveis     --
    --************************
    nCdMultiEmpresa         NUMBER;
    vDsDetalhamento         VARCHAR2(100);
    nNrDiasVencto           NUMBER;
    vTpVencimento           VARCHAR2(100);
    nCdTipDoc               NUMBER;
    nCdReduzido             NUMBER;
    vTpIncImposto           VARCHAR2(100);
    vTpData                 VARCHAR2(100);
    nVlPercentual           NUMBER;
    nVlDeducao              NUMBER;
    nVlMinRecolhimento      NUMBER;
    nVlDetalhamento         NUMBER;
    vTpStatus               VARCHAR2(1);
    vDsMensagemAlerta       VARCHAR2(100);
    vExcecao                VARCHAR2(4000);
    vExcecaoLinha           VARCHAR2(4000);
    vDsObservacao           dbaps.prestador_credito_debito.ds_observacao%TYPE;
    nVlHorasTrabalhadasPj   NUMBER;
    nVlBaseCalculoImposto   NUMBER;
    nPagamentoInvalido      NUMBER;
    nVlTotalImposto         NUMBER;
    nVlLiquido              NUMBER;
    nVlSaldoInsuficiente    NUMBER;
    nCdMensContrato         NUMBER;
    nCdLogRepassePrestador  NUMBER;
    nCdPrestadorAssociado   NUMBER;
    nVlCapitalSocial        NUMBER;
    nVlCapitalSocialRet     NUMBER;
    dDtFinalCobertura       DATE;
    nSeqRepassePrestador    NUMBER;
    
    --****************************
    --   Variaveis Tipo Cursor  --
    --****************************
    rRepassePrestador               cRepassePrestador%ROWTYPE;
    rVlRepassePrestador             cVlRepassePrestador%ROWTYPE;
    rConfigMVS                      cConfigMVS%ROWTYPE;
    rMensContratoSaldoInsuficiente  cMensContratoSaldoInsuficiente%ROWTYPE;
    rPagamentoPrestadoCoopPJ        cPagamentoPrestadoCoopPJ%ROWTYPE;

  BEGIN

    --Evitar incompatibilidade com formatos de Data
    EXECUTE IMMEDIATE 'ALTER SESSION SET NLS_DATE_LANGUAGE      = "BRAZILIAN PORTUGUESE"
                                         NLS_NUMERIC_CHARACTERS = ",."
                                         NLS_DATE_FORMAT        = "DD/MM/YYYY"
                                         NLS_LANGUAGE           = "BRAZILIAN PORTUGUESE"
                                         NLS_SORT               = "BINARY"
                                         NLS_TIME_FORMAT        = "HH24:MI:SS"
                                         NLS_COMP               = "BINARY"';

    -- Default Variaves
    nCdMultiEmpresa       := 1;
    nPagamentoInvalido    := 0;
    nVlBaseCalculoImposto := 0;
    nVlTotalImposto       := 0;
    nVlLiquido            := 0;
    nVlSaldoInsuficiente  := 0;
    nCdPrestadorAssociado := NULL;
    nVlCapitalSocial      := 0;
    nVlCapitalSocialRet   := 0;
    dDtFinalCobertura     := NULL;

    -- Verifica se a Folha � do Tipo de Prestador 27 - Cooperado PJ
    OPEN cPagamentoPrestadoCoopPJ;
    FETCH cPagamentoPrestadoCoopPJ
      INTO rPagamentoPrestadoCoopPJ;
    CLOSE cPagamentoPrestadoCoopPJ;
    
    --Limpa Tabela de Log
    DELETE CUSTOM.LOG_REPASSE_PRESTADOR_CLIENTE
     WHERE CD_PAGAMENTO_PRESTADOR = PCD_PAGAMENTO_PRESTADOR; 
    COMMIT;
    
    --Log    
    PRC_LOG_REPASSE_PREST_CLIENTE (PCD_PAGAMENTO_PRESTADOR,NULL,'INICIO','PONTO DE ENTRADA COOPERADO PJ -> SN_COOPERADO_PJ: '|| nvl(rPagamentoPrestadoCoopPJ.Sn_Cooperado_Pj,'N'),SYSDATE);
      
    IF nvl(rPagamentoPrestadoCoopPJ.Sn_Cooperado_Pj,'N') = 'S' THEN
      --Carrega Configura��es
      OPEN cConfigMVS;
      FETCH cConfigMVS
        INTO rConfigMVS;
      CLOSE cConfigMVS;
      
      --  Inicio do Loop que Gera o Repasse para o Cooperado PJ que tem Horas Trabalhadas e n�o teve Produ��o ou Acrescimos e Descontos
      FOR rHoraTrabCoopPjSemRepasse IN cHoraTrabCoopPjSemRepasse (rPagamentoPrestadoCoopPJ.dt_competencia) LOOP
        BEGIN
          SELECT DBAPS.SEQ_REPASSE_PRESTADOR.NEXTVAL
            INTO nSeqRepassePrestador
            FROM DUAL;
        EXCEPTION
          WHEN OTHERS THEN
            Raise_Application_Error(-20001,'Erro ao gerar a chave prim�ria da tabela DBAPS.REPASSE_PRESTADOR');       
        END;
        
        BEGIN 
          -- Criando repasse para o prestador
          INSERT INTO DBAPS.REPASSE_PRESTADOR
            (CD_REPASSE_PRESTADOR,
             CD_FATURA,
             CD_PRESTADOR,
             CD_CON_PAG,
             DS_ERRO,
             DT_LANCAMENTO,
             CD_EXP_CONTABILIDADE,
             DT_VENCIMENTO_ORIGINAL,
             NR_NOTA_FISCAL,
             CD_USUARIO_REPASSE,
             DT_USUARIO_REPASSE,
             DS_OBSERVACAO,
             SN_FECHADO,
             DS_MENSAGEM_EXTERNA,
             CD_PAGAMENTO_PRESTADOR,
             VL_PRODUCAO_MEDICA,
             VL_ACRESCIMOS,
             VL_DESCONTOS,
             VL_CAPITAL_SOCIAL,
             VL_HORAS_TRABALHADAS,
             VL_LIQUIDO)
          VALUES
            (nSeqRepassePrestador,
             NULL,
             rHoraTrabCoopPjSemRepasse.CD_PRESTADOR_PAGAMENTO,
             NULL,
             NULL,
             SYSDATE,
             NULL,
             rPagamentoPrestadoCoopPJ.DT_VENCIMENTO,
             NULL,
             USER,
             SYSDATE,
             rPagamentoPrestadoCoopPJ.DS_OBSERVACAO,
             'N',
             rPagamentoPrestadoCoopPJ.DS_MENSAGEM_EXTERNA,
             PCD_PAGAMENTO_PRESTADOR,
             0,
             0,
             0,
             0,
             0,
             0);  
        
          --Log    
          PRC_LOG_REPASSE_PREST_CLIENTE (PCD_PAGAMENTO_PRESTADOR,nSeqRepassePrestador,'HORA TRABALHADA','PRESTADOR COM REALIZOU HORAS E N�O TINHA REPASSE GERADO PELA ROTINA PADRAO',SYSDATE);
                   
        EXCEPTION
          WHEN OTHERS THEN
            vExcecao      := SQLERRM;
            vExcecaoLinha := DBMS_UTILITY.FORMAT_ERROR_BACKTRACE;
            Raise_Application_Error(-20999,'ERRO AO INSERIR NA TABELA: DBAPS.REPASSE_PRESTADOR ' || vExcecao || ' LINHA DO ERRO: ' || vExcecaoLinha);
        END;
        COMMIT;
      END LOOP;
      
      -- Inicio do Loop Principal
      FOR rRepassePrestador IN cRepassePrestador LOOP

        /*****************************************************************************************/
        /*                             HORAS TRABALHADAS COOPERADO PJ                            */
        /*****************************************************************************************/
        FOR rFaturaHoraTrabCoopPj IN cFaturaHoraTrabCoopPj (rRepassePrestador.Dt_Competencia,
                                                            rRepassePrestador.Cd_Prestador) LOOP
          vDsMensagemAlerta := NULL;
          vTpStatus         := NULL;

          --Limpa os lan�amentos de Horas Trabalhadas da Tabela ItPagamentoPrestador
          DELETE DBAPS.ITPAGAMENTO_PRESTADOR IPP
           WHERE IPP.CD_PAGAMENTO_PRESTADOR = PCD_PAGAMENTO_PRESTADOR
             AND IPP.CD_PRESTADOR           = rFaturaHoraTrabCoopPj.Cd_Prestador_Pagamento
             AND IPP.DS_TIPO_FOLHA          = 'HORA_TRABALHADA';
          COMMIT;

          IF rFaturaHoraTrabCoopPj.Sn_Fechado = 'N' THEN
            vDsMensagemAlerta := 'FATURA ' || rFaturaHoraTrabCoopPj.Cd_Fatura || ' ESTA ABERTA!';
            vTpStatus := 'I';
          ELSIF rFaturaHoraTrabCoopPj.Sn_Fechado = 'S' THEN
            vTpStatus := 'C';
          END IF;

          BEGIN
            INSERT INTO DBAPS.ITPAGAMENTO_PRESTADOR
              (CD_ITPAGAMENTO_PRESTADOR,
               CD_PAGAMENTO_PRESTADOR,
               CD_FATURA,
               CD_PRESTADOR,
               CD_USUARIO_INCLUSAO,
               DT_INCLUSAO,
               TP_STATUS,
               DS_MOTIVO_INVALIDO,
               DS_TIPO_FOLHA,
               NR_NOTA_FISCAL)
            VALUES
              (DBAPS.SEQ_ITPAGAMENTO_PRESTADOR.NEXTVAL,
               PCD_PAGAMENTO_PRESTADOR,
               rFaturaHoraTrabCoopPj.CD_FATURA,
               rFaturaHoraTrabCoopPj.Cd_Prestador_Pagamento,
               USER,
               SYSDATE,
               vTpStatus, --I-> INVALIDA; C-> CARREGADA
               vDsMensagemAlerta, --DS_MOTIVO_INVALIDO (DETALHA O MOTIVO PELA QUAL A FATURA NAO PODE SER PROCESSADA
               rFaturaHoraTrabCoopPj.Tipo_Folha,
               NULL);
          EXCEPTION
            WHEN OTHERS THEN
               vExcecao      := SQLERRM;
               vExcecaoLinha := DBMS_UTILITY.FORMAT_ERROR_BACKTRACE;
               Raise_Application_Error(-20999,'ERRO AO INSERIR NA TABELA: DBAPS.ITPAGAMENTO_PRESTADOR ' || vExcecao || ' LINHA DO ERRO: ' || vExcecaoLinha);
          END;          
          COMMIT;
          --Log    
          PRC_LOG_REPASSE_PREST_CLIENTE (PCD_PAGAMENTO_PRESTADOR,NULL,'HORA TRABALHADA','INSERINDO FATURA NO PRESTADOR ' || rFaturaHoraTrabCoopPj.Cd_Prestador_Pagamento,SYSDATE);
        END LOOP;

        --Verifica se a Pagamentos Invalidos
        nPagamentoInvalido := 0;
        
        OPEN cPagamentoInvalido;
        FETCH cPagamentoInvalido
          INTO nPagamentoInvalido;
          
          --Log
          PRC_LOG_REPASSE_PREST_CLIENTE (PCD_PAGAMENTO_PRESTADOR,NULL,'HORA TRABALHADA','TOTAL DE REGISTROS INVALIDOS : ' || nPagamentoInvalido || ' - ' || rRepassePrestador.cd_repasse_prestador,SYSDATE);
          
          IF nPagamentoInvalido > 0 THEN
            Raise_Application_Error(-20999,'ERRO: EXISTEM FATURAS/PRESTADORES INV�LIDOS NESTE PROCESSO DE FOLHA (PAGAMENTO_PRESTADOR). POSS�VEIS MOTIVOS: 1) FATURA N�O FECHADA; 2) PRESTADOR SEM CONTRATO');
          END IF;
        CLOSE cPagamentoInvalido;

        -- Carrega Horas Trabalhadas de Plant�o de Cooperados PJ
        FOR rHoraTrabCoopPj IN cHoraTrabCoopPj(rRepassePrestador.Dt_Competencia,
                                               rRepassePrestador.Cd_Prestador)  LOOP

          vDsObservacao := NULL;
          vDsObservacao := 'ACRESCIMO EM PRODUCAO MEDICA REFERENTE A HORAS TRABALHADAS: CODIGO: ' ||
                            rHoraTrabCoopPj.cd_itlancamento_hora                                  ||
                            ' - VALOR: '                                                          ||
                            rHoraTrabCoopPj.vl_horas                                              ||
                            'ITEM DE DESPESA: '                                                   ||
                            rHoraTrabCoopPj.ds_item_despesa                                       ||
                            'DE '                                                                 ||
                            rHoraTrabCoopPj.DT_INICIO                                             ||
                            'A '                                                                  ||
                            rHoraTrabCoopPj.DT_FIM                                                ||
                            ' - OBSERVACAO: '                                                     ||
                            rHoraTrabCoopPj.DS_OBSERVACAO                                         ||
                            'CD_PRESTADOR_EXECUTANTE: '                                           ||
                            rHoraTrabCoopPj.CD_PRESTADOR;

          -- REALIZA O LANCAMENTO NA TABELA PRESTADOR_CREDITO_DEBITO
          INSERT INTO DBAPS.PRESTADOR_CREDITO_DEBITO
            (CD_PRES_CR_DB,
             CD_FATURA,
             CD_LOTE,
             CD_PRESTADOR,
             TP_LANCAMENTO,
             VL_LANCAMENTO,
             DS_USER_INCLUSAO,
             DT_INCLUSAO,
             CD_ITEM_DESPESA,
             CD_ITLANCAMENTO_HORA,
             DS_OBSERVACAO,
             CD_SETOR,
             CD_REPASSE_PRESTADOR)
          VALUES
            (DBAPS.SEQ_PRESTADOR_CREDITO_DEBITO.NEXTVAL,
             rHoraTrabCoopPj.Cd_Fatura,
             NULL,
             rHoraTrabCoopPj.Cd_Prestador_Pagamento,
             'C',
             rHoraTrabCoopPj.Vl_Horas,
             USER,
             SYSDATE,
             rHoraTrabCoopPj.CD_ITEM_DESPESA,
             rHoraTrabCoopPj.Cd_Itlancamento_Hora,
             vDsObservacao,
             rHoraTrabCoopPj.Cd_Setor,
             rRepassePrestador.Cd_Repasse_Prestador);
                          
          --Log    
          PRC_LOG_REPASSE_PREST_CLIENTE (PCD_PAGAMENTO_PRESTADOR,rRepassePrestador.Cd_Repasse_Prestador,'HORA TRABALHADA','INSERINDO DBAPS.PRESTADOR_CREDITO_DEBITO PRESTADOR: ' || rHoraTrabCoopPj.Cd_Prestador_Pagamento || ' CD_ITLANCAMENTO_HORA: ' || rHoraTrabCoopPj.Cd_Itlancamento_Hora,SYSDATE);
          
          --Atualiza Tabela de Horas Trabalhadas
          BEGIN
            UPDATE DBAPS.ITLANCAMENTO_HORA
               SET CD_REPASSE_PRESTADOR = rRepassePrestador.Cd_Repasse_Prestador
             WHERE CD_ITLANCAMENTO_HORA = rHoraTrabCoopPj.CD_ITLANCAMENTO_HORA;
            COMMIT;
          EXCEPTION
            WHEN OTHERS THEN
              vExcecao      := NULL;
              vExcecaoLinha := NULL;
              vExcecao      := SQLERRM;
              vExcecaoLinha := DBMS_UTILITY.FORMAT_ERROR_BACKTRACE;
              Raise_Application_Error(-20999,'ERRO AO ATUALIZAR TABELA DBAPS.ITLANCAMENTO_HORA COOPERADO PJ REPASSE NR. '|| rRepassePrestador.cd_repasse_prestador ||' - '||vExcecao || ' LINHA DO ERRO: ' || vExcecaoLinha);
          END;
          --Atualiza Status (P = Processado) HORAS TRABALHADAS COOPERADO PJ
          BEGIN
            UPDATE DBAPS.ITPAGAMENTO_PRESTADOR IPP
               SET IPP.TP_STATUS               = 'P'
             WHERE IPP.CD_PAGAMENTO_PRESTADOR  = PCD_PAGAMENTO_PRESTADOR
               AND IPP.CD_PRESTADOR            = rRepassePrestador.Cd_Prestador
               AND IPP.DS_TIPO_FOLHA           = 'HORA_TRABALHADA';
            COMMIT;
          EXCEPTION
            WHEN OTHERS THEN
              vExcecao      := NULL;
              vExcecaoLinha := NULL;
              vExcecao      := SQLERRM;
              vExcecaoLinha := DBMS_UTILITY.FORMAT_ERROR_BACKTRACE;
              Raise_Application_Error(-20999,'ERRO AO ATUALIZAR TABELA DBAPS.ITPAGAMENTO_PRESTADOR COOPERADO PJ REPASSE NR. '|| rRepassePrestador.cd_repasse_prestador ||' - '||vExcecao || ' LINHA DO ERRO: ' || vExcecaoLinha);
          END;
        END LOOP; --Fecha Loop Cursor cHoraTrabCoopPj

        OPEN cVlHorasTrabalhadasPj (rRepassePrestador.cd_repasse_prestador);
        FETCH cVlHorasTrabalhadasPj
          INTO nVlHorasTrabalhadasPj;
        CLOSE cVlHorasTrabalhadasPj;

        -- Atualizando valores do Repasse Prestados Apos os Lanca�amentos da Horas Trabalhadas Cooperado PJ
        BEGIN
          UPDATE DBAPS.REPASSE_PRESTADOR RP
             SET RP.VL_HORAS_TRABALHADAS = Nvl(nVlHorasTrabalhadasPj, 0)
           WHERE RP.CD_REPASSE_PRESTADOR = rRepassePrestador.cd_repasse_prestador;
          COMMIT;
          --Log    
          PRC_LOG_REPASSE_PREST_CLIENTE (PCD_PAGAMENTO_PRESTADOR,rRepassePrestador.cd_repasse_prestador,'HORA TRABALHADA','ATUALIZA VALOR REPASSE PRESTADOR: ' || rRepassePrestador.CD_PRESTADOR,SYSDATE);          
        EXCEPTION
          WHEN OTHERS THEN
            vExcecao      := NULL;
            vExcecaoLinha := NULL;
            vExcecao      := SQLERRM;
            vExcecaoLinha := DBMS_UTILITY.FORMAT_ERROR_BACKTRACE;
            Raise_Application_Error(-20999,'ERRO AO ATUALIZAR VALOR DE HORAS TRABALHADAS COOPERADO PJ REPASSE NR. '|| rRepassePrestador.cd_repasse_prestador ||' - '||vExcecao || ' LINHA DO ERRO: ' || vExcecaoLinha);
        END;

        /*****************************************************************************************/
        /*                                CAPITAL SOCIAL                                         */
        /*****************************************************************************************/
        nCdLogRepassePrestador := NULL;
        OPEN cLogRepassePrestador(rRepassePrestador.cd_repasse_prestador);
        FETCH cLogRepassePrestador
          INTO nCdLogRepassePrestador;
        CLOSE cLogRepassePrestador;

       
        FOR rCoopAssociadoCapitalSocial in cCoopAssociadoCapitalSocial(rRepassePrestador.Cd_Prestador) LOOP
          
          nVlCapitalSocial    := 0;
          nVlCapitalSocialRet := 0;
                                   
          --Log    
          PRC_LOG_REPASSE_PREST_CLIENTE (PCD_PAGAMENTO_PRESTADOR,rRepassePrestador.cd_repasse_prestador,'CAPITAL SOCIAL','ENTRADA CALCULO CAPITAL SOCIAL PRESTADOR: ' || rCoopAssociadoCapitalSocial.Cd_Prestador_Associado,SYSDATE);          
                                                        
          custom.pkg_repasse_prestador_cliente.PRC_DESCONTO_CAPITAL_SOCIAL(PCD_PAGAMENTO_PRESTADOR,
                                                                           rRepassePrestador.cd_repasse_prestador,
                                                                           nCdLogRepassePrestador,
                                                                           rCoopAssociadoCapitalSocial.Cd_Prestador_Associado,
                                                                           rRepassePrestador.Dt_Competencia,
                                                                           rRepassePrestador.Dt_Vencimento_Original,
                                                                           nVlCapitalSocialRet);
          --Totalizando o Desconto de Capital Social
          nVlCapitalSocial := NVL(nVlCapitalSocial,0) + NVL(nVlCapitalSocialRet,0);
          
          --Log    
          PRC_LOG_REPASSE_PREST_CLIENTE (PCD_PAGAMENTO_PRESTADOR,rRepassePrestador.cd_repasse_prestador,'CAPITAL SOCIAL','SAIDA CALCULO CAPITAL SOCIAL PRESTADOR: ' || rCoopAssociadoCapitalSocial.Cd_Prestador_Associado || ' VALOR: ' || nVlCapitalSocial,SYSDATE);
          
        END LOOP;
        -- Atualizando valores do Repasse Prestados Apos os Lanca�amentos do Capital Social Cooperado PJ
        --Log    
        PRC_LOG_REPASSE_PREST_CLIENTE (PCD_PAGAMENTO_PRESTADOR,rRepassePrestador.cd_repasse_prestador,'CAPITAL SOCIAL','ATUALIZA VALOR CAPITAL SOCIAL PRESTADOR: ' || rRepassePrestador.Cd_Prestador || ' VALOR: ' || Nvl(nVlCapitalSocial,0),SYSDATE);          
        IF nVlCapitalSocialRet > 0 THEN 
          BEGIN
            UPDATE DBAPS.REPASSE_PRESTADOR RP
               SET RP.Vl_Capital_Social = NVL(rRepassePrestador.Vl_Capital_Social,0) + Nvl(nVlCapitalSocial,0)
             WHERE RP.CD_REPASSE_PRESTADOR = rRepassePrestador.cd_repasse_prestador;
             
             nVlCapitalSocial    := 0;
             nVlCapitalSocialRet := 0;
                          
            --Log    
            PRC_LOG_REPASSE_PREST_CLIENTE (PCD_PAGAMENTO_PRESTADOR,rRepassePrestador.cd_repasse_prestador,'CAPITAL SOCIAL','ATUALIZA REPASSE DO PRESTADOR: ' || rRepassePrestador.cd_prestador || ' VALOR: ' || Nvl(nVlCapitalSocial,0),SYSDATE); 
             
          EXCEPTION
            WHEN OTHERS THEN
              vExcecao      := NULL;
              vExcecaoLinha := NULL;
              vExcecao      := SQLERRM;
              vExcecaoLinha := DBMS_UTILITY.FORMAT_ERROR_BACKTRACE;
              Raise_Application_Error(-20999,'ERRO AO ATUALIZAR VALOR DO CAPITAL SOCIAL COOPERADO PJ REPASSE NR. '|| rRepassePrestador.cd_repasse_prestador ||' - '||vExcecao || ' LINHA DO ERRO: ' || vExcecaoLinha);
          END;
        END IF;  
        /*****************************************************************************************/
        /*                                IMPOSTOS COOPERADO PJ                                  */
        /*****************************************************************************************/

        --Limpa Impostos Calculados pelo Processamento Padr�o
        DELETE dbaps.repasse_prestador_imposto rpi
         WHERE rpi.cd_repasse_prestador = rRepassePrestador.Cd_Repasse_Prestador;

        --Recalcula Imposto Prestador
        FOR rImpostoFornecedor IN cImpostoFornecedor(rRepassePrestador.cd_fornecedor) LOOP
        
          vDsDetalhamento       := NULL;
          nNrDiasVencto         := NULL;
          vTpVencimento         := NULL;
          nCdTipDoc             := NULL;
          nCdReduzido           := NULL;
          vTpIncImposto         := NULL;
          vTpData               := NULL;
          nVlPercentual         := NULL;
          nVlDeducao            := NULL;
          nVlMinRecolhimento    := NULL;
          nVlDetalhamento       := NULL;
          nVlBaseCalculoImposto := 0;

          --Carrega Valor Base de Calculo Imposto
          nVlBaseCalculoImposto := nvl(rRepassePrestador.Vl_Producao_Medica,0) + nvl(nVlHorasTrabalhadasPj,0) + nvl(rRepassePrestador.Vl_Acres_Tributavel,0);
          
          --Log    
          PRC_LOG_REPASSE_PREST_CLIENTE (PCD_PAGAMENTO_PRESTADOR,rRepassePrestador.cd_repasse_prestador,'IMPOSTO','ENTRADA CALCULO DE IMPOSTO PRESTADOR: ' || rRepassePrestador.Cd_Prestador || ' BASE DE CALCULO: ' || nVlBaseCalculoImposto,SYSDATE); 

          DBAMV.PACK_CALC_DETALHAMENTO.CALCULA_IMPOSTO_COM_INCIDENCIA(rImpostoFornecedor.cd_detalhamento,
                                                                      rRepassePrestador.cd_fornecedor,
                                                                      NULL,
                                                                      nCdMultiEmpresa,
                                                                      rRepassePrestador.Dt_Vencimento,
                                                                      nVlBaseCalculoImposto,
                                                                      vDsDetalhamento,
                                                                      nNrDiasVencto,
                                                                      vTpVencimento,
                                                                      nCdTipDoc,
                                                                      nCdReduzido,
                                                                      vTpIncImposto,
                                                                      vTpData,
                                                                      nVlPercentual,
                                                                      nVlDeducao,
                                                                      nVlMinRecolhimento,
                                                                      nVlDetalhamento,
                                                                      'N');
          --Log    
          PRC_LOG_REPASSE_PREST_CLIENTE (PCD_PAGAMENTO_PRESTADOR,rRepassePrestador.cd_repasse_prestador,'IMPOSTO','SAIDA CALCULO DE IMPOSTO PRESTADOR: ' || rRepassePrestador.Cd_Prestador || ' CD_DETALHAMENTO: '|| rImpostoFornecedor.Cd_Detalhamento || ' VL. IMPOSTO: ' || nVlDetalhamento ,SYSDATE); 
   
          -- s� insere na repasse prestador imposto se for folha do tipo Normal
          IF rRepassePrestador.TP_FOLHA = 'N' THEN
            INSERT INTO DBAPS.REPASSE_PRESTADOR_IMPOSTO
              (CD_REPASSE_PRESTADOR_IMPOSTO,
               CD_REPASSE_PRESTADOR,
               CD_DETALHAMENTO,
               VL_BASE_CALCULO,
               VL_ALIQUOTA,
               VL_IMPOSTO,
               CD_USUARIO_INCLUSAO,
               DT_INCLUSAO,
               VL_DEDUCAO,
               VL_RETENCAO,
               CD_REDUZIDO,
               VL_REMUNERACAO)
            VALUES
              (DBAPS.SEQ_REPASSE_PRESTADOR_IMPOSTO.NEXTVAL,
               rRepassePrestador.CD_REPASSE_PRESTADOR,
               rImpostoFornecedor.Cd_Detalhamento,
               nVlBaseCalculoImposto,
               nVlPercentual,
               nVlDetalhamento,
               USER,
               SYSDATE,
               nVlDeducao,
               nVlDetalhamento,
               nCdReduzido,
               nVlDetalhamento);
          END IF;
        END LOOP;

        --Atualiza Valor Total Imposto
        nVlTotalImposto := 0;

        OPEN cRepassePrestadorImposto (rRepassePrestador.CD_REPASSE_PRESTADOR);
        FETCH cRepassePrestadorImposto
         INTO nVlTotalImposto;
        CLOSE cRepassePrestadorImposto;

        -- Atualizando valores do Repasse Prestados Apos os Lanca�amentos da Horas Trabalhadas Cooperado PJ
        BEGIN
          UPDATE DBAPS.REPASSE_PRESTADOR RP
             SET RP.Vl_Impostos = Nvl(nVlTotalImposto,0)
           WHERE RP.CD_REPASSE_PRESTADOR = rRepassePrestador.cd_repasse_prestador;
        EXCEPTION
          WHEN OTHERS THEN
            vExcecao      := NULL;
            vExcecaoLinha := NULL;
            vExcecao      := SQLERRM;
            vExcecaoLinha := DBMS_UTILITY.FORMAT_ERROR_BACKTRACE;
            Raise_Application_Error(-20999,'ERRO AO ATUALIZAR VALOR DE IMPOSTOS COOPERADO PJ REPASSE NR. '|| rRepassePrestador.cd_repasse_prestador ||' - '||vExcecao || ' LINHA DO ERRO: ' || vExcecaoLinha);
        END;
        
        --Log    
        PRC_LOG_REPASSE_PREST_CLIENTE (PCD_PAGAMENTO_PRESTADOR,rRepassePrestador.cd_repasse_prestador,'IMPOSTO','ATUALIZA REPASSE: ' || rRepassePrestador.Cd_Prestador || '  VL. IMPOSTO: ' || Nvl(nVlTotalImposto,0) ,SYSDATE); 

        -- Atualiza valores do Repasse Prestador
        OPEN cVlRepassePrestador(rRepassePrestador.cd_repasse_prestador);
        FETCH cVlRepassePrestador
          INTO rVlRepassePrestador;
          IF cVlRepassePrestador%FOUND THEN
            nVlLiquido := NVL(rVlRepassePrestador.VL_PRODUCAO_MEDICA,0)   +
                          NVL(rVlRepassePrestador.VL_HORAS_TRABALHADAS,0) +
                          NVL(rVlRepassePrestador.VL_ACRESCIMOS,0)        -
                          NVL(rVlRepassePrestador.VL_DESCONTOS,0)         -
                          NVL(rVlRepassePrestador.VL_CAPITAL_SOCIAL,0)    -
                          NVL(rVlRepassePrestador.VL_IMPOSTOS,0);
            IF nVlLiquido >= 0 THEN
              BEGIN
                UPDATE DBAPS.REPASSE_PRESTADOR RP
                   SET RP.VL_LIQUIDO            = nVlLiquido,
                       RP.VL_LIQUIDO_ORIGINAL   = nVlLiquido,
                       RP.VL_SALDO_INSUFICIENTE = 0
                 WHERE RP.CD_REPASSE_PRESTADOR  = rRepassePrestador.cd_repasse_prestador;
                COMMIT;
              EXCEPTION
                WHEN OTHERS THEN
                  vExcecao      := NULL;
                  vExcecaoLinha := NULL;
                  vExcecao      := SQLERRM;
                  vExcecaoLinha := DBMS_UTILITY.FORMAT_ERROR_BACKTRACE;
                  Raise_Application_Error(-20999,'ERRO AO ATUALIZAR VALOR DE LIQUIDO COOPERADO PJ REPASSE NR. '|| rRepassePrestador.cd_repasse_prestador ||' - '||vExcecao || ' LINHA DO ERRO: ' || vExcecaoLinha);
              END;
              --Se o Saldo Liquido � positivo precisamos localizar e excluir a Fatura de Saldo Insuficiente apurado pela Rotina padrao;
              IF NVL(rVlRepassePrestador.Vl_Saldo_Insuficiente,0) < 0 THEN                
                --Log    
                PRC_LOG_REPASSE_PREST_CLIENTE (PCD_PAGAMENTO_PRESTADOR,rRepassePrestador.cd_repasse_prestador,'SALDO INSUFICIENTE INDEVIDO','PRESTADOR : ' || rRepassePrestador.Cd_Prestador || '  VL. SALDO INSUFICIENTE: ' || NVL(rVlRepassePrestador.Vl_Saldo_Insuficiente,0) ,SYSDATE); 

                --Carrega Fatura Liquido Insuficiente Gerada pela Rotina Padrao para Exclusao e Gera��o da Nova Fatura com Valor Atualizado
                OPEN cMensContratoSaldoInsuficiente (rRepassePrestador.Cd_Contrato,
                                                     to_char(rRepassePrestador.Dt_Competencia,'YYYY'),
                                                     LPAD(to_char(rRepassePrestador.Dt_Competencia,'MM'),2,0));
                FETCH cMensContratoSaldoInsuficiente
                  INTO rMensContratoSaldoInsuficiente;
                  IF cMensContratoSaldoInsuficiente%FOUND THEN
                    
                    --Apaga Fatura Liquido Insuficiente Gerada pela Rotina Padrao
                    DELETE dbaps.mens_contrato mc
                     WHERE mc.cd_mens_contrato = rMensContratoSaldoInsuficiente.cd_mens_contrato;                     
                     
                    --Log    
                    PRC_LOG_REPASSE_PREST_CLIENTE (PCD_PAGAMENTO_PRESTADOR,rRepassePrestador.cd_repasse_prestador,'SALDO INSUFICIENTE INDEVIDO','PRESTADOR : ' || rRepassePrestador.Cd_Prestador || ' REPASSE: ' || rRepassePrestador.cd_repasse_prestador || ' EXCLUINDO FATURA: ' || rMensContratoSaldoInsuficiente.cd_mens_contrato,SYSDATE);  
                    
                    --Apaga Mensagem Fatura Liquido Insuficiente Gerada pela Rotina Padrao
                    DELETE dbaps.repasse_prestador_mensagem rpm
                     WHERE rpm.cd_repasse_prestador = rRepassePrestador.cd_repasse_prestador
                       AND rpm.tp_grupo = 'OT'
                       AND instr(rpm.ds_mensagem,rMensContratoSaldoInsuficiente.cd_mens_contrato) > 0;                    
                    
                    --Log    
                    PRC_LOG_REPASSE_PREST_CLIENTE (PCD_PAGAMENTO_PRESTADOR,rRepassePrestador.cd_repasse_prestador,'SALDO INSUFICIENTE INDEVIDO','PRESTADOR : ' || rRepassePrestador.Cd_Prestador || '  EXCLUINDO MENSAGEM REPASSE: ' || rRepassePrestador.cd_repasse_prestador,SYSDATE);  
                    COMMIT;
                  END IF;
                CLOSE cMensContratoSaldoInsuficiente;                        
              END IF;
            ELSIF nVlLiquido < 0 THEN
              BEGIN
                UPDATE DBAPS.REPASSE_PRESTADOR RP
                   SET RP.VL_LIQUIDO            = 0,
                       RP.VL_LIQUIDO_ORIGINAL   = 0,
                       RP.VL_SALDO_INSUFICIENTE = nVlLiquido
                 WHERE RP.CD_REPASSE_PRESTADOR  = rRepassePrestador.cd_repasse_prestador;                
                COMMIT;
                --Log    
                PRC_LOG_REPASSE_PREST_CLIENTE (PCD_PAGAMENTO_PRESTADOR,rRepassePrestador.cd_repasse_prestador,'ATUALIZA SALDO INSUFICIENTE','PRESTADOR : ' || rRepassePrestador.Cd_Prestador || ' REPASSE: ' || rRepassePrestador.cd_repasse_prestador || ' VL SALDO INSUFICIENTE: ' || NVL(nVlLiquido,0),SYSDATE);  
                    
              EXCEPTION
                WHEN OTHERS THEN
                  vExcecao      := NULL;
                  vExcecaoLinha := NULL;
                  vExcecao      := SQLERRM;
                  vExcecaoLinha := DBMS_UTILITY.FORMAT_ERROR_BACKTRACE;
                  Raise_Application_Error(-20999,'ERRO AO ATUALIZAR VALOR DE LIQUIDO COOPERADO PJ REPASSE NR. '|| rRepassePrestador.cd_repasse_prestador ||' - '||vExcecao || ' LINHA DO ERRO: ' || vExcecaoLinha);
              END;
            END IF;
          END IF;
          --Log    
          PRC_LOG_REPASSE_PREST_CLIENTE (PCD_PAGAMENTO_PRESTADOR,rRepassePrestador.cd_repasse_prestador,'ATUALIZA REPASSE','PRESTADOR: ' || rRepassePrestador.Cd_Prestador || '  VL. LIQUIDO: ' || nVlLiquido,SYSDATE); 

          --***************************************************************************************************
          --*                LIQUIDO INSUFICIENTE - SALDO NEGATIVO - GERAR BOLETO                             *
          --***************************************************************************************************
          IF nVlLiquido < 0 THEN
                        
            nVlSaldoInsuficiente := 0;

            OPEN cLiquidoNegativo (rRepassePrestador.CD_REPASSE_PRESTADOR);
            FETCH cLiquidoNegativo
              INTO nVlSaldoInsuficiente;
              -- N�o gerar boleto se saldo insuficiente for menor que X reais (R$) - Valor Minimo
              IF nVlSaldoInsuficiente < 0 AND C_VL_MINIMO_LIQUIDO_INSUF > nVlSaldoInsuficiente THEN
                
                --Log    
                PRC_LOG_REPASSE_PREST_CLIENTE (PCD_PAGAMENTO_PRESTADOR,rRepassePrestador.cd_repasse_prestador,'LIQUIDO INSUFICIENTE',' PRESTADOR: ' || rRepassePrestador.Cd_Prestador || ' VL. ' || nVlSaldoInsuficiente,SYSDATE); 


                IF rRepassePrestador.cd_contrato IS NULL THEN
                  Raise_Application_Error(-20999,'PRESTADOR: ' ||rRepassePrestador.CD_PRESTADOR ||' - N�O POSSUI CONTRATO PARA GERA��O DE T�TULO. FAVOR PROVIDENCIAR');
                END IF;
                IF rConfigMVS.CD_LCTO_MENSALIDADE_PREST_COOP IS NULL THEN
                  Raise_Application_Error(-20999,'N�O EXISTE ITEM DE RECEITA CONFIGURADO PARA SALDO INSUFICIENTE');
                END IF;

                -- Trava para evitar Gera��o de Fatura sem Parametro contabil
                IF DBAPS.FNC_CONFIG_CONTABIL(null, rConfigMVS.CD_LCTO_MENSALIDADE_PREST_COOP) <> 0 THEN
                 Raise_Application_Error(-20999,'T�tulo do l�quido insuficiente n�o foi gerado porque n�o existe configura��o cont�bil. Favor solicitar ao setor cont�bil da OPERADORA a configura��o financeira/cont�bil do item de receita ' || rConfigMVS.CD_LCTO_MENSALIDADE_PREST_COOP );
                END IF;

                --Carrega Fatura Liquido Insuficiente Gerada pela Rotina Padrao para Exclusao e Gera��o da Nova Fatura com Valor Atualizado
                OPEN cMensContratoSaldoInsuficiente (rRepassePrestador.Cd_Contrato,
                                                     to_char(rRepassePrestador.Dt_Competencia,'YYYY'),
                                                     LPAD(to_char(rRepassePrestador.Dt_Competencia,'MM'),2,0));
                FETCH cMensContratoSaldoInsuficiente
                  INTO rMensContratoSaldoInsuficiente;
                  IF cMensContratoSaldoInsuficiente%FOUND THEN

                    --Apaga Fatura Liquido Insuficiente Gerada pela Rotina Padrao
                    DELETE dbaps.mens_contrato mc
                     WHERE mc.cd_mens_contrato = rMensContratoSaldoInsuficiente.cd_mens_contrato;

                    --Apaga Mensagem Fatura Liquido Insuficiente Gerada pela Rotina Padrao
                    DELETE dbaps.repasse_prestador_mensagem rpm
                     WHERE rpm.cd_repasse_prestador = rRepassePrestador.cd_repasse_prestador
                       AND rpm.tp_grupo = 'OT'
                       AND instr(rpm.ds_mensagem,rMensContratoSaldoInsuficiente.cd_mens_contrato) > 0;

                  END IF;
                CLOSE cMensContratoSaldoInsuficiente;

                -- Realiza o lan�amento na tabela de MENS_CONTRATO
                nCdMensContrato := NULL;

                SELECT DBAPS.SEQ_MENS_CONTRATO.NEXTVAL
                  INTO nCdMensContrato
                  FROM SYS.DUAL;

                --Carrega Data Fim da Cobertura
                dDtFinalCobertura := NULL;
                dDtFinalCobertura := rRepassePrestador.Dt_Vencimento_Original + 30;

                BEGIN
                  INSERT INTO DBAPS.MENS_CONTRATO
                    (CD_MENS_CONTRATO,
                     CD_CONTRATO,
                     NR_MES,
                     NR_ANO,
                     DT_EMISSAO,
                     DT_VENCIMENTO,
                     DT_VENCIMENTO_ORIGINAL,
                     VL_MENSALIDADE,
                     SN_EMITIDO,
                     CD_PARCELA,
                     TP_RECEITA,
                     CD_MULTI_EMPRESA,
                     DS_OBSERVACAO,
                     DT_INICIO_COBERTURA,
                     DT_FINAL_MENSALIDADE,
                     DT_CONTABILIZACAO,
                     CD_REPASSE_PRESTADOR)
                  VALUES
                    (nCdMensContrato,
                     rRepassePrestador.cd_contrato, --CD_CONTRATO
                     To_Char(rRepassePrestador.dt_competencia, 'MM'), -- NR_MES
                     To_Char(rRepassePrestador.dt_competencia, 'YYYY'), -- NR_ANO
                     rRepassePrestador.Dt_Vencimento_Original, -- DT_EMISSAO (GPS-1202 SOROCABA DESEJA DATA DE EMISSAO O VENCIMENTO DA FOLHA
                     To_Date(rRepassePrestador.Nr_Dia_Vencimento ||to_char(rRepassePrestador.Dt_Vencimento_Original, 'mm/yyyy'),'dd/mm/yyyy'), -- DT_VENCIMENTO
                     To_Date(rRepassePrestador.Nr_Dia_Vencimento ||to_char(rRepassePrestador.Dt_Vencimento_Original, 'mm/yyyy'),'dd/mm/yyyy'), -- DT_VENCIMENTO_ORIGINAL
                     Abs(nVlSaldoInsuficiente), -- VL_MENSALIDADE
                     'N', -- SN_EMITIDO
                     NULL, -- CD_PARCELA
                     'P', -- TP_RECEITA
                     nCdMultiEmpresa, -- CD_MULTI_EMPRESA
                     'LIQUIDO INSUFICIENTE COMPET�NCIA ' ||To_Char(rRepassePrestador.dt_competencia, 'MMYYYY') ||' - REPASSE PRESTADOR: ' || rRepassePrestador.cd_repasse_prestador,--DS_OBSERVACAO
                     rRepassePrestador.Dt_Vencimento_Original, --DT_INICIO_COBERTURA
                     dDtFinalCobertura,--DT_FINAL_MENSALIDADE
                     Trunc(SYSDATE), --DT_CONTABILIZACAO
                     rRepassePrestador.cd_repasse_prestador --CD_REPASSE_PRESTADOR
                     );
                EXCEPTION
                  WHEN OTHERS THEN
                    vExcecao      := NULL;
                    vExcecaoLinha := NULL;
                    vExcecao      := SQLERRM;
                    vExcecaoLinha := DBMS_UTILITY.FORMAT_ERROR_BACKTRACE;
                    Raise_Application_Error(-20777, 'ERRO AO INSERIR REGISTRO TABELA DBAPS.MENS_CONTRATO -> ' || vExcecao || ' - ' || vExcecaoLinha);
                END;
                -- Realiza o lan�amento na tabela de ITMENS_CONTRATO
                BEGIN
                  INSERT INTO DBAPS.ITMENS_CONTRATO
                    (CD_LCTO_MENSALIDADE,
                     CD_MENS_CONTRATO,
                     VL_LANCAMENTO,
                     QT_LANCAMENTO)
                  VALUES
                    (rConfigMVS.CD_LCTO_MENSALIDADE_PREST_COOP,
                     nCdMensContrato,
                     Abs(nVlSaldoInsuficiente),
                     1);
                EXCEPTION
                  WHEN OTHERS THEN
                    vExcecao      := NULL;
                    vExcecaoLinha := NULL;
                    vExcecao      := SQLERRM;
                    vExcecaoLinha := DBMS_UTILITY.FORMAT_ERROR_BACKTRACE;
                    Raise_Application_Error(-20888, 'ERRO AO INSERIR REGISTRO TABELA DBAPS.ITMENS_CONTRATO -> ' || vExcecao || ' - ' || vExcecaoLinha);
                END;
                
                --Log    
                PRC_LOG_REPASSE_PREST_CLIENTE (PCD_PAGAMENTO_PRESTADOR,rRepassePrestador.cd_repasse_prestador,'LIQUIDO INSUFICIENTE','FATURA: '|| nCdMensContrato || ' CONTRATO: '|| rRepassePrestador.cd_contrato,SYSDATE); 
                
                nCdLogRepassePrestador := NULL;

                OPEN cLogRepassePrestador(rRepassePrestador.cd_repasse_prestador);
                FETCH cLogRepassePrestador
                  INTO nCdLogRepassePrestador;
                CLOSE cLogRepassePrestador;

                IF nCdLogRepassePrestador IS NOT NULL THEN
                  DBAPS.PACK_MVS_REPASSE_PRESTADOR.P_GRAVA_LOG_REP_PRES_MENS_ERRO(nCdLogRepassePrestador, 'GERADO TITULO DE NUMERO: ' || nCdMensContrato,'A');
                END IF;

                BEGIN
                  INSERT INTO DBAPS.REPASSE_PRESTADOR_MENSAGEM
                    (CD_REPASSE_PRESTADOR_MENSAGEM,
                     CD_REPASSE_PRESTADOR,
                     DS_MENSAGEM,
                     TP_GRUPO)
                  VALUES
                    (DBAPS.SEQ_REPASSE_PRESTADOR_MENSAGEM.NEXTVAL,
                     rRepassePrestador.cd_repasse_prestador,
                     'ATEN��O PRESTADOR - GERADO BOLETO DE N� ' || nCdMensContrato ||
                     ' REFERENTE AO SALDO INSUFICIENTE NO VALOR DE R$ ' ||
                     Abs(nVlSaldoInsuficiente) || '. VENCIMENTO PARA O DIA : ' ||
                     To_Char(Last_Day(rRepassePrestador.dt_vencimento), 'DD/MM/YYYY'),
                     'OT');
                EXCEPTION
                  WHEN OTHERS THEN
                    vExcecao      := NULL;
                    vExcecaoLinha := NULL;
                    vExcecao      := SQLERRM;
                    vExcecaoLinha := DBMS_UTILITY.FORMAT_ERROR_BACKTRACE;
                    Raise_Application_Error(-20999, 'ERRO AO INSERIR REGISTRO TABELA DBAPS.REPASSE_PRESTADOR_MENSAGEM -> ' || vExcecao || ' - ' || vExcecaoLinha);
                END;
                --Log    
                PRC_LOG_REPASSE_PREST_CLIENTE (PCD_PAGAMENTO_PRESTADOR,rRepassePrestador.cd_repasse_prestador,'LIQUIDO INSUFICIENTE','INSERE MENSAGEM DA FATURA: '|| nCdMensContrato || ' CONTRATO: '|| rRepassePrestador.cd_contrato,SYSDATE); 
              END IF;
            CLOSE cLiquidoNegativo;
          END IF;
        CLOSE cVlRepassePrestador;
      END LOOP; --Fecha Loop Principal
      
      --Limpa Repasse Zerado       
      FOR rRepassePrestadorZerado IN cRepassePrestadorZerado LOOP              
        
        BEGIN
          DELETE DBAPS.ITPAGAMENTO_PRESTADOR IT
           WHERE IT.CD_PAGAMENTO_PRESTADOR = PCD_PAGAMENTO_PRESTADOR
             AND IT.CD_PRESTADOR = rRepassePrestadorZerado.Cd_Prestador; 
            
          DELETE DBAPS.REPASSE_PRESTADOR RP
           WHERE RP.CD_PAGAMENTO_PRESTADOR = PCD_PAGAMENTO_PRESTADOR 
             AND RP.CD_REPASSE_PRESTADOR   = rRepassePrestadorZerado.Cd_Repasse_Prestador;
        
        EXCEPTION
          WHEN OTHERS THEN
            vExcecao      := SQLERRM;
            vExcecaoLinha := DBMS_UTILITY.FORMAT_ERROR_BACKTRACE;
            Raise_Application_Error(-20999,'ERRO DO DELETAR REPASSE PRESTADOR ZERADO : ' || rRepassePrestadorZerado.Cd_Repasse_Prestador || ' - ' || vExcecao || ' LINHA DO ERRO: ' || vExcecaoLinha);             
        END;        
        COMMIT;
        --Log    
        PRC_LOG_REPASSE_PREST_CLIENTE (PCD_PAGAMENTO_PRESTADOR,rRepassePrestadorZerado.Cd_Repasse_Prestador,'LIMPA REPASSE ZERADO',' PRESTADOR: ' || rRepassePrestadorZerado.Cd_Repasse_Prestador,SYSDATE);    
             
      END LOOP; 
      
    --Verifica se na Folha de Cooperado Pessoa Fisica do Tipo 0 gerou cobran�a de Capital Social ou Repasse Zerado e para o Cooperado PJ, que precisa ser excluido.
    ELSIF nvl(rPagamentoPrestadoCoopPJ.Sn_Cooperado_Pj,'N') = 'N' AND rPagamentoPrestadoCoopPJ.CD_TIP_PRESTADOR = 0 THEN

      --Limpa Repasse Zerado       
      FOR rRepassePrestadorZerado IN cRepassePrestadorZerado LOOP              
        
        BEGIN
          DELETE DBAPS.ITPAGAMENTO_PRESTADOR IT
           WHERE IT.CD_PAGAMENTO_PRESTADOR = PCD_PAGAMENTO_PRESTADOR
             AND IT.CD_PRESTADOR = rRepassePrestadorZerado.Cd_Prestador; 
            
          DELETE DBAPS.REPASSE_PRESTADOR RP
           WHERE RP.CD_PAGAMENTO_PRESTADOR = PCD_PAGAMENTO_PRESTADOR 
             AND RP.CD_REPASSE_PRESTADOR   = rRepassePrestadorZerado.Cd_Repasse_Prestador;
        
        EXCEPTION
          WHEN OTHERS THEN
            vExcecao      := SQLERRM;
            vExcecaoLinha := DBMS_UTILITY.FORMAT_ERROR_BACKTRACE;
            Raise_Application_Error(-20999,'ERRO DO DELETAR REPASSE PRESTADOR ZERADO : ' || rRepassePrestadorZerado.Cd_Repasse_Prestador || ' - ' || vExcecao || ' LINHA DO ERRO: ' || vExcecaoLinha);             
        END;        
        COMMIT;
        --Log    
        PRC_LOG_REPASSE_PREST_CLIENTE (PCD_PAGAMENTO_PRESTADOR,rRepassePrestadorZerado.Cd_Repasse_Prestador,'LIMPA REPASSE ZERADO',' PRESTADOR: ' || rRepassePrestadorZerado.Cd_Repasse_Prestador,SYSDATE);                 
      END LOOP;               
      
      --Limpa Repasse que gerou Capital Social para o Cooperado PJ
      FOR rRepassePrestadorCooperado IN cRepassePrestadorCooperado LOOP                
        IF rRepassePrestadorCooperado.Vl_Liquido            =  0 AND
           rRepassePrestadorCooperado.vl_capital_social     <> 0 AND 
           rRepassePrestadorCooperado.Vl_Saldo_Insuficiente <> 0 THEN          
          --Chamada da Rotina Padrao MV de Cancelamento da Folha
          dbaps.prc_cancela_pag_prestador (PCD_PAGAMENTO_PRESTADOR,rRepassePrestadorCooperado.cd_prestador);          
          --Limpa Tabela ITPAGAMENTO_PRESTADOR
          DELETE DBAPS.ITPAGAMENTO_PRESTADOR IPP
           WHERE IPP.CD_PAGAMENTO_PRESTADOR = PCD_PAGAMENTO_PRESTADOR
             AND IPP.CD_PRESTADOR = rRepassePrestadorCooperado.cd_prestador;              
          COMMIT;          
          --Log    
          PRC_LOG_REPASSE_PREST_CLIENTE (PCD_PAGAMENTO_PRESTADOR,rRepassePrestadorCooperado.Cd_Repasse_Prestador,'LIMPA CAPITAL SOCIAL',' PRESTADOR: ' || rRepassePrestadorCooperado.cd_prestador,SYSDATE);                                       
        END IF;
      END LOOP;      
    END IF;
    --Log    
    PRC_LOG_REPASSE_PREST_CLIENTE (PCD_PAGAMENTO_PRESTADOR,NULL,'FIM','PONTO DE SAIDA COOPERADO PJ' ,SYSDATE);    
    COMMIT;
  EXCEPTION
    WHEN OTHERS THEN
      vExcecao      := SQLERRM;
      vExcecaoLinha := DBMS_UTILITY.FORMAT_ERROR_BACKTRACE;
      Raise_Application_Error(-20999,'ERRO: ' || vExcecao || ' LINHA DO ERRO: ' || vExcecaoLinha);
  END PRC_REPASSE_PRESTADOR_CLIENTE;

  -- (02) -> RECALCULO CUSTOMIZADO DO IMPOSTO DA FOLHA DE PRESTADORES (GRUPO 27 - COOPERADO PJ)
  PROCEDURE PRC_RECALC_IMP_REPASSE_CLIENTE (PCD_REPASSE_PRESTADOR IN NUMBER) IS

    --************************
    --        Cursores      --
    --************************

    -- Verifica se o Codigo da Folha � do Tipo Prestador 27 - Cooperado PJ
    CURSOR cSnPagamentoPrestadoCoopPJ IS
      SELECT 'S' SN_COOPERADO_PJ
        FROM DBAPS.PAGAMENTO_PRESTADOR PP,
             DBAPS.REPASSE_PRESTADOR   RP
       WHERE PP.CD_PAGAMENTO_PRESTADOR = RP.CD_PAGAMENTO_PRESTADOR
         AND RP.CD_REPASSE_PRESTADOR   = PCD_REPASSE_PRESTADOR
         AND PP.CD_TIP_PRESTADOR       = 27;

    --Carrega Fornecedor Repasse
    CURSOR cFornecedorRepasse IS
      SELECT P.CD_FORNECEDOR
        FROM DBAPS.PRESTADOR         P,
             DBAPS.REPASSE_PRESTADOR RP
       WHERE P.CD_PRESTADOR          = RP.CD_PRESTADOR
         AND RP.CD_REPASSE_PRESTADOR = PCD_REPASSE_PRESTADOR;

    -- Carrega Impostos Fornecedor
    CURSOR cImpostoFornecedor (PCD_FORNECEDOR IN NUMBER) IS
      SELECT FD.CD_DETALHAMENTO,
             FD.SN_RETEM_SERVICO SN_RETEM,
             TD.CD_ITEM_RES,
             TD.TP_DETALHAMENTO
        FROM DBAMV.FORN_DETALHAMENTO FD,
             DBAMV.TIP_DETALHE       TD
       WHERE FD.CD_DETALHAMENTO      = TD.CD_DETALHAMENTO
         AND FD.CD_FORNECEDOR        = PCD_FORNECEDOR
         AND FD.CD_MULTI_EMPRESA     = 1
         AND FD.SN_RETEM_SERVICO     = 'S'
         AND ((TD.TP_DATA <> 'P' AND Nvl(dbaps.fnc_mvs_retorna_valor_config('CONFIG_IMPOSTFOLHA_TRAVA_PGTO',1),'N') = 'N') OR
             (dbaps.fnc_mvs_retorna_valor_config('CONFIG_IMPOSTFOLHA_TRAVA_PGTO',1) = 'S'));

    --Carrega Valores Repasse Prestador
    CURSOR cRepassePrestador (PCD_REPASSE_PRESTADOR IN NUMBER) IS
      SELECT NVL(RP.VL_PRODUCAO_MEDICA,0) VL_PRODUCAO_MEDICA,
             NVL(RP.VL_HORAS_TRABALHADAS,0) VL_HORAS_TRABALHADAS,
             NVL(RP.VL_ACRESCIMOS,0) VL_ACRESCIMOS,
             NVL(RP.VL_DESCONTOS,0) VL_DESCONTOS,
             NVL(RP.VL_CAPITAL_SOCIAL,0) VL_CAPITAL_SOCIAL,
             NVL(RP.VL_IMPOSTOS,0) VL_IMPOSTOS,
             NVL(RP.VL_LIQUIDO,0) VL_LIQUIDO,
             NVL(RP.VL_LIQUIDO_ORIGINAL,0) VL_LIQUIDO_ORIGINAL,
             PP.DT_VENCIMENTO,
             PP.TP_FOLHA,
             NVL((SELECT SUM(PV.VL_LANCAMENTO)
                    FROM DBAPS.PRESTADOR_CREDITO_DEBITO PV,
                         DBAPS.ITPAGAMENTO_PRESTADOR    IP
                   WHERE IP.CD_PRESTADOR                = PV.CD_PRESTADOR
                     AND IP.CD_FATURA                   = PV.CD_FATURA
                     AND IP.CD_PAGAMENTO_PRESTADOR      = RP.CD_PAGAMENTO_PRESTADOR
                     AND PV.CD_PRESTADOR                = RP.CD_PRESTADOR
                     AND PV.CD_REPASSE_PRESTADOR        = PCD_REPASSE_PRESTADOR
                     AND PV.CD_ITEM_DESPESA             = '41'),0) VL_ACRES_TRIBUTAVEL
        FROM DBAPS.PAGAMENTO_PRESTADOR PP,
             DBAPS.REPASSE_PRESTADOR   RP
       WHERE PP.CD_PAGAMENTO_PRESTADOR = RP.CD_PAGAMENTO_PRESTADOR
         AND RP.CD_REPASSE_PRESTADOR   = PCD_REPASSE_PRESTADOR;

     --Carrega Valor dos Impostos Cooperado PJ
    CURSOR cRepassePrestadorImposto IS
      SELECT SUM(NVL(RPI.VL_IMPOSTO,0)) VL_IMPOSTO
        FROM DBAPS.REPASSE_PRESTADOR_IMPOSTO RPI
       WHERE RPI.CD_REPASSE_PRESTADOR = PCD_REPASSE_PRESTADOR;

    --************************
    --        Variaveis     --
    --************************
    nCdMultiEmpresa         NUMBER;
    vDsDetalhamento         VARCHAR2(100);
    nNrDiasVencto           NUMBER;
    vTpVencimento           VARCHAR2(100);
    nCdTipDoc               NUMBER;
    nCdReduzido             NUMBER;
    vTpIncImposto           VARCHAR2(100);
    vTpData                 VARCHAR2(100);
    nVlPercentual           NUMBER;
    nVlDeducao              NUMBER;
    nVlMinRecolhimento      NUMBER;
    nVlDetalhamento         NUMBER;
    nCdFornecedor           NUMBER;
    nVlBaseCalculoImposto   NUMBER;
    nVlTotalImposto         NUMBER;
    nVlDifencaImposto       NUMBER;
    nVlLiquidoNovo          NUMBER;
    vExcecao                VARCHAR2(4000);
    vExcecaoLinha           VARCHAR2(4000);

    --****************************
    --   Variaveis Tipo Cursor  --
    --****************************
    rRepassePrestador           cRepassePrestador%ROWTYPE;
    rSnPagamentoPrestadoCoopPJ  cSnPagamentoPrestadoCoopPJ%ROWTYPE;

  BEGIN

    -- Default Variaves
    nCdFornecedor         := NULL;
    nCdMultiEmpresa       := 1;
    nVlBaseCalculoImposto := 0;
    nVlDifencaImposto     := 0;
    nVlLiquidoNovo        := 0;

    -- Verifica se a Folha � do Tipo de Prestador 27 - Cooperado PJ
    OPEN cSnPagamentoPrestadoCoopPJ;
    FETCH cSnPagamentoPrestadoCoopPJ
      INTO rSnPagamentoPrestadoCoopPJ;
    CLOSE cSnPagamentoPrestadoCoopPJ;

    IF nvl(rSnPagamentoPrestadoCoopPJ.Sn_Cooperado_Pj,'N') = 'S' THEN

      --Recalcula Imposto Prestador
      OPEN cFornecedorRepasse;
      FETCH cFornecedorRepasse
        INTO nCdFornecedor;

        IF cFornecedorRepasse%FOUND THEN

          --Limpa Impostos Calculados pelo Processamento Padr�o
          DELETE dbaps.repasse_prestador_imposto rpi
           WHERE rpi.cd_repasse_prestador = PCD_REPASSE_PRESTADOR;

          --Carrega Valor Base de Calculo Imposto
          OPEN cRepassePrestador(PCD_REPASSE_PRESTADOR);
          FETCH cRepassePrestador
            INTO rRepassePrestador;
          CLOSE cRepassePrestador;

          FOR rImpostoFornecedor IN cImpostoFornecedor(nCdFornecedor) LOOP

            vDsDetalhamento       := NULL;
            nNrDiasVencto         := NULL;
            vTpVencimento         := NULL;
            nCdTipDoc             := NULL;
            nCdReduzido           := NULL;
            vTpIncImposto         := NULL;
            vTpData               := NULL;
            nVlPercentual         := NULL;
            nVlDeducao            := NULL;
            nVlMinRecolhimento    := NULL;
            nVlDetalhamento       := NULL;
            nVlBaseCalculoImposto := 0;

            --Carrega Base de Calculo (Produ��o + Horas Trabalhadas + Acrescimo Tributavel - Evento->  "41 ESTORNO - PGTO JA REALIZADO"
            nVlBaseCalculoImposto := nvl(rRepassePrestador.Vl_Producao_Medica,0) + nvl(rRepassePrestador.Vl_Horas_Trabalhadas,0) + nvl(rRepassePrestador.Vl_Acres_Tributavel,0);

            DBAMV.PACK_CALC_DETALHAMENTO.CALCULA_IMPOSTO_COM_INCIDENCIA(rImpostoFornecedor.cd_detalhamento,
                                                                        nCdFornecedor,
                                                                        NULL,
                                                                        nCdMultiEmpresa,
                                                                        rRepassePrestador.Dt_Vencimento,
                                                                        nVlBaseCalculoImposto,
                                                                        vDsDetalhamento,
                                                                        nNrDiasVencto,
                                                                        vTpVencimento,
                                                                        nCdTipDoc,
                                                                        nCdReduzido,
                                                                        vTpIncImposto,
                                                                        vTpData,
                                                                        nVlPercentual,
                                                                        nVlDeducao,
                                                                        nVlMinRecolhimento,
                                                                        nVlDetalhamento,
                                                                        'N');

            -- S� insere na repasse prestador imposto se for folha do tipo Normal
            IF rRepassePrestador.TP_FOLHA = 'N' THEN
              INSERT INTO DBAPS.REPASSE_PRESTADOR_IMPOSTO
                (CD_REPASSE_PRESTADOR_IMPOSTO,
                 CD_REPASSE_PRESTADOR,
                 CD_DETALHAMENTO,
                 VL_BASE_CALCULO,
                 VL_ALIQUOTA,
                 VL_IMPOSTO,
                 CD_USUARIO_INCLUSAO,
                 DT_INCLUSAO,
                 VL_DEDUCAO,
                 VL_RETENCAO,
                 CD_REDUZIDO,
                 VL_REMUNERACAO)
              VALUES
                (DBAPS.SEQ_REPASSE_PRESTADOR_IMPOSTO.NEXTVAL,
                 PCD_REPASSE_PRESTADOR,
                 rImpostoFornecedor.Cd_Detalhamento,
                 nVlBaseCalculoImposto,
                 nVlPercentual,
                 nVlDetalhamento,
                 USER,
                 SYSDATE,
                 nVlDeducao,
                 nVlDetalhamento,
                 nCdReduzido,
                 nVlDetalhamento);
              COMMIT;
            END IF;
          END LOOP;
          --Atualiza Valor Total Imposto
          nVlTotalImposto := 0;

          OPEN cRepassePrestadorImposto;
          FETCH cRepassePrestadorImposto
           INTO nVlTotalImposto;
          CLOSE cRepassePrestadorImposto;

          -- Atualizando valores do Repasse Prestados Apos os Lan�amentos dos Impostos Cooperado PJ
          nVlDifencaImposto := nvl(rRepassePrestador.Vl_Impostos,0) - nvl(nVlTotalImposto,0);

          --Se imposto igual ao anterior - n�o h� nada a fazer
          IF nVlDifencaImposto = 0 THEN
             RETURN;
          END IF;

          BEGIN
            --ir� adicionar ou remover valor liquido de acordo com o sinal matematico de nDiferencaIMposto (- ou +)
            nVlLiquidoNovo := rRepassePrestador.Vl_Liquido + nVlDifencaImposto;

            UPDATE DBAPS.REPASSE_PRESTADOR RP
               SET RP.VL_IMPOSTOS = nVlTotalImposto,
                   RP.VL_LIQUIDO  = nVlLiquidoNovo
             WHERE CD_REPASSE_PRESTADOR = PCD_REPASSE_PRESTADOR;

            COMMIT;

          EXCEPTION
            WHEN OTHERS THEN
              vExcecao      := NULL;
              vExcecaoLinha := NULL;
              vExcecao      := SQLERRM;
              vExcecaoLinha := DBMS_UTILITY.FORMAT_ERROR_BACKTRACE;
              Raise_Application_Error(-20999,'ERRO AO ATUALIZAR VALOR DE IMPOSTOS COOPERADO PJ REPASSE NR. '|| PCD_REPASSE_PRESTADOR ||' - '||vExcecao || ' LINHA DO ERRO: ' || vExcecaoLinha);
          END;
        END IF;
      CLOSE cFornecedorRepasse;
    END IF;
    COMMIT;
  EXCEPTION
    WHEN OTHERS THEN
      vExcecao      := NULL;
      vExcecaoLinha := NULL;
      vExcecao      := SQLERRM;
      vExcecaoLinha := DBMS_UTILITY.FORMAT_ERROR_BACKTRACE;
      Raise_Application_Error(-20999,'FALHA GERAL NO RECALCULO DE IMPOSTO COOPERADO PJ DEMONSTRATIVO: '|| PCD_REPASSE_PRESTADOR ||' - '||vExcecao || ' LINHA DO ERRO: ' || vExcecaoLinha);
  END PRC_RECALC_IMP_REPASSE_CLIENTE;

  -- (03) -> DESCONTO CAPITAL COOPERADOR PJ
  PROCEDURE PRC_DESCONTO_CAPITAL_SOCIAL (PCD_PAGAMENTO_PRESTADOR   IN NUMBER,
                                         PCD_REPASSE_PRESTADOR     IN NUMBER,
                                         PCD_LOG_REPASSE_PRESTADOR IN NUMBER,
                                         PCD_PRESTADOR             IN NUMBER,
                                         PDT_COMPETENCIA           IN DATE,
                                         PDT_VENCIMENTO            IN DATE,
                                         PVL_CAPITAL_SOCIAL_RET    OUT NUMBER) IS

    --Carrega Valores para Desconto de Capital Social
    CURSOR cCapitalSocial (PCD_PRESTADOR     IN NUMBER,
                           PCD_MULTI_EMPRESA IN NUMBER) IS
      SELECT P.CD_PRESTADOR,
             CUSTOM.PKG_REPASSE_PRESTADOR_CLIENTE.FNC_RETORNA_PREST_PAGAMENTO(P.CD_PRESTADOR) CD_PRESTADOR_PAGAMENTO,
             P.TP_DESCONTO_CAPITAL_SOCIAL,
             CASE
               WHEN (NVL(M.VL_TOTAL, 0) - (NVL(PAGAS.VL_QUOTA_PARCELAS_PAGAS, 0) + NVL(TRANSFERENCIAS.VL_TRANSFERENCIAS, 0))) > NVL(M.VL_MENSAL_PAGAMENTO, 0) THEN NVL(M.VL_MENSAL_PAGAMENTO, 0)
               ELSE (NVL(M.VL_TOTAL, 0) - (NVL(PAGAS.VL_QUOTA_PARCELAS_PAGAS, 0) + NVL(TRANSFERENCIAS.VL_TRANSFERENCIAS, 0)))
             END VL_MENSAL_ATUAL,
             M.CD_MODELO_CAPITAL_SOCIAL
        FROM DBAPS.PRESTADOR               P,
             DBAPS.MODELO_CAPITAL_SOCIAL   M,
             (SELECT COUNT(1) QT_QUOTA_PARCELAS_PAGAS,
                     NVL(SUM(MCR.VL_RECEBIMENTO), 0) VL_QUOTA_PARCELAS_PAGAS,
                     P.CD_PRESTADOR,
                     MAX(MC.CD_MENS_CONTRATO) CD_MENS_CONTRATO_PAGA
                FROM DBAPS.MENS_CONTRATO     MC,
                     DBAPS.PRESTADOR         P,
                     DBAPS.CONTRATO          C,
                     DBAPS.MENS_CONTRATO_REC MCR
               WHERE P.CD_PRESTADOR          = C.CD_PRESTADOR
                 AND P.CD_PRESTADOR          = PCD_PRESTADOR
                 AND MCR.CD_MENS_CONTRATO    = MC.CD_MENS_CONTRATO
                 AND C.CD_CONTRATO           = MC.CD_CONTRATO
                 AND NVL(C.SN_ATIVO, 'S')    = 'S'
                 AND P.CD_MULTI_EMPRESA      = 1
                 AND MC.TP_QUITACAO          IN ('P', 'Q')
                 AND MC.DT_CANCELAMENTO      IS NULL
                 AND MC.CD_MODELO_CAPITAL_SOCIAL IS NOT NULL
               GROUP BY P.CD_PRESTADOR) PAGAS,
             (SELECT COUNT(1) QT_TRANSFERENCIAS,
                     SUM(T.VL_TRANSFERENCIA) VL_TRANSFERENCIAS,
                     P.CD_PRESTADOR
                FROM DBAPS.PRESTADOR P, DBAPS.TRANSFERENCIA_CAPITAL_SOCIAL T
               WHERE P.CD_PRESTADOR = T.CD_PRESTADOR_PARA
                 AND P.CD_PRESTADOR = PCD_PRESTADOR
               GROUP BY P.CD_PRESTADOR) TRANSFERENCIAS
       WHERE P.CD_PRESTADOR                = PCD_PRESTADOR
         AND P.CD_MODELO_CAPITAL_SOCIAL    = M.CD_MODELO_CAPITAL_SOCIAL(+)
         AND P.CD_PRESTADOR                = PAGAS.CD_PRESTADOR(+)
         AND P.CD_PRESTADOR                = TRANSFERENCIAS.CD_PRESTADOR(+)
         AND P.DT_SUSPENSAO_CAPITAL_SOCIAL IS NULL
         AND P.CD_MULTI_EMPRESA            = PCD_MULTI_EMPRESA;

    -- CURSOR CAPITAL SOCIAL NO CONTRATO DO PRESTADOR
    CURSOR cMensContrato(P_CD_PRESTADOR         IN NUMBER,
                         P_CD_REPASSE_PRESTADOR IN NUMBER) IS
      SELECT P.CD_PRESTADOR,
             P.NM_PRESTADOR,
             MS.CD_MENS_CONTRATO,
             C.NM_RESPONSAVEL_FINANCEIRO,
             MS.DT_EMISSAO,
             VL_MENSALIDADE,
             MS.NR_MES,
             MS.NR_ANO,
             MS.TP_QUITACAO,
             MS.CD_PROCESS_CB,
             NVL(PCB.SN_ABERTO, 'S') SN_ABERTO,
             P.TP_DESCONTO_CAPITAL_SOCIAL,
             C.CD_CONTRATO,
             MCR.DT_RECEBIMENTO
        FROM DBAPS.MENS_CONTRATO     MS,
             DBAPS.PROCESS_CB        PCB,
             DBAPS.PRESTADOR         P,
             DBAPS.CONTRATO          C,
             DBAPS.MENS_CONTRATO_REC MCR
       WHERE C.CD_PRESTADOR          = P.CD_PRESTADOR
         AND P.CD_PRESTADOR          = P_CD_PRESTADOR
         AND MS.CD_MENS_CONTRATO     = MCR.CD_MENS_CONTRATO(+)
         AND MS.CD_PROCESS_CB        = PCB.CD_PROCESS_CB(+)
         AND MS.CD_CONTRATO          = C.CD_CONTRATO
         AND MS.DT_CANCELAMENTO      IS NULL
         AND C.TP_CONTRATO           = 'P'
         AND P.CD_MULTI_EMPRESA      = 1
         AND MS.CD_REPASSE_PRESTADOR = P_CD_REPASSE_PRESTADOR
         AND MS.TP_RECEITA           IN ('T', 'O') -- outras/capital social
       ORDER BY MS.DT_EMISSAO;

    -- CURSOR DE DADOS DOS PRESTADORES
    CURSOR cPrestadores(PCD_PRESTADOR IN NUMBER) IS
      SELECT P.CD_PRESTADOR,
             P.NM_PRESTADOR,
             P.TP_DESCONTO_CAPITAL_SOCIAL,
             P.CD_MODELO_CAPITAL_SOCIAL
        FROM DBAPS.PRESTADOR          P,
             DBAPS.TIP_PRESTADOR      TP
       WHERE P.CD_TIP_PRESTADOR       = TP.CD_TIP_PRESTADOR
         AND P.CD_MULTI_EMPRESA       = 1
         AND P.CD_PRESTADOR           = PCD_PRESTADOR
         AND P.CD_MODELO_CAPITAL_SOCIAL IS NOT NULL
         AND P.DT_SUSPENSAO_CAPITAL_SOCIAL IS NULL;

    -- CURSOR DE DADOS DO LANCAMENTO/ITEM DESPESA
    CURSOR cLctoMensalidade(nCdLctoMensalidade IN NUMBER) IS
      SELECT ID.CD_ITEM_DESPESA,
             LM.CD_LCTO_MENSALIDADE,
             LM.TP_OPERACAO
        FROM DBAPS.ITEM_DESPESA ID,
             DBAPS.LCTO_MENSALIDADE LM
       WHERE ID.CD_ITEM_DESPESA     = LM.CD_ITEM_DESPESA
         AND LM.CD_LCTO_MENSALIDADE = nCdLctoMensalidade;

    -- CURSOR DE DADOS DO CONTRATO
    CURSOR cContrato(PCD_PRESTADOR IN NUMBER) IS
      SELECT CD_CONTRATO,
             NVL(NR_DIA_VENCIMENTO,
             TO_NUMBER(TO_CHAR(LAST_DAY(SYSDATE), 'DD'))) NR_DIA_VENCIMENTO
        FROM DBAPS.CONTRATO
       WHERE CD_PRESTADOR = PCD_PRESTADOR
         AND NVL(SN_ATIVO, 'S') = 'S';

    CURSOR cContaCorrenteOperadora IS
      SELECT CC.NR_AGENCIA,
             CC.NR_BANCO,
             CC.NR_CONTA_CORRENTE,
             ME.CD_CONTA_CORRENTE_CP_CO CD_CONTA_CORRENTE
        FROM DBAPS.CONTA_CORRENTE CC,
             DBAMV.MULTI_EMPRESAS_MV_SAUDE ME
       WHERE CC.CD_CONTA_CORRENTE = ME.CD_CONTA_CORRENTE_CP_CO /*ME.CD_CONTA_CORRENTE_BAIXA_AUT*/
         AND CC.CD_MULTI_EMPRESA = ME.CD_MULTI_EMPRESA
         AND CC.CD_MULTI_EMPRESA = 1;

    -- CARREGA O CODIGO DO LCTO_MENSALIDADE CONFIGURADO PARA DESCONTO DE CONTRATOS NA TELA DE CONFIGURACOES
    CURSOR cConfigCapitalSocial IS
      SELECT MEMS.CD_ITEM_CAPITAL_SOCIAL,
             MEMS.SN_QUITAR_DESP_PREST_COOPERADO
        FROM DBAMV.MULTI_EMPRESAS_MV_SAUDE MEMS
       WHERE MEMS.CD_MULTI_EMPRESA = 1;

     --Verifica se existe Registro Tabela Dbaps.itpagamento_prestador sem Fatura
    CURSOR cItPagamentoPrestador IS
      SELECT COUNT(*) QT_REGISTRO,
             CUSTOM.PKG_REPASSE_PRESTADOR_CLIENTE.FNC_RETORNA_PREST_PAGAMENTO(PCD_PRESTADOR) CD_PRESTADOR_PAGAMENTO
       FROM DBAPS.ITPAGAMENTO_PRESTADOR IPP
      WHERE IPP.CD_PAGAMENTO_PRESTADOR  = PCD_PAGAMENTO_PRESTADOR
        AND IPP.CD_PRESTADOR            = CUSTOM.PKG_REPASSE_PRESTADOR_CLIENTE.FNC_RETORNA_PREST_PAGAMENTO(PCD_PRESTADOR)
        AND IPP.CD_FATURA               IS NULL;

    --************************
    --        Constante     --
    --************************
    C_CD_MULTI_EMPRESA  CONSTANT NUMBER := 1;

    --************************
    --        Variaveis     --
    --************************
    nCdRedCapitalSocial          dbamv.multi_empresas_mv_saude.cd_reduzido_baixa_producao%TYPE;
    nCdLctoMensalidade           NUMBER;
    vSnQuitarDespPrestCooperado  VARCHAR2(1);
    nCdMensContrato              NUMBER;
    nCdPresCrDb                  NUMBER;
    nCdMensContratoRecRet        NUMBER;
    nCdProcessCb                 NUMBER(20);
    dDtEmissao                   DATE;
    dDtVencimento                DATE;
    vDsMensagemErro              VARCHAR2(4000);
    vExcecao                     VARCHAR2(4000);
    vExcecaoLinha                VARCHAR2(4000);

    --****************************
    --   Variaveis Tipo Cursor  --
    --****************************
    rLctoMensalidade         cLctoMensalidade%ROWTYPE;
    rPrestadores             cPrestadores%ROWTYPE;
    rCapitalSocial           cCapitalSocial%ROWTYPE;
    rMensContrato            cMensContrato%ROWTYPE;
    rContrato                cContrato%ROWTYPE;
    rContaCorrenteOperadora  cContaCorrenteOperadora%ROWTYPE;
    rItPagamentoPrestador    cItPagamentoPrestador%ROWTYPE;

  BEGIN

    -- Default Variaves
    nCdLctoMensalidade           := 0;
    vSnQuitarDespPrestCooperado  := 'N';
    nCdMensContrato              := 0;
    nCdPresCrDb                  := 0;
    nCdMensContratoRecRet        := 0;
    nCdMensContrato              := 0;
    nCdPresCrDb                  := 0;
    nCdMensContratoRecRet        := 0;
    dDtEmissao                   := NULL;
    vDsMensagemErro              := NULL;
    vExcecao                     := NULL;
    vExcecaoLinha                := NULL;

    --Verifica se h� paramatros cadastrados para o desconto de Capital Social
    OPEN cConfigCapitalSocial ;
    FETCH cConfigCapitalSocial
      INTO nCdLctoMensalidade,
           vSnQuitarDespPrestCooperado;
    CLOSE cConfigCapitalSocial;

    IF NVL(nCdLctoMensalidade, 0) <> 0 THEN
      --Verifica dados do Evento de Capital Social Cadastrado
      OPEN cLctoMensalidade(nCdLctoMensalidade);
        FETCH cLctoMensalidade
          INTO rLctoMensalidade;
        IF cLctoMensalidade%FOUND THEN
          --Verifica se Existe Modelo de Capital Social Cadastrado para o Prestador
          OPEN cPrestadores(PCD_PRESTADOR);
          FETCH cPrestadores
            INTO rPrestadores;
            IF cPrestadores%FOUND THEN
              --Verifica se j� existe Fatura de Capital Social para na mesma competencia
              OPEN cMensContrato(rPrestadores.CD_PRESTADOR,PCD_REPASSE_PRESTADOR);
              FETCH cMensContrato
                INTO rMensContrato;
                --Verifica se existe contrato cadastrado no prestador para geracao da fatura de Capital Social
                IF cMensContrato%NOTFOUND THEN
                  OPEN cContrato(rPrestadores.Cd_Prestador);
                  FETCH cContrato
                    INTO rContrato;
                    IF cContrato%FOUND THEN
                      -- Verifica se o prestador tem valor de Capital Social a ser descontado
                      OPEN cCapitalSocial (rPrestadores.Cd_Prestador,C_CD_MULTI_EMPRESA);
                      FETCH cCapitalSocial
                       INTO rCapitalSocial;
                      CLOSE cCapitalSocial;
                      -- Realiza Lan�amento da Fatura de Capital Social
                      IF nvl(rCapitalSocial.Vl_Mensal_Atual,0) > 0 THEN

                        --Carrega Tabela dbaps.itPagamento_prestador com Registro do Tipo Capital_Social
                        OPEN cItPagamentoPrestador;
                        FETCH cItPagamentoPrestador
                          INTO rItPagamentoPrestador;
                        CLOSE cItPagamentoPrestador;

                        IF nvl(rItPagamentoPrestador.qt_registro,0) = 0 THEN
                          BEGIN

                            --Limpa os lan�amentos de Horas Trabalhadas da Tabela ItPagamentoPrestador
                            DELETE DBAPS.ITPAGAMENTO_PRESTADOR IPP
                             WHERE IPP.CD_PAGAMENTO_PRESTADOR = PCD_PAGAMENTO_PRESTADOR
                               AND IPP.CD_PRESTADOR           = rItPagamentoPrestador.cd_prestador_pagamento
                               AND IPP.DS_TIPO_FOLHA          = 'CAPITAL_SOCIAL';
                            COMMIT;

                            INSERT INTO DBAPS.ITPAGAMENTO_PRESTADOR
                              (CD_ITPAGAMENTO_PRESTADOR,
                               CD_PAGAMENTO_PRESTADOR,
                               CD_FATURA,
                               CD_PRESTADOR,
                               CD_USUARIO_INCLUSAO,
                               DT_INCLUSAO,
                               TP_STATUS,
                               DS_MOTIVO_INVALIDO,
                               DS_TIPO_FOLHA,
                               NR_NOTA_FISCAL)
                            VALUES
                              (DBAPS.SEQ_ITPAGAMENTO_PRESTADOR.NEXTVAL,
                               PCD_PAGAMENTO_PRESTADOR,
                               NULL,
                               rItPagamentoPrestador.cd_prestador_pagamento,
                               USER,
                               SYSDATE,
                               'P', --I-> INVALIDA; C-> CARREGADA; P-> PROCESSADA
                               NULL, --DS_MOTIVO_INVALIDO (DETALHA O MOTIVO PELA QUAL A FATURA NAO PODE SER PROCESSADA
                               'CAPITAL_SOCIAL',
                               NULL);
                          EXCEPTION
                            WHEN OTHERS THEN
                               vExcecao      := SQLERRM;
                               vExcecaoLinha := DBMS_UTILITY.FORMAT_ERROR_BACKTRACE;
                               Raise_Application_Error(-20999,'ERRO AO INSERIR NA TABELA: DBAPS.ITPAGAMENTO_PRESTADOR ' || vExcecao || ' LINHA DO ERRO: ' || vExcecaoLinha ||
                               ' - ' || rItPagamentoPrestador.qt_registro || ' - ' || PCD_PRESTADOR);
                          END;
                          COMMIT;
                        END IF;

                        --Carrega Sequencia Tabela Dbaps.Mens_Contrato
                        SELECT DBAPS.SEQ_MENS_CONTRATO.NEXTVAL
                          INTO nCdMensContrato
                          FROM SYS.DUAL;

                        --Carrega Dt. Vencimento Fatura
                        dDtVencimento   := NULL;                        
                        IF TO_CHAR(PDT_COMPETENCIA, 'MM') = '02' AND rContrato.Nr_Dia_Vencimento > 28 THEN
                          dDtVencimento := NVL(PDT_VENCIMENTO,LAST_DAY(PDT_COMPETENCIA));
                        ELSE                                  
                          dDtVencimento   := NVL(PDT_VENCIMENTO,TO_DATE(lpad(rContrato.Nr_Dia_Vencimento,2,0) || TO_CHAR(PDT_COMPETENCIA, 'MM') || '/' || TO_CHAR(PDT_COMPETENCIA, 'YYYY'),'DD/MM/YYYY'));
                        END IF;  
                        
                        --Carrega Dt. Emissao Fatura
                        dDtEmissao      := NULL;
                        IF TRUNC(SYSDATE) > LAST_DAY(PDT_COMPETENCIA) THEN
                           dDtEmissao := LAST_DAY(PDT_COMPETENCIA);
                        ELSIF TRUNC(SYSDATE) <= LAST_DAY(PDT_COMPETENCIA) AND TO_CHAR(SYSDATE,'YYYYMM') = TO_CHAR(PDT_COMPETENCIA,'YYYYMM') THEN
                           dDtEmissao := TRUNC(SYSDATE);
                        ELSE
                          dDtEmissao  := LAST_DAY(PDT_COMPETENCIA);
                        END IF;

                        --Carrega Mensagem Fatura
                        vDsMensagemErro := 'COBRANCA DE CAPITAL SOCIAL BOLETO NUMERO ' || nCdMensContrato || ' COMP: ' || TO_CHAR(PDT_COMPETENCIA, 'MM') || '/' || TO_CHAR(PDT_COMPETENCIA, 'YYYY');

                        BEGIN
                          INSERT INTO DBAPS.MENS_CONTRATO
                            (CD_MENS_CONTRATO,
                             CD_CONTRATO,
                             NR_MES,
                             NR_ANO,
                             DT_EMISSAO,
                             DT_VENCIMENTO,
                             DT_VENCIMENTO_ORIGINAL,
                             VL_MENSALIDADE,
                             SN_EMITIDO,
                             CD_PARCELA,
                             TP_RECEITA,
                             CD_MULTI_EMPRESA,
                             DS_OBSERVACAO,
                             CD_REPASSE_PRESTADOR,
                             CD_MODELO_CAPITAL_SOCIAL)
                          VALUES
                            (nCdMensContrato,
                             rContrato.CD_CONTRATO,
                             TO_CHAR(PDT_COMPETENCIA, 'MM'),
                             TO_CHAR(PDT_COMPETENCIA, 'YYYY'),
                             dDtEmissao,
                             dDtVencimento,
                             dDtVencimento,
                             rCapitalSocial.VL_MENSAL_ATUAL,
                             'N',
                             NULL,
                             'T',
                             C_CD_MULTI_EMPRESA,
                             vDsMensagemErro,
                             PCD_REPASSE_PRESTADOR,
                             rCapitalSocial.CD_MODELO_CAPITAL_SOCIAL);
                        EXCEPTION
                          WHEN OTHERS THEN
                            vExcecao      := NULL;
                            vExcecaoLinha := NULL;
                            vExcecao      := SQLERRM;
                            vExcecaoLinha := DBMS_UTILITY.FORMAT_ERROR_BACKTRACE;
                            Raise_Application_Error(-20999,'ERRO AO INSERIR FATURA CAPITAL SOCIAL NRO ' || nCdMensContrato || 'COOPERADO PJ REPASSE NR. '|| PCD_REPASSE_PRESTADOR ||' - '||vExcecao || ' LINHA DO ERRO: ' || vExcecaoLinha);
                        END;
                        -- REALIZA O LANCAMENTO NA TABELA DE ITMENS_CONTRATO
                        BEGIN
                          INSERT INTO DBAPS.ITMENS_CONTRATO
                            (CD_LCTO_MENSALIDADE,
                             CD_MENS_CONTRATO,
                             VL_LANCAMENTO,
                             QT_LANCAMENTO)
                          VALUES
                            (rLctoMensalidade.CD_LCTO_MENSALIDADE,
                             nCdMensContrato,
                             DECODE(rLctoMensalidade.TP_OPERACAO,'D',rCapitalSocial.VL_MENSAL_ATUAL * (-1),rCapitalSocial.VL_MENSAL_ATUAL),
                             1);
                        EXCEPTION
                          WHEN OTHERS THEN
                            vExcecao      := NULL;
                            vExcecaoLinha := NULL;
                            vExcecao      := SQLERRM;
                            vExcecaoLinha := DBMS_UTILITY.FORMAT_ERROR_BACKTRACE;
                            Raise_Application_Error(-20999,'ERRO AO INSERIR DBAPS.ITMENS_CONTRATO NRO: ' || nCdMensContrato || ' COOPERADO PJ REPASSE NR. '|| PCD_REPASSE_PRESTADOR ||' - '|| vExcecao || ' LINHA DO ERRO: ' || vExcecaoLinha);
                        END;
                        -- VERIFICA SE O DESCONTO DE CAPITAL VAI OCORRER NA PRODUCAO MEDICA PARA LIQUIDAR A FATURA GERADA
                        IF NVL(rCapitalSocial.Tp_Desconto_Capital_Social,'PM') = 'PM' THEN
                          -- Cria Lote de Cobran�a Avulso para Fatura de Capital Social
                          OPEN cContaCorrenteOperadora;
                          FETCH cContaCorrenteOperadora
                            INTO rContaCorrenteOperadora;
                          CLOSE cContaCorrenteOperadora;

                          nCdProcessCb := NULL;
                          nCdProcessCb := dbaps.fnc_atribuir_lote_cobranca_mvs(nCdMensContrato,
                                                                               rContrato.CD_CONTRATO,
                                                                               vDsMensagemErro,
                                                                               rContaCorrenteOperadora.CD_CONTA_CORRENTE,
                                                                               NULL);
                          --Grava Log Lote de Cobran�a
                          IF (NVL(nCdProcessCb, 0) <> 0) THEN
                            DBAPS.PACK_MVS_REPASSE_PRESTADOR.P_GRAVA_LOG_REP_PRES_MENS_ERRO(PCD_LOG_REPASSE_PRESTADOR,
                                                                                            'LOTE DE COBRANCA '      ||
                                                                                            TO_CHAR(nCdProcessCb)    ||
                                                                                            ' GERADO PARA O BOLETO ' ||
                                                                                            TO_CHAR(nCdMensContrato),'A');
                          ELSE
                            vDsMensagemErro := 'NAO FOI POSSIVEL GERAR O LOTE DE COBRANCA PARA O BOLETO ' || TO_CHAR(nCdMensContrato);
                            DBAPS.PACK_MVS_REPASSE_PRESTADOR.P_GRAVA_LOG_REP_PRES_MENS_ERRO(PCD_LOG_REPASSE_PRESTADOR,vDsMensagemErro,'A');
                            DBAPS.PACK_MVS_REPASSE_PRESTADOR.P_GRAVA_REPASSE_PREST_MENSAGEM(PCD_REPASSE_PRESTADOR,vDsMensagemErro,'CS');
                          END IF;

                          -- Realiza Baixa da
                          nCdMensContratoRecRet := NULL;

                          --CARREGA CODIGO REDUZIDO PARA BAIXA CAPITAL SOCIAL
                          BEGIN
                            SELECT CD_REDUZIDO_BAIXA_PRODUCAO
                              INTO nCdRedCapitalSocial
                              FROM DBAMV.MULTI_EMPRESAS_MV_SAUDE
                             WHERE CD_MULTI_EMPRESA = C_CD_MULTI_EMPRESA;
                          EXCEPTION
                            WHEN Others THEN
                              Raise_Application_Error(-20999,'CAPITAL SOCIAL - N�O FOI CONFIGURADA CONTA CONTABIL PARA CAPITAL SOCIAL (DBAMV.MULTI_EMPRESAS_MV_SAUDE.CD_REDUZIDO_BAIXA_PRODUCAO)');
                          END;
                          DBAPS.PRC_MENS_CONTRATO_REC(P_ACAO                    => 'REC',
                                                      PCD_SISTEMA_BAIXA         => 'MVS#' || nCdRedCapitalSocial,
                                                      PCD_MENS_CONTRATO         => nCdMensContrato,
                                                      PCD_RECCON_REC            => NULL,
                                                      PDT_RECEBIMENTO           => SYSDATE,
                                                      PDT_CREDITO               => SYSDATE,
                                                      PVL_RECEBIMENTO           => rCapitalSocial.VL_MENSAL_ATUAL,
                                                      PDT_ESTORNO               => NULL,
                                                      PCD_MENS_CONTRATO_REC_RET => nCdMensContratoRecRet,
                                                      PVL_DESCONTO              => NULL,
                                                      PVL_ACRESCIMO             => NULL);

                          IF nCdMensContratoRecRet IS NOT NULL THEN vDsMensagemErro := 'BOLETO ' || TO_CHAR(nCdMensContrato) || ' DESCONTADO EM PRODUCAO MEDICA';

                            -- REALIZA O LANCAMENTO NA TABELA PRESTADOR_CREDITO_DEBITO
                            INSERT INTO DBAPS.PRESTADOR_CREDITO_DEBITO
                              (CD_PRES_CR_DB,
                               CD_FATURA,
                               CD_LOTE,
                               CD_PRESTADOR,
                               TP_LANCAMENTO,
                               VL_LANCAMENTO,
                               DS_USER_INCLUSAO,
                               DT_INCLUSAO,
                               CD_ITEM_DESPESA,
                               CD_MENS_CONTRATO,
                               DS_OBSERVACAO,
                               CD_REPASSE_PRESTADOR,
                               CD_MODELO_CAPITAL_SOCIAL)
                            VALUES
                              (DBAPS.SEQ_PRESTADOR_CREDITO_DEBITO.NEXTVAL,
                               NULL,
                               NULL,
                               rPrestadores.CD_PRESTADOR,
                               'D',
                               rCapitalSocial.VL_MENSAL_ATUAL,
                               USER,
                               SYSDATE,
                               rLctoMensalidade.CD_ITEM_DESPESA,
                               nCdMensContrato,
                               vDsMensagemErro,
                               PCD_REPASSE_PRESTADOR,
                               rCapitalSocial.CD_MODELO_CAPITAL_SOCIAL);

                            PVL_CAPITAL_SOCIAL_RET := rCapitalSocial.VL_MENSAL_ATUAL;
                            DBAPS.PACK_MVS_REPASSE_PRESTADOR.P_GRAVA_LOG_REP_PRES_MENS_ERRO(PCD_LOG_REPASSE_PRESTADOR,vDsMensagemErro,'A');
                          ELSE
                            vDsMensagemErro := 'BOLETO ' || TO_CHAR(nCdMensContrato) || ' NAO QUITADO POIS HOUVE FALHA NA BAIXA';
                            DBAPS.PACK_MVS_REPASSE_PRESTADOR.P_GRAVA_LOG_REP_PRES_MENS_ERRO(PCD_LOG_REPASSE_PRESTADOR,vDsMensagemErro,'A');
                            DBAPS.PACK_MVS_REPASSE_PRESTADOR.P_GRAVA_REPASSE_PREST_MENSAGEM(PCD_REPASSE_PRESTADOR,vDsMensagemErro,'CS');
                          END IF;
                        --<RLUCAS> 09/01/2023 -- CRIA O LOTE DE COBRANCA AVULSO PARA A FATURA DE CAPITAL SOCIAL QUE O TIPO DE DESCONTO SEJA BBOLETO AVULSO
                        ELSIF NVL(rCapitalSocial.Tp_Desconto_Capital_Social,'PM') = 'BA' THEN
                          nCdProcessCb := NULL;
                          nCdProcessCb := DBAPS.FNC_ATRIBUIR_LOTE_COBRANCA_MVS(nCdMensContrato,
                                                                               RCONTRATO.CD_CONTRATO,
                                                                               vDsMensagemErro,
                                                                               10,
                                                                               NULL);

                          IF (NVL(nCdProcessCb, 0) <> 0) THEN DBAPS.PACK_MVS_REPASSE_PRESTADOR.P_GRAVA_LOG_REP_PRES_MENS_ERRO(PCD_LOG_REPASSE_PRESTADOR,
                                                                                                                              'LOTE DE COBRANCA ' ||
                                                                                                                              TO_CHAR(nCdProcessCb) ||
                                                                                                                              ' GERADO PARA O BOLETO ' ||
                                                                                                                              TO_CHAR(nCdMensContrato),
                                                                                                                              'A');
                          ELSE
                            vDsMensagemErro := 'NAO FOI POSSIVEL GERAR O LOTE DE COBRANCA PARA O BOLETO ' || TO_CHAR(nCdMensContrato);
                            DBAPS.PACK_MVS_REPASSE_PRESTADOR.P_GRAVA_LOG_REP_PRES_MENS_ERRO(PCD_LOG_REPASSE_PRESTADOR,vDsMensagemErro,'A');
                            DBAPS.PACK_MVS_REPASSE_PRESTADOR.P_GRAVA_REPASSE_PREST_MENSAGEM(PCD_REPASSE_PRESTADOR,vDsMensagemErro,'CS');
                          END IF;
                        END IF;
                      END IF;
                    END IF;
                  CLOSE cContrato;
                END IF;
              CLOSE cMensContrato;
            END IF;
          CLOSE cPrestadores;
        END IF;
      CLOSE cLctoMensalidade;
    END IF;
  EXCEPTION
    WHEN OTHERS THEN
      vExcecao      := NULL;
      vExcecaoLinha := NULL;
      vExcecao      := SQLERRM;
      vExcecaoLinha := DBMS_UTILITY.FORMAT_ERROR_BACKTRACE;
      RAISE_APPLICATION_ERROR (-20099,'FALHA GERAL PKG_REPASSE_PRESTADOR_CLIENTE.PRC_DESCONTO_CAPITAL_SOCIAL ' || 'ERRO -> ' || vExcecao || 'LINHA ->  ' || vExcecaoLinha);
  END PRC_DESCONTO_CAPITAL_SOCIAL;

  -- (04) -> FUN��O QUE RETORNA O PRESTADOR PAGAMENTO GRUPO 27 - COOPERADO PJ
  FUNCTION FNC_RETORNA_PREST_PAGAMENTO (PCD_PRESTADOR IN NUMBER)
    RETURN NUMBER IS

    --Verifica Prestador Pagamento Cooperado PJ
    CURSOR cPrestadorAssociado IS
      SELECT PA.CD_PRESTADOR
        FROM DBAPS.PRESTADOR_ASSOCIADO PA,
             DBAPS.PRESTADOR           P,
             DBAPS.TIP_PRESTADOR       TIP
       WHERE 1 = 1
         AND PA.CD_PRESTADOR           = P.CD_PRESTADOR
         AND P.CD_TIP_PRESTADOR        = TIP.CD_TIP_PRESTADOR
         AND PA.CD_PRESTADOR_ASSOCIADO = PCD_PRESTADOR
         AND P.TP_SITUACAO             = 'A'
         AND TIP.TP_TIP_PRESTADOR      = 6
         AND PA.SN_REPASSE_PJ          = 'S'
         AND P.CD_TIP_PRESTADOR        = 27
         AND PA.DT_INICIO              <= TRUNC(SYSDATE)
         AND P.DT_INI_SERVICO          <= TRUNC(SYSDATE)
         AND (PA.DT_TERMINO IS NULL OR PA.DT_TERMINO >= TRUNC(SYSDATE));

    nCdPrestadorAssociado NUMBER;

  BEGIN

    --Default Variavel
    nCdPrestadorAssociado := NULL;

    OPEN cPrestadorAssociado;
    FETCH cPrestadorAssociado
      INTO nCdPrestadorAssociado;
    CLOSE cPrestadorAssociado;

    RETURN nCdPrestadorAssociado;

  EXCEPTION
    WHEN OTHERS THEN
    RETURN NULL;
  END FNC_RETORNA_PREST_PAGAMENTO;
  
  -- (05) -> MIGRA OS CONTRATOS COM DESCONTO EM PRODU��O NA CADASTRO DE PESSOA FISICA DO COOPERADO PARA O EMPRESA DO COOPERADO PJ
  PROCEDURE PRC_PREST_DESC_PROD_COOP_PJ IS
    
    CURSOR cPrestDescProdCoopPj IS 
      SELECT PDP.CD_PRESTADOR_DESCONTO_PRODUCAO,
             PDP.CD_PRESTADOR CD_PRESTADOR_ORIGEM,
             PA.CD_PRESTADOR CD_PRESTADOR_PAGAMENTO,
             PP.DT_INI_SERVICO  DT_INICIO_VIGENCIA_PJ,
             PP.DT_INI_SERVICO - 1 DT_FIM_VIGENCIA_PF,
             PDP.CD_CONTRATO,
             CO.TP_COBRANCA,
             PDP.DT_INICIO_VIGENCIA,
             PDP.DT_FIM_VIGENCIA,
             PDP.DT_INCLUSAO,
             PDP.CD_USUARIO_INCLUSAO
        FROM DBAPS.PRESTADOR                   PR,
             DBAPS.PRESTADOR_ASSOCIADO         PA,
             DBAPS.PRESTADOR                   PP,
             DBAPS.PRESTADOR_DESCONTO_PRODUCAO PDP,
             DBAPS.CONTRATO                    CO
       WHERE PR.CD_PRESTADOR                   = PA.CD_PRESTADOR_ASSOCIADO
         AND PA.CD_PRESTADOR                   = PP.CD_PRESTADOR
         AND PR.CD_PRESTADOR                   = PDP.CD_PRESTADOR
         AND PDP.CD_CONTRATO                   = CO.CD_CONTRATO
         AND CO.TP_COBRANCA                    = 'F' -- FOLHA 
         AND PP.CD_TIP_PRESTADOR               = 27  -- COOPERADO PJ
         AND PP.TP_SITUACAO                    = 'A' -- ATIVO
         AND PP.DT_INI_SERVICO                 <= TRUNC(SYSDATE)
         AND (PA.DT_TERMINO IS NULL OR PA.DT_TERMINO > TRUNC(SYSDATE))
         AND NOT EXISTS (SELECT 1 
                           FROM DBAPS.PRESTADOR_DESCONTO_PRODUCAO DP
                          WHERE DP.CD_PRESTADOR = PA.CD_PRESTADOR
                            AND DP.CD_CONTRATO  = PDP.CD_CONTRATO)
      ORDER BY 2;
                
    nSeqPrestDescontoProducao   NUMBER;
    nSeqPrestDescontoContrato   NUMBER;
    vCdUsuarioIntegracao        VARCHAR2(5);
    dDtFimVigenciaCoopPj        DATE;
                
  BEGIN
      
    nSeqPrestDescontoProducao := NULL;
    nSeqPrestDescontoContrato := NULL;
    vCdUsuarioIntegracao      := 'DBAMV';
    dDtFimVigenciaCoopPj      := to_date('01/01/2050','dd/mm/yyyy');
    
    FOR rPrestDescProdCoopPj IN cPrestDescProdCoopPj LOOP
                          
      --INATIVA O CONTRATO NO CADASTRO DO PRESTADOR PESSOA FISICA DO COOPERADO 
      BEGIN
        UPDATE DBAPS.PRESTADOR_DESCONTO_PRODUCAO DP
           SET DP.DT_FIM_VIGENCIA = rPrestDescProdCoopPj.DT_FIM_VIGENCIA_PF
         WHERE DP.CD_PRESTADOR_DESCONTO_PRODUCAO = rPrestDescProdCoopPj.CD_PRESTADOR_DESCONTO_PRODUCAO;
      EXCEPTION
        WHEN OTHERS THEN
          NULL;
      END;     
      -- INICIA O DESCONTO DO CONTRATO NA EMPRESA DO COOPERADO PJ
      BEGIN
                  
        nSeqPrestDescontoProducao := DBAPS.SEQ_PREST_DESCONTO_PRODUCAO.NEXTVAL;
           
        INSERT INTO DBAPS.PRESTADOR_DESCONTO_PRODUCAO
          (cd_prestador_desconto_producao,
           cd_prestador,
           cd_contrato,
           dt_inicio_vigencia,
           dt_fim_vigencia,
           dt_inclusao,
           cd_usuario_inclusao)
        VALUES
          (nSeqPrestDescontoProducao,
           rPrestDescProdCoopPj.cd_prestador_pagamento,
           rPrestDescProdCoopPj.cd_contrato,
           rPrestDescProdCoopPj.Dt_Inicio_Vigencia_Pj,
           dDtFimVigenciaCoopPj,
           SYSDATE,
           vCdUsuarioIntegracao);      
      EXCEPTION
        WHEN OTHERS THEN
          ROLLBACK;
          NULL;  
      END;
      
      -- CRIA O RELACIONAMENTO DO CONTRATO COM DESCONTO NA PRODUCAO DO COOPERADO PESSOA FISICA COM A EMPRESA DO COOPERADO PJ
      BEGIN    
                
        nSeqPrestDescontoContrato := CUSTOM.SEQ_PREST_DESCONTO_CONTRATO.NEXTVAL;        

        INSERT INTO custom.prestador_desconto_contrato pdc  
          (cd_prestador_desconto_contrato,
           cd_prestador_desconto_producao,
           cd_prestador_desc_prod_origem,
           cd_prestador_origem,
           cd_usuario_inclusao,
           dt_inclusao)
        VALUES
          (nSeqPrestDescontoContrato,
           nSeqPrestDescontoProducao,
           rPrestDescProdCoopPj.Cd_Prestador_Desconto_Producao,
           rPrestDescProdCoopPj.Cd_Prestador_Origem,
           USER,
           SYSDATE);      
      EXCEPTION
        WHEN OTHERS THEN 
          ROLLBACK;
          NULL;  
      END;
    END LOOP;    
  COMMIT;
  EXCEPTION
    WHEN OTHERS THEN 
      ROLLBACK;
      NULL;  
  END PRC_PREST_DESC_PROD_COOP_PJ;
  
  -- (06) -> GERAR LOG CALCULO REPASSE PRESTADOR CLIENTE
  PROCEDURE PRC_LOG_REPASSE_PREST_CLIENTE (PCD_PAGAMENTO_PRESTADOR NUMBER,
                                           PCD_REPASSE_PRESTADOR   NUMBER,
                                           PDS_ETAPA               VARCHAR2,
                                           PDS_MENSAGEM            VARCHAR2,
                                           PDT_INCLUSAO            DATE) IS
                                             
    nSeqLogRepasseCliente NUMBER;
    vExcecao              VARCHAR2(4000);
    vExcecaoLinha         VARCHAR2(4000);
        
  BEGIN    
    
    BEGIN
      SELECT CUSTOM.SEQ_LOG_REPASSE_PREST_CLIENTE.NEXTVAL
        INTO nSeqLogRepasseCliente
        FROM DUAL;
    EXCEPTION
      WHEN OTHERS THEN
      Raise_Application_Error(-20001,'Erro ao gerar a chave prim�ria da tabela DBAPS.LOG_REPASSE_PRESTADOR_CLIENTE');       
    END;  
    
    BEGIN
    INSERT INTO CUSTOM.LOG_REPASSE_PRESTADOR_CLIENTE 
      (CD_LOG_REPASSE_PREST_CLIENTE,
       CD_PAGAMENTO_PRESTADOR,
       CD_REPASSE_PRESTADOR,
       DS_ETAPA,
       DS_MENSAGEM,
       DT_INCLUSAO)
    VALUES
      (nSeqLogRepasseCliente,
       PCD_PAGAMENTO_PRESTADOR,
       PCD_REPASSE_PRESTADOR,
       PDS_ETAPA,
       PDS_MENSAGEM,
       PDT_INCLUSAO);      
    EXCEPTION
      WHEN OTHERS THEN 
        Raise_Application_Error(-20001,'Erro ao Gravar Dados Tabela DBAPS.LOG_REPASSE_PRESTADOR_CLIENTE');              
    END;
    COMMIT;     
  EXCEPTION
    WHEN OTHERS THEN 
      vExcecao      := NULL;
      vExcecaoLinha := NULL;
      vExcecao      := SQLERRM;
      vExcecaoLinha := DBMS_UTILITY.FORMAT_ERROR_BACKTRACE;
      Raise_Application_Error(-20999,'ERRO : ' || ' - ' || vExcecao || ' LINHA DO ERRO: ' || vExcecaoLinha);      
  END PRC_LOG_REPASSE_PREST_CLIENTE;                                                                                      
END PKG_REPASSE_PRESTADOR_CLIENTE;