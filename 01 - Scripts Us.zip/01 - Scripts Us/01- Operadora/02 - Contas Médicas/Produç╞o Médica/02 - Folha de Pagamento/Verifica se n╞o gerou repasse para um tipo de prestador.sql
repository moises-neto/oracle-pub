Select *
  From v_Ctas_Medicas v, Dbaps.Prestador p
 Where v.Cd_Prestador_Pagamento = p.Cd_Prestador
   And v.Dt_Competencia = '202208'
   And p.Cd_Tip_Prestador = 18
   And v.Tp_Pagcob In ('PN', 'CP')
   And v.Tp_Situacao_Conta In ('AA', 'AT')
   And v.Tp_Situacao_Itconta In ('AA', 'AT')
   And v.Tp_Situacao_Equipe In ('AA', 'AT')
   And v.Tp_Pagcob In ('CP', 'PN')
   And v.Cd_Repasse_Prestador Is Null;
