--Carregar as faturas (Par�metros da folha) --> prc_pag_prestador_param

--Processar as faturas(processar a folha) --> prc_repasse_prestador_v2


Select * From dbaps.itpagamento_prestador i  ---respons�vel por incluir os valores 
Where i.cd_pagamento_prestador = 695
and i.ds_tipo_folha = 'PRODUCAO_MEDICA'
and i.cd_fatura in(33487, 33420);

Select * From dbaps.repasse_prestador rp
Where rp.cd_pagamento_prestador = 695
And rp.
And rp.cd_fatura = 33487;



select count(*) from itpagamento_prestador l
where l.cd_fatura = 33487;


Select rowid, f.* From dbaps.fatura f
Where f.cd_fatura = 33420
