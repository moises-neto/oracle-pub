CREATE OR REPLACE PROCEDURE prc_repasse_prestador_v2(PCD_PAGAMENTO_PRESTADOR NUMBER) IS
  /**************************************************************
    <objeto>
     <nome>PRC_REPASSE_PRESTADOR_V2</nome>
     <usuario>Maikon Oliveira</usuario>
     <dataAlteracao>15/06/2020 08:21</alteracao>
     <ultimaAlteracao>
      Ajuste no update do repasse prestador.(Maikon Oliveira)
     </ultimaAlteracao>
     <descricao>PROCEDURE REALIZA PAGAMENTOS DA FOLHA DO COOPERADO</descricao>
    <parametro>PCD_PAGAMENTO_PRESTADOR</parametro>
    <versao>1.28</versao>
    <soul>PLANO-01-146</soul>
    </objeto>
  ***************************************************************/

  --****- NOVA ROTINA DE REPASSE PRESTADOR - PRINCIPAL - 03/11/2017 ****--

  -- Configura�oes da operadora
  CURSOR cME_MVS IS
    SELECT CD_ITEM_RES_HMEDICO,
           CD_SETOR_HMEDICO,
           CD_SETOR_IRPF,
           CD_ITEM_RES_IRPF,
           CD_SETOR_IRPJ,
           CD_ITEM_RES_IRPJ,
           CD_SETOR_ISS,
           CD_ITEM_RES_ISS,
           CD_LCTO_MENSALIDADE_PREST_COOP, --Liquido insuficiente
           CD_DESPESA_CAPTATION            --Item de despesas captation
      FROM DBAMV.MULTI_EMPRESAS_MV_SAUDE
     WHERE CD_MULTI_EMPRESA = DBAMV.PKG_MV2000.LE_EMPRESA;

  -- Configuracao de tributos
  CURSOR cConfigFinanc IS
    SELECT CD_TIP_DOC_PAG_MVS,
           CD_TIP_DOC_REC_MVS,
           NR_DIAS_AVENCER_PAG_MVS,
           CD_DETALHAMENTO_IRPF_MVS,
           CD_DETALHAMENTO_IRPJ_MVS,
           CD_DETALHAMENTO_ISS_MVS,
           SN_INT_MVS
      FROM DBAMV.CONFIG_FINANC
     WHERE CD_MULTI_EMPRESA = PKG_MV2000.LE_EMPRESA;

  -- Parametros de geracao da folha de pagamento
  CURSOR cItemPagPrestador(PCD_PRESTADOR   IN NUMBER ,
                           PNR_NOTA_FISCAL IN VARCHAR2) IS
    SELECT PP.CD_PAGAMENTO_PRESTADOR,
           PP.DT_INCLUSAO,
           PP.DT_VENCIMENTO,
           PP.DT_COMPETENCIA DT_COMPETENCIA_FOLHA,
           PP.DT_ULTIMO_PROCESSAMENTO,
           PP.DS_MENSAGEM_INTERNA,
           PP.CD_TIP_PRESTADOR,
           IPP.CD_FATURA,
           IPP.CD_PRESTADOR,
           P.SN_CONTA_PAGAR,
           P.CD_FORNECEDOR,
           P.TP_PRESTADOR,
           P.NR_DIAS_VENCIMENTO,
           P.NR_DIA_PAGAMENTO,
           P.NM_PRESTADOR,
           F.NR_MES_PAGTO,
           F.NR_ANO_PAGTO,
           F.DT_VENCIMENTO DT_VENCIMENTO_ORIGINAL,
           F.NR_MES,
           F.NR_ANO,
           P.SN_IMPOSTO_VALOR_BRUTO,
           Decode(P.SN_RPA,'S',(DBAPS.FNC_NUMERO_RPA(NVL(DBAMV.PKG_MV2000.LE_EMPRESA,1),IPP.CD_FATURA)),'N',IPP.NR_NOTA_FISCAL) NR_NOTA_FISCAL,
           PP.TP_FATURA
      FROM DBAPS.PAGAMENTO_PRESTADOR   PP,
           DBAPS.ITPAGAMENTO_PRESTADOR IPP,
           DBAPS.PRESTADOR             P,
           DBAPS.FATURA                F
     WHERE PP.CD_PAGAMENTO_PRESTADOR = IPP.CD_PAGAMENTO_PRESTADOR
       AND IPP.CD_PRESTADOR = P.CD_PRESTADOR
       AND IPP.CD_FATURA = F.CD_FATURA(+)
       AND IPP.TP_STATUS NOT IN ('I', 'A') --@TODO DESCOMENTAR QUANDO DEIXAR EM PRODUCAO
       AND PP.CD_PAGAMENTO_PRESTADOR = PCD_PAGAMENTO_PRESTADOR
       AND IPP.CD_PRESTADOR = PCD_PRESTADOR
       AND Nvl(IPP.NR_NOTA_FISCAL,'-1') = Nvl(PNR_NOTA_FISCAL,'-1');

  --Pegar contas medicas e lan�amentos avulsos de contas medicas da credito debito linear
  CURSOR cProducao(PCD_FATURA NUMBER, PCD_PRESTADOR NUMBER,PTP_FATURA IN VARCHAR2) IS
    SELECT CD_LOTE,
           SUM(VL_TOTAL_PAGO) VL_TOTAL_PAGO,
           SUM(VL_TOTAL_COBRADO) VL_TOTAL_COBRADO
      FROM (SELECT VCM.CD_LOTE,
              Decode(TP_FATURA,'C',VL_TOTAL_ADICIONAL_PAGO,VL_TOTAL_PAGO) VL_TOTAL_PAGO,
              Decode(TP_FATURA,'C',VL_TOTAL_ADICIONAL_COBRADO,VL_TOTAL_COBRADO)VL_TOTAL_COBRADO
              FROM DBAPS.V_CTAS_MEDICAS VCM, DBAPS.PRESTADOR PR
             WHERE VCM.CD_FATURA = PCD_FATURA
               AND VCM.CD_PRESTADOR_PAGAMENTO = PR.CD_PRESTADOR
               AND PR.CD_PRESTADOR = PCD_PRESTADOR
               AND VCM.TP_FATURA = PTP_FATURA --Tipo da fatura: P-Pagamento / C-Cobran�a
               AND VCM.TP_ORIGEM = '2'
             --AND VCM.TP_SITUACAO_CONTA IN ('AA', 'AT')
             --AND VCM.TP_SITUACAO_ITCONTA IN ('AA', 'AT')
             --AND VCM.TP_SITUACAO_EQUIPE IN ('AA', 'AT')
               AND VCM.TP_PAGCOB IN ('CP', 'PN') --07/12/2017
            UNION ALL
            SELECT VCDL.CD_LOTE,
                   VL_LANCAMENTO VL_TOTAL_PAGO,
                   VL_LANCAMENTO VL_TOTAL_COBRADO
              FROM DBAPS.V_CREDITO_DEBITO_LINEAR VCDL
             WHERE VCDL.CD_FATURA = PCD_FATURA
               AND VCDL.CD_PRESTADOR = PCD_PRESTADOR
               AND VCDL.CD_ITLANCAMENTO_HORA IS NULL
               AND VCDL.CD_PRESTADOR_AC_DC IS NULL
               AND VCDL.CD_RECURSO_GLOSA IS NULL
               AND VCDL.CD_PRESTADOR_PENSAO IS NULL)
     GROUP BY CD_LOTE;

  -- Total de impostos por repasse
  CURSOR cImposto(P_CD_REPASSE_PRESTADOR IN NUMBER) IS
    SELECT SUM(vl_imposto) vl_imposto
      FROM DBAPS.REPASSE_PRESTADOR_IMPOSTO rpi
     WHERE cd_repasse_prestador = P_CD_REPASSE_PRESTADOR;

  -- Pagamentos invalidos
  CURSOR cPagamentoInvalido IS
    SELECT 1
      FROM DBAPS.ITPAGAMENTO_PRESTADOR
     WHERE CD_PAGAMENTO_PRESTADOR = PCD_PAGAMENTO_PRESTADOR
       AND TP_STATUS = 'I'
       AND ROWNUM = 1;

  -- Dados do lote
  CURSOR cLoteDados(PCD_LOTE IN NUMBER) IS
    SELECT TP_GUIA
      FROM DBAPS.LOTE L, DBAPS.TIPO_ATENDIMENTO TA
     WHERE L.CD_TIPO_ATENDIMENTO = TA.CD_TIPO_ATENDIMENTO
       AND L.CD_LOTE = PCD_LOTE;

  --Busca titulos somente titulos oriundos de um REPASSE_PRESTADOR
  
  --Wesley solicitou para n�o fazer o liquido
  --Naum descontar o liquido Unimed Sorocaba
  CURSOR cSaldoInsufAberto(PCD_PRESTADOR IN NUMBER) IS
    SELECT RP.CD_PAGAMENTO_PRESTADOR,
           RP.CD_PRESTADOR,
           MC.TP_QUITACAO,
           (MC.VL_MENSALIDADE - Nvl(MC.VL_PAGO, 0)) VALOR_DIVIDA,
           MC.CD_MENS_CONTRATO,
           MC.NR_MES || '/' || MC.NR_ANO COMPETENCIA,
           MC.CD_PROCESS_CB
      FROM DBAPS.MENS_CONTRATO MC, DBAPS.REPASSE_PRESTADOR RP
     WHERE MC.CD_REPASSE_PRESTADOR = RP.CD_REPASSE_PRESTADOR
       AND MC.CD_REPASSE_PRESTADOR IS NOT NULL
       AND MC.DT_CANCELAMENTO IS NULL
       AND MC.CD_MULTI_EMPRESA = DBAMV.PKG_MV2000.LE_EMPRESA
       AND RP.CD_PRESTADOR = PCD_PRESTADOR
       AND TP_QUITACAO <> 'Q'
       and 1 = 2;
       --FIm
       ---Naum descontar o liquido Unimed Sorocaba

  --Existe conta a pagar para o repasse prestador
  CURSOR cExisteContaPagar IS
    SELECT 1
      FROM DBAPS.REPASSE_PRESTADOR
     WHERE CD_PAGAMENTO_PRESTADOR = PCD_PAGAMENTO_PRESTADOR
       AND CD_CON_PAG IS NOT NULL;
  --
  CURSOR cDadosNotaFiscal(PCD_NOTA_FISCAL IN VARCHAR2) IS
    SELECT NFP.CD_TIP_DOC, NFP.NR_SERIE, NFP.DT_EMISSAO, NFP.DT_VENCIMENTO
      FROM DBAPS.NOTA_FISCAL_PROTOCOLO NFP
     WHERE NFP.NR_NOTA_FISCAL = PCD_NOTA_FISCAL;


  -- busca o formato de agrupamento da folha de pagamento
  CURSOR cTpAgrupamentoFolha IS
    SELECT TP_AGRUPAMENTO_FOLHA
      FROM DBAMV.MULTI_EMPRESAS_MV_SAUDE
     WHERE CD_MULTI_EMPRESA = DBAMV.PKG_MV2000.LE_EMPRESA;
  --
  -- Chave que indica se vai ter rateio para os coperados
  CURSOR cMvsConfiguracao(P_CHAVE IN VARCHAR2, PCD_MULTI_EMPRESA IN NUMBER) IS
    SELECT VALOR
      FROM DBAPS.MVS_CONFIGURACAO
     WHERE CHAVE = P_CHAVE
       AND CD_MULTI_EMPRESA =
           Nvl(PCD_MULTI_EMPRESA, DBAMV.PKG_MV2000.LE_EMPRESA);

   --Dados da  Fatura A500
   CURSOR cDadosA500Parcial(PCD_FATURA IN NUMBER) IS
    SELECT NR_DOC_FISCAL_1_PTU,
           DT_VENCIMENTO,
           DT_EMISSAO_DOC_1_PTU,
           TP_FATURA
      FROM DBAPS.FATURA
    WHERE CD_FATURA =PCD_FATURA;

  --Dados do Captation
  CURSOR cDadosCaptationPrestador(PCD_PRESTADOR IN NUMBER,
                                  PDT_REFERENCIA IN DATE)IS
  SELECT PC.VL_CAPTATION
    FROM DBAPS.PRESTADOR_CAPTATION PC
      WHERE PC.CD_PRESTADOR = PCD_PRESTADOR
      AND Trunc(PC.DT_VIGENCIA) =
      (SELECT TRUNC(MAX(PC2.DT_VIGENCIA)) DT_VIGENCIA
                                         FROM DBAPS.PRESTADOR_CAPTATION PC2
                                        WHERE PC2.CD_PRESTADOR = PC.CD_PRESTADOR
                                          AND TRUNC(PC2.DT_VIGENCIA) <= TRUNC(PDT_REFERENCIA));

   -- Busca item de despesa do saldo insuficiente.
  CURSOR cItemDespesaSaldoInsuficiente (P_CD_LCTO_MENSALIDADE IN NUMBER) IS
    SELECT CD_ITEM_DESPESA
      FROM DBAPS.LCTO_MENSALIDADE
     WHERE CD_LCTO_MENSALIDADE = P_CD_LCTO_MENSALIDADE;

    --Verifica a integra��o com o contas a receber
  CURSOR cPS IS
    SELECT NVL(SN_INTEGRA_CON_REC, 'N') SN_INTEGRA_CON_REC
      FROM DBAPS.PLANO_DE_SAUDE
     WHERE ID = 1;


  TYPE TPRODMED IS RECORD(
    CD_PRESTADOR       NUMBER,
    VL_PRODUCAO_MEDICA NUMBER,
    VL_HORA_TRABALHADA NUMBER,
    VL_CAPITAL_SOCIAL  NUMBER,
    VL_ACRESCIMO       NUMBER,
    VL_DESCONTO        NUMBER,
    VL_DESC_CONTRATO   NUMBER);
  TYPE APRODMEDICA IS TABLE OF TPRODMED INDEX BY VARCHAR2(64);

  vProdMedPrestador             APRODMEDICA;
  rCfgFin                       cConfigFinanc%ROWTYPE;
  rMEMVS                        cME_MVS%ROWTYPE;
  rImposto                      cImposto%ROWTYPE;
  rLoteDados                    cLoteDados%ROWTYPE;
  nValorProducaoMedica          NUMBER;
  nValorTotalCobrado            NUMBER;
  nValorHoraTrabalhada          NUMBER;
  nCdRepassePrestador           NUMBER;
  nCdLogRepassePrestador        NUMBER;
  nCdConPag                     NUMBER;
  dDtVencimento                 DATE;
  cDtVencimento                 VARCHAR2(2000);
  cDsMensagemErro               VARCHAR2(4000);
  nCdSetorIR                    NUMBER;
  nCdDetalhamentoIR             NUMBER;
  nCdItemResIR                  NUMBER;
  nCdReduzidoDespesa            NUMBER;
  vContas                       DBAPS.PACK_MVS_REPASSE_PRESTADOR.ACONTAS;
  nI                            NUMBER;
  nVlTotHorasTrab               NUMBER;
  nVlDiferenca                  NUMBER;
  nVlIncidencia                 NUMBER;
  nVlHoras                      NUMBER;
  nVlLancamento                 NUMBER;
  vTpOperacao                   VARCHAR2(1); --C-Credito / D-Debito
  CSQLERRM                      VARCHAR2(4000);
  nVlDescContrato               NUMBER;
  nValorProdMedValida           NUMBER;
  nValorAcrescimo               NUMBER;
  nValorRecursoGlosa            NUMBER;
  nValorDesconto                NUMBER;
  nRetVlAcrescimo               NUMBER;
  nRetVlDesconto                NUMBER;
  nRetVlRecursoGlosa            NUMBER;
  nRetVlCapitalSocial           NUMBER;
  nRetVlDescontoContrato        NUMBER;
  nRetVlPensaoAliment           NUMBER;
  nRetVlImposto                 NUMBER;
  nValorHorasTrab               NUMBER;
  nValorCapitalSocial           NUMBER;
  nVlImposto                    NUMBER;
  nVLBasePensaoAliment          NUMBER;
  nVLBasePensaoAlimentTipo2     NUMBER;
  nVlLiquidoSemImposto          NUMBER;
  nVlLiquidoFinal               NUMBER;
  nVlSaldoInsuficiente          NUMBER;
  nCdMensContratoRecRet         NUMBER;
  nVlTotalDivida                NUMBER;
  nCdMensContrato               NUMBER;
  nTeste                        NUMBER(1);
  nSeqLogPagPrestador           NUMBER;
  iIterator                     NUMBER;
  vDsErro                       VARCHAR2(30000);
  vDiaVencMensContrato          VARCHAR2(2);
  nCdProcessCbNF                NUMBER;
  nNrNotaFiscal                 VARCHAR2(4000);
  rDadosNotaFiscal              cDadosNotaFiscal%ROWTYPE;
  rMvsConfiguracao              cMvsConfiguracao%ROWTYPE;
  rDadosA500Parcial             cDadosA500Parcial%ROWTYPE;
  rItemDespesaSaldoInsuficiente cItemDespesaSaldoInsuficiente%ROWTYPE;
  tpAgrupamentoFolha            VARCHAR2(2);
  nCdFarturaRateio              NUMBER;
  rDadosCaptationPrestador      cDadosCaptationPrestador%ROWTYPE;
  nVlLancamentoCaptationCredito NUMBER;
  nVlLancamentoCaptationDebito  NUMBER;
  nRetVlCaptation               NUMBER;
  vSnIntegrConRec               VARCHAR2(1);
  C_CD_REDUZIDO                 dbamv.multi_empresas_mv_saude.cd_reduzido_baixa_producao%TYPE;
  C_VALOR_MINIMO_LIQUIDO_INSUF  NUMBER(10) := 0;
  C_ITEM_DESP_QUIT_LIQUID_INSUF NUMBER(10);

BEGIN


  OPEN cPS;
	 FETCH cPS INTO vSnIntegrConRec;
	 CLOSE cPS;

  OPEN cME_MVS;
  FETCH cME_MVS
    INTO rMEMVS;
  IF cME_MVS%NOTFOUND THEN
    Raise_Application_Error(-20010,
                            'N�o existe configura��o na tabela DBAMV.MULTI_EMPRESAS_MV_SAUDE.');
  END IF;
  CLOSE cME_MVS;

  OPEN cConfigFinanc;
  FETCH cConfigFinanc
    INTO rCfgFin;

  IF cConfigFinanc%NOTFOUND THEN
    Raise_Application_Error(-20003,
                            'N�o existe configura��o no financeiro para a opereradora ' ||
                            DBAMV.PKG_MV2000.LE_EMPRESA);
  END IF;
  CLOSE cConfigFinanc;
  IF rCfgFin.SN_INT_MVS = 'N' THEN
    Raise_Application_Error(-20004,
                            'O m�dulo financeiro n�o est� configurado para integrar com a operadora ' ||
                            DBAMV.PKG_MV2000.LE_EMPRESA);
  END IF;
  IF rCfgFin.CD_TIP_DOC_PAG_MVS IS NULL THEN
    Raise_Application_Error(-20005,
                            'Tipo de documento da conta a pagar n�o foi informado na configura��o do financeiro para a operadora ' ||
                            DBAMV.PKG_MV2000.LE_EMPRESA);
  END IF;
  IF rCfgFin.NR_DIAS_AVENCER_PAG_MVS IS NULL THEN
    Raise_Application_Error(-20006,
                            'N�mero de dias a vencer padr�o da conta a pagar n�o foi informado na configura��o do financeiro para a operadora ' ||
                            DBAMV.PKG_MV2000.LE_EMPRESA);
  END IF;
  IF rCfgFin.CD_DETALHAMENTO_IRPF_MVS IS NULL THEN
    Raise_Application_Error(-20007,
                            'IRPF padr�o da conta a pagar n�o foi informado na configura��o do financeiro para a operadora ' ||
                            DBAMV.PKG_MV2000.LE_EMPRESA);
  END IF;
  IF rCfgFin.CD_DETALHAMENTO_IRPJ_MVS IS NULL THEN
    Raise_Application_Error(-20008,
                            'IRPJ padr�o da conta a pagar n�o foi informado na configura��o do financeiro para a operadora ' ||
                            DBAMV.PKG_MV2000.LE_EMPRESA);
  END IF;
  IF rCfgFin.CD_DETALHAMENTO_ISS_MVS IS NULL THEN
    Raise_Application_Error(-20009,
                            'ISS padr�o da conta a pagar n�o foi informado na configura��o do financeiro para a operadora ' ||
                            DBAMV.PKG_MV2000.LE_EMPRESA);
  END IF;

  OPEN cExisteContaPagar;
  IF cExisteContaPagar%FOUND THEN
    Raise_Application_Error(-20999,
                            'ERRO: CONTA A PAGAR J� GERADA PARA ESSA FOLHA, N�O � POSS�VEL PROCESSAR COM A CONTA A PAGAR GERADA.');
  END IF;
  CLOSE cExisteContaPagar;

  OPEN cPagamentoInvalido;
  FETCH cPagamentoInvalido
    INTO nTeste;
  IF cPagamentoInvalido%FOUND THEN
    Raise_Application_Error(-20999,
                            'ERRO: EXISTEM FATURAS/PRESTADORES INV�LIDOS NESTE PROCESSO DE FOLHA (PAGAMENTO_PRESTADOR). POSS�VEIS MOTIVOS: 1) FATURA N�O FECHADA; 2) PRESTADOR SEM CONTRATO');
  END IF;
  CLOSE cPagamentoInvalido;

  IF Nvl(DBAPS.FNC_MVS_RETORNA_VALOR_CONFIG('CONTMED_PAGTO_UNIFICADO',DBAMV.PKG_MV2000.LE_EMPRESA),'N') = 'N' THEN

    Raise_Application_Error(-20999,'SISTEMA N�O CONFIGURADO PARA UTILIZAR PAGAMENTO UNIFICADO CONTAS MEDICAS - FAVOR ATIVE CHAVE CONTMED_PAGTO_UNIFICADO');
  END IF;

  IF Nvl(DBAPS.FNC_MVS_RETORNA_VALOR_CONFIG('CONTMED_FOLHA_PGTO',DBAMV.PKG_MV2000.LE_EMPRESA),'N') = 'N' THEN

    Raise_Application_Error(-20999,'SISTEMA N�O CONFIGURADO PARA UTILIZAR FOLHA DE PAGAMENTO - FAVOR ATIVE CHAVE CONTMED_FOLHA_PGTO');
  END IF;

  UPDATE DBAPS.PRESTADOR_AC_DC
     SET CD_REPASSE_PRESTADOR = NULL
   WHERE CD_REPASSE_PRESTADOR IN
         (SELECT CD_REPASSE_PRESTADOR
            FROM DBAPS.REPASSE_PRESTADOR RP
           WHERE RP.CD_PAGAMENTO_PRESTADOR = PCD_PAGAMENTO_PRESTADOR
             AND SN_FECHADO = 'N');
  COMMIT;
  DELETE FROM DBAPS.PRESTADOR_CREDITO_DEBITO RP
   WHERE CD_REPASSE_PRESTADOR IN
         (SELECT CD_REPASSE_PRESTADOR
            FROM DBAPS.REPASSE_PRESTADOR RP
           WHERE RP.CD_PAGAMENTO_PRESTADOR = PCD_PAGAMENTO_PRESTADOR
             AND SN_FECHADO = 'N');
  COMMIT;
  DELETE FROM DBAPS.REPASSE_PRESTADOR_MENSAGEM RPM
   WHERE RPM.CD_REPASSE_PRESTADOR IN
         (SELECT CD_REPASSE_PRESTADOR
            FROM DBAPS.REPASSE_PRESTADOR RP
           WHERE RP.CD_PAGAMENTO_PRESTADOR = PCD_PAGAMENTO_PRESTADOR
             AND SN_FECHADO = 'N');
  COMMIT;
  DELETE FROM DBAPS.REPASSE_PRESTADOR_IMPOSTO RPI
   WHERE CD_REPASSE_PRESTADOR IN
         (SELECT CD_REPASSE_PRESTADOR
            FROM DBAPS.REPASSE_PRESTADOR RP
           WHERE RP.CD_PAGAMENTO_PRESTADOR = PCD_PAGAMENTO_PRESTADOR
             AND SN_FECHADO = 'N');
  COMMIT;

  -- Tabela de controle para o contador em tela
  DELETE FROM DBAPS.LOG_PAGAMENTO_PRESTADOR
   WHERE CD_PAGAMENTO_PRESTADOR = PCD_PAGAMENTO_PRESTADOR;
  COMMIT;

  --Removido cd_repasse_prestador das contas medicas antes de deletar o repasse
  UPDATE DBAPS.ITCONTA_MED
     SET CD_REPASSE_PRESTADOR = NULL
   WHERE CD_REPASSE_PRESTADOR IN
         (SELECT CD_REPASSE_PRESTADOR
            FROM DBAPS.REPASSE_PRESTADOR
           WHERE CD_PAGAMENTO_PRESTADOR = PCD_PAGAMENTO_PRESTADOR
            AND SN_FECHADO = 'N');

  UPDATE DBAPS.ITREMESSA_PRESTADOR_EQUIPE
     SET CD_REPASSE_PRESTADOR = NULL
   WHERE CD_REPASSE_PRESTADOR IN
         (SELECT CD_REPASSE_PRESTADOR
            FROM DBAPS.REPASSE_PRESTADOR
           WHERE CD_PAGAMENTO_PRESTADOR = PCD_PAGAMENTO_PRESTADOR
            AND SN_FECHADO = 'N');

  COMMIT;

  --Delete dos repasses
  DELETE FROM DBAPS.REPASSE_PRESTADOR
   WHERE CD_PAGAMENTO_PRESTADOR = PCD_PAGAMENTO_PRESTADOR
     AND SN_FECHADO = 'N';
  COMMIT;

  vProdMedPrestador.DELETE();

  UPDATE DBAPS.PAGAMENTO_PRESTADOR
     SET DT_INICIO_PROCESSAMENTO = SYSDATE
   WHERE CD_PAGAMENTO_PRESTADOR = PCD_PAGAMENTO_PRESTADOR;
  COMMIT;

  -- Agrupa receitas e despesas do prestador
  -- Por favor nao retirar a ordem do select, devido ao rateio para os coperados � imprescind�vel para o funcionamento do rateio, quando utilizado pela operadora.
  FOR rPrestadores IN (SELECT *
                         FROM (SELECT DISTINCT IPP.CD_PRESTADOR,
                                               PP.DT_COMPETENCIA,
                                               PP.DT_VENCIMENTO,
                                               PP.DS_OBSERVACAO,
                                               PP.DS_MENSAGEM_EXTERNA,
                                               C.CD_CONTRATO,
                                               P.SN_IMPOSTO_VALOR_BRUTO,
                                               P.TP_PRESTADOR,
                                               P.SN_CAPTATION,
                                               P.CD_TIP_PRESTADOR,
                                               NULL NR_NOTA_FISCAL,
                                               P.TP_CREDENCIAMENTO
                                 FROM DBAPS.PAGAMENTO_PRESTADOR     PP,
                                      DBAPS.ITPAGAMENTO_PRESTADOR   IPP,
                                      DBAPS.PRESTADOR               P,
                                      DBAPS.CONTRATO                C,
                                      DBAMV.MULTI_EMPRESAS_MV_SAUDE MEMVS
                                WHERE PP.CD_PAGAMENTO_PRESTADOR =
                                      IPP.CD_PAGAMENTO_PRESTADOR
                                  AND IPP.CD_PRESTADOR = P.CD_PRESTADOR
                                  AND P.CD_PRESTADOR = C.CD_PRESTADOR(+)
                                  AND IPP.TP_STATUS = 'C'
                                  AND PP.CD_PAGAMENTO_PRESTADOR =
                                      PCD_PAGAMENTO_PRESTADOR
                                  AND MEMVS.TP_AGRUPAMENTO_FOLHA = 'PS' --Prestador
                                  AND MEMVS.CD_MULTI_EMPRESA =
                                      DBAMV.PKG_MV2000.LE_EMPRESA
                               UNION ALL
                               SELECT IPP.CD_PRESTADOR,
                                      PP.DT_COMPETENCIA,
                                      PP.DT_VENCIMENTO,
                                      PP.DS_OBSERVACAO,
                                      PP.DS_MENSAGEM_EXTERNA,
                                      C.CD_CONTRATO,
                                      P.SN_IMPOSTO_VALOR_BRUTO,
                                      P.TP_PRESTADOR,
                                      P.SN_CAPTATION,
                                      P.CD_TIP_PRESTADOR,
                                      IPP.NR_NOTA_FISCAL,
                                      P.TP_CREDENCIAMENTO
                                 FROM DBAPS.PAGAMENTO_PRESTADOR     PP,
                                      DBAPS.ITPAGAMENTO_PRESTADOR   IPP,
                                      DBAPS.PRESTADOR               P,
                                      DBAPS.CONTRATO                C,
                                      DBAMV.MULTI_EMPRESAS_MV_SAUDE MEMVS
                                WHERE PP.CD_PAGAMENTO_PRESTADOR =
                                      IPP.CD_PAGAMENTO_PRESTADOR
                                  AND IPP.CD_PRESTADOR = P.CD_PRESTADOR
                                  AND P.CD_PRESTADOR = C.CD_PRESTADOR(+)
                                  AND IPP.TP_STATUS = 'C'
                                  AND PP.CD_PAGAMENTO_PRESTADOR =
                                      PCD_PAGAMENTO_PRESTADOR
                                  AND MEMVS.TP_AGRUPAMENTO_FOLHA = 'NF' --Nota fiscal
                                  AND MEMVS.CD_MULTI_EMPRESA =
                                      DBAMV.PKG_MV2000.LE_EMPRESA
                                 GROUP BY  IPP.CD_PRESTADOR,
                                               PP.DT_COMPETENCIA,
                                               PP.DT_VENCIMENTO,
                                               PP.DS_OBSERVACAO,
                                               PP.DS_MENSAGEM_EXTERNA,
                                               C.CD_CONTRATO,
                                              P.SN_IMPOSTO_VALOR_BRUTO,
                                               P.TP_PRESTADOR,
                                               P.SN_CAPTATION,
                                               P.CD_TIP_PRESTADOR,
                                               IPP.NR_NOTA_FISCAL,
                                               P.TP_CREDENCIAMENTO
                                              )
                        ORDER BY TP_PRESTADOR DESC) LOOP

    BEGIN
      --
      SELECT DBAPS.SEQ_LOG_PAGAMENTO_PRESTADOR.NEXTVAL
        INTO nSeqLogPagPrestador
        FROM dual;
      --
      INSERT INTO DBAPS.LOG_PAGAMENTO_PRESTADOR
        (CD_LOG_PAGAMENTO_PRESTADOR,
         CD_PAGAMENTO_PRESTADOR,
         CD_PRESTADOR,
         DS_ERRO)
      VALUES
        (nSeqLogPagPrestador,
         PCD_PAGAMENTO_PRESTADOR,
         rPrestadores.CD_PRESTADOR,
         NULL);
      COMMIT;

      -- Procurando todas as faturas associadas ao prestador nessa folha de pagamento

      nValorProducaoMedica      := 0;
      nValorTotalCobrado        := 0;
      nValorHoraTrabalhada      := 0;
      nValorProdMedValida       := 0;
      nVlDescContrato           := 0;
      nValorAcrescimo           := 0;
      nValorDesconto            := 0;
      nValorRecursoGlosa        := 0;
      nValorHorasTrab           := 0;
      nValorCapitalSocial       := 0;
      nVlImposto                := 0;
      nVLBasePensaoAliment      := 0;
      nVLBasePensaoAlimentTipo2 := 0;
      nVlLiquidoFinal           := 0;
      nVlLiquidoSemImposto      := 0;
      nVlSaldoInsuficiente      := 0;
      nRetVlAcrescimo           := 0;
      nRetVlDesconto            := 0;
      nRetVlCapitalSocial       := 0;
      nRetVlImposto             := 0;
      nNrNotaFiscal             := NULL;

      BEGIN
        SELECT DBAPS.SEQ_REPASSE_PRESTADOR.NEXTVAL
          INTO nCdRepassePrestador
          FROM DUAL;
      EXCEPTION
        WHEN OTHERS THEN
          Raise_Application_Error(-20001,
                                  'Erro ao gerar a chave prim�ria da tabela DBAPS.REPASSE_PRESTADOR');
      END;
      -- Criando repasse para o prestador
      INSERT INTO DBAPS.REPASSE_PRESTADOR
        (CD_REPASSE_PRESTADOR,
         CD_FATURA,
         CD_PRESTADOR,
         CD_CON_PAG,
         DS_ERRO,
         DT_LANCAMENTO,
         CD_EXP_CONTABILIDADE,
         DT_VENCIMENTO_ORIGINAL,
         NR_NOTA_FISCAL,
         CD_USUARIO_REPASSE,
         DT_USUARIO_REPASSE,
         DS_OBSERVACAO,
         SN_FECHADO,
         DS_MENSAGEM_EXTERNA,
         CD_PAGAMENTO_PRESTADOR,
         VL_PRODUCAO_MEDICA,
         VL_ACRESCIMOS,
         VL_DESCONTOS,
         VL_CAPITAL_SOCIAL,
         VL_HORAS_TRABALHADAS,
         VL_LIQUIDO)
      VALUES
        (nCdRepassePrestador,
         NULL,
         rPrestadores.CD_PRESTADOR,
         NULL,
         NULL,
         SYSDATE,
         NULL,
         rPrestadores.DT_VENCIMENTO,
         NULL,
         USER,
         SYSDATE,
         rPrestadores.DS_OBSERVACAO,
         'N',
         rPrestadores.DS_MENSAGEM_EXTERNA,
         PCD_PAGAMENTO_PRESTADOR,
         0,
         0,
         0,
         0,
         0,
         0);

      -- OBtem todas os itens de parametros
      FOR rItemPagPrestador IN cItemPagPrestador(rPrestadores.cd_prestador,rPrestadores.NR_NOTA_FISCAL) LOOP

        BEGIN
          SELECT DBAPS.SEQ_LOG_REPASSE_PRESTADOR.NEXTVAL
            INTO nCdLogRepassePrestador
            FROM SYS.DUAL;
        EXCEPTION
          WHEN OTHERS THEN
            Raise_Application_Error(-20002,
                                    'Erro ao gerar a chave prim�ria da tabela DBAPS.LOG_REPASSE_PRESTADOR');
        END;
        --
        INSERT INTO DBAPS.LOG_REPASSE_PRESTADOR
          (CD_LOG_REPASSE_PRESTADOR,
           CD_REPASSE_PRESTADOR,
           CD_FATURA,
           CD_PRESTADOR,
           CD_TIP_PRESTADOR,
           CD_MULTI_EMPRESA,
           CD_TIP_DOC_PAG,
           NR_DIAS_AVENCER_PAG,
           CD_DETALHAMENTO_IRPF_MVS,
           CD_DETALHAMENTO_IRPJ_MVS,
           CD_DETALHAMENTO_ISS_MVS,
           DT_VENCIMENTO,
           DS_OBSERVACAO,
           CD_USUARIO_INCLUSAO,
           DT_INCLUSAO)
        VALUES
          (nCdLogRepassePrestador,
           nCdRepassePrestador,
           rItemPagPrestador.CD_FATURA,
           rItemPagPrestador.CD_PRESTADOR,
           rItemPagPrestador.CD_TIP_PRESTADOR,
           DBAMV.PKG_MV2000.LE_EMPRESA,
           rCfgFin.CD_TIP_DOC_PAG_MVS,
           rCfgFin.NR_DIAS_AVENCER_PAG_MVS,
           rCfgFin.CD_DETALHAMENTO_IRPF_MVS,
           rCfgFin.CD_DETALHAMENTO_IRPJ_MVS,
           rCfgFin.CD_DETALHAMENTO_ISS_MVS,
           rItemPagPrestador.DT_VENCIMENTO,
           rItemPagPrestador.DS_MENSAGEM_INTERNA,
           USER,
           SYSDATE);
        --

        nNrNotaFiscal := NULL;
        nNrNotaFiscal := rItemPagPrestador.NR_NOTA_FISCAL;

        --Quando e fatura de A500 pega os dados da fatura
        IF rItemPagPrestador.TP_FATURA ='C' THEN

          rDadosA500Parcial:= NULL;

          OPEN cDadosA500Parcial(rItemPagPrestador.CD_FATURA);
          FETCH cDadosA500Parcial
            INTO rDadosA500Parcial;
          CLOSE cDadosA500Parcial;

        END IF;--IF rItemPagPrestador.TP_FATURA ='C' THEN

        OPEN cTpAgrupamentoFolha;
        FETCH cTpAgrupamentoFolha
          INTO tpAgrupamentoFolha;
        CLOSE cTpAgrupamentoFolha;

        --Agrupamento por nota fiscal
        IF tpAgrupamentoFolha = 'NF' THEN

          rDadosNotaFiscal := NULL;
          OPEN cDadosNotaFiscal(nNrNotaFiscal);
          FETCH cDadosNotaFiscal
            INTO rDadosNotaFiscal;
          CLOSE cDadosNotaFiscal;

        END IF; --IF tpAgrupamentoFolha = 'NF' THEN

        nVlHoras := 0;
        --***********************************************************************************************************
        --                          HORAS TRABALHADAS - TABELA DBAPS.ITLANCAMENTO_HORA                              *
        --***********************************************************************************************************

        -- procura horas trabalhadas somente se na folha o prestador possuir fatura.
        IF rItemPagPrestador.CD_FATURA IS NOT NULL THEN

          DBAPS.PACK_MVS_REPASSE_PRESTADOR.P_ACRESCIMO_HORAS_TRABALHADAS(nCdRepassePrestador,
                                                                         nCdLogRepassePrestador,
                                                                         rItemPagPrestador.CD_FATURA,
                                                                         rPrestadores.CD_PRESTADOR,
                                                                         nVlHoras);
          nValorHorasTrab := nValorHorasTrab + nVlHoras;

        END IF; --Fim horas trabalhadas

        --***********************************************************************************************************
        --*                                  PRODU��O M�DICA - CONSOLIDA��O                                         *
        --***********************************************************************************************************

        --  procura produ��o m�dica somente se na folha o prestador possuir fatura.
        IF rItemPagPrestador.CD_FATURA IS NOT NULL THEN

          FOR rProd IN cProducao(rItemPagPrestador.CD_FATURA,
                                 rPrestadores.CD_PRESTADOR,
                                 rItemPagPrestador.TP_FATURA) LOOP
            --
            nValorProducaoMedica := nValorProducaoMedica +
                                    Nvl(rProd.VL_TOTAL_PAGO, 0);
            nValorTotalCobrado   := nValorTotalCobrado +
                                    Nvl(rProd.VL_TOTAL_COBRADO, 0);
            --

            --Atualiza o TP_PAGAMENTO das faturas do tipo cobran�a com o valor [P]Parcial.
            UPDATE DBAPS.FATURA
            SET TP_PAGAMENTO = 'P'
            WHERE CD_FATURA = rItemPagPrestador.CD_FATURA
            AND TP_PAGAMENTO IS NULL
            AND TP_FATURA = 'C';

            UPDATE DBAPS.PROTOCOLO_CTAMED
               SET CD_STATUS_PROTOCOLO =
                   (SELECT CD_STATUS_PROTOCOLO
                      FROM DBAPS.STATUS_PROTOCOLO
                     WHERE CD_TISS = 3
                       AND ROWNUM = 1)
             WHERE CD_PROTOCOLO_CTAMED IN
                   (SELECT CD_PROTOCOLO_CTAMED
                      FROM (SELECT CD_PROTOCOLO_CTAMED
                              FROM DBAPS.LOTE
                             WHERE CD_LOTE = rProd.CD_LOTE
                            UNION
                            SELECT CD_PROTOCOLO_CTAMED
                              FROM DBAPS.LOTE_PROTOCOLO_CTAMED
                             WHERE CD_LOTE = rProd.CD_LOTE)
                     WHERE cd_protocolo_ctamed IS NOT NULL);
            --
            rLoteDados := NULL;
            OPEN cLoteDados(rProd.cd_lote);
            FETCH cLoteDados
              INTO rLoteDados;
            CLOSE cLoteDados;

            DBAPS.PKG_SOULSAUDE.ATRIBUI_MODO_IMPORTA_XML('S');

            --Hospitalar
            IF rLoteDados.TP_GUIA IN ('H', 'I','P') THEN

              UPDATE DBAPS.ITCONTA_MED ICM
                 SET CD_REPASSE_PRESTADOR = nCdRepassePrestador
               WHERE CD_PRESTADOR_PAGAMENTO = rPrestadores.CD_PRESTADOR
                 AND ICM.CD_REPASSE_PRESTADOR IS NULL --04/05/20 - evitar UPDATE em conta m�dica que j� tem repasse marcado (para descomentar falar com Maikon/Dellanio)
                 AND ICM.TP_SITUACAO IN ('AA', 'AT', 'GT')
                 AND EXISTS
               (SELECT 1
                        FROM DBAPS.CONTA_HOSPITALAR   CH,
                             DBAPS.ITCONTA_HOSPITALAR ICH
                       WHERE CH.CD_CONTA_HOSPITALAR =
                             ICH.CD_CONTA_HOSPITALAR
                         AND ICH.CD_CONTA_HOSPITALAR =
                             ICM.CD_CONTA_HOSPITALAR
                         AND ICH.CD_LANCAMENTO = ICM.CD_LANCAMENTO
                         AND ICH.TP_PAGCOB IN ('CP', 'PN')
                         AND CD_LOTE = rProd.cd_lote);

            ELSE
              --Ambulatorial
              UPDATE DBAPS.ITREMESSA_PRESTADOR_EQUIPE IRPE
                 SET CD_REPASSE_PRESTADOR = nCdRepassePrestador
               WHERE CD_PRESTADOR_PAGAMENTO = rPrestadores.CD_PRESTADOR
                 AND IRPE.CD_REPASSE_PRESTADOR IS NULL --04/05/20 - evitar UPDATE em conta m�dica que j� tem repasse marcado (para descomentar falar com Maikon/Dellanio)
                 AND IRPE.TP_SITUACAO IN ('AA', 'AT', 'GT')
                 AND EXISTS
               (SELECT 1
                        FROM DBAPS.REMESSA_PRESTADOR   RP,
                             DBAPS.ITREMESSA_PRESTADOR IRP
                       WHERE RP.CD_REMESSA = IRP.CD_REMESSA
                         AND IRP.CD_REMESSA = IRPE.CD_REMESSA
                         AND IRP.CD_LANCAMENTO = IRPE.CD_LANCAMENTO
                         AND IRP.TP_PAGCOB IN ('CP', 'PN')
                         AND CD_LOTE = rProd.cd_lote);

            END IF; --IF rLoteDados.TP_GUIA IN ('H', 'I','P') THEN


            /* FDLA- 30/07/2018 - Atribuir FK para ajustes de producao medica
            Hoje tem o problema do cancelamento da folha apagar todos os credito_debito que possuam FK
            o que deletaria inclusive o que foi digitado manualmente. precisa achar mecanismo pra diferenciar o que � manual
            do automatico*/
            UPDATE DBAPS.PRESTADOR_CREDITO_DEBITO
               SET CD_REPASSE_PRESTADOR = nCdRepassePrestador
             WHERE CD_FATURA = rItemPagPrestador.CD_FATURA
               AND CD_PRESTADOR = rPrestadores.CD_PRESTADOR
               AND CD_ITLANCAMENTO_HORA IS NULL
               AND CD_PRESTADOR_AC_DC IS NULL
               AND CD_RECURSO_GLOSA IS NULL
               AND CD_REPASSE_PRESTADOR IS NULL
               AND CD_PRESTADOR_PENSAO IS NULL
               AND DT_DIGITACAO IS NOT NULL; --Coluna principal (NAO DELETAR EM HIPOTESE NENHUMA)

            DBAPS.PKG_SOULSAUDE.ATRIBUI_MODO_IMPORTA_XML(NULL);

          END LOOP;-- Fim produ��o m�dica
        END IF; --IF rItemPagPrestador.CD_FATURA IS NOT NULL THEN

        nRetVlAcrescimo        := 0;
        nRetVlDesconto         := 0;
        nRetVlCapitalSocial    := 0;
        nRetVlDescontoContrato := 0;
        nRetVlPensaoAliment    := 0;
        nVlDescContrato        := 0;
        nVlLancamento          := 0;
        vTpOperacao            := '';

        --***************************************************************************************************
        --*                                CAPTATION DO PRESTADOR                                           *
        --***************************************************************************************************

        IF rPrestadores.SN_CAPTATION = 'S' THEN

         -- Se configura��o de item de despesa do captation for nulo n�o deixa processar
          IF rMEMVS.CD_DESPESA_CAPTATION IS NULL THEN
            Raise_Application_Error(-20999,'N�O EXISTE ITEM DE DESPESAS CONFIGURADO PARA CAPTATION NA TELA DE CONFIGURA��O: PLANO DE SA�DE / CONFIGURA��ES / CONFIGURA��ES (M_CONFIGURA_SGPS)');
          END IF;

          rDadosCaptationPrestador:= NULL;
          nVlLancamentoCaptationDebito  := 0;
		      nVlLancamentoCaptationCredito := 0;
          --
          OPEN cDadosCaptationPrestador(rPrestadores.CD_PRESTADOR,Nvl(rItemPagPrestador.DT_COMPETENCIA_FOLHA,SYSDATE));
          FETCH cDadosCaptationPrestador
            INTO rDadosCaptationPrestador;

         -- se o valor da produ��o for maior que o captation aplica um desconto
         IF nValorProducaoMedica > rDadosCaptationPrestador.VL_CAPTATION THEN

          nVlLancamentoCaptationDebito :=  nValorProducaoMedica -rDadosCaptationPrestador.VL_CAPTATION;
          nValorProducaoMedica:= nValorProducaoMedica+(rDadosCaptationPrestador.VL_CAPTATION -nValorProducaoMedica);

          BEGIN
          INSERT INTO DBAPS.PRESTADOR_CREDITO_DEBITO
                (CD_PRES_CR_DB,
                 CD_FATURA,
                 CD_PRESTADOR,
                 TP_LANCAMENTO,
                 VL_LANCAMENTO,
                 DS_USER_INCLUSAO,
                 DT_INCLUSAO,
                 CD_ITEM_DESPESA,
                 DS_OBSERVACAO,
                 CD_REPASSE_PRESTADOR
                )
              VALUES
                (DBAPS.SEQ_PRESTADOR_CREDITO_DEBITO.NEXTVAL,
                 Nvl(rItemPagPrestador.CD_FATURA,-1),
                 rPrestadores.Cd_Prestador,
                 'D',
                 nvl(nVlLancamentoCaptationDebito, 0),
                 USER,
                 SYSDATE,
                 rMEMVS.CD_DESPESA_CAPTATION, -- CD_ITEM_DESPESA
                 'LAN�AMENTO REFERENTE DIFEREN�A DO VALOR DO CAPTATION',
                 nCdRepassePrestador
                 );

                 COMMIT;

                  EXCEPTION
               WHEN OTHERS THEN
                 vDsErro := SQLERRM;
                 INSERT INTO DBAPS.REPASSE_PRESTADOR_ERRO
                 VALUES
                   (DBAPS.SEQ_REPASSE_PRESTADOR_ERRO.NEXTVAL,
                    nCdRepassePrestador,
                    'ERRO NO LAN�AMENTO DO CAPTATION: ' ||vDsErro);
                 COMMIT;
                 Raise_Application_Error(-20999, 'Erro: ' || vDsErro);
             END;

         -- caso seja menor aplica uma acrescimo para o prestador
         ELSE

         nVlLancamentoCaptationCredito := rDadosCaptationPrestador.VL_CAPTATION -nValorProducaoMedica;

         nValorProducaoMedica:= nValorProducaoMedica+(rDadosCaptationPrestador.VL_CAPTATION -nValorProducaoMedica);

         BEGIN

         INSERT INTO DBAPS.PRESTADOR_CREDITO_DEBITO
                (CD_PRES_CR_DB,
                 CD_FATURA,
                 CD_PRESTADOR,
                 TP_LANCAMENTO,
                 VL_LANCAMENTO,
                 DS_USER_INCLUSAO,
                 DT_INCLUSAO,
                 CD_ITEM_DESPESA,
                 DS_OBSERVACAO,
                 CD_REPASSE_PRESTADOR
                 )
              VALUES
                (DBAPS.SEQ_PRESTADOR_CREDITO_DEBITO.NEXTVAL,-- CD_PRES_CR_DB
                 Nvl(rItemPagPrestador.CD_FATURA,-1),-- CD_FATURA
                 rPrestadores.Cd_Prestador,-- CD_PRESTADOR
                 'C',-- TP_LANCAMENTO
                 nvl(nVlLancamentoCaptationCredito, 0),-- VL_LANCAMENTO
                 USER,-- DS_USER_INCLUSAO
                 SYSDATE,-- DT_INCLUSAO
                 rMEMVS.CD_DESPESA_CAPTATION, -- CD_ITEM_DESPESA
                 'LAN�AMENTO REFERENTE DIFEREN�A DO VALOR DO CAPTATION',-- DS_OBSERVACAO
                 nCdRepassePrestador -- CD_REPASSE_PRESTADOR
               );
                 COMMIT;

            EXCEPTION
               WHEN OTHERS THEN
                 vDsErro := SQLERRM;
                 INSERT INTO DBAPS.REPASSE_PRESTADOR_ERRO
                 VALUES
                   (DBAPS.SEQ_REPASSE_PRESTADOR_ERRO.NEXTVAL,
                    nCdRepassePrestador,
                    'ERRO NO LAN�AMENTO DO CAPTATION: ' ||vDsErro);
                 COMMIT;
                 Raise_Application_Error(-20999, 'Erro: ' || vDsErro);
             END;

         END IF;

          CLOSE cDadosCaptationPrestador;
        END IF;


        --***************************************************************************************************
        --*           ACR�SCIMO(S)/DESCONTO(S) PARA O PRESTADOR - TABELA DBAPS.PRESTADOR_AC_DC              *
        --***************************************************************************************************

        -- Se nao tiver fatura - procure acresc/descontos de forma avulsa pela competencia
        DBAPS.PACK_MVS_REPASSE_PRESTADOR.P_ACRESCIMOS_DESCONTOS(nCdRepassePrestador,
                                                                nCdLogRepassePrestador,
                                                                Nvl(rItemPagPrestador.CD_FATURA,
                                                                    -1),
                                                                rPrestadores.CD_PRESTADOR,
                                                                rItemPagPrestador.DT_COMPETENCIA_FOLHA,
                                                                nRetVlAcrescimo,
                                                                nRetVlDesconto);
        nValorAcrescimo := nValorAcrescimo + nRetVlAcrescimo;
        nValorDesconto  := nValorDesconto + nRetVlDesconto;

        --***************************************************************************************************
        --*                                     RECURSO GLOSA                                               *
        --***************************************************************************************************
        DBAPS.PACK_MVS_REPASSE_PRESTADOR.P_RECURSO_GLOSA(nCdRepassePrestador,
                                                         nCdLogRepassePrestador,
                                                         Nvl(rItemPagPrestador.CD_FATURA,
                                                             -1),
                                                         rPrestadores.CD_PRESTADOR,
                                                         nRetVlRecursoGlosa);
        nValorRecursoGlosa := nValorRecursoGlosa + nRetVlRecursoGlosa;


        --Entender o que � isso!
        nValorProdMedValida := nValorProducaoMedica;

        --***************************************************************************************************
        --*                                     CAPITAL SOCIAL                                              *
        --***************************************************************************************************

        -- OP: 43587 - REALIZA O DESCONTO DE CAPITAL SOCIAL
--        if  rPrestadores.CD_PRESTADOR in (174314 ,132487 ,150526,111625) then 
        DBAPS.PACK_MVS_REPASSE_PRESTADOR.P_DESCONTO_CAPITAL_SOCIAL(nCdRepassePrestador,
                                                                   nCdLogRepassePrestador,
                                                                   rPrestadores.DT_COMPETENCIA,
                                                                   rPrestadores.CD_PRESTADOR,
                                                                   SYSDATE,
                                                                   rPrestadores.DT_VENCIMENTO,
                                                                   nValorProdMedValida,
                                                                   nRetVlCapitalSocial);

        nValorCapitalSocial := nValorCapitalSocial + nRetVlCapitalSocial;

        IF nValorCapitalSocial > 0 THEN
          cDsMensagemErro := 'CAPITAL SOCIAL DESCONTADO PARA O PRESTADOR: ' ||
                             TO_CHAR(rPrestadores.CD_PRESTADOR) ||
                             ' NO VALOR : ' || nValorCapitalSocial;
          DBAPS.PACK_MVS_REPASSE_PRESTADOR.P_GRAVA_LOG_REP_PRES_MENS_ERRO(nCdLogRepassePrestador,
                                                                          cDsMensagemErro,
                                                                          'A');
        END IF;
--end if;
        --***************************************************************************************************
        --*               DESCONTO DE CONTRATO NA PRODU��O M�DICA  --@TODO: VALIDAR PROCESSO                *
        --***************************************************************************************************
        DBAPS.PACK_MVS_REPASSE_PRESTADOR.P_DESCONTO_CONTRATO(nCdRepassePrestador,
                                                             nCdLogRepassePrestador,
                                                             rPrestadores.DT_COMPETENCIA,
                                                             rPrestadores.CD_PRESTADOR,
                                                             rPrestadores.DT_VENCIMENTO,
                                                             nValorProdMedValida,
                                                             nRetVlDescontoContrato);

        nVlDescContrato := nVlDescContrato + nRetVlDescontoContrato;
        nValorDesconto  := nValorDesconto + nRetVlDescontoContrato; --juntar com os demais descontos

        --Atribuindo fatura/prestador como processada
        UPDATE DBAPS.ITPAGAMENTO_PRESTADOR
           SET TP_STATUS = 'P'
         WHERE CD_PAGAMENTO_PRESTADOR = PCD_PAGAMENTO_PRESTADOR
           AND Nvl(CD_FATURA, -1) = Nvl(rItemPagPrestador.CD_FATURA, -1)
           AND CD_PRESTADOR = rItemPagPrestador.CD_PRESTADOR;

        --
        nCdFarturaRateio := null;
        nCdFarturaRateio := rItemPagPrestador.CD_FATURA;
        --
      END LOOP;
      -- ENDLOOP rItemPagPrestador - FIM FATURAS ASSOCIADAS AO PRESTADOR

      --      REMOVIDO FAZ REPASSE SER REALIZADO EM CIMA DO VALOR BRUTO ISSO S� DEVE UTILIZAR PARA CALCULAR IMPOSTO EM CIMA DO BRUTO!
      --      IF Nvl(rPrestadores.SN_IMPOSTO_VALOR_BRUTO, 'N') = 'S' THEN
      --        nValorProducaoMedica := nValorTotalCobrado;
      --      END IF;

      -- TICKET PLANO-7869
      -- Permite realizar o rateio de 90% para o prestador ex: Clinica, Hospital, e 10% para os coperados ex: m�dicos associados
      --Verifica se existe a chave para verificar se existe RAteio para a folha de pagamento do prestador
      IF rPrestadores.Tp_Prestador = 'J' THEN
        OPEN cMvsConfiguracao('CONTMED_PRESTADOR_FOLHA_RATEIO',
                              dbamv.pkg_mv2000.Le_Empresa);
        FETCH cMvsConfiguracao
          INTO rMvsConfiguracao;
        --
        IF cMvsConfiguracao%FOUND THEN
          IF rMvsConfiguracao.Valor = 'S' THEN
            -- Verifica se a chave ta ligada para o Rateio para os coperados.
            nValorProducaoMedica := DBAPS.FNC_PRESTADOR_FOLHA_RATEIO(rPrestadores.Cd_Prestador,
                                                                     nValorProducaoMedica,
                                                                     nCdRepassePrestador,
                                                                     nCdFarturaRateio); -- Fatura
          END IF; --IF rMvsConfiguracao.Valor = 'S' THEN
          --
        END IF; --IF cMvsConfiguracao%FOUND THEN
        CLOSE cMvsConfiguracao;
      END IF;--IF rPrestadores.Tp_Prestador = 'J' THEN

      -- Atualizando valores do repasse
      UPDATE DBAPS.REPASSE_PRESTADOR
         SET VL_PRODUCAO_MEDICA   = Nvl(Round(nValorProducaoMedica, 2), 0),
             VL_TOTAL_COBRADO_CM  = Nvl(nValorTotalCobrado, 0),
             VL_ACRESCIMOS        = Nvl(nValorAcrescimo +Nvl(nVlLancamentoCaptationCredito,0), 0),
             VL_DESCONTOS         = Nvl(nValorDesconto-Nvl(nVlLancamentoCaptationDebito,0), 0),
             VL_CAPITAL_SOCIAL    = Nvl(nValorCapitalSocial, 0),
             VL_RECURSO_GLOSA     = Nvl(nValorRecursoGlosa, 0),
             VL_HORAS_TRABALHADAS = Nvl(nValorHorasTrab, 0),
             NR_NOTA_FISCAL       = Decode(rDadosA500Parcial.TP_FATURA,NULL,nNrNotaFiscal,rDadosA500Parcial.NR_DOC_FISCAL_1_PTU),
             CD_TIP_DOC           = rDadosNotaFiscal.CD_TIP_DOC,
             NR_SERIE             = rDadosNotaFiscal.NR_SERIE,
             DT_EMISSAO_CON_PAG   = Decode(rDadosA500Parcial.TP_FATURA,NULL,rDadosNotaFiscal.DT_EMISSAO,rDadosA500Parcial.DT_EMISSAO_DOC_1_PTU),
             DT_VENCIMENTO        = Decode(rDadosA500Parcial.TP_FATURA,NULL,rDadosNotaFiscal.DT_VENCIMENTO,rDadosA500Parcial.DT_VENCIMENTO)
       WHERE CD_REPASSE_PRESTADOR = nCdRepassePrestador;
      --

      nVlLiquidoSemImposto := (nValorProducaoMedica + nValorHorasTrab +
                              nValorAcrescimo + nValorRecursoGlosa) -
                              (nValorDesconto) - (nValorCapitalSocial);


      -- O imposto sempre deve ser tentando o calculo pelos seguintes motivos:
      -- 1) Registrar bases de calculo zeradas e valor de imposto zerado
      -- 2) Reter o imposto para gerar um saldo insuficiente para pagamento do prestador (via boleto)
      DBAPS.PRC_CALCULA_IMPOSTO_PRESTADOR(nCdRepassePrestador,
                                          nRetVlImposto);
      nVlImposto := nRetVlImposto;

      --***************************************************************************************************
      --*      PENSAO (PROD. MEDICA + HORAS TRABALHADAS - IMPOSTOS) = BASE DE CALCULO DE P.A              *
      --***************************************************************************************************
      nVLBasePensaoAliment      := nValorProducaoMedica + nValorHorasTrab -
                                   nVlImposto;
      nVLBasePensaoAlimentTipo2 := nVlLiquidoSemImposto - (nVlImposto);
      --
      IF nVLBasePensaoAliment > 0 THEN
        DBAPS.PACK_MVS_REPASSE_PRESTADOR.P_PENSAO_ALIMENTICIA(nCdRepassePrestador,
                                                              nCdLogRepassePrestador,
                                                              rPrestadores.DT_COMPETENCIA,
                                                              rPrestadores.CD_PRESTADOR,
                                                              nVLBasePensaoAliment,
                                                              nVLBasePensaoAlimentTipo2,
                                                              nRetVlPensaoAliment);

        nValorDesconto := nValorDesconto + nRetVlPensaoAliment;

      END IF;

      --
      vProdMedPrestador(rPrestadores.CD_PRESTADOR).VL_PRODUCAO_MEDICA := nValorProducaoMedica;
      vProdMedPrestador(rPrestadores.CD_PRESTADOR).VL_HORA_TRABALHADA := nValorHorasTrab;
      vProdMedPrestador(rPrestadores.CD_PRESTADOR).VL_ACRESCIMO := nValorAcrescimo;
      vProdMedPrestador(rPrestadores.CD_PRESTADOR).VL_DESCONTO := nValorDesconto;
      vProdMedPrestador(rPrestadores.CD_PRESTADOR).VL_CAPITAL_SOCIAL := nValorCapitalSocial;
      vProdMedPrestador(rPrestadores.CD_PRESTADOR).VL_DESC_CONTRATO := nVlDescContrato;

      /*OPEN cImposto(nCdRepassePrestador);
      FETCH cImposto INTO rImposto;
      IF cImposto%FOUND THEN
        nVlImposto := rImposto.vl_imposto;
      END IF;
      CLOSE cImposto;*/
      --
      nVlLiquidoFinal := nVlLiquidoSemImposto - (nVlImposto);

      --@TODO - criar configura��es
      C_CD_REDUZIDO                 := 1992; --Unimed Sorocaba
      vDiaVencMensContrato          := '25';

       OPEN cItemDespesaSaldoInsuficiente(rMEMVS.CD_LCTO_MENSALIDADE_PREST_COOP);
       FETCH cItemDespesaSaldoInsuficiente
         INTO rItemDespesaSaldoInsuficiente;

       IF cItemDespesaSaldoInsuficiente%FOUND THEN
         C_ITEM_DESP_QUIT_LIQUID_INSUF := rItemDespesaSaldoInsuficiente.CD_ITEM_DESPESA;
       ELSE
         C_ITEM_DESP_QUIT_LIQUID_INSUF := 55;
       END IF;

      CLOSE cItemDespesaSaldoInsuficiente;

      UPDATE DBAPS.REPASSE_PRESTADOR
         SET VL_LIQUIDO_ORIGINAL     = Nvl(nVlLiquidoFinal, 0),
             VL_TOTAL_DIVIDA_QUITADA = 0 --Inicalizando
       WHERE CD_REPASSE_PRESTADOR = nCdRepassePrestador;

      --**************************************************************************************************************************************
      --*                                  QUITAR LIQUIDOS INSUFICIENTES DO COOPERADO - 07/12/2017                                           *
      --* Processo: caso a Unimed tenha alguem em divida com ela descontar o valor da divida do repasse atual (mesmo que seja 1 real apenas) *
      --* Caso o Liquido Final n�o seja suficiente pra quitar a divida.. quite-a mesmo assim e gere um novo boleto da nova divida            *
      --**************************************************************************************************************************************

      IF DBAPS.PKG_UNIMED.LE_UNIMED IS NOT NULL AND nVlLiquidoFinal >= 0 THEN

        nVlTotalDivida := 0;

        SELECT CD_REDUZIDO_BAIXA_PRODUCAO
          INTO C_CD_REDUZIDO
          FROM DBAMV.MULTI_EMPRESAS_MV_SAUDE
         WHERE CD_MULTI_EMPRESA = DBAMV.PKG_MV2000.LE_EMPRESA;

        FOR rSaldoInsuf IN cSaldoInsufAberto(rPrestadores.CD_PRESTADOR) LOOP

          nCdMensContratoRecRet := NULL;
          nVlTotalDivida        := nVlTotalDivida +
                                   rSaldoInsuf.VALOR_DIVIDA;

          /* Processo
          --QUITAR BOLETO ANTIGO caso tenha saldo positivo > 0 (mesmo que seja 1 real)
          --Descontar o valor da divida no repasse atual
          */
          BEGIN

            --Antes de receber - criar um lote de cobran�a avulso caso nao tenha se nao criar vai dar erro no recebimento
            IF rSaldoInsuf.CD_PROCESS_CB IS NULL THEN

              DBAPS.PRC_GERAR_LOTE_COBRANCA_AVULSO(rSaldoInsuf.cd_mens_contrato, --PCD_MENS_CONTRATO
                                                   'LOTE DE COBRAN�A GERADO AUTOMATICAMENTE - QUITA��O SALDO INSUFICIENTE ' ||rSaldoInsuf.cd_mens_contrato, --PDS_DESCRICAO
                                                   'N', --PSN_NOTA_FISCAL
                                                   nCdProcessCbNF, --PCD_PROCESS_CB_NF
                                                   NULL, --PCD_LOG_GER_MENS
                                                   NULL, --PCD_CONTA_CORRENTE
                                                   NULL, --PCD_PROCESS_CB IN
                                                   vSnIntegrConRec --PSN_GERAR_CON_REC
                                                   );
            END IF;

            DBAPS.PRC_MENS_CONTRATO_REC(P_ACAO                    => 'REC',
                                        PCD_SISTEMA_BAIXA         => 'MVS#' ||
                                                                     C_CD_REDUZIDO,
                                        PCD_MENS_CONTRATO         => rSaldoInsuf.CD_MENS_CONTRATO,
                                        PCD_RECCON_REC            => NULL,
                                        PDT_RECEBIMENTO           => SYSDATE,
                                        PDT_CREDITO               => SYSDATE,
                                        PVL_RECEBIMENTO           => rSaldoInsuf.VALOR_DIVIDA,
                                        PDT_ESTORNO               => NULL,
                                        PCD_MENS_CONTRATO_REC_RET => nCdMensContratoRecRet --SETAR CODIGO CONTABIL POIS NAO FOI RECEBIMENTO FINANCEIRO (CONTA 2.1.9)
                                       ,
                                        PVL_DESCONTO              => NULL,
                                        PVL_ACRESCIMO             => NULL);


            INSERT INTO DBAPS.PRESTADOR_CREDITO_DEBITO
              (CD_PRES_CR_DB,
               CD_FATURA,
               CD_LOTE,
               CD_PRESTADOR,
               TP_LANCAMENTO,
               VL_LANCAMENTO,
               VL_PERC_LANCAMENTO,
               DS_USER_INCLUSAO,
               DT_INCLUSAO,
               CD_ITEM_DESPESA,
               CD_PRESTADOR_AC_DC,
               DS_OBSERVACAO,
               CD_REPASSE_PRESTADOR)
            VALUES
              (DBAPS.SEQ_PRESTADOR_CREDITO_DEBITO.NEXTVAL,
               NULL,
               NULL,
               rPrestadores.CD_PRESTADOR,
               'D',
               rSaldoInsuf.VALOR_DIVIDA,
               NULL,
               USER,
               SYSDATE,
               C_ITEM_DESP_QUIT_LIQUID_INSUF,
               NULL,
               'REFERENTE A QUITA��O DO BOLETO DE SALDO INSUFICIENTE N�: ' ||
               rSaldoInsuf.CD_MENS_CONTRATO || ' (COMPETENCIA: ' ||
               rSaldoInsuf.COMPETENCIA || ') - NO VALOR DE R$ ' ||
               rSaldoInsuf.VALOR_DIVIDA || ' - CODIGO DA MENS_CON_REC: ' ||
               nCdMensContratoRecRet,
               nCdRepassePrestador);
            --
            --
          EXCEPTION
            WHEN OTHERS THEN

              vDsErro := SQLERRM;
              INSERT INTO DBAPS.REPASSE_PRESTADOR_ERRO
              VALUES
                (DBAPS.SEQ_REPASSE_PRESTADOR_ERRO.NEXTVAL,
                 nCdRepassePrestador,
                 'ERRO NA BAIXA DO SALDO INSUFICIENTE - VALOR DIVIDA: ' ||
                 rSaldoInsuf.VALOR_DIVIDA || ' ERRO: ' || vDsErro);
              COMMIT;
              Raise_Application_Error(-20999, 'Erro: ' || vDsErro);

          END;

          IF nCdMensContratoRecRet IS NOT NULL THEN
            --
            UPDATE dbaps.mens_contrato_rec
               SET CD_REP_PREST_QUITACAO_DIVIDA = nCdRepassePrestador
             WHERE cd_mens_contrato_rec = nCdMensContratoRecRet;
            --
            UPDATE DBAPS.MENS_CONTRATO
               SET TP_QUITACAO = 'Q'
             WHERE CD_MENS_CONTRATO = rSaldoInsuf.CD_MENS_CONTRATO;
            --
            INSERT INTO DBAPS.REPASSE_PRESTADOR_MENSAGEM
              (CD_REPASSE_PRESTADOR_MENSAGEM,
               CD_REPASSE_PRESTADOR,
               DS_MENSAGEM,
               TP_GRUPO)
            VALUES
              (DBAPS.SEQ_REPASSE_PRESTADOR_MENSAGEM.NEXTVAL,
               nCdRepassePrestador,
               'DESCONTO REFERENTE A QUITA��O DO BOLETO DE SALDO INSUFICIENTE EM ABERTO DE N�: ' ||
               rSaldoInsuf.CD_MENS_CONTRATO || ' (COMPETENCIA: ' ||
               rSaldoInsuf.COMPETENCIA || ') - NO VALOR DE R$ ' ||
               rSaldoInsuf.VALOR_DIVIDA,
               'AD');

            COMMIT;

          END IF;

        END LOOP;

        /* ABter divida do total liquido
        Ex: divida R$ 200 - liquido final: R$ 120 ==> novo liquido final = R$ -80 */
        nVlLiquidoFinal := nVlLiquidoFinal - nVlTotalDivida;

        UPDATE DBAPS.REPASSE_PRESTADOR
           SET VL_TOTAL_DIVIDA_QUITADA = Nvl(nVlTotalDivida, 0),
               VL_DESCONTOS            = VL_DESCONTOS +
                                         Nvl(nVlTotalDivida, 0)
         WHERE CD_REPASSE_PRESTADOR = nCdRepassePrestador;

      END IF; --ENDIF Quitar liquido insuficiente
      --
      --***************************************************************************************************
      --*                LIQUIDO INSUFICIENTE - SALDO NEGATIVO - GERAR BOLETO                             *
      --***************************************************************************************************

      -- N�o gerar boleto se saldo insuficiente for menor que X reais (R$) - Removido
      IF nVlLiquidoFinal < 0 AND C_VALOR_MINIMO_LIQUIDO_INSUF > nVlLiquidoFinal AND rPrestadores.TP_CREDENCIAMENTO = 'D' THEN

        IF rPrestadores.cd_contrato IS NULL THEN
          Raise_Application_Error(-20999,'PRESTADOR: ' ||rPrestadores.CD_PRESTADOR ||' - N�O POSSUI CONTRATO PARA GERA��O DE T�TULO. FAVOR PROVIDENCIAR');
        END IF;
        IF rMEMVS.CD_LCTO_MENSALIDADE_PREST_COOP IS NULL THEN
          Raise_Application_Error(-20999,'N�O EXISTE ITEM DE RECEITA CONFIGURADO PARA SALDO INSUFICIENTE');
        END IF;

        -- Trava para evitar
        IF DBAPS.FNC_CONFIG_CONTABIL(null, rMEMVS.CD_LCTO_MENSALIDADE_PREST_COOP) <> 0 THEN
         Raise_Application_Error(-20999,'T�tulo do l�quido insuficiente n�o foi gerado porque n�o existe configura��o cont�bil. Favor solicitar ao setor cont�bil da OPERADORA a configura��o financeira/cont�bil do item de receita ' || rMEMVS.CD_LCTO_MENSALIDADE_PREST_COOP );
        END IF;

        -- Realiza o lan�amento na tabela de MENS_CONTRATO
        SELECT DBAPS.SEQ_MENS_CONTRATO.NEXTVAL
          INTO nCdMensContrato
          FROM SYS.DUAL;
        --
        BEGIN

          IF vDiaVencMensContrato <
             To_Char(rPrestadores.dt_vencimento, 'DD') THEN
            vDiaVencMensContrato := To_Char(rPrestadores.dt_vencimento,
                                            'DD');
          END IF;

          INSERT INTO DBAPS.MENS_CONTRATO
            (CD_MENS_CONTRATO,
             CD_CONTRATO,
             NR_MES,
             NR_ANO,
             DT_EMISSAO, --1� Dia - Dentro da competencia do boleto
             DT_VENCIMENTO,
             DT_VENCIMENTO_ORIGINAL,
             VL_MENSALIDADE,
             SN_EMITIDO,
             CD_PARCELA,
             TP_RECEITA,
             CD_MULTI_EMPRESA,
             DS_OBSERVACAO,
             DT_INICIO_COBERTURA,
             DT_FINAL_MENSALIDADE,
             DT_CONTABILIZACAO,
             CD_REPASSE_PRESTADOR)
          VALUES
            (nCdMensContrato,
             rPrestadores.cd_contrato, --CD_CONTRATO
             To_Char(rPrestadores.dt_competencia, 'MM'), -- NR_MES
             To_Char(rPrestadores.dt_competencia, 'YYYY'), -- NR_ANO
             rPrestadores.dt_vencimento, -- DT_EMISSAO (GPS-1202 SOROCABA DESEJA DATA DE EMISSAO O VENCIMENTO DA FOLHA
             To_Date(vDiaVencMensContrato ||to_char(rPrestadores.dt_vencimento, 'mm/yyyy'),'dd/mm/yyyy'), -- DT_VENCIMENTO
             To_Date(vDiaVencMensContrato ||to_char(rPrestadores.dt_vencimento, 'mm/yyyy'),'dd/mm/yyyy'), -- DT_VENCIMENTO_ORIGINAL
             Abs(nVlLiquidoFinal), -- VL_MENSALIDADE
             'N', -- SN_EMITIDO
             NULL, -- CD_PARCELA
             'P', -- TP_RECEITA
             DBAMV.PKG_MV2000.LE_EMPRESA, -- CD_MULTI_EMPRESA
             'LIQUIDO INSUFICIENTE COMPET�NCIA ' ||To_Char(rPrestadores.dt_competencia, 'MMYYYY') ||' - REPASSE PRESTADOR: ' || nCdRepassePrestador,--DS_OBSERVACAO
             Trunc(rPrestadores.dt_competencia, 'MM'), --DT_INICIO_COBERTURA
             Last_Day(rPrestadores.dt_competencia),--DT_FINAL_MENSALIDADE
             Trunc(SYSDATE), --DT_CONTABILIZACAO
             nCdRepassePrestador --CD_REPASSE_PRESTADOR
             );

          -- Realiza o lan�amento na tabela de ITMENS_CONTRATO
          INSERT INTO DBAPS.ITMENS_CONTRATO
            (CD_LCTO_MENSALIDADE,
             CD_MENS_CONTRATO,
             VL_LANCAMENTO,
             QT_LANCAMENTO)
          VALUES
            (rMEMVS.CD_LCTO_MENSALIDADE_PREST_COOP,
             nCdMensContrato,
             Abs(nVlLiquidoFinal),
             1);
          DBAPS.PACK_MVS_REPASSE_PRESTADOR.P_GRAVA_LOG_REP_PRES_MENS_ERRO(nCdLogRepassePrestador,
                                                                          'GERADO TITULO DE NUMERO: ' ||
                                                                          nCdMensContrato,
                                                                          'A');

          INSERT INTO DBAPS.REPASSE_PRESTADOR_MENSAGEM
            (CD_REPASSE_PRESTADOR_MENSAGEM,
             CD_REPASSE_PRESTADOR,
             DS_MENSAGEM,
             TP_GRUPO)
          VALUES
            (DBAPS.SEQ_REPASSE_PRESTADOR_MENSAGEM.NEXTVAL,
             nCdRepassePrestador,
             'ATEN��O PRESTADOR - GERADO BOLETO DE N� ' || nCdMensContrato ||
             ' REFERENTE AO SALDO INSUFICIENTE NO VALOR DE R$ ' ||
             Abs(nVlLiquidoFinal) || '. VENCIMENTO PARA O DIA : ' ||
             To_Char(Last_Day(rPrestadores.dt_vencimento), 'DD/MM/YYYY'),
             'OT');

        EXCEPTION
          WHEN OTHERS THEN
            CSQLERRM := SQLERRM;
            DBAPS.PACK_MVS_REPASSE_PRESTADOR.P_GRAVA_LOG_REP_PRES_MENS_ERRO(nCdLogRepassePrestador,
                                                                            CSQLERRM,
                                                                            'E');
            Raise_Application_Error(-20888, CSQLERRM);
        END;
        nVlSaldoInsuficiente := nVlLiquidoFinal;
      END IF;
      --
      --nVlLiquidoFinal := nVlLiquidoSemImposto - (nVlImposto) + ( (nVlSaldoInsuficiente*-1));
      nVlLiquidoFinal := nVlLiquidoFinal + ((nVlSaldoInsuficiente * -1));
      --
      UPDATE DBAPS.REPASSE_PRESTADOR
         SET VL_IMPOSTOS           = Nvl(Round(nVlImposto,2), 0),
             VL_LIQUIDO            = Nvl(Round(nVlLiquidoFinal,2), 0),
             VL_SALDO_INSUFICIENTE = Nvl(nVlSaldoInsuficiente, 0),
             VL_DESCONTOS          = Nvl(nValorDesconto, 0)
       WHERE CD_REPASSE_PRESTADOR = nCdRepassePrestador;
      COMMIT;
      --
      --TRY CATCH LOOP
    EXCEPTION
      WHEN OTHERS THEN
        Raise_Application_Error(-20999, 'Erro: ' || SQLERRM);
    END;
  END LOOP; --END LOOP rPrestadores PAGAMENTO_PRESTADOR

  IF vProdMedPrestador.Count > 0 THEN
    UPDATE dbaps.pagamento_prestador pp
       SET pp.dt_ultimo_processamento = SYSDATE
     WHERE pp.cd_pagamento_prestador = PCD_PAGAMENTO_PRESTADOR;
  END IF;

  COMMIT;

  --TRY CATCH GERAL
EXCEPTION
  WHEN OTHERS THEN

    CSQLERRM := SQLERRM;

    IF nSeqLogPagPrestador IS NULL THEN

      INSERT INTO DBAPS.LOG_PAGAMENTO_PRESTADOR
        (CD_LOG_PAGAMENTO_PRESTADOR,
         CD_PAGAMENTO_PRESTADOR,
         CD_PRESTADOR,
         DS_ERRO)
      VALUES
        (DBAPS.SEQ_LOG_PAGAMENTO_PRESTADOR.NEXTVAL,
         PCD_PAGAMENTO_PRESTADOR,
         NULL,
         CSQLERRM);

    ELSE

      UPDATE DBAPS.LOG_PAGAMENTO_PRESTADOR
         SET DS_ERRO = CSQLERRM
       WHERE CD_LOG_PAGAMENTO_PRESTADOR = nSeqLogPagPrestador;

    END IF;

    IF nCdRepassePrestador IS NOT NULL THEN
      UPDATE DBAPS.REPASSE_PRESTADOR
         SET DS_ERRO = CSQLERRM
       WHERE CD_REPASSE_PRESTADOR = nCdRepassePrestador;
    END IF;

    COMMIT;

    Raise_Application_Error(-20999, 'Erro: ' || CSQLERRM);

END;
/
