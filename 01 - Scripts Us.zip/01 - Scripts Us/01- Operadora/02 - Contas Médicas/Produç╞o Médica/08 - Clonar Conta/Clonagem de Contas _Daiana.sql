/*  CH2205-3642   COPIA CONTAS /BAIXA CONTABIL
 Pe�o a gentileza realizar copia das contas conforme MENSALIDADES apresentada devido falha operacional e comp fechada .

Pe�o a gentileza copiar conforme tela de refat em anexo ,limpando os campos conforme destaque ,
realizar as copias pela mensalidade para que n�o tenha duplicidade
*/

-- fnc_clona_conta_intercambio   --2413

Select 1
  From Dbaps.v_Ctas_Medicas v
 Where v.Cd_Fatura In (38383, 38386, 38387, 38470)

 Create Table Custom.Temp_Clonagem_Conta_Medica As
  Select Distinct Vf.Cd_Lote,
                  Vf.Cd_Conta_Medica,
                  Vf.Cd_Mens_Contrato As Mensalidade,
                  Vf.Cd_Unimed_Origem As Unimed_Origem,
                  Vf.Cd_Fatura As Fatura_Origem,
                  Case
                    When Vf.Cd_Fatura In (37284, 37286) And
                         Vf.Cd_Unimed_Origem = 865 Then
                     38383
                    When Vf.Cd_Fatura In (37322, 37338) And
                         Vf.Cd_Unimed_Origem = 865 Then
                     38386
                    When Vf.Cd_Fatura In
                         (37390, 37391, 36326, 37017, 37018) And
                         Vf.Cd_Unimed_Origem = 994 Then
                     38387
                    Else
                     38470
                  End Fatura_Destino
        
          From Dbaps.v_Ctas_Medicas_Fatura Vf
         Where Vf.Cd_Fatura In (37284,
                                37286,
                                37322,
                                37338,
                                37390,
                                37391,
                                36326,
                                37017,
                                37018,
                                36354,
                                36355,
                                37294,
                                37293,
                                37314,
                                37316)
           And Vf.Cd_Unimed_Origem In (865, 994, 29, 69, 32, 248)
           And Vf.Cd_Mens_Contrato In (2363146,
                                       2362813,
                                       2364898,
                                       2364893,
                                       2366027,
                                       2366268,
                                       2363489,
                                       2363635,
                                       2363699);


Select * From Dbaps.Remessa_Prestador Rp Where Rp.Cd_Remessa = 8487626;

Select t.* From Tmp_Clonar t;

/*TAB=NAO_EXISTE*/
Select t.*
  From Tmp_Clonar t
 Where Not Exists (Select *
          From Dbaps.v_Ctas_Medicas Vc
         Where Vc.Cd_Conta_Medica = t.Cd_Conta_Medica);

/*TAB=CONTA_ORIGINAL*/
Select Distinct Vc.Cd_Fatura, Vc.Cd_Lote, Vc.Cd_Conta_Medica
  From Dbaps.v_Ctas_Medicas Vc, Tmp_Clonar Ta
 Where Vc.Cd_Conta_Medica = Ta.Cd_Conta_Medica;

/*TAB=CONTA_CLONADA*/
Select Distinct Vc.Cd_Fatura,
                Vc.Cd_Lote,
                Vc.Ds_Lote,
                Vc.Cd_Conta_Medica,
                t.*
  From Dbaps.v_Ctas_Medicas Vc, Tmp_Clonadas t
 Where Vc.Cd_Conta_Medica = t.Conta_Destino;

Declare

  v_Retorno Number := 0;

Begin

  For Ix In (Select Distinct t.*
               From Custom.Temp_Clonagem_Conta_Medica t
              Where Not Exists
              (Select 1
                       From Dbaps.Tmp_Clonadas v
                      Where v.Cd_Conta_Medica = t.Cd_Conta_Medica)) Loop
  
    Begin
    
      v_Retorno := Dbaps.Fnc_Clona_Conta_Intercambio_Ob(Pcd_Lote_Origem         => Ix.Cd_Lote,
                                                        Pcd_Conta_Medica_Origem => Ix.Cd_Conta_Medica,
                                                        Pcd_Fatura_Destino      => Ix.Fatura_Destino);
    
      Insert Into Dbaps.Tmp_Clonadas
        (Cd_Lote,
         Cd_Conta_Medica,
         Conta_Destino,
         Cd_Fatura_Nova,
         Dt_Inclusao)
      Values
        (Ix.Cd_Lote,
         Ix.Cd_Conta_Medica,
         v_Retorno,
         Ix.Fatura_Destino,
         Sysdate);
    
    Exception
      When Others Then
        Rollback;
        Raise_Application_Error(-20002,
                                'Falha: ' || Sqlerrm || 'cd_conta_medica: ' ||
                                Ix.Cd_Conta_Medica);
    End;
  End Loop;

Exception
  When Others Then
    Rollback;
    Raise_Application_Error(-20001, 'Falha: ' || Sqlerrm);
End;

/

  Select t.* From Tmp_Clonar t;

/*TAB=CONTA_ORIGINAL*/
Select Distinct Vc.Cd_Fatura, Vc.Cd_Lote, Vc.Cd_Conta_Medica
  From Dbaps.v_Ctas_Medicas Vc, Tmp_Clonar Ta
 Where Vc.Cd_Conta_Medica = Ta.Cd_Conta_Medica;

/*TAB=CONTA_CLONADA*/
Select Distinct Vc.Cd_Fatura, Vc.Cd_Lote, Vc.Cd_Conta_Medica, t.*
  From Dbaps.v_Ctas_Medicas Vc, Tmp_Clonadas t
 Where Vc.Cd_Conta_Medica = t.Conta_Destino;
