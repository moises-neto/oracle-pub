 --MENS CONTRATO PN
 -- SEM MENS CONTRATO IGUAL A ORIGINAL 
 
    
-- TEM MENSALIDADE --> DE CP PARA CN
-- N�O TEM MENSALIDADE --> MESMO VALOR DO TP_PAGCOB ORIGINAL 

/*
CP --> CN

*/
Declare

  v_Retorno Number := 0;
Begin
  For i In (Select t.nr_guia,
                   t.cd_procedimento,
                   t.dt_realizacao,
                   t.cd_prestador,
                   t.nm_prestador,
                   t.lote_guias,
                   t.competencia_pag,
                   t.valor_pago,
                   t.mens_contrato,
                   v.cd_conta_medica As cd_conta_medica,
                   v.cd_lancamento,
                   v.tp_pagcob
              From temp_antecipacao_cooperado t, v_ctas_medicas v
              
             Where v.cd_lote = t.lote_guias
             And v.nr_guia = t.nr_guia
             And v.cd_procedimento = t.cd_procedimento
             And trunc(v.dt_realizado) = trunc(t.dt_realizacao) 
             And t.Mens_Contrato Is Not Null
            
             )
  
   Loop
  
    Begin
      v_Retorno := Custom.Pkg_Conmvs_Prod_Med.Fnc_Clona_Conta_Pagamento_V2(Pcd_Lote_Origem         => i.lote_guias,
                                                                           Pcd_Conta_Medica_Origem => i.Cd_Conta_Medica,
                                                                           Pcd_Fatura_Destino      => 50955,
                                                                           Pcd_Lancamento_Origem   => i.Cd_Lancamento,
                                                                           Pcd_Tp_Pagcob           => 'PN');
    End;
  
  End Loop;

End;

ORA-20999: TRG ITREMESSA EQP AMB. >> Tipo de pagamento n�o permitido para operadora que n�o s�o unimed ( HM )
ORA-06512: em "DBAPS.TRG_ITREMESSA_PRESTADOR_EQUIPE", line 140
ORA-04088: erro durante a execu��o do gatilho 'DBAPS.TRG_ITREMESSA_PRESTADOR_EQUIPE'
ORA-06512: em "CUSTOM.PKG_CONMVS_PROD_MED", line 1449
ORA-06512: em line 30
ORA-06512: em line 30

View program sources of error stack?


--------------------------------------------------------------------------- AJUSTANDO ORIGEM----------------------------------------------------

Begin

  For i In (Select t.nr_guia,
                   t.cd_procedimento,
                   t.dt_realizacao,
                   t.cd_prestador,
                   t.nm_prestador,
                   t.lote_guias,
                   t.competencia_pag,
                   t.valor_pago,
                   t.mens_contrato,
                   v.cd_conta_medica As cd_conta_medica,
                   v.cd_lancamento,
                   v.tp_pagcob,
                   V.tp_conta
              From temp_antecipacao_cooperado t, v_ctas_medicas v
              
             Where v.cd_lote = t.lote_guias
             And v.nr_guia = t.nr_guia
             And v.cd_procedimento = t.cd_procedimento
             And trunc(v.dt_realizado) = trunc(t.dt_realizacao) 
             And t.Mens_Contrato Is Not Null
            
            ) Loop
  
    Begin
      If (i.Tp_Conta = 'A') Then
        Update Itremessa_Prestador Ip
           Set Ip.Tp_Pagcob   = 'CN'
         Where Ip.Cd_Remessa = i.Cd_Conta_Medica
           And Ip.Cd_Lancamento = i.Cd_Lancamento;
      
     
   
      Else
      
        Update Dbaps.Itconta_Hospitalar Ih
           Set Ih.Tp_Pagcob   = 'CN'
             
         Where Ih.Cd_Conta_Hospitalar = i.Cd_Conta_Medica
           And Ih.Cd_Lancamento = i.Cd_Lancamento;
           
      End If;
    
    End;
    Dbms_Output.Put_Line(i.Tp_Conta || ' - ' || i.Cd_Conta_Medica || ' - ' ||
                         i.Tp_Pagcob);
  End Loop;

End;


/*
N�O TEM MENSALIDADE --> NN

*/

Declare

  v_Retorno Number := 0;
Begin
  For i In (Select t.nr_guia,
                   t.cd_procedimento,
                   t.dt_realizacao,
                   t.cd_prestador,
                   t.nm_prestador,
                   t.lote_guias,
                   t.competencia_pag,
                   t.valor_pago,
                   t.mens_contrato,
                   v.cd_conta_medica As cd_conta_medica,
                   v.cd_lancamento,
                   v.tp_pagcob
              From temp_antecipacao_cooperado t, v_ctas_medicas v
              
             Where v.cd_lote = t.lote_guias
             And v.nr_guia = t.nr_guia
             And v.cd_procedimento = t.cd_procedimento
             And trunc(v.dt_realizado) = trunc(t.dt_realizacao) 
             And t.Mens_Contrato Is Null
            
             )
  
   Loop
  
    Begin
      v_Retorno := Custom.Pkg_Conmvs_Prod_Med.Fnc_Clona_Conta_Pagamento_V2(Pcd_Lote_Origem         => i.lote_guias,
                                                                           Pcd_Conta_Medica_Origem => i.Cd_Conta_Medica,
                                                                           Pcd_Fatura_Destino      => 50955,
                                                                           Pcd_Lancamento_Origem   => i.Cd_Lancamento,
                                                                           Pcd_Tp_Pagcob           => I.TP_PAGCOB);
    End;
  
  End Loop;

End;
--------------------------------------------------------------------------- AJUSTANDO ORIGEM----------------------------------------------------

Begin

  For i In (Select t.nr_guia,
                   t.cd_procedimento,
                   t.dt_realizacao,
                   t.cd_prestador,
                   t.nm_prestador,
                   t.lote_guias,
                   t.competencia_pag,
                   t.valor_pago,
                   t.mens_contrato,
                   v.cd_conta_medica As cd_conta_medica,
                   v.cd_lancamento,
                   v.tp_pagcob,
                   V.tp_conta
              From temp_antecipacao_cooperado t, v_ctas_medicas v
              
             Where v.cd_lote = t.lote_guias
             And v.nr_guia = t.nr_guia
             And v.cd_procedimento = t.cd_procedimento
             And trunc(v.dt_realizado) = trunc(t.dt_realizacao) 
             And t.Mens_Contrato Is Null
            
            ) Loop
  
    Begin
      If (i.Tp_Conta = 'A') Then
        Update Itremessa_Prestador Ip
           Set Ip.Tp_Pagcob   = 'NN'
               Ip.Tp_Situacao = 'GA',
               Ip.Cd_Motivo   = 62
         Where Ip.Cd_Remessa = i.Cd_Conta_Medica
           And Ip.Cd_Lancamento = i.Cd_Lancamento;
      
       Update Itremessa_Prestador_Equipe Ip
           Set Ip.Tp_Situacao = 'GA', Ip.Cd_Motivo = 62
         Where Ip.Cd_Remessa = i.Cd_Conta_Medica
           And Ip.Cd_Lancamento = i.Cd_Lancamento;
    
      Else
      
        Update Dbaps.Itconta_Hospitalar Ih
           Set Ih.Tp_Pagcob   = 'NN',
               Ih.Tp_Situacao = 'GA',
               Ih.Cd_Motivo   = 62
         Where Ih.Cd_Conta_Hospitalar = i.Cd_Conta_Medica
           And Ih.Cd_Lancamento = i.Cd_Lancamento;
      
        Update Dbaps.Itconta_Hospitalar Ih
           Set Ih.Tp_Situacao = 'GA', Ih.Cd_Motivo = 62
         Where Ih.Cd_Conta_Hospitalar = i.Cd_Conta_Medica
           And Ih.Cd_Lancamento = i.Cd_Lancamento;
      
      End If;
    
    End;
    Dbms_Output.Put_Line(i.Tp_Conta || ' - ' || i.Cd_Conta_Medica || ' - ' ||
                         i.Tp_Pagcob);
  End Loop;

End;

