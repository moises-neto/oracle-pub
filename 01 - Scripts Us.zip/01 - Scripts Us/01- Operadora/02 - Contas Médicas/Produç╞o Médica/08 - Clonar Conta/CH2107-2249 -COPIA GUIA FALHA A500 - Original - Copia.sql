/*
CH2107-2249 -COPIA GUIA /FALHA A500
Realizar copia das contas para  FATURA 29368,
que se encontra na fatura MV 
28070,
28119,
28110,
28055,
28056,
28057
das carteira (140 e 970)
mens contrato 1926363 (970)
e 1926409 (140),
limpar a informa��o que tr�s devido copia,
realizar a altera��o EXCE��O DE ATENDIMENTO para NORMAL SEM AUTORIZA��O
*/


/*-- fnc_clona_conta_intercambio
create table tmp_clonar as
select distinct vf.cd_lote, vf.cd_conta_medica, 29368 FATURA
  from dbaps.v_ctas_medicas_fatura vf
 where vf.cd_fatura in (28070, 28119, 28110, 28055, 28056, 28057)
   and vf.cd_unimed_origem in (140, 970)
   and vf.cd_mens_contrato in (1926363, 1926409);
*/

select * from dbaps.remessa_prestador rp
where rp.cd_remessa = 8487626;



select t.* from tmp_clonar t;

/*TAB=NAO_EXISTE*/
select t.*
  from tmp_clonar t
 where not exists (select *
          from dbaps.v_ctas_medicas vc
         where vc.cd_conta_medica = t.cd_conta_medica);

/*TAB=CONTA_ORIGINAL*/
select distinct vc.cd_fatura, vc.cd_lote, vc.cd_conta_medica
  from dbaps.v_ctas_medicas vc, tmp_clonar ta
 where vc.cd_conta_medica = ta.cd_conta_medica;

/*TAB=CONTA_CLONADA*/
select distinct vc.cd_fatura, vc.cd_lote, vc.ds_lote, vc.cd_conta_medica, t.*
  from dbaps.v_ctas_medicas vc, tmp_clonadas t
 where vc.cd_conta_medica = t.conta_destino
;
 


Declare

  v_retorno number := 0;

Begin

  For Ix In (select distinct t.*
               from tmp_clonar t) Loop
  
    Begin
    
      v_retorno := dbaps.fnc_clona_conta_intercambio_ob(Ix.cd_lote,
                                                   Ix.cd_conta_medica,
                                                   Ix.Fatura);
    
      insert into tmp_clonadas
      values
        (Ix.cd_lote, Ix.cd_conta_medica, v_retorno);
    
    Exception
      When Others Then
        Rollback;
        Raise_Application_Error(-20002,
                                'Falha: ' || Sqlerrm || 'cd_conta_medica: ' ||
                                Ix.cd_conta_medica);
    End;
  End Loop;

Exception
  When Others Then
    Rollback;
    Raise_Application_Error(-20001, 'Falha: ' || Sqlerrm);
End;

/


select t.* from tmp_clonar t;


/*TAB=CONTA_ORIGINAL*/
select distinct vc.cd_fatura, vc.cd_lote, vc.cd_conta_medica
  from dbaps.v_ctas_medicas vc, tmp_clonar ta
 where vc.cd_conta_medica = ta.cd_conta_medica;

/*TAB=CONTA_CLONADA*/
select distinct vc.cd_fatura, vc.cd_lote, vc.cd_conta_medica, t.*
  from dbaps.v_ctas_medicas vc, tmp_clonadas t
 where vc.cd_conta_medica = t.conta_destino;
