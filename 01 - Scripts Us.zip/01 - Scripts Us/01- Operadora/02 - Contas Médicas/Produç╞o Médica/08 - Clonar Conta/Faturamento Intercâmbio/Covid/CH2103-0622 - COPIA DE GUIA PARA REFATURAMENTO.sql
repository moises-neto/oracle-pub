/*
-- CH2103-0622 - COPIA DE GUIA PARA REFATURAMENTO
Pe�o a gentileza realizar copia das contas em anexo conforme j� solicitado via CH -CH2102-3217,
para a fatura MV 25651,
deixar na conta somente os c�digos com a seguinte descri��o e codigo:(40324796,40314618,40324788)
SARS-COV-2 (CORONAV�RUS COVID-19) - PESQUISA POR RT (COM DIRETRIZ DEFINIDA PELA ANS - N� 126)
SARS-COV-2 (CORONAV�RUS COVID-19), PESQUISA DE ANTICORPOS TOTAIS (IGA, IGG, IGM), (COM DIRETRIZ DEFINIDA PELA ANS N� 132)
SARS-COV-2 (CORONAV�RUS COVID-19), PESQUISA DE ANTICORPOS IGA, IGG OU IGM, ISOLADA POR CLASSE DE IMUNOGLOBULINA, (COM DIRETRIZ DEFINIDA PELA ANS N� 132)
*/

-- CH2103-0739



/* 
Inserir as contas na tmp_contas_refat_covid 
Abrir a dbaps.fnc_clona_conta_pagamento e atualizar o nome do lote e a a��o
*/


/*TAB=CLONAR*/

select distinct t.cd_lote                  lote_origem,
       t.cd_conta_medica          conta_origem,
       t.nr_carteira_beneficiario,
       t.nm_beneficiario,      
       25651                      fatura_destino
  from tmp_contas_refat_covid t
 where not exists (select 1
          from tmp_contas_clonadas_covid tr
         where tr.conta_origem = t.cd_conta_medica
           and tr.lote_origem = t.cd_lote)
           /*and t.cd_conta_medica = 7445717*/;

select t.cd_lote                  lote_origem,
       t.cd_conta_medica          conta_origem,
       t.nr_carteira_beneficiario,
       t.nm_beneficiario,
       t.cd_procedimento,
       t.ds_procedimento,
       25651                      fatura_destino,
       tc.conta_destino
  from tmp_contas_refat_covid t, tmp_contas_clonadas_covid tc
 where tc.conta_origem = t.cd_conta_medica
   and tc.lote_origem = t.cd_lote
   /*and t.cd_conta_medica = 7445717*/;


BEGIN
  DBAMV.PKG_MV2000.ATRIBUI_EMPRESA('1');
END;
/

Declare

v_retorno number := 0;

Begin

  For Ix In (select distinct t.cd_lote                  lote_origem,
                    t.cd_conta_medica          conta_origem,                    
                    25651                      fatura_destino
               from tmp_contas_refat_covid t
              where not exists (select 1
                       from tmp_contas_clonadas_covid tr
                      where tr.conta_origem = t.cd_conta_medica
                        and tr.lote_origem = t.cd_lote)
              /*and t.cd_conta_medica = 7445717*/) Loop
  
    Begin
    
      v_retorno := fnc_clona_conta_intercam_covid(Ix.lote_origem,
                                                  Ix.conta_origem,
                                                  Ix.fatura_destino);
    
      insert into tmp_contas_clonadas_covid
      values
        (Ix.lote_origem, Ix.conta_origem, v_retorno);
    
    Exception
      When Others Then
        Rollback;
        Raise_Application_Error(-20002,
                                'Falha: ' || Sqlerrm || ' Conta Origem: ' ||
                                Ix.conta_origem || ' Lote Origem: ' ||
                                Ix.lote_origem );
    End;
  End Loop;

Exception
  When Others Then
    Rollback;
    Raise_Application_Error(-20001, 'Falha: ' || Sqlerrm);
End;

/

  select distinct t.cd_lote                  lote_origem,
         t.cd_conta_medica          conta_origem,
         t.nr_carteira_beneficiario,
         t.nm_beneficiario,         
         25651                      fatura_destino
    from tmp_contas_refat_covid t
   where not exists (select 1
            from tmp_contas_clonadas_covid tr
           where tr.conta_origem = t.cd_conta_medica
             and tr.lote_origem = t.cd_lote)
             /*and t.cd_conta_medica = 7445717*/;

select t.cd_lote                  lote_origem,
       t.cd_conta_medica          conta_origem,
       t.nr_carteira_beneficiario,
       t.nm_beneficiario,
       t.cd_procedimento,
       t.ds_procedimento,
       25651                      fatura_destino,
       tc.conta_destino
  from tmp_contas_refat_covid t, tmp_contas_clonadas_covid tc
 where tc.conta_origem = t.cd_conta_medica
   and tc.lote_origem = t.cd_lote
   /*and t.cd_conta_medica = 7445717*/;


/*TAB=INCLUIR_INDICACAO*/


select distinct t.cd_lote lote_origem,
                t.cd_conta_medica conta_origem,
                t.nr_carteira_beneficiario,
                t.nm_beneficiario,
                t.cd_procedimento,
                t.ds_procedimento,                
                vc.cd_lote lote_destino,
                tc.conta_destino,
                vc.cd_procedimento,
                rp.cd_indicacao_clinica indicacao_clinica_conta,
                custom.fn_remove_acento(t.indicacao_clinica) indicacao_clinica_planilha
  from tmp_contas_refat_covid    t,
       tmp_contas_clonadas_covid tc,
       dbaps.v_ctas_medicas      vc,
       dbaps.remessa_prestador   rp
 where tc.conta_origem = t.cd_conta_medica
   and tc.lote_origem = t.cd_lote
   and vc.cd_conta_medica = tc.conta_destino
   and rp.cd_remessa = vc.cd_conta_medica
   and rp.cd_indicacao_clinica is null
   /*and t.cd_conta_medica = 7445717*/;

BEGIN
DBAMV.PKG_MV2000.ATRIBUI_EMPRESA('1');
END;
/


Declare
Begin

  For Ix In (select distinct
                             tc.conta_destino,                            
                             rp.cd_indicacao_clinica indicacao_clinica_conta,
                             custom.fn_remove_acento(t.indicacao_clinica) indicacao_clinica_planilha
               from tmp_contas_refat_covid    t,
                    tmp_contas_clonadas_covid tc,
                    dbaps.v_ctas_medicas      vc,
                    dbaps.remessa_prestador   rp
              where tc.conta_origem = t.cd_conta_medica
                and tc.lote_origem = t.cd_lote
                and vc.cd_conta_medica = tc.conta_destino
                and rp.cd_remessa = vc.cd_conta_medica
                and rp.cd_indicacao_clinica is null
                /*and t.cd_conta_medica = 7445717*/) Loop
  
    Begin
    
      UPDATE DBAPS.REMESSA_PRESTADOR RP
         SET rp.cd_indicacao_clinica = Ix.indicacao_clinica_planilha
       WHERE rp.cd_remessa = Ix.Conta_Destino;
    
    Exception
      When Others Then
        Rollback;
        Raise_Application_Error(-20002,
                                'Falha: ' || Sqlerrm || ' Conta: ' ||
                                Ix.Conta_Destino);
    End;
  End Loop;

Exception
  When Others Then
    Rollback;
    Raise_Application_Error(-20001, 'Falha: ' || Sqlerrm);
End;
/

  select distinct t.cd_lote lote_origem,
                  t.cd_conta_medica conta_origem,
                  t.nr_carteira_beneficiario,
                  t.nm_beneficiario,
                  t.cd_procedimento,
                  t.ds_procedimento,                  
                  vc.cd_lote lote_destino,
                  tc.conta_destino,
                  vc.cd_procedimento,
                  rp.cd_indicacao_clinica indicacao_clinica_conta,
                  custom.fn_remove_acento(t.indicacao_clinica) indicacao_clinica_planilha
    from tmp_contas_refat_covid    t,
         tmp_contas_clonadas_covid tc,
         dbaps.v_ctas_medicas      vc,
         dbaps.remessa_prestador   rp
   where tc.conta_origem = t.cd_conta_medica
     and tc.lote_origem = t.cd_lote
     and vc.cd_conta_medica = tc.conta_destino
     and rp.cd_remessa = vc.cd_conta_medica
     and rp.cd_indicacao_clinica is null
     /*and t.cd_conta_medica = 7445717*/;

select distinct t.cd_lote lote_origem,
                t.cd_conta_medica conta_origem,
                t.nr_carteira_beneficiario,
                t.nm_beneficiario,
                /*t.cd_procedimento,
                t.ds_procedimento,  */              
                vc.cd_lote lote_destino,
                tc.conta_destino,
                vc.cd_procedimento,
                rp.cd_indicacao_clinica indicacao_clinica_conta,
                custom.fn_remove_acento(t.indicacao_clinica) indicacao_clinica_planilha
  from tmp_contas_refat_covid    t,
       tmp_contas_clonadas_covid tc,
       dbaps.v_ctas_medicas      vc,
       dbaps.remessa_prestador   rp
 where tc.conta_origem = t.cd_conta_medica
   and tc.lote_origem = t.cd_lote
   and vc.cd_conta_medica = tc.conta_destino
   and rp.cd_remessa = vc.cd_conta_medica
   /*and t.cd_conta_medica = 7445717*/;
