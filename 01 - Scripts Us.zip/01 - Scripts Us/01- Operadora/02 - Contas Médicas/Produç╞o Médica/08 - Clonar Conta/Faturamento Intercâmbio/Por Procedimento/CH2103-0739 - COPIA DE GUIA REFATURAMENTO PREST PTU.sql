/*
CH2103-0739 - COPIA DE GUIA REFATURAMENTO PREST PTU
realizar copia das contas em anexo e incluir nas mesma a informa��o de PREST PTU
na aba Cob Intercambio conforme prestador apresentado em conta
(realizado para faturas Autorizador).

Segue fatura MV para realizar copiar 25653 (5� REF PROFISSIONAL EXECUTENTE UNIMED 970)
*/

/* 
Inserir as contas na tmp_contas_executante 
Abrir a dbaps.fnc_clona_conta_pagamento e atualizar o nome do lote e a a��o
*/


select distinct t.* from tmp_contas_executante t;

/*TAB=CLONAR*/

select distinct t.cd_lote                  lote_origem,
       t.cd_conta_medica          conta_origem,
       t.nr_carteira_beneficiario,
       t.nm_beneficiario,
       t.cd_procedimento,
       t.ds_procedimento,
       25653                      fatura_destino
  from tmp_contas_executante t
 where not exists (select 1
          from tmp_contas_clonadas_covid tr
         where tr.conta_origem = t.cd_conta_medica
           and tr.lote_origem = t.cd_lote);

select distinct t.cd_lote                  lote_origem,
       t.cd_conta_medica          conta_origem,
       t.nr_carteira_beneficiario,
       t.nm_beneficiario,
       t.cd_procedimento,
       t.ds_procedimento,
       25653                      fatura_destino,
       tc.conta_destino
  from tmp_contas_executante t, tmp_contas_clonadas_covid tc
 where tc.conta_origem = t.cd_conta_medica
   and tc.lote_origem = t.cd_lote;

/*   
ORA-20001: Falha: ORA-20002: Falha: ORA-20999:  Lote/Conta origem n�o encontrada(o)! 
Conta Origem: 7444934 Lote Origem: 279902 Procedimento: 40314618
ORA-06512: em line 38

*/

BEGIN
  DBAMV.PKG_MV2000.ATRIBUI_EMPRESA('1');
END;
/

Declare

v_retorno number := 0;

Begin

  For Ix In (select distinct t.cd_lote                  lote_origem,
                    t.cd_conta_medica          conta_origem,
                    t.nr_carteira_beneficiario,
                    t.nm_beneficiario,
                    t.cd_procedimento,
                    t.ds_procedimento,
                    25653                      fatura_destino
               from tmp_contas_executante t
              where not exists (select 1
                       from tmp_contas_clonadas_covid tr
                      where tr.conta_origem = t.cd_conta_medica
                        and tr.lote_origem = t.cd_lote)) Loop
  
    Begin
    
      v_retorno := fnc_clona_conta_intercambio_pr(Ix.lote_origem,
                                                  Ix.conta_origem,
                                                  Ix.cd_procedimento,
                                                  Ix.fatura_destino);
    
      insert into tmp_contas_clonadas_covid
      values
        (Ix.lote_origem, Ix.conta_origem, v_retorno);
    
    Exception
      When Others Then
        Rollback;
        Raise_Application_Error(-20002,
                                'Falha: ' || Sqlerrm || ' Conta Origem: ' ||
                                Ix.conta_origem || ' Lote Origem: ' ||
                                Ix.lote_origem || ' Procedimento: ' ||
                                Ix.Cd_Procedimento);
    End;
  End Loop;

Exception
  When Others Then
    Rollback;
    Raise_Application_Error(-20001, 'Falha: ' || Sqlerrm);
End;

/

  select distinct t.cd_lote                  lote_origem,
         t.cd_conta_medica          conta_origem,
         t.nr_carteira_beneficiario,
         t.nm_beneficiario,
         t.cd_procedimento,
         t.ds_procedimento,
         25653                      fatura_destino
    from tmp_contas_executante t
   where not exists (select 1
            from tmp_contas_clonadas_covid tr
           where tr.conta_origem = t.cd_conta_medica
             and tr.lote_origem = t.cd_lote);

select distinct t.cd_lote                  lote_origem,
       t.cd_conta_medica          conta_origem,
       t.nr_carteira_beneficiario,
       t.nm_beneficiario,
       t.cd_procedimento,
       t.ds_procedimento,
       25653                      fatura_destino,
       tc.conta_destino
  from tmp_contas_executante t, tmp_contas_clonadas_covid tc
 where tc.conta_origem = t.cd_conta_medica
   and tc.lote_origem = t.cd_lote;



select distinct t.cd_lote                  lote_origem,
       t.cd_conta_medica          conta_origem,
       t.nr_carteira_beneficiario,
       t.nm_beneficiario,
       t.cd_procedimento,
       t.ds_procedimento,
       25653                      fatura_destino,
       tc.conta_destino
  from tmp_contas_executante     t,
       tmp_contas_clonadas_covid tc,
       dbaps.v_ctas_medicas      vc
 where tc.conta_origem = t.cd_conta_medica
   and tc.lote_origem = t.cd_lote
   and vc.cd_conta_medica = tc.conta_destino;

select distinct t.cd_lote                  lote_origem,
       t.cd_conta_medica          conta_origem,
       t.nr_carteira_beneficiario,
       t.nm_beneficiario,
       t.cd_procedimento,
       t.ds_procedimento,
       25653                      fatura_destino,
       tc.conta_destino
  from tmp_contas_executante     t,
       tmp_contas_clonadas_covid tc,
       dbaps.v_ctas_medicas      vc,
       dbaps.remessa_prestador   rp
 where tc.conta_origem = t.cd_conta_medica
   and tc.lote_origem = t.cd_lote
   and vc.cd_conta_medica = tc.conta_destino
   and rp.cd_remessa = vc.cd_conta_medica;

select vc.cd_lote,
       vc.cd_conta_medica,
       vc.cd_lancamento,
       vc.cd_procedimento,
       po.ds_procedimento,
       vc.cd_prestador,
       (select pr.nm_prestador
          from dbaps.prestador pr
         where pr.cd_prestador = vc.cd_prestador) prestador,
       case vc.cd_procedimento
         when '50000470' then
          (select pa.cd_prestador_associado
             from dbaps.prestador_associado     pa,
                  dbaps.especialidade_prestador ep
            where pa.cd_prestador = vc.cd_prestador
              and ep.cd_prestador = pa.cd_prestador_associado
              and ep.cd_especialidade = 96 -- PSICOLOGO
              and pa.dt_termino is null
              and pa.sn_repasse_pj = 'S'
              and rownum = 1)
       
       --- 50000462 CONSULTA EM PSICOLOGIA       
         when '50000462' then
          (select pa.cd_prestador_associado
             from dbaps.prestador_associado     pa,
                  dbaps.especialidade_prestador ep
            where pa.cd_prestador = vc.cd_prestador
              and ep.cd_prestador = pa.cd_prestador_associado
              and ep.cd_especialidade = 96 -- PSICOLOGO
              and pa.dt_termino is null
              and pa.sn_repasse_pj = 'S'
              and rownum = 1)
       
       -- 50000560  CONSULTA AMBULATORIAL POR NUTRICIONISTA 
         when '50000560' THEN
          (select pa.cd_prestador_associado
             from dbaps.prestador_associado     pa,
                  dbaps.especialidade_prestador ep
            where pa.cd_prestador = vc.cd_prestador
              and ep.cd_prestador = pa.cd_prestador_associado
              and ep.cd_especialidade = 30 -- NUTRICIONISTA 
              and pa.dt_termino is null
              and pa.sn_repasse_pj = 'S'
              and rownum = 1)
       
       -- 50000616 SESS�O INDIVIDUAL AMBULATORIAL DE FONOAUDIOLOGIA 
         when '50000616' THEN
          (select pa.cd_prestador_associado
             from dbaps.prestador_associado     pa,
                  dbaps.especialidade_prestador ep
            where pa.cd_prestador = vc.cd_prestador
              and ep.cd_prestador = pa.cd_prestador_associado
              and ep.cd_especialidade = 31 -- FONOAUDIOLOGO  
              and pa.dt_termino is null
              and pa.sn_repasse_pj = 'S'
              and rownum = 1)
       
       -- 50000080 SESS�O INDIVIDUAL AMBULATORIAL, EM TERAPIA OCUPACIONAL
         when '50000080' then
          (select pa.cd_prestador_associado
             from dbaps.prestador_associado     pa,
                  dbaps.especialidade_prestador ep
            where pa.cd_prestador = vc.cd_prestador
              and ep.cd_prestador = pa.cd_prestador_associado
              and ep.cd_especialidade = 32 -- TERAPEUTA OCUPACIONAL   
              and pa.dt_termino is null
              and pa.sn_repasse_pj = 'S'
              and rownum = 1)
       
       -- 50000616  SESS�O INDIVIDUAL AMBULATORIAL DE FONOAUDIOLOGIA 
         when '50000616' then
          (select pa.cd_prestador_associado
             from dbaps.prestador_associado     pa,
                  dbaps.especialidade_prestador ep
            where pa.cd_prestador = vc.cd_prestador
              and ep.cd_prestador = pa.cd_prestador_associado
              and ep.cd_especialidade = 31 -- FONOAUDIOLOGO 
              and pa.dt_termino is null
              and pa.sn_repasse_pj = 'S'
              and rownum = 1)
       
         else
          (select pa.cd_prestador_associado
             from dbaps.prestador_associado     pa,
                  dbaps.especialidade_prestador ep
            where pa.cd_prestador = vc.cd_prestador
              and ep.cd_prestador = pa.cd_prestador_associado
              and ep.cd_especialidade = 29 -- FISIOTERAPEUTA GERAL
              and pa.dt_termino is null
              and pa.sn_repasse_pj = 'S'
              and rownum = 1)
       end prestador_ptu,
       
       ite.cd_prestador_ptu,
       itf.cd_prestador_ptu

  from dbaps.v_ctas_medicas             vc,
       dbaps.procedimento               po,
       dbaps.itremessa_prestador_equipe ite,
       dbaps.itremessa_prestador_fatura itf,
       tmp_contas_executante            t,
       tmp_contas_clonadas_covid        tc

 where tc.conta_origem = t.cd_conta_medica
   and tc.lote_origem = t.cd_lote
   and vc.cd_conta_medica = tc.conta_destino
   and po.cd_procedimento = vc.cd_procedimento
   and ite.cd_remessa = vc.cd_conta_medica
   and ite.cd_lancamento = vc.cd_lancamento
   and itf.cd_remessa = vc.cd_conta_medica
   and itf.cd_lancamento = vc.cd_lancamento
   and itf.cd_prestador_ptu is null;

--alter trigger dbaps.trg_itremessa_prestador_fatura disable;

Declare
Begin

  For Ix In (select vc.cd_lote,
                    vc.cd_conta_medica,
                    vc.cd_lancamento,
                    vc.cd_procedimento,
                    po.ds_procedimento,
                    vc.cd_prestador,
                    (select pr.nm_prestador
                       from dbaps.prestador pr
                      where pr.cd_prestador = vc.cd_prestador) prestador,
                    case vc.cd_procedimento
                      when '50000470' then
                       (select pa.cd_prestador_associado
                          from dbaps.prestador_associado     pa,
                               dbaps.especialidade_prestador ep
                         where pa.cd_prestador = vc.cd_prestador
                           and ep.cd_prestador = pa.cd_prestador_associado
                           and ep.cd_especialidade = 96 -- PSICOLOGO
                           and pa.dt_termino is null
                           and pa.sn_repasse_pj = 'S'
                           and rownum = 1)
                    
                    --- 50000462 CONSULTA EM PSICOLOGIA       
                      when '50000462' then
                       (select pa.cd_prestador_associado
                          from dbaps.prestador_associado     pa,
                               dbaps.especialidade_prestador ep
                         where pa.cd_prestador = vc.cd_prestador
                           and ep.cd_prestador = pa.cd_prestador_associado
                           and ep.cd_especialidade = 96 -- PSICOLOGO
                           and pa.dt_termino is null
                           and pa.sn_repasse_pj = 'S'
                           and rownum = 1)
                    
                    -- 50000560  CONSULTA AMBULATORIAL POR NUTRICIONISTA 
                      when '50000560' THEN
                       (select pa.cd_prestador_associado
                          from dbaps.prestador_associado     pa,
                               dbaps.especialidade_prestador ep
                         where pa.cd_prestador = vc.cd_prestador
                           and ep.cd_prestador = pa.cd_prestador_associado
                           and ep.cd_especialidade = 30 -- NUTRICIONISTA 
                           and pa.dt_termino is null
                           and pa.sn_repasse_pj = 'S'
                           and rownum = 1)
                    
                    -- 50000616 SESS�O INDIVIDUAL AMBULATORIAL DE FONOAUDIOLOGIA 
                      when '50000616' THEN
                       (select pa.cd_prestador_associado
                          from dbaps.prestador_associado     pa,
                               dbaps.especialidade_prestador ep
                         where pa.cd_prestador = vc.cd_prestador
                           and ep.cd_prestador = pa.cd_prestador_associado
                           and ep.cd_especialidade = 31 -- FONOAUDIOLOGO  
                           and pa.dt_termino is null
                           and pa.sn_repasse_pj = 'S'
                           and rownum = 1)
                    
                    -- 50000080 SESS�O INDIVIDUAL AMBULATORIAL, EM TERAPIA OCUPACIONAL
                      when '50000080' then
                       (select pa.cd_prestador_associado
                          from dbaps.prestador_associado     pa,
                               dbaps.especialidade_prestador ep
                         where pa.cd_prestador = vc.cd_prestador
                           and ep.cd_prestador = pa.cd_prestador_associado
                           and ep.cd_especialidade = 32 -- TERAPEUTA OCUPACIONAL   
                           and pa.dt_termino is null
                           and pa.sn_repasse_pj = 'S'
                           and rownum = 1)
                    
                    -- 50000616  SESS�O INDIVIDUAL AMBULATORIAL DE FONOAUDIOLOGIA 
                      when '50000616' then
                       (select pa.cd_prestador_associado
                          from dbaps.prestador_associado     pa,
                               dbaps.especialidade_prestador ep
                         where pa.cd_prestador = vc.cd_prestador
                           and ep.cd_prestador = pa.cd_prestador_associado
                           and ep.cd_especialidade = 31 -- FONOAUDIOLOGO 
                           and pa.dt_termino is null
                           and pa.sn_repasse_pj = 'S'
                           and rownum = 1)
                    
                      else
                       (select pa.cd_prestador_associado
                          from dbaps.prestador_associado     pa,
                               dbaps.especialidade_prestador ep
                         where pa.cd_prestador = vc.cd_prestador
                           and ep.cd_prestador = pa.cd_prestador_associado
                           and ep.cd_especialidade = 29 -- FISIOTERAPEUTA GERAL
                           and pa.dt_termino is null
                           and pa.sn_repasse_pj = 'S'
                           and rownum = 1)
                    end prestador_ptu
             
               from dbaps.v_ctas_medicas             vc,
                    dbaps.procedimento               po,
                    dbaps.itremessa_prestador_equipe ite,
                    dbaps.itremessa_prestador_fatura itf,
                    tmp_contas_executante            t,
                    tmp_contas_clonadas_covid        tc
             
              where tc.conta_origem = t.cd_conta_medica
                and tc.lote_origem = t.cd_lote
                and vc.cd_conta_medica = tc.conta_destino
                and po.cd_procedimento = vc.cd_procedimento
                and ite.cd_remessa = vc.cd_conta_medica
                and ite.cd_lancamento = vc.cd_lancamento
                and itf.cd_remessa = vc.cd_conta_medica
                and itf.cd_lancamento = vc.cd_lancamento
                and itf.cd_prestador_ptu is null) Loop
  
    Begin
    
      UPDATE DBAPS.ITREMESSA_PRESTADOR_EQUIPE ITE
         SET ite.cd_prestador_ptu = Ix.Prestador_Ptu
       WHERE ite.cd_remessa = Ix.Cd_Conta_Medica
         and ite.cd_lancamento = Ix.Cd_Lancamento;
    
      UPDATE DBAPS.Itremessa_Prestador_Fatura itf
         SET itf.cd_prestador_ptu = Ix.Prestador_Ptu
       WHERE itf.cd_remessa = Ix.Cd_Conta_Medica
         and itf.cd_lancamento = Ix.Cd_Lancamento;
    
    Exception
      When Others Then
        Rollback;
        Raise_Application_Error(-20002,
                                'Falha: ' || Sqlerrm || ' Conta: ' ||
                                Ix.Cd_Conta_Medica);
    End;
  End Loop;

Exception
  When Others Then
    Rollback;
    Raise_Application_Error(-20001, 'Falha: ' || Sqlerrm);
End;
/

--alter trigger dbaps.trg_itremessa_prestador_fatura enable;
  select distinct vc.cd_lote,
         vc.cd_conta_medica,
         vc.cd_lancamento,
         vc.cd_procedimento,
         po.ds_procedimento,
         vc.cd_prestador,
         (select pr.nm_prestador
            from dbaps.prestador pr
           where pr.cd_prestador = vc.cd_prestador) prestador,
         case vc.cd_procedimento
           when '50000470' then
            (select pa.cd_prestador_associado
               from dbaps.prestador_associado     pa,
                    dbaps.especialidade_prestador ep
              where pa.cd_prestador = vc.cd_prestador
                and ep.cd_prestador = pa.cd_prestador_associado
                and ep.cd_especialidade = 96 -- PSICOLOGO
                and pa.dt_termino is null
                and pa.sn_repasse_pj = 'S'
                and rownum = 1)
         
         --- 50000462 CONSULTA EM PSICOLOGIA       
           when '50000462' then
            (select pa.cd_prestador_associado
               from dbaps.prestador_associado     pa,
                    dbaps.especialidade_prestador ep
              where pa.cd_prestador = vc.cd_prestador
                and ep.cd_prestador = pa.cd_prestador_associado
                and ep.cd_especialidade = 96 -- PSICOLOGO
                and pa.dt_termino is null
                and pa.sn_repasse_pj = 'S'
                and rownum = 1)
         
         -- 50000560  CONSULTA AMBULATORIAL POR NUTRICIONISTA 
           when '50000560' THEN
            (select pa.cd_prestador_associado
               from dbaps.prestador_associado     pa,
                    dbaps.especialidade_prestador ep
              where pa.cd_prestador = vc.cd_prestador
                and ep.cd_prestador = pa.cd_prestador_associado
                and ep.cd_especialidade = 30 -- NUTRICIONISTA 
                and pa.dt_termino is null
                and pa.sn_repasse_pj = 'S'
                and rownum = 1)
         
         -- 50000616 SESS�O INDIVIDUAL AMBULATORIAL DE FONOAUDIOLOGIA 
           when '50000616' THEN
            (select pa.cd_prestador_associado
               from dbaps.prestador_associado     pa,
                    dbaps.especialidade_prestador ep
              where pa.cd_prestador = vc.cd_prestador
                and ep.cd_prestador = pa.cd_prestador_associado
                and ep.cd_especialidade = 31 -- FONOAUDIOLOGO  
                and pa.dt_termino is null
                and pa.sn_repasse_pj = 'S'
                and rownum = 1)
         
         -- 50000080 SESS�O INDIVIDUAL AMBULATORIAL, EM TERAPIA OCUPACIONAL
           when '50000080' then
            (select pa.cd_prestador_associado
               from dbaps.prestador_associado     pa,
                    dbaps.especialidade_prestador ep
              where pa.cd_prestador = vc.cd_prestador
                and ep.cd_prestador = pa.cd_prestador_associado
                and ep.cd_especialidade = 32 -- TERAPEUTA OCUPACIONAL   
                and pa.dt_termino is null
                and pa.sn_repasse_pj = 'S'
                and rownum = 1)
         
         -- 50000616  SESS�O INDIVIDUAL AMBULATORIAL DE FONOAUDIOLOGIA 
           when '50000616' then
            (select pa.cd_prestador_associado
               from dbaps.prestador_associado     pa,
                    dbaps.especialidade_prestador ep
              where pa.cd_prestador = vc.cd_prestador
                and ep.cd_prestador = pa.cd_prestador_associado
                and ep.cd_especialidade = 31 -- FONOAUDIOLOGO 
                and pa.dt_termino is null
                and pa.sn_repasse_pj = 'S'
                and rownum = 1)
         
           else
            (select pa.cd_prestador_associado
               from dbaps.prestador_associado     pa,
                    dbaps.especialidade_prestador ep
              where pa.cd_prestador = vc.cd_prestador
                and ep.cd_prestador = pa.cd_prestador_associado
                and ep.cd_especialidade = 29 -- FISIOTERAPEUTA GERAL
                and pa.dt_termino is null
                and pa.sn_repasse_pj = 'S'
                and rownum = 1)
         end prestador_ptu,
         
         ite.cd_prestador_ptu,
         itf.cd_prestador_ptu
  
    from dbaps.v_ctas_medicas             vc,
         dbaps.procedimento               po,
         dbaps.itremessa_prestador_equipe ite,
         dbaps.itremessa_prestador_fatura itf,
         tmp_contas_executante            t,
         tmp_contas_clonadas_covid        tc
  
   where tc.conta_origem = t.cd_conta_medica
     and tc.lote_origem = t.cd_lote
     and vc.cd_conta_medica = tc.conta_destino
     and po.cd_procedimento = vc.cd_procedimento
     and ite.cd_remessa = vc.cd_conta_medica
     and ite.cd_lancamento = vc.cd_lancamento
     and itf.cd_remessa = vc.cd_conta_medica
     and itf.cd_lancamento = vc.cd_lancamento
     /*and itf.cd_prestador_ptu is null*/;
