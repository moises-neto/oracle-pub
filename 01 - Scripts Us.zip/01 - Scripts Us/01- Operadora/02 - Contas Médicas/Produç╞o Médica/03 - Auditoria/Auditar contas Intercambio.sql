Declare
  v_Retorno Number := 0;

Begin
  Begin
    Dbamv.Pkg_Mv2000.Atribui_Empresa('1');
  End;
  For i In (Select v.Cd_Lote, v.Cd_Conta_Medica, v.Cd_Lancamento
               From Temp_Contas_Hosp_Acerto_V2 v) Loop
  
    Begin
      v_Retorno := Dbaps.Fnc_Analisa_Intercambio_Fat(Ptp_Conta => 'A', -- A-> ambulatorial
                                                     Pcd_Lote  => i.Cd_Lote,
                                                     Pcd_Conta => i.Cd_Conta_Medica);
    End;
  
  End Loop;

End;
