Declare
  v_Retorno Number := 0;
Begin

  For i In (Select Distinct v.Cd_Lote, v.Cd_Conta_Medica
              From Temp_Contas_Audit_202303 v
             Where Exists (Select 1
                      From Dbaps.Remessa_Prestador Rp
                     Where Rp.Cd_Remessa = v.Cd_Conta_Medica
                       And Rp.Tp_Situacao = ('NA'))
                       Order By 2 Desc) Loop
  
    Begin
      v_Retorno := Dbaps.Fnc_Mvs_Analisa_Conta_Amb_018(i.Cd_Lote,
                                                       i.Cd_Conta_Medica,
                                                       'S',
                                                       1);
    End;
  
  End Loop;

End;

/*Select Rowid, e.*
  From Remessa_Prestador e --Dbaps.Itremessa_Prestador_Equipe e
 Where Exists (Select 1
          From v_Ctas_Medicas v
         Where v.Cd_Lote In (437786, 437789)
              
           And v.Tp_Situacao_Equipe In ('NA')
              --And e.Cd_Lancamento = v.Cd_Lancamento
           And e.Cd_Remessa = v.Cd_Conta_Medica)
           
        
           
           
 Select Rowid, e.*
  From remessa_prestador e--Dbaps.Itremessa_Prestador_Equipe e
 Where Exists (Select 1
          From v_Ctas_Medicas v
         Where v.Cd_fatura = 40398
           And v.Tp_Situacao_Equipe In ('NA')
          -- And e.Cd_Lancamento = v.Cd_Lancamento
           And e.Cd_Remessa = v.Cd_Conta_Medica
           )
           
           And e.tp_situacao = 'AA'
           
           Update lote l        
           Set l.sn_fechado = 'N'
           Where l.cd_lote = 428691
           
   */
