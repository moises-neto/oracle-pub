
Declare
Begin
  For i In (Select t.Dt_Competencia,
           t.Cd_Fatura,
           t.Cd_Lote,
           t.Ds_Lote,
           t.Cd_Conta_Medica,
           t.Cd_Lancamento,
           t.Nr_Guia,
           t.Cd_Procedimento,
           t.Cd_Prestador,
           t.Cd_Prestador_Pagamento,
           t.Vl_Percentual_Cobrado,
           t.Vl_Percentual_Pago,
           (Select i.Vl_Percentual_Intercambio
              From Itremessa_Prestador i
             Where i.Cd_Remessa = t.Cd_Conta_Medica
               And i.Cd_Lancamento = t.Cd_Lancamento
               And Not Exists
             (Select 1
                      From Dbaps.Itremessa_Prestador_Fatura f
                     Where f.Cd_Remessa = t.Cd_Conta_Medica
                     And f.cd_mens_contrato Is Not Null)) As Percentual_Intercambio,
                     (Select Distinct v.nr_carteira_beneficiario From v_ctas_medicas v Where v.cd_conta_medica = t.cd_conta_medica)
      From Temp_Contas_Hosp_Acerto_V2 t
     Where  Exists (Select 1
                      From Dbaps.Itremessa_Prestador_Fatura f
                     Where f.Cd_Remessa = t.Cd_Conta_Medica
                     And f.cd_lancamento = t.cd_lancamento
                     And f.cd_mens_contrato Is Null)
                     ) Loop
  
    Begin
    
      Dbaps.Prc_Cancela_Auditoria(Ptp_Auditoria    => 'C', --P pagamento C - Cobran�a
                                  Pcd_Lote         => i.Cd_Lote,
                                  Pcd_Conta_Medica => i.Cd_Conta_Medica,
                                  Ptp_Conta        => 'A'
                                  -- Psn_Valida       =>,
                                  -- Pcd_Lancamento   =>
                                  );
    
    End;
  End Loop;
Exception
  When Others Then
    Raise_Application_Error(-20001, 'Falha: ' || Sqlerrm);
  --  Rollback;
End;

  
