
Declare

  Cursor Cdadosproc Is
    Select p.cd_procedimento
      From DBAPS.PROCEDIMENTO P 
      Where Not Exists (Select 1 From Proced_Tipo_Atendimento pt
     Where p.cd_procedimento = pt.cd_procedimento
     And  pt.Cd_Tipo_Atendimento = 12);
      
v_contador Pls_Integer := 0;

Begin

  For i In Cdadosproc Loop
  v_contador := v_contador +1; 
   Begin
      Insert Into Dbaps.Proced_Tipo_Atendimento
        (Cd_Procedimento,
         Cd_Tipo_Atendimento,
         Sn_Autorizacao,
         Sn_Guia,
         Sn_Aplica_Redutor,
         Cd_Nivel_Hierarquico,
         Sn_Visivel_Web)
      Values
        (i.Cd_Procedimento, 12, 'S', 'S', 'N', '0', 'S');
    
    End;  
    
    
    
If(v_contador = 1000) Then
  Commit;
  v_contador := 0;
  End If;
 
  End Loop;
 
Commit; 
 
Exception
  When Others Then
    Rollback;
  
    Raise_Application_Error(-20001, 'falha: ' || Sqlerrm);
  
End;

