Select rowid,
       nf.nr_nota_fiscal_nfe,
       nf.hr_emissao_nfe,
       nf.cd_verificacao_nfe,
       nf.ds_retorno_nfe,
       nf.cd_status_nfe,
       nf.cd_tipo_situacao_nota_fiscal,
       nf.*
  From dbamv.mvs_nota_fiscal nf
 Where nf.nr_id_nota_fiscal in (1759208, 1759207);
