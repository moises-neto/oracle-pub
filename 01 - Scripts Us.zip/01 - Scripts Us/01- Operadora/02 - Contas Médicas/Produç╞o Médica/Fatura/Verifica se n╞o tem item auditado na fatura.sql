Select Distinct Rp.Cd_Lote,
                Rp.Cd_Remessa,
                It.Cd_Lancamento,
                It.Cd_Procedimento,
                rp.tp_situacao,
                rp.tp_situacao_cobranca,
                it.tp_situacao,
                it.tp_situacao_cobranca
  From Dbaps.Remessa_Prestador   Rp,
       Dbaps.Itremessa_Prestador It,
       Dbaps.Lote                Lo
 Where It.Cd_Remessa = Rp.Cd_Remessa
   And Lo.Cd_Lote = Rp.Cd_Lote
   And Lo.Cd_Fatura = 36316 
 -- And rp.cd_remessa = 10883535
   And Rp.Cd_Unimed_Origem <> '018'
   And (rp.tp_situacao <> 'AA' Or rp.tp_situacao_cobranca <> 'AA')
   
   
   And Not Exists (Select 1
          From Dbaps.Itremessa_Prestador_Fatura Itf
         Where Itf.Cd_Remessa = Rp.Cd_Remessa
           And Itf.Cd_Lancamento = It.Cd_Lancamento);
           
 Select v.Cd_Fatura,
        v.Cd_Lote,
        v.Cd_Conta_Medica,
        v.Cd_Procedimento,
        v.Cd_Lancamento
   From v_Ctas_Medicas v
  Where v.Cd_Fatura = 36316
  And (V.tp_situacao = 'NA' Or v.tp_situacao_conta = 'NA' Or v.tp_situacao_itconta = 'NA') 
    /**And (v.tp_situacao = 'NA' Or v.tp_situacao_conta = 'NA' Or v.tp_situacao_itconta = 'NA'
        Or v.tp_situacao_cobranca_conta = 'NA' Or v.tp_situacao_equipe = 'NA' Or )*/
    And v.cd_unimed_origem <> '018'
  
 Union All
 
 
 Select Distinct ch.Cd_Lote,
                ch.cd_conta_hospitalar,
                ih.Cd_Lancamento,
                ih.Cd_Procedimento,
                ch.tp_situacao,
                ch.tp_situacao_cobranca,
                ih.tp_situacao,
                ih.tp_situacao_cobranca
  From Dbaps.Conta_Hospitalar   ch,
       Dbaps.Itconta_Hospitalar ih,
       Dbaps.Lote                Lo
 Where ch.cd_conta_hospitalar = ih.cd_conta_hospitalar
   And ch.Cd_Lote = lo.Cd_Lote
   And Lo.Cd_Fatura = 36316 
 -- And rp.cd_remessa = 10883535
   And ch.Cd_Unimed_Origem <> '018'
   And (ch.tp_situacao = 'NA' Or ch.tp_situacao_cobranca <> 'NA')
   
   
   And Not Exists (Select 1
          From Dbaps.Itremessa_Prestador_Fatura Itf
         Where Itf.Cd_Remessa = Rp.Cd_Remessa
           And Itf.Cd_Lancamento = It.Cd_Lancamento);
           
    
