/*
CH2111-5034 - Alterar prestador pagamento

Solicito alteração do prestador pagamento
dos seguintes atendimentos e serviços.
Não conseguimos realizar o ajuste,
pois esta vinculada com a folha de pagamento
de PJ da produção 11/2021
*/

Select fa.sn_fechado, fa.* From dbaps.fatura fa
Where fa.cd_fatura In (32535, 32550, 32551);

/*
ORA-20005: A fatura (32535) não pode ser aberta, pois existe folha de pagamento processada!
ORA-06512: em "DBAPS.TRG_FATURA", line 168
ORA-04088: erro durante a execução do gatilho 'DBAPS.TRG_FATURA'
*/

Alter Trigger DBAPS.TRG_FATURA Disable;

Update dbaps.fatura fa
Set fa.sn_fechado = 'N'
Where fa.cd_fatura In (32535, 32550, 32551);

Alter Trigger DBAPS.TRG_FATURA Enable;

Select fa.sn_fechado, fa.* From dbaps.fatura fa
Where fa.cd_fatura In (32535, 32550, 32551);