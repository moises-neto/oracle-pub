
-- Falha ao fechar Fatura Interc�mbio 30681

--- 1- Verifica se tem glosa
Select *
--CD_MOTIVO, DS_MOTIVO, SN_LIBERAVEL

  From (
        
        --CONTA AMB
        Select Rp.Cd_Lote,
                Rp.Cd_Remessa            Cd_Conta_Medica,
                Mg.Cd_Motivo,
                Mg.Ds_Motivo,
                Mg.Sn_Libera_Intercambio Sn_Liberavel
          From Dbaps.Ctamed_Amb_Erros  Cae,
                Dbaps.Remessa_Prestador Rp,
                Dbaps.Motivo_Glosa      Mg
         Where Cae.Cd_Remessa_Remessa = Rp.Cd_Remessa
           And Cae.Cd_Motivo = Mg.Cd_Motivo
           And Cae.Dt_Ocorrencia_Manual Is Null
           And Cae.Tp_Ocorrencia = 'C'
        
        Union All
        
        --ITEM AMB
        Select Rp.Cd_Lote,
                Rp.Cd_Remessa            Cd_Conta_Medica,
                Mg.Cd_Motivo,
                Mg.Ds_Motivo,
                Mg.Sn_Libera_Intercambio Sn_Liberavel
          From Dbaps.Ctamed_Amb_Erros    Cae,
                Dbaps.Remessa_Prestador   Rp,
                Dbaps.Itremessa_Prestador Irp,
                Dbaps.Motivo_Glosa        Mg
         Where Cae.Cd_Remessa_Itremaudit = Rp.Cd_Remessa
           And Rp.Cd_Remessa = Irp.Cd_Remessa
           And Cae.Cd_Lancamento_Itremaudit = Irp.Cd_Lancamento
           And Cae.Cd_Motivo = Mg.Cd_Motivo
           And Cae.Cd_Equipe_Medica_Lancmto Is Null
           And (Irp.Tp_Situacao_Cobranca Not In ('AA', 'AT') Or
               Rp.Tp_Situacao_Cobranca In ('AA', 'AT'))
           And Cae.Dt_Ocorrencia_Manual Is Null
           And Cae.Tp_Ocorrencia = 'C'
        
        Union All
        
        --FATURAMENTO AMB
        Select Rp.Cd_Lote,
                Rp.Cd_Remessa            Cd_Conta_Medica,
                Mg.Cd_Motivo,
                Mg.Ds_Motivo,
                Mg.Sn_Libera_Intercambio Sn_Liberavel
          From Dbaps.Ctamed_Amb_Erros           Cae,
                Dbaps.Remessa_Prestador          Rp,
                Dbaps.Itremessa_Prestador        Irp,
                Dbaps.Itremessa_Prestador_Fatura Irpf,
                Dbaps.Motivo_Glosa               Mg
         Where Cae.Cd_Remessa_Itremaudit = Rp.Cd_Remessa
           And Rp.Cd_Remessa = Irp.Cd_Remessa
           And Irpf.Cd_Remessa = Irp.Cd_Remessa
           And Irpf.Cd_Lancamento = Irp.Cd_Lancamento
           And Cae.Cd_Lancamento_Itremaudit = Irpf.Cd_Lancamento
           And Cae.Cd_Equipe_Medica_Lancmto = Irpf.Cd_Equipe_Medica_Lancmto
           And Cae.Cd_Motivo = Mg.Cd_Motivo
           And (Irpf.Tp_Situacao Not In ('AA', 'AT') Or
               Rp.Tp_Situacao_Cobranca In ('AA', 'AT'))
           And Cae.Dt_Ocorrencia_Manual Is Null
           And Cae.Tp_Ocorrencia = 'C'
        /*
        GROUP BY CD_LOTE,
        CD_CONTA_MEDICA,
        CD_MOTIVO,
        DS_MOTIVO,
        SN_LIBERAVEL
        ORDER BY SN_LIBERAVEL,
        CD_MOTIVO*/
        ) x
 Where Cd_Lote In
       (Select l.Cd_Lote From Dbaps.Lote l Where l.Cd_Fatura = 30681);

Select Rp.Cd_Lote,
       Rp.Cd_Remessa            Cd_Conta_Medica,
       Mg.Cd_Motivo,
       Mg.Ds_Motivo,
       Mg.Sn_Libera_Intercambio Sn_Liberavel
  From Dbaps.Ctamed_Amb_Erros           Cae,
       Dbaps.Remessa_Prestador          Rp,
       Dbaps.Itremessa_Prestador        Irp,
       Dbaps.Itremessa_Prestador_Fatura Irpf,
       Dbaps.Motivo_Glosa               Mg
 Where Cae.Cd_Remessa_Itremaudit = Rp.Cd_Remessa
   And Rp.Cd_Remessa = Irp.Cd_Remessa
   And Irpf.Cd_Remessa = Irp.Cd_Remessa
   And Irpf.Cd_Lancamento = Irp.Cd_Lancamento
   And Cae.Cd_Lancamento_Itremaudit = Irpf.Cd_Lancamento
   And Cae.Cd_Equipe_Medica_Lancmto = Irpf.Cd_Equipe_Medica_Lancmto
   And Cae.Cd_Motivo = Mg.Cd_Motivo
   And (Irpf.Tp_Situacao Not In ('AA', 'AT') Or
       Rp.Tp_Situacao_Cobranca In ('AA', 'AT'))
   And Cae.Dt_Ocorrencia_Manual Is Null
   And Cae.Tp_Ocorrencia = 'C'
   And Rp.Cd_Lote In
       (Select l.Cd_Lote From Dbaps.Lote l Where l.Cd_Fatura = 30681);

-- Verifica se valorizou interc�mbio para SADT
Select Distinct Rp.Cd_Lote,
                Rp.Cd_Remessa,
                It.Cd_Lancamento,
                It.Cd_Procedimento
  From Dbaps.Remessa_Prestador   Rp,
       Dbaps.Itremessa_Prestador It,
       Dbaps.Lote                Lo
 Where It.Cd_Remessa = Rp.Cd_Remessa
   And Lo.Cd_Lote = Rp.Cd_Lote
   And Lo.Cd_Fatura = 30681
   And Rp.Cd_Unimed_Origem <> '018'
   And Not Exists (Select 1
          From Dbaps.Itremessa_Prestador_Fatura Itf
         Where Itf.Cd_Remessa = Rp.Cd_Remessa
           And Itf.Cd_Lancamento = It.Cd_Lancamento);

-- Verifica se valorizou interc�mbio para INTERNA��O
Select Distinct Ch.Cd_Lote,
                Ch.Cd_Conta_Hospitalar,
                It.Cd_Lancamento,
                It.Cd_Procedimento
  From Dbaps.Conta_Hospitalar   Ch,
       Dbaps.Itconta_Hospitalar It,
       Dbaps.Lote               Lo
 Where Lo.Cd_Lote = Ch.Cd_Lote
   And It.Cd_Conta_Hospitalar = Ch.Cd_Conta_Hospitalar
   And Lo.Cd_Fatura = 30681
   And Ch.Cd_Unimed_Origem <> '018'
   And Not Exists
 (Select 1
          From Dbaps.Itconta_Hospitalar_Fatura Icf
         Where Icf.Cd_Conta_Hospitalar = Ch.Cd_Conta_Hospitalar
           And Icf.Cd_Lancamento = It.Cd_Lancamento);

Select Fa.Sn_Fechado_Cobranca, Fa.*
  From Dbaps.Fatura Fa
 Where Fa.Cd_Fatura = 30681;
