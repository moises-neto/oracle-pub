Select 1
  From Dbaps.v_Ctas_Medicas_Fatura Vcmf
 Where Vcmf.Cd_Multi_Empresa = Dbamv.Pkg_Mv2000.Le_Empresa
   And (Vcmf.Tp_Situacao_Conta In ('NA', 'GA') Or
       Vcmf.Tp_Situacao_Itconta In ('NA', 'GA') Or
       Vcmf.Tp_Situacao_Equipe In ('NA', 'GA'))
   And Vcmf.Tp_Fatura = 'P'
   And Vcmf.Cd_Fatura = 36316;

Select 1
  From (Select 1
          From Dbaps.Remessa_Prestador   Rp,
               Dbaps.Itremessa_Prestador Irp,
               Dbaps.Lote                l
         Where Rp.Cd_Lote = l.Cd_Lote
           And Rp.Cd_Remessa = Irp.Cd_Remessa
           And l.Tp_Lote = 'P'
           And Rp.Tp_Beneficiario In ('EV', 'RC', 'RE')
         And Irp.Tp_Pagcob In ('CP', 'CN')
          And Irp.Tp_Situacao Not In ('GT')
           And l.Cd_Fatura = 36316
           And Not Exists
         (Select 1
                  From Dbaps.Itremessa_Prestador_Fatura Irpf
                 Where Irpf.Cd_Remessa = Irp.Cd_Remessa
                   And Irpf.Cd_Lancamento = Irp.Cd_Lancamento)
        Union All
        Select 1
          From Dbaps.Conta_Hospitalar   Ch,
               Dbaps.Itconta_Hospitalar Ich,
               Dbaps.Lote               l
         Where Ch.Cd_Lote = l.Cd_Lote
           And Ch.Cd_Conta_Hospitalar = Ich.Cd_Conta_Hospitalar
          And l.Tp_Lote = 'P'
           And Ch.Tp_Beneficiario In ('EV', 'RC', 'RE')
           And Ich.Tp_Pagcob In ('CP', 'CN')
           And Ich.Tp_Situacao Not In ('GT')
           And l.Cd_Fatura = 36316
           And Not Exists
         (Select 1
                  From Dbaps.Itconta_Hospitalar_Fatura Ichf
                 Where Ichf.Cd_Conta_Hospitalar = Ich.Cd_Conta_Hospitalar
                   And Ichf.Cd_Lancamento = Ich.Cd_Lancamento)
 
 
