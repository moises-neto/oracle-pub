/*
pagamento
*/

Select Rowid,
       Ie.Cd_Remessa,
       Ie.Nm_Prestador,
       Ie.Nm_Prestador_Externo,
       Ie.Cd_Prestador_Ptu,
       (Select p.Cd_Prestador
          From Dbaps.Prestador p
         Where p.Ds_Cod_Conselho = Ie.Ds_Cod_Conselho) As Prestador
  From Dbaps.Itremessa_Prestador_Equipe Ie
 Where Ie.Cd_Lancamento In (Select Rp.Cd_Lancamento
                              From Itremessa_Prestador Rp
                            
                             Where Rp.Cd_Lancamento = Ie.Cd_Lancamento
                               And Rp.Cd_Remessa = Ie.Cd_Remessa
                               And Rp.Cd_Remessa
                                  
                                   In (11776774,
                                       11776789,
                                       11776791,
                                       11776741,
                                       11776745,
                                       11776747,
                                       11776754,
                                       11776782,
                                       11776805,
                                       11776806,
                                       11776836,
                                       11776858,
                                       11776910,
                                       11776940,
                                       11776959,
                                       11776978,
                                       11776981,
                                       11777005,
                                       11777010,
                                       11777031,
                                       11777038,
                                       11777048,
                                       11777075,
                                       11777099,
                                       11777131,
                                       11777166,
                                       11777161,
                                       11777153,
                                       11777160,
                                       11777163,
                                       11777167,
                                       11777169,
                                       11777171,
                                       11777186,
                                       11777203,
                                       11777212,
                                       11777216,
                                       11777250,
                                       11777241,
                                       11777258,
                                       11777262,
                                       11777265,
                                       11777275,
                                       11777284,
                                       11777289,
                                       11777305,
                                       11777323,
                                       11777350,
                                       11777382,
                                       11777389,
                                       11777374,
                                       11777399,
                                       11777447,
                                       11779495,
                                       11779497,
                                       11780778,
                                       11773296
                                       
                                       )
                               And Rp.Cd_Procedimento = 10101039
                            
                            )


/*Cobran�a*/

Select Rowid,
       Ie.Cd_Remessa,
       Ie.Nm_Prestador,
       Ie.Nm_Prestador_Externo,
       Ie.Cd_Prestador_Ptu,
       (Select p.Cd_Prestador
          From Dbaps.Prestador p, itremessa_prestador_equipe iqe
          
         Where ie.cd_remessa = iqe.cd_remessa
         And iqe.cd_lancamento = ie.cd_lancamento 
         And p.Ds_Cod_Conselho = iqe.ds_cod_conselho) As Prestador
  From Dbaps.Itremessa_Prestador_Fatura Ie
 Where Ie.Cd_Lancamento In (Select Rp.Cd_Lancamento
                              From Itremessa_Prestador Rp
                            
                             Where Rp.Cd_Lancamento = Ie.Cd_Lancamento
                               And Rp.Cd_Remessa = Ie.Cd_Remessa
                               And Rp.Cd_Remessa
                                  
                                   In (11776774,
                                       11776789,
                                       11776791,
                                       11776741,
                                       11776745,
                                       11776747,
                                       11776754,
                                       11776782,
                                       11776805,
                                       11776806,
                                       11776836,
                                       11776858,
                                       11776910,
                                       11776940,
                                       11776959,
                                       11776978,
                                       11776981,
                                       11777005,
                                       11777010,
                                       11777031,
                                       11777038,
                                       11777048,
                                       11777075,
                                       11777099,
                                       11777131,
                                       11777166,
                                       11777161,
                                       11777153,
                                       11777160,
                                       11777163,
                                       11777167,
                                       11777169,
                                       11777171,
                                       11777186,
                                       11777203,
                                       11777212,
                                       11777216,
                                       11777250,
                                       11777241,
                                       11777258,
                                       11777262,
                                       11777265,
                                       11777275,
                                       11777284,
                                       11777289,
                                       11777305,
                                       11777323,
                                       11777350,
                                       11777382,
                                       11777389,
                                       11777374,
                                       11777399,
                                       11777447,
                                       11779495,
                                       11779497,
                                       11780778,
                                       11773296
                                       
                                       )
                               And Rp.Cd_Procedimento = 10101039
                            
                            )
