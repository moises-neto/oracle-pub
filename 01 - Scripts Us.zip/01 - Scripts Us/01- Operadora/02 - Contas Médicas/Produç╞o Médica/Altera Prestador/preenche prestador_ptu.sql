/*
preencher o c�digo 10109900 e 10101039 >>>> com os dados 
Nome: LAUREANE FERREIRA SILVA
CPF: 404.527.618-16
NR conselho: 176973
Conselho:06 
UF COnselho: 35

Preencher campo PREST PTU (aba pagamento e aba cobran�a) com o 1000935
*/
Declare

Begin
  For i In (Select Distinct v.Cd_Conta_Medica,
                            v.Cd_Lancamento,
                            1000935 As Cd_Prestador_Ptu_New
              From Dbaps.v_Ctas_Medicas v
             Where v.Cd_Lote In (437655,437656)
               And v.Cd_Procedimento In (10109900, 10101039)
               And v.Cd_Unimed_Origem <> 018) Loop
  
    Begin
      --pagamento
    
      Update Dbaps.Itremessa_Prestador_Equipe e
         Set e.Cd_Prestador_Ptu = 1000935
       Where e.Cd_Remessa = i.Cd_Conta_Medica
         And e.Cd_Lancamento = i.Cd_Lancamento
         And e.Cd_Prestador_Ptu Is Null;
    
      --Cobran�a
    
      Update Dbaps.Itremessa_Prestador_Fatura f
         Set f.Cd_Prestador_Ptu = 1000935
       Where f.Cd_Remessa = i.Cd_Conta_Medica
         And f.Cd_Lancamento = i.Cd_Lancamento
         And f.Cd_Prestador_Ptu Is Null;
    
      Dbms_Output.Put_Line('Conta alterada: ' || i.Cd_Conta_Medica ||
                           '  Lancamento: ' || i.Cd_Lancamento);
    
    End;
  End Loop;

Exception
  When Others Then
    Rollback;
    Raise_Application_Error(-20001, 'Falha: ' || Sqlerrm);
  
End;
