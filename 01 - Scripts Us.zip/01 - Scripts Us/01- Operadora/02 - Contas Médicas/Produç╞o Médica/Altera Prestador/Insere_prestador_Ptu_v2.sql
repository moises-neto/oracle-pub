Begin
  If (2 = 2) Then
    For i In (Select Rp.Cd_Lote,
                     Ip.Cd_Remessa,
                     Ip.Cd_Lancamento,
                     Ip.Cd_Prestador,
                     Ip.Cd_Prestador_Ptu As Cd_Prest_Pag,
                     Ip.Cd_Prestador     As Cd_Prestador_Ptu_New,
                     Ip.Cd_Prestador     As Prestador_Executante
              
                From Dbaps.Itremessa_Prestador_Equipe Ip,
                     Dbaps.Remessa_Prestador          Rp,
                     Itremessa_Prestador              It
              
               Where Rp.Cd_Remessa = Ip.Cd_Remessa
                 And Ip.Cd_Remessa = It.Cd_Remessa
                 And It.Cd_Lancamento = Ip.Cd_Lancamento
                 And Ip.Cd_Prestador_Ptu Is Null
                    
                 And Nvl(It.Cd_Procedimento, It.Cd_Proc_Digita) In
                     ('31602231',
                      '31602240',
                      '31602266',
                      '31602347',
                      '30101794',
                      '30711029',
                      '30711037')
                 And Exists
               (Select 1
                        From v_Ctas_Medicas v
                       Where v.Cd_Fatura In (44164, 43602)
                         And v.Cd_Conta_Medica = Ip.Cd_Remessa
                         And v.Cd_Lancamento = Ip.Cd_Lancamento)) Loop
    
      Begin
        --Pagamento sadt
        Update Dbaps.Itremessa_Prestador_Equipe Ie
           Set Ie.Cd_Prestador_Ptu = i.Cd_Prestador_Ptu_New
         Where Ie.Cd_Remessa = i.Cd_Remessa
           And Ie.Cd_Lancamento = i.Cd_Lancamento
           And Ie.Cd_Prestador_Ptu Is Null;
      
        --Cobran�a sadt
        Update Dbaps.Itremessa_Prestador_Fatura Ifa
           Set Ifa.Cd_Prestador_Ptu = i.Cd_Prestador_Ptu_New
         Where Ifa.Cd_Remessa = i.Cd_Remessa
           And Ifa.Cd_Lancamento = i.Cd_Lancamento
           And Ifa.Cd_Prestador_Ptu Is Null;
      
      End;
      Dbms_Output.Put_Line('Conta: ' || i.Cd_Remessa);
    End Loop;
  End If;
Exception
  When Others Then
    Rollback;
    Raise_Application_Error(-20001, 'Falha: ' || Sqlerrm);
End;
