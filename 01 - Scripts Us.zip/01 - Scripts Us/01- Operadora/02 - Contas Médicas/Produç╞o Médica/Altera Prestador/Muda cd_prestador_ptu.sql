/*Create Table temp_Acerto_Pag_300100_v2 As Select v.Tp_Conta,
                   v.Cd_Fatura,
                   v.Cd_Lote,
                   v.Cd_Conta_Medica,
                   v.Cd_Procedimento,
                   v.Cd_Lancamento,
                   v.Vl_Total_Pago,
                   v.Tp_Pagcob,
                   v.Tp_Situacao_Conta,
                   v.Tp_Situacao_Itconta,
                   v.Cd_Motivo,
                   v.Cd_Motivo_Alta,
                   v.Cd_Motivo_Conta,
                   v.Cd_Motivo_Itconta,
                   v.Cd_Motivo_Equipe,
                   v.Cd_Prestador,
                   (Select p.Nm_Prestador
                      From Dbaps.Prestador p
                     Where p.Cd_Prestador = v.Cd_Prestador) As Nm_Prestador,
                   (Select Distinct Vf.Cd_Mens_Contrato
                      From Dbaps.v_Ctas_Medicas_Fatura Vf
                     Where Vf.Cd_Lote = v.Cd_Lote
                       And Vf.Cd_Conta_Medica = v.Cd_Conta_Medica
                       And Vf.Cd_Lancamento = v.Cd_Lancamento
                          
                       And Rownum = 1) As Mens_Contrato,
                   v.Cd_Repasse_Prestador,
                   v.Cd_Prestador_Pagamento
            
              From v_Ctas_Medicas v
             Where v.Dt_Competencia = '202212'
               And v.Cd_Prestador_Principal = 300100
               And v.Cd_Prestador_Pagamento <> 300100
               And v.Cd_Procedimento In ('30711029',
'30720109',
'30712092',
'30711037',
'30717094',
'30727146',
'30729165',
'30729114');*/

Begin
  For i In (Select * From temp_Acerto_Pag_300100_v2) Loop
  
    If (i.Tp_Conta = 'A') Then
      Update Dbaps.Itremessa_Prestador_Equipe Ie
         Set Ie.Cd_Prestador_Pagamento = 300100
       Where Ie.Cd_Remessa = i.Cd_Conta_Medica
         And Ie.Cd_Lancamento = i.Cd_Lancamento;
    
    Else
      Update Dbaps.Itconta_Med Im
         Set Im.Cd_Prestador_Pagamento = 300100
       Where Im.Cd_Conta_Hospitalar = i.Cd_Conta_Medica
         And Im.Cd_Lancamento = i.Cd_Lancamento;
    
    End If;
  
    Dbms_Output.Put_Line('CONTA: ' || i.Cd_Conta_Medica || ' LAN�AMENTO: ' ||
                         i.Cd_Lancamento);
  
  End Loop;

End;    
         

/*      
Create Table Temp_Acerto_Pag_300100_cob_v2  As
       Select *
         From Temp_Acerto_Pag_300100_V2 v
        Where Exists (Select 1
                 From Dbaps.v_Ctas_Medicas_Fatura f
                Where f.Cd_Conta_Medica = v.Cd_Conta_Medica
                  And f.Cd_Lancamento = v.Cd_Lancamento);*/
 
/  
Alter Trigger DBAPS.trg_itremessa_prestador_fatura Disable;
Alter Trigger DBAPS.TRG_ITCONTA_HOSPITALAR_FATURA Disable;

Begin
  For i In (Select * From AJUSTE_PRESTADOR_PTU) Loop
  
    Begin
      --If (i.Tp_Conta = 'A') Then
        Update Itremessa_Prestador_Fatura f
           Set f.Cd_Prestador_Ptu = i.Cd_Prestador_ptu_new
         Where f.Cd_Remessa = i.Cd_Conta_Medica
           And f.Cd_Lancamento = i.Cd_Lancamento;
      
      /*Else
        Update Itconta_Hospitalar_Fatura f
           Set f.Cd_Prestador_Ptu = i.Cd_Prestador
         Where f.Cd_Conta_Hospitalar = i.Cd_Conta_Medica
           And f.Cd_Lancamento = i.Cd_Lancamento;
      
      End If;*/
    
    End;
    Dbms_Output.Put_Line('CONTA: ' || i.Cd_Conta_Medica || ' LAN�AMENTO: ' ||
                         i.Cd_Lancamento);
   
  End Loop;

End;

Alter Trigger DBAPS.trg_itremessa_prestador_fatura Enable;
Alter Trigger DBAPS.TRG_ITCONTA_HOSPITALAR_FATURA Enable;



Create Table AJUSTE_PRESTADOR_PTU

(CD_CONTA_MEDICA NUMBER,
CD_LANCAMENTO NUMBER,
CD_PRESTADOR_PTU_NEW Number)


Select A.*, Rowid From AJUSTE_PRESTADOR_PTU A





