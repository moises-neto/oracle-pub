Declare

Begin
  For i In (Select Distinct v.Cd_Conta_Medica,
                            (Select g.Cd_Prestador
                               From Dbaps.Guia g
                              Where g.Nr_Guia = v.Nr_Guia) As Prest_Guia_New,
                            v.Cd_Prestador_Solicitante As Guia_Old
              From Dbaps.v_Ctas_Medicas v
             Where v.Cd_Lote = 513912
               And Cd_Prestador_Solicitante Is Null) Loop
  
    Begin
            Update dbaps.remessa_prestador rp
            Set rp.cd_prestador_solicitante = i.prest_guia_new
            Where rp.cd_remessa = i.cd_conta_medica;
            
    End;
       dbms_output.put_line('Conta: ' || i.cd_conta_medica || ' Prestador Novo: ' || i.prest_guia_new );
  End Loop;

End;
