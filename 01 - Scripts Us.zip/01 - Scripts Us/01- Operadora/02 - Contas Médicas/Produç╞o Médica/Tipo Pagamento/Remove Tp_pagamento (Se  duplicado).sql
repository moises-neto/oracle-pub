Declare

  Cursor Cdados Is
  
    Select *
      From (Select --Count(v.Tp_Pagamento),
             Row_Number() Over(Partition By v.Cd_Conta_Medica, v.Cd_Lote, v.Cd_Lancamento, v.Vl_Unit_Pago, p.nm_prestador Order By v.Cd_Conta_Medica, v.Cd_Lote, v.Cd_Lancamento, v.Vl_Unit_Pago, p.nm_prestador) Contar,
             v.Tp_Conta,
             v.Cd_Conta_Medica,
             v.Cd_Lote,
             v.Cd_Lancamento,
             v.Cd_Prestador_Pagamento,
             v.cd_protocolo_ctamed,
             v.dt_apresentacao,
             (Select p.Nm_Prestador
                From Dbaps.Prestador p
               Where p.Cd_Prestador = v.Cd_Prestador_Pagamento) As Prestador,
             v.Vl_Unit_Pago,
             v.Cd_Lancamento_Equipe,
              v.cd_prestador
              From v_Ctas_Medicas v, dbaps.prestador p
            
             Where v.cd_prestador = p.cd_prestador 
             And v.Dt_Competencia = to_char(Sysdate,'YYYYMM')
                  --And v.cd_conta_medica In(12516729,12527835)
               And v.Tp_Pagamento = 'HM'
               And v.Tp_Fatura = 'P'
               And v.Tp_Situacao_Conta In ('AA', 'AT')
               And v.Tp_Situacao_Itconta In ('AA', 'AT')
               And v.Tp_Situacao_Equipe In ('AA', 'AT')
               And v.Tp_Pagcob In ('CP', 'PN')
               And v.Cd_Prestador_Pagamento Is Not Null
            --And v.cd_lancamento_equipe <>1
            --And v.cd_procedimento = '50000083'
            ) x
    
     Where x.Contar > 1
     Order By 1, 2, 4, 8;

Begin
  For i In Cdados Loop
    Begin
      
      Delete From Itremessa_Prestador_Equipe Eq
       Where Eq.Cd_Remessa = i.Cd_Conta_Medica
         And Eq.Cd_Lancamento = i.Cd_Lancamento
         And Eq.Cd_Equipe_Medica_Lancmto = i.Cd_Lancamento_Equipe
         And Eq.Tp_Pagamento = 'HM'; 
         dbms_output.put_line('Conta: '|| i.Cd_Conta_Medica || ' Lancamento: ' || i.Cd_Lancamento);
    
    End;
  End Loop;

End;
