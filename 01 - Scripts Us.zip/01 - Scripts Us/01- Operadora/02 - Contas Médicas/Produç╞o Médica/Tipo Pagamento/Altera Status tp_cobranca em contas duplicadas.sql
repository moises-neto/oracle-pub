
Declare
  -- Cursor Ccontasduplicadas Is
  /* Select Distinct 'I' As TP_CONTA,
                  t.Periodo,
                  t.Nrguia,
                  t.Cd_Lote,
                  t.Cd_Conta_Medica,
                  Custom.f_Retorna_Ctas_Html(t.Cd_Conta_Medica) Atual,
                  t.Periodo_Conta_Ja_Apresentada,
                  t.Cd_Lote_Ja_Apresentada,
                  t.Cd_Conta_Ja_Apresentada Conta_Ja_Apresentada,
                  Custom.f_Retorna_Ctas_Html(t.Cd_Conta_Ja_Apresentada) Anterior
    From Custom.Analise_Ctas_Custom t
   Where t.Periodo = '202206'
        
     And Exists (Select 1
            From Dbaps.Conta_Hospitalar c
           Where t.Cd_Conta_Medica = c.Cd_Conta_Hospitalar)
     And Exists
   (Select 1
            From Dbaps.Conta_Hospitalar c
           Where t.Cd_Conta_Ja_Apresentada = c.Cd_Conta_Hospitalar)
  
  Union*/

  /*  Select Distinct 'A' As Tp_Conta,
                 t.Periodo,
                 t.Nrguia,
                 t.Cd_Lote,
                 t.Cd_Conta_Medica,
                 Custom.f_Retorna_Ctas_Html(t.Cd_Conta_Medica) Atual,
                 t.Periodo_Conta_Ja_Apresentada,
                 t.Cd_Lote_Ja_Apresentada,
                 t.Cd_Conta_Ja_Apresentada Conta_Ja_Apresentada,
                 Custom.f_Retorna_Ctas_Html(t.Cd_Conta_Ja_Apresentada) Anterior
   From Custom.Analise_Ctas_Custom t
  Where t.Periodo = '202206'
       
    And Exists (Select 1
           From Dbaps.Remessa_Prestador r
          Where t.Cd_Conta_Medica = r.Cd_Remessa)
       
    And Exists (Select 1
           From Dbaps.Remessa_Prestador r
          Where t.Cd_Conta_Ja_Apresentada = r.Cd_Remessa)
       
    And t.Cd_Conta_Medica = 11900258;*/

  --- Vcontasduplicadas Ccontasduplicadas%Rowtype;

  Vcontador Pls_Integer := 0;
Begin

  For i In ( /*Select Distinct 'A' As Tp_Conta,
                                                    (Select Distinct f.Cd_Fatura
                                                       From Dbaps.Fatura f, Dbaps.Lote l
                                                      Where f.Cd_Fatura = l.Cd_Fatura
                                                        And l.Cd_Lote = t.Cd_Lote) As Fatura,
                                                    t.Periodo,
                                                    t.Nrguia,
                                                    t.Cd_Lote,
                                                    t.Cd_Conta_Medica,
                                                    Custom.f_Retorna_Ctas_Html(t.Cd_Conta_Medica) Atual,
                                                    t.Periodo_Conta_Ja_Apresentada,
                                                    t.Cd_Lote_Ja_Apresentada,
                                                    t.Cd_Conta_Ja_Apresentada Conta_Ja_Apresentada,
                                                    Custom.f_Retorna_Ctas_Html(t.Cd_Conta_Ja_Apresentada) Anterior
                                      From Custom.Analise_Ctas_Custom t
                                     Where t.Periodo = '202206'
                                          
                                       And Exists (Select 1
                                              From Dbaps.Fatura         f,
                                                   Dbaps.Lote           l,
                                                   Dbaps.v_Ctas_Medicas v
                                             Where l.Cd_Lote = t.Cd_Lote
                                               And f.Cd_Fatura = l.Cd_Fatura
                                               And v.Cd_Conta_Medica = t.Cd_Conta_Medica
                                               And f.Sn_Fechado = 'N'
                                                  
                                               And Dbaps.Fnc_Mvs_Mvto_Despesas(Pdt_Competencia => Null,
                                                                               Pcd_Fatura      => f.Cd_Fatura,
                                                                               Pcd_Prestador   => v.Cd_Prestador_Pagamento) = 'OK')
                                          
                                       And Exists
                                     (Select 1
                                              From Dbaps.Remessa_Prestador r, Itremessa_Prestador Ip
                                             Where t.Cd_Conta_Medica = r.Cd_Remessa
                                               And r.Cd_Remessa = Ip.Cd_Remessa
                                               And Ip.Tp_Pagcob <> 'NN')
                                          
                                       And Exists
                                     (Select 1
                                              From Dbaps.Remessa_Prestador r, Itremessa_Prestador Ip
                                             Where t.Cd_Conta_Ja_Apresentada = r.Cd_Remessa
                                               And r.Cd_Remessa = Ip.Cd_Remessa
                                               And Ip.Tp_Pagcob <> 'NN')*/
            
            
Select Rp.Cd_Lote,
       Rp.Nr_Guia,
       Rp.Nr_Guia_Prestador,
       Rp.Cd_Remessa As Conta,
       Ip.Cd_Procedimento,
       ip.cd_lancamento,
       Ip.Dt_Realizado,
       Ip.Tp_Pagcob,
       ip.Rowid,
       'NN' As Tp_Pagcob_New

  From Dbaps.Remessa_Prestador   Rp,
       Fatura                    f,
       Lote                      l,
       Dbaps.Itremessa_Prestador Ip
 Where Rp.Cd_Lote = l.Cd_Lote
   And f.Cd_Fatura = l.Cd_Fatura
   And Rp.Cd_Remessa = Ip.Cd_Remessa
   And f.Nr_Ano || f.Nr_Mes = '202206'
   And Ip.Tp_Pagcob <> 'NN'
   And Exists (Select 1
          From Dbaps.Ctamed_Amb_Erros Ca
         Where Ca.Cd_Remessa_Itremaudit = Rp.Cd_Remessa
           And Ca.Cd_Motivo In (9002, 9609)
           And Ca.Cd_Usuario_Liberacao Is Null)
      
   And Not Exists
 (Select 1 From Temp_Moises_Dupl_2 t Where t.Cd_Conta = Rp.Cd_Remessa) 
 
 And rp.cd_remessa Not In (11932419,11932418)
  
 
 

            
            ) Loop
    Begin
      Vcontador := Vcontador + 1;
      Update Dbaps.Itremessa_Prestador Ip
         Set Ip.Tp_Pagcob = 'NN'
       Where Ip.Cd_Remessa = i.Conta
         And Ip.Cd_Lancamento = i.Cd_Lancamento
         And Ip.Tp_Pagcob In ('CP')
         ;
    
      Dbms_Output.Put_Line('Conta: ' || i.conta || ' CD_LANCAMENTO: ' ||
                           i.Cd_Lancamento);
      /*  If (Vcontador >= 100) Then
          Commit;
        End If;
      */
    Exception
      When Others Then
        Raise_Application_Error(-20001,
                                ' Falha N�o tratada --> ' || Sqlerrm);
    End;
  
  End Loop;

Exception
  When Others Then
    Raise_Application_Error(-20001, ' Falha N�o tratada --> ' || Sqlerrm);
  
End;
