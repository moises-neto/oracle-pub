Declare
  Cursor Cdadoscontahospitalar Is
    Select Distinct v.Cd_Conta_Medica, v.Tp_Conta
      From v_Ctas_Medicas v
     Where v.Cd_Fatura In (36465, 36464, 36746, 36747)
       And v.Tp_Pagcob <> 'NN';

Begin
  For i In Cdadoscontahospitalar Loop
  
    Begin
      If (i.Tp_Conta = 'A') Then
        Update Itremessa_Prestador Ip
           Set Ip.Tp_Pagcob = 'NN'
         Where Ip.Cd_Remessa = i.Cd_Conta_Medica;
      
      Else
        Update Itconta_Hospitalar Ih
           Set Ih.Tp_Pagcob = 'NN'
         Where Ih.Cd_Conta_Hospitalar = i.Cd_Conta_Medica;
      
      End If;
      End;
      End Loop;
      
      If (Cdadoscontahospitalar%Isopen) Then
        Close Cdadoscontahospitalar;
      End If;
    
    End;
/    
    Select ih.tp_pagcob From Itconta_Hospitalar Ih
    Where ih.cd_conta_hospitalar = 123726;
    
    Select ip.tp_pagcob From itremessa_prestador ip
    Where ip.cd_remessa = 10882950
