/*
CH2106-4877 - Liberar Trava Portal TISS 
Favor abrir o Portal TISS para o prestador 1001153,
enviar arquivos XML UTI Covid.
*/


1- Abrir a trigger trg_portal_block
2- Incluir o c�digo do prestador que deve ser liberado

