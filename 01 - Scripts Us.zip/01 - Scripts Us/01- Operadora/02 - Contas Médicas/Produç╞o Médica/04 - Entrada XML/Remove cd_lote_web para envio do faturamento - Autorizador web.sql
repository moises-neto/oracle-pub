Select g.*, Rowid From dbaps.guia g
Where g.nr_guia = 101225609;
        485990
--485990

Select it.*, Rowid From itguia it
Where it.nr_guia = 104538189;
--43721

Select Ite.*, Rowid
  From Itguia_Execucao Ite
 Where Exists (Select 1
          From Dbaps.Itguia It
         Where It.Nr_Guia = 104538189
           And Ite.Cd_Itguia = It.Cd_Itguia);

Select * From lote_guia_web w
Where w.cd_lote_guia_web = 47639;
                                                                      
Begin
  For i In (Select Ie.Cd_Itguia_Execucao, Ie.Cd_Lote_Guia_Web
              From Dbaps.Itguia          It,
                   Dbaps.Lote_Guia_Web   Lgw,
                   Dbaps.Itguia_Execucao Ie
             Where Ie.Cd_Lote_Guia_Web = Lgw.Cd_Lote_Guia_Web
               /*And Lgw.Cd_Protocolo_Ctamed In
                   (593675)*/
                   And Exists(Select 1 From protocolo_ctamed pc Where pc.cd_protocolo_ctamed = lgw.cd_protocolo_ctamed And pc.cd_status_protocolo = 4
                   And Trunc(pc.dt_inclusao) Between '16/11/2022' And '15/12/2022' )
                   And ie.cd_lote_guia_web Is Not Null
               And It.Cd_Itguia = Ie.Cd_Itguia) Loop
    Begin
      Update Dbaps.Itguia_Execucao Ie
         Set Ie.Cd_Lote_Guia_Web = Null
       Where Ie.Cd_Itguia_Execucao = i.Cd_Itguia_Execucao
         And Ie.Cd_Lote_Guia_Web = i.Cd_Lote_Guia_Web;
    End;
    Dbms_Output.Put_Line('cd_itguia: ' || i.Cd_Itguia_Execucao || ' cd_lote ' ||
                         i.Cd_Lote_Guia_Web);
  
  End Loop;
End;
