Select Tm.Ds_Xml, Tm.*
  From Dbaps.Protocolo_Ctamed Pc, Dbaps.Tiss_Lot_Guia Tlg, Tiss_Mensagem Tm

 Where 1 = 1
   And Pc.Id_Tisslotguia = Tlg.Id
   And Tlg.Id_Pai = Tm.Id
   And Pc.Cd_Protocolo_Ctamed = 699198 ;
   
  
