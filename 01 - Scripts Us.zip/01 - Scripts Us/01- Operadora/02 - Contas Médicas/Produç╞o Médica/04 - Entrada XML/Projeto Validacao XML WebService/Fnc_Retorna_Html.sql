Create Or Replace Function Custom.Fnc_Retorna_Html(Pcd_Protocolo In Number)
/*
  Desenvolvedor: Mois�s de Souza
  Data: 03/05/2022
  Objetivo: Retornar o conteudo de erro e transformar em HTML para envio de e-mail da rotina (Prc_Valida_Prot_Tiss_Tes_Hosp).
  */

 Return Clob Is

  Cursor Cdadoshtml Is
  
    Select Distinct Lt.Cd_Protocolo_Ctamed      As Protocolo,
                    Lt.Ds_Carteira_Beneficiario As Carteira,
                    Pc.Nr_Lote_Prestador        As Lote,
                    Vg.Nr_Senha_Autorizacao     As Guia,
                    Vg.Nr_Guia_Operadora        As Nr_Guia_Operadora,
                    Lt.Ds_Erro                  As Erro
      From Custom.Tiss_Controle_Protocolo Tc,
           Dbaps.Log_Erro_Protocolo_Tiss  Lt,
           Dbaps.Protocolo_Ctamed         Pc,
           Dbaps.v_Tiss_Lote_Guia         Vg
     Where Tc.Cd_Protocolo_Ctamed = Pcd_Protocolo
       And Lt.Cd_Protocolo_Ctamed = Tc.Cd_Protocolo_Ctamed
       And Pc.Cd_Protocolo_Ctamed = Tc.Cd_Protocolo_Ctamed
       And Vg.Cd_Protocolo_Ctamed = Pc.Cd_Protocolo_Ctamed
       And Tc.Sn_Validado = 'S'
       And Lt.Cd_Erro <> 'E999';

  Vcorpo_Email Clob := '';

  Vcabecalho Varchar2(500) := '';

  Vtable Clob := '';

  Vlinhas Clob := '';

  Vlinhasfull Clob := '';

  Vemail Clob := '';

  -- Vdados Number;

Begin

  For i In Cdadoshtml Loop
  
    Vlinhas := '<tr>
            <td style="text-align: center;">' || i.Protocolo ||
               '</td>
            <td style="text-align: center;">' || i.Carteira ||
               '</td>
            <td style="text-align: center;">' || i.Lote ||
               '</td>
            <td style="text-align: center;">' || i.Guia ||
               '</td> 
                </td>
            <td style="text-align: center;">' ||
               i.Nr_Guia_Operadora ||
               '</td>
            <td style="text-align: center;">' || i.Erro ||
               '</td>
        </tr>
        ';
  
    Vlinhasfull := Vlinhasfull || Vlinhas;
  
  End Loop;
  If (Cdadoshtml%Isopen) Then
    Close Cdadoshtml;
  End If;

  Vcabecalho := '<p>
   <div style=" background-color: rgb(125, 211, 125);">
       <h2 style="font-size: 25px; text-align: center; padding-right: 1500px;"> Protocolo Rejeitado </h2>
    </div>
</p>';

  Vtable := '<p> <table border="2" style="margin-left: 15px; width: 1200px;" >

        <tr>
            <th style="background: rgb(138, 223, 159);">Protocolo</th>
            <th style="background: rgb(138, 223, 159);">Carteira</th>
            <th style="background: rgb(138, 223, 159);">Lote</th>
            <th style="background: rgb(138, 223, 159);">Guia</th> 
            <th style="background: rgb(138, 223, 159);">Nr Guia Operadora</th>
            <th style="background: rgb(138, 223, 159);">Motivo</th>

        </tr>
        </p>';

  Vcorpo_Email := Vtable || Vlinhasfull;

  Vemail := Vcabecalho || Vcorpo_Email;

  Return Vemail;

End Fnc_Retorna_Html;
/
