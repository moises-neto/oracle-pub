Create Or Replace Procedure Custom.Prc_Validacao_Xml_Hospital Is

  /*
  Desenvolvedor: Mois�s de Souza
  Data: 03/05/2022
  Objetivo: chamar a procedure Prc_Valida_Prot_Tiss_Tes_Hosp para execu��o via job (6643)
  */

  Cursor Cdadosprotocolo Is
    Select Tp.Cd_Protocolo_Ctamed
      From Custom.Tiss_Controle_Protocolo Tp, Dbaps.Protocolo_Ctamed Pc
     Where Tp.Cd_Protocolo_Ctamed = Pc.Cd_Protocolo_Ctamed
       And Pc.Cd_Status_Protocolo <> 4
       And Tp.Sn_Validado = 'N'
       And tp.sn_passou_rotina <> 'S'
       And Trunc(Tp.Dt_Inclusao) Between Trunc(Tp.Dt_Inclusao) - 5 And
           Trunc(Sysdate);

  v_Sql Varchar2(100) := 'Rotina: Custom.Prc_Validacao_Xml_Hospital ';
Begin

  For i In Cdadosprotocolo Loop
  
    Begin
    
      Update Custom.Tiss_Controle_Protocolo Tp
         Set Tp.Sn_Passou_Rotina = 'S'
       Where Tp.Cd_Protocolo_Ctamed = i.Cd_Protocolo_Ctamed;
      Commit;
      
      Dbaps.Prc_Valida_Prot_Tiss_Tes_Hosp(Pcd_Protocolo_Ctamed => i.Cd_Protocolo_Ctamed);
      
    Exception
      When Others Then
        v_Sql := v_Sql || '  Erro Ora --> ' || Sqlerrm;
        Begin
          Insert Into Custom.Tiss_Controle_Protocolo_Erro
            (Id_Log_Erro, Cd_Protocolo_Ctamed, Dt_Log_Erro, Erro_Ora)
          Values
            (Custom.Seq_Id_Controle_Protocolo_Erro.Nextval,
             i.Cd_Protocolo_Ctamed,
             Sysdate,
             v_Sql);
        
        End;
      
    End Loop;
  
  End Loop;

Exception
  When Others Then
    v_Sql := v_Sql || '  Erro Ora --> ' || Sqlerrm;
    Begin
      Insert Into Custom.Tiss_Controle_Protocolo_Erro
        (Id_Log_Erro, Cd_Protocolo_Ctamed, Dt_Log_Erro, Erro_Ora)
      Values
        (Custom.Seq_Id_Controle_Protocolo_Erro.Nextval,
         Null,
         Sysdate,
         v_Sql);
    End;
End Prc_Validacao_Xml_Hospital;
/
