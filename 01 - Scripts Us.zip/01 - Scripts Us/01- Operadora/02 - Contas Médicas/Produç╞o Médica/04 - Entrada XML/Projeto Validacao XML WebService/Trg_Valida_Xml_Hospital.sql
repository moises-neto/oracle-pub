Create Or Replace Trigger Custom.Trg_Valida_Xml_Hospital
  After Insert On Protocolo_Ctamed
  Referencing New As New Old As Old
  For Each Row
  
  --Desenvolvedor: Mois�s de Souza
  --Data: 03/05/2022
  --grava��o na tabela Custom.Tiss_Controle_Protocolo para chamar a rotina Prc_Valida_Prot_Tiss_Tes_Hosp 
  -- pois ela est� validando xml vindos do hospital (origem WebService). 
Declare
  --Pragma Autonomous_Transaction;

  v_Sqlerr Varchar2(500) := '';

Begin
  --Hospital Unimed (Tratamento de valida��o no XML)
  If (:New.Cd_Prestador = '300100' And :New.Cd_Status_Protocolo <> 4) Then
  
    Begin
      Insert Into Custom.Tiss_Controle_Protocolo
        (Id_Controle_Protocolo,
         Cd_Protocolo_Ctamed,
         Cd_Status_Protocolo,
         Dt_Envio,
         Dt_Inclusao,
         Dt_Log,
         Sn_Validado)
      Values
        (Custom.Seq_Id_Controle_Protocolo.Nextval,
         :New.Cd_Protocolo_Ctamed,
         :New.Cd_Status_Protocolo,
         :New.Dt_Envio_Lote,
         :New.Dt_Inclusao,
         Sysdate,
         'N');
    
    Exception
      When Others Then
        v_Sqlerr := substr(Sqlerrm,0,500);
        Begin
          Insert Into Custom.Tiss_Controle_Protocolo_Erro
            (Id_Log_Erro, Cd_Protocolo_Ctamed, Dt_Log_Erro, Erro_Ora)
          Values
            (Custom.Seq_Id_Controle_Protocolo_Erro.Nextval,
             :New.Cd_Protocolo_Ctamed,
             Sysdate,
             v_Sqlerr);
        
        End;
      
    End;
  End If;
End Trg_Valida_Xml_Hospital;
/
