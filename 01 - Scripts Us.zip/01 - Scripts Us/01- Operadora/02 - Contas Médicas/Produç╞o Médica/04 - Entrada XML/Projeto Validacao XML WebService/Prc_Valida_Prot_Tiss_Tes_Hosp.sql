Create Or Replace Procedure Dbaps.Prc_Valida_Prot_Tiss_Tes_Hosp(Pcd_Protocolo_Ctamed In Number) Is
  /**************************************************************
      Objeto de valida��o do protocolo Tiss da Unimed Sorocaba
    CRIA��O           : Mois�s de Souza - UNIMED SOROCABA
    DATA             : 03/05/2022
    OBJETIVO         : Estamos seguindo o objeto da MV prc_mvs_valida_protocolo_tiss,
     por�m precisamos customizar valida��es do hospital.
   ATEN��O: Regra apenas para o Hospital 300100                 
  
  */ --cursor do dados das guias
  -- DIF_HORAS_VALIDACAO - ESQUEMA PARA EVITAR VALIDA��O DE GUIAS J� HOMOLOGADAS NA ULTIMA HORA (FOCO: PERFORMANCE) (apos 1 hora revalida-se tudo)
  Cursor Cvtissloteguia(p_Cd_Protocolo_Ctamed In Number) Is
    Select v.Nr_Numero_Carteira,
           Regexp_Replace(v.Nr_Guia_Prestador, '[^[:digit:]]+') Nr_Guia_Prestador,
           Regexp_Replace(v.Nr_Guia_Operadora, '[^[:digit:]]+') Nr_Guia_Operadora,
           v.Cd_Prestador,
           v.Nm_Beneficiario,
           Regexp_Replace(v.Nr_Senha_Autorizacao, '[^[:digit:]]+') Nr_Senha_Autorizacao,
           v.Cd_Protocolo_Ctamed,
           Regexp_Replace(v.Nr_Identificador_Beneficiario, '[^[:digit:]]+') Nr_Identificador_Beneficiario,
           Regexp_Replace(v.Cd_Prestador_Exec, '[^[:digit:]]+') Cd_Prestador_Exec,
           Regexp_Replace(v.Cnpj_Exec, '[^[:digit:]]+') Cnpj_Exec,
           Regexp_Replace(v.Cpf_Exec, '[^[:digit:]]+') Cpf_Exec,
           v.Cd_Multi_Empresa,
           v.Id_Pai,
           v.Cd_Procedimento
      From Dbaps.v_Tiss_Lote_Guia v
     Where v.Cd_Protocolo_Ctamed = Pcd_Protocolo_Ctamed
       And Pcd_Protocolo_Ctamed Is Not Null
       And Exists
     (Select 1
              From Custom.Tiss_Controle_Protocolo Tp
             Where Tp.Cd_Protocolo_Ctamed = v.Cd_Protocolo_Ctamed
               And Tp.Sn_Validado = 'N')
    
     Group By v.Nr_Numero_Carteira,
              v.Nr_Guia_Prestador,
              v.Nr_Guia_Operadora,
              v.Cd_Prestador,
              v.Nm_Beneficiario,
              v.Nr_Senha_Autorizacao,
              v.Cd_Protocolo_Ctamed,
              v.Nr_Identificador_Beneficiario,
              v.Cd_Prestador_Exec,
              v.Cnpj_Exec,
              v.Cpf_Exec,
              v.Cd_Multi_Empresa,
              v.Id_Pai,
              v.Cd_Procedimento;

  Cursor Cexisteerro(p_Cd_Erro             In Varchar,
                     p_Cd_Protocolo_Ctamed In Number,
                     p_Nr_Guia_Prestador   In Varchar2) Is
    Select 1
      From Dbaps.Log_Erro_Protocolo_Tiss
     Where Cd_Protocolo_Ctamed = p_Cd_Protocolo_Ctamed
       And Cd_Erro = p_Cd_Erro
       And Ds_Guia_Prestador = p_Nr_Guia_Prestador;
  /**
  *  Cursor cProtocoloCtaMed
  */
  Cursor Cprotocoloctamed(p_Cd_Protocolo_Ctamed In Number) Is
    Select Pc.Id_Tisslotguia,
           Pc.Cd_Prestador,
           Mt.Cd_Retorno_Tiss_Mensagem Id_Tiss_Mensagem_Retorno,
           Tm.Id,
           Mt.Cd_Tiss_Mensagem,
           Pc.Cd_Protocolo_Ctamed,
           Pc.Cd_Multi_Empresa,
           Pc.Dt_Envio_Lote
      From Dbaps.Protocolo_Ctamed Pc,
           Dbaps.Tiss_Lot_Guia    Tlg,
           Dbaps.Tiss_Mensagem    Tm,
           Dbaps.Mv_Tiss          Mt,
           Dbaps.Prestador        p,
           Dbaps.Fatura           f
     Where Pc.Id_Tisslotguia = Tlg.Id
       And Tlg.Id_Pai = Tm.Id
       And Tm.Id = Mt.Cd_Tiss_Mensagem(+)
       And Pc.Cd_Prestador = p.Cd_Prestador
       And Pc.Cd_Fatura = f.Cd_Fatura(+)
       And Pc.Cd_Protocolo_Ctamed = p_Cd_Protocolo_Ctamed
       And Exists
     (Select 1
              From Custom.Tiss_Controle_Protocolo Tp
             Where Tp.Cd_Protocolo_Ctamed = Pc.Cd_Protocolo_Ctamed
               And Tp.Sn_Validado = 'N');

  /**
  *  Cursor cVerificaProcedimento, verifica se o Procedimento precisa de avalicao previa.
  */

  --Mois�s 25/03/2022 --> (CH2203-0567) N�o permitir a postagem de arquivo com consulta 10101039 COM o CD_TIPO_ATENDIMENTO_TISS <>11

  Cursor Cverificaconsultaps Is
    Select v.Cd_Protocolo_Ctamed,
           v.Nr_Numero_Carteira,
           v.Nr_Guia_Prestador,
           v.Nr_Senha_Autorizacao,
           v.Cd_Prestador,
           v.Nm_Beneficiario,
           v.Nr_Guia_Operadora,
           v.Cd_Tipo_Atendimento
      From Dbaps.v_Tiss_Lote_Guia v
     Where v.Cd_Protocolo_Ctamed = Pcd_Protocolo_Ctamed
       And v.Cd_Procedimento = '10101039'
       And v.Cd_Tipo_Atendimento <> '11'
       And Exists
     (Select 1
              From Custom.Tiss_Controle_Protocolo Tp
             Where Tp.Cd_Protocolo_Ctamed = v.Cd_Protocolo_Ctamed
               And Tp.Sn_Validado = 'N');
  -- Mois�s --> 12/04/2022 atender ao requisito do manual do PTU XML --> CH2202-2485
  -- (travar quando for guia de interna��o, conter os procedimento
  --31309038, 31309054, 31309097, 31309127 e 31309135, e n�o tiver o CD_TIPO_INTERNACAO = 3.

  Cursor Ctipointernacao Is
    Select v.Cd_Protocolo_Ctamed,
           v.Nr_Numero_Carteira,
           v.Nr_Guia_Prestador,
           v.Nr_Senha_Autorizacao,
           v.Cd_Prestador,
           v.Nm_Beneficiario,
           v.Nr_Guia_Operadora,
           v.Cd_Tipo_Internacao
      From Dbaps.v_Tiss_Lote_Guia v
     Where v.Cd_Protocolo_Ctamed = Pcd_Protocolo_Ctamed
       And v.Cd_Tipo_Internacao <> 3
       And v.Cd_Procedimento In
           (31309038, 31309054, 31309097, 31309127, 31309135)
       And Exists
     (Select 1
              From Custom.Tiss_Controle_Protocolo Tp
             Where Tp.Cd_Protocolo_Ctamed = v.Cd_Protocolo_Ctamed
               And Tp.Sn_Validado = 'N');

  --TESTE MOISES

  Cursor Cguiasduplicadas Is
    Select v.Cd_Protocolo_Ctamed,
           v.Nr_Numero_Carteira,
           v.Nr_Guia_Prestador,
           v.Nr_Senha_Autorizacao,
           v.Cd_Prestador,
           v.Nm_Beneficiario,
           v.Nr_Guia_Operadora,
           v.Cd_Tipo_Atendimento,
           v.Cd_Tipo_Internacao
      From Dbaps.v_Tiss_Lote_Guia v
     Where v.Cd_Protocolo_Ctamed = Pcd_Protocolo_Ctamed
       And v.Cd_Tipo_Atendimento = 1
       And Exists (Select 1
              From Dbaps.Remessa_Prestador Rp
             Where Rp.Nr_Guia = v.Nr_Senha_Autorizacao)
          
       And Exists
     (Select 1
              From Custom.Tiss_Controle_Protocolo Tp
             Where Tp.Cd_Protocolo_Ctamed = v.Cd_Protocolo_Ctamed
               And Tp.Sn_Validado = 'N')
    
    Union All
    --Interna��o
    Select v.Cd_Protocolo_Ctamed,
           v.Nr_Numero_Carteira,
           v.Nr_Guia_Prestador,
           v.Nr_Senha_Autorizacao,
           v.Cd_Prestador,
           v.Nm_Beneficiario,
           v.Nr_Guia_Operadora,
           v.Cd_Tipo_Atendimento,
           v.Cd_Tipo_Internacao
      From Dbaps.v_Tiss_Lote_Guia v
     Where v.Cd_Protocolo_Ctamed = Pcd_Protocolo_Ctamed
       And Exists
     (Select 1
              From Custom.Tiss_Controle_Protocolo Tp
             Where Tp.Cd_Protocolo_Ctamed = v.Cd_Protocolo_Ctamed
               And Tp.Sn_Validado = 'N')
          
       And Exists (Select 1
              From Dbaps.Conta_Hospitalar c
             Where c.Nr_Guia = v.Nr_Senha_Autorizacao
               And c.Cd_Tipo_Faturamento <> 'C')
    Union All --(SADT)
    
    Select v.Cd_Protocolo_Ctamed,
           v.Nr_Numero_Carteira,
           v.Nr_Guia_Prestador,
           v.Nr_Senha_Autorizacao,
           v.Cd_Prestador,
           v.Nm_Beneficiario,
           v.Nr_Guia_Operadora,
           v.Cd_Tipo_Atendimento,
           v.Cd_Tipo_Internacao
      From Dbaps.v_Tiss_Lote_Guia v
     Where v.Cd_Protocolo_Ctamed = Pcd_Protocolo_Ctamed
       And v.Cd_Tipo_Atendimento Not In (3, 8, 10)
       And Exists
     (Select 1
              From Custom.Tiss_Controle_Protocolo Tp
             Where Tp.Cd_Protocolo_Ctamed = v.Cd_Protocolo_Ctamed
               And Tp.Sn_Validado = 'N')
          
       And Exists
     (Select 1
              From Dbaps.Remessa_Prestador Rp, Itremessa_Prestador Ip
             Where Rp.Cd_Remessa = Ip.Cd_Remessa
                  
               And Rp.Nr_Guia = v.Nr_Senha_Autorizacao
               And Nvl(Ip.Cd_Procedimento, Ip.Cd_Proc_Digita) =
                   v.Cd_Procedimento
               And Ip.Qt_Cobrado = v.Qt_Realizado
               And To_Char(Ip.Dt_Realizado, 'DD/MM/YYYY') =
                   Substr(v.Dt_Procedimento, 9, 9) || '/' ||
                   Substr(v.Dt_Procedimento, 6, 2) || '/' ||
                   Substr(v.Dt_Procedimento, 0, 4))
       And Not Exists (Select 1
              From Procedimento_Baixo_Risco Br
             Where Br.Cd_Procedimento = v.Cd_Procedimento
               And Br.Dt_Inativacao Is Null);

  Cursor Ccodigoinexistente Is
    Select v.Cd_Protocolo_Ctamed,
           v.Nr_Numero_Carteira,
           v.Nr_Guia_Prestador,
           v.Nr_Senha_Autorizacao,
           v.Cd_Prestador,
           v.Nm_Beneficiario,
           v.Nr_Guia_Operadora,
           v.Cd_Procedimento
      From Dbaps.v_Tiss_Lote_Guia v
     Where v.Cd_Protocolo_Ctamed = Pcd_Protocolo_Ctamed
       And v.Cd_Procedimento <> '99910073'
          
       And Exists
     (Select 1
              From Custom.Tiss_Controle_Protocolo Tp
             Where Tp.Cd_Protocolo_Ctamed = v.Cd_Protocolo_Ctamed
               And Tp.Sn_Validado = 'N')
       And Not Exists
     (Select 1
              From Dbaps.Procedimento p
             Where p.Cd_Procedimento = v.Cd_Procedimento);

  Cursor Cguiavencida Is
  --Interna��o
    Select v.Cd_Protocolo_Ctamed,
           v.Nr_Numero_Carteira,
           v.Nr_Guia_Prestador,
           v.Nr_Senha_Autorizacao,
           v.Cd_Prestador,
           v.Nm_Beneficiario,
           v.Nr_Guia_Operadora,
           v.Cd_Tipo_Atendimento,
           v.Cd_Tipo_Internacao
      From Dbaps.v_Tiss_Lote_Guia v
     Where v.Cd_Protocolo_Ctamed = Pcd_Protocolo_Ctamed
          
       And Exists
     (Select 1
              From Custom.Tiss_Controle_Protocolo Tp
             Where Tp.Cd_Protocolo_Ctamed = v.Cd_Protocolo_Ctamed
               And Tp.Sn_Validado = 'N')
       And Exists
     (Select 1
              From Dbaps.Conta_Hospitalar c, Dbaps.Itconta_Hospitalar Ih
             Where c.Cd_Conta_Hospitalar = Ih.Cd_Conta_Hospitalar
               And c.Nr_Guia = v.Nr_Guia_Operadora
               And Exists (Select 1
                      From Dbaps.Guia g
                     Where g.Nr_Guia = c.Nr_Guia
                       And g.Sn_Valida_Rest_Carencia = 'S'
                       And Substr(v.Dt_Procedimento, 9, 9) || '/' ||
                           Substr(v.Dt_Procedimento, 6, 2) || '/' ||
                           Substr(v.Dt_Procedimento, 0, 4) >
                           Trunc(g.Dt_Vencimento))
            
            Union
            
            Select 1
              From Dbaps.Conta_Hospitalar c, Dbaps.Itconta_Hospitalar Ih
             Where c.Cd_Conta_Hospitalar = Ih.Cd_Conta_Hospitalar
               And c.Nr_Guia = v.Nr_Guia_Prestador
               And Exists (Select 1
                      From Dbaps.Guia g
                     Where g.Nr_Guia = c.Nr_Guia
                       And g.Sn_Valida_Rest_Carencia = 'S'
                       And Substr(v.Dt_Procedimento, 9, 9) || '/' ||
                           Substr(v.Dt_Procedimento, 6, 2) || '/' ||
                           Substr(v.Dt_Procedimento, 0, 4) >
                           Trunc(g.Dt_Vencimento)))
    Union All --(SADT) e Consulta
    
    Select v.Cd_Protocolo_Ctamed,
           v.Nr_Numero_Carteira,
           v.Nr_Guia_Prestador,
           v.Nr_Senha_Autorizacao,
           v.Cd_Prestador,
           v.Nm_Beneficiario,
           v.Nr_Guia_Operadora,
           v.Cd_Tipo_Atendimento,
           v.Cd_Tipo_Internacao
      From Dbaps.v_Tiss_Lote_Guia v
     Where v.Cd_Protocolo_Ctamed = Pcd_Protocolo_Ctamed
       And v.Cd_Tipo_Atendimento Not In (3, 8, 10)
       And Exists
     (Select 1
              From Custom.Tiss_Controle_Protocolo Tp
             Where Tp.Cd_Protocolo_Ctamed = v.Cd_Protocolo_Ctamed
               And Tp.Sn_Validado = 'N')
       And Exists
     (Select 1
              From Dbaps.Remessa_Prestador Rp, Itremessa_Prestador Ip
             Where Rp.Cd_Remessa = Ip.Cd_Remessa
               And Rp.Nr_Guia = v.Nr_Guia_Prestador
                  
               And Exists (Select 1
                      From Dbaps.Guia g
                     Where g.Nr_Guia = Rp.Nr_Guia
                       And g.Sn_Valida_Rest_Carencia = 'S'
                       And Substr(v.Dt_Procedimento, 9, 9) || '/' ||
                           Substr(v.Dt_Procedimento, 6, 2) || '/' ||
                           Substr(v.Dt_Procedimento, 0, 4) >
                           Trunc(g.Dt_Vencimento))
            
            Union
            
            Select 1
              From Dbaps.Remessa_Prestador Rp, Itremessa_Prestador Ip
             Where Rp.Cd_Remessa = Ip.Cd_Remessa
               And Rp.Nr_Guia = v.Nr_Guia_Operadora
                  
               And Exists (Select 1
                      From Dbaps.Guia g
                     Where g.Nr_Guia = Rp.Nr_Guia
                       And g.Sn_Valida_Rest_Carencia = 'S'
                       And Substr(v.Dt_Procedimento, 9, 9) || '/' ||
                           Substr(v.Dt_Procedimento, 6, 2) || '/' ||
                           Substr(v.Dt_Procedimento, 0, 4) >
                           Trunc(g.Dt_Vencimento)));

  /* Cursor Cquantidadeultrapassada Is
  
  Select v.Cd_Protocolo_Ctamed,
         v.Nr_Numero_Carteira,
         v.Nr_Guia_Prestador,
         v.Nr_Senha_Autorizacao,
         v.Cd_Prestador,
         v.Nm_Beneficiario,
         v.Nr_Guia_Operadora,
         v.Cd_Procedimento
    From Dbaps.v_Tiss_Lote_Guia v
   Where v.Cd_Protocolo_Ctamed = Pcd_Protocolo_Ctamed
     And Exists
   (Select 1
            From Custom.Tiss_Controle_Protocolo Tp
           Where Tp.Cd_Protocolo_Ctamed = v.Cd_Protocolo_Ctamed
             And Tp.Sn_Validado = 'N')
     And Exists
   (Select 1
            From Dbaps.Procedimento p, Dbaps.Grupo_Procedimento Gp
           Where p.Cd_Grupo_Procedimento = Gp.Cd_Grupo_Procedimento
             And p.Cd_Procedimento = v.Cd_Procedimento
             And Gp.Tp_Gru_Pro In ('SP', 'SD')
          Union
          Select 1
            From Dbaps.Procedimento p
           Where p.Cd_Procedimento = v.Cd_Procedimento
             And p.Sn_Pacote = 'S')
        
     And Length(v.Qt_Realizado) > 3;
   */
  Cursor Cdeclaracaonascidoouobtito Is
  
    Select v.Cd_Protocolo_Ctamed,
           v.Nr_Numero_Carteira,
           v.Nr_Guia_Prestador,
           v.Nr_Senha_Autorizacao,
           v.Cd_Prestador,
           v.Nm_Beneficiario,
           v.Nr_Guia_Operadora,
           v.Cd_Procedimento
      From Dbaps.Tiss_Lot_Guia_Fat_Resint_Decl d,
           Dbaps.Tiss_Lot_Guia_Fat_Resint      r,
           Dbaps.v_Tiss_Lote_Guia              v
     Where d.Id_Pai = r.Id
       And v.Id_Pai = r.Id
       And v.Cd_Protocolo_Ctamed = Pcd_Protocolo_Ctamed
       And Exists
     (Select 1
              From Custom.Tiss_Controle_Protocolo Tp
             Where Tp.Cd_Protocolo_Ctamed = v.Cd_Protocolo_Ctamed
               And Tp.Sn_Validado = 'N')
       And (d.Ds_Declaracao_Obito Is Null And
           d.Nr_Declaracao_Nascido Is Null)
       And v.Cd_Procedimento In
           ('31309054', '31309097', '31309127', '31309135')
    
    Union All
    
    Select v.Cd_Protocolo_Ctamed,
           v.Nr_Numero_Carteira,
           v.Nr_Guia_Prestador,
           v.Nr_Senha_Autorizacao,
           v.Cd_Prestador,
           v.Nm_Beneficiario,
           v.Nr_Guia_Operadora,
           v.Cd_Procedimento
      From Dbaps.Tiss_Lot_Guia_Fat_Resint_Decl d,
           Dbaps.Tiss_Lot_Guia_Fat_Resint      r,
           Dbaps.v_Tiss_Lote_Guia              v
     Where d.Id_Pai = r.Id
       And v.Id_Pai = r.Id
       And v.Cd_Protocolo_Ctamed = Pcd_Protocolo_Ctamed
       And Exists
     (Select 1
              From Custom.Tiss_Controle_Protocolo Tp
             Where Tp.Cd_Protocolo_Ctamed = v.Cd_Protocolo_Ctamed
               And Tp.Sn_Validado = 'N')
       And v.Cd_Procedimento In
           ('31309054', '31309097', '31309127', '31309135')
          
       And Length(Custom.Fnc_Ajusta_Numero(v_String => Trim(Nvl(d.Ds_Declaracao_Obito,
                                                                d.Nr_Declaracao_Nascido)))) > 11;

  Cursor Cdeclaracaoobito Is
  
    Select v.Cd_Protocolo_Ctamed,
           v.Nr_Numero_Carteira,
           v.Nr_Guia_Prestador,
           v.Nr_Senha_Autorizacao,
           v.Cd_Prestador,
           v.Nm_Beneficiario,
           v.Nr_Guia_Operadora,
           v.Cd_Procedimento
      From Dbaps.Tiss_Lot_Guia_Fat_Resint_Decl d,
           Dbaps.Tiss_Lot_Guia_Fat_Resint      r,
           Dbaps.v_Tiss_Lote_Guia              v
     Where d.Id_Pai = r.Id
       And v.Id_Pai = r.Id
       And v.Cd_Protocolo_Ctamed = Pcd_Protocolo_Ctamed
       And v.Cd_Motivo_Alta In (41, 65, 66, 67)
       And Exists
     (Select 1
              From Custom.Tiss_Controle_Protocolo Tp
             Where Tp.Cd_Protocolo_Ctamed = v.Cd_Protocolo_Ctamed
               And Tp.Sn_Validado = 'N')
       And d.Ds_Declaracao_Obito Is Null
    
    Union All
    
    Select v.Cd_Protocolo_Ctamed,
           v.Nr_Numero_Carteira,
           v.Nr_Guia_Prestador,
           v.Nr_Senha_Autorizacao,
           v.Cd_Prestador,
           v.Nm_Beneficiario,
           v.Nr_Guia_Operadora,
           v.Cd_Procedimento
      From Dbaps.Tiss_Lot_Guia_Fat_Resint_Decl d,
           Dbaps.Tiss_Lot_Guia_Fat_Resint      r,
           Dbaps.v_Tiss_Lote_Guia              v
     Where d.Id_Pai = r.Id
       And v.Id_Pai = r.Id
       And v.Cd_Protocolo_Ctamed = Pcd_Protocolo_Ctamed
       And v.Cd_Motivo_Alta In (41, 65, 66, 67)
       And Exists
     (Select 1
              From Custom.Tiss_Controle_Protocolo Tp
             Where Tp.Cd_Protocolo_Ctamed = v.Cd_Protocolo_Ctamed
               And Tp.Sn_Validado = 'N')
          
       And Length(Custom.Fnc_Ajusta_Numero(v_String => Trim(d.Ds_Declaracao_Obito))) > 11;

  Cursor Cobrigagrauparticipacao Is
  
    Select v.Cd_Protocolo_Ctamed,
           v.Nr_Numero_Carteira,
           v.Nr_Guia_Prestador,
           v.Nr_Senha_Autorizacao,
           v.Cd_Prestador,
           v.Nm_Beneficiario,
           v.Nr_Guia_Operadora,
           v.Cd_Procedimento
      From Dbaps.Tiss_Lot_Guia_Fat_Resint      r,
           Dbaps.Tiss_Lot_Guia_Fat_Resint_Proc p,
           Dbaps.Tiss_Lot_Guia_Fat_Resint_Eqp  e,
           Dbaps.v_Tiss_Lote_Guia              v
     Where r.Id = p.Id_Pai
       And p.Id = e.Id_Pai
       And v.Id_Pai = r.Id
       And v.Cd_Protocolo_Ctamed = Pcd_Protocolo_Ctamed
       And e.Cd_Posicao_Profissional Is Null
       And Exists
     (Select 1
              From Custom.Tiss_Controle_Protocolo Tp
             Where Tp.Cd_Protocolo_Ctamed = v.Cd_Protocolo_Ctamed
               And Tp.Sn_Validado = 'N')
          
       And Exists
     (Select 1
              From Dbaps.Procedimento p, Dbaps.Grupo_Procedimento Gp
             Where Gp.Cd_Grupo_Procedimento = p.Cd_Grupo_Procedimento
               And p.Cd_Procedimento = v.Cd_Procedimento
               And Gp.Tp_Gru_Pro = 'SP');

  --DELCARA��O DE VARI�VEIS de controle

  Rvtissloteguia        Cvtissloteguia%Rowtype;
  Rprotocoloctamed      Cprotocoloctamed%Rowtype;
  Vcoderro              Varchar2(10);
  Vretorno_Unidade      Varchar2(5000);
  Vretorno_Procedimento Varchar2(5000);
  Nqtderrostotal        Number;
  Nqtderros             Number;
  Vexcecao              Varchar2(1000);
  Vexcecaolinha         Varchar2(1000);
  Vverificaconsultaps   Cverificaconsultaps%Rowtype;
  Vtipointernacao       Ctipointernacao%Rowtype;
  Vguiasduplicadas      Cguiasduplicadas%Rowtype;
  Vcodigoinexistente    Ccodigoinexistente%Rowtype;
  Vguiavencida          Cguiavencida%Rowtype;
  Vdatavencimento       Varchar2(30) := '';
  Nqtderrostotal2       Pls_Integer;
  Vhtml                 Clob := '';
  Vloteprestador        Varchar2(20) := '';
  Vtamanhoemail         Number := 0;
  --Vquantidadeultrapassada    Cquantidadeultrapassada%Rowtype;
  Vdeclaracaonascidoouobtito Cdeclaracaonascidoouobtito%Rowtype;
  Vdeclaracaobtito           Cdeclaracaoobito%Rowtype;
  Vobrigagrauparticipacao    Cobrigagrauparticipacao%Rowtype;
  --
  --
  Procedure Prc_Insere_Log_Erro(p_Numero_Carteira       In Varchar2,
                                p_Numero_Guia_Prestador In Varchar2,
                                p_Numero_Guia_Operadora In Varchar2,
                                p_Numero_Senha          In Varchar2,
                                p_Codigo_Prestador      In Varchar2,
                                p_Nm_Beneficiario       In Varchar2,
                                p_Node_Xml              In Varchar2,
                                p_Node_Xml_Sub          In Varchar2,
                                p_Ds_Erro               In Varchar2,
                                p_Cd_Erro               In Varchar2,
                                p_Tp_Erro               In Varchar2,
                                p_Sn_Guia_Web           In Varchar2 Default 'N',
                                p_Procedimento          In Varchar2 Default Null) Is
  
    Binsereerro Boolean;
    Nteste      Number;
    Vdescricao  Varchar2(6000 Char) := p_Ds_Erro;
  Begin
    -- G -> ERRO DE GUIA - APENAS UMA OCORRENCIA
    -- I -> ERRO DE ITEM DE GUIA - VARIAS OCORRENCIAS
    Binsereerro := True;
    Nteste      := Null;
    /*
     - String de apresenta��o para o PDF do PORTAL.:
    '[G001] - SENHA: XXXXXXXXX - GUIA PRESTADOR: XXXXXXXXX - Descri��o do Problema.';
    '[P001] - SENHA: XXXXXXXXX - GUIA PRESTADOR: XXXXXXXXX - PROCEDIMENTO - Descri��o do Problema.';
     - Para o autorizador a string ser� simples!
    '[G001 ou P001] - Descri��o do Problema.';
    */
  
    If (p_Tp_Erro = 'G') Then
      Vdescricao := Vdescricao;
    Else
      Vdescricao := p_Ds_Erro;
    End If;
    If p_Tp_Erro = 'G' Then
      Open Cexisteerro(p_Cd_Erro,
                       Pcd_Protocolo_Ctamed,
                       p_Numero_Guia_Prestador);
      Fetch Cexisteerro
        Into Nteste;
      If Cexisteerro%Found Then
        Binsereerro := False;
      End If;
      Close Cexisteerro;
    End If;
  
    If Binsereerro Then
      Insert Into Dbaps.Log_Erro_Protocolo_Tiss
        (Cd_Log_Erro_Protocolo_Tiss,
         Cd_Protocolo_Ctamed,
         Ds_Carteira_Beneficiario,
         Ds_Guia_Prestador,
         Ds_Guia_Operadora,
         Ds_Codigo_Prestador,
         Nm_Beneficiario,
         Ds_Tipo_Guia,
         Ds_Node_Xml,
         Ds_Node_Xml_Sub,
         Ds_Erro,
         Cd_Erro)
      Values
        (Dbaps.Seq_Mvs_Log_Erro_Proto_Tiss.Nextval,
         Pcd_Protocolo_Ctamed,
         p_Numero_Carteira,
         p_Numero_Guia_Prestador,
         p_Numero_Guia_Operadora,
         p_Codigo_Prestador,
         p_Nm_Beneficiario,
         'IOD',
         p_Node_Xml,
         p_Node_Xml_Sub,
         Vdescricao,
         Substr(p_Cd_Erro, 0, 100));
    End If;
  End;

Begin
  Nqtderrostotal := 0;
  Nqtderros      := 0;
  -- REMOVENDO LOG ANTIGO

  Rprotocoloctamed := Null;
  Open Cprotocoloctamed(Pcd_Protocolo_Ctamed);
  Fetch Cprotocoloctamed
    Into Rprotocoloctamed;
  Close Cprotocoloctamed;

  --
  --****************************
  --* CURSOR DO CABE�ALHO DO PROTOCOLO
  --****************************
  --
  Open Cvtissloteguia(Pcd_Protocolo_Ctamed);
  Loop
    Fetch Cvtissloteguia
      Into Rvtissloteguia;
    Begin
      --EXCEPTION DE GUIA
      If Cvtissloteguia%Notfound Then
        Exit;
      End If;
    
      -- if rVTissLoteGuia.Cd_Prestador = 1001153 then
    
      --Verifica se a unidade de medida esta correta
      --Verifica se procediemnto esta inativo
      Select To_Char(Dbaps.Fnc_Verifica_Procedimento_Tes1(Rvtissloteguia.Cd_Protocolo_Ctamed,
                                                          Rvtissloteguia.Nr_Guia_Operadora,
                                                          Rvtissloteguia.Cd_Procedimento))
        Into Vretorno_Procedimento
        From Dual;
    
      Select To_Char(Dbaps.Fnc_Retorna_Unidade_Med_Tes1(Rvtissloteguia.Cd_Protocolo_Ctamed,
                                                        Rvtissloteguia.Nr_Guia_Operadora,
                                                        Rvtissloteguia.Cd_Procedimento))
        Into Vretorno_Unidade
        From Dual;
    
      If ((Upper(Vretorno_Procedimento) <> 'OK' And
         Upper(Vretorno_Unidade) = 'OK') Or
         (Upper(Vretorno_Procedimento) <> 'OK' And
         Upper(Vretorno_Unidade) <> 'OK')) Then
      
        Nqtderros := Nqtderros + 1;
        Vcoderro  := 'G999';
        Prc_Insere_Log_Erro(Rvtissloteguia.Nr_Numero_Carteira,
                            Rvtissloteguia.Nr_Guia_Prestador,
                            Rvtissloteguia.Nr_Guia_Operadora,
                            Rvtissloteguia.Nr_Senha_Autorizacao,
                            Rvtissloteguia.Cd_Prestador,
                            Rvtissloteguia.Nm_Beneficiario,
                            --'',
                            '',
                            '',
                            'PROCEDIMENTO INATIVO: ( ' ||
                            Substr(Vretorno_Procedimento, 0, 1950) || ' )',
                            -- Lpad(Vretorno_Procedimento, 1900) || ')',
                            'G999',
                            'I',
                            'N');
      
      Elsif (Upper(Vretorno_Procedimento) = 'OK' And
            Upper(Vretorno_Unidade) <> 'OK') Then
        Nqtderros := Nqtderros + 1;
        Vcoderro  := 'G999';
        Prc_Insere_Log_Erro(Rvtissloteguia.Nr_Numero_Carteira,
                            Rvtissloteguia.Nr_Guia_Prestador,
                            Rvtissloteguia.Nr_Guia_Operadora,
                            Rvtissloteguia.Nr_Senha_Autorizacao,
                            Rvtissloteguia.Cd_Prestador,
                            Rvtissloteguia.Nm_Beneficiario,
                            --rVTissLoteGuia.DS_TP_PROTOCOLO,
                            '',
                            '',
                            'UNIDADE DE MEDIDA INCORRETA: ( ' ||
                            Substr(Vretorno_Unidade, 0, 1950) || ' )',
                            --Lpad(Vretorno_Unidade, 1900) || ')',
                            'G999',
                            'I',
                            'N');
      
      End If;
      Commit;
    
      --EXCEPTION A NIVEL DE GUIA PARA PROIBIR TODAS EM CASO DE PROBLEMA NO BANCO
    Exception
      When Others Then
        Vexcecao      := Sqlerrm;
        Vexcecaolinha := Dbms_Utility.Format_Error_Backtrace;
        Vcoderro      := 'E999';
        Prc_Insere_Log_Erro(Rvtissloteguia.Nr_Numero_Carteira,
                            Rvtissloteguia.Nr_Guia_Prestador,
                            Rvtissloteguia.Nr_Guia_Operadora,
                            Rvtissloteguia.Nr_Senha_Autorizacao,
                            Rvtissloteguia.Cd_Prestador,
                            Rvtissloteguia.Nm_Beneficiario,
                            '',
                            '',
                            'EXCEPTION-GUIA! N�o foi possivel validar as regras. Favor entre em contato com a Operadora MSG: ' ||
                            Vexcecao || ' linha do erro: ' || Vexcecaolinha,
                            Vcoderro,
                            'E',
                            'N');
        Commit;
    End; --EXCEPTION DE GUIA
    Nqtderrostotal := Nqtderrostotal + Nqtderros;
  End Loop;
  -- FIM DO LOOP DE GUIAS
  Close Cvtissloteguia;
  --nQtdErrosTotal := nQtdErrosTotal + nQtdErros;

  --Mois�s 25/03/2022 --> (CH2203-0567) N�o permitir a postagem de arquivo com consulta 10101039 COM o CD_TIPO_ATENDIMENTO_TISS <>11
  Begin
    For Vverificaconsultaps In Cverificaconsultaps Loop
    
      Begin
      
        Prc_Insere_Log_Erro(Vverificaconsultaps.Nr_Numero_Carteira,
                            Vverificaconsultaps.Nr_Guia_Prestador,
                            Vverificaconsultaps.Nr_Guia_Operadora,
                            Vverificaconsultaps.Nr_Senha_Autorizacao,
                            Vverificaconsultaps.Cd_Prestador,
                            Vverificaconsultaps.Nm_Beneficiario,
                            '',
                            '',
                            'Conforme o padr�o TISS para procedimento de Consulta de Pronto Socorro �
                             necess�rio informar o CD_ATENDIMENTO_TISS no valor 11. Guia: ' ||
                            Vverificaconsultaps.Nr_Guia_Operadora ||
                            ' Tipo de atendimento Tiss: ' ||
                            Vverificaconsultaps.Cd_Tipo_Atendimento,
                            'G998',
                            'I',
                            'N');
      
      End;
    End Loop;
    Commit;
  
  Exception
    When Others Then
      Dbms_Output.Put_Line('exception-gral');
      Vexcecao      := Sqlerrm;
      Vexcecaolinha := Dbms_Utility.Format_Error_Backtrace;
      Vcoderro      := 'E999';
      Prc_Insere_Log_Erro(Vverificaconsultaps.Nr_Numero_Carteira,
                          Vverificaconsultaps.Nr_Guia_Prestador,
                          Vverificaconsultaps.Nr_Guia_Operadora,
                          Vverificaconsultaps.Nr_Senha_Autorizacao,
                          Vverificaconsultaps.Cd_Prestador,
                          Vverificaconsultaps.Nm_Beneficiario,
                          '',
                          '',
                          'EXCEPTION-GLOBAL! N�o foi possivel validar as regras. Favor entre em contato com a Operadora MSG: ' ||
                          Vexcecao || ' linha do erro: ' || Vexcecaolinha,
                          Vcoderro,
                          'E',
                          'N');
      Commit;
      If (Cverificaconsultaps%Isopen) Then
        Close Cverificaconsultaps;
      End If;
  End;

  -- Mois�s --> 12/04/2022 atender ao requisito do manual do PTU XML --> CH2202-2485 (travar quando for guia de interna��o, conter os procedimento
  --31309038, 31309054, 31309097, 31309127 e 31309135, e n�o tiver o CD_TIPO_INTERNACAO = 3.

  Begin
    For Vtipointernacao In Ctipointernacao Loop
    
      Begin
        Prc_Insere_Log_Erro(Vtipointernacao.Nr_Numero_Carteira,
                            Vtipointernacao.Nr_Guia_Prestador,
                            Vtipointernacao.Nr_Guia_Operadora,
                            Vtipointernacao.Nr_Senha_Autorizacao,
                            Vtipointernacao.Cd_Prestador,
                            Vtipointernacao.Nm_Beneficiario,
                            --rVTissLoteGuia.DS_TP_PROTOCOLO,
                            '',
                            '',
                            '1506 - TIPO DE INTERNA��O INV�LIDO: ' ||
                            Vtipointernacao.Nr_Guia_Operadora,
                            'G997',
                            'I',
                            'N');
      
      End;
    End Loop;
    Commit;
  
  Exception
    When Others Then
      Dbms_Output.Put_Line('exception-gral');
      Vexcecao      := Sqlerrm;
      Vexcecaolinha := Dbms_Utility.Format_Error_Backtrace;
      Vcoderro      := 'E999';
      Prc_Insere_Log_Erro(Vtipointernacao.Nr_Numero_Carteira,
                          Vtipointernacao.Nr_Guia_Prestador,
                          Vtipointernacao.Nr_Guia_Operadora,
                          Vtipointernacao.Nr_Senha_Autorizacao,
                          Vtipointernacao.Cd_Prestador,
                          Vtipointernacao.Nm_Beneficiario,
                          '',
                          '',
                          'EXCEPTION-GLOBAL! N�o foi possivel validar as regras. Favor entre em contato com a Operadora MSG: ' ||
                          Vexcecao || ' linha do erro: ' || Vexcecaolinha,
                          Vcoderro,
                          'E',
                          'N');
      Commit;
      If (Ctipointernacao%Isopen) Then
        Close Ctipointernacao;
      End If;
  End;

  --GUIAS DUPLICADAS

  Begin
    For Vguiasduplicadas In Cguiasduplicadas Loop
    
      Begin
      
        Prc_Insere_Log_Erro(Vguiasduplicadas.Nr_Numero_Carteira,
                            Vguiasduplicadas.Nr_Guia_Prestador,
                            Vguiasduplicadas.Nr_Guia_Operadora,
                            Vguiasduplicadas.Nr_Senha_Autorizacao,
                            Vguiasduplicadas.Cd_Prestador,
                            Vguiasduplicadas.Nm_Beneficiario,
                            --rVTissLoteGuia.DS_TP_PROTOCOLO,
                            '',
                            '',
                            'Duplicidade de Guias: ' ||
                            Vguiasduplicadas.Nr_Senha_Autorizacao,
                            'G996',
                            'I',
                            'N');
      
      End;
    End Loop;
    Commit;
  
  Exception
    When Others Then
      Dbms_Output.Put_Line('exception-gral');
      Vexcecao      := Sqlerrm;
      Vexcecaolinha := Dbms_Utility.Format_Error_Backtrace;
      Vcoderro      := 'E999';
      Prc_Insere_Log_Erro(Vguiasduplicadas.Nr_Numero_Carteira,
                          Vguiasduplicadas.Nr_Guia_Prestador,
                          Vguiasduplicadas.Nr_Guia_Operadora,
                          Vguiasduplicadas.Nr_Senha_Autorizacao,
                          Vguiasduplicadas.Cd_Prestador,
                          Vguiasduplicadas.Nm_Beneficiario,
                          '',
                          '',
                          'EXCEPTION-GLOBAL! N�o foi possivel validar as regras. Favor entre em contato com a Operadora MSG: ' ||
                          Vexcecao || ' linha do erro: ' || Vexcecaolinha,
                          Vcoderro,
                          'E',
                          'N');
      Commit;
      If (Cguiasduplicadas%Isopen) Then
        Close Cguiasduplicadas;
      End If;
  End;

  --C�digo Inexistente

  Begin
    For Vcodigoinexistente In Ccodigoinexistente Loop
    
      Begin
      
        Prc_Insere_Log_Erro(Vcodigoinexistente.Nr_Numero_Carteira,
                            Vcodigoinexistente.Nr_Guia_Prestador,
                            Vcodigoinexistente.Nr_Guia_Operadora,
                            Vcodigoinexistente.Nr_Senha_Autorizacao,
                            Vcodigoinexistente.Cd_Prestador,
                            Vcodigoinexistente.Nm_Beneficiario,
                            --rVTissLoteGuia.DS_TP_PROTOCOLO,
                            '',
                            '',
                            'C�digo Inexistente: ' ||
                            Vcodigoinexistente.Cd_Procedimento,
                            'G995',
                            'I',
                            'N');
      
      End;
    End Loop;
    Commit;
  
  Exception
    When Others Then
      Dbms_Output.Put_Line('exception-gral');
      Vexcecao      := Sqlerrm;
      Vexcecaolinha := Dbms_Utility.Format_Error_Backtrace;
      Vcoderro      := 'E999';
      Prc_Insere_Log_Erro(Vcodigoinexistente.Nr_Numero_Carteira,
                          Vcodigoinexistente.Nr_Guia_Prestador,
                          Vcodigoinexistente.Nr_Guia_Operadora,
                          Vcodigoinexistente.Nr_Senha_Autorizacao,
                          Vcodigoinexistente.Cd_Prestador,
                          Vcodigoinexistente.Nm_Beneficiario,
                          '',
                          '',
                          'EXCEPTION-GLOBAL! N�o foi possivel validar as regras. Favor entre em contato com a Operadora MSG: ' ||
                          Vexcecao || ' linha do erro: ' || Vexcecaolinha,
                          Vcoderro,
                          'E',
                          'N');
      Commit;
      If (Ccodigoinexistente%Isopen) Then
        Close Ccodigoinexistente;
      End If;
  End;

  --Guia Vencida

  Begin
    For Vguiavencida In Cguiavencida Loop
    
      Begin
      
        Begin
          Select g.Dt_Vencimento
            Into Vdatavencimento
            From Dbaps.Guia g
           Where g.Nr_Guia =
                 Nvl(Vguiavencida.Nr_Guia_Operadora,
                     Vguiavencida.Nr_Guia_Prestador);
        
        Exception
          When Others Then
            Null;
        End;
      
        Prc_Insere_Log_Erro(Vguiavencida.Nr_Numero_Carteira,
                            Vguiavencida.Nr_Guia_Prestador,
                            Vguiavencida.Nr_Guia_Operadora,
                            Vguiavencida.Nr_Senha_Autorizacao,
                            Vguiavencida.Cd_Prestador,
                            Vguiavencida.Nm_Beneficiario,
                            --rVTissLoteGuia.DS_TP_PROTOCOLO,
                            '',
                            '',
                            'Guia Vencida: ' ||
                            Nvl(Vguiavencida.Nr_Guia_Operadora,
                                Vguiavencida.Nr_Guia_Prestador) ||
                            ' Na data de: ' || Vdatavencimento,
                            'G994',
                            'I',
                            'N');
      
        Commit;
      End;
    End Loop;
  
  Exception
    When Others Then
      Dbms_Output.Put_Line('exception-gral');
      Vexcecao      := Sqlerrm;
      Vexcecaolinha := Dbms_Utility.Format_Error_Backtrace;
      Vcoderro      := 'E999';
      Prc_Insere_Log_Erro(Vguiavencida.Nr_Numero_Carteira,
                          Vguiavencida.Nr_Guia_Prestador,
                          Vguiavencida.Nr_Guia_Operadora,
                          Vguiavencida.Nr_Senha_Autorizacao,
                          Vguiavencida.Cd_Prestador,
                          Vguiavencida.Nm_Beneficiario,
                          '',
                          '',
                          'EXCEPTION-GLOBAL! N�o foi possivel validar as regras. Favor entre em contato com a Operadora MSG: ' ||
                          Vexcecao || ' linha do erro: ' || Vexcecaolinha,
                          Vcoderro,
                          'E',
                          'N');
      Commit;
      If (Cguiavencida%Isopen) Then
        Close Cguiavencida;
      End If;
  End;

  /*  --Quantidade ultrapassa 3 casas
  
   Begin
     For Vquantidadeultrapassada In Cquantidadeultrapassada Loop
     
       Begin
       
         Prc_Insere_Log_Erro(Vquantidadeultrapassada.Nr_Numero_Carteira,
                             Vquantidadeultrapassada.Nr_Guia_Prestador,
                             Vquantidadeultrapassada.Nr_Guia_Operadora,
                             Vquantidadeultrapassada.Nr_Senha_Autorizacao,
                             Vquantidadeultrapassada.Cd_Prestador,
                             Vquantidadeultrapassada.Nm_Beneficiario,
                             --rVTissLoteGuia.DS_TP_PROTOCOLO,
                             '',
                             '',
                             'A quantidade do procedimento: ' ||
                             Vquantidadeultrapassada.Cd_Procedimento ||
                             ' Ultrapassa 3 casas',
                             'G993',
                             'I',
                             'N');
       
         Commit;
       End;
     End Loop;
   
   Exception
     When Others Then
       Dbms_Output.Put_Line('exception-gral');
       Vexcecao      := Sqlerrm;
       Vexcecaolinha := Dbms_Utility.Format_Error_Backtrace;
       Vcoderro      := 'E999';
       Prc_Insere_Log_Erro(Vquantidadeultrapassada.Nr_Numero_Carteira,
                           Vquantidadeultrapassada.Nr_Guia_Prestador,
                           Vquantidadeultrapassada.Nr_Guia_Operadora,
                           Vquantidadeultrapassada.Nr_Senha_Autorizacao,
                           Vquantidadeultrapassada.Cd_Prestador,
                           Vquantidadeultrapassada.Nm_Beneficiario,
                           '',
                           '',
                           'EXCEPTION-GLOBAL! N�o foi possivel validar as regras. Favor entre em contato com a Operadora MSG: ' ||
                           Vexcecao || ' linha do erro: ' || Vexcecaolinha,
                           Vcoderro,
                           'E',
                           'N');
       Commit;
       If (Cquantidadeultrapassada%Isopen) Then
         Close Cquantidadeultrapassada;
       End If;
   End;
  */
  -- Declara��o Nascido Vivo ou Obito

  Begin
    For Vdeclaracaonascidoouobtito In Cdeclaracaonascidoouobtito Loop
    
      Begin
      
        Prc_Insere_Log_Erro(Vdeclaracaonascidoouobtito.Nr_Numero_Carteira,
                            Vdeclaracaonascidoouobtito.Nr_Guia_Prestador,
                            Vdeclaracaonascidoouobtito.Nr_Guia_Operadora,
                            Vdeclaracaonascidoouobtito.Nr_Senha_Autorizacao,
                            Vdeclaracaonascidoouobtito.Cd_Prestador,
                            Vdeclaracaonascidoouobtito.Nm_Beneficiario,
                            --rVTissLoteGuia.DS_TP_PROTOCOLO,
                            '',
                            '',
                            'Declara��o do Nascido Vivo ou �bito N�o informada, 
                            ou n�o respeitou o limite de caracteres num�ricos (11)',
                            'G992',
                            'I',
                            'N');
      
        Commit;
      End;
    End Loop;
  
  Exception
    When Others Then
      Dbms_Output.Put_Line('exception-gral');
      Vexcecao      := Sqlerrm;
      Vexcecaolinha := Dbms_Utility.Format_Error_Backtrace;
      Vcoderro      := 'E999';
      Prc_Insere_Log_Erro(Vdeclaracaonascidoouobtito.Nr_Numero_Carteira,
                          Vdeclaracaonascidoouobtito.Nr_Guia_Prestador,
                          Vdeclaracaonascidoouobtito.Nr_Guia_Operadora,
                          Vdeclaracaonascidoouobtito.Nr_Senha_Autorizacao,
                          Vdeclaracaonascidoouobtito.Cd_Prestador,
                          Vdeclaracaonascidoouobtito.Nm_Beneficiario,
                          '',
                          '',
                          'EXCEPTION-GLOBAL! N�o foi possivel validar as regras. Favor entre em contato com a Operadora MSG: ' ||
                          Vexcecao || ' linha do erro: ' || Vexcecaolinha,
                          Vcoderro,
                          'E',
                          'N');
      Commit;
      If (Cdeclaracaonascidoouobtito%Isopen) Then
        Close Cdeclaracaonascidoouobtito;
      End If;
  End;

  --Declara��o �bito se motivo 45,65,66,67

  Begin
    For Vdeclaracaobtito In Cdeclaracaoobito Loop
    
      Begin
      
        Prc_Insere_Log_Erro(Vdeclaracaobtito.Nr_Numero_Carteira,
                            Vdeclaracaobtito.Nr_Guia_Prestador,
                            Vdeclaracaobtito.Nr_Guia_Operadora,
                            Vdeclaracaobtito.Nr_Senha_Autorizacao,
                            Vdeclaracaobtito.Cd_Prestador,
                            Vdeclaracaobtito.Nm_Beneficiario,
                            --rVTissLoteGuia.DS_TP_PROTOCOLO,
                            '',
                            '',
                            'Declara��o de �bito N�o informada, 
                            ou n�o respeitou o limite de caracteres num�ricos (11)',
                            'G991',
                            'I',
                            'N');
      
        Commit;
      End;
    End Loop;
  
  Exception
    When Others Then
      Dbms_Output.Put_Line('exception-gral');
      Vexcecao      := Sqlerrm;
      Vexcecaolinha := Dbms_Utility.Format_Error_Backtrace;
      Vcoderro      := 'E999';
      Prc_Insere_Log_Erro(Vdeclaracaobtito.Nr_Numero_Carteira,
                          Vdeclaracaobtito.Nr_Guia_Prestador,
                          Vdeclaracaobtito.Nr_Guia_Operadora,
                          Vdeclaracaobtito.Nr_Senha_Autorizacao,
                          Vdeclaracaobtito.Cd_Prestador,
                          Vdeclaracaobtito.Nm_Beneficiario,
                          '',
                          '',
                          'EXCEPTION-GLOBAL! N�o foi possivel validar as regras. Favor entre em contato com a Operadora MSG: ' ||
                          Vexcecao || ' linha do erro: ' || Vexcecaolinha,
                          Vcoderro,
                          'E',
                          'N');
      Commit;
      If (Cdeclaracaoobito%Isopen) Then
        Close Cdeclaracaoobito;
      End If;
  End;

  --Obriga participa��o para servi�os profissionais 

  Begin
    For Vobrigagrauparticipacao In Cobrigagrauparticipacao Loop
    
      Begin
      
        Prc_Insere_Log_Erro(Vobrigagrauparticipacao.Nr_Numero_Carteira,
                            Vobrigagrauparticipacao.Nr_Guia_Prestador,
                            Vobrigagrauparticipacao.Nr_Guia_Operadora,
                            Vobrigagrauparticipacao.Nr_Senha_Autorizacao,
                            Vobrigagrauparticipacao.Cd_Prestador,
                            Vobrigagrauparticipacao.Nm_Beneficiario,
                            --rVTissLoteGuia.DS_TP_PROTOCOLO,
                            '',
                            '',
                            'Grau de participa��o obrigat�rio para Servi�o Profissional: ' ||
                            Vobrigagrauparticipacao.Cd_Procedimento,
                            'G990',
                            'I',
                            'N');
      
        Commit;
      End;
    End Loop;
  
  Exception
    When Others Then
      Dbms_Output.Put_Line('exception-gral');
      Vexcecao      := Sqlerrm;
      Vexcecaolinha := Dbms_Utility.Format_Error_Backtrace;
      Vcoderro      := 'E999';
      Prc_Insere_Log_Erro(Vobrigagrauparticipacao.Nr_Numero_Carteira,
                          Vobrigagrauparticipacao.Nr_Guia_Prestador,
                          Vobrigagrauparticipacao.Nr_Guia_Operadora,
                          Vobrigagrauparticipacao.Nr_Senha_Autorizacao,
                          Vobrigagrauparticipacao.Cd_Prestador,
                          Vobrigagrauparticipacao.Nm_Beneficiario,
                          '',
                          '',
                          'EXCEPTION-GLOBAL! N�o foi possivel validar as regras. Favor entre em contato com a Operadora MSG: ' ||
                          Vexcecao || ' linha do erro: ' || Vexcecaolinha,
                          Vcoderro,
                          'E',
                          'N');
      Commit;
      If (Cobrigagrauparticipacao%Isopen) Then
        Close Cobrigagrauparticipacao;
      End If;
  End;

  If (Rprotocoloctamed.Id_Tiss_Mensagem_Retorno Is Not Null) Then
  
    Nqtderrostotal2 := 0;
  
    Select Count(*)
      Into Nqtderrostotal2
      From Dbaps.Log_Erro_Protocolo_Tiss
     Where Cd_Protocolo_Ctamed = Pcd_Protocolo_Ctamed
       And Cd_Erro In ('G999',
                       'G998',
                       'G997',
                       'G996',
                       'G995',
                       'G994',
                       'G993',
                       'G992',
                       'G991',
                       'G990');
  
    If Nqtderrostotal2 > 0 Then
    
      Update Dbaps.Tiss_Mensagem
         Set Ds_Msg_Erro = Nqtderrostotal2 || ' ERROS NO XML'
       Where Id = Rprotocoloctamed.Id_Tiss_Mensagem_Retorno;
    
      Update Dbaps.Protocolo_Ctamed p
         Set p.Cd_Status_Protocolo = 9,
             p.Ds_Rejeicao         = 'Erro de valida��o do XML Regras internas da operadora, E-mail de rejei��o enviado para destinat�rios. (PRC_VALIDA_PROT_TISS_TES_HOSP)'
       Where p.Cd_Protocolo_Ctamed = Pcd_Protocolo_Ctamed;
    
      Update Custom.Tiss_Controle_Protocolo Tc
         Set Tc.Sn_Validado = 'S', Tc.Cd_Status_Protocolo = 9
       Where Tc.Cd_Protocolo_Ctamed = Pcd_Protocolo_Ctamed;
      Commit;
    
      --Disparando e-mail
      Begin
      
        Begin
          Select Pc.Nr_Lote_Prestador
            Into Vloteprestador
            From Dbaps.Protocolo_Ctamed Pc
           Where Pc.Cd_Protocolo_Ctamed = Pcd_Protocolo_Ctamed;
        Exception
          When Others Then
            Null;
          
        End;
      
        Vhtml := Custom.Fnc_Retorna_Html(Pcd_Protocolo => Pcd_Protocolo_Ctamed);
      
        Vtamanhoemail := Dbms_Lob.Getlength(Vhtml); --Pegando o tamanho do e-mail em bytes.
      
        Update Custom.Tiss_Controle_Protocolo Tc
           Set Tc.Tamanho_Email_Bytes = Vtamanhoemail
         Where Tc.Cd_Protocolo_Ctamed = Pcd_Protocolo_Ctamed;
        Commit;
      
        If (Vtamanhoemail <= 17000000) Then
          --fazer o ajuste para a coluna TAMANHO_EMAIL_BYTES (17000000 --> 17Mg) m�ximo 18 mb para enviar e-mail.
        
          Custom.Pkg_Rotinas_Atendmvs.Prc_Envia_Email_V2('moises.neto@unimedsorocaba.coop.br',
                                                         'moises.neto@unimedsorocaba.coop.br',
                                                         'PROTOCOLO REJEITADO :' ||
                                                         Pcd_Protocolo_Ctamed ||
                                                         ' LOTE PRESTADOR: ' ||
                                                         Vloteprestador,
                                                         Vhtml);
        
          Custom.Pkg_Rotinas_Atendmvs.Prc_Envia_Email_V2('ana.baena@unimedsorocaba.coop.br',
                                                         'ana.baena@unimedsorocaba.coop.br',
                                                         'PROTOCOLO REJEITADO :' ||
                                                         Pcd_Protocolo_Ctamed ||
                                                         ' LOTE PRESTADOR: ' ||
                                                         Vloteprestador,
                                                         Vhtml);
        
          Custom.Pkg_Rotinas_Atendmvs.Prc_Envia_Email_V2('renan.rosolen@unimedsorocaba.coop.br',
                                                         'renan.rosolen@unimedsorocaba.coop.br',
                                                         'PROTOCOLO REJEITADO :' ||
                                                         Pcd_Protocolo_Ctamed ||
                                                         ' LOTE PRESTADOR: ' ||
                                                         Vloteprestador,
                                                         Vhtml);
        
          Custom.Pkg_Rotinas_Atendmvs.Prc_Envia_Email_V2('maria.vieira@unimedsorocaba.coop.br',
                                                         'maria.vieira@unimedsorocaba.coop.br',
                                                         'PROTOCOLO REJEITADO :' ||
                                                         Pcd_Protocolo_Ctamed ||
                                                         ' LOTE PRESTADOR: ' ||
                                                         Vloteprestador,
                                                         Vhtml);
        
          Begin
            If (Vhtml Is Not Null) Then
            
              Update Custom.Tiss_Controle_Protocolo Tc
                 Set Tc.Sn_Envio_Email = 'S',
                     Tc.Email          = Vhtml,
                     Tc.Dt_Envio_Email = Sysdate
               Where Tc.Cd_Protocolo_Ctamed = Pcd_Protocolo_Ctamed;
            
            End If;
          End;
        End If;
      End;
    
    Else
    
      Update Dbaps.Tiss_Mensagem
         Set Ds_Msg_Erro = Null
       Where Id = Rprotocoloctamed.Id_Tiss_Mensagem_Retorno;
    
    End If;
  
  End If;

  Commit;

Exception
  When Others Then
    Dbms_Output.Put_Line('exception-gral');
    Vexcecao      := Sqlerrm;
    Vexcecaolinha := Dbms_Utility.Format_Error_Backtrace;
    Vcoderro      := 'E999';
    Prc_Insere_Log_Erro(Rvtissloteguia.Nr_Numero_Carteira,
                        Rvtissloteguia.Nr_Guia_Prestador,
                        Rvtissloteguia.Nr_Guia_Operadora,
                        Rvtissloteguia.Nr_Senha_Autorizacao,
                        Rvtissloteguia.Cd_Prestador,
                        Rvtissloteguia.Nm_Beneficiario,
                        '',
                        '',
                        'EXCEPTION-GLOBAL! N�o foi possivel validar as regras. Favor entre em contato com a Operadora MSG: ' ||
                        Vexcecao || ' linha do erro: ' || Vexcecaolinha,
                        Vcoderro,
                        'E',
                        'N');
    Commit;
End;
/
