Create Table CUSTOM.Tiss_Controle_Protocolo
(
ID_CONTROLE_PROTOCOLO Number,
cd_protocolo_ctamed Number Not Null,
CD_STATUS_PROTOCOLO Number(1),
DT_ENVIO Date,
DT_INCLUSAO Date,
DT_LOG Date Default Sysdate,
SN_VALIDADO Char(1) Default 'N',
Constraint PK_CONTROLE_PROTOCOLO Primary Key (ID_CONTROLE_PROTOCOLO)
)


Create Sequence seq_ID_CONTROLE_PROTOCOLO
Start With 1
Increment By 1;

Grant Select On custom.seq_ID_CONTROLE_PROTOCOLO To dbaps;

Grant All On Tiss_Controle_Protocolo To dbaps;


Create Table custom.Tiss_Controle_Protocolo_erro
(
id_log_erro Number,
cd_protocolo_ctamed Number,
DT_LOG_erro Date Default Sysdate,
erro_ora Varchar2(500) Not Null,
Constraint PK_CONTROLE_PROTOCOLO_erro Primary Key (id_log_erro)
)

Create Sequence  seq_ID_CONTROLE_PROTOCOLO_erro
Start With 1
Increment By 1;
 Grant Select On custom.seq_ID_CONTROLE_PROTOCOLO_erro To dbaps;

Grant All On Tiss_Controle_Protocolo_erro To dbaps;


Select * From Custom.Tiss_Controle_Protocolo

Delete From Custom.Tiss_Controle_Protocolo
