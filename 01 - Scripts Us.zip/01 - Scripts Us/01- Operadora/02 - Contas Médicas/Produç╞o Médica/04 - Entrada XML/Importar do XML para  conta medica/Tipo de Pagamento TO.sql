
Select Vc.Cd_Conta_Medica,
       Vc.Cd_Lancamento,
       Vc.Cd_Procedimento,
       (Select Po.Ds_Procedimento
          From Dbaps.Procedimento Po
         Where Po.Cd_Procedimento = Vc.Cd_Procedimento) Ds_Procedimento,
       Vc.Tp_Pagamento,
       Vc.Cd_Prestador_Pagamento,
       (Select Pr.Nm_Prestador
          From Dbaps.Prestador Pr
         Where Pr.Cd_Prestador = Vc.Cd_Prestador_Pagamento) Nm_Prestador
  From Dbaps.v_Ctas_Medicas Vc
 Where Vc.Cd_Lote = 349749
   And Vc.Tp_Pagamento = 'TO';
   

Declare
Begin

  For Ix In (Select Vc.Cd_Conta_Medica,
       Vc.Cd_Lancamento,
       Vc.Cd_Procedimento,
       (Select Po.Ds_Procedimento
          From Dbaps.Procedimento Po
         Where Po.Cd_Procedimento = Vc.Cd_Procedimento) Ds_Procedimento,
       Vc.Tp_Pagamento,
       Vc.cd_prestador_pagamento,
       (Select pr.nm_prestador From dbaps.prestador pr 
       Where pr.cd_prestador = vc.cd_prestador_pagamento) nm_prestador
  From Dbaps.v_Ctas_Medicas Vc
 Where Vc.Cd_Lote = 349749
   And Vc.Tp_Pagamento = 'TO') Loop
  
    Begin
    
      UPDATE dbaps.itremessa_prestador_equipe ite
      Set ite.tp_pagamento = 'HM'
      Where ite.cd_remessa = Ix.Cd_Conta_Medica
      And ite.cd_lancamento = Ix.Cd_Lancamento;
    
    Exception
      When Others Then
        Rollback;
        Raise_Application_Error(-20002,
                                'Falha: ' || Sqlerrm || ' Cd_Conta_Medica: ' ||
                                Ix.Cd_Conta_Medica || ' Lcto: ' || Ix.Cd_Lancamento);
    End;
  End Loop;

Exception
  When Others Then
    Rollback;
    Raise_Application_Error(-20001, 'Falha: ' || Sqlerrm);
End;
/

Select Vc.Cd_Conta_Medica,
       Vc.Cd_Lancamento,
       Vc.Cd_Procedimento,
       (Select Po.Ds_Procedimento
          From Dbaps.Procedimento Po
         Where Po.Cd_Procedimento = Vc.Cd_Procedimento) Ds_Procedimento,
       Vc.Tp_Pagamento,
       Vc.Cd_Prestador_Pagamento,
       (Select Pr.Nm_Prestador
          From Dbaps.Prestador Pr
         Where Pr.Cd_Prestador = Vc.Cd_Prestador_Pagamento) Nm_Prestador
  From Dbaps.v_Ctas_Medicas Vc
 Where Vc.Cd_Lote = 349749
   And Vc.Tp_Pagamento = 'TO';

Select Vc.Cd_Conta_Medica,
       Vc.Cd_Lancamento,
       Vc.Cd_Procedimento,
       (Select Po.Ds_Procedimento
          From Dbaps.Procedimento Po
         Where Po.Cd_Procedimento = Vc.Cd_Procedimento) Ds_Procedimento,
       Vc.Tp_Pagamento,
       Vc.Cd_Prestador_Pagamento,
       (Select Pr.Nm_Prestador
          From Dbaps.Prestador Pr
         Where Pr.Cd_Prestador = Vc.Cd_Prestador_Pagamento) Nm_Prestador
  From Dbaps.v_Ctas_Medicas Vc
 Where Vc.Cd_Lote = 349749;


   
   
   Select * From dbaps.remessa_prestador rp
   Where rp.cd_remessa = 9839508;
   
   Select * From dbaps.lote l
   Where l.cd_lote = 349749;
   
   
   Select * From dbaps.log_transferencia_lote ll
   Where ll.cd_lote_origem = 349749
   Or ll.cd_lote_destino = 349749;
   
   --- dbaps.fnc_tiss_importa_lot_guia


Select * From All_Source a
Where upper(a.TEXT) Like Upper('%Tipo de pagamento n�o permitido para Unimed%');

TRG_ITREMESSA_PRESTADOR_EQUIPE
DBAPS.PRC_MIGRA_CONTA_AMBULATORIAL
