
Select Rp.Nr_Guia, Itp.*
  From Dbaps.Itremessa_Prestador Itp, Dbaps.Remessa_Prestador Rp
 Where Itp.Cd_Remessa = Rp.Cd_Remessa
   And Rp.Cd_Lote = 349749
   And rp.nr_guia = 79533039;

Select v.DT_PROCEDIMENTO, To_Date(v.Dt_Procedimento, 'YYYY-MM-DD'), v.*
  From Dbaps.v_Tiss_Lote_Guia v
 Where v.Nr_Guia_Operadora = '79533039'
 And v.CD_PROCEDIMENTO = '10101039';

Select Rp.Cd_Lote,
       Rp.Nr_Guia,
       To_Date(Itp.Dt_Realizado, 'DD/MM/YYYY'),
       Itp.*,
       Nvl((Select v.Vl_Procedimento
             From Dbaps.v_Tiss_Lote_Guia v
            Where v.Nr_Guia_Operadora = To_Char(Rp.Nr_Guia)
              And v.Cd_Procedimento = Itp.Cd_Procedimento
              And To_Date(v.Dt_Procedimento, 'YYYY-MM-DD') =
                  To_Date(Itp.Dt_Realizado, 'DD/MM/YYYY')
              And Rownum = 1),
           Itp.Vl_Unit_Cobrado) Vl_Procedimento
  From Dbaps.Itremessa_Prestador Itp, Dbaps.Remessa_Prestador Rp
 Where Rp.Cd_Remessa = Itp.Cd_Remessa
   And Rp.Cd_Lote = 349749
   And Itp.Vl_Unit_Pago = 0
   And Itp.Cd_Procedimento = '10101039'
   /*And rp.nr_guia = 79533039*/;

/*
ORA-00604: ocorreu um erro no n�vel 1 SQL recursivo
ORA-06502: PL/SQL: erro: buffer de string de caracteres pequeno demais num�rico ou de valor
ORA-06512: em line 18
ORA-20001: Falha: ORA-20001: Falha Loop: ORA-20002: Falha Update Dbaps.Itremessa_Prestador_Equipe: ORA-20002: Esta atualiza��o n�o ser� poss�vel porque a conta a pagar para fatura/prestador: 32571/70272 j� foi gerada para o financeiro. Contas a Pagar: 473363
ORA-06512: em "DBAPS.PRC_MVS_VERIFICA_LCTO", line 127
ORA-06512: em "DBAPS.TRG_ITREMESSA_PRESTADOR_EQUIPE", line 45
ORA-04088: erro durante a execu��o do gatilho 'DBAPS.TRG_ITREMESSA_PRESTADOR_EQUIPE' Cd_Conta_Medica: 9990125 Cd_Lancamento: 1
ORA-06512: em line 227
*/


Alter trigger DBAPS.TRG_ITREMESSA_PRESTADOR_EQUIPE Disable;

Declare

  v_Equipe          Number := 0;
  v_Nomeprestador   Varchar2(4000);
  v_Vl_Procedimento Number := 0;
  v_Cd_Prestador    Number := 0;

  Ncdlancamentoequipemedica Number := 0;

  Cursor c_Existeequipe(p_Conta Number, p_Lcto Number) Is
    Select Ite.Cd_Equipe_Medica_Lancmto
      From Dbaps.Itremessa_Prestador_Equipe Ite
     Where Ite.Cd_Remessa = p_Conta
       And Ite.Cd_Lancamento = p_Lcto;

  Cursor c_Nomeprestador(p_Cd_Prestador Number) Is
    Select Pr.Nm_Prestador
      From Dbaps.Prestador Pr
     Where Pr.Cd_Prestador = p_Cd_Prestador;

  Cursor c_Prestadorlote(p_Cdlote Number) Is
    Select l.Cd_Prestador From Dbaps.Lote l Where l.Cd_Lote = p_Cdlote;

Begin

  For Ix In (Select Rp.Cd_Lote,
                    Itp.*,
                    Nvl((Select v.Vl_Procedimento
                          From Dbaps.v_Tiss_Lote_Guia v
                         Where v.Nr_Guia_Operadora = To_Char(Rp.Nr_Guia)
                           And v.Cd_Procedimento = Itp.Cd_Procedimento
                           And To_Date(v.Dt_Procedimento, 'YYYY-MM-DD') =
                               To_Date(Itp.Dt_Realizado, 'DD/MM/YYYY')
                           And Rownum = 1),
                        Itp.Vl_Unit_Cobrado) Vl_Procedimento
               From Dbaps.Itremessa_Prestador Itp,
                    Dbaps.Remessa_Prestador   Rp
              Where Rp.Cd_Remessa = Itp.Cd_Remessa
                And Rp.Cd_Lote = 349749
                And Itp.Vl_Unit_Pago = 0
                And Itp.Cd_Procedimento = '10101039') Loop
  
    Begin
    
      Begin
      
        v_Vl_Procedimento := To_Number(Translate(Nvl(Ix.Vl_Procedimento, 0),
                                                 '.',
                                                 ','));
      Exception
        When Others Then
          Rollback;
          Raise_Application_Error(-20002,
                                  'Falha Ix.Vl_Procedimento: ' ||
                                  Ix.Vl_Procedimento || ' ' || Sqlerrm ||
                                  ' Cd_Conta_Medica: ' || Ix.Cd_Remessa ||
                                  ' Cd_Lancamento: ' || Ix.Cd_Lancamento);
      End;
    
      If (v_Vl_Procedimento > 0) Then
      
        Ncdlancamentoequipemedica := Ncdlancamentoequipemedica + 1;
      
        Begin
        
          Update Dbaps.Itremessa_Prestador Itp
             Set Itp.Vl_Unit_Pago = v_Vl_Procedimento
           Where Itp.Cd_Remessa = Ix.Cd_Remessa
             And Itp.Cd_Lancamento = Ix.Cd_Lancamento;
        
        Exception
          When Others Then
            Rollback;
            Raise_Application_Error(-20002,
                                    'Falha Update Dbaps.Itremessa_Prestador: ' ||
                                    Sqlerrm || ' Cd_Conta_Medica: ' ||
                                    Ix.Cd_Remessa || ' Cd_Lancamento: ' ||
                                    Ix.Cd_Lancamento);
        End;
      
        Begin
        
          Open c_Existeequipe(Ix.Cd_Remessa, Ix.Cd_Lancamento);
          Fetch c_Existeequipe
            Into v_Equipe;
          Close c_Existeequipe;
        
        Exception
          When Others Then
            Rollback;
            Raise_Application_Error(-20002,
                                    'Falha c_Existeequipe: ' || Sqlerrm ||
                                    ' Cd_Conta_Medica: ' || Ix.Cd_Remessa ||
                                    ' Cd_Lancamento: ' || Ix.Cd_Lancamento);
        End;
      
        If (v_Equipe > 0) Then
        
          Begin
            Update Dbaps.Itremessa_Prestador_Equipe Ite
               Set Ite.Vl_Unit_Pago = v_Vl_Procedimento
             Where Ite.Cd_Remessa = Ix.Cd_Remessa
               And Ite.Cd_Lancamento = Ix.Cd_Lancamento
               And Ite.Cd_Equipe_Medica_Lancmto = v_Equipe;
          Exception
            When Others Then
              Rollback;
              Raise_Application_Error(-20002,
                                      'Falha Update Dbaps.Itremessa_Prestador_Equipe: ' ||
                                      Sqlerrm || ' Cd_Conta_Medica: ' ||
                                      Ix.Cd_Remessa || ' Cd_Lancamento: ' ||
                                      Ix.Cd_Lancamento);
          End;
        
        Else
        
          If (Nvl(Ix.Cd_Prestador, 0) > 0) Then
          
            v_Cd_Prestador := Ix.Cd_Prestador;
          
          Else
          
            Begin
              Open c_Prestadorlote(Ix.Cd_Lote);
              Fetch c_Prestadorlote
                Into v_Cd_Prestador;
              Close c_Prestadorlote;
            
            Exception
              When Others Then
                Rollback;
                Raise_Application_Error(-20002,
                                        'Falha c_PrestadorLote: ' ||
                                        Sqlerrm || ' Cd_Conta_Medica: ' ||
                                        Ix.Cd_Remessa || ' Cd_Lancamento: ' ||
                                        Ix.Cd_Lancamento);
            End;
          
          End If;
        
          Begin
            Open c_Nomeprestador(v_Cd_Prestador);
            Fetch c_Nomeprestador
              Into v_Nomeprestador;
            Close c_Nomeprestador;
          Exception
            When Others Then
              Rollback;
              Raise_Application_Error(-20002,
                                      'Falha c_Nomeprestador: ' || Sqlerrm ||
                                      ' Cd_Conta_Medica: ' || Ix.Cd_Remessa ||
                                      ' Cd_Lancamento: ' ||
                                      Ix.Cd_Lancamento);
          End;
        
          Begin
          
            Insert Into Dbaps.Itremessa_Prestador_Equipe
              (Cd_Remessa,
               Cd_Lancamento,
               Cd_Ati_Med,
               Ds_Ati_Med,
               Cd_Prestador,
               Nm_Prestador,
               Vl_Conta,
               Vl_Pago,
               Vl_Calculado,
               Tp_Situacao,
               Sn_Pago,
               Vl_Percentual,
               Cd_Equipe_Medica_Lancmto,
               Tp_Pagamento,
               Vl_Unit_Cobrado,
               Vl_Unit_Pago,
               Vl_Unit_Taxa_Cobrado, -- (%)
               Vl_Unit_Taxa_Pago, -- (%)        
               Vl_Unit_Taxa_Administrativa, -- (%)
               Vl_Taxa_Administrativa -- (R$)
               
               )
            Values
              (Ix.Cd_Remessa,
               Ix.Cd_Lancamento,
               8, -- Padr�o importa��o XML
               'CLINICO', -- Padr�o importa��o XML
               v_Cd_Prestador,
               v_Nomeprestador,
               (v_Vl_Procedimento * Ix.Qt_Pago),
               (v_Vl_Procedimento * Ix.Qt_Pago), -- VL_PAGO
               v_Vl_Procedimento, -- VL_CALCULADO
               'NA', -- TP_SITUACAO
               'N', -- SN_PAGO
               '100', -- Padr�o importa��o XML
               Ncdlancamentoequipemedica,
               'HM', -- Padr�o importa��o XML
               v_Vl_Procedimento,
               v_Vl_Procedimento,
               0,
               0,
               0,
               0);
          
          Exception
            When Others Then
              Rollback;
              Raise_Application_Error(-20002,
                                      'Falha  Insert Dbaps.Itremessa_Prestador_Equipe: ' ||
                                      Sqlerrm || ' Cd_Conta_Medica: ' ||
                                      Ix.Cd_Remessa || ' Cd_Lancamento: ' ||
                                      Ix.Cd_Lancamento);
          End; -- Fim Insert
        
        End If; --- If(v_equipe > 0)
      
      End If; -- If (Ix.Vl_Procedimento > 0)
    
    Exception
      When Others Then
        Rollback;
        Raise_Application_Error(-20001, 'Falha Loop: ' || Sqlerrm);
    End;
  End Loop;

Exception
  When Others Then
    Rollback;
    Raise_Application_Error(-20001, 'Falha: ' || Sqlerrm);
  
End;
/

Alter trigger DBAPS.TRG_ITREMESSA_PRESTADOR_EQUIPE Enable;

  Select Itp.*,
         Nvl((Select v.Vl_Procedimento
               From Dbaps.v_Tiss_Lote_Guia v
              Where v.Nr_Guia_Operadora = To_Char(Rp.Nr_Guia)
                And v.Cd_Procedimento = Itp.Cd_Procedimento
                And To_Date(v.Dt_Procedimento, 'YYYY-MM-DD') =
                    To_Date(Itp.Dt_Realizado, 'DD/MM/YYYY')
                And Rownum = 1),
             Itp.Vl_Unit_Cobrado) Vl_Procedimento
    From Dbaps.Itremessa_Prestador Itp, Dbaps.Remessa_Prestador Rp
   Where Rp.Cd_Remessa = Itp.Cd_Remessa
     And Rp.Cd_Lote = 349749
     And Itp.Vl_Unit_Pago = 0
     And Itp.Cd_Procedimento = '10101039';

Select Vc.Tp_Conta,
       Vc.Cd_Conta_Medica,
       Vc.Cd_Lancamento,
       Vc.Cd_Procedimento,
       (Select Po.Ds_Procedimento
          From Dbaps.Procedimento Po
         Where Po.Cd_Procedimento = Vc.Cd_Procedimento) Ds_Procedimento,
       Vc.Tp_Pagamento,
       Vc.Cd_Prestador_Pagamento,
       (Select Pr.Nm_Prestador
          From Dbaps.Prestador Pr
         Where Pr.Cd_Prestador = Vc.Cd_Prestador_Pagamento) Nm_Prestador,
       Vc.Vl_Unit_Pago,
       Vc.Vl_Unit_Pago_Original,
       Vc.Vl_Unit_Cobrado
  From Dbaps.v_Ctas_Medicas Vc
 Where Vc.Cd_Lote = 349749
   And Vc.Vl_Unit_Pago = 0
   And Vc.Cd_Procedimento = '10101039';
   
Select Itp.*,
         Nvl((Select v.Vl_Procedimento
               From Dbaps.v_Tiss_Lote_Guia v
              Where v.Nr_Guia_Operadora = To_Char(Rp.Nr_Guia)
                And v.Cd_Procedimento = Itp.Cd_Procedimento
                And To_Date(v.Dt_Procedimento, 'YYYY-MM-DD') =
                    To_Date(Itp.Dt_Realizado, 'DD/MM/YYYY')
                And Rownum = 1),
             Itp.Vl_Unit_Cobrado) Vl_Procedimento
    From Dbaps.Itremessa_Prestador Itp, Dbaps.Remessa_Prestador Rp
   Where Rp.Cd_Remessa = Itp.Cd_Remessa
     And Rp.Cd_Lote = 349749
     And Itp.Vl_Unit_Pago > 0
     And Itp.Cd_Procedimento = '10101039';
