
Select Vc.Cd_Lote, Vc.Cd_Conta_Medica, Vc.Cd_Lancamento, Vc.Cd_Procedimento
  From Dbaps.v_Ctas_Medicas Vc
 Where Vc.Cd_Lote = 349749
   And Vc.Cd_Prestador_Pagamento Is Null;
   
/*
ORA-20002:  Falha: ORA-20002:  Falha: ORA-20002: Esta atualiza��o n�o ser� poss�vel porque a conta a pagar para fatura/prestador: 32571/70272 j� foi gerada para o financeiro. Contas a Pagar: 473363
ORA-06512: em "DBAPS.PRC_MVS_VERIFICA_LCTO", line 127
ORA-06512: em "DBAPS.TRG_ITREMESSA_PRESTADOR_EQUIPE", line 45
ORA-04088: erro durante a execu��o do gatilho 'DBAPS.TRG_ITREMESSA_PRESTADOR_EQUIPE' Lote: 349749 Conta: 9990125 Lcto: 1
ORA-06512: em line 34
*/


Alter Trigger DBAPS.TRG_ITREMESSA_PRESTADOR_EQUIPE Disable;

Declare
Begin

  For Ix In (Select Vc.Cd_Lote,
                    Vc.Cd_Conta_Medica,
                    Vc.Cd_Lancamento,
                    Vc.Cd_Procedimento,
                    Vc.Tp_Pagamento
               From Dbaps.v_Ctas_Medicas Vc
              Where Vc.Cd_Lote = 349749
                And Vc.Cd_Prestador_Pagamento Is Null) Loop
    Begin
      Update Dbaps.Itremessa_Prestador_Equipe Ite
         Set Ite.Cd_Prestador_Pagamento = '300100'
       Where Ite.Cd_Remessa = Ix.Cd_Conta_Medica
         And Ite.Cd_Lancamento = Ix.Cd_Lancamento
         And Ite.Tp_Pagamento = Ix.Tp_Pagamento;
    
    Exception
      When Others Then
        Rollback;
        Raise_Application_Error(-20002,
                                ' Falha: ' || Sqlerrm || ' Lote: ' ||
                                Ix.Cd_Lote || ' Conta: ' ||
                                Ix.Cd_Conta_Medica || ' Lcto: ' ||
                                Ix.Cd_Lancamento);
      
    End;
  End Loop;

Exception
  When Others Then
    Rollback;
    Raise_Application_Error(-20002, ' Falha: ' || Sqlerrm);
End;
/

Alter Trigger DBAPS.TRG_ITREMESSA_PRESTADOR_EQUIPE Enable;

Select Vc.Cd_Lote, Vc.Cd_Conta_Medica, Vc.Cd_Lancamento, Vc.Cd_Procedimento
  From Dbaps.v_Ctas_Medicas Vc
 Where Vc.Cd_Lote = 349749
   And Vc.Cd_Prestador_Pagamento Is Null;
