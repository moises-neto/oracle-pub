/*
Concluimos hoje o fechamento da folha de prestador juridicos, necessario apenas verificar se 
todas as contas em que o cd_prestador_pagamento � JURIDICO (cd_tip_prestador == 9,12,18,) e TP_PAGCOB = CP OU PN s
e gerou tudo cd_repasse_prestador.
*/

Select v.Tp_Conta,
       v.Cd_Fatura,
       v.Cd_Lote,
       v.Cd_Conta_Medica,
       v.Cd_Procedimento,
       v.Cd_Lancamento,
       v.Vl_Total_Pago,
       v.Tp_Pagcob,
       v.Tp_Situacao_Conta,
       v.Tp_Situacao_Itconta,
       v.Cd_Motivo,
       v.Cd_Motivo_Alta,
       v.Cd_Motivo_Conta,
       v.Cd_Motivo_Itconta,
       v.Cd_Motivo_Equipe,
       v.Cd_Prestador,
       (Select p.Nm_Prestador
          From Dbaps.Prestador p
         Where p.Cd_Prestador = v.Cd_Prestador) As Nm_Prestador,
       (Select Distinct Vf.Cd_Mens_Contrato
          From Dbaps.v_Ctas_Medicas_Fatura Vf
         Where Vf.Cd_Lote = v.Cd_Lote
           And Vf.Cd_Conta_Medica = v.Cd_Conta_Medica
           And Vf.Cd_Lancamento = v.Cd_Lancamento
              
           And Rownum = 1) As Mens_Contrato,
       v.Cd_Repasse_Prestador,
       v.Cd_Prestador_Pagamento,
       p.Cd_Tip_Prestador

  From v_Ctas_Medicas v, Dbaps.Prestador p
 Where p.Cd_Prestador = v.Cd_Prestador_Pagamento
   And v.Dt_Competencia = To_Char(Sysdate, 'YYYYMM')
   And v.Tp_Situacao_Conta In ('AA', 'AT')
   And v.Tp_Situacao_Itconta In ('AA', 'AT')
   And v.Tp_Fatura = 'P'
      -- And v.Tp_Situacao_Equipe In ('AA', 'AT')
   And v.Tp_Pagcob In ('CP', 'PN')
   And p.Cd_Tip_Prestador In(7,0,3,14) --mudar os tipos de prestadores
      -- And p.Cd_Tip_Prestador In (9,12,18,23)
   And v.Cd_Repasse_Prestador Is Null;

--- Update dbaps.remesa
/*
 Begin
 
   For i In (Select v.Cd_Conta_Medica, v.Cd_Lancamento
               From v_Ctas_Medicas v, Dbaps.Prestador p
              Where p.Cd_Prestador = v.Cd_Prestador
                And v.Dt_Competencia = '202209'
                And v.Tp_Situacao_Conta In ('AA', 'AT')
                And v.Tp_Situacao_Itconta In ('AA', 'AT')
                And v.Tp_Situacao_Equipe In ('AA', 'AT')
                And v.Tp_Pagcob In ('CP', 'PN')
                And v.Cd_Prestador_Principal = 1001153
                   -- And p.Cd_Tip_Prestador In (18, 12, 9, 23)
                And v.Cd_Repasse_Prestador Is Null) Loop
   
     Begin
     
       --sadt Itens
       Update Dbaps.Itremessa_Prestador Ipe
          Set Ipe.Tp_Pagcob = 'NN'
        Where Ipe.Cd_Remessa = i.Cd_Conta_Medica
          And Ipe.Cd_Lancamento = i.Cd_Lancamento;
     End;
   
     Dbms_Output.Put_Line('Conta: ' || i.Cd_Conta_Medica);
   End Loop;
 
 End;
     */
