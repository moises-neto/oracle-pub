-- profissional pagamento
Select v.Cd_Fatura,
       v.Cd_Protocolo_Ctamed,
       v.Cd_Tipo_Atendimento,
       v.Cd_Lote,
       v.Cd_Conta_Medica,
       v.Cd_Lancamento,
       v.Cd_Prestador Prof_Executante,
       (Select Pre.Nm_Prestador
          From Dbaps.Prestador Pre
         Where Pre.Cd_Prestador = v.Cd_Prestador) Nm_Prof_Executante,
       v.Cd_Prestador_Pagamento Prest_Pagamento,
       (Select Pre.Nm_Prestador
          From Dbaps.Prestador Pre
         Where Pre.Cd_Prestador = v.Cd_Prestador_Pagamento) Nm_Prest_Pagamento
  From v_Ctas_Medicas v
 Where 1 = 1
   And v.Dt_Competencia = '202306'
      -- And v.Tp_Situacao_Conta In ('AA', 'AT')
      -- And v.cd_procedimento <> '10101012'
   And Exists (Select 1
          From Prestador p
         Where p.Cd_Prestador = v.Cd_Prestador
           And p.Cd_Tip_Prestador = 27)
   And Exists
 (Select 1
          From Prestador p
         Where p.Cd_Prestador = v.Cd_Prestador_Pagamento --PAGAMENTOS PARA COOPERADOS.
           And p.Cd_Tip_Prestador = (0)
           And Exists
         (Select 1
                  From Dbaps.Prestador_Associado Pa, Dbaps.Prestador Pp
                 Where Pa.Cd_Prestador = Pp.Cd_Prestador -- UNINDO PRESTADOR PJ 27
                   And Pp.Cd_Tip_Prestador = 27
                   And Pa.Cd_Prestador_Associado = p.Cd_Prestador -- EXISTS UM PRESTADOR PJ (ASSOCIANDO UM COOPERADO).
                   And Pa.Dt_Termino Is Null))
 Order By v.Cd_Lote, v.Cd_Conta_Medica, v.Cd_Lancamento;

/* 
 Select * From PRESTADOR_ASSOCIADO PP
 Where PP.CD_PRESTADOR_ASSOCIADO = 70385
*/
