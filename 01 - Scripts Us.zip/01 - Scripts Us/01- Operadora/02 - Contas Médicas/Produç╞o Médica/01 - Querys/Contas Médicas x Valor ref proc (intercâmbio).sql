----interc�mbio

/*
Nacional = '1001
Estadual = '1002'
994% = '1003'
*/
 Create Table temp_acerto_202306_coop_intercambio As 
Select 'NACIONAL' As Tp_Unimed,
       v.Tp_Conta,
       v.Cd_Protocolo_Ctamed,
       v.Cd_Fatura,
       v.Cd_Lote,
       v.Cd_Conta_Medica,
       v.Nr_Guia,
       v.Cd_Unimed_Origem,
       v.Nr_Carteira_Beneficiario,
       (Select p.Cd_Grupo_Procedimento
          From Dbaps.Procedimento p
         Where p.Cd_Procedimento = v.Cd_Procedimento) As Grupo_Procedimento,
       v.Cd_Procedimento,
       v.Ds_Procedimento,
       v.Dt_Realizado,
       v.Qt_Pago,
       v.Cd_Lancamento,
       v.Cd_Lancamento_Equipe,
       v.Cd_Prestador As Cd_Prestador_Executor,
       (Select p.Nm_Prestador
          From Dbaps.Prestador p
         Where p.Cd_Prestador = v.Cd_Prestador) As Nm_Prestador_Executante,
       (Select p.Cd_Tip_Prestador
          From Dbaps.Prestador p
         Where p.Cd_Prestador = v.Cd_Prestador) As Tipo_Prestador_Executante,
       
       v.Cd_Prestador_Pagamento As Cd_Prestador_Pagamento,
       (Select p.Nm_Prestador
          From Dbaps.Prestador p
         Where p.Cd_Prestador = v.Cd_Prestador_Pagamento) As Nm_Prestador_Pagamento,
       (Select p.Cd_Tip_Prestador
          From Dbaps.Prestador p
         Where p.Cd_Prestador = v.Cd_Prestador_Pagamento) As Tipo_Prestador_Pagamento,
       v.Vl_Percentual_Pago,
       v.Cd_Atividade_Medica,
       v.Cd_Via_Acesso,
       v.Vl_Unit_Pago,
       Sum(v.Vl_Total_Pago) As Vl_Total_Pago,
       Sum(v.Vl_Total_Pago) / v.Qt_Pago As Divisao,
       (Select Vp.Vl_Referencia
          From Valor_Ref_Proc Vp
         Where Vp.Cd_Procedimento = v.Cd_Procedimento
           And Vp.Cd_Tabela = 1001
           And Trunc(Vp.Dt_Vigencia) =
               (Select Max(Trunc(Vpp.Dt_Vigencia))
                  From Valor_Ref_Proc Vpp
                 Where Vpp.Cd_Procedimento = Vp.Cd_Procedimento
                   And Vpp.Cd_Tabela = Vpp.Cd_Tabela
                   And v.Dt_Realizado >= Vpp.Dt_Vigencia
                   And Vpp.Cd_Tabela = 1001)
        
        ) As Valor_Ref_Proc_Mais_Vigente,
       (Select Distinct f.cd_mens_contrato 
       From v_Ctas_medicas_fatura f 
       Where  f.dt_competencia = v.dt_competencia
       And f.cd_conta_medica = v.cd_conta_medica 
        And f.cd_lancamento = v.cd_lancamento
     And f.cd_lancamento_equipe = v.cd_lancamento_equipe
     ) As mens_contrato 
  From v_Ctas_Medicas v
 Where v.Dt_Competencia = '202307'
   And v.Tp_Situacao_Conta In ('AA', 'AT')
   And v.Tp_Situacao_Itconta In ('AA', 'AT')
   And v.Tp_Situacao_Equipe In ('AA', 'AT')
   And v.Tp_Pagcob In ('CP', 'PN')
   And v.Cd_Tip_Acomodacao = '7'
   And v.Tp_Pagamento = 'HM'
   And Substr(v.Nr_Carteira_Beneficiario, 0, 3) <> '018'
   And Exists (Select 1
          From Dbaps.Prestador p
         Where p.Cd_Prestador = v.Cd_Prestador_Pagamento
           And p.Cd_Tip_Prestador In (0, 27))
      
   And v.Cd_Prestador_Pagamento Is Not Null
   And Exists (Select 1
          From Dbaps.Itmodelo_Criterio_Procedimento Im
         Where Im.Cd_Modelo_Criterio = 1003
           And Im.Cd_Procedimento = v.Cd_Procedimento)
   And Exists (Select 1
          From Dbaps.Ptu_Unimed Pu
         Where Pu.Cd_Unimed = v.Cd_Unimed_Origem
           And Pu.Tp_Abrangencia = 'N')

           
 Group By v.Tp_Conta,
          v.Cd_Protocolo_Ctamed,
          v.Cd_Fatura,
          v.Cd_Prestador,
          v.Cd_Prestador_Pagamento,
          v.Cd_Lote,
          v.Cd_Conta_Medica,
          v.Cd_Procedimento,
          v.Cd_Lancamento,
          v.Nr_Guia,
          v.Cd_Unimed_Origem,
          v.Ds_Procedimento,
          v.Nr_Carteira_Beneficiario,
          v.Qt_Pago,
          v.Cd_Via_Acesso,
          v.Vl_Unit_Pago,
          v.Dt_Realizado,
          v.Vl_Percentual_Pago,
          v.Cd_Atividade_Medica,
          v.dt_competencia,
          v.Cd_Lancamento_Equipe

Union All

Select 'ESTADUAL' As Tp_Unimed,
       v.Tp_Conta,
       v.Cd_Protocolo_Ctamed,
       v.Cd_Fatura,
       v.Cd_Lote,
       v.Cd_Conta_Medica,
       v.Nr_Guia,
       v.Cd_Unimed_Origem,
       v.Nr_Carteira_Beneficiario,
       (Select p.Cd_Grupo_Procedimento
          From Dbaps.Procedimento p
         Where p.Cd_Procedimento = v.Cd_Procedimento) As Grupo_Procedimento,
       v.Cd_Procedimento,
       v.Ds_Procedimento,
       v.Dt_Realizado,
       v.Qt_Pago,
       v.Cd_Lancamento,
       v.Cd_Lancamento_Equipe,
       v.Cd_Prestador As Cd_Prestador_Executor,
       (Select p.Nm_Prestador
          From Dbaps.Prestador p
         Where p.Cd_Prestador = v.Cd_Prestador) As Nm_Prestador_Executante,
       (Select p.Cd_Tip_Prestador
          From Dbaps.Prestador p
         Where p.Cd_Prestador = v.Cd_Prestador) As Tipo_Prestador_Executante,
       
       v.Cd_Prestador_Pagamento As Cd_Prestador_Pagamento,
       (Select p.Nm_Prestador
          From Dbaps.Prestador p
         Where p.Cd_Prestador = v.Cd_Prestador_Pagamento) As Nm_Prestador_Pagamento,
       (Select p.Cd_Tip_Prestador
          From Dbaps.Prestador p
         Where p.Cd_Prestador = v.Cd_Prestador_Pagamento) As Tipo_Prestador_Pagamento,
       v.Vl_Percentual_Pago,
       v.Cd_Atividade_Medica,
       v.Cd_Via_Acesso,
       v.Vl_Unit_Pago,
       Sum(v.Vl_Total_Pago) As Vl_Total_Pago,
       Sum(v.Vl_Total_Pago) / v.Qt_Pago As Divisao,
       (Select Vp.Vl_Referencia
          From Valor_Ref_Proc Vp
         Where Vp.Cd_Procedimento = v.Cd_Procedimento
           And Vp.Cd_Tabela = 1002
           And Trunc(Vp.Dt_Vigencia) =
               (Select Max(Trunc(Vpp.Dt_Vigencia))
                  From Valor_Ref_Proc Vpp
                 Where Vpp.Cd_Procedimento = Vp.Cd_Procedimento
                   And Vpp.Cd_Tabela = Vpp.Cd_Tabela
                   And v.Dt_Realizado >= Vpp.Dt_Vigencia
                   And Vpp.Cd_Tabela = 1002)
        
        ) As Valor_Ref_Proc_Mais_Vigente,
         (Select Distinct f.cd_mens_contrato 
       From v_Ctas_medicas_fatura f 
       Where  f.dt_competencia = v.dt_competencia
       And f.cd_conta_medica = v.cd_conta_medica 
        And f.cd_lancamento = v.cd_lancamento
     And f.cd_lancamento_equipe = v.cd_lancamento_equipe
     ) As mens_contrato 
  From v_Ctas_Medicas v
 Where v.Dt_Competencia = '202307'
   And v.Tp_Situacao_Conta In ('AA', 'AT')
   And v.Tp_Situacao_Itconta In ('AA', 'AT')
   And v.Tp_Situacao_Equipe In ('AA', 'AT')
   And v.Tp_Pagcob In ('CP', 'PN')
   And v.Cd_Tip_Acomodacao = '7'
   And v.Tp_Pagamento = 'HM'
   And Substr(v.Nr_Carteira_Beneficiario, 0, 3) <> '018'
   And Exists (Select 1
          From Dbaps.Prestador p
         Where p.Cd_Prestador = v.Cd_Prestador_Pagamento
           And p.Cd_Tip_Prestador In (0, 27))
      
   And v.Cd_Prestador_Pagamento Is Not Null
   And Exists (Select 1
          From Dbaps.Itmodelo_Criterio_Procedimento Im
         Where Im.Cd_Modelo_Criterio = 1003
           And Im.Cd_Procedimento = v.Cd_Procedimento)
   And Exists (Select 1
          From Dbaps.Ptu_Unimed Pu
         Where Pu.Cd_Unimed = v.Cd_Unimed_Origem
           And Pu.Tp_Abrangencia = 'E')

 Group By v.Tp_Conta,
          v.Cd_Protocolo_Ctamed,
          v.Cd_Fatura,
          v.Cd_Prestador,
          v.Cd_Prestador_Pagamento,
          v.Cd_Lote,
          v.Cd_Conta_Medica,
          v.Cd_Procedimento,
          v.Cd_Lancamento,
          v.Nr_Guia,
          v.Ds_Procedimento,
          v.Nr_Carteira_Beneficiario,
          v.Qt_Pago,
          v.Cd_Via_Acesso,
          v.Cd_Unimed_Origem,
          v.Vl_Unit_Pago,
          v.Dt_Realizado,   
          v.dt_competencia,
          v.Vl_Percentual_Pago,
          v.Cd_Atividade_Medica,
          v.Cd_Lancamento_Equipe 
          
Union All          
Select '994' As Tp_Unimed,
       v.Tp_Conta,
       v.Cd_Protocolo_Ctamed,
       v.Cd_Fatura,
       v.Cd_Lote,
       v.Cd_Conta_Medica,
       v.Nr_Guia,
       v.Cd_Unimed_Origem,
       v.Nr_Carteira_Beneficiario,
       (Select p.Cd_Grupo_Procedimento
          From Dbaps.Procedimento p
         Where p.Cd_Procedimento = v.Cd_Procedimento) As Grupo_Procedimento,
       v.Cd_Procedimento,
       v.Ds_Procedimento,
       v.Dt_Realizado,
       v.Qt_Pago,
       v.Cd_Lancamento,
       v.Cd_Lancamento_Equipe,
       v.Cd_Prestador As Cd_Prestador_Executor,
       (Select p.Nm_Prestador
          From Dbaps.Prestador p
         Where p.Cd_Prestador = v.Cd_Prestador) As Nm_Prestador_Executante,
       (Select p.Cd_Tip_Prestador
          From Dbaps.Prestador p
         Where p.Cd_Prestador = v.Cd_Prestador) As Tipo_Prestador_Executante,
       
       v.Cd_Prestador_Pagamento As Cd_Prestador_Pagamento,
       (Select p.Nm_Prestador
          From Dbaps.Prestador p
         Where p.Cd_Prestador = v.Cd_Prestador_Pagamento) As Nm_Prestador_Pagamento,
       (Select p.Cd_Tip_Prestador
          From Dbaps.Prestador p
         Where p.Cd_Prestador = v.Cd_Prestador_Pagamento) As Tipo_Prestador_Pagamento,
       v.Vl_Percentual_Pago,
       v.Cd_Atividade_Medica,
       v.Cd_Via_Acesso,
       v.Vl_Unit_Pago,
       Sum(v.Vl_Total_Pago) As Vl_Total_Pago,
       Sum(v.Vl_Total_Pago) / v.Qt_Pago As Divisao,
       (Select Vp.Vl_Referencia
          From Valor_Ref_Proc Vp
         Where Vp.Cd_Procedimento = v.Cd_Procedimento
           And Vp.Cd_Tabela = 1003
           And Trunc(Vp.Dt_Vigencia) =
               (Select Max(Trunc(Vpp.Dt_Vigencia))
                  From Valor_Ref_Proc Vpp
                 Where Vpp.Cd_Procedimento = Vp.Cd_Procedimento
                   And Vpp.Cd_Tabela = Vpp.Cd_Tabela
                   And v.Dt_Realizado >= Vpp.Dt_Vigencia
                   And Vpp.Cd_Tabela = 1003)
        
        ) As Valor_Ref_Proc_Mais_Vigente,
       (Select Distinct f.cd_mens_contrato 
       From v_Ctas_medicas_fatura f 
       Where  f.dt_competencia = v.dt_competencia
       And f.cd_conta_medica = v.cd_conta_medica 
        And f.cd_lancamento = v.cd_lancamento
     And f.cd_lancamento_equipe = v.cd_lancamento_equipe
     ) As mens_contrato 
  From v_Ctas_Medicas v
 Where v.Dt_Competencia = '202307'
   And v.Tp_Situacao_Conta In ('AA', 'AT')
   And v.Tp_Situacao_Itconta In ('AA', 'AT')
   And v.Tp_Situacao_Equipe In ('AA', 'AT')
   And v.Tp_Pagcob In ('CP', 'PN')
   And v.Cd_Tip_Acomodacao = '7'
   And v.Tp_Pagamento = 'HM'
   And Substr(v.Nr_Carteira_Beneficiario, 0, 3) <> '018'
   And Exists (Select 1
          From Dbaps.Prestador p
         Where p.Cd_Prestador = v.Cd_Prestador_Pagamento
           And p.Cd_Tip_Prestador In (0, 27))
      
   And v.Cd_Prestador_Pagamento Is Not Null
   And Exists (Select 1
          From Dbaps.Itmodelo_Criterio_Procedimento Im
         Where Im.Cd_Modelo_Criterio = 1003
           And Im.Cd_Procedimento = v.Cd_Procedimento)
   And Substr(v.nr_carteira_beneficiario,0,3) = '994'

 Group By v.Tp_Conta,
          v.Cd_Protocolo_Ctamed,
          v.Cd_Fatura,
          v.Cd_Prestador,
          v.Cd_Prestador_Pagamento,
          v.Cd_Lote,
          v.Cd_Conta_Medica,
          v.Cd_Procedimento,
          v.Cd_Lancamento,
          v.Nr_Guia,   
          v.dt_competencia,
          v.Ds_Procedimento,
          v.Nr_Carteira_Beneficiario,
          v.Qt_Pago,
          v.Cd_Via_Acesso,
          v.Cd_Unimed_Origem,
          v.Vl_Unit_Pago,
          v.Dt_Realizado,
          v.Vl_Percentual_Pago,
          v.Cd_Atividade_Medica,
          v.Cd_Lancamento_Equipe 
