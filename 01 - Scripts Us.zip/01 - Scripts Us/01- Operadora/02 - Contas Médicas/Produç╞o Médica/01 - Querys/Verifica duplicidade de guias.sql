/*
Favor fazer o levantamento da produ��o 06 e 07/22, referente a carteira 018.5762....., 
com a identifica��o das guias de consultas em duplicidade.

Identificar - guia e lote/ nome e carteira do benefici�rio/ data da realiza��o/ compet�ncia, 
guia paga e guia duplicada/ valor pago e valor zerado ( n�o pago) co-participa��o cobrada / 
m�dico que recebeu.

*/

Select z.*,
       (Select Listagg(Ite.Tp_Pagamento || ' - ' ||
                       Ite.Cd_Prestador_Pagamento,
                       ',') Within Group(Order By Ite.Tp_Pagamento)
        
          From Dbaps.Itremessa_Prestador_Equipe Ite
         Where Ite.Cd_Remessa = z.Cd_Conta_Medica
           And Ite.Cd_Lancamento = z.Cd_Lancamento) Cd_Prestador_Pagamento

  From (Select x.*
          From (Select t.*,
                       Row_Number() Over(Partition By t.Nr_Guia, t.Dt_Realizado, t.Cd_Procedimento Order By t.Nr_Guia, t.Dt_Realizado, t.Dt_Competencia, t.Cd_Conta_Medica) Contar
                
                  From (Select Distinct Vc.Dt_Competencia,
                                        Vc.Cd_Fatura,
                                        
                                        Vc.Cd_Lote,
                                        Vc.Nr_Guia,
                                        Vc.Tp_Conta,
                                        Vc.Cd_Conta_Medica,
                                        Vc.Nr_Carteira_Beneficiario,
                                        Vc.Nm_Beneficiario,
                                        Vc.Cd_Lancamento,
                                        Trunc(Vc.Dt_Realizado) Dt_Realizado,
                                        Vc.Cd_Procedimento,
                                        (Select Po.Ds_Procedimento
                                           From Dbaps.Procedimento Po
                                          Where Po.Cd_Procedimento =
                                                Vc.Cd_Procedimento) Ds_Procedimento,
                                        
                                        Vc.Cd_Prestador_Principal,
                                        (Select Pr.Nm_Prestador
                                           From Dbaps.Prestador Pr
                                          Where Pr.Cd_Prestador =
                                                Vc.Cd_Prestador_Principal) Nm_Prestador,
                                        
                                        Vc.Tp_Pagcob,
                                        
                                        (Select Distinct Vf.Cd_Mens_Contrato
                                           From Dbaps.v_Ctas_Medicas_Fatura Vf
                                          Where Vf.Cd_Lote = Vc.Cd_Lote
                                            And Vf.Cd_Conta_Medica =
                                                Vc.Cd_Conta_Medica
                                            And Vf.Cd_Lancamento =
                                                Vc.Cd_Lancamento) Cd_Mens_Contrato,
                                        Vc.Vl_Franquia
                        
                          From Dbaps.v_Ctas_Medicas Vc
                         Where Vc.Dt_Competencia Between '202206' And '202207'
                              
                           --And Vc.Tp_Pagcob <> 'NN'
                           And Vc.Tp_Fatura = 'P'
                           And Vc.Sn_Refaturar = 'N'
                           And Vc.Tp_Conta = 'A'
                           And Substr(Vc.Nr_Carteira_Beneficiario, 0, 7) =
                               '0185762'
                           And Exists
                         (Select 1
                                  From Dbaps.v_Ctas_Medicas Vv
                                 Where Vv.Cd_Procedimento = Vc.Cd_Procedimento
                                   And Trunc(Vv.Dt_Realizado) =
                                       Trunc(Vc.Dt_Realizado)
                                   And Vv.Nr_Carteira_Beneficiario =
                                       Vc.Nr_Carteira_Beneficiario
                                   And Vv.Cd_Prestador_Principal =
                                       Vc.Cd_Prestador_Principal
                                   And Vv.Vl_Percentual_Pago =
                                       Vc.Vl_Percentual_Pago
                                   And Vv.Tp_Fatura = 'P'
                                   And Vv.Sn_Refaturar = 'N'
                                   And Vv.Tp_Conta = 'A'
                                   And Vv.Cd_Conta_Medica <> Vc.Cd_Conta_Medica
                                   And Vv.Nr_Guia = Vc.Nr_Guia
                                   And Vv.Dt_Competencia <= '202207'
                                   And Substr(Vv.Nr_Carteira_Beneficiario, 0, 7) =
                                       '0185762')
                        
                         Order By 5, 10) t) x) z

  --Where z.nr_guia =85327319

 Order By z.Nr_Guia,
          z.Cd_Procedimento,
          z.Dt_Realizado,
          z.Cd_Conta_Medica,
          z.Cd_Lancamento
          
        --Dbaps.v_Guia_Franquia
