Select v.Tp_Conta,
               v.Cd_Fatura,
               v.Cd_Lote, 
               (Select l.Cd_Tipo_Atendimento || ' - ' ||
                       Ta.Ds_Tipo_Atendimento
                  From Dbaps.Lote l, Dbaps.Tipo_Atendimento Ta
                 Where l.Cd_Tipo_Atendimento = Ta.Cd_Tipo_Atendimento
                   And l.Cd_Lote = v.Cd_Lote) As Tipo_Lote,
               v.Cd_Conta_Medica,
               v.Cd_Procedimento,
               v.Cd_Lancamento,
               v.Tp_Pagcob,
               v.Tp_Situacao_Conta,
               v.Tp_Situacao_Itconta,
               v.Cd_Motivo_Conta,
               v.Cd_Motivo_Itconta,
               v.Cd_Motivo_Equipe,
               v.Cd_Prestador,
               (Select p.Nm_Prestador
                  From Dbaps.Prestador p
                 Where p.Cd_Prestador = v.Cd_Prestador) As Nm_Prestador,
               (Select Distinct Ipf.Cd_Mens_Contrato
                  From Itremessa_Prestador_Fatura Ipf
                 Where Ipf.Cd_Remessa = v.Cd_Conta_Medica
                   And Ipf.Cd_Lancamento = v.Cd_Lancamento
                   And Rownum = 1
                
                Union All
                
                Select Distinct Ihf.Cd_Mens_Contrato
                  From Itconta_Hospitalar_Fatura Ihf
                 Where Ihf.Cd_Conta_Hospitalar = v.Cd_Conta_Medica
                   And Ihf.Cd_Lancamento = v.Cd_Lancamento
                   And Rownum = 1)
          From v_Ctas_Medicas v
         Where v.Dt_Competencia = '202208'
           And v.Tp_Pagcob = 'NN'
              
 
