Select p.Cd_Protocolo_Ctamed,
       p.Cd_Fatura,
       p.Cd_Status_Protocolo || ' - ' ||
       (Select s.Ds_Status_Protocolo
          From Dbaps.Status_Protocolo s
         Where s.Cd_Status_Protocolo = p.Cd_Status_Protocolo) Status,
       Pre.Cd_Tip_Prestador,
       p.cd_importa_lot_guia_agrupada

  From Dbaps.Protocolo_Ctamed p,
       
       Dbaps.Prestador Pre
 Where p.Cd_Prestador = Pre.Cd_Prestador
      --and p.cd_protocolo_ctamed = 606119
  -- And Pre.Cd_Tip_Prestador = '0'
   And p.Dt_Ultima_Importacao Is Null
   And p.Cd_Status_Protocolo Not In (4, 9)
 --  And p.cd_fatura Is Not Null

   And Trunc(p.Dt_Inclusao) Between '14/05/2023' And '15/06/2023';

Select g.Cd_Lote_Guia_Web
  From Guia g
 Where g.Nr_Guia = 119148059

--103845

 Update Guia g Set g.Cd_Lote_Guia_Web = Null
 Where g.Nr_Guia = 119148059;
