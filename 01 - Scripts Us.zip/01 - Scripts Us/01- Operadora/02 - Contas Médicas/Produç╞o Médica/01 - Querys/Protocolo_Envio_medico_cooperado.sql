Create Table TEMP_acerto_ana_202301_3 As  Select p.Cd_Protocolo_Ctamed,
               v.Cd_Tipo_Atendimento || ' - ' ||
               (Select t.Ds_Tipo_Atendimento
                  From Dbaps.Tipo_Atendimento t
                 Where t.Cd_Tipo_Atendimento = v.Cd_Tipo_Atendimento) Tp_Guia,
               Trunc(p.Dt_Inclusao) Dt_Recebimento,
               p.Cd_Fatura,
               p.Cd_Status_Protocolo || ' - ' ||
               (Select s.Ds_Status_Protocolo
                  From Dbaps.Status_Protocolo s
                 Where s.Cd_Status_Protocolo = p.Cd_Status_Protocolo) Status,
               v.Cd_Lote,
               v.Cd_Prestador || ' - ' || Pre.Nm_Prestador Prestador,
               v.Vl_Total_Pago Vl_Total_Pago,
               Pre.Cd_Tip_Prestador,
               v.Cd_Conta_Medica,
               V.NR_GUIA, 
               v.Cd_Lancamento,
               v.Tp_Pagcob,
               (Select f.Cd_Mens_Contrato
                  From Dbaps.v_Ctas_Medicas_Fatura f
                 Where f.Cd_Conta_Medica = v.Cd_Conta_Medica
                   And Rownum = 1) As Mens_Contrato,
               v.Tp_Conta
          From Dbaps.Protocolo_Ctamed p,
               v_Ctas_Medicas         v,
               Dbaps.Prestador        Pre
         Where p.Cd_Protocolo_Ctamed = v.Cd_Protocolo_Ctamed
           And p.Cd_Prestador = Pre.Cd_Prestador
              --and p.cd_protocolo_ctamed = 606119
           And Pre.Cd_Tip_Prestador = '0'
           And Trunc(p.Dt_Inclusao) = '16/01/2023'
           And Not Exists
 (Select 1
          From Temp_Acerto_Ana_202301 t
         Where t.cd_fatura = v.cd_fatura)

         
         
           
