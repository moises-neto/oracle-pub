/*Solicito por gentileza em car�ter de urg�ncia um levantamento de todos os atendimentos apresentados pelo prestador (principal) 1001153, 
tipo de guias do lote 3 e 4 referente a compet�ncia de Abril de 2023.

Campos:
Compet�ncia, conta m�dica, lote, guia, prestador principal, prestador executante, unimed origem, carteira, 
nome do benefici�rio, car�ter de atendimento, tipo de interna��o, cid c�d e descri��o, procedimento principal 
(o que possui participa��o de cirurgiao e de maior valor), prestador pagamento, valor total da conta.

Quando for tipo de atendimento de interna��o clinica considerar procedimento principal o de visita hospitalar.*/

Select *

  From (Select Distinct v.Dt_Competencia,
                        v.Cd_Lote,
                        v.Cd_Conta_Medica,
                        v.Nr_Guia,
                        v.Cd_Tipo_Atendimento,
                        --  v.Cd_Lancamento,
                        v.Cd_Regime_Internacao,
                        v.Cd_Prestador_Principal,
                        v.Cd_Prestador,
                        (Select p.Nm_Prestador
                           From Dbaps.Prestador p
                          Where p.Cd_Prestador = v.Cd_Prestador) Nm_Prestador,
                        (Select Pp.Cd_Tip_Prestador || ' - ' ||
                                (Select Tp.Nm_Prestador
                                   From Dbaps.Tip_Prestador Tp
                                  Where Tp.Cd_Tip_Prestador =
                                        Pp.Cd_Tip_Prestador)
                           From Dbaps.Prestador Pp
                          Where Pp.Cd_Prestador = v.Cd_Prestador) As Tipo_Prestador,
                        v.Cd_Unimed_Origem,
                        v.Nr_Carteira_Beneficiario,
                        v.Nm_Beneficiario,
                        v.Tp_Carater_Atendimento,
                        v.Tp_Internacao,
                        v.Cd_Cid,
                        v.Cd_Procedimento,
                        
                        (Select p.Ds_Procedimento
                           From Procedimento p
                          Where p.Cd_Procedimento = v.Cd_Procedimento) Ds_Procedimento,
                        (Select c.Ds_Cid From Cid c Where c.Cd_Cid = v.Cd_Cid) As Ds_Cid,
                        v.Cd_Prestador_Pagamento,
                        v.Cd_Via_Acesso,
                        v.Cd_Atividade_Medica,
                        (Select Sum(Vv.Vl_Total_Pago)
                           From v_Ctas_Medicas Vv
                          Where Vv.Cd_Protocolo_Ctamed =
                                v.Cd_Protocolo_Ctamed) As Valor,
                        v.Vl_Total_Pago,
                        Rank() Over(Partition By v.nr_guia Order By v.Vl_Total_Pago Desc) As Valor_Procedimento_Rank
          From v_Ctas_Medicas v, Lote l
         Where v.Cd_Lote = l.Cd_Lote
           And l.cd_prestador = 1001153
           And l.Cd_Tipo_Atendimento In (3, 4)
           And v.Cd_Atividade_Medica = 1
           And v.Dt_Competencia = '202304'
           And v.Tp_Situacao_Conta In ('AA', 'AT')
           And v.Tp_Situacao_Itconta In ('AA', 'AT')
           And v.Tp_Situacao_Equipe In ('AA', 'AT')
           And v.Tp_Pagcob In ('CP', 'PN')
        -- And v.cd_conta_medica = 203093 
        ) x

 Where Valor_Procedimento_Rank = 1

Union All

Select *

  From (Select Distinct v.Dt_Competencia,
                        v.Cd_Lote,
                        v.Cd_Conta_Medica,
                        v.Nr_Guia,
                        v.Cd_Tipo_Atendimento,
                        --  v.Cd_Lancamento,
                        v.Cd_Prestador_Principal,
                        v.Cd_Prestador,
                        (Select p.Nm_Prestador
                           From Dbaps.Prestador p
                          Where p.Cd_Prestador = v.Cd_Prestador) Nm_Prestador,
                        (Select Pp.Cd_Tip_Prestador || ' - ' ||
                                (Select Tp.Nm_Prestador
                                   From Dbaps.Tip_Prestador Tp
                                  Where Tp.Cd_Tip_Prestador =
                                        Pp.Cd_Tip_Prestador)
                           From Dbaps.Prestador Pp
                          Where Pp.Cd_Prestador = v.Cd_Prestador) As Tipo_Prestador,
                        v.Cd_Unimed_Origem,
                        v.Nr_Carteira_Beneficiario,
                        v.Nm_Beneficiario,
                        v.Tp_Carater_Atendimento,
                        v.Tp_Internacao,
                        v.Cd_Cid,
                        v.Cd_Procedimento,
                        v.Cd_Regime_Internacao,
                        (Select p.Ds_Procedimento
                           From Procedimento p
                          Where p.Cd_Procedimento = v.Cd_Procedimento) Ds_Procedimento,
                        (Select c.Ds_Cid From Cid c Where c.Cd_Cid = v.Cd_Cid) As Ds_Cid,
                        v.Cd_Prestador_Pagamento,
                        v.Cd_Via_Acesso,
                        v.Cd_Atividade_Medica,
                        (Select Sum(Vv.Vl_Total_Pago)
                           From v_Ctas_Medicas Vv
                          Where Vv.Cd_Protocolo_Ctamed =
                                v.Cd_Protocolo_Ctamed) As Valor,
                        v.Vl_Total_Pago,
                        Rank() Over(Partition By v.Nr_Guia Order By v.Vl_Total_Pago Desc) As Valor_Procedimento_Rank
          From v_Ctas_Medicas v, Lote l
         Where v.Cd_Lote = l.Cd_Lote
            And l.cd_prestador = 1001153
           And l.Cd_Tipo_Atendimento In (3, 4)
              ---  And v.Cd_Atividade_Medica <> 1
              -- And (v.Cd_Via_Acesso Is Not Null And v.Cd_Via_Acesso <> 1)
           And v.Dt_Competencia = '202304'
           And v.Tp_Situacao_Conta In ('AA', 'AT')
           And v.Tp_Situacao_Itconta In ('AA', 'AT')
           And v.Tp_Situacao_Equipe In ('AA', 'AT')
           And v.Tp_Pagcob In ('CP', 'PN')
              
           And Not Exists
         (Select 1
                  From v_Ctas_Medicas Vv, Lote l
                 Where 1 = 1
                   And Vv.cd_protocolo_ctamed =  v.cd_protocolo_ctamed
                   And Vv.Cd_Prestador_Principal = 1001153
                   And l.Cd_Tipo_Atendimento In (3, 4)
                   And Vv.Cd_Atividade_Medica = 1
                   And (Vv.Cd_Via_Acesso = 1 Or Vv.Cd_Via_Acesso Is Null)
                   And Vv.Dt_Competencia = '202304'
                   And Vv.Tp_Situacao_Conta In ('AA', 'AT')
                   And Vv.Tp_Situacao_Itconta In ('AA', 'AT')
                   And Vv.Tp_Situacao_Equipe In ('AA', 'AT')
                   And Vv.Tp_Pagcob In ('CP', 'PN'))
              
           And Exists (Select 1
                  From Dbaps.v_Ctas_Medicas Vvv
                 Where v.Cd_Conta_Medica = Vvv.Cd_Conta_Medica
                   And Vvv.Cd_Procedimento = '10102019')
        
        ) x

 Where Valor_Procedimento_Rank = 1
