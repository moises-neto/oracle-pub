select cm.cd_prestador, cm.vl_total_pago, cm.tp_pagcob, cm.*
  from dbaps.v_ctas_medicas cm
 where cm.nr_guia in ('63886019', '63884109','63870339','63869389','63869149','64240969') --guias
   and cm.tp_pagamento = 'HM'
   and cm.tp_fatura = 'P'
   and cm.tp_origem = '2'
   and cm.tp_situacao_conta IN ('AA', 'AT')
   and cm.tp_situacao_itconta IN ('AA', 'AT')
   and cm.tp_situacao_equipe = 'AA'
   and cm.tp_pagcob not in ('NN', 'CN')
