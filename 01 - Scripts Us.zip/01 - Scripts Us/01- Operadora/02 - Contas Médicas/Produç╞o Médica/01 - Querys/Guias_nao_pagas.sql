/*Ol� boa tarde!
Solicito levantamento dos atendimentos de cooperados de n�vel 0 (autorizador), do per�odo de 16/01/2023 at� 15/02/2023,
o que foi autorizado online que n�o est� na produ��o 01/2023.
Se o campo cd_lote_guia_web (DBAPS.GUIA) estiver preenchido, significa que foi enviado para faturamento
e o mesmo n�mero que est� no CD_LOTE_GUIA_WEB ser� == NR_LOTE_PRESTADOR� �(DBAPS.PROTOCOLO_CTAMED),
com isso n�o necessariamente a guia foi importada, possa ser que tenha sido enviada mas ainda n�o entrou no contas m�dicas.
Preciso que retorne todas essas guias, e exiba em colunas se foi faturada (condi��o acima)
e qual compet�ncia est� (caso n�o tenha sido importada, trazer NULL), se foi apenas autorizada e n�o faturada ainda.
Se preocupar se o item n�o est� em outras compet�ncia (duplicidade).
Nesse levantamento trazer as colunas como de costume, e acrescentar se est� na produ��o 02/2023 ou se n�o est� em nenhuma outra produ��o
(n�o foi enviado para faturamento).
*/
Select Distinct g.Nr_Guia,
                It.Cd_Procedimento,
                Nvl(Trunc(It.Dt_Realizacao), Trunc(g.Dt_Emissao)) As Dt_Realizacao,
                p.Cd_Prestador,
                p.Nm_Prestador,
                g.Cd_Lote_Guia_Web,
                (Select Distinct v.Cd_Lote
                   From Dbaps.v_Ctas_Medicas v
                  Where v.Nr_Guia = g.Nr_Guia
                    And Trunc(v.Dt_Realizado) =
                        Nvl(Trunc(It.Dt_Realizacao), Trunc(v.Dt_Realizado))
                    And v.Cd_Procedimento = It.Cd_Procedimento
                    And v.Tp_Pagcob In ('CP', 'PN')) As Lote_Guias,
                (Select Distinct v.Dt_Competencia
                   From Dbaps.v_Ctas_Medicas v
                  Where v.Nr_Guia = g.Nr_Guia
                    And Trunc(v.Dt_Realizado) =
                        Nvl(Trunc(It.Dt_Realizacao), Trunc(v.Dt_Realizado))
                    And v.Cd_Procedimento = It.Cd_Procedimento
                    And v.Tp_Pagcob In ('CP', 'PN')) As Competencia_Pag,
                (Select Sum(v.Vl_Total_Pago)
                   From Dbaps.v_Ctas_Medicas v
                  Where v.Nr_Guia = g.Nr_Guia
                    And Trunc(v.Dt_Realizado) =
                        Nvl(Trunc(It.Dt_Realizacao), Trunc(v.Dt_Realizado))
                    And v.Cd_Procedimento = It.Cd_Procedimento
                    And v.Tp_Situacao_Conta In ('AA', 'AT')
                    And v.Tp_Situacao_Itconta In ('AA', 'AT')
                    And v.Tp_Situacao_Equipe In ('AA', 'AT')
                    And v.Tp_Pagcob In ('CP', 'PN')
                    And v.Cd_Prestador_Pagamento Is Not Null) Valor_Pago,
                (Select Distinct f.Cd_Mens_Contrato
                   From v_Ctas_Medicas_Fatura f
                  Where f.Nr_Guia = g.Nr_Guia
                    And Trunc(f.Dt_Realizado) =
                        Nvl(Trunc(It.Dt_Realizacao), Trunc(f.Dt_Realizado))
                    And f.Cd_Procedimento = It.Cd_Procedimento
                    And Rownum = 1) As Mens_Contrato
                    
  From Dbaps.Guia g, Dbaps.Prestador p, Dbaps.Itguia It
 Where g.Cd_Prestador_Executor = p.Cd_Prestador
   And It.Nr_Guia = g.Nr_Guia
   And p.Cd_Tip_Prestador = 0
   And Nvl(Trunc(It.Dt_Realizacao), '16/01/2023') Between '16/01/2023' And
       '15/02/2023'
   And Trunc(g.Dt_Emissao) Between '16/01/2023' And '15/02/2023'
   And Not Exists (Select 1
          From Dbaps.v_Ctas_Medicas v
         Where v.Nr_Guia = g.Nr_Guia
           And v.Dt_Competencia = '202302')
   And It.Tp_Status = '4'
   
Union All ---

Select Distinct g.Nr_Guia,
                It.Cd_Procedimento,
                Trunc(Ie.Dt_Execucao) As Dt_Realizacao,
                p.Cd_Prestador,
                p.Nm_Prestador,
                g.Cd_Lote_Guia_Web,
                (Select Distinct v.Cd_Lote
                   From Dbaps.v_Ctas_Medicas v
                  Where v.Nr_Guia = g.Nr_Guia
                    And Trunc(v.Dt_Realizado) = Trunc(Ie.Dt_Execucao)
                    And v.Cd_Procedimento = It.Cd_Procedimento
                    And v.Tp_Pagcob In ('CP', 'PN')) As Lote_Guias,
                (Select Distinct v.Dt_Competencia
                   From Dbaps.v_Ctas_Medicas v
                  Where v.Nr_Guia = g.Nr_Guia
                    And Trunc(v.Dt_Realizado) = Trunc(Ie.Dt_Execucao)
                    And v.Cd_Procedimento = It.Cd_Procedimento
                    And v.Tp_Pagcob In ('CP', 'PN')) As Competencia_Pag,
                (Select Sum(v.Vl_Total_Pago)
                   From Dbaps.v_Ctas_Medicas v
                  Where v.Nr_Guia = g.Nr_Guia
                    And Trunc(v.Dt_Realizado) = Trunc(Ie.Dt_Execucao)
                    And v.Cd_Procedimento = It.Cd_Procedimento
                    And v.Tp_Situacao_Conta In ('AA', 'AT')
                    And v.Tp_Situacao_Itconta In ('AA', 'AT')
                    And v.Tp_Situacao_Equipe In ('AA', 'AT')
                    And v.Tp_Pagcob In ('CP', 'PN')
                    And v.Cd_Prestador_Pagamento Is Not Null) Valor_Pago,
                (Select Distinct f.Cd_Mens_Contrato
                   From v_Ctas_Medicas_Fatura f
                  Where f.Nr_Guia = g.Nr_Guia
                    And Trunc(f.Dt_Realizado) = Trunc(Ie.Dt_Execucao)
                    And f.Cd_Procedimento = It.Cd_Procedimento
                    And Rownum = 1) As Mens_Contrato
  From Dbaps.Guia            g,
       Dbaps.Prestador       p,
       Dbaps.Itguia          It,
       Dbaps.Itguia_Execucao Ie
 Where g.Cd_Prestador = p.Cd_Prestador
   And It.Nr_Guia = g.Nr_Guia
   And Ie.Cd_Itguia = It.Cd_Itguia
   And g.Cd_Prestador_Executor Is Null
   And p.Cd_Tip_Prestador = 0
   And Trunc(Ie.Dt_Execucao) Between '16/01/2023' And '15/02/2023'
   And Not Exists
 (Select 1
          From Dbaps.v_Ctas_Medicas v
         Where v.Nr_Guia = g.Nr_Guia
           And Trunc(v.Dt_Realizado) = Trunc(Ie.Dt_Execucao)
           And v.Dt_Competencia = '202302')
   And It.Tp_Status = '4'
 Order By 3 Asc
