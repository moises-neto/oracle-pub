Select c.*
  From Dbaps.Ctamed_Amb_Erros c, Dbaps.v_Ctas_Medicas v

 Where (c.Cd_Remessa_Itremaudit = v.Cd_Conta_Medica Or
       c.Cd_Remessa_Remessa = v.Cd_Conta_Medica)
   And v.Cd_Fatura = 40863
      --And v.nr_guia = 96910729 
   And c.Sn_Liberado = 'N';


---
                        
Select Rp.Cd_Lote, Rp.Cd_Conta_Hospitalar,
 c.*
  From Dbaps.Itcontah_Rejeitada_Log c, Conta_Hospitalar Rp

 Where c.Cd_Conta_Hospitalar = Rp.Cd_Conta_Hospitalar
   And Exists (Select 1
          From v_Ctas_Medicas v
         Where v.Cd_Conta_Medica = c.Cd_Conta_Hospitalar
           And v.Cd_Fatura = 41217)
   And c.Sn_Liberado = 'N';

----

Select * From Dbaps.v_ctas_Medicas v
Where v.cd_fatura = 41217
--And v.cd_unimed_origem <> 018
--And v.tp_situacao_itconta = 'NA'
And v.vl_total_pago = 0
And v.tp_situacao_itconta In('AA','AT','NA')
And v.tp_situacao_equipe In('AA','AT','NA')
