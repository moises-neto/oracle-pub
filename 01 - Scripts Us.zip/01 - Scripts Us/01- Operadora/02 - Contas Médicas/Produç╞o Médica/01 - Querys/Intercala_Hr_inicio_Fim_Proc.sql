
--'DBAPS.TRG_ITCONTA_HOSPITALAR'

--'DBAPS.TRG_ITREMESSA_PRESTADOR'


Declare

  Cursor Cdadoshorarioproc Is
   Select *
      From (Select Distinct f.Cd_Fatura,
                   f.Cd_Lote,
                   f.Cd_Conta_Medica,
                   f.Cd_Procedimento,
                   f.Cd_Lancamento,
                   f.Hr_Inicial,
                   f.Hr_Final,
                   Rank() Over(Partition By f.Cd_Conta_Medica, f.Cd_Procedimento Order By f.Cd_Lancamento) Rank,
                   
                   ((f.Hr_Inicial) -
                   ((Rank()
                    Over(Partition By f.Cd_Conta_Medica,
                           f.Cd_Procedimento Order By f.Cd_Lancamento) / 24 / 60))) +
                   1 / 24 / 60 As Hr_Inicial_Atualizada,
                   
                   ((f.Hr_Final) -
                   ((Rank()
                    Over(Partition By f.Cd_Conta_Medica,
                           f.Cd_Procedimento Order By f.Cd_Lancamento) / 24 / 60))) +
                   1 / 24 / 60 As Hr_Final_Atualizada
            
              From Dbaps.v_Ctas_Medicas_Fatura f
             Where f.Dt_Competencia  Between '202202' And '202204'
              And Exists
             (Select 1
                      From Dbaps.v_Ctas_Medicas_Fatura Ff
                     
                       Where f.Cd_Conta_Medica = Ff.Cd_Conta_Medica
                       And f.Cd_Procedimento = Ff.Cd_Procedimento
                       And f.Dt_Realizado = Ff.Dt_Realizado
                       And f.Hr_Final = Ff.Hr_Final
                       And f.Hr_Inicial = Ff.Hr_Inicial
                       And f.Cd_Lancamento <> Ff.Cd_Lancamento)
                  
           
           
            ) x
    
     Where x.Rank <> 1;

vCountador Pls_Integer := 0;

Begin

  For i In Cdadoshorarioproc Loop
      vCountador := vCountador +1;
    Begin
      /*Update Dbaps.Itconta_Hospitalar Ih
         Set Ih.Hr_Inicial = i.Hr_Inicial_Atualizada,
             Ih.Hr_Final   = i.Hr_Final_Atualizada
       Where Ih.Cd_Conta_Hospitalar = i.Cd_Conta_Medica
         And Ih.Cd_Procedimento = i.Cd_Procedimento
         And Ih.Cd_Lancamento = i.Cd_Lancamento;
       */
      /* Update Dbaps.Itremessa_Prestador ip
         Set ip.hr_inicial = i.Hr_Inicial_Atualizada,
             ip.Hr_Final   = i.Hr_Final_Atualizada
       Where ip.cd_remessa = i.Cd_Conta_Medica
         And ip.Cd_Procedimento = i.Cd_Procedimento
         And ip.cd_lancamento = i.Cd_Lancamento;*/
         
      Dbms_Output.Put_Line('Lote: ' || i.cd_lote ||  ' Conta Hospitalar: ' || i.Cd_Conta_Medica ||
                           ' Lancamentos: ' || i.Cd_Lancamento);
    
    End;
  If(vCountador = 100) Then
     Commit;
     vCountador := 0;
  End If;
End Loop;

Commit;

End;
