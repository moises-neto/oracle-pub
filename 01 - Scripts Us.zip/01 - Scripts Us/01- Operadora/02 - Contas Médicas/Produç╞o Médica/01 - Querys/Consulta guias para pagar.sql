Select Count(Distinct g.Nr_Guia) As Guia_Nao_Entro_Contas_202212,
       Null Guia_Entro_Contas,
       p.Cd_Prestador,
       p.Nm_Prestador
  From Dbaps.Guia g, Dbaps.Prestador p

 Where g.Cd_Prestador_Executor = p.Cd_Prestador
   And p.Cd_Tip_Prestador = 0
   And p.Dt_Inativacao Is Null
   And Trunc(g.Dt_Emissao) Between '16/11/2022' And '15/12/2022'
   And g.Sn_Valida_Rest_Carencia = 'S'
    And g.Cd_Prestador_Executor = 113359
      
   And Exists
 (Select 1
          From Dbaps.Itguia It
         Where It.Nr_Guia = g.Nr_Guia
           And It.Cd_Procedimento In (10101012,
                                      10101050,
                                      10101057,
                                      10101058,
                                      10101063,
                                      10106014,
                                      10106146,
                                      20104065,
                                      20104316,
                                      30205093,
                                      30402042,
                                      30402077,
                                      30501016,
                                      30501083,
                                      30501113,
                                      30501164,
                                      31601014,
                                      30713145,
                                      40101010,
                                      40103404,
                                      40103447,
                                      40201023,
                                      41301099,
                                      41301323,
                                      31303196,
                                      41401239,
                                      40201198,
                                      40201201,
                                      40201210,
                                      40201228,
                                      40201236,
                                      40201244,
                                      40201252,
                                      40201260)
           And It.Tp_Status = '4')

 Group By p.Cd_Prestador, p.Nm_Prestador
