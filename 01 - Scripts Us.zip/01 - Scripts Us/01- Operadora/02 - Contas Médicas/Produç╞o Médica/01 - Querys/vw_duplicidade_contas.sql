create or replace view custom.vw_duplicidade_contas as
Select z."DT_COMPETENCIA",z."CD_FATURA",z."SN_FATURA_FECHADA",z."CD_LOTE",z."NR_GUIA",z."TP_CONTA",z."CD_CONTA_MEDICA",z."NR_CARTEIRA_BENEFICIARIO",z."NM_BENEFICIARIO",z."CD_LANCAMENTO",z."DT_REALIZADO",z."CD_PROCEDIMENTO",z."DS_PROCEDIMENTO",z."CD_PRESTADOR_PRINCIPAL",z."NM_PRESTADOR",z."TP_PAGCOB",z."CD_MENS_CONTRATO",z."CD_MOTIVO_ITCONTA",z."TP_SITUACAO_ITCONTA",z."VL_PERCENTUAL_PAGO",z."CONTAR",z."ACAO",z."CD_MOTIVO_NEW",z."TP_SITUACAO_NEW",
                    (Select Listagg(Ite.Tp_Pagamento || ' - ' ||
                                    Ite.Cd_Prestador_Pagamento,
                                    ',') Within Group(Order By Ite.Tp_Pagamento)

                       From Dbaps.Itremessa_Prestador_Equipe Ite
                      Where Ite.Cd_Remessa = z.Cd_Conta_Medica
                        And Ite.Cd_Lancamento = z.Cd_Lancamento) Cd_Prestador_Pagamento

              From (Select x.*,
                            Case
                              When x.Contar >= 1 And x.Cd_Mens_Contrato Is Null Then
                               'NN'
                              When x.Contar >= 1 And
                                   x.Cd_Mens_Contrato Is Not Null Then
                               'CN'
                              Else
                               x.Tp_Pagcob
                            End Acao,
                            Case
                              When x.Contar >= 1 And x.Cd_Mens_Contrato Is Null And
                                   x.Cd_Motivo_Itconta Is Null Then
                               24
                              Else
                               x.Cd_Motivo_Itconta
                            End Cd_Motivo_New,
                            Case

                              When x.Contar >= 1 And x.Cd_Mens_Contrato Is Null And
                                   x.Cd_Motivo_Itconta Is Null Then
                               'GT'
                              Else
                               x.Tp_Situacao_Itconta
                            End Tp_Situacao_New

                       From (Select t.*,
                                    Row_Number() Over(Partition By t.Nr_Guia, t.Dt_Realizado, t.Cd_Procedimento, t.Vl_Percentual_Pago Order By t.Nr_Guia, t.Dt_Realizado, t.Dt_Competencia, t.Cd_Conta_Medica, t.Vl_Percentual_Pago) Contar

                               From (Select Distinct Vc.Dt_Competencia,
                                                     Vc.Cd_Fatura,
                                                     Vc.Sn_Fatura_Fechada,
                                                     Vc.Cd_Lote,
                                                     Vc.Nr_Guia,
                                                     Vc.Tp_Conta,
                                                     Vc.Cd_Conta_Medica,
                                                     Vc.Nr_Carteira_Beneficiario,
                                                     Vc.Nm_Beneficiario,
                                                     Vc.Cd_Lancamento,
                                                     Trunc(Vc.Dt_Realizado) Dt_Realizado,
                                                     Vc.Cd_Procedimento,
                                                     (Select Po.Ds_Procedimento
                                                        From Dbaps.Procedimento Po
                                                       Where Po.Cd_Procedimento =
                                                             Vc.Cd_Procedimento) Ds_Procedimento,

                                                     Vc.Cd_Prestador_Principal,
                                                     (Select Pr.Nm_Prestador
                                                        From Dbaps.Prestador Pr
                                                       Where Pr.Cd_Prestador =
                                                             Vc.Cd_Prestador_Principal) Nm_Prestador,

                                                     Vc.Tp_Pagcob,

                                                     (Select Distinct Vf.Cd_Mens_Contrato
                                                        From Dbaps.v_Ctas_Medicas_Fatura Vf
                                                       Where Vf.Cd_Lote =
                                                             Vc.Cd_Lote
                                                         And Vf.Cd_Conta_Medica =
                                                             Vc.Cd_Conta_Medica
                                                         And Vf.Cd_Lancamento =
                                                             Vc.Cd_Lancamento) Cd_Mens_Contrato,
                                                     Vc.Cd_Motivo_Itconta,
                                                     Vc.Tp_Situacao_Itconta,
                                                     Vc.Vl_Percentual_Pago

                                       From Dbaps.v_Ctas_Medicas Vc
                                      Where Vc.Dt_Competencia =
                                            To_Char(Sysdate, 'YYYYMM')

                                        And Vc.Tp_Pagcob <> 'NN'
                                        And Vc.Tp_Fatura = 'P'
                                        And Vc.Sn_Refaturar = 'N'
                                        And Vc.Tp_Conta = 'A'
                                        And Vc.Cd_Fatura Not In
                                            (40731, 41649, 41650)
                                        And Exists
                                      (Select 1
                                               From Dbaps.v_Ctas_Medicas Vv
                                              Where Vv.Cd_Procedimento =
                                                    Vc.Cd_Procedimento
                                                And Trunc(Vv.Dt_Realizado) =
                                                    Trunc(Vc.Dt_Realizado)
                                                And Vv.Nr_Carteira_Beneficiario =
                                                    Vc.Nr_Carteira_Beneficiario
                                                And Vv.Cd_Prestador_Principal =
                                                    Vc.Cd_Prestador_Principal
                                                And Vv.Vl_Percentual_Pago =
                                                    Vc.Vl_Percentual_Pago
                                                And Vv.Tp_Fatura = 'P'
                                                And Vv.Sn_Refaturar = 'N'
                                                And Vv.Tp_Conta = 'A'
                                                And Vv.Cd_Conta_Medica <>
                                                    Vc.Cd_Conta_Medica
                                                And Vv.Nr_Guia = Vc.Nr_Guia
                                                And Vv.Dt_Competencia >= '202201'
                                                And Vv.Cd_Fatura Not In
                                                    (40731, 41649, 41650)
                                                And Vv.Dt_Competencia <
                                                    To_Char(Sysdate, 'YYYYMM')
                                                And Vv.Tp_Pagcob In ('CP', 'PN')
                                                   -- And Vv.Cd_Repasse_Prestador Is Not Null
                                                And Exists
                                              (Select 1
                                                       From Dbaps.Prestador     p,
                                                            Dbaps.Tip_Prestador Tp
                                                      Where p.Cd_Tip_Prestador =
                                                            Tp.Cd_Tip_Prestador
                                                        And p.Cd_Prestador =
                                                            Vv.Cd_Prestador_Principal
                                                        And Tp.Cd_Tip_Prestador In
                                                            (0, 18, 9, 12))
                                                And Vv.Cd_Prestador_Principal Not In
                                                    (300100, 1001553, 1003001)
                                                And Not Exists
                                              (Select 1
                                                       From Dbaps.Procedimento p
                                                      Where p.Cd_Procedimento =
                                                            Vv.Cd_Procedimento
                                                        And p.Cd_Grupo_Procedimento In
                                                            (1021, 1022, 1023)))
                                        And Vc.Cd_Repasse_Prestador Is Null
                                        And Not Exists
                                      (Select 1
                                               From Custom.Log_Altera_Tp_Pagcob La
                                              Where La.Cd_Lote = Vc.Cd_Lote
                                                And La.Cd_Conta_Medica =
                                                    Vc.Cd_Conta_Medica
                                                And La.Cd_Lancamento =
                                                    Vc.Cd_Lancamento
                                                And La.Dt_Realizado =
                                                    Trunc(Vc.Dt_Realizado)
                                                And Trunc(La.Dt_Log) <>
                                                    '21/07/2022')
                                      Order By 5, 10) t) x) z

            Union All
            /*
            2� ESCOPO DA DUPLICIDADE:
            DUPLICIDADE ABAIXO � PEGANDO A MESMA COMPET�NCIA, UTILIZANDO OUTRAS REGRAS ADICIONAIS
            */

            Select z."DT_COMPETENCIA",z."CD_FATURA",z."SN_FATURA_FECHADA",z."CD_LOTE",z."NR_GUIA",z."TP_CONTA",z."CD_CONTA_MEDICA",z."NR_CARTEIRA_BENEFICIARIO",z."NM_BENEFICIARIO",z."CD_LANCAMENTO",z."DT_REALIZADO",z."CD_PROCEDIMENTO",z."DS_PROCEDIMENTO",z."CD_PRESTADOR_PRINCIPAL",z."NM_PRESTADOR",z."TP_PAGCOB",z."CD_MENS_CONTRATO",z."CD_MOTIVO_ITCONTA",z."TP_SITUACAO_ITCONTA",z."VL_PERCENTUAL_PAGO",z."CONTAR",z."ACAO",z."CD_MOTIVO_NEW",z."TP_SITUACAO_NEW",
                    (Select Listagg(Ite.Tp_Pagamento || ' - ' ||
                                    Ite.Cd_Prestador_Pagamento,
                                    ',') Within Group(Order By Ite.Tp_Pagamento)
                       From Dbaps.Itremessa_Prestador_Equipe Ite
                      Where Ite.Cd_Remessa = z.Cd_Conta_Medica
                        And Ite.Cd_Lancamento = z.Cd_Lancamento) Cd_Prestador_Pagamento

              From (Select x.*,
                            Case
                              When x.Contar > 1 And x.Cd_Mens_Contrato Is Null Then
                               'NN'
                              When x.Contar > 1 And
                                   x.Cd_Mens_Contrato Is Not Null Then
                               'CN'
                              Else
                               x.Tp_Pagcob
                            End Acao,
                            Case
                              When x.Contar > 1 And x.Cd_Mens_Contrato Is Null And
                                   x.Cd_Motivo_Itconta Is Null Then
                               24
                              Else
                               x.Cd_Motivo_Itconta
                            End Cd_Motivo_New,
                            Case

                              When x.Contar > 1 And x.Cd_Mens_Contrato Is Null And
                                   x.Cd_Motivo_Itconta Is Null Then
                               'GT'
                              Else
                               x.Tp_Situacao_Itconta
                            End Tp_Situacao_New

                       From (Select t.*,
                                    Row_Number() Over(Partition By t.Nr_Guia, t.Dt_Realizado, t.Cd_Procedimento, t.Vl_Percentual_Pago Order By t.Nr_Guia, t.Dt_Realizado, t.Dt_Competencia, t.Cd_Conta_Medica, t.Vl_Percentual_Pago) Contar
                               From (Select Distinct Vc.Dt_Competencia,
                                                     Vc.Cd_Fatura,
                                                     Vc.Sn_Fatura_Fechada,
                                                     Vc.Cd_Lote,
                                                     Vc.Nr_Guia,
                                                     Vc.Tp_Conta,
                                                     Vc.Cd_Conta_Medica,
                                                     Vc.Nr_Carteira_Beneficiario,
                                                     Vc.Nm_Beneficiario,
                                                     Vc.Cd_Lancamento,
                                                     Trunc(Vc.Dt_Realizado) Dt_Realizado,
                                                     Vc.Cd_Procedimento,
                                                     (Select Po.Ds_Procedimento
                                                        From Dbaps.Procedimento Po
                                                       Where Po.Cd_Procedimento =
                                                             Vc.Cd_Procedimento) Ds_Procedimento,

                                                     Vc.Cd_Prestador_Principal,
                                                     (Select Pr.Nm_Prestador
                                                        From Dbaps.Prestador Pr
                                                       Where Pr.Cd_Prestador =
                                                             Vc.Cd_Prestador_Principal) Nm_Prestador,

                                                     Vc.Tp_Pagcob,

                                                     (Select Distinct Vf.Cd_Mens_Contrato
                                                        From Dbaps.v_Ctas_Medicas_Fatura Vf
                                                       Where Vf.Cd_Lote =
                                                             Vc.Cd_Lote
                                                         And Vf.Cd_Conta_Medica =
                                                             Vc.Cd_Conta_Medica
                                                         And Vf.Cd_Lancamento =
                                                             Vc.Cd_Lancamento) Cd_Mens_Contrato,
                                                     Vc.Cd_Motivo_Itconta,
                                                     Vc.Tp_Situacao_Itconta,
                                                     Vc.Vl_Percentual_Pago

                                       From Dbaps.v_Ctas_Medicas Vc
                                      Where Vc.Dt_Competencia =
                                            To_Char(Sysdate, 'YYYYMM')

                                        And Vc.Tp_Pagcob <> 'NN'
                                        And Vc.Tp_Fatura = 'P'
                                        And Vc.Sn_Refaturar = 'N'
                                        And Vc.Tp_Conta = 'A'
                                        And Vc.Cd_Fatura Not In
                                            (40731, 41649, 41650)
                                        And Exists
                                      (Select 1
                                               From Dbaps.Prestador     p,
                                                    Dbaps.Tip_Prestador Tp
                                              Where p.Cd_Tip_Prestador =
                                                    Tp.Cd_Tip_Prestador
                                                And p.Cd_Prestador =
                                                    Vc.Cd_Prestador_Principal
                                                And Tp.Cd_Tip_Prestador In
                                                    (0, 18, 9, 12))
                                        And Vc.Cd_Prestador_Principal Not In
                                            (300100, 1001553, 1003001)
                                        And Not Exists
                                      (Select 1
                                               From Dbaps.Procedimento p
                                              Where p.Cd_Procedimento =
                                                    Vc.Cd_Procedimento
                                                And p.Cd_Grupo_Procedimento In
                                                    (1021, 1022, 1023))
                                        And Exists
                                      (Select 1
                                               From Dbaps.v_Ctas_Medicas Vv
                                              Where Vv.Cd_Procedimento =
                                                    Vc.Cd_Procedimento
                                                And Trunc(Vv.Dt_Realizado) =
                                                    Trunc(Vc.Dt_Realizado)
                                                And Vv.Nr_Carteira_Beneficiario =
                                                    Vc.Nr_Carteira_Beneficiario
                                                And Vv.Cd_Prestador_Principal =
                                                    Vc.Cd_Prestador_Principal
                                                And Vv.Vl_Percentual_Pago =
                                                    Vc.Vl_Percentual_Pago
                                                And Vv.Tp_Fatura = 'P'
                                                And Vv.Sn_Refaturar = 'N'
                                                And Vv.Tp_Conta = 'A'
                                                And Vv.Nr_Guia = Vc.Nr_Guia
                                                And Vv.Cd_Conta_Medica <>
                                                    Vc.Cd_Conta_Medica
                                                And Vv.Cd_Fatura Not In
                                                    (40731, 41649, 41650)
                                                And Vv.Dt_Competencia =
                                                    To_Char(Sysdate, 'YYYYMM')
                                                And Exists
                                              (Select 1
                                                       From Dbaps.Prestador     p,
                                                            Dbaps.Tip_Prestador Tp
                                                      Where p.Cd_Tip_Prestador =
                                                            Tp.Cd_Tip_Prestador
                                                        And p.Cd_Prestador =
                                                            Vv.Cd_Prestador_Principal
                                                        And Tp.Cd_Tip_Prestador In
                                                            (0, 18, 9, 12))
                                                And Vv.Cd_Prestador_Principal Not In
                                                    (300100, 1001553, 1003001)
                                                And Not Exists
                                              (Select 1
                                                       From Dbaps.Procedimento p
                                                      Where p.Cd_Procedimento =
                                                            Vv.Cd_Procedimento
                                                        And p.Cd_Grupo_Procedimento In
                                                            (1021, 1022, 1023)))
                                        And Vc.Cd_Repasse_Prestador Is Null
                                        And Not Exists
                                      (Select 1
                                               From Custom.Log_Altera_Tp_Pagcob La
                                              Where La.Cd_Lote = Vc.Cd_Lote
                                                And La.Cd_Lote Not In
                                                    (461402,
                                                     461404,
                                                     461387,
                                                     461385,
                                                     460067,
                                                     459988,
                                                     459295,
                                                     457703,
                                                     457544)
                                                And La.Cd_Conta_Medica =
                                                    Vc.Cd_Conta_Medica
                                                And La.Cd_Lancamento =
                                                    Vc.Cd_Lancamento
                                                And La.Dt_Realizado =
                                                    Trunc(Vc.Dt_Realizado)
                                                And Trunc(La.Dt_Log) <>
                                                    '21/07/2022')
                                      Order By 5, 10) t) x) z

             Where z.Contar > 1
;
