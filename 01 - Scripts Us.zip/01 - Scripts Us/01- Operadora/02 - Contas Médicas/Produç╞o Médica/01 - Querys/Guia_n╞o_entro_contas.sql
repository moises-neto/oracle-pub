Select Count(Distinct g.Nr_Guia) As Guia_Nao_Entro_Contas_202212,
       Null Guia_Entro_Contas,
       Null Guia_Entro_Contas_202301,
       p.Cd_Prestador,
       p.Nm_Prestador
  From Dbaps.Guia g, Dbaps.Prestador p

 Where g.Cd_Prestador_Executor = p.Cd_Prestador
   And p.Cd_Tip_Prestador = 0
   And p.Dt_Inativacao Is Null
   And Trunc(g.Dt_Emissao) Between '16/11/2022' And '15/12/2022'
   And g.Sn_Valida_Rest_Carencia = 'S'
   And Not Exists (Select 1
          From Dbaps.Remessa_Prestador Rp, Lote l, Fatura f
         Where Rp.Cd_Lote = l.Cd_Lote
           And l.Cd_Fatura = f.Cd_Fatura
           And f.Nr_Ano || f.Nr_Mes = '202212'
           And Rp.Nr_Guia = g.Nr_Guia)

   And Exists
 (Select 1
          From Dbaps.Itguia It
         Where It.Nr_Guia = g.Nr_Guia
           And It.Cd_Procedimento In (10101012,
                                      10101050,
                                      10101057,
                                      10101058,
                                      10101063,
                                      10106014,
                                      10106146,
                                      20104065,
                                      20104316,
                                      30205093,
                                      30402042,
                                      30402077,
                                      30501016,
                                      30501083,
                                      30501113,
                                      30501164,
                                      31601014,
                                      30713145,
                                      40101010,
                                      40103404,
                                      40103447,
                                      40201023,
                                      41301099,
                                      41301323,
                                      31303196,
                                      41401239,
                                      40201198,
                                      40201201,
                                      40201210,
                                      40201228,
                                      40201236,
                                      40201244,
                                      40201252,
                                      40201260)
           And It.Tp_Status = '4')

 Group By p.Cd_Prestador, p.Nm_Prestador

Union All

Select Null As Guia_Nao_Entro_Contas,
       Count(Distinct g.Nr_Guia) As Guia_Entro_Contas_202212,
       Null Guia_Entro_Contas_202301,
       p.Cd_Prestador,
       p.Nm_Prestador
  From Dbaps.Guia g, Dbaps.Prestador p

 Where g.Cd_Prestador_Executor = p.Cd_Prestador
   And p.Cd_Tip_Prestador = 0
   And p.Dt_Inativacao Is Null
   And Trunc(g.Dt_Emissao) Between '16/11/2022' And '15/12/2022'
   And g.Sn_Valida_Rest_Carencia = 'S'
   And Exists (Select 1
          From Dbaps.Remessa_Prestador Rp, Lote l, Fatura f
         Where Rp.Cd_Lote = l.Cd_Lote
           And l.Cd_Fatura = f.Cd_Fatura
          And f.Nr_Ano || f.Nr_Mes = '202212'
           And Rp.Nr_Guia = g.Nr_Guia)

   And Exists
 (Select 1
          From Dbaps.Itguia It
         Where It.Nr_Guia = g.Nr_Guia
           And It.Cd_Procedimento In (10101012,
                                      10101050,
                                      10101057,
                                      10101058,
                                      10101063,
                                      10106014,
                                      10106146,
                                      20104065,
                                      20104316,
                                      30205093,
                                      30402042,
                                      30402077,
                                      30501016,
                                      30501083,
                                      30501113,
                                      30501164,
                                      31601014,
                                      30713145,
                                      40101010,
                                      40103404,
                                      40103447,
                                      40201023,
                                      41301099,
                                      41301323,
                                      31303196,
                                      41401239,
                                      40201198,
                                      40201201,
                                      40201210,
                                      40201228,
                                      40201236,
                                      40201244,
                                      40201252,
                                      40201260)
           And It.Tp_Status = '4')

 Group By p.Cd_Prestador, p.Nm_Prestador

Union All

Select Null As Guia_Nao_Entro_Contas,
       Null As Guia_Entro_Contas_202212,
       Count(Distinct g.Nr_Guia) Guia_Entro_Contas_202301,
       p.Cd_Prestador,
       p.Nm_Prestador
  From Dbaps.Guia g, Dbaps.Prestador p

 Where g.Cd_Prestador_Executor = p.Cd_Prestador
   And p.Cd_Tip_Prestador = 0
   And p.Dt_Inativacao Is Null
   And Trunc(g.Dt_Emissao) Between '16/11/2022' And '15/12/2022'
   And g.Sn_Valida_Rest_Carencia = 'S'
   And Exists (Select 1
          From Dbaps.Remessa_Prestador Rp, Lote l, Fatura f
         Where Rp.Cd_Lote = l.Cd_Lote
           And l.Cd_Fatura = f.Cd_Fatura
          And f.Nr_Ano || f.Nr_Mes = '202301'
           And Rp.Nr_Guia = g.Nr_Guia)

   And Exists
 (Select 1
          From Dbaps.Itguia It
         Where It.Nr_Guia = g.Nr_Guia
           And It.Cd_Procedimento In (10101012,
                                      10101050,
                                      10101057,
                                      10101058,
                                      10101063,
                                      10106014,
                                      10106146,
                                      20104065,
                                      20104316,
                                      30205093,
                                      30402042,
                                      30402077,
                                      30501016,
                                      30501083,
                                      30501113,
                                      30501164,
                                      31601014,
                                      30713145,
                                      40101010,
                                      40103404,
                                      40103447,
                                      40201023,
                                      41301099,
                                      41301323,
                                      31303196,
                                      41401239,
                                      40201198,
                                      40201201,
                                      40201210,
                                      40201228,
                                      40201236,
                                      40201244,
                                      40201252,
                                      40201260)
           And It.Tp_Status = '4')

 Group By p.Cd_Prestador, p.Nm_Prestador

/*Select *
  From Temp_Cooperado_202212;
*/
/*
 Create Table TEMP_COOPERADO_202212 As
 Select l.Cd_Prestador,
       Pr.Nm_Prestador,
      Sum(l.Vl_Producao_Medica) Valor,
       p.Dt_Competencia
  From Repasse_Prestador l, Pagamento_Prestador p, Dbaps.Prestador Pr
Where l.Cd_Pagamento_Prestador = p.Cd_Pagamento_Prestador
   And Pr.Cd_Prestador = l.Cd_Prestador
   And p.Dt_Competencia Between '01/12/2022' And '31/12/2022'
   And p.Cd_Tip_Prestador = 0
   And p.Tp_Prestador = 'F'
   And l.Vl_Producao_Medica = 0
Group By l.Cd_Prestador, Pr.Nm_Prestador, p.Dt_Competencia
Order By 2
*/

/*Select From Dbaps.v_Ctas_Medicas v
 Where v.Dt_Competencia = '202212'
   And v.Tp_Situacao_Conta In ('AA', 'AT')
   And v.Tp_Situacao_Itconta In ('AA', 'AT')
   And v.Tp_Situacao_Equipe In ('AA', 'AT')
   And v.Tp_Pagcob In ('CP', 'PN')
   And v.Cd_Prestador_Pagamento Is Not Null

  Select l.Cd_Prestador,
         Pr.Nm_Prestador,
         Sum(l.Vl_Producao_Medica) Valor,
         p.Dt_Competencia
          From Repasse_Prestador   l,
         Pagamento_Prestador p,
         Dbaps.Prestador     Pr
         Where l.Cd_Pagamento_Prestador = p.Cd_Pagamento_Prestador
           And Pr.Cd_Prestador = l.Cd_Prestador
           And p.Dt_Competencia Between '01/12/2022' And '31/12/2022'
           And p.Cd_Tip_Prestador = 0
           And p.Tp_Prestador = 'F'
        -- And l.Vl_Producao_Medica = 0
         Group By l.Cd_Prestador, Pr.Nm_Prestador, p.Dt_Competencia
         Order By 2*/
