Select v.Tp_Conta,
       v.Cd_Protocolo_Ctamed,
       v.Cd_Fatura,
       v.Cd_Lote,
       v.Cd_Conta_Medica,
       v.Nr_Guia,
       v.Cd_Unimed_Origem,
       v.Nr_Carteira_Beneficiario,
       (Select p.Cd_Grupo_Procedimento
          From Dbaps.Procedimento p
         Where p.Cd_Procedimento = v.Cd_Procedimento) As Grupo_Procedimento,
       v.Cd_Procedimento,
       v.Ds_Procedimento,
       v.Dt_Realizado,
       v.Qt_Pago,
       v.Cd_Lancamento,
       v.Cd_Lancamento_Equipe,
       v.Cd_Prestador As Cd_Prestador_Executor,
       (Select p.Nm_Prestador
          From Dbaps.Prestador p
         Where p.Cd_Prestador = v.Cd_Prestador) As Nm_Prestador_Executante,
       (Select p.Cd_Tip_Prestador
          From Dbaps.Prestador p
         Where p.Cd_Prestador = v.Cd_Prestador) As Tipo_Prestador_Executante,
       
       v.Cd_Prestador_Pagamento As Cd_Prestador_Pagamento,
       (Select p.Nm_Prestador
          From Dbaps.Prestador p
         Where p.Cd_Prestador = v.Cd_Prestador_Pagamento) As Nm_Prestador_Pagamento,
       (Select p.Cd_Tip_Prestador
          From Dbaps.Prestador p
         Where p.Cd_Prestador = v.Cd_Prestador_Pagamento) As Tipo_Prestador_Pagamento,
       v.Vl_Percentual_Pago,
       v.Cd_Atividade_Medica,
       v.Cd_Via_Acesso,
       v.Vl_Unit_Pago,
       Sum(v.Vl_Total_Pago) As Vl_Total_Pago,
       Sum(v.Vl_Total_Pago) / v.Qt_Pago As Divisao,
       (Select Vp.Vl_Referencia
          From Valor_Ref_Proc Vp
         Where Vp.Cd_Procedimento = v.Cd_Procedimento
         And vp.cd_tabela = 1000
           And Trunc(Vp.Dt_Vigencia) =
               (Select Max(Trunc(Vpp.Dt_Vigencia))
                  From Valor_Ref_Proc Vpp
                 Where Vpp.Cd_Procedimento = Vp.Cd_Procedimento
                   And Vpp.Cd_Tabela = Vpp.Cd_Tabela
                   And vpp.cd_tabela = 1000
                   And v.Dt_Realizado >= Vpp.Dt_Vigencia)) As Valor_Ref_Proc_Mais_Vigente
  From v_Ctas_Medicas v
 Where v.Dt_Competencia = '202306'
   And v.Tp_Situacao_Conta In ('AA', 'AT')
   And v.Tp_Situacao_Itconta In ('AA', 'AT')
   And v.Tp_Situacao_Equipe In ('AA', 'AT')
   And v.Tp_Pagcob In ('CP', 'PN')
   And v.cd_unimed_origem = '018'
      
   And Exists
 (Select 1
          From Temp_Acerto_202306_Coop t
         Where t.Cd_Lote = v.Cd_Lote
           And t.Cd_Conta_Medica = v.Cd_Conta_Medica
           And t.Cd_Lancamento = v.Cd_Lancamento
           And t.Cd_Lancamento_Equipe = v.Cd_Lancamento_Equipe)

 Group By v.Tp_Conta,
          v.Cd_Protocolo_Ctamed,
          v.Cd_Fatura,
          v.Cd_Prestador,
          v.Cd_Prestador_Pagamento,
          v.Cd_Lote,
          v.Cd_Conta_Medica,
          v.Cd_Procedimento,
          v.Cd_Lancamento,
          v.Nr_Guia,
          v.Cd_Unimed_Origem,
          v.Ds_Procedimento,
          v.Nr_Carteira_Beneficiario,
          v.Qt_Pago,
          v.Cd_Via_Acesso,
          v.Vl_Unit_Pago,
          v.Dt_Realizado,
          v.Vl_Percentual_Pago,
          v.Cd_Atividade_Medica,
          v.Dt_Competencia,
          v.Cd_Lancamento_Equipe

-- Delete From Temp_Acerto_202306_Coop
