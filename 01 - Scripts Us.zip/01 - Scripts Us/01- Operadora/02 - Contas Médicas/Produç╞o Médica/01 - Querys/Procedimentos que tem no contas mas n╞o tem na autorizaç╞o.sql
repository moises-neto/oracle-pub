/*competencia 06/2022
fatura 39489
cart�o diferente de 018
itens da tela de autoriza��o que estejam divergente da tela do contas


*/

Select v.Cd_Fatura,
       v.Cd_Lote,
       v.Nr_Guia,
       v.Nr_Guia_Prestador,
       Nvl(v.Cd_Procedimento, v.Cd_Procedimento_Digitado) As Procedimento,
       v.Cd_Prestador_Pagamento,
       (Select p.Nm_Prestador
          From Prestador p
         Where p.Cd_Prestador = v.Cd_Prestador_Pagamento) As Nm_Prestador
  From v_Ctas_Medicas v
 Where v.Cd_Fatura = 39489
   And v.Cd_Matricula Is Null
      
   And Not Exists
 (Select 1
          From Dbaps.Guia g, Dbaps.Itguia It
         Where g.Nr_Guia = It.Nr_Guia
           And g.Nr_Guia = v.Nr_Guia
           And Nvl(It.Cd_Procedimento, It.Cd_Procedimento_Autorizadorweb) =
               Nvl(v.Cd_Procedimento, v.Cd_Procedimento_Digitado)
        
        Union
        
        Select 1
          From Dbaps.Guia g, Dbaps.Itguia It
         Where g.Nr_Guia = It.Nr_Guia
           And g.Cd_Ptu_Mensagem_Origem = v.Cd_Ptu_Mensagem_Origem
           And Nvl(It.Cd_Procedimento, It.Cd_Procedimento_Autorizadorweb) =
               Nvl(v.Cd_Procedimento, v.Cd_Procedimento_Digitado)
        
        )
