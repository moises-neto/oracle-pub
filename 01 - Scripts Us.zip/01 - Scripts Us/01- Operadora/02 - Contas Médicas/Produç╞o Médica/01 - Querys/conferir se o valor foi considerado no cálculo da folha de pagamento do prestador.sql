
/*CONFERIR SE ENTROU NA FOLHA*/  
-- 1-  Guardar o valor vl_producao_medica:40476,94 
-- 2- Pegar o cd_repasse_prestador e pesquisar na v_ctas_medicas
Select * From dbaps.repasse_prestador rp
Where rp.cd_prestador = 800005
And rp.cd_con_pag Is Null
And rp.sn_fechado = 'N';

-- 3- Pesquisar o cd_repasse_prestador na v_ctas_medicas
-- 4- Somar o vl_total_pago total pago e ver se bate com o conferir se bate vl_producao_medica da  repasse_prestador
Select Sum(vc.vl_total_pago) From dbaps.v_ctas_medicas vc
Where vc.cd_prestador_pagamento = '800005'
And vc.cd_repasse_prestador = 380908;


-- 1-  Guardar o valor vl_producao_medica:40476,94 
-- 2- Pegar o cd_repasse_prestador e pesquisar na v_ctas_medicas
Select * From dbaps.repasse_prestador rp
Where rp.cd_prestador = 800020
And rp.cd_con_pag Is Null
And rp.sn_fechado = 'N';

-- 3- Pesquisar o cd_repasse_prestador na v_ctas_medicas
-- 4- Somar o vl_total_pago total pago e ver se bate com o conferir se bate vl_producao_medica da  repasse_prestador
Select Sum(vc.vl_total_pago) From dbaps.v_ctas_medicas vc
Where vc.cd_prestador_pagamento = '800020'
And vc.cd_repasse_prestador = 380828;
