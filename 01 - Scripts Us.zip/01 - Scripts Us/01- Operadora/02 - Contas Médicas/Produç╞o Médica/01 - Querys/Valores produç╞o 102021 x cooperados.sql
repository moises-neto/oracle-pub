/*
CH2110-5457 - Valores produ��o 10/2021 x cooperados

Solicitamos os valores da produ��o m�dica dos cooperados em anexo referente ao m�s 10/2021 e fatura q consta
conta. Motivo:
Precisamos realizar os descontos e n�o podemos ultrapassar o
valor de 25% da produ��o m�dica.
Constar somente CRM - Nome do Cooperado, R$ da produ��o e
fatura para lan�armos o desconto.

*/

/*TAB=Valores da Producao 202110 X Cooperado*/
Select v.Cd_Prestador_Pagamento,
       Sum(v.Vl_Total_Pago) Total_Pago,
       (Sum(v.Vl_Total_Pago) / 4) Parcial,
       Min(v.Cd_Fatura) Cd_Fatura
  From v_Ctas_Medicas v
 Where v.Dt_Competencia = '202110'
   And v.Cd_Prestador_Pagamento In
       ('45096',
        '49152',
        '51689',
        '60301',
        '63325',
        '64097',
        '66510',
        '69180',
        '70385',
        '72768',
        '76596',
        '76597',
        '76954',
        '79678',
        '79914',
        '80399',
        '88901',
        '92613',
        '93579',
        '96567',
        '100841',
        '102000',
        '102587',
        '103220',
        '103698',
        '105080',
        '107774',
        '107801',
        '108765',
        '111965',
        '113204',
        '114032',
        '118872',
        '121461',
        '121557',
        '121817',
        '123802',
        '126775',
        '128976',
        '129804',
        '129823',
        '130086',
        '130478',
        '133973',
        '137122',
        '139974',
        '145131',
        '150323',
        '151586',
        '153647',
        '156223',
        '157819',
        '161931',
        '163110',
        '169273',
        '1000402',
        '107801',
        '111965',
        '129823',
        '161931',
        '51689',
        '60301',
        '63325')
 Group By v.Cd_Prestador_Pagamento
 Order By 1;

/*TAB=Prestador_Nao_Encontrados*/
Select Pr.Cd_Prestador, Pr.Nm_Prestador
  From Dbaps.Prestador Pr
 Where Pr.Cd_Prestador In ('45096',
                           '49152',
                           '51689',
                           '60301', 
                           '63325',
                           '64097',
                           '66510',
                           '69180',
                           '70385',
                           '72768',
                           '76596',
                           '76597',
                           '76954',
                           '79678',
                           '79914',
                           '80399',
                           '88901',
                           '92613',
                           '93579',
                           '96567',
                           '100841',
                           '102000',
                           '102587',
                           '103220',
                           '103698',
                           '105080',
                           '107774',
                           '107801',
                           '108765',
                           '111965',
                           '113204',
                           '114032',
                           '118872',
                           '121461',
                           '121557',
                           '121817',
                           '123802',
                           '126775',
                           '128976',
                           '129804',
                           '129823',
                           '130086',
                           '130478',
                           '133973',
                           '137122',
                           '139974',
                           '145131',
                           '150323',
                           '151586',
                           '153647',
                           '156223',
                           '157819',
                           '161931',
                           '163110',
                           '169273',
                           '1000402',
                           '107801',
                           '111965',
                           '129823',
                           '161931',
                           '51689',
                           '60301',
                           '63325')
   And Not Exists
 (Select 1
          From v_Ctas_Medicas v
         Where v.Dt_Competencia = '202110'
           And v.Cd_Prestador_Pagamento = Pr.Cd_Prestador)
 Order By 1;
