Select v.Cd_Protocolo_Ctamed,
       v.Cd_Fatura,
       v.Cd_Lote,
       v.Cd_Conta_Medica,
       v.Cd_Lancamento,
       v.Cd_Procedimento,
       (Select p.Ds_Procedimento
          From Dbaps.Procedimento p
         Where p.Cd_Procedimento = v.Cd_Procedimento) As Ds_Procedimento,
       v.Cd_Prestador_Principal,
       (Select p.Nm_Prestador
          From Dbaps.Prestador p
         Where p.Cd_Prestador = v.Cd_Prestador_Principal) As Nm_Prestador_Principal,
       (Select Tp.Cd_Tip_Prestador || ' - ' || Tp.Nm_Prestador
          From Dbaps.Tip_Prestador Tp, Dbaps.Prestador p
         Where Tp.Cd_Tip_Prestador = p.Cd_Tip_Prestador
           And p.Cd_Prestador = v.Cd_Prestador_Principal) As Tipo_Prestador_Principal,

       v.Cd_Prestador As Prestador_Executante,
       (Select p.Nm_Prestador
          From Dbaps.Prestador p
         Where p.Cd_Prestador = v.Cd_Prestador) As Nm_Prestador_Executante,
          (Select Tp.Cd_Tip_Prestador || ' - ' || Tp.Nm_Prestador
          From Dbaps.Tip_Prestador Tp, Dbaps.Prestador p
         Where Tp.Cd_Tip_Prestador = p.Cd_Tip_Prestador
           And p.Cd_Prestador = v.Cd_Prestador) As Tipo_Prestador_Executante,
       v.Cd_Prestador_Pagamento As Prestador_Pagamento,
       (Select p.Nm_Prestador
          From Dbaps.Prestador p
         Where p.Cd_Prestador = v.Cd_Prestador_Pagamento) As Nm_Prestador_Pagamento,
          (Select Tp.Cd_Tip_Prestador || ' - ' || Tp.Nm_Prestador
          From Dbaps.Tip_Prestador Tp, Dbaps.Prestador p
         Where Tp.Cd_Tip_Prestador = p.Cd_Tip_Prestador
           And p.Cd_Prestador = v.cd_prestador_pagamento) As Tipo_Prestador_Pagamento,
       v.Vl_Total_Pago
  From v_Ctas_Medicas v

 Where v.Dt_Competencia = '202307'
   And v.Cd_Prestador <> v.Cd_Prestador_Principal
   And v.Cd_Tipo_Atendimento In (1, 2)

   And Exists (Select 1
          From Dbaps.Prestador p
         Where p.Cd_Prestador = v.Cd_Prestador_Principal
           And p.Cd_Tip_Prestador In (0, 18,27))
