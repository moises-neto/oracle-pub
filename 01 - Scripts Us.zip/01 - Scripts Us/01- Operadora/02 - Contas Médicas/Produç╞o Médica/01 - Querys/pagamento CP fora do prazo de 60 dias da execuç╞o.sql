/*
extrair relat�rio da compet�ncia, pagamento CP fora do prazo de 60 dias da execu��o - 
mostrar para Fernanda antes de pagar
*/

Select v.Cd_Fatura,
       v.Cd_Lote,
       v.Cd_Conta_Medica,
       v.Cd_Procedimento,
       (Select p.Ds_Procedimento
          From Dbaps.Procedimento p
         Where p.Cd_Procedimento = v.Cd_Procedimento) As Ds_Procedimento,
       v.Vl_Total_Pago,
       v.Cd_Prestador,
       (Select Pr.Nm_Prestador
          From Dbaps.Prestador Pr
         Where Pr.Cd_Prestador = v.Cd_Prestador) As Nm_Prestador,
       v.Dt_Realizado,
       v.Tp_Pagcob,
       Trunc(v.Dt_Apresentacao_Conta_Medica) As Dt_Apresentacao_Conta_Medica,
       Trunc(v.Dt_Apresentacao_Conta_Medica) - Trunc(v.Dt_Realizado) As Qtde_Dias_Pos_Execucao
  From Dbaps.v_Ctas_Medicas v
 Where v.Dt_Competencia = '202207'
   And v.Tp_Pagcob In ('CP', 'PN')
   And Trunc(v.Dt_Apresentacao_Conta_Medica) - Trunc(v.Dt_Realizado) > = 60
