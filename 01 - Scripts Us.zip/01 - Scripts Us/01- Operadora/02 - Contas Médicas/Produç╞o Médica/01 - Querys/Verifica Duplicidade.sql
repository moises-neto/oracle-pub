Select Distinct Cd_Protocolo_Ctamed,
                Dt_Competencia,
                Cd_Fatura,
                Cd_Lote,
                Nr_Guia,
                v.Qt_Cobrado,
                Cd_Conta_Medica,
                Cd_Lancamento,
                v.Vl_Percentual_Pago,
                v.Cd_Prestador_Principal,
                v.Nr_Carteira_Beneficiario,
                Trunc(v.Dt_Realizado),
                Tp_Pagcob,
                Cd_Motivo_Itconta,
                v.Cd_Procedimento,
                v.Sn_Refaturar,
                Tp_Fatura,
                v.cd_tipo_atendimento

  From v_Ctas_Medicas v
 Where v.nr_guia = 104505209  --v.nr_carteira_beneficiario = '8650000676841097'
--- And
  And v.cd_procedimento = 20103492 
  
 --And v.Nr_Guia = 96491379
 --And v.Cd_Procedimento = '00679461'
 And Trunc(v.dt_realizado) = '14/07/2022';
