Select p.Cd_Procedimento, p.Cd_Termo
  From Procedimento_Uni_Med_Tnumm p
 Where p.Cd_Procedimento = 79023185
   And Trunc(p.Dt_Inicio_Vigencia_Arquivo) =
       (Select Max(Trunc(Pp.Dt_Inicio_Vigencia_Arquivo))
          From Dbaps.Procedimento_Uni_Med_Tnumm Pp
         Where Pp.Cd_Procedimento = p.Cd_Procedimento);



Begin

  For i In (Select It.Cd_Conta_Hospitalar,
                   It.Cd_Lancamento,
                   It.Sn_Liberado,
                   Ih.Cd_Procedimento,
                   Ih.Cd_Termo,
                   (Select p.Cd_Termo
                      From Procedimento_Uni_Med_Tnumm p
                     Where p.Cd_Procedimento = Ih.Cd_Procedimento
                       And Trunc(p.Dt_Inicio_Vigencia_Arquivo) =
                           (Select Max(Trunc(Pp.Dt_Inicio_Vigencia_Arquivo))
                              From Dbaps.Procedimento_Uni_Med_Tnumm Pp
                             Where Pp.Cd_Procedimento = p.Cd_Procedimento)) As Cd_Termo_Correto
              From Dbaps.Itcontah_Rejeitada_Log It,
                   Dbaps.Itconta_Hospitalar     Ih
            
             Where It.Cd_Conta_Hospitalar = Ih.Cd_Conta_Hospitalar
               And It.Cd_Lancamento = Ih.Cd_Lancamento
               And It.Cd_Motivo = 9707
               And It.Sn_Liberado = 'N'
               --And ih.cd_conta_hospitalar = 228220
               --And ih.cd_lancamento = 532
               And Exists
             (Select 1
                      From Dbaps.v_Ctas_Medicas v
                     Where v.Cd_Conta_Medica = It.Cd_Conta_Hospitalar
                       And v.Cd_Lancamento = It.Cd_Lancamento
                       And v.Dt_Competencia = '202306')) Loop
     
  
  Update dbaps.itconta_hospitalar ih    
  Set ih.cd_termo = i.cd_termo_correto
  Where ih.cd_conta_hospitalar = i.cd_conta_hospitalar
  And ih.cd_lancamento = i.cd_lancamento;
  
  
    Dbms_Output.Put_Line('Conta: ' || i.Cd_Conta_Hospitalar ||
                         ' Lancamento: ' || i.Cd_Lancamento ||
                         ' cd_termo old: ' || i.Cd_Termo ||
                         ' Cd_termo_new: ' || i.Cd_Termo_Correto);
  
  End Loop;

End;






