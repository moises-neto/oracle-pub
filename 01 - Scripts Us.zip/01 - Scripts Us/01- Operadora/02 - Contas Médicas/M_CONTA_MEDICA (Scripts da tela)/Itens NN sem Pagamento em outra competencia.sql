/*ITENS COM NN SEM PAGAMENTO EM OUTRA COMPET�NCIA

Validar se todos os itens com NN j� tem pagamento em qualquer outra compet�ncia.

Olhar se tem CP e c�digo de repasse*/
Select Vc.Dt_Competencia,
       Vc.Cd_Fatura,
       Vc.Cd_Lote,
       (Select l.Cd_Tipo_Atendimento || ' - ' || Ta.Ds_Tipo_Atendimento
          From Dbaps.Lote l, Dbaps.Tipo_Atendimento Ta
         Where l.Cd_Tipo_Atendimento = Ta.Cd_Tipo_Atendimento
           And l.Cd_Lote = Vc.Cd_Lote) As Tipo_Lote,
       Vc.Nr_Guia,
       Vc.Tp_Conta,
       Vc.Cd_Conta_Medica,
       Vc.Nr_Carteira_Beneficiario,
       Vc.Nm_Beneficiario,
       Vc.Cd_Lancamento,
       Trunc(Vc.Dt_Realizado) Dt_Realizado,
       Vc.Cd_Procedimento,
       (Select Po.Ds_Procedimento
          From Dbaps.Procedimento Po
         Where Po.Cd_Procedimento = Vc.Cd_Procedimento) Ds_Procedimento,
       
       Vc.Cd_Prestador_Principal,
       (Select Pr.Nm_Prestador
          From Dbaps.Prestador Pr
         Where Pr.Cd_Prestador = Vc.Cd_Prestador_Principal) Nm_Prestador,
       
       Vc.Tp_Pagcob,
       
       (Select Distinct Vf.Cd_Mens_Contrato
          From Dbaps.v_Ctas_Medicas_Fatura Vf
         Where Vf.Cd_Lote = Vc.Cd_Lote
           And Vf.Cd_Conta_Medica = Vc.Cd_Conta_Medica
           And Vf.Cd_Lancamento = Vc.Cd_Lancamento) Cd_Mens_Contrato,
       Vc.Cd_Motivo_Itconta,
       Vc.Tp_Situacao_Itconta

  From Dbaps.v_Ctas_Medicas Vc
 Where Vc.Dt_Competencia = To_Char(Sysdate, 'YYYYMM')
      
   And Vc.Tp_Pagcob = 'NN'
   And Vc.Tp_Fatura = 'P'
   And Vc.Sn_Refaturar = 'N'
   And Vc.Tp_Conta = 'A'
   And Vc.Cd_Fatura <> 40731
   And Exists
 (Select 1
          From Dbaps.v_Ctas_Medicas Vv
         Where Vv.Cd_Procedimento = Vc.Cd_Procedimento
           And Trunc(Vv.Dt_Realizado) = Trunc(Vc.Dt_Realizado)
           And Vv.Nr_Carteira_Beneficiario = Vc.Nr_Carteira_Beneficiario
           And Vv.Cd_Prestador_Principal = Vc.Cd_Prestador_Principal
           And Vv.Vl_Percentual_Pago = Vc.Vl_Percentual_Pago
              
           And Vv.Tp_Fatura = 'P'
           And Vv.Sn_Refaturar = 'N'
           And Vv.Cd_Motivo_Itconta Is Null
           And Vv.Tp_Conta = 'A'
           And Vv.Cd_Conta_Medica <> Vc.Cd_Conta_Medica
           And Vv.Nr_Guia = Vc.Nr_Guia
           And Vv.Dt_Competencia >= '202201'
           And Vv.Cd_Fatura <> 40731
           And Vv.Cd_Repasse_Prestador Is Null
           And Vv.Tp_Pagcob <> 'NN'
           And Vv.Dt_Competencia <> Vc.Dt_Competencia)
      
   And Vc.Cd_Repasse_Prestador Is Null
