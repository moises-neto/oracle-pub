Select * From itconta 10769300,  
10769303,  
10769303,  
10655901,  
10655904,  
11048992,





prc_analisa_conta_amb_cliente (Ponto de entrada para contas de Consulta e SADT).

prc_analisa_conta_hosp_cliente  (Ponto de entrada para contas de internacao).


Select v.*, Rowid From Ctamed_Amb_Erros v
Where v.cd_remessa_itremaudit
 In (10769303)
And v.cd_motivo In (231,9728)


Select cc.* From Dbaps.Conta_Medica_Contestacao cc
Where cc.cd_conta_medica In(10769303, 10655901, 10655904)
