/*VERIFICAR SE H� ITENS COM A SITUA��O NA E CONTA AA NA COMPET�NCIA

conta com a CONTA AA por�m, item NA (precisa auditar o item antes de fechar fatura pois n�o valoriza no demonstrativo)*/

Select Distinct v.Cd_Fatura,
                v.Cd_Lote,
                (Select l.Cd_Tipo_Atendimento || ' - ' ||
                        Ta.Ds_Tipo_Atendimento
                   From Dbaps.Lote l, Dbaps.Tipo_Atendimento Ta
                  Where l.Cd_Tipo_Atendimento = Ta.Cd_Tipo_Atendimento
                    And l.Cd_Lote = v.Cd_Lote) As Tipo_Lote,
                v.Cd_Conta_Medica,
                v.Cd_Procedimento,
                v.Cd_Lancamento,
                
                (Select Distinct Ipf.Cd_Mens_Contrato
                   From Itremessa_Prestador_Fatura Ipf
                  Where Ipf.Cd_Remessa = v.Cd_Conta_Medica
                    And Ipf.Cd_Lancamento = v.Cd_Lancamento
                    And Rownum = 1
                 
                 Union All
                 
                 Select Distinct Ihf.Cd_Mens_Contrato
                   From Itconta_Hospitalar_Fatura Ihf
                  Where Ihf.Cd_Conta_Hospitalar = v.Cd_Conta_Medica
                    And Ihf.Cd_Lancamento = v.Cd_Lancamento
                    And Rownum = 1) As Mens_Contrato,
                v.Tp_Pagcob,
                v.Tp_Situacao_Conta,
                v.Tp_Situacao_Itconta

  From Dbaps.v_Ctas_Medicas v

 Where v.Dt_Competencia = To_Char(Sysdate, 'YYYYMM')
   And v.Tp_Situacao_Conta = 'AA'
   And v.Tp_Situacao_Itconta = 'NA'
