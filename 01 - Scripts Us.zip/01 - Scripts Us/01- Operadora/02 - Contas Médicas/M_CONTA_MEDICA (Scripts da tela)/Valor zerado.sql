--Pagamento--

/*Select *
 From (Select v.Cd_Fatura,
 v.Cd_Lote,
 (Select l.Cd_Tipo_Atendimento || ' - ' ||
 Ta.Ds_Tipo_Atendimento
 From Dbaps.Lote l, Dbaps.Tipo_Atendimento Ta
 Where l.Cd_Tipo_Atendimento = Ta.Cd_Tipo_Atendimento
 And l.Cd_Lote = v.Cd_Lote) As Tipo_Lote,
 v.Cd_Conta_Medica,
 v.Cd_Procedimento,
 v.Cd_Lancamento,
 Sum(v.Vl_Unit_Pago_Original) As Valor_Somado,
 (Select Distinct Ipf.Cd_Mens_Contrato
 From Itremessa_Prestador_Fatura Ipf
 Where Ipf.Cd_Remessa = v.Cd_Conta_Medica
 And Ipf.Cd_Lancamento = v.Cd_Lancamento
 And Rownum = 1
 
 Union All
 
 Select Distinct Ihf.Cd_Mens_Contrato
 From Itconta_Hospitalar_Fatura Ihf
 Where Ihf.Cd_Conta_Hospitalar = v.Cd_Conta_Medica
 And Ihf.Cd_Lancamento = v.Cd_Lancamento
 And Rownum = 1) As Mens_Contrato,
 v.Tp_Pagcob,
 v.Tp_Situacao,
 v.Tp_Situacao_Itconta
 
 From Dbaps.v_Ctas_Medicas v
 
 
 Where v.Dt_Competencia = To_Char(Sysdate, 'YYYYMM')
 
 And Exists (Select 1
 From v_Ctas_Medicas Vv
 Where Vv.Cd_Conta_Medica = v.Cd_Conta_Medica
 And Vv.Vl_Unit_Pago In ('0,01', '0')
 And Vv.Dt_Competencia = To_Char(Sysdate, 'YYYYMM')
 And v.Tp_Fatura = 'P'
 And (Vv.Tp_Situacao_Conta = 'AA' And
 Vv.Tp_Situacao_Itconta = 'AA')
 And Vv.Tp_Pagcob In ('PN', 'CP') 
 And vv.tp_situacao <> 'GT'
 
 Union All
 Select 1
 From v_Ctas_Medicas Vv
 Where Vv.Cd_Conta_Medica = v.Cd_Conta_Medica
 And Vv.Vl_Unit_Pago_Original In ('0,01', '0')
 And Vv.Dt_Competencia = To_Char(Sysdate, 'YYYYMM')
 And v.Tp_Fatura = 'P'
 And (Vv.Tp_Situacao_Conta = 'AA' And
 Vv.Tp_Situacao_Itconta = 'AA')
 And Vv.Tp_Pagcob In ('PN', 'CP')
 And vv.tp_situacao <> 'GT'
 
 )
 
 And Not Exists
 (Select 1
 From Dbaps.Procedimento p
 Where p.Cd_Procedimento = v.Cd_Procedimento
 And p.Cd_Grupo_Procedimento In (1021, 1022))
 
 Group By v.Cd_Lote,
 v.Cd_Conta_Medica,
 v.Cd_Procedimento,
 v.Cd_Lancamento,
 v.Cd_Fatura,
 v.Cd_Motivo_Itconta,
 v.Cd_Motivo_Equipe,
 v.Tp_Situacao,
 v.Tp_Pagcob,
 v.Tp_Situacao_Itconta) x
 Where x.Valor_Somado In ('0', '0,01')
*/

--SADT E CONSULTA
Select a.*
  From (Select f.Cd_Fatura,
               l.Cd_Lote,
               (Select Ta.Cd_Tipo_Atendimento || ' - ' ||
                       Ta.Ds_Tipo_Atendimento
                  From Dbaps.Tipo_Atendimento Ta
                 Where Ta.Cd_Tipo_Atendimento = l.Cd_Tipo_Atendimento) As Tipo_Lote,
               
               Rp.Cd_Remessa As Conta,
               Ip.Cd_Procedimento,
               Ip.Cd_Lancamento,
               (Select Distinct Ipf.Cd_Mens_Contrato
                  From Itremessa_Prestador_Fatura Ipf
                 Where Ipf.Cd_Remessa = Rp.Cd_Remessa
                   And Ipf.Cd_Lancamento = Ip.Cd_Lancamento
                   And Rownum = 1) As Mensalidade,
               Ip.Tp_Pagcob,
               Ip.Tp_Situacao As Situacao_Item,
               
               Sum(Ipe.Vl_Unit_Pago) As Valor
          From Dbaps.Itremessa_Prestador        Ip,
               Dbaps.Itremessa_Prestador_Equipe Ipe,
               Dbaps.Remessa_Prestador          Rp,
               Dbaps.Lote                       l,
               Dbaps.Fatura                     f
         Where Rp.Cd_Remessa = Ip.Cd_Remessa
           And Ip.Cd_Remessa = Ipe.Cd_Remessa
           And Ip.Cd_Lancamento = Ipe.Cd_Lancamento
           And Rp.Cd_Lote = l.Cd_Lote
           And l.Cd_Fatura = f.Cd_Fatura
           And f.Nr_Ano || f.Nr_Mes = To_Char(Sysdate, 'YYYYMM')
           And (Rp.Tp_Situacao = 'AA' And Ip.Tp_Situacao = 'AA' And
               Ipe.Tp_Situacao = 'AA')
              
           And Ip.Tp_Pagcob In ('PN', 'CP')
           And f.Tp_Fatura = 'P'
           And Not Exists
         (Select 1
                  From Dbaps.Procedimento p
                 Where p.Cd_Procedimento = Ip.Cd_Procedimento
                   And p.Cd_Grupo_Procedimento In (1021, 1022))
        
         Group By Rp.Cd_Remessa,
                  f.Cd_Fatura,
                  l.Cd_Lote,
                  Ip.Cd_Procedimento,
                  Ip.Cd_Lancamento,
                  Ip.Tp_Pagcob,
                  Ip.Tp_Situacao,
                  l.Cd_Tipo_Atendimento) a
 Where a.Valor In ('0,01', '0')

Union All --INTERNA��O E HONOR�RIO 

Select a.*
  From (Select f.Cd_Fatura,
               l.Cd_Lote,
               (Select Ta.Cd_Tipo_Atendimento || ' - ' ||
                       Ta.Ds_Tipo_Atendimento
                  From Dbaps.Tipo_Atendimento Ta
                 Where Ta.Cd_Tipo_Atendimento = l.Cd_Tipo_Atendimento) As Tipo_Lote,
               
               Ch.Cd_Conta_Hospitalar As Conta,
               Ih.Cd_Procedimento,
               Ih.Cd_Lancamento,
               (Select Distinct Ihf.Cd_Mens_Contrato
                  From Itconta_Hospitalar_Fatura Ihf
                 Where Ihf.Cd_Conta_Hospitalar = Ch.Cd_Conta_Hospitalar
                   And Ihf.Cd_Lancamento = Ih.Cd_Lancamento
                   And Rownum = 1) As Mensalidade,
               Ih.Tp_Pagcob,
               Ih.Tp_Situacao As Situacao_Item,
               
               Sum(Im.Vl_Unit_Pago) As Valor
          From Dbaps.Itconta_Hospitalar Ih,
               Dbaps.Itconta_Med        Im,
               Dbaps.Conta_Hospitalar   Ch,
               Dbaps.Lote               l,
               Dbaps.Fatura             f
         Where Ch.Cd_Conta_Hospitalar = Ih.Cd_Conta_Hospitalar
           And Ih.Cd_Conta_Hospitalar = Im.Cd_Conta_Hospitalar
           And Ih.Cd_Lancamento = Im.Cd_Lancamento
           And Ch.Cd_Lote = l.Cd_Lote
           And l.Cd_Fatura = f.Cd_Fatura
           And f.Nr_Ano || f.Nr_Mes = To_Char(Sysdate, 'YYYYMM')
           And (Ch.Tp_Situacao = 'AA' And Ih.Tp_Situacao = 'AA' And
               Im.Tp_Situacao = 'AA')
              
           And Ih.Tp_Pagcob In ('PN', 'CP')
           And f.Tp_Fatura = 'P'
           And Not Exists
         (Select 1
                  From Dbaps.Procedimento p
                 Where p.Cd_Procedimento = Ih.Cd_Procedimento
                   And p.Cd_Grupo_Procedimento In (1021, 1022))
        
         Group By Ch.Cd_Conta_Hospitalar,
                  f.Cd_Fatura,
                  l.Cd_Lote,
                  Ih.Cd_Procedimento,
                  Ih.Cd_Lancamento,
                  Ih.Tp_Pagcob,
                  Ih.Tp_Situacao,
                  l.Cd_Tipo_Atendimento) a
 Where a.Valor In ('0,01', '0')

---Cobran�a
