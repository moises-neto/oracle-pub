--Auditar todas as contas do Lote
prc_analisa_conta_hosp  --> Internação. 
DBAPS.FNC_MVS_ANALISA_CONTA_AMB--> Consulta e SADT.