/*
-Unimed Origem
-Carteiria
-Nome do paciente
-Lote
-Conta
-Guia
-Tipo de Guia
-Idade
-Ds Prestador e C�d pagamento
-Ds Prestador e C�d Executante
-Dt Realizado
-Cod Servico
-Descri��o do Servico
-Ds Procedimento Conta
-Qtde
-Valor
-Tipo de a��o
-Compet�ncia de Pagamento*/
Create Table levantamento_lais_v2 As
Select v.Cd_Unimed_Origem As "C�digo da Unimed Origem",
       (Select u.Ds_Unimed
          From Dbaps.Unimed u
         Where u.Cd_Unimed = v.Cd_Unimed_Origem) As "Nome Unimed",
       v.Nr_Carteira_Beneficiario As Carteira,
       
       v.Nm_Beneficiario As "Nome do Benefici�rio",
       v.Cd_Lote As Lote,
       v.Cd_Conta_Medica As Conta,
       Coalesce(To_Char(v.Nr_Guia),
                To_Char(v.Cd_Guia_Externa),
                To_Char(v.Nr_Guia_Prestador)) As Guia,
       (Select Ta.Ds_Tipo_Atendimento
          From Dbaps.Tipo_Atendimento Ta
         Where Ta.Cd_Tipo_Atendimento = v.Cd_Tipo_Atendimento) As "Tipo da Guia",
       Nvl((Select Dbaps.Fn_Idade(Pnascimento    => Us.Dt_Nascimento,
                                 Pdt_Comparacao => Trunc(v.Dt_Realizado))
             From Dbaps.Usuario Us
            Where Us.Cd_Matricula = v.Cd_Matricula),
           
           (Select Dbaps.Fn_Idade(Pnascimento    => Us.Dt_Nascimento,
                                  Pdt_Comparacao => Trunc(v.Dt_Realizado))
              From Dbaps.Beneficiario_Transito Us
             Where Us.Cd_Matricula = v.Nr_Carteira_Beneficiario)
           
           ) As Idade,
       v.Cd_Prestador_Pagamento As "C�digo Prestador Pagamento",
       (Select p.Nm_Prestador
          From Dbaps.Prestador p
         Where p.Cd_Prestador = v.Cd_Prestador_Pagamento) As "Nome Prestador Pagamento",
       
       Trunc(v.Dt_Realizado) As "Data Realiza��o",
       
       v.Cd_Procedimento As Codigo,
       (Select p.Ds_Procedimento
          From Dbaps.Procedimento p
         Where p.Cd_Procedimento = v.Cd_Procedimento) As "Descri��o do Procedimento",
       v.Qt_Pago As "Quantidade Paga",
       v.Vl_Total_Pago As "Valor Total Pago",
       v.Dt_Competencia_Pgto As "Compet�ncia pag",
       v.Dt_Competencia As "Compet�ncia Conta"

  From v_Ctas_Medicas v, Carteira_Lais c
 Where v.Nr_Carteira_Beneficiario = c.Carteira_2
   And v.Dt_Competencia Between '202201' And '202210'
   And v.Tp_Situacao_Conta In ('AA', 'AT')
   And v.Tp_Situacao_Itconta In ('AA', 'AT')
   And v.Tp_Situacao_Equipe In ('AA', 'AT')
   And v.Tp_Pagcob In ('CP', 'PN')
--  And v.Cd_Prestador_Pagamento In (92708, 75916, 49164, 92716, 117717)
