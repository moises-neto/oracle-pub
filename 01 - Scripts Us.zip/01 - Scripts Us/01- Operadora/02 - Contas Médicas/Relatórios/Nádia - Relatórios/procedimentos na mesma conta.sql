/*
Favor fazer o levantamento, referente os c�digos 31602240 e 31202231, e demais c�digos do grupo 40.20..., na mesma guia, 
na  mesma data e mesmo benefici�rio, per�odo de 01/22 � 04/22, 
identificar, guia e lote/ c�digo e descri��o dos procedimentos, data o hor�rio da realiza��o, 
nome e CRM dos m�dicos, grau de participa��o dos m�dicos, qtd. valor, e vias de acesso. , nome e cart�o do benefici�rio.
*/

Select v.Dt_Competencia,
       v.Cd_Lote,
       v.Cd_Conta_Medica,
       v.Nr_Guia,
       v.Nm_Beneficiario,
       v.Nr_Carteira_Beneficiario,
       v.Cd_Procedimento,
       (Select p.Ds_Procedimento
          From Procedimento p
         Where p.Cd_Procedimento = v.Cd_Procedimento) As Desc_Procedimento,
       v.Dt_Realizado,
       v.Hr_Inicial,
       v.Hr_Final,
       (Select Pr.Nm_Prestador
          From Dbaps.Prestador Pr
         Where Pr.Cd_Prestador = v.Cd_Prestador) As Nm_Prestador,
       
       (Select Pr.Ds_Cod_Conselho
          From Dbaps.Prestador Pr
         Where Pr.Cd_Prestador = v.Cd_Prestador) As Cod_Conselho,
       v.Cd_Atividade_Medica As Grau_Part,
       v.Qt_Pago,
       v.Vl_Total_Pago,
       Decode(v.Cd_Via_Acesso,
              '1',
              'UNICA',
              '2',
              'MESMA',
              '3',
              'DIFERENTES') Vias

  From v_Ctas_Medicas v

 Where v.Dt_Competencia Between '202201' And '202204'
      
   And v.Cd_Procedimento In ('31602240', '31202231')    
   And Exists
 (
        
        Select 1
          From Dbaps.Remessa_Prestador Rp, Itremessa_Prestador It
         Where Rp.Cd_Remessa = It.Cd_Remessa
           And Rp.Nr_Carteira_Beneficiario = v.Nr_Carteira_Beneficiario
           And Nvl(To_Char(Rp.Nr_Guia), Rp.Nr_Guia_Prestador) =
               Nvl(To_Char(v.Nr_Guia), v.Nr_Guia_Prestador)
           And It.Dt_Realizado = v.Dt_Realizado
           And substr(Nvl(It.Cd_Procedimento, It.Cd_Proc_Digita), 1, 4) = '4020'
        
        Union All
        
        Select 1
          From Dbaps.Conta_Hospitalar Ch, Itconta_Hospitalar Ich
         Where Ch.Cd_Conta_Hospitalar = Ich.Cd_Conta_Hospitalar
           And Ch.Nr_Carteira_Beneficiario = v.Nr_Carteira_Beneficiario
           And Nvl(To_Char(Ch.Nr_Guia), Ch.Nr_Guia_Prestador) =
               Nvl(To_Char(v.Nr_Guia), v.Nr_Guia_Prestador)
           And Ich.Dt_Lancamento = v.Dt_Realizado
           And Substr(Nvl(Ich.Cd_Procedimento, Ich.Cd_Proc_Digita), 1, 4) = '4020'
        
        )

--  And v.cd_conta_medica = 10742580
