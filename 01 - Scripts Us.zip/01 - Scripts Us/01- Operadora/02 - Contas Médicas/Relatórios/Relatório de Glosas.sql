Select Distinct 
                   x.Id_Ptu,
                   x.Ds_Arquivo,
                   x.Dh_Geracao,
                   x.Cd_Lote,
                   x.Cd_Conta_Medica,
                   x.Nr_Guia,
                   x.Cd_Prestador_Lote,
                   x.Nm_Prestador,
                   x.Tipo_Prestador,
                   x.Nr_Carteira_Beneficiario,
                   x.Nm_Beneficiario,
                   x.Cd_Unimed_Origem,
                   x.Unimed_Origem,
                   x.Periodo_A500,
                   x.Periodo_A550,
                   x.Nr_Fatura,
                   x.dt_vencimento,
                   x.Nota_Fiscal,
                   x.Cd_Lancamento,
                   x.Cd_Procedimento,
                   x.Ds_Procedimento,
                   x.Qt_Cobrado,
                   x.Qt_Reconh,
                   x.Cd_Motivo,
                   x.Ds_Motivo,
                   x.Tipo_Glosa,
                   x.Complemento_Glosa,
                   x.Todas_Glosas_Agrupadas,
                   
                   /*
                   Obs.: Para n�o repetir valores
                   os mesmos ser�o apresentados, apenas para o maior motivo de glosa
                   */
                   
                   x.Vl_Total_Cobrado,
                   
                   x.Vl_Total_Cobrado_Com_Taxa,
                   
                   x.Vl_Total_Reconhecido,
                   
                   x.Vl_Total_Reconhecido_Com_Taxa,
                   
                   (x.Vl_Total_Cobrado - x.Vl_Total_Reconhecido) Vl_Total_Contestado,
                   
                   (x.Vl_Total_Cobrado_Com_Taxa -
                   x.Vl_Total_Reconhecido_Com_Taxa) Vl_Total_Contestado_Com_Taxa,
                   
                   x.Tp_Acordo,
                   
                   x.Observacao
   
     From (Select t.Id_Ptu,
                  t.Ds_Arquivo,
                  t.Dh_Geracao,
                  t.Cd_Lote,
                  t.Cd_Conta_Medica,
                  t.Nr_Guia,
                  t.Cd_Prestador_Lote,
                  t.Nm_Prestador,
                  t.Tipo_Prestador,
                  t.Nr_Carteira_Beneficiario,
                  t.Nm_Beneficiario,
                  t.Cd_Unimed_Origem,
                  t.Unimed_Origem,
                  t.Periodo_A500,
                  t.Periodo_A550,
                  t.Nr_Fatura,
                  t.dt_vencimento,
                  t.Nota_Fiscal,
                  t.Cd_Lancamento,
                  t.Cd_Procedimento,
                  t.Ds_Procedimento,
                  t.Qt_Cobrado,
                  t.Qt_Reconh,
                  t.Cd_Motivo,
                  --t.maior_cd_motivo,
                  t.Ds_Motivo,
                  t.Tipo_Glosa,
                  
                  Listagg(t.Ds_Motivo_Rejeitado, ' // ') Within Group(Order By t.Ds_Motivo_Rejeitado) Complemento_Glosa,
                  Listagg(t.Cd_Motivo || ' - ' || t.Ds_Motivo, ' // ') Within Group(Order By t.Cd_Motivo) Todas_Glosas_Agrupadas,
                  
                  /*
                  Obs.: Para n�o repetir valores
                  os mesmos ser�o apresentados, apenas para o maior motivo de glosa
                  */
                  
                  Case
                    When t.Cd_Ptu_A550_Quest_Proc_Mot_Glo =
                         t.Maior_Cd_Quest_Proc_Mot_Glo Then
                     t.Vl_Total_Cobrado
                    Else
                     0
                  End Vl_Total_Cobrado,
                  
                  Case
                    When t.Cd_Ptu_A550_Quest_Proc_Mot_Glo =
                         t.Maior_Cd_Quest_Proc_Mot_Glo Then
                     t.Vl_Total_Cobrado_Com_Taxa
                    Else
                     0
                  End Vl_Total_Cobrado_Com_Taxa,
                  
                  Case
                    When t.Cd_Ptu_A550_Quest_Proc_Mot_Glo =
                         t.Maior_Cd_Quest_Proc_Mot_Glo Then
                     t.Vl_Total_Reconhecido
                    Else
                     0
                  End Vl_Total_Reconhecido,
                  
                  Case
                    When t.Cd_Ptu_A550_Quest_Proc_Mot_Glo =
                         t.Maior_Cd_Quest_Proc_Mot_Glo Then
                     t.Vl_Total_Reconhecido_Com_Taxa
                  End Vl_Total_Reconhecido_Com_Taxa,
                  
                  /*
                  case
                    when t.cd_motivo = t.maior_cd_motivo then
                     vl_total_contestado
                    else
                     0
                  end vl_total_contestado,
                  
                  case
                    when t.cd_motivo = t.maior_cd_motivo then
                     vl_total_contestado_com_taxa
                    else
                     0
                  end vl_total_contestado_com_taxa,*/
                  
                  t.Tp_Acordo,
                  
                  'OBS: Valores apresentados apenas para 1 motivo de glosa. Caso o item tenha mais de um motivo de glosa, favor verificar os valores no �ltimo c�digo de glosa.' Observacao /*,
                      
                                     (Vl_Total_Cobrado_Com_Taxa - t.Vl_Total_Reconhecido_Com_Taxa) Vl_Contestado*/
             From (Select
                   
                    A550.Cd_Ptu_Remessa_Retorno Id_Ptu,
                    A550.Ds_Arquivo,
                    A550.Dh_Geracao,
                    Vf.Cd_Lote,
                    Vf.Cd_Conta_Medica,
                    Nvl(Vf.Nr_Guia, Vf.Cd_Guia_Externa) Nr_Guia,
                    Vf.Cd_Prestador_Principal Cd_Prestador_Lote,
                    Pr.Nm_Prestador,
                    Tp.Nm_Prestador Tipo_Prestador,
                    Vf.Nr_Carteira_Beneficiario,
                    Vf.Nm_Beneficiario,
                    Vf.Cd_Unimed_Origem,
                    (Select Un.Ds_Unimed
                       From Dbaps.Unimed Un
                      Where Un.Cd_Unimed = Vf.Cd_Unimed_Origem) Unimed_Origem,
                    Vf.Dt_Competencia Periodo_A500,
                    To_Char(To_Date(A550.Dh_Geracao, 'DD/MM/YYYY'), 'YYYYMM') Periodo_A550,
                    --Vf.Cd_Mens_Contrato Nr_Fatura,
                    A500.Cd_Mens_Contrato Nr_Fatura,
                    /*(Select Distinct n.Nr_Nota_Fiscal_Eletronica
                     From Dbaps.Nota_Fiscal_Mvs n
                    Where n.Cd_Mens_Contrato = Vf.Cd_Mens_Contrato
                      And n.Cd_Contrato = Vf.Cd_Unimed_Origem) Nota_Fiscal,*/
                    (select mc.dt_vencimento
                       from dbaps.mens_contrato mc
                      where mc.cd_mens_contrato = A500.Cd_Mens_Contrato) dt_vencimento,
                    R1.Doc_Fiscal_1 Nota_Fiscal,
                    Vf.Cd_Lancamento,
                    Vf.Cd_Procedimento,
                    Po.Ds_Procedimento,
                    Vf.Qt_Pago Qt_Cobrado,
                    Pqp.Qt_Reconh,
                    R4.Nr_Seq,
                    Vf.Nr_Seq_A500,
                    R4.Cd_Lancamento R4_Cd_Lancamento,
                    Vf.Cd_Lancamento Vf_Cd_Lancamento,
                    
                    Pmg.Cd_Ptu_A550_Quest_Proc_Mot_Glo,
                    Mg.Cd_Motivo,
                    (Select Max(Pqm.Cd_Motivo_Ques)
                       From Dbaps.Ptu_A550_Quest_Proc_Mot_Glo Pqm
                      Where Pqm.Cd_Ptu_A550_Quest_Proc =
                            Pqp.Cd_Ptu_A550_Quest_Proc) Maior_Cd_Motivo,
                    (Select Max(Pqm.Cd_Ptu_A550_Quest_Proc_Mot_Glo)
                       From Dbaps.Ptu_A550_Quest_Proc_Mot_Glo Pqm
                      Where Pqm.Cd_Ptu_A550_Quest_Proc =
                            Pqp.Cd_Ptu_A550_Quest_Proc) Maior_Cd_Quest_Proc_Mot_Glo,
                    Pmg.Ds_Motivo_Ques Ds_Motivo_Rejeitado,
                    Mg.Ds_Motivo,
                    Tg.Tipo_Glosa,
                    ((R4.Vl_Serv_Cob + R4.Vl_Co_Cob + R4.Vl_Filme_Cob) / 100) Vl_Total_Cobrado,
                    ((R4.Vl_Serv_Cob + R4.Vl_Adic_Ser + R4.Vl_Co_Cob +
                    R4.Vl_Adic_Co + R4.Vl_Filme_Cob + R4.Vl_Adic_Filme) / 100) Vl_Total_Cobrado_Com_Taxa,
                    
                    --Sum(Vf.Vl_Total_Adicional_Cobrado) Vl_Total_Cobrado_Com_Taxa,
                    
                    Nvl((Nvl(Pqp.Vl_Reconh_Serv, 0) +
                        Nvl(Pqp.Vl_Reconh_Co, 0) +
                        Nvl(Pqp.Vl_Reconh_Filme, 0)),
                        0) Vl_Total_Reconhecido,
                    
                    Nvl((Nvl(Pqp.Vl_Reconh_Serv, 0) +
                        Nvl(Pqp.Vl_Reconh_Co, 0) +
                        Nvl(Pqp.Vl_Reconh_Filme, 0) +
                        Nvl(Pqp.Vl_Reconh_Adic_Serv, 0) +
                        Nvl(Pqp.Vl_Reconh_Adic_Co, 0) +
                        Nvl(Pqp.Vl_Reconh_Adic_Filme, 0)),
                        0) Vl_Total_Reconhecido_Com_Taxa,
                    
                    Pqp.Tp_Acordo
                   
                     From Dbaps.Ptu_A500_R504               R4,
                          Dbaps.Ptu_Remessa_Retorno         A500,
                          Dbaps.Ptu_A500_R502               R2,
                          Dbaps.Ptu_A500_R501               R1,
                          Dbaps.v_Ctas_Medicas_Fatura       Vf,
                          Dbaps.Ptu_Remessa_Retorno         A550,
                          Dbaps.Ptu_A550                    P550,
                          Dbaps.Ptu_A550_Quest              Pq,
                          Dbaps.Ptu_A550_Quest_Proc         Pqp,
                          Dbaps.Ptu_A550_Quest_Proc_Mot_Glo Pmg,
                          Dbaps.Procedimento                Po,
                          Dbaps.Prestador                   Pr,
                          Dbaps.Tip_Prestador               Tp,
                          Dbaps.Motivo_Glosa                Mg,
                          Dbaps.Tipo_Motivo_Glosa           Tg
                    Where R4.Cd_Ptu_Remessa_Retorno =
                          A500.Cd_Ptu_Remessa_Retorno
                      And R1.Cd_Ptu_Remessa_Retorno =
                          A500.Cd_Ptu_Remessa_Retorno
                      And R2.Cd_Ptu_Remessa_Retorno =
                          A500.Cd_Ptu_Remessa_Retorno
                      And Vf.Cd_Lote = R2.Nr_Lote
                      And Vf.Cd_Conta_Medica = R2.Nr_Nota
                      And Vf.Cd_Lancamento = R4.Cd_Lancamento
                      And Po.Cd_Procedimento = Vf.Cd_Procedimento
                      And Pr.Cd_Prestador = Vf.Cd_Prestador_Principal
                      And Tp.Cd_Tip_Prestador = Pr.Cd_Tip_Prestador
                      And R4.Cd_Ptu_A500_R502 = R2.Cd_Ptu_A500_R502
                      And A500.Tp_Status = 'E'
                      And A500.Ds_Motivo_Cancelamento Is Null
                      And A500.Cd_Usuario_Cancelamento Is Null
                         
                         /*And A500.Ds_Arquivo Like '%1628683%'*/
                         
                      And A500.Tp_Arquivo = 'A500'
                      And Substr(A550.Ds_Arquivo,
                                 5,
                                 Length(A550.Ds_Arquivo) -
                                 (Instr(A550.Ds_Arquivo, '.') - 4)) =
                          Substr(A500.Ds_Arquivo,
                                 2,
                                 Length(A500.Ds_Arquivo) -
                                 (Instr(A500.Ds_Arquivo, '.') - 4))
                         
                         --And A550.Ds_Arquivo Like '%1624088%'
                      And A550.Tp_Arquivo = 'A550'
                      And Substr(A550.Ds_Arquivo, 1, 3) = 'NC1'
                      And A550.Tp_Status = 'F'
                      And P550.Cd_Ptu_Remessa_Retorno =
                          A550.Cd_Ptu_Remessa_Retorno
                         
                      And Pq.Cd_Ptu_A550 = P550.Cd_Ptu_A550
                         
                      And Pqp.Cd_Ptu_A550_Quest = Pq.Cd_Ptu_A550_Quest
                      And Pqp.Seq_Itemtxt = R4.Nr_Seq
                      And Vf.Cd_Conta_Medica = Pq.Nr_Nota
                      And Vf.Cd_Lote = To_Number(Pq.Nr_Lote)
                      And Pmg.Cd_Ptu_A550_Quest_Proc =
                          Pqp.Cd_Ptu_A550_Quest_Proc
                      And Mg.Cd_Motivo = Pmg.Cd_Motivo_Ques
                      And Tg.Cd_Motivo = Mg.Cd_Motivo
                      And Pqp.Tp_Acordo <> '11'
                      And Mg.Cd_Motivo <> 99
                         
                         -- FILTRO
                      And To_Date(A550.Dh_Geracao, 'DD/MM/YYYY') Between
                          '01/03/2022' And '31/03/2022'
                          And a550.ds_arquivo Like '%1784395%'
                   
                   ) t
           
            Group By t.Id_Ptu,
                     t.Ds_Arquivo,
                     t.Dh_Geracao,
                     t.Cd_Lote,
                     t.Cd_Conta_Medica,
                     t.Nr_Guia,
                     t.Cd_Prestador_Lote,
                     t.Nm_Prestador,
                     t.Tipo_Prestador,
                     t.Nr_Carteira_Beneficiario,
                     t.Nm_Beneficiario,
                     t.Cd_Unimed_Origem,
                     t.Unimed_Origem,
                     t.Periodo_A500,
                     t.Periodo_A550,
                     t.Nr_Fatura,
                     t.dt_vencimento,
                     t.Nota_Fiscal,
                     t.Cd_Lancamento,
                     t.Cd_Procedimento,
                     t.Ds_Procedimento,
                     t.Qt_Cobrado,
                     t.Qt_Reconh,
                     t.Cd_Motivo,
                     --t.maior_cd_motivo,
                     t.Ds_Motivo,
                     t.Tipo_Glosa,
                     
                     /*
                     Obs.: Para n�o repetir valores
                     os mesmos ser�o apresentados, apenas para o maior motivo de glosa
                     */
                     
                     Case
                       When t.Cd_Ptu_A550_Quest_Proc_Mot_Glo =
                            t.Maior_Cd_Quest_Proc_Mot_Glo Then
                        t.Vl_Total_Cobrado
                       Else
                        0
                     End,
                     
                     Case
                       When t.Cd_Ptu_A550_Quest_Proc_Mot_Glo =
                            t.Maior_Cd_Quest_Proc_Mot_Glo Then
                        t.Vl_Total_Cobrado_Com_Taxa
                       Else
                        0
                     End,
                     
                     Case
                       When t.Cd_Ptu_A550_Quest_Proc_Mot_Glo =
                            t.Maior_Cd_Quest_Proc_Mot_Glo Then
                        t.Vl_Total_Reconhecido
                       Else
                        0
                     End,
                     
                     Case
                       When t.Cd_Ptu_A550_Quest_Proc_Mot_Glo =
                            t.Maior_Cd_Quest_Proc_Mot_Glo Then
                        t.Vl_Total_Reconhecido_Com_Taxa
                     End,
                     
                     t.Tp_Acordo,
                     
                     (Vl_Total_Cobrado_Com_Taxa -
                     t.Vl_Total_Reconhecido_Com_Taxa)
           
           ) x
