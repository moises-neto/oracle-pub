/*
MU2108-007 - Importacao Layout 5767 - 20-08

Favor proceder com as inclus�es dos layouts em anexo,
conforme vig�ncias apontadas em seus nomes (20/08 e 01/09).

*/

/*tab=v_ususario antes total por contrato*/
Select v.Nrcontrato, Count(*) Linha
  From Dbaps.v_Usuario v
 Where v.Cd_Contrato In (1017125,1017708,1017709)
 Group By v.Nrcontrato;

/*tab=v_ususario antes detalhe*/
Select *
  From Dbaps.v_Usuario v
 Where v.Cd_Contrato In (1017125,1017708,1017709);

/*tab= antes Olhando a tabela imp*/
Select Count(*)
  From Dbaps.Imp_Usuario_Leiaute_Proprio Iu
 Where Iu.Sn_Integrado = 'N'
   And Iu.Cd_Contrato In (1017125,1017708,1017709);

/*tab=v_ususario antes Olhando detalhe tabela imp*/
Select u.*
  From Dbaps.Imp_Usuario u
 Where u.Cd_Contrato In (1017125,1017708,1017709);

/*tab=v_ususario Detalhes antes de importar*/
Select u.Dt_Cadastro,
       u.Dt_Recebimento_Documentacao,
       u.Cd_Familia,
       u.Cd_Familia_Contrato,
       u.Dt_Cadastro_Sistema,
       u.Dt_Comissao_Inicial,
       u.*
  From Dbaps.Usuario u, Dbaps.Imp_Usuario_Leiaute_Proprio i
 Where u.Cd_Contrato = i.Cd_Contrato
   And u.Cd_Plano = i.Cd_Plano
   And i.Cd_Contrato In (1017125,1017708,1017709);

/*tab=IMPORTAR*/
Begin
  -- Call the procedure
  For Ix In (Select p.Cd_Contrato, Count(*)
               From Imp_Usuario_Leiaute_Proprio p
              Where p.Cd_Contrato In (1017125,1017708,1017709)
              and p.sn_integrado = 'N'
              Group By p.Cd_Contrato) Loop
    Pr_Imp_Usuario_Leiaute_Proprio(p_Cd_Contrato         => Ix.Cd_Contrato,
                                   p_Dt_Adesao           => '01/11/2021',
                                   p_Dt_Comissao_Inicial => '01/11/2021');
  End Loop;
End;
/

/*tab=usuario depois de importar*/
  Select u.Dt_Cadastro,
         u.Dt_Recebimento_Documentacao,
         u.Cd_Familia,
         u.Cd_Familia_Contrato,
         u.Dt_Cadastro_Sistema,
         u.Dt_Comissao_Inicial,
         u.Ds_Email,
         u.Cd_Agrupamento_Carencia,
         u.*
    From Dbaps.Usuario                     u,
         Dbaps.Imp_Usuario_Leiaute_Proprio i,
         Dbaps.Imp_Usuario                 Iu
   Where u.Cd_Contrato = i.Cd_Contrato
        --And u.Cd_Plano = i.Cd_Plano
     And i.Cd_Contrato In (1017711,1017712,1017713,1017714)
     And i.Nr_Seq_Usuario_Imp = Iu.Cd_Imp_Usuario
     And Iu.Cd_Mat_Alternativa = u.Cd_Mat_Alternativa;

/*tab=imp usuario depois de importar*/
Select u.*, ROWID
  From Dbaps.Imp_Usuario u
 Where u.Cd_Contrato In (1017125,1017708,1017709);

/*tab=contagem usuario depois de importar*/
Select Count(*)
  From Dbaps.Imp_Usuario_Leiaute_Proprio Iu
 Where Iu.Sn_Integrado = 'N'
   And Iu.Cd_Contrato In (1017125,1017708,1017709);

/*tab=v_usuario contagem depois de importar*/
Select v.Nrcontrato, Count(*) Linha
  From Dbaps.v_Usuario v
 Where v.Cd_Contrato In (1017125,1017708,1017709)
 Group By v.Nrcontrato;

/*tab=v_usuario depois de importar detalhes*/
Select *
  From Dbaps.v_Usuario v
 Where v.Cd_Contrato In (1017125,1017708,1017709); 
 
 SELECT COUNT(*) FROM DBAPS.USUARIO U WHERE U.CD_CONTRATO = '1017637'
 
 sELECT * fROM DBAPS.USUARIO U WHERE UPPER(U.NM_SEGURADO) LIKE UPPER('%Ingrid Sayuri Nakazone%')   

DBAPS.PRC_TISS_DEMONSTRATIVOS

select count(*) From usuario u
where u.cd_contrato in (1017125,1017708,1017709)


