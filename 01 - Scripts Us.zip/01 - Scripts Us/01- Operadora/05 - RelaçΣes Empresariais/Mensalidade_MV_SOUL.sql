/*
N�mero do contrato
nome do benefici�rio
per�odo
idade do benef no per�odo
valor de mensalidade faturado
valor pago
*/

Select mc.cd_contrato as Contrato,
       u.nm_segurado as Beneficiario,
       mc.nr_ano ||  mc.nr_mes as Periodo, 
       u.dt_nascimento,
       custom.fn_idade(Pdt_Comparacao => mc.dt_emissao, Pnascimento => mu.dt_nascimento) as Idade_Periodo,
       iu.vl_lancamento as Valor_Faturado,
       Decode(mc.tp_quitacao, 'A', 'Aberto', 'P', 'Parcial', 'Q', 'Quitado') as Situacao
  From Dbaps.Mens_Contrato  mc,
       Dbaps.Mens_Usuario   Mu,
       Dbaps.Itmens_Usuario Iu,
       Dbaps.usuario u
 Where Mc.Cd_Contrato = mu.cd_contrato
   And Iu.Cd_Mens_Usuario = mu.cd_mens_usuario 
   And u.cd_matricula = mu.cd_matricula
   And mc.cd_contrato = 5418;
                
   
   -- A - ABERTO / P  - PARCIAL / Q - QUITADO
   
   Select iu.* fROM  Dbaps.Itmens_Usuario Iu, Dbaps.Mens_Usuario muu 
   wHERE IU.Cd_Mens_Usuario = muu.cd_mens_usuario
   And muu.cd_contrato = 5418
   And muu.cd_matricula = 686280211;
