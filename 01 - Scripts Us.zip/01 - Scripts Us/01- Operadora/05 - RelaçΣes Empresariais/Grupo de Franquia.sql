
select pc.dt_inativacao,
case
  pc.cd_plano

  when 138 then
    35
  end franquia,
 pc.* from dbaps.plano_contrato pc
where pc.cd_contrato = 1020317 
and pc.cd_plano in (267);


select * From plano_contrato c
where c.cd_grupo_franquia = 35



select pc.cd_contrato,
       pc.cd_plano,
       pc.*
      
  from dbaps.plano_contrato pc
 where pc.cd_contrato = 1020317
   and pc.cd_plano in (267);
   
   Select * From dbaps.plano_contrato pc
 where pc.cd_contrato = 1016174 


BEGIN
  DBAMV.PKG_MV2000.ATRIBUI_EMPRESA('1');
END;
/



Declare

v_retorno Number := 0;

Begin

  For Ix In (
select pc.cd_contrato,
       pc.cd_plano,
       case pc.cd_plano
         when 267 then
          24949
       end cd_modelo_copar
  from dbaps.plano_contrato pc
 where pc.cd_contrato = 1020317
   and pc.cd_plano in (267))
  
   Loop
  
    Begin
    
      v_retorno := dbaps.fnc_duplica_franquia(ix.cd_contrato,
                                              ix.cd_plano,
                                              ix.cd_modelo_copar);
    
      UPDATE DBAPS.Plano_Contrato p
         SET p.cd_grupo_franquia = v_retorno
       WHERE P.CD_CONTRATO = IX.CD_CONTRATO
         and p.cd_plano = Ix.Cd_Plano
         and p.dt_inativacao is null;
    
    Exception
      When Others Then
        Rollback;
        Raise_Application_Error(-20002,
                                'Falha: ' || Sqlerrm || ' Contrato: ' ||
                                Ix.Cd_Contrato || ' Plano:  ' ||
                                Ix.Cd_Plano);
    End;
  End Loop;

Exception
  When Others Then
    Rollback;
    Raise_Application_Error(-20001, 'Falha: ' || Sqlerrm);
End;

/

select pc.dt_inativacao,
case
  pc.cd_plano
  when 138 then
    35
  end franquia,
 pc.* from dbaps.plano_contrato pc
where pc.cd_contrato = 1016174
and pc.cd_plano in (138);
