select  
       co.cd_contrato,
       pc.cd_plano,
       pc.cd_grupo_faixa_etaria_aposenta,
       vt.cd_faixa_etaria,
       vt.tp_usuario,
       vt.dt_vigencia,
       vt.nr_meses,
       vt.vl_mensalidade,
       vt.vl_inclusao,
       vt.vl_exclusao,
       vt.vl_mensalidade vl_mensalidade_original,
       vt.vl_inclusao vl_inclusao_original,
       vt.vl_exclusao vl_exclusao_original,
       vt.cd_faixa_vidas,
       user cd_usuario_cadastro,
       sysdate dh_cadastro,
       vt.cd_tabela_preco,
       'N' sn_forca_alter_dt_rejuste,
       vt.tp_sexo
  from dbaps.contrato co, dbaps.plano_contrato pc, dbaps.valores_tabela vt
 where co.cd_contrato in (1013785, 1012448, 1012449, 1012450, 1012451)
   and pc.cd_contrato = co.cd_contrato
   and vt.cd_tabela_preco = pc.cd_tabela_preco_aposentado
   and vt.cd_plano = pc.cd_plano;


select co.cd_contrato_tem,
       co.cd_contrato,
       pc.cd_plano,
       pc.cd_tabela_preco_aposentado,
       vtc.*
  from dbaps.contrato co, dbaps.plano_contrato pc, dbaps.valores_tabela_contrato vtc
 where co.cd_contrato in (1013785, 1012448, 1012449, 1012450, 1012451)
   and pc.cd_contrato = co.cd_contrato
   and vtc.cd_contrato = pc.cd_contrato
   and vtc.cd_plano = pc.cd_plano
   and vtc.cd_tabela_preco = pc.cd_tabela_preco_aposentado
  ;


 
 
BEGIN
  DBAMV.PKG_MV2000.ATRIBUI_EMPRESA('1');
END;
/

Declare

Begin

  For Ix In (
    
 select  
       co.cd_contrato,
       pc.cd_plano,
       pc.cd_grupo_faixa_etaria_aposenta cd_grupo_faixa_etaria,
       vt.cd_faixa_etaria,
       vt.tp_usuario,
       vt.dt_vigencia,
       vt.nr_meses,
       vt.vl_mensalidade,
       vt.vl_inclusao,
       vt.vl_exclusao,
       vt.vl_mensalidade vl_mensalidade_original,
       vt.vl_inclusao vl_inclusao_original,
       vt.vl_exclusao vl_exclusao_original,
       vt.cd_faixa_vidas,
       user cd_usuario_cadastro,
       sysdate dh_cadastro,
       vt.cd_tabela_preco,
       'N' sn_forca_alter_dt_rejuste,
       vt.tp_sexo
  from dbaps.contrato co, dbaps.plano_contrato pc, dbaps.valores_tabela vt
 where co.cd_contrato in (1013785, 1012448, 1012449, 1012450, 1012451)
   and pc.cd_contrato = co.cd_contrato
   and vt.cd_tabela_preco = pc.cd_tabela_preco_aposentado
   and vt.cd_plano = pc.cd_plano


   ) Loop
  
    Begin
    
     INSERT INTO DBAPS.valores_tabela_contrato vtc
     (
     cd_contrato,
       cd_plano,
       cd_grupo_faixa_etaria,
       cd_faixa_etaria,
       tp_usuario,
       dt_vigencia,
       nr_meses,
       vl_mensalidade,
       vl_inclusao,
       vl_exclusao,
       vl_mensalidade_original,
       vl_inclusao_original,
       vl_exclusao_original,
       cd_faixa_vidas,
       cd_usuario_cadastro,
       dh_cadastro,
       cd_tabela_preco,
       sn_forca_alter_dt_rejuste,
       tp_sexo
     )
     values
     (
     
       Ix.cd_contrato,
       Ix.cd_plano,
       Ix.cd_grupo_faixa_etaria,
       Ix.cd_faixa_etaria,
       Ix.tp_usuario,
       Ix.dt_vigencia,
       Ix.nr_meses,
       Ix.vl_mensalidade,
       Ix.vl_inclusao,
       Ix.vl_exclusao,
       Ix.vl_mensalidade_original,
       Ix.vl_inclusao_original,
       Ix.vl_exclusao_original,
       Ix.cd_faixa_vidas,
       Ix.cd_usuario_cadastro,
       Ix.dh_cadastro,
       Ix.cd_tabela_preco,
       Ix.sn_forca_alter_dt_rejuste,
       Ix.tp_sexo
     );
     
         
    Exception
      When Others Then
        Rollback;
        Raise_Application_Error(-20002,
                                'Falha: ' || Sqlerrm || ' Contrato: ' ||
                                Ix.Cd_Contrato);
    End;
  End Loop;

Exception
  When Others Then
    Rollback;
    Raise_Application_Error(-20001, 'Falha: ' || Sqlerrm);
End;
/


select co.cd_contrato_tem,
       co.cd_contrato,
       pc.cd_plano,
       pc.cd_tabela_preco_aposentado
  from dbaps.contrato co, dbaps.plano_contrato pc
 where co.cd_contrato in (1013785, 1012448, 1012449, 1012450, 1012451)
   and pc.cd_contrato = co.cd_contrato;



select  
       co.cd_contrato,
       pc.cd_plano,
       pc.cd_grupo_faixa_etaria_aposenta,
       vt.cd_faixa_etaria,
       vt.tp_usuario,
       vt.dt_vigencia,
       vt.nr_meses,
       vt.vl_mensalidade,
       vt.vl_inclusao,
       vt.vl_exclusao,
       vt.vl_mensalidade vl_mensalidade_original,
       vt.vl_inclusao vl_inclusao_original,
       vt.vl_exclusao vl_exclusao_original,
       vt.cd_faixa_vidas,
       user cd_usuario_cadastro,
       sysdate dh_cadastro,
       vt.cd_tabela_preco,
       'N' sn_forca_alter_dt_rejuste,
       vt.tp_sexo
  from dbaps.contrato co, dbaps.plano_contrato pc, dbaps.valores_tabela vt
 where co.cd_contrato in (1013785, 1012448, 1012449, 1012450, 1012451)
   and pc.cd_contrato = co.cd_contrato
   and vt.cd_tabela_preco = pc.cd_tabela_preco
   and vt.cd_plano = pc.cd_plano;


select co.cd_contrato_tem,
       co.cd_contrato,
       pc.cd_plano,
       pc.cd_tabela_preco_aposentado,
       vtc.*
  from dbaps.contrato co, dbaps.plano_contrato pc, dbaps.valores_tabela_contrato vtc
 where co.cd_contrato in (1013785, 1012448, 1012449, 1012450, 1012451)
   and pc.cd_contrato = co.cd_contrato
   and vtc.cd_contrato = pc.cd_contrato
   and vtc.cd_plano = pc.cd_plano
   and vtc.cd_tabela_preco = pc.cd_tabela_preco_aposentado
  ;
