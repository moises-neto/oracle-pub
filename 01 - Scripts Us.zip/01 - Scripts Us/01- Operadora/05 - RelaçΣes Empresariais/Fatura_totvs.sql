Select Distinct Us.Cdareaacao || Us.Nrcontrato ||
                Lpad(Us.Nrfamilia, 6, '0') || Us.Tpusuario || Us.Nrdigitoct Carteira,
                p.Nopessoa Nome,
                To_Char(Dfp.Nrperiodo) Periodo,
                Dfp.Nrfatura Fatura,
                Dfp.Vlfaturado--,
              --custom.fn_idade(Pdt_Comparacao => Dfp.Nrperiodo, Pnascimento => p.dtnascimento) as Idade_Periodo
                
  From Detalhe_Faturamento_Premio@Orcoop Dfp
 Inner Join Usuario@Orcoop Us
    On (Us.Nrregistro_Usuario = Dfp.Nrregistro)
 Inner Join Pessoa@Orcoop p
    On (p.Nrregistro = Us.Nrregistro_Usuario)
 Where /*Dfp.Nrregistro = 1198281
   And Dfp.Tpusuario = '00'
   And*/
 Dfp.Cdcategserv = ' '
 And Us.Nrcontrato = '5012'
 And Us.Nrfamilia = '2151'
 And Dfp.Nrperiodo Between '201201' And '201812';
