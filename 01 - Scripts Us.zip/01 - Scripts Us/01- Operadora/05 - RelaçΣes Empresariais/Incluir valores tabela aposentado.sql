/*
Exemplo:
MU2108-016 - Altera��o de Dados do Contrato
Por gentileza verificar a tabela de aposentados 1277
da empresa 1016746,
pois os valores n�o est�o constando.
*/

-- Cursor
Select Pc.Cd_Contrato,
       Pc.Cd_Plano,
       Pc.Cd_Grupo_Faixa_Etaria,
       Vt.Cd_Faixa_Etaria,
       Vt.Tp_Usuario,
       Vt.Dt_Vigencia,
       Vt.Cd_Grupo_Direito,
       Vt.Nr_Meses,
       Vt.Vl_Mensalidade,
       Vt.Vl_Inclusao,
       Vt.Vl_Exclusao,
       Null Perc_Aumento_Ano,
       Null Cd_Log_Reajuste,
       '0,00' Vl_Mensalidade_Original,
       '0,00' Vl_Inclusao_Original,
       '0,00' Vl_Exclusao_Original,
       Vt.Cd_Faixa_Vidas,
       User Cd_Usuario_Cadastro,
       Trunc(Sysdate) Dh_Cadastro,
       Null Cd_Usuario_Ultima_Alteracao,
       Null Dh_Ultima_Alteracao,
       Vt.Cd_Tabela_Preco,
       Null Vl_Mensalidade_Intercambio,
       'S' Sn_Forca_Alter_Dt_Rejuste,
       Vt.Tp_Sexo,
       Null Tp_Origem
  From Dbaps.Valores_Tabela Vt, Dbaps.Plano_Contrato Pc
 Where Vt.Cd_Tabela_Preco = Pc.Cd_Tabela_Preco_Aposentado
   And Pc.Cd_Contrato = 1016746 -- Substituir pelo n� do Contrato MV
   And Pc.Cd_Tabela_Preco_Aposentado = 1277 -- Substituir pelo n� da Tabela de Pre�o
   And Not Exists
 (Select 1
          From Dbaps.Valores_Tabela_Contrato Vtc
         Where Vtc.Cd_Contrato = Pc.Cd_Contrato
           And Vtc.Cd_Plano = Pc.Cd_Plano
           And Vtc.Cd_Tabela_Preco = Pc.Cd_Tabela_Preco_Aposentado)
 Order By Pc.Cd_Contrato,
          Pc.Cd_Plano,
          Pc.Cd_Tabela_Preco,
          Vt.Cd_Faixa_Etaria,
          Vt.Tp_Usuario Desc;

-- Tabela de Pre�o
Select * From Dbaps.Valores_Tabela Vt Where Vt.Cd_Tabela_Preco = 1277;

-- Tabelas j� adicionadas no contrato
Select *
  From Dbaps.Valores_Tabela_Contrato Vtc
 Where Vtc.Cd_Contrato = 1016746
 Order By Vtc.Cd_Contrato,
          Vtc.Cd_Plano,
          Vtc.Cd_Tabela_Preco,
          Vtc.Cd_Faixa_Etaria,
          Vtc.Tp_Usuario Desc;

-- Verifica se a tabela j� foi adicionada ao contrato
Select Vtc.*
  From Dbaps.Valores_Tabela_Contrato Vtc
 Where Vtc.Cd_Contrato = 1016746
   And Vtc.Cd_Tabela_Preco = 1277
 Order By Vtc.Cd_Contrato,
          Vtc.Cd_Plano,
          Vtc.Cd_Tabela_Preco,
          Vtc.Cd_Faixa_Etaria,
          Vtc.Tp_Usuario Desc;

Declare
Begin

  For Ix In (Select Pc.Cd_Contrato,
                    Pc.Cd_Plano,
                    Pc.Cd_Grupo_Faixa_Etaria,
                    Vt.Cd_Faixa_Etaria,
                    Vt.Tp_Usuario,
                    Vt.Dt_Vigencia,
                    Vt.Cd_Grupo_Direito,
                    Vt.Nr_Meses,
                    Vt.Vl_Mensalidade,
                    Vt.Vl_Inclusao,
                    Vt.Vl_Exclusao,
                    Null Perc_Aumento_Ano,
                    Null Cd_Log_Reajuste,
                    '0,00' Vl_Mensalidade_Original,
                    '0,00' Vl_Inclusao_Original,
                    '0,00' Vl_Exclusao_Original,
                    Vt.Cd_Faixa_Vidas,
                    User Cd_Usuario_Cadastro,
                    Trunc(Sysdate) Dh_Cadastro,
                    Null Cd_Usuario_Ultima_Alteracao,
                    Null Dh_Ultima_Alteracao,
                    Vt.Cd_Tabela_Preco,
                    Null Vl_Mensalidade_Intercambio,
                    'S' Sn_Forca_Alter_Dt_Rejuste,
                    Vt.Tp_Sexo,
                    Null Tp_Origem
               From Dbaps.Valores_Tabela Vt, Dbaps.Plano_Contrato Pc
              Where Vt.Cd_Tabela_Preco = Pc.Cd_Tabela_Preco_Aposentado
                And Pc.Cd_Contrato = 1016746
                And Pc.Cd_Tabela_Preco_Aposentado = 1277
                And Not Exists
              (Select 1
                       From Dbaps.Valores_Tabela_Contrato Vtc
                      Where Vtc.Cd_Contrato = Pc.Cd_Contrato
                        And Vtc.Cd_Plano = Pc.Cd_Plano
                        And Vtc.Cd_Tabela_Preco =
                            Pc.Cd_Tabela_Preco_Aposentado)
              Order By Pc.Cd_Contrato,
                       Pc.Cd_Plano,
                       Pc.Cd_Tabela_Preco,
                       Vt.Cd_Faixa_Etaria,
                       Vt.Tp_Usuario Desc) Loop
  
    Begin
    
      Insert Into Dbaps.Valores_Tabela_Contrato
        (Cd_Contrato,
         Cd_Plano,
         Cd_Grupo_Faixa_Etaria,
         Cd_Faixa_Etaria,
         Tp_Usuario,
         Dt_Vigencia,
         Cd_Grupo_Direito,
         Nr_Meses,
         Vl_Mensalidade,
         Vl_Inclusao,
         Vl_Exclusao,
         Perc_Aumento_Ano,
         Cd_Log_Reajuste,
         Vl_Mensalidade_Original,
         Vl_Inclusao_Original,
         Vl_Exclusao_Original,
         Cd_Faixa_Vidas,
         Cd_Usuario_Cadastro,
         Dh_Cadastro,
         Cd_Usuario_Ultima_Alteracao,
         Dh_Ultima_Alteracao,
         Cd_Tabela_Preco,
         Vl_Mensalidade_Intercambio,
         Sn_Forca_Alter_Dt_Rejuste,
         Tp_Sexo,
         Tp_Origem)
      Values
        (Ix.Cd_Contrato,
         Ix.Cd_Plano,
         Ix.Cd_Grupo_Faixa_Etaria,
         Ix.Cd_Faixa_Etaria,
         Ix.Tp_Usuario,
         Ix.Dt_Vigencia,
         Ix.Cd_Grupo_Direito,
         Ix.Nr_Meses,
         Ix.Vl_Mensalidade,
         Ix.Vl_Inclusao,
         Ix.Vl_Exclusao,
         Ix.Perc_Aumento_Ano,
         Ix.Cd_Log_Reajuste,
         Ix.Vl_Mensalidade_Original,
         Ix.Vl_Inclusao_Original,
         Ix.Vl_Exclusao_Original,
         Ix.Cd_Faixa_Vidas,
         Ix.Cd_Usuario_Cadastro,
         Ix.Dh_Cadastro,
         Ix.Cd_Usuario_Ultima_Alteracao,
         Ix.Dh_Ultima_Alteracao,
         Ix.Cd_Tabela_Preco,
         Ix.Vl_Mensalidade_Intercambio,
         Ix.Sn_Forca_Alter_Dt_Rejuste,
         Ix.Tp_Sexo,
         Ix.Tp_Origem);
    
    Exception
      When Others Then
        Rollback;
        Raise_Application_Error(-20002,
                                'Falha: ' || Sqlerrm || ' Contrato: ' ||
                                Ix.Cd_Contrato);
    End;
  End Loop;

Exception
  When Others Then
    Rollback;
    Raise_Application_Error(-20001, 'Falha: ' || Sqlerrm);
End;
/

-- Valida se a tabela j� foi adicionada ao contrato
  Select *
    From Dbaps.Valores_Tabela_Contrato Vtc
   Where Vtc.Cd_Contrato = 1016746
     And Vtc.Cd_Tabela_Preco = 1277
   Order By Vtc.Cd_Contrato,
            Vtc.Cd_Plano,
            Vtc.Cd_Tabela_Preco,
            Vtc.Cd_Faixa_Etaria,
            Vtc.Tp_Usuario Desc;

-- Tabelas j� adicionadas no contrato
Select *
  From Dbaps.Valores_Tabela_Contrato Vtc
 Where Vtc.Cd_Contrato = 1016746
 Order By Vtc.Cd_Contrato,
          Vtc.Cd_Plano,
          Vtc.Cd_Tabela_Preco,
          Vtc.Cd_Faixa_Etaria,
          Vtc.Tp_Usuario Desc;
