-- Coloquei a planilha
Select Iu.*, Rowid
  From Dbaps.Imp_Usuario_Leiaute_Proprio Iu
 Where Iu.Cd_Contrato In (1017125,1017708,1017709)
 And iu.sn_integrado = 'N'
 and iu.nr_familia  in(810,811);    
 
  /**********************VERIFICAR ANTES DE IMPORTAR************************************/
  
---Verificar CD_DEPENDENTE n�o pode ter quantidade 2

Select Iu.Nr_Familia, iu.cd_dependente, count(*) as qtde
  From Dbaps.Imp_Usuario_Leiaute_Proprio Iu
 Where Iu.Cd_Contrato In (1017125, 1017708, 1017709)
   and iu.sn_integrado = 'N'
 Group by Iu.Nr_Familia, iu.cd_dependente
Having count(*) > 1
   
-- Qtd Total
Select count(*)
  From Dbaps.Imp_Usuario_Leiaute_Proprio Iu
 Where Iu.Sn_Integrado = 'N'
  And Iu.Cd_Contrato In (1017125,1017708,1017709)
  

-- Qtd Titular
Select  count(*)
  From Dbaps.Imp_Usuario_Leiaute_Proprio Iu
 Where Iu.Sn_Integrado = 'N'
 and iu.tp_usuario = 'T'
   And Iu.Cd_Contrato In (1017125,1017708,1017709);

-- Qtd Dependentes
Select  count(*)
  From Dbaps.Imp_Usuario_Leiaute_Proprio Iu
 Where Iu.Sn_Integrado = 'N'
 and iu.tp_usuario = 'D'
   And Iu.Cd_Contrato In (1017125,1017708,1017709);
   
-- Qtd Agregados
Select  count(*)
  From Dbaps.Imp_Usuario_Leiaute_Proprio Iu
 Where Iu.Sn_Integrado = 'N'
 and iu.tp_usuario = 'A'
   And Iu.Cd_Contrato In (1017125,1017708,1017709);
                          
                          
--prc_mvs_ptu_efetiva_a550_xml
