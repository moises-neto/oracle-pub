Declare
  Cursor cDados is
    Select y.contrato_mv,
           y.cd_responsavel_carteira as nm_usuario_old,
           y.nm_usuario_novo         as nm_usuario_new
      From (Select x.*,
                   Case x.cd_carteira_contrato
                     When 1 Then
                      'SIBRITO'
                     WHEN 2 Then
                      'MUANTONIO'
                     ELSE
                      '1'
                   End nm_usuario_novo
              From (SELECT CD_CONTRATO_INTERNO,
                           CD_CONTRATO contrato_mv,
                           NM_RESPONSAVEL_FINANCEIRO RESPONSAVEL_FINANCEIRO,
                           (select count(u.cd_matricula)
                              from dbaps.usuario u
                             where u.cd_contrato = c.cd_contrato
                               and u.sn_ativo = 'S'
                               and u.cd_familia > 0) qtd_vidas_ativas,
                           c.cd_carteira_contrato,
                           (Select ca.ds_carteira_contrato
                              From dbaps.carteira_contrato ca
                             Where ca.cd_carteira_contrato =
                                   c.cd_carteira_contrato) carteira_contrato,
                           cd_usuario cd_responsavel_carteira,
                           (select us.nm_usuario
                              from dbasgu.usuarios us
                             where us.cd_usuario = c.cd_usuario) nm_responsavel_carteira
                      FROM DBAPS.CONTRATO c
                     WHERE c.TP_CONTRATO in ('E', 'A')
                       and c.sn_demitido_aposentado_obito = 'N'
                       and c.sn_ativo = 'S'
                       And c.cd_carteira_contrato Is Not Null
                     ORDER BY 3) x
            
             Where x.cd_carteira_contrato in (1, 2)) y
     Where y.cd_responsavel_carteira <> y.nm_usuario_novo;
  --and y.contrato_mv in (1055, 1707, 2217);

Begin
  For i in cDados Loop
    Begin
      Update dbaps.contrato con
         set con.cd_usuario = i.nm_usuario_new
       Where con.cd_contrato = i.contrato_mv;
      Dbms_Output.put_line('Contrato Alterado: ' || i.contrato_mv ||
                           ' Responsavel antigo: ' || i.nm_usuario_old ||
                           ' Responsável novo: ' || i.nm_usuario_new);
    End;
  End Loop;

End;
