ROTINAS DE REAJUSTE DE MENSALIDADE

 1 - prc_mvs_reajuste_mensalidade
 
 2 - dbaps.fnc_mvs_Retorna_Perc_Reaj
 
 3 - dbaps.prc_mvs_reajusta_valores