Select c.dt_prox_reajuste, c.dt_vencimento_contrato, c.nr_dia_vencimento, c.dt_ultimo_reajuste, rowid From contrato c
where c.cd_contrato = 13655


