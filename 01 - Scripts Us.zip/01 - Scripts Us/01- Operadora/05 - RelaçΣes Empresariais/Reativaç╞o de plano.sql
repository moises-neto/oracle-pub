
/*
MU2105-018 - Reativa��o de plano

estou tentando reativar os planos 126 e 127 
do contrato mv 7573
mas n�o estou conseguindo.
Pe�o efetuarem a reativa��o por banco.
*/


-- inclui a data de reativa��o
select dpc.dt_reativacao, dpc.*, rowid from dbaps.desliga_plano_contrato dpc
where dpc.cd_contrato = 7573
and dpc.cd_plano in (126, 127);

-- remove a data de inativa��o
select pc.dt_inativacao, pc.*, rowid from dbaps.plano_contrato pc
where pc.cd_contrato = 7573
and pc.cd_plano in (126, 127);
