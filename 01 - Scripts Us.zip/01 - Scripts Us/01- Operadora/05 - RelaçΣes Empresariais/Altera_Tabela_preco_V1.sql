Select pc.*, rowid From dbaps.plano_contrato pc
where pc.cd_contrato = 8388  
