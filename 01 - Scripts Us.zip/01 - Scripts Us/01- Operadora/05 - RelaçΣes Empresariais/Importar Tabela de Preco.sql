/*
MU2107-028 - Importa��o de Tabela de Pre�os

Contrato:
- 1011109

Favor importar as tabelas dos contratos "filhos para o contrato pai conforme abaixo:


IMPORTAR A TABELA DOS PLANOS 471 E 472 DO CONTRATO FILHO 1011109 PARA O CONTRATO PAI 1011108 PLANOS 471 E 472. (ROSE PLASTIC BRASIL EMBALAGENS PLASTICAS LTDA)


IMPORTAR A TABELA DOS PLANOS 471 E 472 DO CONTRATO FILHO 1011146 PARA O CONTRATO PAI 1011145 PLANOS 471 E 472.(QUALITY CENTRAL DE ESTERILIZA��O LTDA)


IMPORTAR A TABELA DOS PLANOS 471 E 472 DO CONTRATO FILHO 1011150 PARA O CONTRATO PAI 1011149 PLANOS 471 E 472.
(DFC TRANSPORTES EIRELI)


IMPORTAR A TABELA DOS PLANOS 471 E 472 DO CONTRATO FILHO 1011148 PARA O CONTRATO PAI 1011147 PLANOS 471 E 472.
(ALVES LIMA COMERCIO E ESTERILIZA��O DE MATERIAIS MEDICOS EIRELI)


IMPORTAR A TABELA DOS PLANOS 471 E 472 DO CONTRATO FILHO 1011043 PARA O CONTRATO PAI 1011041 PLANOS 471 E 472.
(PROAUTO ELECTRIC LTDA)

LARISSA, CONFORME FALAMOS ATIVAR OS PLANOS 471 E 471 DO CONTRATO 1011041 PROAUTO ELECTRIC LTDA)

Assim que finalizado favor nos avisar pois precisamos liberar ao setor de cadastro.
*/

--  IMPORTAR A TABELA DOS PLANOS 471 E 472 DO CONTRATO FILHO 1011109 PARA O CONTRATO PAI 1011108 PLANOS 471 E 472. (ROSE PLASTIC BRASIL EMBALAGENS PLASTICAS LTDA)

Select *  From plano_contrato pcc
where pcc.cd_contrato = 1011041


select *
  from dbaps.valores_tabela_contrato vtc
 where vtc.cd_contrato = 1011109
   and vtc.dt_vigencia =
       (select max(vt.dt_vigencia)
          from dbaps.valores_tabela_contrato vt
         where vt.cd_contrato = 1011109)
 order by vtc.cd_contrato,
          vtc.cd_plano,
          vtc.cd_faixa_etaria,
          vtc.tp_usuario desc;

select *
  from dbaps.valores_tabela_contrato vtc
 where vtc.cd_contrato = 1011108
   and vtc.dt_vigencia =
       (select max(vt.dt_vigencia)
          from dbaps.valores_tabela_contrato vt
         where vt.cd_contrato = 1011108)
 order by vtc.cd_contrato,
          vtc.cd_plano,
          vtc.cd_faixa_etaria,
          vtc.tp_usuario desc;

Declare
Begin

  For Ix In (select vtc.*--, c.cd_contrato_tem
               from dbaps.valores_tabela_contrato vtc, contrato c
              where c.cd_contrato = vtc.cd_contrato 
              and vtc.cd_plano in(472,471)
              and vtc.cd_contrato in(1011146, 1011150, 1011148, 1011043)
                and vtc.dt_vigencia =
                    (select max(vt.dt_vigencia)
                       from dbaps.valores_tabela_contrato vt
                      where vt.cd_contrato = c.cd_contrato)) Loop
  
    Begin
    
      INSERT INTO dbaps.valores_tabela_contrato vtc
        (cd_contrato,
         cd_plano,
         cd_grupo_faixa_etaria,
         cd_faixa_etaria,
         tp_usuario,
         dt_vigencia,
         nr_meses,
         vl_mensalidade,
         vl_inclusao,
         vl_exclusao,
         vl_mensalidade_original,
         vl_inclusao_original,
         vl_exclusao_original,
         cd_faixa_vidas,
         cd_usuario_cadastro,
         dh_cadastro,
         cd_tabela_preco,
         vl_mensalidade_intercambio,
         sn_forca_alter_dt_rejuste,
         tp_sexo)
      values
        (ix.cd_contrato_tem,
         Ix.cd_plano,
         Ix.cd_grupo_faixa_etaria,
         Ix.cd_faixa_etaria,
         Ix.tp_usuario,
         trunc(sysdate),
         Ix.nr_meses,
         Ix.vl_mensalidade,
         Ix.vl_inclusao,
         Ix.vl_exclusao,
         Ix.vl_mensalidade_original,
         Ix.vl_inclusao_original,
         Ix.vl_exclusao_original,
         Ix.cd_faixa_vidas,
         Ix.cd_usuario_cadastro,
         Ix.dh_cadastro,
         Ix.cd_tabela_preco,
         Ix.vl_mensalidade_intercambio,
         Ix.sn_forca_alter_dt_rejuste,
         Ix.tp_sexo);
    
    Exception
      When Others Then
        Rollback;
        Raise_Application_Error(-20002,
                                'Falha: ' || Sqlerrm || 'cid: ' ||
                                Ix.Cd_Contrato);
    End;
  End Loop;

Exception
  When Others Then
    Rollback;
    Raise_Application_Error(-20001, 'Falha: ' || Sqlerrm);
End;
/

  select *
    from dbaps.valores_tabela_contrato vtc
   where vtc.cd_contrato = 1011109
     and vtc.dt_vigencia =
         (select max(vt.dt_vigencia)
            from dbaps.valores_tabela_contrato vt
           where vt.cd_contrato = 1011109)
   order by vtc.cd_contrato,
            vtc.cd_plano,
            vtc.cd_faixa_etaria,
            vtc.tp_usuario desc;

select *
  from dbaps.valores_tabela_contrato vtc
 where vtc.cd_contrato in(1011146, 1011150, 1011148, 1011043)
   and vtc.dt_vigencia =
       (select max(vt.dt_vigencia)
          from dbaps.valores_tabela_contrato vt
         where vt.cd_contrato in(1011146, 1011150, 1011148, 1011043))
 order by vtc.cd_contrato,
          vtc.cd_plano,
          vtc.cd_faixa_etaria,
          vtc.tp_usuario desc;
