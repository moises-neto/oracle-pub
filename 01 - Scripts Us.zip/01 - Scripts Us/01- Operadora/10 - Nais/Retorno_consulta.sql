select count(g.nr_guia) Quantidade,
       nvl(nvl(bt.nm_segurado, u.nm_segurado), g.ds_destino_cortesia) as Beneficiario,
       g.nr_carteira_utilizada
  from dbaps.guia                  g,
       dbaps.itguia                i,
       dbaps.itguia_erros          e,
       dbaps.beneficiario_transito bt,
       dbaps.usuario               u
 where g.nr_guia = i.nr_guia
   and e.nr_guia = g.nr_guia
   and u.cd_matricula(+) = g.cd_matricula
   And bt.cd_beneficiario_transito(+) = g.cd_beneficiario_transito
   and i.cd_procedimento = '10101047'
   and g.cd_prestador = '1001553'
   and g.cd_mot_cancelamento_guia is null
   and e.cd_motivo = '9687' -- glosa de retorno
   and g.dt_emissao between '01/12/2020' and '28/02/2021'
 group by nvl(nvl(bt.nm_segurado, u.nm_segurado), g.ds_destino_cortesia),
          g.nr_carteira_utilizada,
          g.nr_carteira_utilizada
          
           Select *
             from beneficiario_transito b
            where b.cd_matricula = '9941408268433005'
