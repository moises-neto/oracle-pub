 --Empresas que tem plano APS
/*TAB=Contratos APS*/
select distinct substr(co.cd_contrato_interno, 1, 4) contratos
  from dbaps.contrato co, dbaps.plano_contrato pc
 where pc.cd_contrato = co.cd_contrato
   and pc.cd_plano in (471, 472, 473, 474)
   and pc.dt_inativacao is null
   and co.sn_ativo = 'S';

/*TAB=Carteiras APS*/
select co.cd_contrato_interno,
       us.cd_mat_alternativa        carteira,
       co.nm_responsavel_financeiro empresa
  from dbaps.usuario us, dbaps.contrato co
 where co.cd_contrato = us.cd_contrato
   and us.cd_plano in (471, 472, 473, 474)
   and us.sn_ativo = 'S'
 order by 1;

/*TAB=Beneficiarios Centro Medico*/
select us.cd_mat_alternativa carteira, us.nm_segurado nome
  from dbaps.usuario us, dbaps.contrato co, dbaps.plano_contrato pc
 where pc.cd_contrato = co.cd_contrato
   and us.cd_contrato = co.cd_contrato
   and us.cd_plano = pc.cd_plano
   and substr(co.cd_contrato_interno, 1, 4) = '5743'
   and pc.cd_plano in (471, 472, 473, 474)
   and pc.dt_inativacao is null
   and co.sn_ativo = 'S'
   and us.sn_ativo = 'S'
 order by 2;
