Select * from guia_anexo g
where g.nr_guia = '65623129'

Select G.TP_ORIGEM, GA.* from dbaps.guia_anexo ga INNER JOIN DBAPS.GUIA G
ON (G.NR_GUIA = GA.NR_GUIA)
where trunc(ga.dt_cadastro) = '16/02/2021'
and g.nr_transacao = 2102000092030
AND G.TP_ORIGEM = 'INT'
--Where g.nr_transacao = 2102000086961 
ORDER BY GA.DT_CADASTRO DESC

SELECT * FROM GUIA         

