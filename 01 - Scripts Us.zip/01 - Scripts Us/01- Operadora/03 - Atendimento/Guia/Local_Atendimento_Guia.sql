Select g.ds_endereco, g.cd_prestador_endereco from guia g
where g.nr_guia in ('65044849') for update

--JOSE SCOMPARIM NUM. 230 - JARDIM HERMINIA - BOITUVA - SP
--CLAUDIO MANOEL DA COSTA NUM. 212 - JARDIM VERGUEIRO - SOROCABA - SP

Select g.cd_prestador_endereco, g.ds_endereco from guia g
where g.cd_prestador = '1002005'
and g.dt_emissao between '01/01/2021' and sysdate

SELECT * FROM GUIA G
WHERE G.NR_GUIA = 65044849 FOR UPDATE

--GONCALVES MAGALHAES NUM. 1092 - VILA TRUJILLO - SOROCABA - SP
--MONTE ALEGRE NUM. 470 - CENTRO - VOTORANTIM - SP
--GONCALVES MAGALHAES NUM. 1092 - VILA TRUJILLO - SOROCABA - SP


--2102000079022


     CUSTOM.PRC_ATUALIZA_LOCAL_ATEN_GUIA
