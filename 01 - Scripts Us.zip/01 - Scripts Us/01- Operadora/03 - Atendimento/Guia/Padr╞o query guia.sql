/*Pe�o a gentileza de gerar um levantamento com todas as transa��es registradas na tela de guias cadastradas para 
os Contratados Executantes 800056 � IDS INSTITUTO DE DIAGNOSTICO SOROCABA LTDA  MEDICINA  NUCLEAR e 800016 � CENTRO MEDICO IMAGEM SA, 
referente aos meses de Abril, Maio e Junho 2022.

Favor retornar as seguintes informa��es no relat�rio:

* Contratado Executante - GUIA.CD_PRESTADOR_EXECUTOR
* Tipo de guia - GUIA.CD_TIPO_ATENDIMENTO
* Descri��o do tipo de guia
* N�mero da Transa��o - GUIA.NR_TRANSACAO
* N�mero da Guia - GUIA.NR_GUIA
* Nome do usu�rio - GUIA.DSP_NM_SEGURADO / GUIA.DS_DESTINO_CORTESIA
* Contratado Solicitante - GUIA.CD_PRESTADOR
* Emiss�o (data de abertura da transa��o) - GUIA.DT_EMISSAO
* C�digo do procedimento - ITGUIA.CD_PROCEDIMENTO
* Descri��o do procedimento - ITGUIA.DSP_DS_PROCEDIMENTO
* Quantidade Solicitada - ITGUIA.QT_SOLIC_PREST
* Quantidade Autorizada - ITGUIA.QT_SOLICITADO
* Status do procedimento
* Status da guia - GUIA.DSP_TP_SITUACAO_ATUAL
* Descri��o Unimed Origem
*/

Select g.Dt_Emissao,
       g.Cd_Prestador_Executor As Cod_Prestador_Exec,
       --p.Nm_Prestador As Nome_Prestador_Exec,
       Ta.Cd_Tipo_Atendimento As Tipo_Guia,
       Ta.Ds_Tipo_Atendimento As Ds_Tipo_Guia,
       g.Nr_Transacao As Transacao,
       g.Nr_Guia As Guia,
       Nvl(g.Ds_Destino_Cortesia,
           (Select u.Nm_Segurado
              From Dbaps.Usuario u
             Where u.Cd_Matricula = g.Cd_Matricula)) As Nm_Beneficiario,
       (Select p.Nm_Prestador
          From Dbaps.Prestador p
         Where p.Cd_Prestador = g.Cd_Prestador) As Contratado_Solicitado,
       It.Cd_Procedimento,
       (Select p.Ds_Procedimento p
          From Dbaps.Procedimento p
         Where p.Cd_Procedimento = It.Cd_Procedimento) As Ds_Procedimento,
       To_char(it.Qt_Solic_Prest) As Qtd_Solicitada,
       It.Qt_Solicitado As Qtd_Autorizada,
       Decode(It.Tp_Status,
              0,
              'Nenhum',
              1,
              'Em an�lise (Administrativa)',
              2,
              'Em an�lise (Auditoria m�dica)',
              3,
              'Negado',
              4,
              'Liberado',
              5,
              'Cancelado',
              6,
              'Faturamento',
              Null) As Status_Procedimento,
       Dbaps.Fnc_Status_Guia(Pnr_Guia => g.Nr_Guia) As Status_Guia,
       (Select u.Cd_Unimed || ' - ' || u.Ds_Unimed
          From Dbaps.Unimed u
         Where u.Cd_Unimed = g.Cd_Unimed_Origem) As Unimed_Origem
  From Dbaps.Guia g
 Inner Join Dbaps.Itguia It
    On (g.Nr_Guia = It.Nr_Guia)
 Inner Join Dbaps.Tipo_Atendimento Ta
    On (Ta.Cd_Tipo_Atendimento = g.Cd_Tipo_Atendimento)
 Where Trunc(g.Dt_Emissao) Between '01/04/2022' And '30/08/2022'
   And g.Cd_Prestador_Executor In (800016, 800056)  
   
