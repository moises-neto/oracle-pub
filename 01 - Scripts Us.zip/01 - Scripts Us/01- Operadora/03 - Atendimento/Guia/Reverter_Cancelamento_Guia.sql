
--deixar os procedimentos com TP_STATUS = 0.
Select it.*, rowid
  From itguia it
 where it.nr_guia = (Select g.nr_guia
                       From dbaps.guia g
                      where g.nr_transacao = 2108000129606);
                      
                      
 
 -- Remover se tiver preenchido um dos campos.                    
Select g.cd_mot_cancelamento, g.cd_mot_cancelamento_guia, rowid
  From dbaps.guia g
 where g.nr_transacao = 2202000102079;
                                       
 
 
custom.pkg_rotinas_atendmvs

call custom.pkg_rotinas_atendmvs.PRC_ALTERA_STATUS_GUIA(P_NR_TRANSACAO => 2110000149486,P_STATUS_NEW => 'ANALISE');

SELECT



