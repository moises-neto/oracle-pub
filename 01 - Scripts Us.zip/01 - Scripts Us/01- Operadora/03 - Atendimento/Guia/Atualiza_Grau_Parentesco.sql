BEGIN
  DBAMV.PKG_MV2000.ATRIBUI_EMPRESA('1');
END;
/

Declare
Begin

  For Ix In (Select * From teste_view_2 where ds_objeto_valor_antigo is not null ) Loop
  
    Begin
    
      UPDATE DBAPS.USUARIO U
         SET u.cd_parentesco = Ix.Ds_Objeto_Valor_Antigo
         
       WHERE u.cd_matricula = Ix.Cd_Matricula
       and u.cd_parentesco is null
       and u.sn_titular = 'N' 
       AND U.SN_ATIVO = 'S'; 

    Exception
      When Others Then
        Rollback;
        Raise_Application_Error(-20002,
                                'Falha: ' || Sqlerrm || 'Matricula: ' ||
                                Ix.Cd_Matricula);
    End;
  End Loop;

Exception
  When Others Then
    Rollback;
    Raise_Application_Error(-20001, 'Falha: ' || Sqlerrm);
End;
