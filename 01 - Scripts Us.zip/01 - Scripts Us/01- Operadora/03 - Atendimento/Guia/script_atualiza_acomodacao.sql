Declare
  Vcontador Number;
Begin

  For i In (Select g.Cd_Tip_Acomodacao,
                   g.Nr_Guia,
                   Ta.Cd_Tip_Acomodacao As Tp_Acomodacao_New,
                   g.nr_transacao,
                   g.dt_emissao
              From Beneficiario_Transito Bt, Guia g, Tip_Acomodacao Ta
             Where g.NR_CARTEIRA_BENEFICIARIO = Bt.cd_matricula
               And Ta.Tp_Acomodacao = Bt.Tp_Acomodacao
             And Bt.Tp_Acomodacao Is Not Null
               And g.Cd_Tip_Acomodacao Is Null 
               And g.cd_tipo_atendimento In(3,8)
               --And g.nr_transacao = 2305000188383
               --And g.Sn_Valida_Rest_Carencia = 'S'
               And g.Dt_Impressao_Guia Is Null
              And Trunc(g.Dt_Emissao) Between '01/05/2023' And Trunc(Sysdate)
              -- And g.nr_transacao In (2305000155257,2305000137398)
               ---Select  * From temp_ajuste_moises
               ) Loop
  
    Vcontador := Vcontador + 1;
  
    Update Dbaps.Guia g
       Set g.Cd_Tip_Acomodacao = i.Tp_Acomodacao_New
     Where g.Nr_Guia = i.Nr_Guia;
    
     If(Vcontador >= 30) Then
    
    Commit;
  
    Vcontador := 0;
  
  End If;

End Loop;
Commit;
 
End;

