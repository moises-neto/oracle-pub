--AUTORIZADAS
SELECT *
  FROM ((SELECT X.STATUS, SUM(X.QUANTIDADE) GUIAS, X.NIVEL
           FROM (SELECT 'Autorizado [2]' STATUS,
                        1 AS QUANTIDADE,
                        'N�VEL' || ' ' || MAX(P.NR_NIVEL_AUTORIZACAO) AS NIVEL
                   FROM DBAPS.GUIA G, DBAPS.ITGUIA IT, DBAPS.PROCEDIMENTO P
                  WHERE G.NR_GUIA = IT.NR_GUIA
                    AND P.CD_PROCEDIMENTO = IT.CD_PROCEDIMENTO
                    AND TRUNC(G.DT_EMISSAO) BETWEEN '01/06/2021' AND
                        '30/06/2021'
                    And g.sn_valida_rest_carencia = 'S'
                    AND G.CD_MATRICULA IS NOT NULL
                  Group by g.nr_guia) X
          GROUP BY X.STATUS, X.NIVEL)
       
        UNION ALL --Autorizado parcialmente
       
        (SELECT X.STATUS, SUM(X.QUANTIDADE) AS GUIAS, X.NIVEL
           FROM (SELECT 'Autorizado parcialmente [8]' AS STATUS,
                        1 AS QUANTIDADE,
                        'N�VEL' || ' ' ||
                        (SELECT MAX(P.NR_NIVEL_AUTORIZACAO)
                           FROM DBAPS.ITGUIA IT, DBAPS.PROCEDIMENTO P
                          WHERE IT.NR_GUIA = G.NR_GUIA
                            AND IT.CD_PROCEDIMENTO = P.CD_PROCEDIMENTO) AS NIVEL
                   FROM (SELECT G.NR_GUIA
                           FROM DBAPS.GUIA G
                          WHERE TRUNC(G.DT_EMISSAO) BETWEEN '01/06/2021' AND
                                '30/06/2021'
                            AND G.CD_MATRICULA IS NOT NULL) G
                  Where Exists
                  (select 1
                           From dbaps.itguia it
                          where it.nr_guia = g.nr_guia
                            and it.tp_status = '4'
                            And it.nr_guia_prorrogacao is null
                            And exists
                          (select 1
                                   From dbaps.itguia it
                                  where it.nr_guia = g.nr_guia
                                    and it.tp_status not in (4, 0)
                                    And it.nr_guia_prorrogacao is null))
                 
                  Group by g.nr_guia) X
          GROUP BY X.STATUS, X.NIVEL)
       
        UNION ALL --Negado [4]
       
        (SELECT X.STATUS, SUM(X.QUANTIDADE) GUIAS, X.NIVEL
           FROM (SELECT 'Negado [4]' AS STATUS,
                        1 AS QUANTIDADE,
                        'N�VEL' || ' ' ||
                        (SELECT MAX(P.NR_NIVEL_AUTORIZACAO)
                           FROM DBAPS.ITGUIA IT, DBAPS.PROCEDIMENTO P
                          WHERE IT.NR_GUIA = G.NR_GUIA
                            AND IT.CD_PROCEDIMENTO = P.CD_PROCEDIMENTO) AS NIVEL
                   FROM (SELECT G.NR_GUIA
                           FROM DBAPS.GUIA G
                          WHERE TRUNC(G.DT_EMISSAO) BETWEEN '01/06/2021' AND
                                '30/06/2021'
                            AND G.CD_MATRICULA IS NOT NULL) G
                  Where Exists (select 1
                           From dbaps.itguia it
                          where it.nr_guia = g.nr_guia
                            and it.tp_status = '3')
                    And Not exists (select 1
                           From dbaps.itguia it
                          where it.nr_guia = g.nr_guia
                            and it.tp_status in (4, 0))
                 
                  Group by g.nr_guia) X
          GROUP BY X.STATUS, X.NIVEL)
       
        UNION ALL -- Cancelada [7]
       
        (SELECT X.STATUS, SUM(X.QUANTIDADE) GUIAS, X.NIVEL
           FROM (SELECT 'Cancelada [7]' STATUS,
                        1 AS QUANTIDADE,
                        'N�VEL' || ' ' ||
                        (SELECT MAX(P.NR_NIVEL_AUTORIZACAO)
                           FROM DBAPS.ITGUIA IT, DBAPS.PROCEDIMENTO P
                          WHERE IT.NR_GUIA = G.NR_GUIA
                            AND IT.CD_PROCEDIMENTO = P.CD_PROCEDIMENTO) AS NIVEL
                   FROM (SELECT G.NR_GUIA
                           FROM DBAPS.GUIA G
                          WHERE TRUNC(G.DT_EMISSAO) BETWEEN '01/06/2021' AND
                                '30/06/2021'
                            AND G.CD_MATRICULA IS NOT NULL) G
                  Where Exists (select 1
                           From dbaps.itguia it
                          where it.nr_guia = g.nr_guia
                            and it.tp_status = '5')
                  Group by g.nr_guia) X
          GROUP BY X.STATUS, X.NIVEL)
       
        UNION ALL -- EM AN�LISE
       
        (SELECT X.STATUS, SUM(X.QUANTIDADE) GUIAS, X.NIVEL
           FROM (SELECT 'Em analise [3]' as STATUS,
                        1 AS QUANTIDADE,
                        'N�VEL' || ' ' ||
                        (SELECT MAX(P.NR_NIVEL_AUTORIZACAO)
                           FROM DBAPS.ITGUIA IT, DBAPS.PROCEDIMENTO P
                          WHERE IT.NR_GUIA = G.NR_GUIA
                            AND IT.CD_PROCEDIMENTO = P.CD_PROCEDIMENTO) AS NIVEL
                   FROM (SELECT G.NR_GUIA
                           FROM DBAPS.GUIA G
                          WHERE TRUNC(G.DT_EMISSAO) BETWEEN '01/06/2021' AND
                                '30/06/2021'
                            AND G.CD_MATRICULA IS NOT NULL) G
                  Where Exists (select 1
                           From dbaps.itguia it
                          where it.nr_guia = g.nr_guia
                            and it.tp_status in (0, 1, 2))
                     or Not exists (select 1
                           From dbaps.itguia it
                          where it.nr_guia = g.nr_guia)
                  Group by g.nr_guia) X
          GROUP BY X.STATUS, X.NIVEL)
       
        UNION all --Auditoria [5]
       
        (SELECT X.STATUS, SUM(X.QUANTIDADE) GUIAS, X.NIVEL
           FROM (SELECT 'Auditoria [5]' AS STATUS,
                        1 AS QUANTIDADE,
                        'N�VEL' || ' ' || (SELECT MAX(P.NR_NIVEL_AUTORIZACAO)
                           FROM DBAPS.ITGUIA IT, DBAPS.PROCEDIMENTO P
                          WHERE IT.NR_GUIA = G.NR_GUIA
                            AND IT.CD_PROCEDIMENTO = P.CD_PROCEDIMENTO) AS NIVEL
                   FROM (SELECT G.NR_GUIA
                           FROM DBAPS.GUIA G
                          WHERE TRUNC(G.DT_EMISSAO) BETWEEN '01/06/2021' AND
                                '30/06/2021'
                            AND G.CD_MATRICULA IS NOT NULL) G
                           Where Exists (Select 1 From itguia it where it.nr_guia = g.nr_guia and it.tp_status = 2)
                  GROUP BY G.NR_GUIA) X
          GROUP BY X.STATUS, X.NIVEL)) X
 ORDER BY STATUS
