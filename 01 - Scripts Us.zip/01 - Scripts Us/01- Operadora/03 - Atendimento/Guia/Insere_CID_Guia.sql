Select Rowid,
       g.nr_guia,
       g.cd_cid,
       (select distinct v.cd_conta_medica 
          From dbaps.v_ctas_medicas v
         where v.nr_guia = g.nr_guia)
  From dbaps.guia g
 where g.nr_guia in
       (select v.nr_guia
          From dbaps.v_ctas_medicas v
         where v.cd_conta_medica in
               (10291865, 10291860, 10289602, 10289598, 10291875))
              
