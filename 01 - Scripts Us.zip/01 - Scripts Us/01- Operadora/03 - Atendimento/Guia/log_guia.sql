Select g.dtatualizacao$$,
       g.nrsequencia$$,
       g.tpoperacao$$,
       g.nousuario_rede$$,
       g.nr_guia,
       g.cd_prestador,
       g.nm_prestador,
       g.ds_email_beneficiario
  from inf$rpl.lg$_guia g
 where g.nr_guia = '78537599'
 order by g.nrsequencia$$ asc

Select g.*
  from inf$rpl.lg$_guia g
 where g.nr_transacao in(2110000038119)
  
 order by g.nrsequencia$$ asc;
 
 Select IT.NR_GUIA, it.tp_status, it.* from inf$rpl.lg$_itguia it
 where it.nr_guia in (78995259)
 and it.cd_procedimento = 40201171
-- And it.cd_procedimento = 40301630
  order by it.nrsequencia$$ asc;    
  
    
               
    
    sELECT * fROM inf$rpl.lg$_usuario U
    WHERE u.cd_matricula = 2015160048
    
   Select * From  inf$rpl.lg$_deslig_futuro_benefc d
   where d.cd_matricula = 1858170092;
   
   
   Select * From inf$rpl.lg$_desl
