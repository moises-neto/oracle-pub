Select * from DBAPS.PTU_RESP_ORDEM_SERV_PROC

Select * from PTU_RESP_ORDEM_SERVICO p
where p.cd_ptu_mensagem = 633581795
