CREATE OR REPLACE PROCEDURE DBAPS.prc_ptu_autorizador_v8(P_ID_PTU_MENSAGEM     IN NUMBER
                            ,P_ID_PTU_MENSAGEM_OUT OUT NUMBER) IS
  /**************************************************************
    <objeto>
     <nome>prc_ptu_autorizador</nome>
     <usuario>Eli Filho</usuario>
     <dataAlteracao>11/12/2020 19:25</dataAlteracao>
     <alteracao>Foi realizado ajuste no TP_TABELA para devolver o c�digo da tabela corretamente.
    Tamb�m foi realizado ajuste para n�o dar erro de procedimento duplicado quando a Unimed enviar
    c�digo de procedimento igual ao c�digo de pacote (nessa regra foi adicionada o TP_TABELA
    para ser validado al�m do c�digo do pacote/procedimento).
     </alteracao>
     <descricao>PROCEDURE CHAMADA PELO WEBSERVICE PTU PEDIDO DE AUTORIZACAO E PEDIDO DE COMPLEMENTO DE AUTORIZACAO</descricao>
     <parametro></parametro>
     <versao>1.61</versao>
    </objeto>
  ***************************************************************/
  CURSOR cPtuMensagem(P_ID_PTU_MENSAGEM IN NUMBER) IS --CABECALHO DA PTU MENSAGEM
    SELECT *
      FROM DBAPS.PTU_MENSAGEM
     WHERE CD_PTU_MENSAGEM = P_ID_PTU_MENSAGEM;
  --
  --* CURSOR QUE VERIFICA SE O WEB SERVICE ESTA ATIVO OU NAO. (CHAVE WEBSERVICE_PTU_AUTORIZACAO)
  CURSOR cWebserviceAtivo(P_CD_MULTI_EMPRESA IN NUMBER) IS
    SELECT VALOR
      FROM DBAPS.MVS_CONFIGURACAO
     WHERE CHAVE = 'WEBSERVICE_PTU_AUTORIZACAO'
       AND CD_MULTI_EMPRESA =
           NVL(P_CD_MULTI_EMPRESA, DBAMV.PKG_MV2000.LE_EMPRESA);
  --* CURSOR QUE RETORNA OS DADOS DAS SOLICITACAO - 00600 E 00605
  CURSOR cPedidoAutorizacao(PCD_PTU_MENSAGEM        IN NUMBER
                           ,PCD_UNIMED_REQUISITANTE IN VARCHAR2) IS
    SELECT *
      FROM (SELECT '00600' TP_TRANSACAO
                  ,NULL NR_GUIA
                  ,PPA.CD_CID
                  ,E.CD_ESPECIALIDADE CD_ESPECIALIDADE_MEDICA
                  ,PPA.CD_IBGE
                  ,PPA.CD_IDENTIFICACAO
                  ,TO_CHAR(DBAPS.FNC_TISS_USUARIO(LPAD(PPA.CD_UNIMED_ORIGEM ||
                                                       LPAD(PPA.CD_IDENTIFICACAO, 13, '0'), 16, '0'), PPA.CD_IDENTIFICACAO_BIOMETRICA)) CD_MATRICULA
                  ,LPAD(PPA.CD_UNIMED_ORIGEM ||
                        LPAD(PPA.CD_IDENTIFICACAO, 13, '0'), 16, '0') NR_CARTEIRA_BENEFICIARIO
                  ,PPA.CD_IDENTIFICACAO_BIOMETRICA
                  ,PPA.CD_PRESTADOR
                  ,PPA.CD_PRESTADOR_REQUISITANTE
                  ,PPA.CD_PRESTADOR_REQUI_UNIMED
                  ,PPA.CD_PRESTADOR_UNIMED
                  ,PPA.CD_PTU_MENSAGEM
                  ,PPA.CD_PTU_PEDIDO_AUTORIZACAO
                  ,PPA.CD_UNIMED_ATEND
                  ,PPA.CD_UNIMED_ORIGEM
                  ,PPA.CD_VERSAO_PTU
                  ,PPA.CL_METASTASE
                  ,PPA.CL_NODULO
                  ,PPA.CL_TUMOR
                  ,PPA.DS_AREA_IRRADIADA
                  ,PPA.DS_EMAIL_PROFISSIONAL
                  ,PPA.DS_INDICACAO_CLINICA
                  ,PPA.DS_INFO_RELEVANTES_QUIMIO
                  ,PPA.DS_INFO_RELEVANTES_RADIO
                  ,PPA.DS_JUSTIFICATIVA_TECNICA
                  ,PPA.DS_MATERIAL_SOLIC_OPME
                  ,PPA.DS_OBSERVACAO
                  ,PPA.DS_OPME
                  ,PPA.DS_PLANO_TERAPEUTICO
                  ,PPA.DS_QUIMIO
                  ,PPA.DS_QUIMIO_RADIO
                  ,PPA.DS_RADIO
                  ,PPA.DS_VERSAO_TISS
                  ,PPA.DT_ATENDIMENTO
                  ,PPA.DT_IRRADIACAO
                  ,PPA.DT_PREV_ADMIN
                  ,PPA.DT_QUIMIO
                  ,TO_DATE(TO_CHAR(PPA.DT_SUGERIDA_INTERNACAO, 'YYYY-MM-DD'), 'YYYY-MM-DD') DT_SUGERIDA_INTERNACAO
                  ,PPA.NM_PRESTADOR_ALTO_CUSTO NM_PRESTADOR
                  ,PPA.NM_PROFISSIONAL
                  ,PPA.NR_ALTURA_BENEF_QUIMIO
                  ,PPA.NR_CICLOS
                  ,PPA.NR_CICLO_ATUAL
                  ,PPA.NR_IDADE
                  ,DECODE(PPA.SN_ORDEM_SERVICO, 'S', PPA.NR_IDENT_ORDEM_SERVICO, 0) NR_IDENT_ORDEM_SERVICO
                  ,PPA.NR_INTERVALO_CICLOS
                  ,PPA.NR_PESO_BENEF_QUIMIO
                  ,PPA.NR_SUP_CORP_BENEF_QUIMIO
                  ,PPA.NR_TELEFONE_PROFISSIONAL
                  ,NULL NR_TRANSACAO_ORIGEM_PRES
                  ,PPA.NR_TRANSACAO_PRESTADORA
                  ,PPA.NR_VIA_CARTAO
                  ,PPA.QTD_DIAS_CICLO
                  ,PPA.QT_CAMPOS
                  ,PPA.QT_DIAS_CICLO
                  ,PPA.QT_DIAS_EVOLUCAO_DOENCA
                  ,PPA.QT_DIAS_TRATAMENTO
                  ,PPA.QT_DOSES_DIA
                  ,PPA.QT_DOSES_TOTAL
                  ,PPA.SN_ANEXO
                  ,PPA.SN_LIMINAR
                  ,Nvl(PPA.SN_ORDEM_SERVICO, 'N') SN_ORDEM_SERVICO
                  ,PPA.SN_RN
                  ,Decode(PPA.SN_URGENCIA_EMERGENCIA, 'S', 'U', 'E') SN_URGENCIA_EMERGENCIA
                  ,IA.CD_INDICADOR_ACIDENTE TP_ACIDENTE
                  ,PPA.TP_IDENTIFICACAO_ALTO_CUSTO
                  ,DECODE(PPA.TP_INTERNACAO, 1, 'N', 2, 'C', 3, 'O', 6, 'P', 7, 'S', NULL) TP_INTERNACAO
                  , --1 = InternaCAO Clinica 2 = InternaCAO Cirurgica 3 = InternaCAO Obstetrica 6 = InternaCAO Pediatrica 7 = InternaCAO Psiquiatrica
                   PPA.TP_QUIMIO
                  ,PPA.TP_REDE_MIN
                  ,PPA.TP_SEXO
                  ,DECODE(PPA.TP_SEXO, 1, 'M', 3, 'F', 'I') TP_SEXO_SOUL
                  ,
                   --QUIMIO
                   PPA.NM_PROFISSIONAL_QUIMIO
                  ,PPA.DS_EMAIL_PROFISSIONAL_QUIMIO
                  ,PPA.NR_TEL_PROFISSIONAL_QUIMIO
                  ,TETQ.CD_TIPO_ESTADIAMENTO_TUMOR    TP_ESTADIAMENTO_TUMOR_QUIMIO
                  ,PPA.DT_CIRURGIA_QUIMIO
                  ,PPA.DT_DIAGNOSTICO_QUIMIO
                  ,PPA.DS_CIRURGIA_QUIMIO
                  ,PPA.DS_DIAG_CIT_HIST_QUIMIO
                  ,PPA.CD_CID_1_QUIMIO
                  ,PPA.CD_CID_2_QUIMIO
                  ,PPA.CD_CID_3_QUIMIO
                  ,PPA.CD_CID_4_QUIMIO
                  ,TFTQ.CD_TIPO_FINALIDADE_TRATAMENTO TP_FINALIDADE_QUIMIO
                  ,TPEQ.CD_TIPO_ECOG                  TP_ECOG_QUIMIO
                  ,
                   --RADIO
                   PPA.NM_PROFISSIONAL_RADIO
                  ,PPA.DS_EMAIL_PROFISSIONAL_RADIO
                  ,PPA.NR_TEL_PROFISSIONAL_RADIO
                  ,TETR.CD_TIPO_ESTADIAMENTO_TUMOR    TP_ESTADIAMENTO_TUMOR_RADIO
                  ,PPA.DT_CIRURGIA_RADIO
                  ,PPA.DT_DIAGNOSTICO_RADIO
                  ,PPA.DS_CIRURGIA_RADIO
                  ,PPA.DS_DIAG_CIT_HIST_RADIO
                  ,PPA.CD_CID_1_RADIO
                  ,PPA.CD_CID_2_RADIO
                  ,PPA.CD_CID_3_RADIO
                  ,PPA.CD_CID_4_RADIO
                  ,TFTR.CD_TIPO_FINALIDADE_TRATAMENTO TP_FINALIDADE_RADIO
                  ,TPER.CD_TIPO_ECOG                  TP_ECOG_RADIO
                  ,TPEDIAGIMG.CD_TIPO_ECOG            TP_DIAGNOSTICO_IMAGEM
                --,CD_DIAG_IMAGEM_RADIO
                  ,NULL                               TP_ACOMODACAO_GUIA_PAI
                  ,PPA.NR_TOKEN
                  ,PPA.TP_ETAPA_AUTORIZACAO
              FROM DBAPS.PTU_PEDIDO_AUTORIZACAO         PPA
                  ,DBAPS.MVS_TIPO_ESTADIAMENTO_TUMOR    TETQ
                  ,DBAPS.MVS_TIPO_ESTADIAMENTO_TUMOR    TETR
                  ,DBAPS.MVS_TIPO_FINALIDADE_TRATAMENTO TFTQ
                  ,DBAPS.MVS_TIPO_FINALIDADE_TRATAMENTO TFTR
                  ,DBAPS.MVS_TIPO_ECOG                  TPEQ
                  ,DBAPS.MVS_TIPO_ECOG                  TPER
                  ,DBAPS.MVS_TIPO_ECOG                  TPEDIAGIMG
                  ,DBAPS.ESPECIALIDADE                  E
                  ,DBAPS.INDICADOR_ACIDENTE             IA
                  ,DBAPS.PTU_MENSAGEM                   PTU
             WHERE PPA.TP_ESTADIAMENTO_TUMOR_QUIMIO = TETQ.CD_PTU(+)
               AND PPA.TP_ESTADIAMENTO_TUMOR_RADIO = TETR.CD_PTU(+)
               AND PPA.TP_FINALIDADE_QUIMIO = TFTQ.CD_PTU(+)
               AND PPA.TP_FINALIDADE_RADIO = TFTR.CD_PTU(+)
               AND PPA.TP_ECOG_QUIMIO = TPEQ.CD_PTU(+)
               AND PPA.TP_ECOG_RADIO = TPER.CD_PTU(+)
               AND PPA.TP_DIAGNOSTICO_IMAGEM = TPEDIAGIMG.CD_TIPO_ECOG(+)
               AND PPA.CD_ESPECIALIDADE_MEDICA = E.CD_PTU_ESPECIALIDADE(+)
               AND PPA.TP_ACIDENTE = IA.CD_PTU(+)
               AND PPA.CD_PTU_MENSAGEM = PTU.CD_PTU_MENSAGEM
               AND PPA.CD_PTU_MENSAGEM = PCD_PTU_MENSAGEM
               AND LPAD(NVL(PPA.CD_UNIMED_ATEND, PTU.CD_UNIMED_ORIGEM), 4, '0') =
                   LPAD(PCD_UNIMED_REQUISITANTE, 4, '0')
               AND ROWNUM = 1
            UNION ALL
            SELECT '00605' TP_TRANSACAO
                  ,G.NR_GUIA
                  ,NULL CD_CID
                  ,E.CD_ESPECIALIDADE CD_ESPECIALIDADE_MEDICA
                  ,NULL CD_IBGE
                  ,PPCA.CD_IDENTIFICACAO
                  ,TO_CHAR(DBAPS.FNC_TISS_USUARIO(LPAD(PPCA.CD_UNIMED_ORIGEM ||
                                                       LPAD(PPCA.CD_IDENTIFICACAO, 13, '0'), 16, '0'), PPCA.CD_IDENTIFICACAO_BIOMETRICA)) CD_MATRICULA
                  ,LPAD(PPCA.CD_UNIMED_ORIGEM ||
                        LPAD(PPCA.CD_IDENTIFICACAO, 13, '0'), 16, '0') NR_CARTEIRA_BENEFICIARIO
                  ,PPCA.CD_IDENTIFICACAO_BIOMETRICA
                  ,PPCA.CD_PRESTADOR
                  ,PPCA.CD_PRESTADOR_REQUISITANTE
                  ,PPCA.CD_PRESTADOR_REQUI_UNIMED
                  ,PPCA.CD_PRESTADOR_UNIMED
                  ,PPCA.CD_PTU_MENSAGEM
                  ,PPCA.CD_PTU_PEDIDO_COMPLMT_AUT CD_PTU_PEDIDO_AUTORIZACAO
                  ,TO_NUMBER(G.CD_UNIMED_EXECUTORA) CD_UNIMED_ATEND
                  ,PPCA.CD_UNIMED_ORIGEM
                  ,PPCA.CD_VERSAO_PTU
                  ,PPCA.CL_METASTASE
                  ,PPCA.CL_NODULO
                  ,PPCA.CL_TUMOR
                  ,PPCA.DS_AREA_IRRADIADA
                  ,PPCA.DS_EMAIL_PROFISSIONAL
                  ,PPCA.DS_INDICACAO_CLINICA
                  ,PPCA.DS_INFO_RELEVANTES_QUIMIO
                  ,PPCA.DS_INFO_RELEVANTES_RADIO
                  ,PPCA.DS_JUSTIFICATIVA_TECNICA
                  ,PPCA.DS_MATERIAL_SOLIC_OPME
                  ,PPCA.DS_OBSERVACAO
                  ,PPCA.DS_OPME
                  ,PPCA.DS_PLANO_TERAPEUTICO
                  ,PPCA.DS_QUIMIO
                  ,PPCA.DS_QUIMIO_RADIO
                  ,PPCA.DS_RADIO
                  ,G.CD_VERSAO_TISS DS_VERSAO_TISS
                  ,NULL DT_ATENDIMENTO
                  ,PPCA.DT_IRRADIACAO
                  ,PPCA.DT_PREV_ADMIN
                  ,PPCA.DT_QUIMIO
                  ,NULL DT_SUGERIDA_INTERNACAO
                  ,NULL NM_PRESTADOR
                  ,PPCA.NM_PROFISSIONAL
                  ,PPCA.NR_ALTURA_BENEF_QUIMIO
                  ,PPCA.NR_CICLOS
                  ,PPCA.NR_CICLO_ATUAL
                  ,PPCA.NR_IDADE
                  ,0 NR_IDENT_ORDEM_SERVICO
                  ,PPCA.NR_INTERVALO_CICLOS
                  ,PPCA.NR_PESO_BENEF_QUIMIO
                  ,PPCA.NR_SUP_CORP_BENEF_QUIMIO
                  ,PPCA.NR_TELEFONE_PROFISSIONAL
                  ,PPCA.NR_TRANSACAO_ORIGEM_PRES
                  ,PPCA.NR_TRANSACAO_PRESTADORA
                  ,NULL NR_VIA_CARTAO
                  ,NULL QTD_DIAS_CICLO
                  ,PPCA.QT_CAMPOS
                  ,PPCA.QT_DIAS_CICLO
                  ,NULL QT_DIAS_EVOLUCAO_DOENCA
                  ,PPCA.QT_DIAS_TRATAMENTO
                  ,PPCA.QT_DOSES_DIA
                  ,PPCA.QT_DOSES_TOTAL
                  ,PPCA.SN_ANEXO
                  ,PPCA.SN_LIMINAR
                  ,'N' SN_ORDEM_SERVICO
                  ,NULL SN_RN
                  ,G.TP_CARATER_SOLIC_INTER SN_URGENCIA_EMERGENCIA
                  ,NULL TP_ACIDENTE
                  ,NULL TP_IDENTIFICACAO_ALTO_CUSTO
                  ,NULL TP_INTERNACAO
                  ,PPCA.TP_QUIMIO
                  ,NULL TP_REDE_MIN
                  ,PPCA.TP_SEXO
                  ,DECODE(PPCA.TP_SEXO, 1, 'M', 3, 'F', 'I') TP_SEXO_SOUL
                  ,
                   --QUIMIO
                   PPCA.NM_PROFISSIONAL_QUIMIO
                  ,PPCA.DS_EMAIL_PROFISSIONAL_QUIMIO
                  ,PPCA.NR_TEL_PROFISSIONAL_QUIMIO
                  ,TETQ.CD_TIPO_ESTADIAMENTO_TUMOR    TP_ESTADIAMENTO_TUMOR_QUIMIO
                  ,PPCA.DT_CIRURGIA_QUIMIO
                  ,PPCA.DT_DIAGNOSTICO_QUIMIO
                  ,PPCA.DS_CIRURGIA_QUIMIO
                  ,PPCA.DS_DIAG_CIT_HIST_QUIMIO
                  ,PPCA.CD_CID_1_QUIMIO
                  ,PPCA.CD_CID_2_QUIMIO
                  ,PPCA.CD_CID_3_QUIMIO
                  ,PPCA.CD_CID_4_QUIMIO
                  ,TFTQ.CD_TIPO_FINALIDADE_TRATAMENTO TP_FINALIDADE_QUIMIO
                  ,TPEQ.CD_TIPO_ECOG                  TP_ECOG_QUIMIO
                  ,
                   --RADIO
                   PPCA.NM_PROFISSIONAL_RADIO
                  ,PPCA.DS_EMAIL_PROFISSIONAL_RADIO
                  ,PPCA.NR_TEL_PROFISSIONAL_RADIO
                  ,TETR.CD_TIPO_ESTADIAMENTO_TUMOR    TP_ESTADIAMENTO_TUMOR_RADIO
                  ,PPCA.DT_CIRURGIA_RADIO
                  ,PPCA.DT_DIAGNOSTICO_RADIO
                  ,PPCA.DS_CIRURGIA_RADIO
                  ,PPCA.DS_DIAG_CIT_HIST_RADIO
                  ,PPCA.CD_CID_1_RADIO
                  ,PPCA.CD_CID_2_RADIO
                  ,PPCA.CD_CID_3_RADIO
                  ,PPCA.CD_CID_4_RADIO
                  ,TFTR.CD_TIPO_FINALIDADE_TRATAMENTO TP_FINALIDADE_RADIO
                  ,TPER.CD_TIPO_ECOG                  TP_ECOG_RADIO
                  ,TPEDIAGIMG.CD_TIPO_ECOG            TP_DIAGNOSTICO_IMAGEM
                --,CD_DIAG_IMAGEM_RADIO
                  ,G.CD_TIP_ACOMODACAO                TP_ACOMODACAO_GUIA_PAI
                  ,PPCA.NR_TOKEN
                  ,NULL TP_ETAPA_AUTORIZACAO
              FROM DBAPS.PTU_PEDIDO_COMPLMT_AUT         PPCA
                  ,DBAPS.MVS_TIPO_ESTADIAMENTO_TUMOR    TETQ
                  ,DBAPS.MVS_TIPO_ESTADIAMENTO_TUMOR    TETR
                  ,DBAPS.MVS_TIPO_FINALIDADE_TRATAMENTO TFTQ
                  ,DBAPS.MVS_TIPO_FINALIDADE_TRATAMENTO TFTR
                  ,DBAPS.MVS_TIPO_ECOG                  TPEQ
                  ,DBAPS.MVS_TIPO_ECOG                  TPER
                  ,DBAPS.MVS_TIPO_ECOG                  TPEDIAGIMG
                  ,DBAPS.ESPECIALIDADE                  E
                  ,DBAPS.GUIA                           G
                  ,DBAPS.PTU_MENSAGEM                   PTU
             WHERE PPCA.TP_ESTADIAMENTO_TUMOR_QUIMIO = TETQ.CD_PTU(+)
               AND PPCA.TP_ESTADIAMENTO_TUMOR_RADIO = TETR.CD_PTU(+)
               AND PPCA.TP_FINALIDADE_QUIMIO = TFTQ.CD_PTU(+)
               AND PPCA.TP_FINALIDADE_RADIO = TFTR.CD_PTU(+)
               AND PPCA.TP_ECOG_QUIMIO = TPEQ.CD_PTU(+)
               AND PPCA.TP_ECOG_RADIO = TPER.CD_PTU(+)
               AND PPCA.TP_DIAGNOSTICO_IMAGEM = TPEDIAGIMG.CD_TIPO_ECOG(+)
               AND PPCA.CD_ESPECIALIDADE_MEDICA = E.CD_PTU_ESPECIALIDADE(+)
               AND PPCA.NR_TRANSACAO_ORIGEM_PRES = G.CD_PTU_MENSAGEM_DESTINO
               AND PPCA.CD_PTU_MENSAGEM = PTU.CD_PTU_MENSAGEM
               AND PPCA.CD_PTU_MENSAGEM = PCD_PTU_MENSAGEM
               AND LPAD(NVL(PPCA.CD_PRESTADOR_REQUI_UNIMED, PTU.CD_UNIMED_ORIGEM), 4, '0') =
                   LPAD(PCD_UNIMED_REQUISITANTE, 4, '0')
               AND ROWNUM = 1);
  --* CURSOR RESPONSAVEL POR RETORNA OS PROCEDIMENTOS DAS TRANSACOES 00600 e 00605
  CURSOR cPedidoAutorizacaoItem(PCD_PTU_PEDIDO IN NUMBER
                               ,PTP_ANEXO      IN NUMBER) IS
    SELECT *
      FROM (SELECT '00600' TP_TRANSACAO
                  ,PTAI.CD_ANVISA
                  ,PTAI.CD_PTU_PEDIDO_AUTORIZACAO CD_PTU_PEDIDO_AUTORIZACAO
                  ,PTAI.CD_PTU_PEDIDO_AUTORIZACAO_ITEM CD_PTU_PEDIDO_AUTORIZACAO_ITEM
                  ,PTAI.CD_REFERENCIA_MATERIAL_FAB
                  ,PTAI.CD_SERVICO CD_SERVICO
                  ,TO_CHAR(PTAI.CD_VIA_ADMIN) CD_VIA_ADMIN
                  ,DBAPS.FNC_AJUSTA_DADO_PTU('ANS', PTAI.DS_SERVICO) DS_SERVICO
                  ,PTAI.DT_PROV
                  ,PTAI.NR_GUIA
                  ,PTAI.QT_FREQUENCIA
                  ,PTAI.QT_SERVICO
                  ,PTAI.QT_TOTAL_DOSAGEM_CICLO
                  ,PTAI.SN_PACOTE
                  ,PTAI.SQ_ITEM
                  ,PTAI.TP_ANEXO
                  ,PTAI.TP_ORDEM
                  ,LPad(PTAI.TP_TABELA,2,'0') TP_TABELA
                  ,MUM.CD_TERMO UNI_MEDIDA_MED
                  ,PTAI.VL_MONETARIO
                  ,PTAI.VL_UNIT_SERVICO
                  ,P.SN_PROCED_UNIVERSAL
                  ,Decode(PTAI.TP_ANEXO, 1, 'Q' --Indicador de Quimioterapia
                         , 2, 'R' --Indicador de Radioterapia
                         , 3, 'O') TP_ANEXO_SOUL
                  , --Indicador de Opme
                   GP.TP_GRU_PRO
                  ,P.CD_PROCEDIMENTO
              FROM DBAPS.PTU_PEDIDO_AUTORIZACAO_ITEM PTAI
                  ,DBAPS.PROCEDIMENTO                P
                  ,DBAPS.GRUPO_PROCEDIMENTO          GP
                  ,DBAPS.MVS_UNIDADE_MEDIDA          MUM
             WHERE CD_PTU_PEDIDO_AUTORIZACAO = PCD_PTU_PEDIDO
               AND PTAI.UNI_MEDIDA_MED = MUM.CD_PTU(+)
               AND P.CD_GRUPO_PROCEDIMENTO = GP.CD_GRUPO_PROCEDIMENTO(+)
               AND SubStr(PTAI.CD_SERVICO,-8) = P.CD_PROCEDIMENTO(+)
               AND (PTP_ANEXO IS NULL OR PTP_ANEXO = PTAI.TP_ANEXO)
            UNION ALL
            SELECT '00605' TP_TRANSACAO
                  ,PPCAI.CD_ANVISA
                  ,PPCAI.CD_PTU_PEDIDO_COMPLMT_AUT CD_PTU_PEDIDO_AUTORIZACAO
                  ,PPCAI.CD_PTU_PEDIDO_COMPLMT_AUT_ITEM CD_PTU_PEDIDO_AUTORIZACAO_ITEM
                  ,PPCAI.CD_REFERENCIA_MATERIAL_FAB
                  ,PPCAI.CD_SERVICO CD_SERVICO
                  ,TO_CHAR(PPCAI.CD_VIA_ADMIN) CD_VIA_ADMIN
                  ,DBAPS.FNC_AJUSTA_DADO_PTU('ANS', PPCAI.DS_SERVICO) DS_SERVICO
                  ,PPCAI.DT_PROV
                  ,NULL NR_GUIA
                  ,PPCAI.QT_FREQUENCIA
                  ,PPCAI.QT_SERVICO
                  ,PPCAI.QT_TOTAL_DOSAGEM_CICLO
                  ,PPCAI.SN_PACOTE
                  ,PPCAI.SQ_ITEM
                  ,PPCAI.TP_ANEXO
                  ,PPCAI.TP_ORDEM
                  ,LPad(PPCAI.TP_TABELA,2,'0') TP_TABELA
                  ,MUM.CD_TERMO UNI_MEDIDA_MED
                  ,PPCAI.VL_MONETARIO
                  ,PPCAI.VL_UNIT_SERVICO
                  ,P.SN_PROCED_UNIVERSAL
                  ,Decode(PPCAI.TP_ANEXO, 1, 'Q' --Indicador de Quimioterapia
                         , 2, 'R' --Indicador de Radioterapia
                         , 3, 'O') TP_ANEXO_SOUL
                  , --Indicador de Opme
                   GP.TP_GRU_PRO
                  ,P.CD_PROCEDIMENTO
              FROM DBAPS.PTU_PEDIDO_COMPLMT_AUT_ITEM PPCAI
                  ,DBAPS.PROCEDIMENTO                P
                  ,DBAPS.GRUPO_PROCEDIMENTO          GP
                  ,DBAPS.MVS_UNIDADE_MEDIDA          MUM
             WHERE CD_PTU_PEDIDO_COMPLMT_AUT = PCD_PTU_PEDIDO
               AND PPCAI.UNI_MEDIDA_MED = MUM.CD_PTU(+)
               AND P.CD_GRUPO_PROCEDIMENTO = GP.CD_GRUPO_PROCEDIMENTO(+)
               AND SubStr(PPCAI.CD_SERVICO,-8)= P.CD_PROCEDIMENTO(+)
               AND (PTP_ANEXO IS NULL OR PTP_ANEXO = PPCAI.TP_ANEXO))
     ORDER BY SQ_ITEM ASC;
     --
  CURSOR cItGuiaAuditoria(PNR_GUIA IN NUMBER) IS
    SELECT 1
      FROM DBAPS.ITGUIA
     WHERE NR_GUIA = PNR_GUIA
       AND TP_STATUS IN (0, 1, 2)
       AND ROWNUM = 1;
  CURSOR cGlosaPtuOnline(PCD_ITGUIA IN NUMBER) IS
    SELECT CD_MOTIVO_PTU_ONLINE CD_GLOSA
      FROM DBAPS.ITGUIA_ERROS
          ,DBAPS.MOTIVO_GLOSA
     WHERE ITGUIA_ERROS.CD_MOTIVO = MOTIVO_GLOSA.CD_MOTIVO
       AND ITGUIA_ERROS.CD_ITGUIA = PCD_ITGUIA
       AND ROWNUM < 5;
  --* CURSOR RESPONSAVEL POR RETORNAR QUANTIDADE DE PROCEDIMENTOS EXISTENTES NO COMPLEMENTO
  CURSOR cQtdAnexosPedido(PCD_PTU_PEDIDO_ITEM IN NUMBER) IS
    SELECT SUM(QT_NAO_ANEXO) QT_NAO_ANEXO
          ,SUM(QT_ANEXO_QUIMIO) QT_ANEXO_QUIMIO
          ,SUM(QT_ANEXO_RADIO) QT_ANEXO_RADIO
          ,SUM(QT_ANEXO_OPME) QT_ANEXO_OPME
          ,SUM((QT_ANEXO_QUIMIO + QT_ANEXO_RADIO + QT_ANEXO_OPME)) QT_ANEXO
          ,SUM(QT_TOTAL) QT_TOTAL
      FROM (SELECT 1 QT_NAO_ANEXO
                  ,0 QT_ANEXO_QUIMIO
                  ,-0 QT_ANEXO_RADIO
                  ,0 QT_ANEXO_OPME
                  ,COUNT(TP_ANEXO) QT_TOTAL
                  ,CD_PTU_PEDIDO_COMPLMT_AUT CD_PTU_PEDIDO_AUTORIZACAO
              FROM DBAPS.PTU_PEDIDO_COMPLMT_AUT_ITEM
             WHERE TP_ANEXO = 9
               AND CD_PTU_PEDIDO_COMPLMT_AUT = PCD_PTU_PEDIDO_ITEM
             GROUP BY CD_PTU_PEDIDO_COMPLMT_AUT -- PEDIDO_COMPLEMENTO_AUTORIZACAO NAO ANEXO
            UNION ALL
            SELECT 0 QT_NAO_ANEXO
                  ,1 QT_ANEXO_QUIMIO
                  ,0 QT_ANEXO_RADIO
                  ,0 QT_ANEXO_OPME
                  ,COUNT(TP_ANEXO) QT_TOTAL
                  ,CD_PTU_PEDIDO_COMPLMT_AUT CD_PTU_PEDIDO_AUTORIZACAO
              FROM DBAPS.PTU_PEDIDO_COMPLMT_AUT_ITEM
             WHERE TP_ANEXO = 1
               AND CD_PTU_PEDIDO_COMPLMT_AUT = PCD_PTU_PEDIDO_ITEM
             GROUP BY CD_PTU_PEDIDO_COMPLMT_AUT -- PEDIDO_COMPLEMENTO_AUTORIZACAO QUIMIOTERAPIA
            UNION ALL
            SELECT 0 QT_NAO_ANEXO
                  ,0 QT_ANEXO_QUIMIO
                  ,1 QT_ANEXO_RADIO
                  ,0 QT_ANEXO_OPME
                  ,COUNT(TP_ANEXO) QT_TOTAL
                  ,CD_PTU_PEDIDO_COMPLMT_AUT CD_PTU_PEDIDO_AUTORIZACAO
              FROM DBAPS.PTU_PEDIDO_COMPLMT_AUT_ITEM
             WHERE TP_ANEXO = 2
               AND CD_PTU_PEDIDO_COMPLMT_AUT = PCD_PTU_PEDIDO_ITEM
             GROUP BY CD_PTU_PEDIDO_COMPLMT_AUT -- PEDIDO_COMPLEMENTO_AUTORIZACAO RADIOTERAPIA
            UNION ALL
            SELECT 0 QT_NAO_ANEXO
                  ,0 QT_ANEXO_QUIMIO
                  ,0 QT_ANEXO_RADIO
                  ,1 QT_ANEXO_OPME
                  ,COUNT(TP_ANEXO) QT_TOTAL
                  ,CD_PTU_PEDIDO_COMPLMT_AUT CD_PTU_PEDIDO_AUTORIZACAO
              FROM DBAPS.PTU_PEDIDO_COMPLMT_AUT_ITEM
             WHERE TP_ANEXO = 3
               AND CD_PTU_PEDIDO_COMPLMT_AUT = PCD_PTU_PEDIDO_ITEM
             GROUP BY CD_PTU_PEDIDO_COMPLMT_AUT -- PEDIDO_COMPLEMENTO_AUTORIZACAO OPME
            UNION ALL
            SELECT 1 QT_NAO_ANEXO
                  ,0 QT_ANEXO_QUIMIO
                  ,0 QT_ANEXO_RADIO
                  ,0 QT_ANEXO_OPME
                  ,COUNT(TP_ANEXO) QT_TOTAL
                  ,CD_PTU_PEDIDO_AUTORIZACAO CD_PTU_PEDIDO_AUTORIZACAO
              FROM DBAPS.PTU_PEDIDO_AUTORIZACAO_ITEM
             WHERE TP_ANEXO = 9
               AND CD_PTU_PEDIDO_AUTORIZACAO = PCD_PTU_PEDIDO_ITEM
             GROUP BY CD_PTU_PEDIDO_AUTORIZACAO -- PEDIDO_AUTORIZACAO NAO ANEXO
            UNION ALL
            SELECT 0 QT_NAO_ANEXO
                  ,1 QT_ANEXO_QUIMIO
                  ,0 QT_ANEXO_RADIO
                  ,0 QT_ANEXO_OPME
                  ,COUNT(TP_ANEXO) QT_TOTAL
                  ,CD_PTU_PEDIDO_AUTORIZACAO CD_PTU_PEDIDO_AUTORIZACAO
              FROM DBAPS.PTU_PEDIDO_AUTORIZACAO_ITEM
             WHERE TP_ANEXO = 1
               AND CD_PTU_PEDIDO_AUTORIZACAO = PCD_PTU_PEDIDO_ITEM
             GROUP BY CD_PTU_PEDIDO_AUTORIZACAO -- PEDIDO_AUTORIZACAO QUIMIOTERAPIA
            UNION ALL
            SELECT 0 QT_NAO_ANEXO
                  ,0 QT_ANEXO_QUIMIO
                  ,1 QT_ANEXO_RADIO
                  ,0 QT_ANEXO_OPME
                  ,COUNT(TP_ANEXO) QT_TOTAL
                  ,CD_PTU_PEDIDO_AUTORIZACAO CD_PTU_PEDIDO_AUTORIZACAO
              FROM DBAPS.PTU_PEDIDO_AUTORIZACAO_ITEM
             WHERE TP_ANEXO = 2
               AND CD_PTU_PEDIDO_AUTORIZACAO = PCD_PTU_PEDIDO_ITEM
             GROUP BY CD_PTU_PEDIDO_AUTORIZACAO -- PEDIDO_AUTORIZACAO RADIOTERAPIA
            UNION ALL
            SELECT 0 QT_NAO_ANEXO
                  ,0 QT_ANEXO_QUIMIO
                  ,0 QT_ANEXO_RADIO
                  ,1 QT_ANEXO_OPME
                  ,COUNT(TP_ANEXO) QT_TOTAL
                  ,CD_PTU_PEDIDO_AUTORIZACAO CD_PTU_PEDIDO_AUTORIZACAO
              FROM DBAPS.PTU_PEDIDO_AUTORIZACAO_ITEM
             WHERE TP_ANEXO = 3
               AND CD_PTU_PEDIDO_AUTORIZACAO = PCD_PTU_PEDIDO_ITEM
             GROUP BY CD_PTU_PEDIDO_AUTORIZACAO -- PEDIDO_AUTORIZACAO OPME
            );
  --* BUSCA OS DADOS DAS GUIAS (SPSADT, INTERNACAO, PRORROGACAO E ODONTOLOGIA (NAO IMPLEMENTADO)
  CURSOR cGuia(PCD_PTU_MENSAGEM_DESTINO IN NUMBER
              ,PCD_UNIMED_REQUISITANTE  IN VARCHAR2) IS
    SELECT NR_GUIA
          ,U.NM_SEGURADO
          ,CD_PTU_MENSAGEM_ORIGEM
          ,DT_VENCIMENTO
          ,SN_VALIDA_REST_CARENCIA
          ,CD_MOT_CANCELAMENTO_GUIA
          ,DS_OBSERVACAO
      FROM (SELECT DISTINCT *
              FROM DBAPS.GUIA G
             WHERE G.CD_PTU_MENSAGEM_DESTINO = PCD_PTU_MENSAGEM_DESTINO
               AND LPAD(CD_UNIMED_EXECUTORA, 4, '0') =
                   LPAD(PCD_UNIMED_REQUISITANTE, 4, '0')
               AND G.CD_MULTI_EMPRESA = DBAMV.PKG_MV2000.LE_EMPRESA
               AND g.SN_VALIDA_REST_CARENCIA = 'N'
            UNION ALL
            SELECT DISTINCT *
              FROM DBAPS.GUIA G
             WHERE G.CD_PTU_MENSAGEM_DESTINO = PCD_PTU_MENSAGEM_DESTINO
               AND LPAD(CD_UNIMED_EXECUTORA, 4, '0') =
                   LPAD(PCD_UNIMED_REQUISITANTE, 4, '0')
               AND G.CD_MULTI_EMPRESA = DBAMV.PKG_MV2000.LE_EMPRESA
               AND g.SN_VALIDA_REST_CARENCIA = 'S') GUIAS
          ,DBAPS.USUARIO U
     WHERE ROWNUM = 1
       AND GUIAS.CD_MATRICULA = U.CD_MATRICULA(+);
  --* CURSOR QUE RETORNA OS PROCEDIMENTOS DE UMA CONSULTA DO PTU ONLINE
  CURSOR cProcedimentoConsulta(P_CD_PROCEDIMENTO IN VARCHAR2) IS
    SELECT CD_PROCEDIMENTO
      FROM DBAPS.PTU_PROCEDIMENTO_CONSULTA
     WHERE CD_PROCEDIMENTO = P_CD_PROCEDIMENTO;
  --
  --* BUSCA PROCEDIMENTOS DA GUIA
  CURSOR cItGuia(P_NR_TRANSACAO_PRESTADORA IN NUMBER
                ,PCD_UNIMED_REQUISITANTE   IN VARCHAR2) IS
    SELECT IG.NR_GUIA
          ,IG.CD_ITGUIA
          ,IG.QT_SOLIC_PREST
          ,IG.QT_SOLICITADO
          ,IG.VL_PROCEDIMENTO
          ,IG.CD_VIA_ADMINISTRACAO
          ,IG.CD_PROCEDIMENTO
          ,IG.QT_FRANQUIA
          ,IG.QT_SOLICITADO_DIA
          ,IG.DT_PROVAVEL
          ,IG.CD_MATERIAL_FABRICANTE
          ,IG.NR_ORDEM_PREFERENCIA
          ,IG.NR_ANVISA
          ,Decode(IG.TP_STATUS, 0, 4, --AUD. MED
                  1, 4, --AUD. MED
                  2, 4, --AUD. MED
                  3, 1, --NEGADO
                  4, 2, --AUTORIZ
                  5, 1 --NEGADO
                  ) TP_STATUS
          ,IG.DS_MENSAGEM_ESPECIFICA
          ,SUBSTR(Nvl(DBAPS.FNC_AJUSTA_DADO_PTU('ANS', IG.DS_PROCEDIMENTO), DBAPS.FNC_AJUSTA_DADO_PTU('ANS', P.DS_PROCEDIMENTO)), 0, 80) DS_PROCEDIMENTO
          ,IG.NR_SQ_ITEM_PTU
          ,IG.TP_INDICADOR_ANEXO
          ,GP.TP_GRU_PRO
          ,NVL(IG.SN_PACOTE_PTU, P.SN_PACOTE) SN_PACOTE
          ,P.SN_GENERICO
          ,P.SN_PROCED_UNIVERSAL
          ,IG.CD_PROCEDIMENTO_AUTORIZADORWEB
          ,LPad(Nvl(IG.TP_TABELA_INTERCAMBIO, Decode(P.TP_TABELA, NULL, Decode(RU.DT_VIGENCIA, NULL, Decode(GP.TP_GRU_PRO, 'SP', 0, 'SD', 0, 'TE', 0, 'SH', 1, 'DI', 1, 'TX', 1, 'MT', 2, 'OP', 2, 'MD', 3, 0) /*DECODE TP_GRU_PRO */, 0) /*DECODE TP_TABELA */, P.TP_TABELA)),2,'0') TP_TABELA
          ,VAT.CD_TISS CD_VIA_ADMIN
          ,MUM.CD_PTU CD_UNIDADE_MEDIDA
          ,Decode((IG.QT_SOLIC_PREST * IG.VL_PROCEDIMENTO), 0, NULL, Round((IG.QT_SOLIC_PREST *
                         IG.VL_PROCEDIMENTO), 2)) VL_MONETARIO
          , --VL_MONETARIO
           Decode(IG.VL_PROCEDIMENTO, 0, NULL, Round(IG.VL_PROCEDIMENTO, 2)) VL_UNIT_SERVICO --VL_UNIT_SERVICO
          ,dbaps.fnc_tabela_tuss(IG.CD_PROCEDIMENTO) CD_TABELA
          ,IG.CD_SERVICO_PTU
      FROM DBAPS.ITGUIA                 IG
          ,DBAPS.PROCEDIMENTO           P
          ,DBAPS.GRUPO_PROCEDIMENTO     GP
          ,DBAPS.ROL_UNIMED             RU
          ,DBAPS.VIA_ADMINISTRACAO_TISS VAT
          ,DBAPS.MVS_UNIDADE_MEDIDA     MUM
          ,DBAPS.GUIA                   G
     WHERE IG.NR_GUIA = G.NR_GUIA(+)
       AND IG.CD_PROCEDIMENTO = P.CD_PROCEDIMENTO(+)
       AND IG.CD_VIA_ADMINISTRACAO = VAT.CD_VIA_ADMINISTRACAO_TISS(+)
       AND IG.CD_UNIDADE_MEDIDA = MUM.CD_TERMO(+)
       AND P.CD_GRUPO_PROCEDIMENTO = GP.CD_GRUPO_PROCEDIMENTO(+)
       AND P.CD_PROCEDIMENTO = RU.CD_PROCEDIMENTO(+)
       AND G.CD_PTU_MENSAGEM_DESTINO = P_NR_TRANSACAO_PRESTADORA
       AND LPAD(G.CD_UNIMED_SOLICITANTE, 4, '0') =
           LPAD(PCD_UNIMED_REQUISITANTE, 4, '0')
     ORDER BY IG.NR_SQ_ITEM_PTU ASC;
  --
  CURSOR cItGuiaAnexos(P_NR_TRANSACAO_PRESTADORA IN NUMBER
                      ,PCD_UNIMED_REQUISITANTE   IN VARCHAR2) IS
    SELECT IG.NR_GUIA
          ,IG.CD_ITGUIA
          ,DECODE(IG.TP_STATUS, 0, 4, --AUD. MED
                  1, 4, --AUD. MED
                  2, 4, --AUD. MED
                  3, 1, --NEGADO
                  4, 2, --AUTORIZ
                  5, 1 --NEGADO
                  ) TP_STATUS
      FROM DBAPS.ITGUIA IG
          ,DBAPS.GUIA   G
     WHERE IG.NR_GUIA = G.NR_GUIA
       AND G.CD_PTU_MENSAGEM_DESTINO = P_NR_TRANSACAO_PRESTADORA
       AND IG.TP_STATUS IN (0, 1, 2)
       AND LPAD(G.CD_UNIMED_SOLICITANTE, 4, '0') =
           LPAD(PCD_UNIMED_REQUISITANTE, 4, '0')
     ORDER BY IG.NR_SQ_ITEM_PTU ASC;
  --
  CURSOR cDadosPrestrador(PCD_PRESTADOR IN NUMBER) IS
    SELECT CD_AUTORIZADOR
      FROM DBAPS.PRESTADOR
     WHERE CD_PRESTADOR = PCD_PRESTADOR;
  --
  CURSOR cProcedimentoPacote(PCD_UNIMED_ORIGEM IN VARCHAR2, PCD_PACOTE_UNIMED_ORIGEM IN VARCHAR2) IS
    SELECT CD_PROCEDIMENTO
      FROM DBAPS.PACOTE_VIGENCIA
    WHERE CD_UNIMED_ORIGEM = LPad(PCD_UNIMED_ORIGEM,3,'0')
    AND CD_PACOTE_UNIMED_ORIGEM = PCD_PACOTE_UNIMED_ORIGEM
    AND (Trunc(DT_FIM_VIGENCIA) IS NULL OR Trunc(DT_FIM_VIGENCIA) <= Trunc(SYSDATE));
  --
  /********************************************************************************************
  * VARIAVEIS
  ********************************************************************************************/
  -- USADAS NOS CURSORES
  rPtuMensagem           cPtuMensagem%ROWTYPE;
  rDadosPrestrador       cDadosPrestrador%ROWTYPE;
  RItGuiaAnexos          cItGuiaAnexos%ROWTYPE;
  rWebserviceAtivo       cWebserviceAtivo%ROWTYPE;
  rPedidoAutorizacao     cPedidoAutorizacao%ROWTYPE;
  rPedidoAutorizacaoItem cPedidoAutorizacaoItem%ROWTYPE;
  rQtdAnexosPedido       cQtdAnexosPedido%ROWTYPE;
  rGuia                  cGuia%ROWTYPE;
  rProcedimentoConsulta  cProcedimentoConsulta%ROWTYPE;
  rProcedimentoPacote    cProcedimentoPacote%ROWTYPE;
  -- USADAS NO CABECALHO
  vCdGlosa                    VARCHAR2(10);
  vDsGlosa                    VARCHAR2(4000);
  vCdVersaoPtu                VARCHAR2(5);
  vTpTransSolicitacao         VARCHAR2(10);
  vTpCliente                  VARCHAR2(20);
  vCdUnimedPrestadora         NUMBER;
  vCdUnimedOrigemBeneficiario NUMBER;
  vCdMultiEmpresa             NUMBER;
  -- USADAS NAS VALIDACOES
  vTpStatus           VARCHAR2(1);
  vCdMatricula        VARCHAR2(100);
  vExcecao            VARCHAR2(4000);
  vExcecaoLinha       VARCHAR2(4000);
  vTipoAutorizacao    VARCHAR2(10);
  vSnAutoriza         VARCHAR2(1);
  vSnPedidoAutorizado VARCHAR2(1);
  -- USADAS NA AUTORIZA GUIA
  nCdEspecialidade         NUMBER(4);
  vSNProcedimentoConsulta  VARCHAR2(1);
  dDtSolicitacao           DATE;
  vTempProcStr             VARCHAR2(4000);
  vTpInternacao            VARCHAR2(1);
  vRetornoAutorizaGuia     VARCHAR2(20);
  vRetornoAutorizaAnexo    VARCHAR2(20);
  nTipoGuia                NUMBER;
  nQtDiasSolicitados       NUMBER;
  vNmBeneficiario          VARCHAR2(1000);
  vTpSexo                  VARCHAR2(10);
  vNrRG                    VARCHAR2(1000);
  vOrgaoExpeditor          VARCHAR2(1000);
  vNmConjuge               VARCHAR2(1000);
  vNmMae                   VARCHAR2(1000);
  vNmPai                   VARCHAR2(1000);
  dDtNascimento            DATE;
  vEndereco                VARCHAR2(1000);
  nNrEndereco              NUMBER;
  vComplemento             VARCHAR2(1000);
  vBairro                  VARCHAR2(1000);
  nCdCidade                NUMBER;
  vNrCEP                   VARCHAR2(1000);
  vNrTelefone              VARCHAR2(1000);
  vNrGuia                  VARCHAR2(1000);
  vNrGuiaTem               VARCHAR2(1000);
  vNrGuiaComplemento       VARCHAR2(4000);
  vDtValidadeCarteira      VARCHAR2(1000);
  vNmTitular               VARCHAR2(1000);
  vNrCpfBeneficiario       VARCHAR2(1000);
  vTpGuia                  VARCHAR2(1000);
  vTpAcomodacao            VARCHAR2(10);
  vNmPrestador             VARCHAR2(1000);
  vEspecialidade           VARCHAR2(1000);
  dDtVencimentoGuia        DATE;
  nCdPlano                 NUMBER;
  vDsPlano                 VARCHAR2(1000);
  vEmpresa                 VARCHAR2(1000);
  vDsMensagem              VARCHAR2(32000);
  nCdMedicoSolicitante     NUMBER;
  nCdPrestadorEndereco     NUMBER;
  nCodigoIndicadorAcidente NUMBER;
  nStatusSolicitacaoGuia   NUMBER;
  nCdPrestador             NUMBER;
  nCdPrestadorSolicitante  NUMBER;
  -- USADAS NOS ANEXOS DE QUIMIO
  vDsDiagCitHistQuimio          VARCHAR2(1000);
  vDsInfoRelevantesQuimio       VARCHAR2(1000);
  vDsPlanoTerapeuticoQuimio     VARCHAR2(1000);
  vDsQuimio                     VARCHAR2(1000);
  vNrAlturaQuimio               NUMBER;
  vNrPesoQuimio                 NUMBER;
  vNrSupCorporalQuimio          NUMBER;
  vDtDiagnosticoQuimio          DATE;
  vCdCid1Quimio                 VARCHAR2(1000);
  vCdCid2Quimio                 VARCHAR2(1000);
  vCdCid3Quimio                 VARCHAR2(1000);
  vCdCid4Quimio                 VARCHAR2(1000);
  vTpEstadiamentoQuimio         NUMBER;
  vTpFinalidadeQuimio           NUMBER;
  vTpEcogQuimio                 NUMBER;
  vTpQuimio                     NUMBER;
  vNrCiclosQuimio               NUMBER;
  vNrCicloAtualQuimio           NUMBER;
  vNrIntervaloCiclosQuimio      NUMBER;
  vDsCirurgiaQuimio             VARCHAR2(1000);
  vDtCirurgiaQuimio             DATE;
  vDsAreaIrradiadaQuimio        VARCHAR2(1000);
  vDtIrradiacaoQuimio           DATE;
  vNmProfSolicitanteQuimio      VARCHAR2(1000);
  vNrTelProfSolicitanteQuimio   NUMBER;
  vDsEmailProfSolicitanteQuimio VARCHAR2(1000);
  -- USADAS NOS ANEXOS DE RADIO
  vDsDiagCitHistRadio          VARCHAR2(1000);
  vDsInfoRelevantesRadio       VARCHAR2(1000);
  vDsRadio                     VARCHAR2(1000);
  vDtDiagnosticoRadio          DATE;
  vCdCid1Radio                 VARCHAR2(1000);
  vCdCid2Radio                 VARCHAR2(1000);
  vCdCid3Radio                 VARCHAR2(1000);
  vCdCid4Radio                 VARCHAR2(1000);
  vTpEstadiamentoRadio         NUMBER;
  vTpFinalidadeRadio           NUMBER;
  vTpEcogRadio                 NUMBER;
  vCdDiagImagemRadio           NUMBER;
  vQtCamposRadio               NUMBER;
  vQtDosesDiaRadio             NUMBER;
  vQtDosesTotalRadio           NUMBER;
  vQtDiasTratamentoRadio       NUMBER;
  vDtPrevistaRadio             DATE;
  vDsCirurgiaRadio             VARCHAR2(1000);
  vDtCirurgiaRadio             DATE;
  vDsQuimioterapiaRadio        VARCHAR2(1000);
  vDtQuimioterapiaRadio        DATE;
  vNmProfSolicitanteRadio      VARCHAR2(1000);
  vNrTelProfSolicitanteRadio   NUMBER;
  vDsEmailProfSolicitanteRadio VARCHAR2(1000);
  vTpCaraterSolicInter         VARCHAR2(2);
  -- USADAS NOS ANEXOS DE OPME
  vDsOpme                 VARCHAR2(1000);
  vDsJustificativaTecOpme VARCHAR2(1000);
  vDsMaterialSolicOpme    VARCHAR2(1000);
  -- AUXILIARES
  vCdProcedimento       VARCHAR2(4000);
  dDtSugeridaInternacao DATE;
  vSnAnexoQuimio        VARCHAR2(1);
  vSnAnexoOpme          VARCHAR2(1);
  vNrTpAnexoQuimio      NUMBER;
  vNrTpAnexoRadio       NUMBER;
  vNrTpAnexoOpme        NUMBER;
  -- USADAS NAS SEQUENCES
  nIdPtuMensagem             DBAPS.PTU_MENSAGEM.CD_PTU_MENSAGEM%TYPE;
  nCdPtuRespPedidoAut        NUMBER;
  nCdPtuRespPedidoAutItem    NUMBER;
  nCdPtuRespPedidoAutItemEsp NUMBER;
  nIdPtuMensagemLog          NUMBER;
  nCdAutorizador             NUMBER(12);
  nNrGuiaQuimio              NUMBER;
  nNrGuiaRadio               NUMBER;
  nNrGuiaOpme                NUMBER;
  nSeqItGuia                 NUMBER;
  --
  vCdProcedimentoPacote      VARCHAR2(12);
  TESTE VARCHAR2(4000);
  -- variaveis fixas
  P_VERSAO_PTU  VARCHAR2(100);
  P_VERSAO_TISS VARCHAR2(100);
  /********************************************************************************************
  * FUNCTION QUE INSERE UMA RESPOSTA PADRAO PARA ERROS NO CABECALHO OU CORPO DA MENSAGEM
  ********************************************************************************************/
  PROCEDURE INSERE_RESPOSTA_PADRAO(PCD_PTU_PEDIDO_RESP_AUTORIZ IN NUMBER
                                  ,PCD_PTU_PEDIDO_AUTORIZACAO  IN NUMBER
                                  ,P_DS_GLOSA_PADRAO           IN VARCHAR2
                                  ,P_STATUS_SOLICITACAO        IN NUMBER) IS
  BEGIN
    SELECT DBAPS.SEQ_PTU_MENSAGEM.NEXTVAL
      INTO nCdPtuRespPedidoAut
      FROM DUAL;
    INSERT INTO DBAPS.PTU_RESP_PEDIDO_AUT
      (CD_PTU_RESP_PEDIDO_AUT
      ,CD_PTU_MENSAGEM
      ,NR_TRANSACAO_PRESTADORA
      ,NR_TRANSACAO_ORIGEM_BENEF
      ,CD_UNIMED_EXECUTORA
      ,CD_UNIMED
      ,CD_IDENTIFICACAO
      ,NM_BENEFICIARIO
      ,DT_VALIDADE_AUTORIZACAO
      ,TP_AUTORIZACAO
      ,TP_ACOMODACAO
      ,CD_VERSAO_PTU
      ,TP_SEXO
      ,DT_NASCIMENTO
      ,DS_OBSERVACAO
      ,DS_MENSAGEM_ERRO)
    VALUES
      (nCdPtuRespPedidoAut --CD_PTU_RESP_PEDIDO_AUT
      ,PCD_PTU_PEDIDO_RESP_AUTORIZ --CD_PTU_MENSAGEM
      ,rPedidoAutorizacao.NR_TRANSACAO_PRESTADORA --NR_TRANSACAO_PRESTADORA
      ,NULL --NR_TRANSACAO_ORIGEM_BENEF
      ,rPedidoAutorizacao.CD_UNIMED_ATEND --CD_UNIMED_EXECUTORA
      ,rPedidoAutorizacao.CD_UNIMED_ORIGEM --CD_UNIMED
      ,rPedidoAutorizacao.CD_IDENTIFICACAO --CD_IDENTIFICACAO
      ,Nvl(SubStr(vNmBeneficiario, 1, 25), 'BENEFICIARIO') --NM_BENEFICIARIO
      ,NULL --DT_VALIDADE_AUTORIZACAO
      ,1 --TP_AUTORIZACAO 1 = Unimed 2 = WSD
      ,Nvl(vTpAcomodacao, 'C') --TP_ACOMODACAO
      ,Nvl(rPedidoAutorizacao.CD_VERSAO_PTU, P_VERSAO_PTU) --CD_VERSAO_PTU
      ,rPedidoAutorizacao.TP_SEXO --TP_SEXO
      ,NULL --DT_NASCIMENTO
      ,DECODE(P_DS_GLOSA_PADRAO, NULL, NULL, 'ERRO: ' || P_DS_GLOSA_PADRAO) --DS_OBSERVACAO
      ,P_DS_GLOSA_PADRAO);
    --
    FOR rPedidoAutorizacaoItem IN cPedidoAutorizacaoItem(PCD_PTU_PEDIDO_AUTORIZACAO, NULL) LOOP
      SELECT DBAPS.SEQ_PTU_MENSAGEM.NEXTVAL
        INTO nCdPtuRespPedidoAutItem
        FROM DUAL;

      INSERT INTO DBAPS.PTU_RESP_PEDIDO_AUT_ITEM
        (CD_PTU_RESP_PEDIDO_AUT_ITEM
        ,CD_PTU_RESP_PEDIDO_AUT
        ,TP_TABELA
        ,CD_SERVICO
        ,DS_SERVICO
        ,QT_AUTORIZADA
        ,TP_INDICACAO_AUTORIZACAO
        ,DS_MENSAGEM_ESPEC
        ,SQ_ITEM)
      VALUES
        (nCdPtuRespPedidoAutItem --CD_PTU_RESP_PEDIDO_AUT_ITEM
        ,nCdPtuRespPedidoAut --CD_PTU_RESP_PEDIDO_AUT
        ,rPedidoAutorizacaoItem.TP_TABELA --TP_TABELA
        ,rPedidoAutorizacaoItem.CD_SERVICO --CD_SERVICO
        ,SUBSTR(DBAPS.FNC_AJUSTA_DADO_PTU('ANS', Nvl(rPedidoAutorizacaoItem.DS_SERVICO, (SELECT DS_PROCEDIMENTO
                                                   FROM DBAPS.PROCEDIMENTO
                                                  WHERE CD_PROCEDIMENTO =
                                                        rPedidoAutorizacaoItem.CD_SERVICO))), 0, 80) --DS_SERVICO
        ,0 --QT_AUTORIZADA
        ,Nvl(P_STATUS_SOLICITACAO, 4) --TP_INDICACAO_AUTORIZACAO (em auditoria)
        ,SubStr(TRIM(regexp_replace(P_DS_GLOSA_PADRAO, '[;]|[;]|[^a-zA-Z0-9 ]+')), 1, 500) --DS_MENSAGEM_ESPEC
        ,rPedidoAutorizacaoItem.SQ_ITEM
      );
      --
      /* MENSAGENS ESPECIFICAS - OBRIGATORIO QUANDO NEGADO */
      SELECT DBAPS.SEQ_PTU_MENSAGEM.NEXTVAL
        INTO nCdPtuRespPedidoAutItemEsp
        FROM DUAL;
      INSERT INTO DBAPS.PTU_RESP_PED_AUT_MENSAGEM_ESP
        (CD_RESP_PED_AUT_MENSAGEM_ESP
        ,CD_PTU_RESP_PEDIDO_AUT_ITEM
        ,CD_PTU_MENSAGEM_ESPECIFICA)
      VALUES
        (nCdPtuRespPedidoAutItemEsp --CD_RESP_PED_AUT_MENSAGEM_ESP
        ,nCdPtuRespPedidoAutItem --CD_PTU_RESP_PEDIDO_AUT_ITEM
        ,2004 -- CD_PTU_MENSAGEM_ESPECIFICA Cadastro beneficiario com problemas
         );
    END LOOP;
  END; --PROCEDURE INSERE_RESPOSTA_PADRAO
  --
  /********************************************************************************************
  * FUNCTION QUE GRAVA A MENSAGEM DE RESPOSTA - PEDIDO DE AUTORIZACAO
  ********************************************************************************************/
  FUNCTION gravarRespostaPedidoAut(P_ID_PTU_AUTORIZACAO     IN NUMBER
                                  ,P_CD_GLOSA               IN VARCHAR2
                                  ,P_DS_GLOSA               IN VARCHAR2
                                  ,P_CD_MULTI_EMPRESA       IN NUMBER
                                  ,P_CD_VERSAO_PTU          IN VARCHAR2
                                  ,P_CD_TRANSACAO           IN VARCHAR2
                                  ,P_TP_CLIENTE             IN VARCHAR2
                                  ,P_CD_UNIMED_PRESTADORA   IN NUMBER
                                  ,P_CD_UNIMED_ORIGEM_BENEF IN NUMBER
                                  ,P_TP_TRANSACAO           IN VARCHAR2)
    RETURN NUMBER IS
  BEGIN
    -- CHAMA CURSOR QUE RETORNA OS DADOS DA SOLICITACAO DE PEDIDO DE AUTORIZACAO.
    OPEN cPedidoAutorizacao(P_ID_PTU_AUTORIZACAO, P_CD_UNIMED_PRESTADORA);
    FETCH cPedidoAutorizacao
      INTO rPedidoAutorizacao;
    CLOSE cPedidoAutorizacao;
    --
    -- CHAMA CURSOR QUE RETORNA OS DADOS DA SOLICITACAO DE PEDIDO DE AUTORIZACAO - ITEM.
    OPEN cQtdAnexosPedido(rPedidoAutorizacao.CD_PTU_PEDIDO_AUTORIZACAO);
    FETCH cQtdAnexosPedido
      INTO rQtdAnexosPedido;
    CLOSE cQtdAnexosPedido;
    --
    -- VERIFICAR SE JA EXISTE ALGUMA GUIA COM ESSA TRANSACAO PARA NAO SALVAR A GUIA NOVAMENTE.
    DBAPS.PRC_INSERE_DEBUG_LOG(P_ID_PTU_AUTORIZACAO, '2.0) Procurando guia com parametros nr. trans. prestadora: ' ||
                                rPedidoAutorizacao.NR_TRANSACAO_PRESTADORA ||
                                '; Uni. Prestadora: ' ||
                                P_CD_UNIMED_PRESTADORA, 'PTU0600');
    OPEN cGuia(rPedidoAutorizacao.NR_TRANSACAO_PRESTADORA, P_CD_UNIMED_PRESTADORA);
    FETCH cGuia
      INTO rGuia;
    CLOSE cGuia;
    --
    IF rGuia.SN_VALIDA_REST_CARENCIA IS NOT NULL THEN
      nIdPtuMensagem    := rGuia.CD_PTU_MENSAGEM_ORIGEM;
      dDtVencimentoGuia := rGuia.DT_VENCIMENTO;
      DBAPS.PRC_INSERE_DEBUG_LOG(P_ID_PTU_AUTORIZACAO, '2) IF rGuia.NR_GUIA IS NOT NULL; nIdPtuMensagem: ' ||
                                  nIdPtuMensagem ||
                                  '; rGuia.NR_GUIA: ' ||
                                  rGuia.NR_GUIA ||
                                  '; P_CD_UNIMED_PRESTADORA: ' ||
                                  P_CD_UNIMED_PRESTADORA, 'PTU0600');
    ELSE
      --
      -- INSERE NA PTU MENSAGEM
      nIdPtuMensagem := DBAPS.FNC_PTU_INSERE_CABECALHO(P_ID_PTU_MENSAGEM --P_ID_MENSAGEM_ENVIO
                                                      , '00501' --P_CD_TRANSACAO
                                                      , P_TP_CLIENTE --P_TP_CLIENTE
                                                      , P_CD_UNIMED_ORIGEM_BENEF --P_CD_UNIMED_ORIGEM_BENEF
                                                      , P_CD_VERSAO_PTU --P_CD_VERSAO
                                                      , P_CD_GLOSA --P_CD_GLOSA
                                                      , P_DS_GLOSA --P_DS_GLOSA
                                                      , P_CD_UNIMED_PRESTADORA --P_CD_UNIMED_PRESTADORA
                                                      , NULL --P_DT_TRANSACAO
                                                      , P_CD_UNIMED_ORIGEM_BENEF --P_CD_UNIMED_ORIGEM_BENEF
                                                      , P_CD_UNIMED_PRESTADORA --P_CD_UNIMED_PRESTADORA
                                                       );
      DBAPS.PRC_INSERE_DEBUG_LOG(P_ID_PTU_AUTORIZACAO, '2) nIdPtuMensagem: ' ||
                                  nIdPtuMensagem, 'PTU0600');
      DBAPS.PRC_INSERE_DEBUG_LOG(P_ID_PTU_AUTORIZACAO, '3) P_CD_GLOSA: ' ||
                                  P_CD_GLOSA ||
                                  '; P_DS_GLOSA: ' ||
                                  P_DS_GLOSA, 'PTU0600');
      --
      --* GLOSA DO CABECALHO DA MENSAGEM (**CABECALHO**)
      IF P_CD_GLOSA IS NULL THEN
        --
        -- SE NAO DEU ERRO NO CABECALHO, VERIFICAR ERROS DO CORPO DA MENSAGEM
        -- VERIFICA O CODIGO DO PROCEDIMENTO
        IF (rQtdAnexosPedido.QT_TOTAL = 1) THEN
          --
          --
          OPEN cPedidoAutorizacaoItem(rPedidoAutorizacao.CD_PTU_PEDIDO_AUTORIZACAO, NULL);
          FETCH cPedidoAutorizacaoItem
            INTO rPedidoAutorizacaoItem;
          CLOSE cPedidoAutorizacaoItem;
          --
          -- CHAMA CURSOR QUE RETORNA OS DADOS DOS PROCEDIMENTOS DE CONSULTA
          OPEN cProcedimentoConsulta(rPedidoAutorizacaoItem.CD_SERVICO);
          FETCH cProcedimentoConsulta
            INTO rProcedimentoConsulta;
          --
          IF (cProcedimentoConsulta%NOTFOUND) THEN
            vSNProcedimentoConsulta := 'N';
          ELSE
            vSNProcedimentoConsulta := 'S';
          END IF;
          CLOSE cProcedimentoConsulta;
        END IF; -- END IF - VERIFICA O CODIGO DO PROCEDIMENTO
        --
        --COMPLEMENTO DE INTERNACAO (PROPRROGACAO DE INTERNACAO DO PTU) - 08-01-2019
        FOR rProcedimento IN cPedidoAutorizacaoItem(rPedidoAutorizacao.CD_PTU_PEDIDO_AUTORIZACAO, NULL) LOOP
          --DI=> DIARIAS
          IF rProcedimento.TP_GRU_PRO IN ('DI') THEN
            vTipoAutorizacao := 'INT';
            BEGIN
              SELECT CD_TIPO_ATENDIMENTO
                INTO nTipoGuia
                FROM DBAPS.TIPO_ATENDIMENTO
               WHERE TP_GUIA = 'I'
                 AND ROWNUM = 1;
            EXCEPTION
              WHEN OTHERS THEN
                nTipoGuia := NULL;
                vCdGlosa  := '4001';
                vDsGlosa  := 'TIPO DE GUIA INTERNACAO NAO CADASTRADO.' ||
                             ' ENTRE EM CONTATO COM A OPERADORA';
            END;
            EXIT; --SAIR DO LOOP POIS ACHOIU UMA INTERNACAO
          END IF;
          --
        END LOOP;
        --
        -- VERIFICA O TIPO DE AUTORIZACAO SOLICITADA
        IF vTipoAutorizacao IS NULL THEN
        --
          IF (rPedidoAutorizacao.TP_INTERNACAO IS NOT NULL) THEN
            vTipoAutorizacao := 'INT';
            --
            BEGIN
              SELECT CD_TIPO_ATENDIMENTO
                INTO nTipoGuia
                FROM DBAPS.TIPO_ATENDIMENTO
               WHERE TP_GUIA = 'I'
                 AND ROWNUM = 1;
            EXCEPTION
              WHEN OTHERS THEN
                nTipoGuia := NULL;
                vCdGlosa  := '4001';
                vDsGlosa  := 'TIPO DE GUIA INTERNACAO NAO CADASTRADO.' ||
                             ' ENTRE EM CONTATO COM A OPERADORA';
            END;
            --
          ELSIF (rQtdAnexosPedido.QT_TOTAL = 1)
                AND (vSNProcedimentoConsulta = 'S')
                AND rPedidoAutorizacaoItem.TP_ANEXO = 9 THEN
            --
            vTipoAutorizacao := 'CONS';
            BEGIN
              SELECT CD_TIPO_ATENDIMENTO
                INTO nTipoGuia
                FROM DBAPS.TIPO_ATENDIMENTO
               WHERE TP_GUIA = 'C'
                 AND ROWNUM = 1;
            EXCEPTION
              WHEN OTHERS THEN
                nTipoGuia := NULL;
                vCdGlosa  := '4001';
                vDsGlosa  := 'TIPO DE GUIA CONSULTA NAO CADASTRADO.' ||
                             ' ENTRE EM CONTATO COM A OPERADORA';
            END;
            --
          ELSE
            --
            /* ANTES DE ATRIBUIR SADT - VEJA SE TEM ANEXO - SE TIVER O TIPO SERA O DO ANEXO */
            IF (rQtdAnexosPedido.QT_ANEXO = 1) THEN
              BEGIN
                SELECT CD_TIPO_ATENDIMENTO
                  INTO nTipoGuia
                  FROM DBAPS.TIPO_ATENDIMENTO
                 WHERE TP_GUIA =
                       Decode(rQtdAnexosPedido.QT_ANEXO_QUIMIO, 1, 'Q', Decode(rQtdAnexosPedido.QT_ANEXO_RADIO, 1, 'R', 'O'))
                   AND ROWNUM = 1;
              EXCEPTION
                WHEN OTHERS THEN
                  nTipoGuia := NULL;
                  vCdGlosa  := '4001';
                  vDsGlosa  := 'TIPO DE ANEXO NAO CADASTRADO.' ||
                               ' ENTRE EM CONTATO COM A OPERADORA';
              END;
            ELSE
              vTipoAutorizacao := 'SADT';
              BEGIN
                IF nTipoGuia IS NULL THEN
                  SELECT CD_TIPO_ATENDIMENTO
                    INTO nTipoGuia
                    FROM DBAPS.TIPO_ATENDIMENTO
                   WHERE TP_GUIA = 'S'
                     AND ROWNUM = 1;
                END IF;
              EXCEPTION
                WHEN OTHERS THEN
                  nTipoGuia := NULL;
                  vCdGlosa  := '4001';
                  vDsGlosa  := 'TIPO DE GUIA SP/SADT NAO CADASTRADO.' ||
                               ' ENTRE EM CONTATO COM A OPERADORA';
              END;
            END IF; /*ENDIF rQtdProcediGuiaComplemento.QT_ANEXO = 1 */
          END IF; -- END IF - VERIFICA O TIPO DE AUTORIZACAO SOLICITADA
        END IF; --vTipoAutorizacao IS NULL
        /*
        * CABECALHO DA MENSAGEM SEM GLOSA
        */
        IF P_CD_GLOSA IS NULL THEN
          -- CHAMA CURSOR QUE RETORNA A CHAVE DO WEBSERVICE NA TABELA MVS_CONFIGURACAO.
          OPEN cWebserviceAtivo(P_CD_MULTI_EMPRESA);
          FETCH cWebserviceAtivo
            INTO rWebserviceAtivo;
          CLOSE cWebserviceAtivo;
          --
          -- VALIDA SE WEBSERVICE ESTA ATIVO
          IF rWebserviceAtivo.VALOR = 'N'
             AND P_CD_GLOSA IS NULL THEN
            vCdGlosa  := '4001';
            vDsGlosa  := 'WEB SERVICE PTU PEDIDO DE AUTORIZACAO NAO ESTA ATIVO - ENTRE EM CONTATO COM A OPERADORA';
            vTpStatus := '3';
          ELSE
            vTpStatus := '1';
          END IF; -- END IF - VALIDA SE WEBSERVICE ESTA ATIVO
          -- DATA SOLICITADA
          vNmPrestador            := rPedidoAutorizacao.NM_PRESTADOR;
          nCdPrestador            := rPedidoAutorizacao.CD_PRESTADOR;
          nCdPrestadorSolicitante := rPedidoAutorizacao.CD_PRESTADOR_REQUISITANTE;
          dDtSugeridaInternacao   := rPedidoAutorizacao.DT_ATENDIMENTO;
          dDtSolicitacao          := TRUNC(SYSDATE);
          --
          nCdAutorizador := 0; -- AUTORIZADOR PADRAO
          IF Nvl(dbaps.fnc_mvs_retorna_valor_config('PTU_PREST_UTILIZA_AUTORIZADOR', P_CD_MULTI_EMPRESA), 'N') = 'S' THEN
            --
            OPEN cDadosPrestrador(Nvl(To_Number(rPedidoAutorizacao.CD_PRESTADOR_UNIMED),To_Number(rPedidoAutorizacao.CD_UNIMED_ATEND)));
            FETCH cDadosPrestrador
              INTO rDadosPrestrador;
            --
            IF cDadosPrestrador%FOUND THEN
              nCdAutorizador := rDadosPrestrador.cd_autorizador;
            END IF;
            CLOSE cDadosPrestrador;
            --
          END IF;
          --
          vCdMatricula := rPedidoAutorizacao.CD_MATRICULA;
          -- VALIDANDO NUMERO DA CARTEIRA DO BENEFICIARIO (IDENTIFICADOR DO BENEFICIARIO)
          IF vCdGlosa IS NULL THEN
            IF vCdMatricula = -1
               AND vCdGlosa IS NULL THEN
              vCdGlosa := '4001';
              vDsGlosa := 'CARTEIRA DO BENEFICIARIO NAO ENCONTRADA - ENTRE EM CONTATO COM A OPERADORA';
            END IF;
          END IF; -- END IF - VALIDANDO NUMERO DA CARTEIRA DO BENEFICIARIO (IDENTIFICADOR DO BENEFICIARIO)
          --
          -- VALIDA A VERSAO DO TISS
          IF rPedidoAutorizacao.DS_VERSAO_TISS IS NOT NULL
             AND
             rPedidoAutorizacao.DS_VERSAO_TISS NOT IN
             ('3.05.01', '3.05.00', '3.04.01', '3.04.00', '3.03.03', '3.03.02', '3.03.01', '3.03.00', '3.02.02', '3.02.01', '3.02.00', '3.01.00', '2.02.03', '2.02.02', '2.02.01', '2.01.03')
             AND vCdGlosa IS NULL THEN
            vCdGlosa := '4013';
            vDsGlosa := 'VERSAO TISS INVALIDA. APENAS AS VERSOES 3.05.01, 3.05.00, 3.04.01, 3.04.00, 3.03.03, 3.03.02, 3.03.01, 3.03.00, 3.02.02, 3.02.01, 3.02.00 SAO ACEITAS';
          END IF; -- END IF - VALIDA A VERSAO DO TISS
          --
          -- VALIDA ESPECIALIDADE MEDICA
          BEGIN
            nCdEspecialidade := 0;
            nCdEspecialidade := rPedidoAutorizacao.CD_ESPECIALIDADE_MEDICA;
          EXCEPTION
            WHEN OTHERS THEN
              vCdGlosa := '4001';
              vDsGlosa := 'ESPECIALIDADE MEDICA INFORMADA ' ||
                          rPedidoAutorizacao.CD_ESPECIALIDADE_MEDICA ||
                          ' NAO POSSUI DE/PARA PARA O PTU NO CADASTRADO.- ENTRE EM CONTATO COM A OPERADORA';
          END;
          --
          -- VALIDA O CARATER DO ATENDIMENTO
          vTpCaraterSolicInter := rPedidoAutorizacao.SN_URGENCIA_EMERGENCIA;
          --VALIDA SE PROCEDIMENTOS EXISTEM NA BASE
          IF vCdGlosa IS NULL THEN
            FOR rProcedimentoExiste IN cPedidoAutorizacaoItem(rPedidoAutorizacao.CD_PTU_PEDIDO_AUTORIZACAO, NULL) LOOP
              IF rProcedimentoExiste.TP_TABELA <> '98' AND rProcedimentoExiste.CD_PROCEDIMENTO IS NULL THEN --TP_TABELA = 98 (PACOTE)
                vCdGlosa := '4001';
                vDsGlosa := 'PROCEDIMENTO ' ||rProcedimentoExiste.CD_SERVICO ||
                            ' NAO INFORMADO (VAZIO)';
              END IF;
            END LOOP;
          END IF;
          --
          /* VALIDA PROCEDIMENTOS EM DUPLICIDADE (AL�M DO C�DIGO DO PROCEDIMENTO, TIPO DE TABELA TAMB�M,
             POIS H� CASOS QUE SER� POSS�VEL MANDAR DOIS PROCEDIMENTOS IGUAIS, UM COMO PROCEDIMENTO NORMAL E OUTRO COMO PACOTE)*/
          IF vCdGlosa IS NULL THEN
            vTempProcStr := '*';
            FOR rProcedimento IN cPedidoAutorizacaoItem(rPedidoAutorizacao.CD_PTU_PEDIDO_AUTORIZACAO, NULL) LOOP
              IF INSTR(vTempProcStr, rProcedimento.CD_SERVICO) > 0 AND INSTR(vTempProcStr, rProcedimento.TP_TABELA) > 0
                 AND rProcedimento.TP_TABELA NOT IN (3)
                 AND rProcedimento.TP_ANEXO NOT IN (1)
                 AND rProcedimento.SN_PROCED_UNIVERSAL = 'N' THEN
                vCdGlosa := '4001';
                vDsGlosa := 'PROCEDIMENTO ' || rProcedimento.CD_SERVICO ||
                            ' INFORMANDO EM DUPLICIDADE';
              ELSE
                vTempProcStr := vTempProcStr || '*' ||
                                rProcedimento.CD_SERVICO || '*' ||
                                rProcedimento.TP_TABELA;
              END IF;
            END LOOP;
          END IF; -- END IF - VALIDA PROCEDIMENTOS EM DUPLICIDADE
          --
          vTpSexo := rPedidoAutorizacao.TP_SEXO_SOUL;
          ---
          /**********************************************
          *** CONVERTENDO DE/PARAS SOUL/PTU
          *********************************************/
          /**
          * VALIDACOES PARA INTERNACAO
          */
          IF (vTipoAutorizacao = 'INT')
             AND vCdGlosa IS NULL THEN
            -- QUANTIDADE DE DIAS SOLICITADOS PARA INTERNACAO (CAMPO NAO INFORMADO NO PTU ONLINE)
            nQtDiasSolicitados := 1;
            -- DATA SUGERIDA PARA INTERNACAO
            BEGIN
              dDtSugeridaInternacao := rPedidoAutorizacao.DT_SUGERIDA_INTERNACAO;
            EXCEPTION
              WHEN OTHERS THEN
                dDtSugeridaInternacao := NULL;
            END;
          END IF; -- END IF - VALIDACOES PARA INTERNACAO
          --
          /* BENEFICIARIO DESLIGADO - PRECISA SALVAR GUIA NO SOUL PARA PODER PEDIR INSISTENCIA DEPOIS
          IF vCdGlosa IS NULL THEN
            IF NVL(DBAPS.FN_SITUACAO_USUARIO(vCdMatricula, SYSDATE, 'S'), 'N') = 'N' THEN
              vCdGlosa := '2004';
              vDsGlosa := 'CADASTRO BENEFICIARIO COM PROBLEMAS';
            END IF;
          END IF;
          */
          /**
          * GLOSA NO CORPO DA MENSAGEM (**PARTE 1**)
          */
          IF vCdGlosa IS NOT NULL THEN
            INSERE_RESPOSTA_PADRAO(nIdPtuMensagem, rPedidoAutorizacao.CD_PTU_PEDIDO_AUTORIZACAO, vDsGlosa, 1);
          ELSE
            /********************************************************************************************
            * =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
            *     >>>>>>>>>>>>>>>> QUIMIOTERAPIA <<<<<<<<<<<<<<<<<<<<<<<<<<
            *-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
            ********************************************************************************************/
            -- DIAGNOSTICO CITOLOGICO E HISTOLOGICO
            BEGIN
              IF (rPedidoAutorizacao.DS_DIAG_CIT_HIST_QUIMIO IS NOT NULL) THEN
                vDsDiagCitHistQuimio := rPedidoAutorizacao.DS_DIAG_CIT_HIST_QUIMIO;
              END IF;
            EXCEPTION
              WHEN OTHERS THEN
                vDsDiagCitHistQuimio := NULL;
            END;
            -- INFORMACOES RELEVANTES
            BEGIN
              IF (rPedidoAutorizacao.DS_INFO_RELEVANTES_QUIMIO IS NOT NULL) THEN
                vDsInfoRelevantesQuimio := rPedidoAutorizacao.DS_INFO_RELEVANTES_QUIMIO;
              END IF;
            EXCEPTION
              WHEN OTHERS THEN
                vDsInfoRelevantesQuimio := NULL;
            END;
            -- PLANO TERAPEUTICO
            BEGIN
              IF (rPedidoAutorizacao.DS_PLANO_TERAPEUTICO IS NOT NULL) THEN
                vDsPlanoTerapeuticoQuimio := rPedidoAutorizacao.DS_PLANO_TERAPEUTICO;
              END IF;
            EXCEPTION
              WHEN OTHERS THEN
                vDsPlanoTerapeuticoQuimio := NULL;
            END;
            -- DESCRICAO DO TRATAMENTO
            BEGIN
              IF (rPedidoAutorizacao.DS_QUIMIO IS NOT NULL) THEN
                vDsQuimio := rPedidoAutorizacao.DS_QUIMIO;
              END IF;
            EXCEPTION
              WHEN OTHERS THEN
                vDsQuimio := NULL;
            END;
            -- DADOS DO BENEFICIARIO (ALTURA, PESO E SUPERFICIE CORPORAL)
            BEGIN
              -- ALTURA
              IF (rPedidoAutorizacao.NR_ALTURA_BENEF_QUIMIO IS NOT NULL) THEN
                vNrAlturaQuimio := rPedidoAutorizacao.NR_ALTURA_BENEF_QUIMIO;
              END IF;
              -- PESO
              IF (rPedidoAutorizacao.NR_PESO_BENEF_QUIMIO IS NOT NULL) THEN
                vNrPesoQuimio := rPedidoAutorizacao.NR_PESO_BENEF_QUIMIO;
              END IF;
              -- SUPERFICIE CORPORAL
              IF (rPedidoAutorizacao.NR_SUP_CORP_BENEF_QUIMIO IS NOT NULL) THEN
                vNrSupCorporalQuimio := rPedidoAutorizacao.NR_SUP_CORP_BENEF_QUIMIO;
              END IF;
            EXCEPTION
              WHEN OTHERS THEN
                vNrAlturaQuimio      := NULL;
                vNrPesoQuimio        := NULL;
                vNrSupCorporalQuimio := NULL;
            END;
            -- DATA DO DIAGNOSTICO
            BEGIN
              IF (rPedidoAutorizacao.DT_DIAGNOSTICO_QUIMIO IS NOT NULL) THEN
                vDtDiagnosticoQuimio := rPedidoAutorizacao.DT_DIAGNOSTICO_QUIMIO;
              END IF;
            EXCEPTION
              WHEN OTHERS THEN
                vDtDiagnosticoQuimio := SYSDATE;
            END;
            -- CIDS
            BEGIN
              -- CID PRINCIPAL
              IF (rPedidoAutorizacao.CD_CID_1_QUIMIO IS NOT NULL) THEN
                vCdCid1Quimio := rPedidoAutorizacao.CD_CID_1_QUIMIO;
              END IF;
              -- CID 2
              IF (rPedidoAutorizacao.CD_CID_2_QUIMIO IS NOT NULL) THEN
                vCdCid2Quimio := rPedidoAutorizacao.CD_CID_2_QUIMIO;
              END IF;
              -- CID 3
              IF (rPedidoAutorizacao.CD_CID_3_QUIMIO IS NOT NULL) THEN
                vCdCid3Quimio := rPedidoAutorizacao.CD_CID_3_QUIMIO;
              END IF;
              -- CID 4
              IF (rPedidoAutorizacao.CD_CID_4_QUIMIO IS NOT NULL) THEN
                vCdCid4Quimio := rPedidoAutorizacao.CD_CID_4_QUIMIO;
              END IF;
            EXCEPTION
              WHEN OTHERS THEN
                vCdCid1Quimio := NULL;
                vCdCid2Quimio := NULL;
                vCdCid3Quimio := NULL;
                vCdCid4Quimio := NULL;
            END;
            -- ESTADIAMENTO
            BEGIN
              IF (rPedidoAutorizacao.TP_ESTADIAMENTO_TUMOR_QUIMIO IS NOT NULL) THEN
                vTpEstadiamentoQuimio := rPedidoAutorizacao.TP_ESTADIAMENTO_TUMOR_QUIMIO;
              END IF;
            EXCEPTION
              WHEN OTHERS THEN
                vTpEstadiamentoQuimio := NULL;
            END;
            -- FINALIDADE
            BEGIN
              IF (rPedidoAutorizacao.TP_FINALIDADE_QUIMIO IS NOT NULL) THEN
                vTpFinalidadeQuimio := rPedidoAutorizacao.TP_FINALIDADE_QUIMIO;
              END IF;
            EXCEPTION
              WHEN OTHERS THEN
                vTpFinalidadeQuimio := NULL;
            END;
            -- ECOG
            BEGIN
              IF (rPedidoAutorizacao.TP_ECOG_QUIMIO IS NOT NULL) THEN
                vTpEcogQuimio := rPedidoAutorizacao.TP_ECOG_QUIMIO;
              END IF;
            EXCEPTION
              WHEN OTHERS THEN
                vTpEcogQuimio := NULL;
            END;
            -- TIPO DE QUIMIOTERAPIA
            BEGIN
              IF (rPedidoAutorizacao.TP_QUIMIO IS NOT NULL) THEN
                vTpQuimio := rPedidoAutorizacao.TP_QUIMIO;
              END IF;
            EXCEPTION
              WHEN OTHERS THEN
                vTpQuimio := NULL;
            END;
            -- DADOS DOS CICLOS (NUMERO DE CICLOS, CICLO ATUAL E INTERVALO)
            BEGIN
              -- NUMERO DE CICLOS
              IF (rPedidoAutorizacao.NR_CICLOS IS NOT NULL) THEN
                vNrCiclosQuimio := rPedidoAutorizacao.NR_CICLOS;
              END IF;
              -- CICLO ATUAL
              IF (rPedidoAutorizacao.NR_CICLO_ATUAL IS NOT NULL) THEN
                vNrCicloAtualQuimio := rPedidoAutorizacao.NR_CICLO_ATUAL;
              END IF;
              -- INTERVALO ENTRE CICLOS
              IF (rPedidoAutorizacao.NR_INTERVALO_CICLOS IS NOT NULL) THEN
                vNrIntervaloCiclosQuimio := rPedidoAutorizacao.NR_INTERVALO_CICLOS;
              END IF;
            EXCEPTION
              WHEN OTHERS THEN
                vNrCiclosQuimio          := NULL;
                vNrCicloAtualQuimio      := NULL;
                vNrIntervaloCiclosQuimio := NULL;
            END;
            -- TRATAMENTOS ANTERIORES (DESCRICAO DA CIRURGIA, DATA DA CIRURGIA, AREA IRRADIADA E DATA DA IRRADIACAO)
            BEGIN
              -- DESCRICAO DA CIRURGIA
              IF (rPedidoAutorizacao.DS_CIRURGIA_QUIMIO IS NOT NULL) THEN
                vDsCirurgiaQuimio := rPedidoAutorizacao.DS_CIRURGIA_QUIMIO;
              END IF;
              -- DATA DA CIRURGIA
              IF (rPedidoAutorizacao.DT_CIRURGIA_QUIMIO IS NOT NULL) THEN
                vDtCirurgiaQuimio := rPedidoAutorizacao.DT_CIRURGIA_QUIMIO;
              END IF;
              -- AREA IRRADIADA
              IF (rPedidoAutorizacao.DS_AREA_IRRADIADA IS NOT NULL) THEN
                vDsAreaIrradiadaQuimio := rPedidoAutorizacao.DS_AREA_IRRADIADA;
              END IF;
              -- DATA DA IRRADIACAO
              IF (rPedidoAutorizacao.DT_IRRADIACAO IS NOT NULL) THEN
                vDtIrradiacaoQuimio := rPedidoAutorizacao.DT_IRRADIACAO;
              END IF;
            EXCEPTION
              WHEN OTHERS THEN
                vDsCirurgiaQuimio      := NULL;
                vDtCirurgiaQuimio      := SYSDATE;
                vDsAreaIrradiadaQuimio := NULL;
                vDtIrradiacaoQuimio    := SYSDATE;
            END;
            -- PROFISSIONAL SOLICITANTE (NOME, NUMERO DE TELEFONE E E-MAIL)
            BEGIN
              -- NOME
              IF (rPedidoAutorizacao.NM_PROFISSIONAL_QUIMIO IS NOT NULL) THEN
                vNmProfSolicitanteQuimio := rPedidoAutorizacao.NM_PROFISSIONAL_QUIMIO;
              END IF;
              -- NUMERO DE TELEFONE
              IF (rPedidoAutorizacao.NR_TEL_PROFISSIONAL_QUIMIO IS NOT NULL) THEN
                vNrTelProfSolicitanteQuimio := rPedidoAutorizacao.NR_TEL_PROFISSIONAL_QUIMIO;
              END IF;
              -- E-MAIL
              IF (rPedidoAutorizacao.DS_EMAIL_PROFISSIONAL_QUIMIO IS NOT NULL) THEN
                vDsEmailProfSolicitanteQuimio := rPedidoAutorizacao.DS_EMAIL_PROFISSIONAL_QUIMIO;
              END IF;
            EXCEPTION
              WHEN OTHERS THEN
                vNmProfSolicitanteQuimio      := NULL;
                vNrTelProfSolicitanteQuimio   := NULL;
                vDsEmailProfSolicitanteQuimio := NULL;
            END;
            -- INDICA A EXISTENCIA DE UM ANEXO DE QUIMIOTERAPIA.
            IF (vNrCiclosQuimio IS NOT NULL)
               AND (vNrCicloAtualQuimio IS NOT NULL)
               AND (vNrIntervaloCiclosQuimio IS NOT NULL) THEN
              vSnAnexoQuimio := 'S';
            ELSE
              vSnAnexoQuimio := 'N';
            END IF; -- END IF - INDICA A EXISTENCIA DE UM ANEXO DE QUIMIOTERAPIA.
            /********************************************************************************************
            * =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
            *     >>>>>>>>>>>>>>>> RADIOTERAPIA <<<<<<<<<<<<<<<<<<<<<<<<<<
            *-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
            ********************************************************************************************/
            -- DIAGNOSTICO CITOLOGICO E HISTOLOGICO
            BEGIN
              IF (rPedidoAutorizacao.DS_DIAG_CIT_HIST_RADIO IS NOT NULL) THEN
                vDsDiagCitHistRadio := rPedidoAutorizacao.DS_DIAG_CIT_HIST_RADIO;
              END IF;
            EXCEPTION
              WHEN OTHERS THEN
                vDsDiagCitHistRadio := NULL;
            END;
            -- INFORMACOES RELEVANTES
            BEGIN
              IF (rPedidoAutorizacao.DS_INFO_RELEVANTES_RADIO IS NOT NULL) THEN
                vDsInfoRelevantesRadio := rPedidoAutorizacao.DS_INFO_RELEVANTES_RADIO;
              END IF;
            EXCEPTION
              WHEN OTHERS THEN
                vDsInfoRelevantesRadio := NULL;
            END;
            -- DESCRICAO DA RADIOTERAPIA
            BEGIN
              IF (rPedidoAutorizacao.DS_RADIO IS NOT NULL) THEN
                vDsRadio := rPedidoAutorizacao.DS_RADIO;
              END IF;
            EXCEPTION
              WHEN OTHERS THEN
                vDsRadio := NULL;
            END;
            -- DATA DO DIAGNOSTICO
            BEGIN
              IF (rPedidoAutorizacao.DT_DIAGNOSTICO_RADIO IS NOT NULL) THEN
                vDtDiagnosticoRadio := rPedidoAutorizacao.DT_DIAGNOSTICO_RADIO;
              END IF;
            EXCEPTION
              WHEN OTHERS THEN
                vDtDiagnosticoRadio := NULL;
            END;
            -- CID
            BEGIN
              -- CID PRINCIPAL
              IF (rPedidoAutorizacao.CD_CID_1_RADIO IS NOT NULL) THEN
                vCdCid1Radio := rPedidoAutorizacao.CD_CID_1_RADIO;
              END IF;
              -- CID 2
              IF (rPedidoAutorizacao.CD_CID_2_RADIO IS NOT NULL) THEN
                vCdCid2Radio := rPedidoAutorizacao.CD_CID_2_RADIO;
              END IF;
              -- CID 3
              IF (rPedidoAutorizacao.CD_CID_3_RADIO IS NOT NULL) THEN
                vCdCid3Radio := rPedidoAutorizacao.CD_CID_3_RADIO;
              END IF;
              -- CID 4
              IF (rPedidoAutorizacao.CD_CID_4_RADIO IS NOT NULL) THEN
                vCdCid4Radio := rPedidoAutorizacao.CD_CID_4_RADIO;
              END IF;
            EXCEPTION
              WHEN OTHERS THEN
                vCdCid1Radio := NULL;
                vCdCid2Radio := NULL;
                vCdCid3Radio := NULL;
                vCdCid4Radio := NULL;
            END;
            -- ESTADIAMENTO
            BEGIN
              IF (rPedidoAutorizacao.TP_ESTADIAMENTO_TUMOR_RADIO IS NOT NULL) THEN
                vTpEstadiamentoRadio := rPedidoAutorizacao.TP_ESTADIAMENTO_TUMOR_RADIO;
              END IF;
            EXCEPTION
              WHEN OTHERS THEN
                vTpEstadiamentoRadio := NULL;
            END;
            -- FINALIDADE
            BEGIN
              IF (rPedidoAutorizacao.TP_FINALIDADE_RADIO IS NOT NULL) THEN
                vTpFinalidadeRadio := rPedidoAutorizacao.TP_FINALIDADE_RADIO;
              END IF;
            EXCEPTION
              WHEN OTHERS THEN
                vTpFinalidadeRadio := NULL;
            END;
            -- ECOG
            BEGIN
              IF (rPedidoAutorizacao.TP_ECOG_RADIO IS NOT NULL) THEN
                vTpEcogRadio := rPedidoAutorizacao.TP_ECOG_RADIO;
              END IF;
            EXCEPTION
              WHEN OTHERS THEN
                vTpEcogRadio := NULL;
            END;
            -- CODIGO DO DIAGNOSTICO POR IMAGEM
            BEGIN
              IF (rPedidoAutorizacao.TP_DIAGNOSTICO_IMAGEM IS NOT NULL) THEN
                vCdDiagImagemRadio := rPedidoAutorizacao.TP_DIAGNOSTICO_IMAGEM;
              END IF;
            EXCEPTION
              WHEN OTHERS THEN
                vCdDiagImagemRadio := NULL;
            END;
            -- CAMPOS
            BEGIN
              -- QUANTIDADE DE CAMPOS
              IF (rPedidoAutorizacao.QT_CAMPOS IS NOT NULL) THEN
                vQtCamposRadio := rPedidoAutorizacao.QT_CAMPOS;
              END IF;
              -- QUANTIDADE DE DOSES POR DIA
              IF (rPedidoAutorizacao.QT_DOSES_DIA IS NOT NULL) THEN
                vQtDosesDiaRadio := rPedidoAutorizacao.QT_DOSES_DIA;
              END IF;
              -- QUANTIDADE DE DOSES NO TOTAL
              IF (rPedidoAutorizacao.QT_DOSES_TOTAL IS NOT NULL) THEN
                vQtDosesTotalRadio := rPedidoAutorizacao.QT_DOSES_TOTAL;
              END IF;
              -- QUANTIDADE DE DIAS DE TRATAMENTO
              IF (rPedidoAutorizacao.QT_DIAS_TRATAMENTO IS NOT NULL) THEN
                vQtDiasTratamentoRadio := rPedidoAutorizacao.QT_DIAS_TRATAMENTO;
              END IF;
            EXCEPTION
              WHEN OTHERS THEN
                vQtCamposRadio         := NULL;
                vQtDosesDiaRadio       := NULL;
                vQtDosesTotalRadio     := NULL;
                vQtDiasTratamentoRadio := NULL;
            END;
            -- DATA PREVISTA
            BEGIN
              IF (rPedidoAutorizacao.DT_PREV_ADMIN IS NOT NULL) THEN
                vDtPrevistaRadio := rPedidoAutorizacao.DT_PREV_ADMIN;
              END IF;
            EXCEPTION
              WHEN OTHERS THEN
                vDtPrevistaRadio := SYSDATE;
            END;
            -- TRATAMENTOS ANTERIORES
            BEGIN
              -- DESCRICAO DA CIRURGIA
              IF (rPedidoAutorizacao.DS_CIRURGIA_RADIO IS NOT NULL) THEN
                vDsCirurgiaRadio := rPedidoAutorizacao.DS_CIRURGIA_RADIO;
              END IF;
              -- DATA DA CIRURGIA
              IF (rPedidoAutorizacao.DT_CIRURGIA_RADIO IS NOT NULL) THEN
                vDtCirurgiaRadio := rPedidoAutorizacao.DT_CIRURGIA_RADIO;
              END IF;
              -- DESCRICAO DA QUIMIOTERAPIA
              IF (rPedidoAutorizacao.DS_QUIMIO_RADIO IS NOT NULL) THEN
                vDsQuimioterapiaRadio := rPedidoAutorizacao.DS_QUIMIO_RADIO;
              END IF;
              -- DATA DA QUIMIOTERAPIA
              IF (rPedidoAutorizacao.DT_QUIMIO IS NOT NULL) THEN
                vDtQuimioterapiaRadio := rPedidoAutorizacao.DT_QUIMIO;
              END IF;
            EXCEPTION
              WHEN OTHERS THEN
                vDsCirurgiaRadio      := NULL;
                vDtCirurgiaRadio      := SYSDATE;
                vDsQuimioterapiaRadio := NULL;
                vDtQuimioterapiaRadio := SYSDATE;
            END;
            -- PROFISSIONAL SOLICITANTE
            BEGIN
              -- NOME
              IF (rPedidoAutorizacao.NM_PROFISSIONAL_RADIO IS NOT NULL) THEN
                vNmProfSolicitanteRadio := rPedidoAutorizacao.NM_PROFISSIONAL_RADIO;
              END IF;
              -- NUMERO DE TELEFONE
              IF (rPedidoAutorizacao.NR_TEL_PROFISSIONAL_RADIO IS NOT NULL) THEN
                vNrTelProfSolicitanteRadio := rPedidoAutorizacao.NR_TEL_PROFISSIONAL_RADIO;
              END IF;
              -- E-MAIL
              IF (rPedidoAutorizacao.DS_EMAIL_PROFISSIONAL_RADIO IS NOT NULL) THEN
                vDsEmailProfSolicitanteRadio := rPedidoAutorizacao.DS_EMAIL_PROFISSIONAL_RADIO;
              END IF;
            EXCEPTION
              WHEN OTHERS THEN
                vNmProfSolicitanteRadio      := NULL;
                vNrTelProfSolicitanteRadio   := NULL;
                vDsEmailProfSolicitanteRadio := NULL;
            END;
            /********************************************************************************************
            * =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-==-=-=-=-=-=-=-=-=
            * >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> OPME <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
            * =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-==-=-=-=
            ********************************************************************************************/
            BEGIN
              IF (rPedidoAutorizacao.DS_OPME IS NOT NULL) THEN
                vDsOpme := rPedidoAutorizacao.DS_OPME;
              END IF;
            EXCEPTION
              WHEN OTHERS THEN
                vDsOpme := NULL;
            END;
            -- JUSTIFICATIVA TECNICA
            BEGIN
              IF (rPedidoAutorizacao.DS_JUSTIFICATIVA_TECNICA IS NOT NULL) THEN
                vDsJustificativaTecOpme := rPedidoAutorizacao.DS_JUSTIFICATIVA_TECNICA;
              END IF;
            EXCEPTION
              WHEN OTHERS THEN
                vDsJustificativaTecOpme := NULL;
            END;
            -- MATERIAL SOLICITANTE
            BEGIN
              IF (rPedidoAutorizacao.DS_MATERIAL_SOLIC_OPME IS NOT NULL) THEN
                vDsMaterialSolicOpme := rPedidoAutorizacao.DS_MATERIAL_SOLIC_OPME;
              END IF;
            EXCEPTION
              WHEN OTHERS THEN
                vDsMaterialSolicOpme := NULL;
            END;
            -- INDICA A EXISTENCIA DE UM ANEXO DE OPME.
            IF (vDsJustificativaTecOpme IS NOT NULL)
               AND (vDsMaterialSolicOpme IS NOT NULL) THEN
              vSnAnexoOpme := 'S';
            ELSE
              vSnAnexoOpme := 'N';
            END IF; -- END IF - INDICA A EXISTENCIA DE UM ANEXO DE OPME.
            /**
            * @TODO - FORAM ENCONTRADAS ALGUMAS DIFICULDADES NO SCHEMA DISPONIBILIZADO PELO PTU (VERSAO 5):
            *
            *         OS CAMPOS DE REGIME DE INTERNACAO, NUMERO DE DIAS SOLICITADOS E DATA SUGERIDA NAO SAO
            *         MENSIONADOS, AFETANDO DIRETAMENTE NO PROCESSAMENTO DE UMA TRANSACAO DE INTERNACAO.
            *         NAS TRANSACOES DE PEDIDO DE AUTORIZACAO, O NUMERO DE CID'S LIMITA-SE A 1, E NOS ANEXOS
            *         ATE 4.
            */
            -- CONCATENANDO PROCEDIMENTOS
            IF rPedidoAutorizacao.NR_GUIA IS NOT NULL THEN
              vNrGuiaComplemento := rPedidoAutorizacao.NR_GUIA;
            END IF;
            vCdProcedimento := '*';
            IF vCdGlosa IS NULL THEN
              FOR rSolicitacaoProcedimento IN cPedidoAutorizacaoItem(rPedidoAutorizacao.CD_PTU_PEDIDO_AUTORIZACAO, NULL) LOOP
                vCdProcedimentoPacote := NULL;
                --REGRA DE PACOTE, TP_TABELA = 98
                IF rSolicitacaoProcedimento.TP_TABELA = '98' THEN
                --VERIFICANDO SE O PROCEDIMENTO DA SOLICITACAO EXISTE, CASO NAO EXISTA, SER� CRIADO AQUI
                  vCdProcedimentoPacote := DBAPS.FNC_PACOTE_UNIMED(rSolicitacaoProcedimento.CD_SERVICO,
                                                                  vCdUnimedPrestadora);
                END IF; -- rSolicitacaoProcedimento.TP_TABELA = '98'
                vCdProcedimento := vCdProcedimento ||
                                   Nvl(vCdProcedimentoPacote, rSolicitacaoProcedimento.CD_PROCEDIMENTO) || '*' || -- CD_PROCEDIMENTO
                                   rSolicitacaoProcedimento.QT_SERVICO || '*' || -- QT_PROCEDIMENO
                                   NVL(TO_CHAR(rSolicitacaoProcedimento.SQ_ITEM), 'NULL') || '*' || -- CD_REGIAO_DENTE
                                  /*CD_FACES_DENTES_ODONTO*/
                                   'NULL' || '*' || -- CD_FACES_DENTES_ODONTO
                                   NVL(TO_CHAR(rSolicitacaoProcedimento.DT_PROV), 'NULL') || '*' || -- DT_PREVISTA
                                   NVL(TO_CHAR(rSolicitacaoProcedimento.CD_VIA_ADMIN), 'NULL') || '*' || -- CD_VIA_ADM
                                   NVL(TO_CHAR(rSolicitacaoProcedimento.TP_ORDEM), 'NULL') || '*' || -- NR_ORDEM_PREFERENCIA
                                   NVL(TO_CHAR(rSolicitacaoProcedimento.VL_MONETARIO), 'NULL') || '*' || -- VL_SOLICITADO
                                   NVL(TO_CHAR(rSolicitacaoProcedimento.CD_ANVISA), 'NULL') || '*' || -- NR_ANVISA
                                   NVL(TO_CHAR(REPLACE(rSolicitacaoProcedimento.CD_REFERENCIA_MATERIAL_FAB, '*')), 'NULL') || '*' || -- CD_MATERIAL_FABRICANTE
                                  /*NR_AUTORIZACAO_FUNCIONAMENTO*/
                                   'NULL' || '*' || -- NR_AUTORIZACAO_FUNCIONAMENTO
                                  /*SN_PRESTADOR_EXECUTOR_OPME*/
                                   'NULL' || '*' || -- SN_PRESTADOR_EXECUTOR_OPME
                                   NVL(TO_CHAR(rSolicitacaoProcedimento.QT_FREQUENCIA), 'NULL') || '*' || -- QT_SOLICITADO_DIA
                                  /*CD_UNIDADE_MEDIDA*/
                                   'NULL' || '*' || -- CD_UNIDADE_MEDIDA
                                  /*QT_TOTAL_DOSAGEM_CICLO*/
                                   'NULL' || '*'; -- QT_TOTAL_DOSAGEM_CICLO
              END LOOP;
            END IF; -- END IF - CONCATENANDO PROCEDIMENTOS
            IF ((rQtdAnexosPedido.QT_ANEXO = 0 AND
               rQtdAnexosPedido.QT_NAO_ANEXO > 0) OR
               rQtdAnexosPedido.QT_ANEXO = 1) THEN
              BEGIN
                vDsMensagem          := NULL;
                vRetornoAutorizaGuia := DBAPS.AUTORIZA_GUIA(NVL(P_CD_MULTI_EMPRESA, DBAMV.PKG_MV2000.LE_EMPRESA) -- 1-PCD_MULTI_EMPRESA              - HOSPITAL/OPERADORA (MULTI-EMPRESA
                                                           , vCdMatricula -- 2-PCD_MATRICULA                  - MATRICULA DO BENEFICIARIO
                                                           , nTipoGuia -- 3-PCD_TIPO_GUIA                  - TIPO DE ATENDIMENTO (GUIA)
                                                           , vTpInternacao -- 4-PTP_INTERNACAO                 - TIPO DE INTERNACAO
                                                           , nQtDiasSolicitados -- 5-PNR_DIAS_AUTORIZACAO           - NUMERO DE DIAS SOLICITADOS
                                                           , nCdPrestador -- 6-PCD_PRESTADOR                  - PRESTADOR EXECUTOR
                                                           , nCdEspecialidade -- 7-PCD_ESPECIALIDADE              - ESPECIALIDADE DO PRESTADOR EXECUTANTE (NAO VAI SER MAIS USADA A ESPECIALIDADE COMO UM CAMPO DE VALIDACAO)
                                                           , vCdProcedimento -- 8-PSTRING_PROC                   - PROCEDIMENTOS (SEPARADOS POR '*')
                                                           , 'S' -- 9-PSN_SOLICITA_AUTORIZACAO       - INDICA SE E UMA SOLICITACAO DE GUIA
                                                           , Nvl(dDtSugeridaInternacao, TRUNC(SYSDATE)) -- 10-PDT_PREVISAO_EXECUCAO         - DATA DE PREVISAO DE EXECUCAO
                                                           , NULL -- 11-PDS_SENHA_AUTORIZACAO         - SENHA DE AUTORIZACAO DO PRESTADOR
                                                           , vNmBeneficiario -- 12-PNM_USUARIO                   - RETORNO DO NOME DO BENEFICIARIO
                                                           , vTpSexo -- 13-PTP_SEXO                      - RETORNO DO SEXO DO BENEFICIARIO
                                                           , vNrCpfBeneficiario -- 14-PNR_CPF                       - RETORNO DO CPF DO BENEFICIARIO
                                                           , vNrRG -- 15-PNR_RG                        - RETORNO DO RG DO BENEFICIARIO
                                                           , vOrgaoExpeditor -- 16-PDS_ORGAO_EXPEDITOR           - RETORNO DO ORGAO EXPEDIDOR DO BENEFICIARIO
                                                           , vNmConjuge -- 17-PNM_CONJUGE                   - RETORNO DO NOME DO CONJUGE DO BENEFICIARIO
                                                           , vNmMae -- 18-PNM_MAE                       - RETORNO DO NOME DA MAE DO BENEFICIARIO
                                                           , vNmPai -- 19-PNM_PAI                       - RETORNO DO NOME DO PAI DO BENEFICIARIO
                                                           , dDtNascimento -- 20-PDT_NASCIMENTO                - RETORNO DA DATA DE NASCIMENTO DO BENEFICIARIO
                                                           , vEndereco -- 21-PDS_ENDERECO                  - RETORNO DO ENDERECO DO BENEFICIARIO
                                                           , nNrEndereco -- 22-PNR_ENDERECO                  - RETORNO DO NUMERO DO ENDERECO DO BENEFICIARIO
                                                           , vComplemento -- 23-PDS_COMPLEMENTO               - RETORNO DO COMPLEMENTO DO ENDERECO DO BENEFICIARIO
                                                           , vBairro -- 24-PDS_BAIRRO                    - RETORNO DO BAIXO DO BENEFICIARIO
                                                           , nCdCidade -- 25-PCD_CIDADE                    - RETORNO DO CODIGO DA CIDADE DO BENEFICIARIO
                                                           , vNrCEP -- 26-PNR_CEP                       - RETORNO DO NUMERO DO CEP DO BENEFICIARIO
                                                           , vNrTelefone -- 27-PNR_TELEFONE                  - RETORNO DO NUMERO DO TELEFONE DO BENEFICIARIO
                                                           , vNrGuia -- 28-PNR_GUIA                      - RETORNO DO NUMERO DA GUIA AUTORIZADA
                                                           , vDtValidadeCarteira -- 29-PDT_VALID_CART                - RETORNO DA DATA VALIDADE DA CARTEIRA
                                                           , vNmTitular -- 30-PNM_TITULAR                   - RETORNO DO NOME DO TITULAR (SE BENEFICIARIO DEPENDENTE OU AGREGADO)
                                                           , vTpGuia -- 31-PDS_TIPO_GUIA                 - RETORNO DA DESCRICAO DO TIPO DE ATENDIMENTO (GUIA)
                                                           , vNmPrestador -- 32-PNM_PRESTADOR                 - RETORNO DO NOME DO PRESTADOR EXECUTOR
                                                           , vEspecialidade -- 33-PDS_ESPECIALIDADE             - RETORNO DA ESPECIALIDADE DO PRESTADOR EXECUTOR
                                                           , dDtVencimentoGuia -- 34-PDT_VENCIMENTO_GUIA           - RETORNO DA DATA DE VENCIMENTO DA GUIA
                                                           , nCdPlano -- 35-PCD_PLANO                     - RETORNO DO CODIGO DO PLANO DO BENEFICIARIO
                                                           , vDsPlano -- 36-PDS_PLANO                     - RETORNO DA DESCRICAO DO PLANO DO BENEFICIARIO
                                                           , vEmpresa -- 37-PDS_EMPRESA                   - RETORNO DA DESCRICAO DA EMPRESA DO BENEFICIARIO (PARA CONTRATOS COLETIVOS)
                                                           , vDsMensagem -- 38-PDS_MENSAGEM                  - RETORNO DA MENSAGEM DE ERRO DA ANALISE DA GUIA
                                                           , 'PTU' -- 39-PTP_ORIGEM                    - ORIGEM: MVS - MVSAUDE; MV2-MV2000i ;INT-INTERNET OU WS-WEBSERVICE
                                                           , nCdPrestadorSolicitante -- 40-PCD_PRESTADOR_SOLICITANTE     - CODIGO DO PRESTADOR SOLICITANTE
                                                           , nCdAutorizador -- 41-PCD_AUTORIZADOR               - CODIGO DO AUTORIZADOR DA GUIA
                                                           , nCdMedicoSolicitante -- 42-PCD_MEDICO_SOLICITANTE        - CODIGO DO MEDICO SOLICITANTE (NAO HA ESSE ITEM NAS PASSAGENS DO TISS)
                                                           , NULL -- 43-PNR_GUIA_PRESTADOR            - NUMERO DA GUIA DO PRESTADOR
                                                           , NULL -- 44-PNR_GUIA_EXTERNA              - NUMERO DA GUIA EXTERNA DA OPERADORA
                                                           , vNrGuiaComplemento -- 45-PNR_GUIA_TEM                  - CODIGO DA GUIA PAI
                                                           , NULL -- 46-PCD_ESPECIALIDADE_SOLICITANTE - CODIGO DA ESPECIALIDADE DO PRESTADOR SOLICITANTE
                                                           , NULL -- 47-PCD_PRESTADOR_SOLICITADO      - CODIGO DO PRESTADOR EXECUTOR SOLICITADO
                                                           , vTpCaraterSolicInter -- 48-PTP_CARATER_SOLIC_INTER       - CODIGO DO CARACTER DA EXECUCAO
                                                           , NULL -- 49-PCD_REGIME_INTERNACAO         - CODIGO DO REGIME DE INTERNACAO
                                                           , NULL -- 50-PCD_PRESTADOR_EXECUTOR_PF     - CODIGO DO PROFISSIONAL EXECUTOR
                                                           , Nvl(rPedidoAutorizacao.CD_CID, Nvl(vCdCid1Radio, vCdCid2Quimio)) -- 51-PCD_CID                       - CID PRINCIPAL
                                                           , Nvl(vCdCid2Radio, vCdCid3Quimio) -- 52-PCD_CID2                      - CID (2)
                                                           , Nvl(vCdCid3Radio, vCdCid1Quimio) -- 53-PCD_CID3                      - CID (3)
                                                           , Nvl(vCdCid4Radio, vCdCid4Quimio) -- 54-PCD_CID4                      - CID (4)
                                                           , nQtDiasSolicitados -- 55-PNR_DIAS_SOLICITACAO          - NUMERO DE DIAS SOLICITADO
                                                           , NULL -- 56-PCD_TIPO_DOENCA               - CODIGO DO TIPO DE DOENCA
                                                           , NULL -- 57-PNR_TEMPO_DOENCA              - VALOR DO TEMPO DA DOENCA
                                                           , nCodigoIndicadorAcidente -- 58-PCD_INDICADOR_ACIDENTE        - CODIGO DA INDICACAO DE ACIDENTE
                                                           , NULL -- 59-PCD_TIPO_ATENDIMENTO_TISS     - CODIGO DO TIPO DE ATENDIMENTO TISS (NAO INFORMADO NO TISS)
                                                           , NULL -- 60-PCD_TIPO_SAIDA_GUIA_SADT      - CODIGO DO TIPO DE SAIDA DA GUIA (NAO INFORMADO NO TISS)
                                                           , rPedidoAutorizacao.DS_OBSERVACAO -- 61-PDS_OBSERVACAO                - OBSERVACAO
                                                           , rPedidoAutorizacao.DS_INDICACAO_CLINICA -- 62-PDS_DIAGNOSTICO               - INDICACAO CLINICA
                                                           , NULL -- 63-PCD_UNIDADE_TEMPO_DOENCA      - CODIGO DA UNIDADE DO TEMPO DA DOENCA
                                                           , NULL -- 64-PCD_TIPO_CONSULTA             - TIPO DA CONSULTA
                                                           , NULL -- 65-PDS_ANEXO_TEXTO               - DESCRICAO DO ANEXO
                                                           , nCdPrestadorEndereco -- 66-PCD_PRESTADOR_ENDERECO        - CODIGO DO PRESTADOR NO ENDERECO
                                                           , rPedidoAutorizacao.SN_RN -- 67-PSN_ATENDIMENTO_RECEM_NATO    - ATENDIMENTO RECEM NATO
                                                           , NULL -- 68-PDT_TERMINO_TRATAMENTO_ODONTO - DATA DO TERMINO DO TRATAMENTO ODONTOLOGICO
                                                           , NULL -- 69-PTP_ATENDIMENTO_ODONTO        - TIPO DO ATENDIMENTO ODONTOLOGICO
                                                           , NULL -- 70-PTP_FATURAMENTO_ODONTO        - TIPO DO FATURAMENTO ODONTOLOGICO
                                                           , Nvl(vNrTelProfSolicitanteQuimio, vNrTelProfSolicitanteRadio) -- 71-PNR_TELEFONE_PROF_SOLIC       - NUMERO DO TELEFONE DO PROFISSIONAL SOLICITANTE
                                                           , Nvl(vDsEmailProfSolicitanteQuimio, vDsEmailProfSolicitanteRadio) -- 72-PDS_EMAIL_PROF_SOLIC          - EMAIL DO PROFISSIONAL SOLICITANTE
                                                           , Nvl(vDtDiagnosticoQuimio, vDtDiagnosticoRadio) -- 73-PDT_DIAGNOSTICO               - DATA DO DIAGNOSTICO
                                                           , vCdDiagImagemRadio -- 74-PCD_DIAGNOSTICO_IMAGEM        - CODIGO DO DIAGNOSTICO POR IMAGEM
                                                           , Nvl(vTpEstadiamentoRadio, vTpEstadiamentoQuimio) -- 75-PCD_ESTADIAMENTO              - CODIGO DO ESTADIAMENTO
                                                           , Nvl(vTpEcogRadio, vTpEcogQuimio) -- 76-PCD_ECOG                      - CODIGO DO ECOG
                                                           , Nvl(vTpFinalidadeRadio, vTpFinalidadeQuimio) -- 77-PCD_FINALIDADE_TRATAMENTO     - CODIGO DA FINALIDADE DO TRATAMENTO
                                                           , Nvl(vDsDiagCitHistRadio, vDsDiagCitHistQuimio) -- 78-PDS_DIAGNOSTICO_CITOHISTO     - DIAGNOSTICO HISPATOLOGICO
                                                           , Nvl(vDsInfoRelevantesRadio, vDsInfoRelevantesQuimio) -- 79-PDS_INFORMACOES_RELEVANTES    - INFORMACOES RELEVANTES
                                                           , Nvl(vDsCirurgiaRadio, vDsCirurgiaQuimio) -- 80-PDS_CIRURGIA                  - CIRURGIA
                                                           , Nvl(vDtCirurgiaRadio, vDtCirurgiaQuimio) -- 81-PDT_REALIZACAO                - DATA DA REALIZACAO
                                                           , Nvl(vDsQuimioterapiaRadio, vDsQuimio) -- 82-PDS_QUIMIOTERAPIA             - QUIMIOTERAPIA
                                                           , Nvl(vDtQuimioterapiaRadio, vDtIrradiacaoQuimio) -- 83-PDT_APLICACAO                 - DATA DA APLICACAO
                                                           , vQtCamposRadio -- 84-PNR_CAMPOS                    - NUMERO DE CAMPOS
                                                           , vQtDosesDiaRadio -- 85-PNR_DOSE_DIA                  - NUMERO DE DOSE DIA
                                                           , vQtDosesTotalRadio -- 86-PNR_DOSE_TOTAL                - TOTAL DE DOSES
                                                           , vQtDiasTratamentoRadio -- 87-NR_TRATAMENTO_DIA             - NUMERO DE TRATAMENTO DIA
                                                           , vNrPesoQuimio -- 88-PNR_PESO_BENEFICIARIO         - PESO DO BENEFICIARIO
                                                           , vNrAlturaQuimio -- 89-PNR_ALTURA_BENEFICIARIO       - ALTURA DO BENEFICIARIO
                                                           , vNrSupCorporalQuimio -- 90-PNR_SUPERFICIE_CORPORAL       - SUPERFICIE CORPORAL DO BENEFICIARIO
                                                           , vNrCiclosQuimio -- 91-PNR_CICLO_PREVISTO            - NUMERO DE CICLOS PREVISTOS
                                                           , vNrCicloAtualQuimio -- 92-PNR_CICLO_ATUAL               - NUMERO DO CICLO ATUAL
                                                           , vNrIntervaloCiclosQuimio -- 93-PNR_INTERVALO_CICLO           - INTERVALO ENTRE CICLO
                                                           , vDsPlanoTerapeuticoQuimio -- 94-PDS_PLANO_TERAPEUTICO         - PLANO TERAPEUTICO
                                                           , vDsAreaIrradiadaQuimio -- 95-PDS_AREA_IRRADIADA            - AREA IRRADIADA
                                                           , vTpQuimio -- 96-PCD_QUIMIOTERAPIA             - CODIGO DA QUIMIOTERAPIA
                                                           , Nvl(rPedidoAutorizacao.DS_VERSAO_TISS, P_VERSAO_TISS) -- 97-PCD_VERSAO_TISS               - A ATUAL VERSAO DO TISS
                                                           , dDtSugeridaInternacao -- 98-PDT_SUGERIDA_INTERNACAO
                                                           , vSnAnexoOpme -- 99-PSN_PREVISAO_USO_OPME
                                                           , vSnAnexoQuimio -- 100-PSN_PREVISAO_USO_QUIMIO
                                                           , rPedidoAutorizacao.DS_JUSTIFICATIVA_TECNICA -- 101-PDS_JUSTIFICATIVA_TECNICA
                                                           , vDsMaterialSolicOpme -- 102-PDS_ESPECIFICACAO_MATERIAL
                                                           , Nvl(vNmProfSolicitanteQuimio, vNmProfSolicitanteRadio) -- 103-PNM_PROFISSIONAL_SOLICITANTE
                                                           , NULL -- 104-PCD_MOTIVO_CONTIGENCIAL      - MOTIVO CONTIGENCIA
                                                           , LPAD(rPedidoAutorizacao.CD_UNIMED_ORIGEM, 3, '0') -- 105-PCD_UNIMED_ORIGEM
                                                           , LPAD(rPedidoAutorizacao.CD_UNIMED_ATEND, 3, '0') -- 106-PCD_UNIMED_EXECUTORA
                                                           , NULL -- 107-PCD_VIA_CARTAO
                                                           , rPedidoAutorizacao.TP_REDE_MIN -- 108-PTP_REDE_MIN
                                                           , rPedidoAutorizacao.CD_IBGE -- 109-PCD_IBGE
                                                           , NULL -- 110 - PCD_TISS_CONSELHO_PROF_SOL
                                                           , NULL -- 111 - PUF_CONSELHO_PROF_SOLC
                                                           , NULL -- 112 - PNR_REG_CONSELHO_PROF_SOLIC
                                                           , NULL -- 113 - PCD_CLASSIFICACAO_TUMOR
                                                           , NULL -- 114 - PCD_CLASSIFICACAO_NODULO
                                                           , NULL -- 115 - PQTD_DIAS_CICLO
                                                           , NULL -- 116 - CD_CLASSIFICACAO_METASTASE
                                                           , NULL -- 117 - PCD_IDENTIFICACAO_BENEFICIARIO
                                                           , rPedidoAutorizacao.TP_ETAPA_AUTORIZACAO  -- 118 - PCD_ETAPA_AUTORIZACAO
                                                           , NULL -- 119 - PCD_MOT_AUSENCIA_COD_VALIDACAO
                                                           , NULL -- 120 - PCD_VALIDACAO
                                                           , NULL -- 121 - PCD_PRESTADOR_EMISSAO_GUIA
                                                           , NULL -- 122 - PCD_TIP_ACOMODACAO
                                                           , NULL -- 123 - PNM_PRESTADOR_EXECUTOR_PF
                                                           , NULL -- 124 - PCD_TISS_CONSELHO_PROF_EXEC_PF
                                                           , NULL -- 125 - PNR_REG_CONSELHO_PROFI_EXEC
                                                           , NULL -- 126 - PUF_CONSELHO_PROFISSIONAL_EXEC
                                                           , NULL -- 127 - PCD_ESPECIALIDADE_EXECUTANTE
                                                           , NULL -- 128 - PDT_EMISSAO
                                                           , NULL -- 129 - PDS_PLANO_BENEF
                                                           , NULL -- 130 - PDS_NOME_EMPRESA
                                                           , NULL -- 131 - PNR_TELEFONE_BENEF
                                                           , NULL -- 132 - PNM_TITULAR_BENEF
                                                           , NULL -- 133 - PNR_REGISTRO_ANS_ANEXO
                                                           , NULL -- 134 - PNR_GUIA_ANEXO
                                                           , NULL -- 135 - PNR_GUIA_REFERENCIADA_ANEXO
                                                           , NULL -- 136 - PNR_GUIA_OPERADORA_ANEXO
                                                           , NULL -- 137 - PNM_BENEFICIARIO_ANEXO
                                                           , NULL -- 138 - PNR_CARTEIRA_ANEXO
                                                           , NULL -- 139 - PSN_DOENCA_PERIODONTAL
                                                           , NULL -- 140 - PSN_ALTERACAO_TECIDO_MOLE
                                                           , NULL -- 141 - PDS_OBSERVACAO_ANEXO
                                                           , NULL -- 142 - PCD_REEMBOLSO
                                                           , rPedidoAutorizacao.NR_TOKEN --143 - NR_TOKEN
                                                           );
                --rafael
                --If vRetornoAutorizaGuia <> 'TRUE' Then
                --
                --    vCdGlosa := '4001';
                --    vDsGlosa := 'PRESTADOR TABELA PROPRIA OU ALTO CUSTO';
                --End IF;
                DBAPS.PRC_INSERE_DEBUG_LOG(P_ID_PTU_AUTORIZACAO, 'Guia: ' ||
                                            vNrGuia ||
                                            '; vCdProcedimento: ' ||
                                            vCdProcedimento, 'PTU0600');
                vNrGuiaTem := vNrGuia;
              EXCEPTION
                WHEN OTHERS THEN
                  vCdGlosa      := '4001';
                  vDsGlosa      := REPLACE('ERRO NA AUTORIZA_GUIA. ERRO: ' ||
                                           SQLERRM || ' LINHA DO ERRO: ' ||
                                           DBMS_UTILITY.FORMAT_ERROR_BACKTRACE, Chr(13) ||
                                            Chr(10));
                  vExcecao      := SQLERRM;
                  vExcecaoLinha := DBMS_UTILITY.FORMAT_ERROR_BACKTRACE;
                  SELECT DBAPS.SEQ_PTU_MENSAGEM.NEXTVAL
                    INTO nIdPtuMensagemLog
                    FROM SYS.DUAL;
                  -- INSERINDO NO LOG DE ERROS
                  INSERT INTO DBAPS.PTU_MENSAGEM_LOG
                    (CD_PTU_MENSAGEM_LOG
                    ,CD_PTU_MENSAGEM
                    ,DT_LOG
                    ,DS_LOG)
                  VALUES
                    (nIdPtuMensagemLog --CD_PTU_MENSAGEM_LOG
                    ,P_ID_PTU_MENSAGEM --CD_PTU_MENSAGEM
                    ,SYSDATE --DT_LOG
                    ,'ERRO: ' || vExcecao || ' LINHA DO ERRO: ' ||
                     vExcecaoLinha --DS_LOG
                     );
              END; -- END - AUTORIZA_GUIA
            ELSIF (rQtdAnexosPedido.QT_ANEXO > 1)
                  AND rGuia.NR_GUIA IS NULL THEN
              BEGIN
                -- CONCATENANDO PROCEDIMENTOS
                vCdProcedimento := '*';
                IF vCdGlosa IS NULL THEN
                  FOR rSolicitacaoProcedimento IN cPedidoAutorizacaoItem(rPedidoAutorizacao.CD_PTU_PEDIDO_AUTORIZACAO, 9) LOOP
                    vCdProcedimentoPacote := NULL;
                    IF rSolicitacaoProcedimento.TP_TABELA = '98' THEN
                    --VERIFICANDO SE O PROCEDIMENTO DA SOLICITACAO EXISTE, CASO NAO EXISTA, SER� CRIADO AQUI
                      vCdProcedimentoPacote := DBAPS.FNC_PACOTE_UNIMED(rSolicitacaoProcedimento.CD_PROCEDIMENTO,
                                                                      vCdUnimedPrestadora);
                    END IF; -- rSolicitacaoProcedimento.TP_TABELA = '98'
                    vCdProcedimento := vCdProcedimento ||
                                       Nvl(vCdProcedimentoPacote, rSolicitacaoProcedimento.CD_PROCEDIMENTO) || '*' || -- CD_PROCEDIMENTO
                                       rSolicitacaoProcedimento.QT_SERVICO || '*' || -- QT_PROCEDIMENO
                                       Nvl(TO_CHAR(rSolicitacaoProcedimento.SQ_ITEM), 'NULL') || '*' || -- CD_REGIAO_DENTE
                                      /*CD_FACES_DENTES_ODONTO*/
                                       'NULL' || '*' || -- CD_FACES_DENTES_ODONTO
                                       Nvl(TO_CHAR(rSolicitacaoProcedimento.DT_PROV), 'NULL') || '*' || -- DT_PREVISTA
                                       Nvl(TO_CHAR(rSolicitacaoProcedimento.CD_VIA_ADMIN), 'NULL') || '*' || -- CD_VIA_ADM
                                       Nvl(TO_CHAR(rSolicitacaoProcedimento.TP_ORDEM), 'NULL') || '*' || -- NR_ORDEM_PREFERENCIA
                                       Nvl(TO_CHAR(rSolicitacaoProcedimento.VL_MONETARIO), 'NULL') || '*' || -- VL_SOLICITADO
                                       Nvl(TO_CHAR(rSolicitacaoProcedimento.CD_ANVISA), 'NULL') || '*' || -- NR_ANVISA
                                       Nvl(TO_CHAR(REPLACE(rSolicitacaoProcedimento.CD_REFERENCIA_MATERIAL_FAB, '*')), 'NULL') || '*' || -- CD_MATERIAL_FABRICANTE
                                      /*NR_AUTORIZACAO_FUNCIONAMENTO*/
                                       'NULL' || '*' || -- NR_AUTORIZACAO_FUNCIONAMENTO
                                      /*SN_PRESTADOR_EXECUTOR_OPME*/
                                       'NULL' || '*' || -- SN_PRESTADOR_EXECUTOR_OPME
                                       NVL(TO_CHAR(rSolicitacaoProcedimento.QT_FREQUENCIA), 'NULL') || '*' || -- QT_SOLICITADO_DIA
                                      /*CD_UNIDADE_MEDIDA*/
                                       'NULL' || '*' || -- CD_UNIDADE_MEDIDA
                                      /*QT_TOTAL_DOSAGEM_CICLO*/
                                       'NULL' || '*'; -- QT_TOTAL_DOSAGEM_CICLO
                    DBAPS.PRC_INSERE_DEBUG_LOG(rPedidoAutorizacao.NR_TRANSACAO_PRESTADORA, vCdProcedimento, 'PRC_PTU_AUTORIZADOR');
                  END LOOP;
                END IF; -- END IF - CONCATENANDO PROCEDIMENTOS
                vDsMensagem          := NULL;
                vRetornoAutorizaGuia := DBAPS.AUTORIZA_GUIA(NVL(P_CD_MULTI_EMPRESA, DBAMV.PKG_MV2000.LE_EMPRESA) -- 1-PCD_MULTI_EMPRESA              - HOSPITAL/OPERADORA (MULTI-EMPRESA
                                                           , vCdMatricula -- 2-PCD_MATRICULA                  - MATRICULA DO BENEFICIARIO
                                                           , nTipoGuia -- 3-PCD_TIPO_GUIA                  - TIPO DE ATENDIMENTO (GUIA)
                                                           , vTpInternacao -- 4-PTP_INTERNACAO                 - TIPO DE INTERNACAO
                                                           , nQtDiasSolicitados -- 5-PNR_DIAS_AUTORIZACAO           - NUMERO DE DIAS SOLICITADOS
                                                           , nCdPrestador -- 6-PCD_PRESTADOR                  - PRESTADOR EXECUTOR
                                                           , nCdEspecialidade -- 7-PCD_ESPECIALIDADE              - ESPECIALIDADE DO PRESTADOR EXECUTANTE (NAO VAI SER MAIS USADA A ESPECIALIDADE COMO UM CAMPO DE VALIDACAO)
                                                           , vCdProcedimento -- 8-PSTRING_PROC                   - PROCEDIMENTOS (SEPARADOS POR '*')
                                                           , 'S' -- 9-PSN_SOLICITA_AUTORIZACAO       - INDICA SE E UMA SOLICITACAO DE GUIA
                                                           , Nvl(dDtSugeridaInternacao, TRUNC(SYSDATE)) -- 10-PDT_PREVISAO_EXECUCAO         - DATA DE PREVISAO DE EXECUCAO
                                                           , NULL -- 11-PDS_SENHA_AUTORIZACAO         - SENHA DE AUTORIZACAO DO PRESTADOR
                                                           , vNmBeneficiario -- 12-PNM_USUARIO                   - RETORNO DO NOME DO BENEFICIARIO
                                                           , vTpSexo -- 13-PTP_SEXO                      - RETORNO DO SEXO DO BENEFICIARIO
                                                           , vNrCpfBeneficiario -- 14-PNR_CPF                       - RETORNO DO CPF DO BENEFICIARIO
                                                           , vNrRG -- 15-PNR_RG                        - RETORNO DO RG DO BENEFICIARIO
                                                           , vOrgaoExpeditor -- 16-PDS_ORGAO_EXPEDITOR           - RETORNO DO ORGAO EXPEDIDOR DO BENEFICIARIO
                                                           , vNmConjuge -- 17-PNM_CONJUGE                   - RETORNO DO NOME DO CONJUGE DO BENEFICIARIO
                                                           , vNmMae -- 18-PNM_MAE                       - RETORNO DO NOME DA MAE DO BENEFICIARIO
                                                           , vNmPai -- 19-PNM_PAI                       - RETORNO DO NOME DO PAI DO BENEFICIARIO
                                                           , dDtNascimento -- 20-PDT_NASCIMENTO                - RETORNO DA DATA DE NASCIMENTO DO BENEFICIARIO
                                                           , vEndereco -- 21-PDS_ENDERECO                  - RETORNO DO ENDERECO DO BENEFICIARIO
                                                           , nNrEndereco -- 22-PNR_ENDERECO                  - RETORNO DO NUMERO DO ENDERECO DO BENEFICIARIO
                                                           , vComplemento -- 23-PDS_COMPLEMENTO               - RETORNO DO COMPLEMENTO DO ENDERECO DO BENEFICIARIO
                                                           , vBairro -- 24-PDS_BAIRRO                    - RETORNO DO BAIXO DO BENEFICIARIO
                                                           , nCdCidade -- 25-PCD_CIDADE                    - RETORNO DO CODIGO DA CIDADE DO BENEFICIARIO
                                                           , vNrCEP -- 26-PNR_CEP                       - RETORNO DO NUMERO DO CEP DO BENEFICIARIO
                                                           , vNrTelefone -- 27-PNR_TELEFONE                  - RETORNO DO NUMERO DO TELEFONE DO BENEFICIARIO
                                                           , vNrGuia -- 28-PNR_GUIA                      - RETORNO DO NUMERO DA GUIA AUTORIZADA
                                                           , vDtValidadeCarteira -- 29-PDT_VALID_CART                - RETORNO DA DATA VALIDADE DA CARTEIRA
                                                           , vNmTitular -- 30-PNM_TITULAR                   - RETORNO DO NOME DO TITULAR (SE BENEFICIARIO DEPENDENTE OU AGREGADO)
                                                           , vTpGuia -- 31-PDS_TIPO_GUIA                 - RETORNO DA DESCRICAO DO TIPO DE ATENDIMENTO (GUIA)
                                                           , vNmPrestador -- 32-PNM_PRESTADOR                 - RETORNO DO NOME DO PRESTADOR EXECUTOR
                                                           , vEspecialidade -- 33-PDS_ESPECIALIDADE             - RETORNO DA ESPECIALIDADE DO PRESTADOR EXECUTOR
                                                           , dDtVencimentoGuia -- 34-PDT_VENCIMENTO_GUIA           - RETORNO DA DATA DE VENCIMENTO DA GUIA
                                                           , nCdPlano -- 35-PCD_PLANO                     - RETORNO DO CODIGO DO PLANO DO BENEFICIARIO
                                                           , vDsPlano -- 36-PDS_PLANO                     - RETORNO DA DESCRICAO DO PLANO DO BENEFICIARIO
                                                           , vEmpresa -- 37-PDS_EMPRESA                   - RETORNO DA DESCRICAO DA EMPRESA DO BENEFICIARIO (PARA CONTRATOS COLETIVOS)
                                                           , vDsMensagem -- 38-PDS_MENSAGEM                  - RETORNO DA MENSAGEM DE ERRO DA ANALISE DA GUIA
                                                           , 'PTU' -- 39-PTP_ORIGEM                    - ORIGEM: MVS - MVSAUDE; MV2-MV2000i ;INT-INTERNET OU WS-WEBSERVICE
                                                           , nCdPrestadorSolicitante -- 40-PCD_PRESTADOR_SOLICITANTE     - CODIGO DO PRESTADOR SOLICITANTE
                                                           , nCdAutorizador -- 41-PCD_AUTORIZADOR               - CODIGO DO AUTORIZADOR DA GUIA
                                                           , nCdMedicoSolicitante -- 42-PCD_MEDICO_SOLICITANTE        - CODIGO DO MEDICO SOLICITANTE (NAO HA ESSE ITEM NAS PASSAGENS DO TISS)
                                                           , NULL -- 43-PNR_GUIA_PRESTADOR            - NUMERO DA GUIA DO PRESTADOR
                                                           , NULL -- 44-PNR_GUIA_EXTERNA              - NUMERO DA GUIA EXTERNA DA OPERADORA
                                                           , vNrGuiaComplemento -- 45-PNR_GUIA_TEM                  - CODIGO DA GUIA PAI
                                                           , NULL -- 46-PCD_ESPECIALIDADE_SOLICITANTE - CODIGO DA ESPECIALIDADE DO PRESTADOR SOLICITANTE
                                                           , NULL -- 47-PCD_PRESTADOR_SOLICITADO      - CODIGO DO PRESTADOR EXECUTOR SOLICITADO
                                                           , vTpCaraterSolicInter -- 48-PTP_CARATER_SOLIC_INTER       - CODIGO DO CARACTER DA EXECUCAO
                                                           , NULL -- 49-PCD_REGIME_INTERNACAO         - CODIGO DO REGIME DE INTERNACAO
                                                           , NULL -- 50-PCD_PRESTADOR_EXECUTOR_PF     - CODIGO DO PROFISSIONAL EXECUTOR
                                                           , rPedidoAutorizacao.CD_CID -- 51-PCD_CID                       - CID PRINCIPAL
                                                           , NULL -- 52-PCD_CID2                      - CID (2)
                                                           , NULL -- 53-PCD_CID3                      - CID (3)
                                                           , NULL -- 54-PCD_CID4                      - CID (4)
                                                           , nQtDiasSolicitados -- 55-PNR_DIAS_SOLICITACAO          - NUMERO DE DIAS SOLICITADO
                                                           , NULL -- 56-PCD_TIPO_DOENCA               - CODIGO DO TIPO DE DOENCA
                                                           , NULL -- 57-PNR_TEMPO_DOENCA              - VALOR DO TEMPO DA DOENCA
                                                           , nCodigoIndicadorAcidente -- 58-PCD_INDICADOR_ACIDENTE        - CODIGO DA INDICACAO DE ACIDENTE
                                                           , NULL -- 59-PCD_TIPO_ATENDIMENTO_TISS     - CODIGO DO TIPO DE ATENDIMENTO TISS (NAO INFORMADO NO TISS)
                                                           , NULL -- 60-PCD_TIPO_SAIDA_GUIA_SADT      - CODIGO DO TIPO DE SAIDA DA GUIA (NAO INFORMADO NO TISS)
                                                           , rPedidoAutorizacao.DS_OBSERVACAO -- 61-PDS_OBSERVACAO                - OBSERVACAO
                                                           , rPedidoAutorizacao.DS_INDICACAO_CLINICA -- 62-PDS_DIAGNOSTICO               - INDICACAO CLINICA
                                                           , NULL -- 63-PCD_UNIDADE_TEMPO_DOENCA      - CODIGO DA UNIDADE DO TEMPO DA DOENCA
                                                           , NULL -- 64-PCD_TIPO_CONSULTA             - TIPO DA CONSULTA
                                                           , NULL -- 65-PDS_ANEXO_TEXTO               - DESCRICAO DO ANEXO
                                                           , nCdPrestadorEndereco -- 66-PCD_PRESTADOR_ENDERECO        - CODIGO DO PRESTADOR NO ENDERECO
                                                           , rPedidoAutorizacao.SN_RN -- 67-PSN_ATENDIMENTO_RECEM_NATO    - ATENDIMENTO RECEM NATO
                                                           , NULL -- 68-PDT_TERMINO_TRATAMENTO_ODONTO - DATA DO TERMINO DO TRATAMENTO ODONTOLOGICO
                                                           , NULL -- 69-PTP_ATENDIMENTO_ODONTO        - TIPO DO ATENDIMENTO ODONTOLOGICO
                                                           , NULL -- 70-PTP_FATURAMENTO_ODONTO        - TIPO DO FATURAMENTO ODONTOLOGICO
                                                           , NULL -- 71-PNR_TELEFONE_PROF_SOLIC       - NUMERO DO TELEFONE DO PROFISSIONAL SOLICITANTE
                                                           , NULL -- 72-PDS_EMAIL_PROF_SOLIC          - EMAIL DO PROFISSIONAL SOLICITANTE
                                                           , NULL -- 73-PDT_DIAGNOSTICO               - DATA DO DIAGNOSTICO
                                                           , NULL -- 74-PCD_DIAGNOSTICO_IMAGEM        - CODIGO DO DIAGNOSTICO POR IMAGEM
                                                           , NULL -- 75-PCD_ESTADIAMENTO              - CODIGO DO ESTADIAMENTO
                                                           , NULL -- 76-PCD_ECOG                      - CODIGO DO ECOG
                                                           , NULL -- 77-PCD_FINALIDADE_TRATAMENTO     - CODIGO DA FINALIDADE DO TRATAMENTO
                                                           , NULL -- 78-PDS_DIAGNOSTICO_CITOHISTO     - DIAGNOSTICO HISPATOLOGICO
                                                           , NULL -- 79-PDS_INFORMACOES_RELEVANTES    - INFORMACOES RELEVANTES
                                                           , NULL -- 80-PDS_CIRURGIA                  - CIRURGIA
                                                           , NULL -- 81-PDT_REALIZACAO                - DATA DA REALIZACAO
                                                           , NULL -- 82-PDS_QUIMIOTERAPIA             - QUIMIOTERAPIA
                                                           , NULL -- 83-PDT_APLICACAO                 - DATA DA APLICACAO
                                                           , NULL -- 84-PNR_CAMPOS                    - NUMERO DE CAMPOS
                                                           , NULL -- 85-PNR_DOSE_DIA                  - NUMERO DE DOSE DIA
                                                           , NULL -- 86-PNR_DOSE_TOTAL                - TOTAL DE DOSES
                                                           , NULL -- 87-NR_TRATAMENTO_DIA             - NUMERO DE TRATAMENTO DIA
                                                           , NULL -- 88-PNR_PESO_BENEFICIARIO         - PESO DO BENEFICIARIO
                                                           , NULL -- 89-PNR_ALTURA_BENEFICIARIO       - ALTURA DO BENEFICIARIO
                                                           , NULL -- 90-PNR_SUPERFICIE_CORPORAL       - SUPERFICIE CORPORAL DO BENEFICIARIO
                                                           , NULL -- 91-PNR_CICLO_PREVISTO            - NUMERO DE CICLOS PREVISTOS
                                                           , NULL -- 92-PNR_CICLO_ATUAL               - NUMERO DO CICLO ATUAL
                                                           , NULL -- 93-PNR_INTERVALO_CICLO           - INTERVALO ENTRE CICLO
                                                           , NULL -- 94-PDS_PLANO_TERAPEUTICO         - PLANO TERAPEUTICO
                                                           , NULL -- 95-PDS_AREA_IRRADIADA            - AREA IRRADIADA
                                                           , NULL -- 96-PCD_QUIMIOTERAPIA             - CODIGO DA QUIMIOTERAPIA
                                                           , Nvl(rPedidoAutorizacao.DS_VERSAO_TISS, P_VERSAO_TISS) -- 97-PCD_VERSAO_TISS               - A ATUAL VERSAO DO TISS
                                                           , Nvl(dDtSugeridaInternacao, TRUNC(SYSDATE)) -- 98-PDT_SUGERIDA_INTERNACAO
                                                           , NULL -- 99-PSN_PREVISAO_USO_OPME
                                                           , NULL -- 100-PSN_PREVISAO_USO_QUIMIO
                                                           , rPedidoAutorizacao.DS_JUSTIFICATIVA_TECNICA -- 101-PDS_JUSTIFICATIVA_TECNICA
                                                           , NULL -- 102-PDS_ESPECIFICACAO_MATERIAL
                                                           , NULL -- 103-PNM_PROFISSIONAL_SOLICITANTE
                                                           , NULL -- 104-PCD_MOTIVO_CONTIGENCIAL      - MOTIVO CONTIGENCIA
                                                           , LPAD(rPedidoAutorizacao.CD_UNIMED_ORIGEM, 3, '0') -- 105-PCD_UNIMED_ORIGEM
                                                           , LPAD(rPedidoAutorizacao.CD_UNIMED_ATEND, 3, '0') -- 106-PCD_UNIMED_EXECUTORA
                                                           , NULL -- 107-PCD_VIA_CARTAO
                                                           , rPedidoAutorizacao.TP_REDE_MIN -- 108-PTP_REDE_MIN
                                                           , rPedidoAutorizacao.CD_IBGE -- 109-PCD_IBGE
                                                           , NULL -- 110 - PCD_TISS_CONSELHO_PROF_SOL
                                                           , NULL -- 111 - PUF_CONSELHO_PROF_SOLC
                                                           , NULL -- 112 - PNR_REG_CONSELHO_PROF_SOLIC
                                                           , NULL -- 113 - PCD_CLASSIFICACAO_TUMOR
                                                           , NULL -- 114 - PCD_CLASSIFICACAO_NODULO
                                                           , NULL -- 115 - PQTD_DIAS_CICLO
                                                           , NULL -- 116 - CD_CLASSIFICACAO_METASTASE
                                                           , NULL -- 117 - PCD_IDENTIFICACAO_BENEFICIARIO
                                                           , rPedidoAutorizacao.TP_ETAPA_AUTORIZACAO  -- 118 - PCD_ETAPA_AUTORIZACAO
                                                           , NULL -- 119 - PCD_MOT_AUSENCIA_COD_VALIDACAO
                                                           , NULL -- 120 - PCD_VALIDACAO
                                                           , NULL -- 121 - PCD_PRESTADOR_EMISSAO_GUIA
                                                           , NULL -- 122 - PCD_TIP_ACOMODACAO
                                                           , NULL -- 123 - PNM_PRESTADOR_EXECUTOR_PF
                                                           , NULL -- 124 - PCD_TISS_CONSELHO_PROF_EXEC_PF
                                                           , NULL -- 125 - PNR_REG_CONSELHO_PROFI_EXEC
                                                           , NULL -- 126 - PUF_CONSELHO_PROFISSIONAL_EXEC
                                                           , NULL -- 127 - PCD_ESPECIALIDADE_EXECUTANTE
                                                           , NULL -- 128 - PDT_EMISSAO
                                                           , NULL -- 129 - PDS_PLANO_BENEF
                                                           , NULL -- 130 - PDS_NOME_EMPRESA
                                                           , NULL -- 131 - PNR_TELEFONE_BENEF
                                                           , NULL -- 132 - PNM_TITULAR_BENEF
                                                           , NULL -- 133 - PNR_REGISTRO_ANS_ANEXO
                                                           , NULL -- 134 - PNR_GUIA_ANEXO
                                                           , NULL -- 135 - PNR_GUIA_REFERENCIADA_ANEXO
                                                           , NULL -- 136 - PNR_GUIA_OPERADORA_ANEXO
                                                           , NULL -- 137 - PNM_BENEFICIARIO_ANEXO
                                                           , NULL -- 138 - PNR_CARTEIRA_ANEXO
                                                           , NULL -- 139 - PSN_DOENCA_PERIODONTAL
                                                           , NULL -- 140 - PSN_ALTERACAO_TECIDO_MOLE
                                                           , NULL -- 141 - PDS_OBSERVACAO_ANEXO
                                                           , NULL -- 142 - PCD_REEMBOLSO
                                                           , rPedidoAutorizacao.NR_TOKEN --143 - NR_TOKEN
                                                           );
                vNrGuiaTem := vNrGuia;
              EXCEPTION
                WHEN OTHERS THEN
                  vCdGlosa      := '4001';
                  vDsGlosa      := REPLACE('ERRO NA AUTORIZA_GUIA. ERRO: ' ||
                                           SQLERRM || ' LINHA DO ERRO: ' ||
                                           DBMS_UTILITY.FORMAT_ERROR_BACKTRACE, Chr(13) ||
                                            Chr(10));
                  vExcecao      := SQLERRM;
                  vExcecaoLinha := DBMS_UTILITY.FORMAT_ERROR_BACKTRACE;
                  SELECT DBAPS.SEQ_PTU_MENSAGEM.NEXTVAL
                    INTO nIdPtuMensagemLog
                    FROM SYS.DUAL;
                  -- INSERINDO NO LOG DE ERROS
                  INSERT INTO DBAPS.PTU_MENSAGEM_LOG
                    (CD_PTU_MENSAGEM_LOG
                    ,CD_PTU_MENSAGEM
                    ,DT_LOG
                    ,DS_LOG)
                  VALUES
                    (nIdPtuMensagemLog --CD_PTU_MENSAGEM_LOG
                    ,P_ID_PTU_MENSAGEM --CD_PTU_MENSAGEM
                    ,SYSDATE --DT_LOG
                    ,'ERRO: ' || vExcecao || ' LINHA DO ERRO: ' ||
                     vExcecaoLinha --DS_LOG
                     );
              END; -- END - AUTORIZA_GUIA
            END IF; --ENDIF QUANTIDADE DE PROCEDIMENTOS
            IF vNrGuia IS NULL THEN
              INSERE_RESPOSTA_PADRAO(nIdPtuMensagem, rPedidoAutorizacao.CD_PTU_PEDIDO_AUTORIZACAO, vDsGlosa, 1);
            ELSE
              BEGIN
                /**
                * INSERINDO OS DADOS AUTORIZADOS
                * SE GUIA FOI INSERIDA
                */
                UPDATE DBAPS.GUIA
                   SET TP_FLUXO_PTU_WS               = 'SERVER'
                      ,CD_PTU_MENSAGEM_ORIGEM        = nIdPtuMensagem --P_ID_PTU_AUTORIZACAO
                      ,CD_PTU_MENSAGEM_DESTINO       = rPedidoAutorizacao.NR_TRANSACAO_PRESTADORA --nIdPtuMensagem
                      ,CD_UNIMED_ORIGEM              = LPAD(rPedidoAutorizacao.CD_UNIMED_ORIGEM, 3, '0')
                      ,CD_UNIMED_EXECUTORA           = LPAD(rPedidoAutorizacao.CD_UNIMED_ATEND, 3, '0')
                      ,CD_UNIMED_SOLICITANTE         = LPAD(rPedidoAutorizacao.CD_UNIMED_ATEND, 3, '0')
                      ,CD_UNI_SOLICIT_EVENTUAL       = LPAD(rPedidoAutorizacao.CD_PRESTADOR_REQUI_UNIMED, 3, '0')
                      ,CD_PREST_SOLICIT_EVENTUAL     = rPedidoAutorizacao.CD_PRESTADOR_REQUISITANTE
                      ,CD_UNI_EXEC_EVENTUAL          = LPAD(rPedidoAutorizacao.CD_PRESTADOR_UNIMED, 3, '0')
                      ,CD_PREST_EXEC_EVENTUAL        = rPedidoAutorizacao.CD_PRESTADOR
                      ,NM_PREST_EXEC_EVENTUAL        = rPedidoAutorizacao.NM_PRESTADOR
                      ,TP_SEXO                       = DECODE(rPedidoAutorizacao.TP_SEXO, 1, 'M', 3, 'F')
                      ,NR_IDADE_BENEFICIARIO         = rPedidoAutorizacao.NR_IDADE
                      ,NR_VIA_CARTAO                 = rPedidoAutorizacao.NR_VIA_CARTAO
                      ,CD_CID                        = rPedidoAutorizacao.CD_CID
                      ,CD_PTU_MENS_ORDEM_SERVICO_ORI = rPedidoAutorizacao.NR_IDENT_ORDEM_SERVICO
                      ,SN_ORDEM_SERVICO              = rPedidoAutorizacao.SN_ORDEM_SERVICO
                      ,CD_INDICADOR_ACIDENTE         = rPedidoAutorizacao.TP_ACIDENTE
                      ,SN_LIMINAR                    = rPedidoAutorizacao.SN_LIMINAR
                      ,CD_CLASSIFICACAO_METASTASE    = DECODE(vSnAnexoQuimio, 'S', rPedidoAutorizacao.CL_METASTASE, NULL)
                      ,CD_CLASSIFICACAO_NODULO       = DECODE(vSnAnexoQuimio, 'S', rPedidoAutorizacao.CL_NODULO, NULL)
                      ,CD_CLASSIFICACAO_TUMOR        = DECODE(vSnAnexoQuimio, 'S', rPedidoAutorizacao.CL_TUMOR, NULL)
                 WHERE NR_GUIA = vNrGuia;
                --COMPLEMENTO DE INTERNACAO - ATUALIZADO TIPO DE ACOMODACAO PARA O TIPO DA GUIA PAI (POIS NAO VEM NO NOVO)
                IF rPedidoAutorizacao.TP_ACOMODACAO_GUIA_PAI IS NULL THEN
                  UPDATE DBAPS.GUIA
                     SET CD_TIP_ACOMODACAO = rPedidoAutorizacao.TP_ACOMODACAO_GUIA_PAI
                   WHERE NR_GUIA = vNrGuia
                     AND CD_TIP_ACOMODACAO IS NULL
                     AND NR_GUIA_TEM IS NOT NULL;
                END IF;
                IF ((rQtdAnexosPedido.QT_ANEXO = 0 AND
                   rQtdAnexosPedido.QT_NAO_ANEXO > 0) OR
                   rQtdAnexosPedido.QT_ANEXO = 1) THEN
                  --
                  FOR rSolicitacaoProcedimento IN cPedidoAutorizacaoItem(rPedidoAutorizacao.CD_PTU_PEDIDO_AUTORIZACAO, NULL) LOOP

                    --REGRA DO PACOTE (TP_TABELA = 98)
          rProcedimentoPacote.CD_PROCEDIMENTO := NULL;
                    IF rSolicitacaoProcedimento.TP_TABELA = '98' THEN
                      OPEN cProcedimentoPacote(vCdUnimedPrestadora, rSolicitacaoProcedimento.CD_SERVICO);
                      FETCH cProcedimentoPacote
                        INTO rProcedimentoPacote;
                      CLOSE cProcedimentoPacote;
                    END IF;
          --
                    UPDATE DBAPS.ITGUIA
                       SET DS_PROCEDIMENTO        = rSolicitacaoProcedimento.DS_SERVICO
                          ,CD_UNIDADE_MEDIDA      = rSolicitacaoProcedimento.UNI_MEDIDA_MED
                          ,QT_TOTAL_DOSAGEM_CICLO = rSolicitacaoProcedimento.QT_TOTAL_DOSAGEM_CICLO
                          ,SN_PACOTE_PTU          = rSolicitacaoProcedimento.SN_PACOTE
                          ,TP_INDICADOR_ANEXO     = rSolicitacaoProcedimento.TP_ANEXO
                          ,VL_PROCEDIMENTO        = Nvl(Nvl(rSolicitacaoProcedimento.VL_UNIT_SERVICO, rSolicitacaoProcedimento.VL_MONETARIO), VL_PROCEDIMENTO)
                          ,TP_TABELA_INTERCAMBIO  = LPad(rSolicitacaoProcedimento.TP_TABELA,2,'0')
                          ,CD_SERVICO_PTU        =  rSolicitacaoProcedimento.CD_SERVICO
                     WHERE NR_GUIA = vNrGuia
                       AND NR_SQ_ITEM_PTU =
                           rSolicitacaoProcedimento.SQ_ITEM
                       AND CD_PROCEDIMENTO = Nvl(rProcedimentoPacote.CD_PROCEDIMENTO, rSolicitacaoProcedimento.CD_PROCEDIMENTO);
                  END LOOP;
                ELSIF (rQtdAnexosPedido.QT_ANEXO > 1)
                      AND rGuia.NR_GUIA IS NULL THEN
                      --
                  FOR rSolicitacaoProcedimento IN cPedidoAutorizacaoItem(rPedidoAutorizacao.CD_PTU_PEDIDO_AUTORIZACAO, 9) LOOP
                    UPDATE DBAPS.ITGUIA
                       SET DS_PROCEDIMENTO        = rSolicitacaoProcedimento.DS_SERVICO
                          ,CD_UNIDADE_MEDIDA      = rSolicitacaoProcedimento.UNI_MEDIDA_MED
                          ,QT_TOTAL_DOSAGEM_CICLO = rSolicitacaoProcedimento.QT_TOTAL_DOSAGEM_CICLO
                          ,SN_PACOTE_PTU          = rSolicitacaoProcedimento.SN_PACOTE
                          ,TP_INDICADOR_ANEXO     = rSolicitacaoProcedimento.TP_ANEXO
                          ,VL_PROCEDIMENTO        = Nvl(Nvl(rSolicitacaoProcedimento.VL_UNIT_SERVICO, rSolicitacaoProcedimento.VL_MONETARIO), VL_PROCEDIMENTO)
                          ,TP_TABELA_INTERCAMBIO  = LPad(rSolicitacaoProcedimento.TP_TABELA,2,'0')
                          ,CD_SERVICO_PTU        =  rSolicitacaoProcedimento.CD_SERVICO
                     WHERE NR_GUIA = vNrGuia
                       AND NR_SQ_ITEM_PTU =
                           RSOLICITACAOPROCEDIMENTO.SQ_ITEM
                       AND CD_PROCEDIMENTO = RSOLICITACAOPROCEDIMENTO.CD_PROCEDIMENTO;
                  END LOOP;
                END IF;
              EXCEPTION
                WHEN OTHERS THEN
                  vCdGlosa := '4001';
                  vDsGlosa := REPLACE('ERRO NA AUTORIZA_GUIA. ERRO: ' ||
                                      SQLERRM || ' LINHA DO ERRO: ' ||
                                      DBMS_UTILITY.FORMAT_ERROR_BACKTRACE, Chr(13) ||
                                       Chr(10));
                  SELECT DBAPS.SEQ_PTU_MENSAGEM.NEXTVAL
                    INTO nIdPtuMensagemLog
                    FROM SYS.DUAL;
                  -- INSERINDO NO LOG DE ERROS
                  INSERT INTO DBAPS.PTU_MENSAGEM_LOG
                    (CD_PTU_MENSAGEM_LOG
                    ,CD_PTU_MENSAGEM
                    ,DT_LOG
                    ,DS_LOG)
                  VALUES
                    (nIdPtuMensagemLog --CD_PTU_MENSAGEM_LOG
                    ,P_ID_PTU_MENSAGEM --CD_PTU_MENSAGEM
                    ,SYSDATE --DT_LOG
                    ,vDsGlosa --DS_LOG
                     );
              END; --ENDIF EXCEPTION
              /**
              * VERIFICA SE HA ANEXOS.
              *
              * CADA TRANSACAO DE PEDIDO DE AUTORIZACAO DO PTU ONLINE PODE ENVIAR ATE TRES 3 (TRES) ANEXOS
              * SIMULTANEOS (OPME, QUIMIOTERAPIA E RADIOTERAPIA). O CAMPO 'TP_ANEXO' DA TABELA REFERENTE AO
              * BLOCO DE SERVICO DO PEDIDO (DBAPS.PTU_PEDIDO_AUTORIZACAO_ITEM) E RESPONSAVEL POR DEFINIR O
              * TIPO DO ANEXO DO PROCEDIMENTO/SERVICO
              *
              */
              IF rQtdAnexosPedido.QT_ANEXO > 1
                 AND rGuia.NR_GUIA IS NULL THEN
                -- AUTORIZACAO DO ANEXO DE QUIMIOTERAPIA.
                IF (rQtdAnexosPedido.QT_ANEXO_QUIMIO > 0) THEN
                  -- TIPO DO ANEXO
                  SELECT CD_TIPO_ATENDIMENTO
                    INTO vNrTpAnexoQuimio
                    FROM DBAPS.TIPO_ATENDIMENTO
                   WHERE TP_GUIA = 'Q'
                     AND ROWNUM = 1;
                  BEGIN
                    -- CONCATENANDO PROCEDIMENTOS
                    vCdProcedimento := '*';
                    IF vCdGlosa IS NULL THEN
                    --
                      FOR rSolicitacaoProcedimento IN cPedidoAutorizacaoItem(rPedidoAutorizacao.CD_PTU_PEDIDO_AUTORIZACAO, 1) LOOP
                        vCdProcedimentoPacote := NULL;
                        IF rSolicitacaoProcedimento.TP_TABELA = '98' THEN
                        --VERIFICANDO SE O PROCEDIMENTO DA SOLICITACAO EXISTE, CASO NAO EXISTA, SER� CRIADO AQUI
                          vCdProcedimentoPacote := DBAPS.FNC_PACOTE_UNIMED(rSolicitacaoProcedimento.CD_PROCEDIMENTO,
                                                                          vCdUnimedPrestadora);
                        END IF; -- rSolicitacaoProcedimento.TP_TABELA = '98'
                        vCdProcedimento := vCdProcedimento ||
                                           Nvl(vCdProcedimentoPacote, rSolicitacaoProcedimento.CD_PROCEDIMENTO) || '*' || -- CD_PROCEDIMENTO
                                           rSolicitacaoProcedimento.QT_SERVICO || '*' || -- QT_PROCEDIMENO
                                           Nvl(TO_CHAR(rSolicitacaoProcedimento.SQ_ITEM), 'NULL') || '*' || -- CD_REGIAO_DENTE
                                          /*CD_FACES_DENTES_ODONTO*/
                                           'NULL' || '*' || -- CD_FACES_DENTES_ODONTO
                                           Nvl(TO_CHAR(rSolicitacaoProcedimento.DT_PROV), 'NULL') || '*' || -- DT_PREVISTA
                                           Nvl(TO_CHAR(rSolicitacaoProcedimento.CD_VIA_ADMIN), 'NULL') || '*' || -- CD_VIA_ADM
                                           Nvl(TO_CHAR(rSolicitacaoProcedimento.TP_ORDEM), 'NULL') || '*' || -- NR_ORDEM_PREFERENCIA
                                           Nvl(TO_CHAR(rSolicitacaoProcedimento.VL_MONETARIO), 'NULL') || '*' || -- VL_SOLICITADO
                                           Nvl(TO_CHAR(rSolicitacaoProcedimento.CD_ANVISA), 'NULL') || '*' || -- NR_ANVISA
                                           Nvl(TO_CHAR(REPLACE(rSolicitacaoProcedimento.CD_REFERENCIA_MATERIAL_FAB, '*')), 'NULL') || '*' || -- CD_MATERIAL_FABRICANTE
                                          /*NR_AUTORIZACAO_FUNCIONAMENTO*/
                                           'NULL' || '*' || -- NR_AUTORIZACAO_FUNCIONAMENTO
                                          /*SN_PRESTADOR_EXECUTOR_OPME*/
                                           'NULL' || '*' || -- SN_PRESTADOR_EXECUTOR_OPME
                                           NVL(TO_CHAR(rSolicitacaoProcedimento.QT_FREQUENCIA), 'NULL') || '*' || -- QT_SOLICITADO_DIA
                                          /*CD_UNIDADE_MEDIDA*/
                                           'NULL' || '*' || -- CD_UNIDADE_MEDIDA
                                          /*QT_TOTAL_DOSAGEM_CICLO*/
                                           'NULL' || '*'; -- QT_TOTAL_DOSAGEM_CICLO
                      END LOOP;
                    END IF; -- END IF - CONCATENANDO PROCEDIMENTOS
                    vDsMensagem           := NULL;
                    vRetornoAutorizaAnexo := DBAPS.AUTORIZA_GUIA(NVL(P_CD_MULTI_EMPRESA, DBAMV.PKG_MV2000.LE_EMPRESA) -- 1-PCD_MULTI_EMPRESA              - HOSPITAL/OPERADORA (MULTI-EMPRESA
                                                                , vCdMatricula -- 2-PCD_MATRICULA                  - MATRICULA DO BENEFICIARIO
                                                                , vNrTpAnexoQuimio -- 3-PCD_TIPO_GUIA                  - TIPO DE ATENDIMENTO (GUIA)
                                                                , vTpInternacao -- 4-PTP_INTERNACAO                 - TIPO DE INTERNACAO
                                                                , nQtDiasSolicitados -- 5-PNR_DIAS_AUTORIZACAO           - NUMERO DE DIAS SOLICITADOS
                                                                , nCdPrestador -- 6-PCD_PRESTADOR                  - PRESTADOR EXECUTOR
                                                                , nCdEspecialidade -- 7-PCD_ESPECIALIDADE              - ESPECIALIDADE DO PRESTADOR EXECUTANTE (NAO VAI SER MAIS USADA A ESPECIALIDADE COMO UM CAMPO DE VALIDACAO)
                                                                , vCdProcedimento -- 8-PSTRING_PROC                   - PROCEDIMENTOS (SEPARADOS POR '*')
                                                                , 'S' -- 9-PSN_SOLICITA_AUTORIZACAO       - INDICA SE E UMA SOLICITACAO DE GUIA
                                                                , Nvl(dDtSugeridaInternacao, TRUNC(SYSDATE)) -- 10-PDT_PREVISAO_EXECUCAO         - DATA DE PREVISAO DE EXECUCAO
                                                                , NULL -- 11-PDS_SENHA_AUTORIZACAO         - SENHA DE AUTORIZACAO DO PRESTADOR
                                                                , vNmBeneficiario -- 12-PNM_USUARIO                   - RETORNO DO NOME DO BENEFICIARIO
                                                                , vTpSexo -- 13-PTP_SEXO                      - RETORNO DO SEXO DO BENEFICIARIO
                                                                , vNrCpfBeneficiario -- 14-PNR_CPF                       - RETORNO DO CPF DO BENEFICIARIO
                                                                , vNrRG -- 15-PNR_RG                        - RETORNO DO RG DO BENEFICIARIO
                                                                , vOrgaoExpeditor -- 16-PDS_ORGAO_EXPEDITOR           - RETORNO DO ORGAO EXPEDIDOR DO BENEFICIARIO
                                                                , vNmConjuge -- 17-PNM_CONJUGE                   - RETORNO DO NOME DO CONJUGE DO BENEFICIARIO
                                                                , vNmMae -- 18-PNM_MAE                       - RETORNO DO NOME DA MAE DO BENEFICIARIO
                                                                , vNmPai -- 19-PNM_PAI                       - RETORNO DO NOME DO PAI DO BENEFICIARIO
                                                                , dDtNascimento -- 20-PDT_NASCIMENTO                - RETORNO DA DATA DE NASCIMENTO DO BENEFICIARIO
                                                                , vEndereco -- 21-PDS_ENDERECO                  - RETORNO DO ENDERECO DO BENEFICIARIO
                                                                , nNrEndereco -- 22-PNR_ENDERECO                  - RETORNO DO NUMERO DO ENDERECO DO BENEFICIARIO
                                                                , vComplemento -- 23-PDS_COMPLEMENTO               - RETORNO DO COMPLEMENTO DO ENDERECO DO BENEFICIARIO
                                                                , vBairro -- 24-PDS_BAIRRO                    - RETORNO DO BAIXO DO BENEFICIARIO
                                                                , nCdCidade -- 25-PCD_CIDADE                    - RETORNO DO CODIGO DA CIDADE DO BENEFICIARIO
                                                                , vNrCEP -- 26-PNR_CEP                       - RETORNO DO NUMERO DO CEP DO BENEFICIARIO
                                                                , vNrTelefone -- 27-PNR_TELEFONE                  - RETORNO DO NUMERO DO TELEFONE DO BENEFICIARIO
                                                                , nNrGuiaQuimio -- 28-PNR_GUIA                      - RETORNO DO NUMERO DA GUIA AUTORIZADA
                                                                , vDtValidadeCarteira -- 29-PDT_VALID_CART                - RETORNO DA DATA VALIDADE DA CARTEIRA
                                                                , vNmTitular -- 30-PNM_TITULAR                   - RETORNO DO NOME DO TITULAR (SE BENEFICIARIO DEPENDENTE OU AGREGADO)
                                                                , vTpGuia -- 31-PDS_TIPO_GUIA                 - RETORNO DA DESCRICAO DO TIPO DE ATENDIMENTO (GUIA)
                                                                , vNmPrestador -- 32-PNM_PRESTADOR                 - RETORNO DO NOME DO PRESTADOR EXECUTOR
                                                                , vEspecialidade -- 33-PDS_ESPECIALIDADE             - RETORNO DA ESPECIALIDADE DO PRESTADOR EXECUTOR
                                                                , dDtVencimentoGuia -- 34-PDT_VENCIMENTO_GUIA           - RETORNO DA DATA DE VENCIMENTO DA GUIA
                                                                , nCdPlano -- 35-PCD_PLANO                     - RETORNO DO CODIGO DO PLANO DO BENEFICIARIO
                                                                , vDsPlano -- 36-PDS_PLANO                     - RETORNO DA DESCRICAO DO PLANO DO BENEFICIARIO
                                                                , vEmpresa -- 37-PDS_EMPRESA                   - RETORNO DA DESCRICAO DA EMPRESA DO BENEFICIARIO (PARA CONTRATOS COLETIVOS)
                                                                , vDsMensagem -- 38-PDS_MENSAGEM                  - RETORNO DA MENSAGEM DE ERRO DA ANALISE DA GUIA
                                                                , 'PTU' -- 39-PTP_ORIGEM                    - ORIGEM: MVS - MVSAUDE; MV2-MV2000i ;INT-INTERNET OU WS-WEBSERVICE
                                                                , nCdPrestadorSolicitante -- 40-PCD_PRESTADOR_SOLICITANTE     - CODIGO DO PRESTADOR SOLICITANTE
                                                                , nCdAutorizador -- 41-PCD_AUTORIZADOR               - CODIGO DO AUTORIZADOR DA GUIA
                                                                , nCdMedicoSolicitante -- 42-PCD_MEDICO_SOLICITANTE        - CODIGO DO MEDICO SOLICITANTE (NAO HA ESSE ITEM NAS PASSAGENS DO TISS)
                                                                , NULL -- 43-PNR_GUIA_PRESTADOR            - NUMERO DA GUIA DO PRESTADOR
                                                                , NULL -- 44-PNR_GUIA_EXTERNA              - NUMERO DA GUIA EXTERNA DA OPERADORA
                                                                , vNrGuiaTem -- 45-PNR_GUIA_TEM                  - CODIGO DA GUIA PAI
                                                                , NULL -- 46-PCD_ESPECIALIDADE_SOLICITANTE - CODIGO DA ESPECIALIDADE DO PRESTADOR SOLICITANTE
                                                                , NULL -- 47-PCD_PRESTADOR_SOLICITADO      - CODIGO DO PRESTADOR EXECUTOR SOLICITADO
                                                                , vTpCaraterSolicInter -- 48-PTP_CARATER_SOLIC_INTER       - CODIGO DO CARACTER DA EXECUCAO
                                                                , NULL -- 49-PCD_REGIME_INTERNACAO         - CODIGO DO REGIME DE INTERNACAO
                                                                , NULL -- 50-PCD_PRESTADOR_EXECUTOR_PF     - CODIGO DO PROFISSIONAL EXECUTOR
                                                                 /* ANEXO DE QUIMIOTERAPIA */, vCdCid1Quimio -- 51-PCD_CID                       - CID PRINCIPAL
                                                                 /* ANEXO DE QUIMIOTERAPIA */, vCdCid2Quimio -- 52-PCD_CID2                      - CID (2)
                                                                 /* ANEXO DE QUIMIOTERAPIA */, vCdCid3Quimio -- 53-PCD_CID3                      - CID (3)
                                                                 /* ANEXO DE QUIMIOTERAPIA */, vCdCid4Quimio -- 54-PCD_CID4                      - CID (4)
                                                                , nQtDiasSolicitados -- 55-PNR_DIAS_SOLICITACAO          - NUMERO DE DIAS SOLICITADO
                                                                , NULL -- 56-PCD_TIPO_DOENCA               - CODIGO DO TIPO DE DOENCA
                                                                , NULL -- 57-PNR_TEMPO_DOENCA              - VALOR DO TEMPO DA DOENCA
                                                                , nCodigoIndicadorAcidente -- 58-PCD_INDICADOR_ACIDENTE        - CODIGO DA INDICACAO DE ACIDENTE
                                                                , NULL -- 59-PCD_TIPO_ATENDIMENTO_TISS     - CODIGO DO TIPO DE ATENDIMENTO TISS (NAO INFORMADO NO TISS)
                                                                , NULL -- 60-PCD_TIPO_SAIDA_GUIA_SADT      - CODIGO DO TIPO DE SAIDA DA GUIA (NAO INFORMADO NO TISS)
                                                                , rPedidoAutorizacao.DS_OBSERVACAO -- 61-PDS_OBSERVACAO                - OBSERVACAO
                                                                , rPedidoAutorizacao.DS_INDICACAO_CLINICA -- 62-PDS_DIAGNOSTICO               - INDICACAO CLINICA
                                                                , NULL -- 63-PCD_UNIDADE_TEMPO_DOENCA      - CODIGO DA UNIDADE DO TEMPO DA DOENCA
                                                                , NULL -- 64-PCD_TIPO_CONSULTA             - TIPO DA CONSULTA
                                                                , NULL -- 65-PDS_ANEXO_TEXTO               - DESCRICAO DO ANEXO
                                                                , nCdPrestadorEndereco -- 66-PCD_PRESTADOR_ENDERECO        - CODIGO DO PRESTADOR NO ENDERECO
                                                                , rPedidoAutorizacao.SN_RN -- 67-PSN_ATENDIMENTO_RECEM_NATO    - ATENDIMENTO RECEM NATO
                                                                , NULL -- 68-PDT_TERMINO_TRATAMENTO_ODONTO - DATA DO TERMINO DO TRATAMENTO ODONTOLOGICO
                                                                , NULL -- 69-PTP_ATENDIMENTO_ODONTO        - TIPO DO ATENDIMENTO ODONTOLOGICO
                                                                , NULL -- 70-PTP_FATURAMENTO_ODONTO        - TIPO DO FATURAMENTO ODONTOLOGICO
                                                                 /* ANEXO DE QUIMIOTERAPIA */, vNrTelProfSolicitanteQuimio -- 71-PNR_TELEFONE_PROF_SOLIC       - NUMERO DO TELEFONE DO PROFISSIONAL SOLICITANTE
                                                                 /* ANEXO DE QUIMIOTERAPIA */, vDsEmailProfSolicitanteQuimio -- 72-PDS_EMAIL_PROF_SOLIC          - EMAIL DO PROFISSIONAL SOLICITANTE
                                                                 /* ANEXO DE QUIMIOTERAPIA */, Nvl(vDtDiagnosticoQuimio, TRUNC(SYSDATE)) -- 73-PDT_DIAGNOSTICO               - DATA DO DIAGNOSTICO
                                                                , NULL -- 74-PCD_DIAGNOSTICO_IMAGEM        - CODIGO DO DIAGNOSTICO POR IMAGEM
                                                                 /* ANEXO DE QUIMIOTERAPIA */, vTpEstadiamentoQuimio -- 75-PCD_ESTADIAMENTO              - CODIGO DO ESTADIAMENTO
                                                                 /* ANEXO DE QUIMIOTERAPIA */, vTpEcogQuimio -- 76-PCD_ECOG                      - CODIGO DO ECOG
                                                                 /* ANEXO DE QUIMIOTERAPIA */, vTpFinalidadeQuimio -- 77-PCD_FINALIDADE_TRATAMENTO     - CODIGO DA FINALIDADE DO TRATAMENTO
                                                                 /* ANEXO DE QUIMIOTERAPIA */, vDsDiagCitHistQuimio -- 78-PDS_DIAGNOSTICO_CITOHISTO     - DIAGNOSTICO HISPATOLOGICO
                                                                 /* ANEXO DE QUIMIOTERAPIA */, vDsInfoRelevantesQuimio -- 79-PDS_INFORMACOES_RELEVANTES    - INFORMACOES RELEVANTES
                                                                 /* ANEXO DE QUIMIOTERAPIA */, vDsCirurgiaQuimio -- 80-PDS_CIRURGIA                  - CIRURGIA
                                                                 /* ANEXO DE QUIMIOTERAPIA */, vDtCirurgiaQuimio -- 81-PDT_REALIZACAO                - DATA DA REALIZACAO
                                                                 /* ANEXO DE QUIMIOTERAPIA */, vDsQuimio -- 82-PDS_QUIMIOTERAPIA             - QUIMIOTERAPIA
                                                                 /* ANEXO DE QUIMIOTERAPIA */, Nvl(vDtIrradiacaoQuimio, TRUNC(SYSDATE)) -- 83-PDT_APLICACAO                 - DATA DA APLICACAO
                                                                , NULL -- 84-PNR_CAMPOS                    - NUMERO DE CAMPOS
                                                                , NULL -- 85-PNR_DOSE_DIA                  - NUMERO DE DOSE DIA
                                                                , NULL -- 86-PNR_DOSE_TOTAL                - TOTAL DE DOSES
                                                                , NULL -- 87-NR_TRATAMENTO_DIA             - NUMERO DE TRATAMENTO DIA
                                                                 /* ANEXO DE QUIMIOTERAPIA */, vNrPesoQuimio -- 88-PNR_PESO_BENEFICIARIO         - PESO DO BENEFICIARIO
                                                                 /* ANEXO DE QUIMIOTERAPIA */, vNrAlturaQuimio -- 89-PNR_ALTURA_BENEFICIARIO       - ALTURA DO BENEFICIARIO
                                                                 /* ANEXO DE QUIMIOTERAPIA */, vNrSupCorporalQuimio -- 90-PNR_SUPERFICIE_CORPORAL       - SUPERFICIE CORPORAL DO BENEFICIARIO
                                                                 /* ANEXO DE QUIMIOTERAPIA */, vNrCiclosQuimio -- 91-PNR_CICLO_PREVISTO            - NUMERO DE CICLOS PREVISTOS
                                                                 /* ANEXO DE QUIMIOTERAPIA */, vNrCicloAtualQuimio -- 92-PNR_CICLO_ATUAL               - NUMERO DO CICLO ATUAL
                                                                 /* ANEXO DE QUIMIOTERAPIA */, vNrIntervaloCiclosQuimio -- 93-PNR_INTERVALO_CICLO           - INTERVALO ENTRE CICLO
                                                                 /* ANEXO DE QUIMIOTERAPIA */, vDsPlanoTerapeuticoQuimio -- 94-PDS_PLANO_TERAPEUTICO         - PLANO TERAPEUTICO
                                                                 /* ANEXO DE QUIMIOTERAPIA */, vDsAreaIrradiadaQuimio -- 95-PDS_AREA_IRRADIADA            - AREA IRRADIADA
                                                                 /* ANEXO DE QUIMIOTERAPIA */, vTpQuimio -- 96-PCD_QUIMIOTERAPIA             - CODIGO DA QUIMIOTERAPIA
                                                                , Nvl(rPedidoAutorizacao.DS_VERSAO_TISS, P_VERSAO_TISS) -- 97-PCD_VERSAO_TISS               - A ATUAL VERSAO DO TISS
                                                                , Nvl(dDtSugeridaInternacao, TRUNC(SYSDATE)) -- 98-PDT_SUGERIDA_INTERNACAO
                                                                , NULL -- 99-PSN_PREVISAO_USO_OPME
                                                                 /* ANEXO DE QUIMIOTERAPIA */, vSnAnexoQuimio -- 100-PSN_PREVISAO_USO_QUIMIO
                                                                , rPedidoAutorizacao.DS_JUSTIFICATIVA_TECNICA -- 101-PDS_JUSTIFICATIVA_TECNICA
                                                                , NULL -- 102-PDS_ESPECIFICACAO_MATERIAL
                                                                , vNmProfSolicitanteQuimio -- 103-PNM_PROFISSIONAL_SOLICITANTE
                                                                , NULL -- 104-PCD_MOTIVO_CONTINGENCIAL
                                                                , LPAD(rPedidoAutorizacao.CD_UNIMED_ORIGEM, 3, '0') -- 105-PCD_UNIMED_ORIGEM
                                                                , LPAD(rPedidoAutorizacao.CD_UNIMED_ATEND, 3, '0') -- 106-PCD_UNIMED_EXECUTORA
                                                                , NULL -- 107-PCD_VIA_CARTAO
                                                                , rPedidoAutorizacao.TP_REDE_MIN -- 108-PTP_REDE_MIN
                                                                , rPedidoAutorizacao.CD_IBGE -- 109-PCD_IBGE
                                                                , NULL -- 110 - PCD_TISS_CONSELHO_PROF_SOL
                                                                , NULL -- 111 - PUF_CONSELHO_PROF_SOLC
                                                                , NULL -- 112 - PNR_REG_CONSELHO_PROF_SOLIC
                                                                , NULL -- 113 - PCD_CLASSIFICACAO_TUMOR
                                                                , NULL -- 114 - PCD_CLASSIFICACAO_NODULO
                                                                , NULL -- 115 - PQTD_DIAS_CICLO
                                                                , NULL -- 116 - CD_CLASSIFICACAO_METASTASE
                                                                , NULL -- 117 - PCD_IDENTIFICACAO_BENEFICIARIO
                                                                , rPedidoAutorizacao.TP_ETAPA_AUTORIZACAO  -- 118 - PCD_ETAPA_AUTORIZACAO
                                                                , NULL -- 119 - PCD_MOT_AUSENCIA_COD_VALIDACAO
                                                                , NULL -- 120 - PCD_VALIDACAO
                                                                , NULL -- 121 - PCD_PRESTADOR_EMISSAO_GUIA
                                                                , NULL -- 122 - PCD_TIP_ACOMODACAO
                                                                , NULL -- 123 - PNM_PRESTADOR_EXECUTOR_PF
                                                                , NULL -- 124 - PCD_TISS_CONSELHO_PROF_EXEC_PF
                                                                , NULL -- 125 - PNR_REG_CONSELHO_PROFI_EXEC
                                                                , NULL -- 126 - PUF_CONSELHO_PROFISSIONAL_EXEC
                                                                , NULL -- 127 - PCD_ESPECIALIDADE_EXECUTANTE
                                                                , NULL -- 128 - PDT_EMISSAO
                                                                , NULL -- 129 - PDS_PLANO_BENEF
                                                                , NULL -- 130 - PDS_NOME_EMPRESA
                                                                , NULL -- 131 - PNR_TELEFONE_BENEF
                                                                , NULL -- 132 - PNM_TITULAR_BENEF
                                                                , NULL -- 133 - PNR_REGISTRO_ANS_ANEXO
                                                                , NULL -- 134 - PNR_GUIA_ANEXO
                                                                , NULL -- 135 - PNR_GUIA_REFERENCIADA_ANEXO
                                                                , NULL -- 136 - PNR_GUIA_OPERADORA_ANEXO
                                                                , NULL -- 137 - PNM_BENEFICIARIO_ANEXO
                                                                , NULL -- 138 - PNR_CARTEIRA_ANEXO
                                                                , NULL -- 139 - PSN_DOENCA_PERIODONTAL
                                                                , NULL -- 140 - PSN_ALTERACAO_TECIDO_MOLE
                                                                , NULL -- 141 - PDS_OBSERVACAO_ANEXO
                                                                , NULL -- 142 - PCD_REEMBOLSO
                                                                , rPedidoAutorizacao.NR_TOKEN --143 - NR_TOKEN
                                                                );
                  EXCEPTION
                    WHEN OTHERS THEN
                      vCdGlosa      := '4001';
                      vDsGlosa      := REPLACE('ERRO NA AUTORIZA_GUIA. ERRO: ' ||
                                               SQLERRM ||
                                               ' LINHA DO ERRO: ' ||
                                               DBMS_UTILITY.FORMAT_ERROR_BACKTRACE, Chr(13) ||
                                                Chr(10));
                      vExcecao      := SQLERRM;
                      vExcecaoLinha := DBMS_UTILITY.FORMAT_ERROR_BACKTRACE;
                      SELECT DBAPS.SEQ_PTU_MENSAGEM.NEXTVAL
                        INTO nIdPtuMensagemLog
                        FROM SYS.DUAL;
                      -- INSERINDO NO LOG DE ERROS
                      INSERT INTO DBAPS.PTU_MENSAGEM_LOG
                        (CD_PTU_MENSAGEM_LOG
                        ,CD_PTU_MENSAGEM
                        ,DT_LOG
                        ,DS_LOG)
                      VALUES
                        (nIdPtuMensagemLog --CD_PTU_MENSAGEM_LOG
                        ,P_ID_PTU_MENSAGEM --CD_PTU_MENSAGEM
                        ,SYSDATE --DT_LOG
                        ,'ERRO: ' || vExcecao || ' LINHA DO ERRO: ' ||
                         vExcecaoLinha --DS_LOG
                         );
                  END; -- END - AUTORIZA ANEXO DE QUIMIOTERAPIA.
                  UPDATE DBAPS.GUIA
                     SET TP_FLUXO_PTU_WS               = 'SERVER'
                        ,CD_PTU_MENSAGEM_ORIGEM        = nIdPtuMensagem --P_ID_PTU_AUTORIZACAO
                        ,CD_PTU_MENSAGEM_DESTINO       = rPedidoAutorizacao.NR_TRANSACAO_PRESTADORA --nIdPtuMensagem
                        ,CD_UNIMED_ORIGEM              = LPAD(rPedidoAutorizacao.CD_UNIMED_ORIGEM, 3, '0')
                        ,CD_UNIMED_EXECUTORA           = LPAD(rPedidoAutorizacao.CD_UNIMED_ATEND, 3, '0')
                        ,CD_UNIMED_SOLICITANTE         = LPAD(rPedidoAutorizacao.CD_UNIMED_ATEND, 3, '0')
                        ,CD_UNI_SOLICIT_EVENTUAL       = LPAD(rPedidoAutorizacao.CD_PRESTADOR_REQUI_UNIMED, 3, '0')
                        ,CD_PREST_SOLICIT_EVENTUAL     = rPedidoAutorizacao.CD_PRESTADOR_REQUISITANTE
                        ,CD_UNI_EXEC_EVENTUAL          = LPAD(rPedidoAutorizacao.CD_PRESTADOR_UNIMED, 3, '0')
                        ,CD_PREST_EXEC_EVENTUAL        = rPedidoAutorizacao.CD_PRESTADOR
                        ,NM_PREST_EXEC_EVENTUAL        = rPedidoAutorizacao.NM_PRESTADOR
                        ,TP_SEXO                       = DECODE(rPedidoAutorizacao.TP_SEXO, 1, 'M', 3, 'F')
                        ,NR_IDADE_BENEFICIARIO         = rPedidoAutorizacao.NR_IDADE
                        ,NR_VIA_CARTAO                 = rPedidoAutorizacao.NR_VIA_CARTAO
                        ,CD_CID                        = rPedidoAutorizacao.CD_CID
                        ,CD_PTU_MENS_ORDEM_SERVICO_ORI = rPedidoAutorizacao.NR_IDENT_ORDEM_SERVICO
                        ,SN_ORDEM_SERVICO              = rPedidoAutorizacao.SN_ORDEM_SERVICO
                        ,CD_INDICADOR_ACIDENTE         = rPedidoAutorizacao.TP_ACIDENTE
                        ,SN_LIMINAR                    = rPedidoAutorizacao.SN_LIMINAR
                        ,CD_CLASSIFICACAO_METASTASE    = rPedidoAutorizacao.CL_METASTASE
                        ,CD_CLASSIFICACAO_NODULO       = rPedidoAutorizacao.CL_NODULO
                        ,CD_CLASSIFICACAO_TUMOR        = rPedidoAutorizacao.CL_TUMOR
                   WHERE NR_GUIA = nNrGuiaQuimio;
                  --
                  FOR rSolicitacaoProcedimento IN cPedidoAutorizacaoItem(rPedidoAutorizacao.CD_PTU_PEDIDO_AUTORIZACAO, 1) LOOP
                    UPDATE DBAPS.ITGUIA
                       SET DS_PROCEDIMENTO        = rSolicitacaoProcedimento.DS_SERVICO
                          ,TP_INDICADOR_ANEXO     = 1
                          ,CD_UNIDADE_MEDIDA      = rSolicitacaoProcedimento.UNI_MEDIDA_MED
                          ,QT_TOTAL_DOSAGEM_CICLO = rSolicitacaoProcedimento.QT_TOTAL_DOSAGEM_CICLO
                          ,SN_PACOTE_PTU          = rSolicitacaoProcedimento.SN_PACOTE
                          ,VL_PROCEDIMENTO        = Nvl(Nvl(rSolicitacaoProcedimento.VL_UNIT_SERVICO, rSolicitacaoProcedimento.VL_MONETARIO), VL_PROCEDIMENTO)
                          ,TP_TABELA_INTERCAMBIO  = LPad(rSolicitacaoProcedimento.TP_TABELA,2,'0')
                          ,CD_SERVICO_PTU        =  rSolicitacaoProcedimento.CD_SERVICO
                     WHERE NR_GUIA = nNrGuiaQuimio
                       AND NR_SQ_ITEM_PTU =
                           rSolicitacaoProcedimento.SQ_ITEM
                       AND CD_PROCEDIMENTO = rSolicitacaoProcedimento.CD_PROCEDIMENTO;
                  END LOOP;
                END IF; --ENDIF TIPO QUIMIO
                -- AUTORIZACAO DO ANEXO DE RADIOTERAPIA
                IF (rQtdAnexosPedido.QT_ANEXO_RADIO > 0)
                   AND rGuia.NR_GUIA IS NULL THEN
                  -- TIPO DO ANEXO
                  SELECT CD_TIPO_ATENDIMENTO
                    INTO vNrTpAnexoRadio
                    FROM DBAPS.TIPO_ATENDIMENTO
                   WHERE TP_GUIA = 'R'
                     AND ROWNUM = 1;
                  -- CONCATENANDO PROCEDIMENTOS
                  vCdProcedimento := '*';
                  IF vCdGlosa IS NULL THEN
                  --
                    FOR rSolicitacaoProcedimento IN cPedidoAutorizacaoItem(rPedidoAutorizacao.CD_PTU_PEDIDO_AUTORIZACAO, 2) LOOP
                       vCdProcedimentoPacote := NULL;
                      IF rSolicitacaoProcedimento.TP_TABELA = '98' THEN
                      --VERIFICANDO SE O PROCEDIMENTO DA SOLICITACAO EXISTE, CASO NAO EXISTA, SER� CRIADO AQUI
                        vCdProcedimentoPacote := DBAPS.FNC_PACOTE_UNIMED(rSolicitacaoProcedimento.CD_PROCEDIMENTO,
                                                                        vCdUnimedPrestadora);
                      END IF; -- rSolicitacaoProcedimento.TP_TABELA = '98'
                      vCdProcedimento := vCdProcedimento ||
                                         Nvl(vCdProcedimentoPacote, rSolicitacaoProcedimento.CD_PROCEDIMENTO)  || '*' || -- CD_PROCEDIMENTO
                                         rSolicitacaoProcedimento.QT_SERVICO || '*' || -- QT_PROCEDIMENO
                                         Nvl(TO_CHAR(rSolicitacaoProcedimento.SQ_ITEM), 'NULL') || '*' || -- CD_REGIAO_DENTE
                                        /*CD_FACES_DENTES_ODONTO*/
                                         'NULL' || '*' || -- CD_FACES_DENTES_ODONTO
                                         Nvl(TO_CHAR(rSolicitacaoProcedimento.DT_PROV), 'NULL') || '*' || -- DT_PREVISTA
                                         Nvl(TO_CHAR(rSolicitacaoProcedimento.CD_VIA_ADMIN), 'NULL') || '*' || -- CD_VIA_ADM
                                         Nvl(TO_CHAR(rSolicitacaoProcedimento.TP_ORDEM), 'NULL') || '*' || -- NR_ORDEM_PREFERENCIA
                                         Nvl(TO_CHAR(rSolicitacaoProcedimento.VL_MONETARIO), 'NULL') || '*' || -- VL_SOLICITADO
                                         Nvl(TO_CHAR(rSolicitacaoProcedimento.CD_ANVISA), 'NULL') || '*' || -- NR_ANVISA
                                         Nvl(TO_CHAR(REPLACE(rSolicitacaoProcedimento.CD_REFERENCIA_MATERIAL_FAB, '*')), 'NULL') || '*' || -- CD_MATERIAL_FABRICANTE
                                        /*NR_AUTORIZACAO_FUNCIONAMENTO*/
                                         'NULL' || '*' || -- NR_AUTORIZACAO_FUNCIONAMENTO
                                        /*SN_PRESTADOR_EXECUTOR_OPME*/
                                         'NULL' || '*' || -- SN_PRESTADOR_EXECUTOR_OPME
                                         NVL(TO_CHAR(rSolicitacaoProcedimento.QT_FREQUENCIA), 'NULL') || '*' || -- QT_SOLICITADO_DIA
                                        /*CD_UNIDADE_MEDIDA*/
                                         'NULL' || '*' || -- CD_UNIDADE_MEDIDA
                                        /*QT_TOTAL_DOSAGEM_CICLO*/
                                         'NULL' || '*'; --QT_TOTAL_DOSAGEM_CICLO
                    END LOOP;
                  END IF; -- END IF - CONCATENANDO PROCEDIMENTOS
                  -- AUTORIZACAO DO ANEXO DE RADIOTERAPIA.
                  BEGIN
                    vDsMensagem           := NULL;
                    vRetornoAutorizaAnexo := DBAPS.AUTORIZA_GUIA(NVL(P_CD_MULTI_EMPRESA, DBAMV.PKG_MV2000.LE_EMPRESA) -- 1-PCD_MULTI_EMPRESA              - HOSPITAL/OPERADORA (MULTI-EMPRESA
                                                                , vCdMatricula -- 2-PCD_MATRICULA                  - MATRICULA DO BENEFICIARIO
                                                                , vNrTpAnexoRadio -- 3-PCD_TIPO_GUIA                  - TIPO DE ATENDIMENTO (GUIA)
                                                                , vTpInternacao -- 4-PTP_INTERNACAO                 - TIPO DE INTERNACAO
                                                                , nQtDiasSolicitados -- 5-PNR_DIAS_AUTORIZACAO           - NUMERO DE DIAS SOLICITADOS
                                                                , nCdPrestador -- 6-PCD_PRESTADOR                  - PRESTADOR EXECUTOR
                                                                , nCdEspecialidade -- 7-PCD_ESPECIALIDADE              - ESPECIALIDADE DO PRESTADOR EXECUTANTE (NAO VAI SER MAIS USADA A ESPECIALIDADE COMO UM CAMPO DE VALIDACAO)
                                                                , vCdProcedimento -- 8-PSTRING_PROC                   - PROCEDIMENTOS (SEPARADOS POR '*')
                                                                , 'S' -- 9-PSN_SOLICITA_AUTORIZACAO       - INDICA SE E UMA SOLICITACAO DE GUIA
                                                                , Nvl(dDtSugeridaInternacao, TRUNC(SYSDATE)) -- 10-PDT_PREVISAO_EXECUCAO         - DATA DE PREVISAO DE EXECUCAO
                                                                , NULL -- 11-PDS_SENHA_AUTORIZACAO         - SENHA DE AUTORIZACAO DO PRESTADOR
                                                                , vNmBeneficiario -- 12-PNM_USUARIO                   - RETORNO DO NOME DO BENEFICIARIO
                                                                , vTpSexo -- 13-PTP_SEXO                      - RETORNO DO SEXO DO BENEFICIARIO
                                                                , vNrCpfBeneficiario -- 14-PNR_CPF                       - RETORNO DO CPF DO BENEFICIARIO
                                                                , vNrRG -- 15-PNR_RG                        - RETORNO DO RG DO BENEFICIARIO
                                                                , vOrgaoExpeditor -- 16-PDS_ORGAO_EXPEDITOR           - RETORNO DO ORGAO EXPEDIDOR DO BENEFICIARIO
                                                                , vNmConjuge -- 17-PNM_CONJUGE                   - RETORNO DO NOME DO CONJUGE DO BENEFICIARIO
                                                                , vNmMae -- 18-PNM_MAE                       - RETORNO DO NOME DA MAE DO BENEFICIARIO
                                                                , vNmPai -- 19-PNM_PAI                       - RETORNO DO NOME DO PAI DO BENEFICIARIO
                                                                , dDtNascimento -- 20-PDT_NASCIMENTO                - RETORNO DA DATA DE NASCIMENTO DO BENEFICIARIO
                                                                , vEndereco -- 21-PDS_ENDERECO                  - RETORNO DO ENDERECO DO BENEFICIARIO
                                                                , nNrEndereco -- 22-PNR_ENDERECO                  - RETORNO DO NUMERO DO ENDERECO DO BENEFICIARIO
                                                                , vComplemento -- 23-PDS_COMPLEMENTO               - RETORNO DO COMPLEMENTO DO ENDERECO DO BENEFICIARIO
                                                                , vBairro -- 24-PDS_BAIRRO                    - RETORNO DO BAIXO DO BENEFICIARIO
                                                                , nCdCidade -- 25-PCD_CIDADE                    - RETORNO DO CODIGO DA CIDADE DO BENEFICIARIO
                                                                , vNrCEP -- 26-PNR_CEP                       - RETORNO DO NUMERO DO CEP DO BENEFICIARIO
                                                                , vNrTelefone -- 27-PNR_TELEFONE                  - RETORNO DO NUMERO DO TELEFONE DO BENEFICIARIO
                                                                , nNrGuiaRadio -- 28-PNR_GUIA                      - RETORNO DO NUMERO DA GUIA AUTORIZADA
                                                                , vDtValidadeCarteira -- 29-PDT_VALID_CART                - RETORNO DA DATA VALIDADE DA CARTEIRA
                                                                , vNmTitular -- 30-PNM_TITULAR                   - RETORNO DO NOME DO TITULAR (SE BENEFICIARIO DEPENDENTE OU AGREGADO)
                                                                , vTpGuia -- 31-PDS_TIPO_GUIA                 - RETORNO DA DESCRICAO DO TIPO DE ATENDIMENTO (GUIA)
                                                                , vNmPrestador -- 32-PNM_PRESTADOR                 - RETORNO DO NOME DO PRESTADOR EXECUTOR
                                                                , vEspecialidade -- 33-PDS_ESPECIALIDADE             - RETORNO DA ESPECIALIDADE DO PRESTADOR EXECUTOR
                                                                , dDtVencimentoGuia -- 34-PDT_VENCIMENTO_GUIA           - RETORNO DA DATA DE VENCIMENTO DA GUIA
                                                                , nCdPlano -- 35-PCD_PLANO                     - RETORNO DO CODIGO DO PLANO DO BENEFICIARIO
                                                                , vDsPlano -- 36-PDS_PLANO                     - RETORNO DA DESCRICAO DO PLANO DO BENEFICIARIO
                                                                , vEmpresa -- 37-PDS_EMPRESA                   - RETORNO DA DESCRICAO DA EMPRESA DO BENEFICIARIO (PARA CONTRATOS COLETIVOS)
                                                                , vDsMensagem -- 38-PDS_MENSAGEM                  - RETORNO DA MENSAGEM DE ERRO DA ANALISE DA GUIA
                                                                , 'PTU' -- 39-PTP_ORIGEM                    - ORIGEM: MVS - MVSAUDE; MV2-MV2000i ;INT-INTERNET OU WS-WEBSERVICE
                                                                , nCdPrestadorSolicitante -- 40-PCD_PRESTADOR_SOLICITANTE     - CODIGO DO PRESTADOR SOLICITANTE
                                                                , nCdAutorizador -- 41-PCD_AUTORIZADOR               - CODIGO DO AUTORIZADOR DA GUIA
                                                                , nCdMedicoSolicitante -- 42-PCD_MEDICO_SOLICITANTE        - CODIGO DO MEDICO SOLICITANTE (NAO HA ESSE ITEM NAS PASSAGENS DO TISS)
                                                                , NULL -- 43-PNR_GUIA_PRESTADOR            - NUMERO DA GUIA DO PRESTADOR
                                                                , NULL -- 44-PNR_GUIA_EXTERNA              - NUMERO DA GUIA EXTERNA DA OPERADORA
                                                                , Nvl(vNrGuiaTem, nNrGuiaQuimio) -- 45-PNR_GUIA_TEM                  - CODIGO DA GUIA PAI
                                                                , NULL -- 46-PCD_ESPECIALIDADE_SOLICITANTE - CODIGO DA ESPECIALIDADE DO PRESTADOR SOLICITANTE
                                                                , NULL -- 47-PCD_PRESTADOR_SOLICITADO      - CODIGO DO PRESTADOR EXECUTOR SOLICITADO
                                                                , vTpCaraterSolicInter -- 48-PTP_CARATER_SOLIC_INTER       - CODIGO DO CARACTER DA EXECUCAO
                                                                , NULL -- 49-PCD_REGIME_INTERNACAO         - CODIGO DO REGIME DE INTERNACAO
                                                                , NULL -- 50-PCD_PRESTADOR_EXECUTOR_PF     - CODIGO DO PROFISSIONAL EXECUTOR
                                                                 /* ANEXO DE RADIOTERAPIA */, vCdCid1Radio -- 51-PCD_CID                       - CID PRINCIPAL
                                                                 /* ANEXO DE RADIOTERAPIA */, vCdCid2Radio -- 52-PCD_CID2                      - CID (2)
                                                                 /* ANEXO DE RADIOTERAPIA */, vCdCid3Radio -- 53-PCD_CID3                      - CID (3)
                                                                 /* ANEXO DE RADIOTERAPIA */, vCdCid4Radio -- 54-PCD_CID4                      - CID (4)
                                                                , nQtDiasSolicitados -- 55-PNR_DIAS_SOLICITACAO          - NUMERO DE DIAS SOLICITADO
                                                                , NULL -- 56-PCD_TIPO_DOENCA               - CODIGO DO TIPO DE DOENCA
                                                                , NULL -- 57-PNR_TEMPO_DOENCA              - VALOR DO TEMPO DA DOENCA
                                                                , nCodigoIndicadorAcidente -- 58-PCD_INDICADOR_ACIDENTE        - CODIGO DA INDICACAO DE ACIDENTE
                                                                , NULL -- 59-PCD_TIPO_ATENDIMENTO_TISS     - CODIGO DO TIPO DE ATENDIMENTO TISS (NAO INFORMADO NO TISS)
                                                                , NULL -- 60-PCD_TIPO_SAIDA_GUIA_SADT      - CODIGO DO TIPO DE SAIDA DA GUIA (NAO INFORMADO NO TISS)
                                                                , rPedidoAutorizacao.DS_OBSERVACAO -- 61-PDS_OBSERVACAO                - OBSERVACAO
                                                                , rPedidoAutorizacao.DS_INDICACAO_CLINICA -- 62-PDS_DIAGNOSTICO               - INDICACAO CLINICA
                                                                , NULL -- 63-PCD_UNIDADE_TEMPO_DOENCA      - CODIGO DA UNIDADE DO TEMPO DA DOENCA
                                                                , NULL -- 64-PCD_TIPO_CONSULTA             - TIPO DA CONSULTA
                                                                , NULL -- 65-PDS_ANEXO_TEXTO               - DESCRICAO DO ANEXO
                                                                , nCdPrestadorEndereco -- 66-PCD_PRESTADOR_ENDERECO        - CODIGO DO PRESTADOR NO ENDERECO
                                                                , rPedidoAutorizacao.SN_RN -- 67-PSN_ATENDIMENTO_RECEM_NATO    - ATENDIMENTO RECEM NATO
                                                                , NULL -- 68-PDT_TERMINO_TRATAMENTO_ODONTO - DATA DO TERMINO DO TRATAMENTO ODONTOLOGICO
                                                                , NULL -- 69-PTP_ATENDIMENTO_ODONTO        - TIPO DO ATENDIMENTO ODONTOLOGICO
                                                                , NULL -- 70-PTP_FATURAMENTO_ODONTO        - TIPO DO FATURAMENTO ODONTOLOGICO
                                                                 /* ANEXO DE RADIOTERAPIA */, vNrTelProfSolicitanteRadio -- 71-PNR_TELEFONE_PROF_SOLIC       - NUMERO DO TELEFONE DO PROFISSIONAL SOLICITANTE
                                                                 /* ANEXO DE RADIOTERAPIA */, vDsEmailProfSolicitanteRadio -- 72-PDS_EMAIL_PROF_SOLIC          - EMAIL DO PROFISSIONAL SOLICITANTE
                                                                 /* ANEXO DE RADIOTERAPIA */, Nvl(vDtDiagnosticoRadio, TRUNC(SYSDATE)) -- 73-PDT_DIAGNOSTICO               - DATA DO DIAGNOSTICO
                                                                 /* ANEXO DE RADIOTERAPIA */, vCdDiagImagemRadio -- 74-PCD_DIAGNOSTICO_IMAGEM        - CODIGO DO DIAGNOSTICO POR IMAGEM
                                                                 /* ANEXO DE RADIOTERAPIA */, vTpEstadiamentoRadio -- 75-PCD_ESTADIAMENTO              - CODIGO DO ESTADIAMENTO
                                                                 /* ANEXO DE RADIOTERAPIA */, vTpEcogRadio -- 76-PCD_ECOG                      - CODIGO DO ECOG
                                                                 /* ANEXO DE RADIOTERAPIA */, vTpFinalidadeRadio -- 77-PCD_FINALIDADE_TRATAMENTO     - CODIGO DA FINALIDADE DO TRATAMENTO
                                                                 /* ANEXO DE RADIOTERAPIA */, vDsDiagCitHistRadio -- 78-PDS_DIAGNOSTICO_CITOHISTO     - DIAGNOSTICO HISPATOLOGICO
                                                                 /* ANEXO DE RADIOTERAPIA */, vDsInfoRelevantesRadio -- 79-PDS_INFORMACOES_RELEVANTES    - INFORMACOES RELEVANTES
                                                                 /* ANEXO DE RADIOTERAPIA */, vDsCirurgiaRadio -- 80-PDS_CIRURGIA                  - CIRURGIA
                                                                 /* ANEXO DE RADIOTERAPIA */, Nvl(vDtCirurgiaRadio, TRUNC(SYSDATE)) -- 81-PDT_REALIZACAO                - DATA DA REALIZACAO
                                                                 /* ANEXO DE RADIOTERAPIA */, vDsQuimioterapiaRadio -- 82-PDS_QUIMIOTERAPIA             - QUIMIOTERAPIA
                                                                 /* ANEXO DE RADIOTERAPIA */, Nvl(vDtQuimioterapiaRadio, TRUNC(SYSDATE)) -- 83-PDT_APLICACAO                 - DATA DA APLICACAO
                                                                 /* ANEXO DE RADIOTERAPIA */, vQtCamposRadio -- 84-PNR_CAMPOS                    - NUMERO DE CAMPOS
                                                                 /* ANEXO DE RADIOTERAPIA */, vQtDosesDiaRadio -- 85-PNR_DOSE_DIA                  - NUMERO DE DOSE DIA
                                                                 /* ANEXO DE RADIOTERAPIA */, vQtDosesTotalRadio -- 86-PNR_DOSE_TOTAL                - TOTAL DE DOSES
                                                                 /* ANEXO DE RADIOTERAPIA */, vQtDiasTratamentoRadio -- 87-NR_TRATAMENTO_DIA             - NUMERO DE TRATAMENTO DIA
                                                                , NULL -- 88-PNR_PESO_BENEFICIARIO         - PESO DO BENEFICIARIO
                                                                , NULL -- 89-PNR_ALTURA_BENEFICIARIO       - ALTURA DO BENEFICIARIO
                                                                , NULL -- 90-PNR_SUPERFICIE_CORPORAL       - SUPERFICIE CORPORAL DO BENEFICIARIO
                                                                , NULL -- 91-PNR_CICLO_PREVISTO            - NUMERO DE CICLOS PREVISTOS
                                                                , NULL -- 92-PNR_CICLO_ATUAL               - NUMERO DO CICLO ATUAL
                                                                , NULL -- 93-PNR_INTERVALO_CICLO           - INTERVALO ENTRE CICLO
                                                                , NULL -- 94-PDS_PLANO_TERAPEUTICO         - PLANO TERAPEUTICO
                                                                , NULL -- 95-PDS_AREA_IRRADIADA            - AREA IRRADIADA
                                                                , NULL -- 96-PCD_QUIMIOTERAPIA             - CODIGO DA QUIMIOTERAPIA
                                                                , Nvl(rPedidoAutorizacao.DS_VERSAO_TISS, P_VERSAO_TISS) -- 97-PCD_VERSAO_TISS               - A ATUAL VERSAO DO TISS
                                                                , Nvl(dDtSugeridaInternacao, TRUNC(SYSDATE)) -- 98-PDT_SUGERIDA_INTERNACAO
                                                                , NULL -- 99-PSN_PREVISAO_USO_OPME
                                                                , NULL -- 100-PSN_PREVISAO_USO_QUIMIO
                                                                , rPedidoAutorizacao.DS_JUSTIFICATIVA_TECNICA -- 101-PDS_JUSTIFICATIVA_TECNICA
                                                                , NULL -- 102-PDS_ESPECIFICACAO_MATERIAL
                                                                , vNmProfSolicitanteRadio -- 103-PNM_PROFISSIONAL_SOLICITANTE
                                                                , NULL -- 104-PCD_MOTIVO_CONTINGENCIAL
                                                                , LPAD(rPedidoAutorizacao.CD_UNIMED_ORIGEM, 3, '0') -- 105-PCD_UNIMED_ORIGEM
                                                                , LPAD(rPedidoAutorizacao.CD_UNIMED_ATEND, 3, '0') -- 106-PCD_UNIMED_EXECUTORA
                                                                , NULL -- 107-PCD_VIA_CARTAO
                                                                , rPedidoAutorizacao.TP_REDE_MIN -- 108-PTP_REDE_MIN
                                                                , rPedidoAutorizacao.CD_IBGE -- 109-PCD_IBGE
                                                                , NULL -- 110 - PCD_TISS_CONSELHO_PROF_SOL
                                                                , NULL -- 111 - PUF_CONSELHO_PROF_SOLC
                                                                , NULL -- 112 - PNR_REG_CONSELHO_PROF_SOLIC
                                                                , NULL -- 113 - PCD_CLASSIFICACAO_TUMOR
                                                                , NULL -- 114 - PCD_CLASSIFICACAO_NODULO
                                                                , NULL -- 115 - PQTD_DIAS_CICLO
                                                                , NULL -- 116 - CD_CLASSIFICACAO_METASTASE
                                                                , NULL -- 117 - PCD_IDENTIFICACAO_BENEFICIARIO
                                                                , rPedidoAutorizacao.TP_ETAPA_AUTORIZACAO  -- 118 - PCD_ETAPA_AUTORIZACAO
                                                                , NULL -- 119 - PCD_MOT_AUSENCIA_COD_VALIDACAO
                                                                , NULL -- 120 - PCD_VALIDACAO
                                                                , NULL -- 121 - PCD_PRESTADOR_EMISSAO_GUIA
                                                                , NULL -- 122 - PCD_TIP_ACOMODACAO
                                                                , NULL -- 123 - PNM_PRESTADOR_EXECUTOR_PF
                                                                , NULL -- 124 - PCD_TISS_CONSELHO_PROF_EXEC_PF
                                                                , NULL -- 125 - PNR_REG_CONSELHO_PROFI_EXEC
                                                                , NULL -- 126 - PUF_CONSELHO_PROFISSIONAL_EXEC
                                                                , NULL -- 127 - PCD_ESPECIALIDADE_EXECUTANTE
                                                                , NULL -- 128 - PDT_EMISSAO
                                                                , NULL -- 129 - PDS_PLANO_BENEF
                                                                , NULL -- 130 - PDS_NOME_EMPRESA
                                                                , NULL -- 131 - PNR_TELEFONE_BENEF
                                                                , NULL -- 132 - PNM_TITULAR_BENEF
                                                                , NULL -- 133 - PNR_REGISTRO_ANS_ANEXO
                                                                , NULL -- 134 - PNR_GUIA_ANEXO
                                                                , NULL -- 135 - PNR_GUIA_REFERENCIADA_ANEXO
                                                                , NULL -- 136 - PNR_GUIA_OPERADORA_ANEXO
                                                                , NULL -- 137 - PNM_BENEFICIARIO_ANEXO
                                                                , NULL -- 138 - PNR_CARTEIRA_ANEXO
                                                                , NULL -- 139 - PSN_DOENCA_PERIODONTAL
                                                                , NULL -- 140 - PSN_ALTERACAO_TECIDO_MOLE
                                                                , NULL -- 141 - PDS_OBSERVACAO_ANEXO
                                                                , NULL -- 142 - PCD_REEMBOLSO
                                                                , rPedidoAutorizacao.NR_TOKEN --143 - NR_TOKEN
                                                                );
                  EXCEPTION
                    WHEN OTHERS THEN
                      vCdGlosa      := '4001';
                      vDsGlosa      := REPLACE('ERRO NA AUTORIZA_GUIA. ERRO: ' ||
                                               SQLERRM ||
                                               ' LINHA DO ERRO: ' ||
                                               DBMS_UTILITY.FORMAT_ERROR_BACKTRACE, Chr(13) ||
                                                Chr(10));
                      vExcecao      := SQLERRM;
                      vExcecaoLinha := DBMS_UTILITY.FORMAT_ERROR_BACKTRACE;
                      SELECT DBAPS.SEQ_PTU_MENSAGEM.NEXTVAL
                        INTO nIdPtuMensagemLog
                        FROM SYS.DUAL;
                      -- INSERINDO NO LOG DE ERROS
                      INSERT INTO DBAPS.PTU_MENSAGEM_LOG
                        (CD_PTU_MENSAGEM_LOG
                        ,CD_PTU_MENSAGEM
                        ,DT_LOG
                        ,DS_LOG)
                      VALUES
                        (nIdPtuMensagemLog --CD_PTU_MENSAGEM_LOG
                        ,P_ID_PTU_MENSAGEM --CD_PTU_MENSAGEM
                        ,SYSDATE --DT_LOG
                        ,'ERRO: ' || vExcecao || ' LINHA DO ERRO: ' ||
                         vExcecaoLinha --DS_LOG
                         );
                  END; -- END - AUTORIZA ANEXO DE RADIOTERAPIA.
                  UPDATE DBAPS.GUIA
                     SET TP_FLUXO_PTU_WS               = 'SERVER'
                        ,CD_PTU_MENSAGEM_ORIGEM        = nIdPtuMensagem --P_ID_PTU_AUTORIZACAO
                        ,CD_PTU_MENSAGEM_DESTINO       = rPedidoAutorizacao.NR_TRANSACAO_PRESTADORA --nIdPtuMensagem
                        ,CD_UNIMED_ORIGEM              = LPAD(rPedidoAutorizacao.CD_UNIMED_ORIGEM, 3, '0')
                        ,CD_UNIMED_EXECUTORA           = LPAD(rPedidoAutorizacao.CD_UNIMED_ATEND, 3, '0')
                        ,CD_UNIMED_SOLICITANTE         = LPAD(rPedidoAutorizacao.CD_UNIMED_ATEND, 3, '0')
                        ,CD_UNI_SOLICIT_EVENTUAL       = LPAD(rPedidoAutorizacao.CD_PRESTADOR_REQUI_UNIMED, 3, '0')
                        ,CD_PREST_SOLICIT_EVENTUAL     = rPedidoAutorizacao.CD_PRESTADOR_REQUISITANTE
                        ,CD_UNI_EXEC_EVENTUAL          = LPAD(rPedidoAutorizacao.CD_PRESTADOR_UNIMED, 3, '0')
                        ,CD_PREST_EXEC_EVENTUAL        = rPedidoAutorizacao.CD_PRESTADOR
                        ,NM_PREST_EXEC_EVENTUAL        = rPedidoAutorizacao.NM_PRESTADOR
                        ,TP_SEXO                       = DECODE(rPedidoAutorizacao.TP_SEXO, 1, 'M', 3, 'F')
                        ,NR_IDADE_BENEFICIARIO         = rPedidoAutorizacao.NR_IDADE
                        ,NR_VIA_CARTAO                 = rPedidoAutorizacao.NR_VIA_CARTAO
                        ,CD_CID                        = rPedidoAutorizacao.CD_CID
                        ,CD_PTU_MENS_ORDEM_SERVICO_ORI = rPedidoAutorizacao.NR_IDENT_ORDEM_SERVICO
                        ,SN_ORDEM_SERVICO              = rPedidoAutorizacao.SN_ORDEM_SERVICO
                        ,CD_INDICADOR_ACIDENTE         = rPedidoAutorizacao.TP_ACIDENTE
                        ,SN_LIMINAR                    = rPedidoAutorizacao.SN_LIMINAR
                   WHERE NR_GUIA = nNrGuiaRadio;
                   --
                  FOR rSolicitacaoProcedimento IN cPedidoAutorizacaoItem(rPedidoAutorizacao.CD_PTU_PEDIDO_AUTORIZACAO, 2) LOOP
                    UPDATE DBAPS.ITGUIA
                       SET DS_PROCEDIMENTO        = rSolicitacaoProcedimento.DS_SERVICO
                          ,TP_INDICADOR_ANEXO     = 2
                          ,CD_UNIDADE_MEDIDA      = rSolicitacaoProcedimento.UNI_MEDIDA_MED
                          ,QT_TOTAL_DOSAGEM_CICLO = rSolicitacaoProcedimento.QT_TOTAL_DOSAGEM_CICLO
                          ,SN_PACOTE_PTU          = rSolicitacaoProcedimento.SN_PACOTE
                          ,VL_PROCEDIMENTO        = Nvl(Nvl(rSolicitacaoProcedimento.VL_UNIT_SERVICO, rSolicitacaoProcedimento.VL_MONETARIO), VL_PROCEDIMENTO)
                          ,TP_TABELA_INTERCAMBIO  = LPad(rSolicitacaoProcedimento.TP_TABELA,2,'0')
                          ,CD_SERVICO_PTU        =  rSolicitacaoProcedimento.CD_SERVICO
                     WHERE NR_GUIA = nNrGuiaRadio
                       AND NR_SQ_ITEM_PTU =
                           rSolicitacaoProcedimento.SQ_ITEM
                       AND CD_PROCEDIMENTO = rSolicitacaoProcedimento.CD_PROCEDIMENTO;
                  END LOOP;
                END IF; -- END IF - AUTORIZACAO DO ANEXO DE RADIOTERAPIA.
                -- AUTORIZACAO DO ANEXO DE OPME
                IF (rQtdAnexosPedido.QT_ANEXO_OPME > 0)
                   AND rGuia.NR_GUIA IS NULL THEN
                  -- TIPO DO ANEXO
                  SELECT CD_TIPO_ATENDIMENTO
                    INTO vNrTpAnexoOpme
                    FROM DBAPS.TIPO_ATENDIMENTO
                   WHERE TP_GUIA = 'O';
                  -- CONCATENANDO PROCEDIMENTOS
                  vCdProcedimento := '*';
                  IF vCdGlosa IS NULL THEN
                     --
                    FOR rSolicitacaoProcedimento IN cPedidoAutorizacaoItem(rPedidoAutorizacao.CD_PTU_PEDIDO_AUTORIZACAO, 3) LOOP
                       vCdProcedimentoPacote := NULL;
                      IF rSolicitacaoProcedimento.TP_TABELA = '98' THEN
                      --VERIFICANDO SE O PROCEDIMENTO DA SOLICITACAO EXISTE, CASO NAO EXISTA, SER� CRIADO AQUI
                        vCdProcedimentoPacote := DBAPS.FNC_PACOTE_UNIMED(rSolicitacaoProcedimento.CD_PROCEDIMENTO,
                                                                        vCdUnimedPrestadora);
                      END IF; -- rSolicitacaoProcedimento.TP_TABELA = '98'
                      vCdProcedimento := vCdProcedimento ||
                                         Nvl(vCdProcedimentoPacote, rSolicitacaoProcedimento.CD_PROCEDIMENTO) || '*' || -- CD_PROCEDIMENTO
                                         rSolicitacaoProcedimento.QT_SERVICO || '*' || -- QT_PROCEDIMENO
                                         Nvl(TO_CHAR(rSolicitacaoProcedimento.SQ_ITEM), 'NULL') || '*' || -- CD_REGIAO_DENTE
                                        /*CD_FACES_DENTES_ODONTO*/
                                         'NULL' || '*' || -- CD_FACES_DENTES_ODONTO
                                         Nvl(TO_CHAR(rSolicitacaoProcedimento.DT_PROV), 'NULL') || '*' || -- DT_PREVISTA
                                         Nvl(TO_CHAR(rSolicitacaoProcedimento.CD_VIA_ADMIN), 'NULL') || '*' || -- CD_VIA_ADM
                                         Nvl(TO_CHAR(rSolicitacaoProcedimento.TP_ORDEM), 'NULL') || '*' || -- NR_ORDEM_PREFERENCIA
                                         Nvl(TO_CHAR(rSolicitacaoProcedimento.VL_MONETARIO), 'NULL') || '*' || -- VL_SOLICITADO
                                         Nvl(TO_CHAR(rSolicitacaoProcedimento.CD_ANVISA), 'NULL') || '*' || -- NR_ANVISA
                                         Nvl(TO_CHAR(REPLACE(rSolicitacaoProcedimento.CD_REFERENCIA_MATERIAL_FAB, '*')), 'NULL') || '*' || -- CD_MATERIAL_FABRICANTE
                                        /*NR_AUTORIZACAO_FUNCIONAMENTO*/
                                         'NULL' || '*' || -- NR_AUTORIZACAO_FUNCIONAMENTO
                                        /*SN_PRESTADOR_EXECUTOR_OPME*/
                                         'NULL' || '*' || -- SN_PRESTADOR_EXECUTOR_OPME
                                         NVL(TO_CHAR(rSolicitacaoProcedimento.QT_FREQUENCIA), 'NULL') || '*' || -- QT_SOLICITADO_DIA
                                        /*CD_UNIDADE_MEDIDA*/
                                         'NULL' || '*' || -- CD_UNIDADE_MEDIDA
                                        /*QT_TOTAL_DOSAGEM_CICLO*/
                                         'NULL' || '*'; -- QT_TOTAL_DOSAGEM_CICLO
                    END LOOP;
                  END IF; -- END IF - CONCATENANDO PROCEDIMENTOS
                  -- AUTORIZACAO DO ANEXO DE OPME.
                  BEGIN
                    vDsMensagem           := NULL;
                    vRetornoAutorizaAnexo := DBAPS.AUTORIZA_GUIA(NVL(P_CD_MULTI_EMPRESA, DBAMV.PKG_MV2000.LE_EMPRESA) -- 1-PCD_MULTI_EMPRESA              - HOSPITAL/OPERADORA (MULTI-EMPRESA
                                                                , vCdMatricula -- 2-PCD_MATRICULA                  - MATRICULA DO BENEFICIARIO
                                                                , vNrTpAnexoOpme -- 3-PCD_TIPO_GUIA                  - TIPO DE ATENDIMENTO (GUIA)
                                                                , vTpInternacao -- 4-PTP_INTERNACAO                 - TIPO DE INTERNACAO
                                                                , nQtDiasSolicitados -- 5-PNR_DIAS_AUTORIZACAO           - NUMERO DE DIAS SOLICITADOS
                                                                , nCdPrestador -- 6-PCD_PRESTADOR                  - PRESTADOR EXECUTOR
                                                                , nCdEspecialidade -- 7-PCD_ESPECIALIDADE              - ESPECIALIDADE DO PRESTADOR EXECUTANTE (NAO VAI SER MAIS USADA A ESPECIALIDADE COMO UM CAMPO DE VALIDACAO)
                                                                , vCdProcedimento -- 8-PSTRING_PROC                   - PROCEDIMENTOS (SEPARADOS POR '*')
                                                                , 'S' -- 9-PSN_SOLICITA_AUTORIZACAO       - INDICA SE E UMA SOLICITACAO DE GUIA
                                                                , Nvl(dDtSugeridaInternacao, TRUNC(SYSDATE)) -- 10-PDT_PREVISAO_EXECUCAO         - DATA DE PREVISAO DE EXECUCAO
                                                                , NULL -- 11-PDS_SENHA_AUTORIZACAO         - SENHA DE AUTORIZACAO DO PRESTADOR
                                                                , vNmBeneficiario -- 12-PNM_USUARIO                   - RETORNO DO NOME DO BENEFICIARIO
                                                                , vTpSexo -- 13-PTP_SEXO                      - RETORNO DO SEXO DO BENEFICIARIO
                                                                , vNrCpfBeneficiario -- 14-PNR_CPF                       - RETORNO DO CPF DO BENEFICIARIO
                                                                , vNrRG -- 15-PNR_RG                        - RETORNO DO RG DO BENEFICIARIO
                                                                , vOrgaoExpeditor -- 16-PDS_ORGAO_EXPEDITOR           - RETORNO DO ORGAO EXPEDIDOR DO BENEFICIARIO
                                                                , vNmConjuge -- 17-PNM_CONJUGE                   - RETORNO DO NOME DO CONJUGE DO BENEFICIARIO
                                                                , vNmMae -- 18-PNM_MAE                       - RETORNO DO NOME DA MAE DO BENEFICIARIO
                                                                , vNmPai -- 19-PNM_PAI                       - RETORNO DO NOME DO PAI DO BENEFICIARIO
                                                                , dDtNascimento -- 20-PDT_NASCIMENTO                - RETORNO DA DATA DE NASCIMENTO DO BENEFICIARIO
                                                                , vEndereco -- 21-PDS_ENDERECO                  - RETORNO DO ENDERECO DO BENEFICIARIO
                                                                , nNrEndereco -- 22-PNR_ENDERECO                  - RETORNO DO NUMERO DO ENDERECO DO BENEFICIARIO
                                                                , vComplemento -- 23-PDS_COMPLEMENTO               - RETORNO DO COMPLEMENTO DO ENDERECO DO BENEFICIARIO
                                                                , vBairro -- 24-PDS_BAIRRO                    - RETORNO DO BAIXO DO BENEFICIARIO
                                                                , nCdCidade -- 25-PCD_CIDADE                    - RETORNO DO CODIGO DA CIDADE DO BENEFICIARIO
                                                                , vNrCEP -- 26-PNR_CEP                       - RETORNO DO NUMERO DO CEP DO BENEFICIARIO
                                                                , vNrTelefone -- 27-PNR_TELEFONE                  - RETORNO DO NUMERO DO TELEFONE DO BENEFICIARIO
                                                                , nNrGuiaOpme -- 28-PNR_GUIA                      - RETORNO DO NUMERO DA GUIA AUTORIZADA
                                                                , vDtValidadeCarteira -- 29-PDT_VALID_CART                - RETORNO DA DATA VALIDADE DA CARTEIRA
                                                                , vNmTitular -- 30-PNM_TITULAR                   - RETORNO DO NOME DO TITULAR (SE BENEFICIARIO DEPENDENTE OU AGREGADO)
                                                                , vTpGuia -- 31-PDS_TIPO_GUIA                 - RETORNO DA DESCRICAO DO TIPO DE ATENDIMENTO (GUIA)
                                                                , vNmPrestador -- 32-PNM_PRESTADOR                 - RETORNO DO NOME DO PRESTADOR EXECUTOR
                                                                , vEspecialidade -- 33-PDS_ESPECIALIDADE             - RETORNO DA ESPECIALIDADE DO PRESTADOR EXECUTOR
                                                                , dDtVencimentoGuia -- 34-PDT_VENCIMENTO_GUIA           - RETORNO DA DATA DE VENCIMENTO DA GUIA
                                                                , nCdPlano -- 35-PCD_PLANO                     - RETORNO DO CODIGO DO PLANO DO BENEFICIARIO
                                                                , vDsPlano -- 36-PDS_PLANO                     - RETORNO DA DESCRICAO DO PLANO DO BENEFICIARIO
                                                                , vEmpresa -- 37-PDS_EMPRESA                   - RETORNO DA DESCRICAO DA EMPRESA DO BENEFICIARIO (PARA CONTRATOS COLETIVOS)
                                                                , vDsMensagem -- 38-PDS_MENSAGEM                  - RETORNO DA MENSAGEM DE ERRO DA ANALISE DA GUIA
                                                                , 'PTU' -- 39-PTP_ORIGEM                    - ORIGEM: MVS - MVSAUDE; MV2-MV2000i ;INT-INTERNET OU WS-WEBSERVICE
                                                                , nCdPrestadorSolicitante -- 40-PCD_PRESTADOR_SOLICITANTE     - CODIGO DO PRESTADOR SOLICITANTE
                                                                , nCdAutorizador -- 41-PCD_AUTORIZADOR               - CODIGO DO AUTORIZADOR DA GUIA
                                                                , nCdMedicoSolicitante -- 42-PCD_MEDICO_SOLICITANTE        - CODIGO DO MEDICO SOLICITANTE (NAO HA ESSE ITEM NAS PASSAGENS DO TISS)
                                                                , NULL -- 43-PNR_GUIA_PRESTADOR            - NUMERO DA GUIA DO PRESTADOR
                                                                , NULL -- 44-PNR_GUIA_EXTERNA              - NUMERO DA GUIA EXTERNA DA OPERADORA
                                                                , Nvl(vNrGuiaTem, nNrGuiaRadio) -- 45-PNR_GUIA_TEM                  - CODIGO DA GUIA PAI
                                                                , NULL -- 46-PCD_ESPECIALIDADE_SOLICITANTE - CODIGO DA ESPECIALIDADE DO PRESTADOR SOLICITANTE
                                                                , NULL -- 47-PCD_PRESTADOR_SOLICITADO      - CODIGO DO PRESTADOR EXECUTOR SOLICITADO
                                                                , vTpCaraterSolicInter -- 48-PTP_CARATER_SOLIC_INTER       - CODIGO DO CARACTER DA EXECUCAO
                                                                , NULL -- 49-PCD_REGIME_INTERNACAO         - CODIGO DO REGIME DE INTERNACAO
                                                                , NULL -- 50-PCD_PRESTADOR_EXECUTOR_PF     - CODIGO DO PROFISSIONAL EXECUTOR
                                                                , rPedidoAutorizacao.CD_CID -- 51-PCD_CID                       - CID PRINCIPAL
                                                                , NULL -- 52-PCD_CID2                      - CID (2)
                                                                , NULL -- 53-PCD_CID3                      - CID (3)
                                                                , NULL -- 54-PCD_CID4                      - CID (4)
                                                                , nQtDiasSolicitados -- 55-PNR_DIAS_SOLICITACAO          - NUMERO DE DIAS SOLICITADO
                                                                , NULL -- 56-PCD_TIPO_DOENCA               - CODIGO DO TIPO DE DOENCA
                                                                , NULL -- 57-PNR_TEMPO_DOENCA              - VALOR DO TEMPO DA DOENCA
                                                                , nCodigoIndicadorAcidente -- 58-PCD_INDICADOR_ACIDENTE        - CODIGO DA INDICACAO DE ACIDENTE
                                                                , NULL -- 59-PCD_TIPO_ATENDIMENTO_TISS     - CODIGO DO TIPO DE ATENDIMENTO TISS (NAO INFORMADO NO TISS)
                                                                , NULL -- 60-PCD_TIPO_SAIDA_GUIA_SADT      - CODIGO DO TIPO DE SAIDA DA GUIA (NAO INFORMADO NO TISS)
                                                                , rPedidoAutorizacao.DS_OBSERVACAO -- 61-PDS_OBSERVACAO                - OBSERVACAO
                                                                , rPedidoAutorizacao.DS_INDICACAO_CLINICA -- 62-PDS_DIAGNOSTICO               - INDICACAO CLINICA
                                                                , NULL -- 63-PCD_UNIDADE_TEMPO_DOENCA      - CODIGO DA UNIDADE DO TEMPO DA DOENCA
                                                                , NULL -- 64-PCD_TIPO_CONSULTA             - TIPO DA CONSULTA
                                                                , NULL -- 65-PDS_ANEXO_TEXTO               - DESCRICAO DO ANEXO
                                                                , nCdPrestadorEndereco -- 66-PCD_PRESTADOR_ENDERECO        - CODIGO DO PRESTADOR NO ENDERECO
                                                                , rPedidoAutorizacao.SN_RN -- 67-PSN_ATENDIMENTO_RECEM_NATO    - ATENDIMENTO RECEM NATO
                                                                , NULL -- 68-PDT_TERMINO_TRATAMENTO_ODONTO - DATA DO TERMINO DO TRATAMENTO ODONTOLOGICO
                                                                , NULL -- 69-PTP_ATENDIMENTO_ODONTO        - TIPO DO ATENDIMENTO ODONTOLOGICO
                                                                , NULL -- 70-PTP_FATURAMENTO_ODONTO        - TIPO DO FATURAMENTO ODONTOLOGICO
                                                                , NULL -- 71-PNR_TELEFONE_PROF_SOLIC       - NUMERO DO TELEFONE DO PROFISSIONAL SOLICITANTE
                                                                , NULL -- 72-PDS_EMAIL_PROF_SOLIC          - EMAIL DO PROFISSIONAL SOLICITANTE
                                                                , NULL -- 73-PDT_DIAGNOSTICO               - DATA DO DIAGNOSTICO
                                                                , NULL -- 74-PCD_DIAGNOSTICO_IMAGEM        - CODIGO DO DIAGNOSTICO POR IMAGEM
                                                                , NULL -- 75-PCD_ESTADIAMENTO              - CODIGO DO ESTADIAMENTO
                                                                , NULL -- 76-PCD_ECOG                      - CODIGO DO ECOG
                                                                , NULL -- 77-PCD_FINALIDADE_TRATAMENTO     - CODIGO DA FINALIDADE DO TRATAMENTO
                                                                , NULL -- 78-PDS_DIAGNOSTICO_CITOHISTO     - DIAGNOSTICO HISPATOLOGICO
                                                                , NULL -- 79-PDS_INFORMACOES_RELEVANTES    - INFORMACOES RELEVANTES
                                                                , NULL -- 80-PDS_CIRURGIA                  - CIRURGIA
                                                                , NULL -- 81-PDT_REALIZACAO                - DATA DA REALIZACAO
                                                                , NULL -- 82-PDS_QUIMIOTERAPIA             - QUIMIOTERAPIA
                                                                , NULL -- 83-PDT_APLICACAO                 - DATA DA APLICACAO
                                                                , NULL -- 84-PNR_CAMPOS                    - NUMERO DE CAMPOS
                                                                , NULL -- 85-PNR_DOSE_DIA                  - NUMERO DE DOSE DIA
                                                                , NULL -- 86-PNR_DOSE_TOTAL                - TOTAL DE DOSES
                                                                , NULL -- 87-NR_TRATAMENTO_DIA             - NUMERO DE TRATAMENTO DIA
                                                                , NULL -- 88-PNR_PESO_BENEFICIARIO         - PESO DO BENEFICIARIO
                                                                , NULL -- 89-PNR_ALTURA_BENEFICIARIO       - ALTURA DO BENEFICIARIO
                                                                , NULL -- 90-PNR_SUPERFICIE_CORPORAL       - SUPERFICIE CORPORAL DO BENEFICIARIO
                                                                , NULL -- 91-PNR_CICLO_PREVISTO            - NUMERO DE CICLOS PREVISTOS
                                                                , NULL -- 92-PNR_CICLO_ATUAL               - NUMERO DO CICLO ATUAL
                                                                , NULL -- 93-PNR_INTERVALO_CICLO           - INTERVALO ENTRE CICLO
                                                                , NULL -- 94-PDS_PLANO_TERAPEUTICO         - PLANO TERAPEUTICO
                                                                , NULL -- 95-PDS_AREA_IRRADIADA            - AREA IRRADIADA
                                                                , NULL -- 96-PCD_QUIMIOTERAPIA             - CODIGO DA QUIMIOTERAPIA
                                                                , Nvl(rPedidoAutorizacao.DS_VERSAO_TISS, P_VERSAO_TISS) -- 97-PCD_VERSAO_TISS               - A ATUAL VERSAO DO TISS
                                                                , Nvl(dDtSugeridaInternacao, TRUNC(SYSDATE)) -- 98-PDT_SUGERIDA_INTERNACAO
                                                                , vSnAnexoOpme -- 99-PSN_PREVISAO_USO_OPME
                                                                , NULL -- 100-PSN_PREVISAO_USO_QUIMIO
                                                                , vDsJustificativaTecOpme -- 101-PDS_JUSTIFICATIVA_TECNICA
                                                                , vDsMaterialSolicOpme -- 102-PDS_ESPECIFICACAO_MATERIAL
                                                                , NULL -- 103-PNM_PROFISSIONAL_SOLICITANTE
                                                                , NULL -- 104-MOTIVO CONTINGENCIAL
                                                                , LPAD(rPedidoAutorizacao.CD_UNIMED_ORIGEM, 3, '0') -- 105-PCD_UNIMED_ORIGEM
                                                                , LPAD(rPedidoAutorizacao.CD_UNIMED_ATEND, 3, '0') -- 106-PCD_UNIMED_EXECUTORA
                                                                , NULL -- 107-PCD_VIA_CARTAO
                                                                , rPedidoAutorizacao.TP_REDE_MIN -- 108-PTP_REDE_MIN
                                                                , rPedidoAutorizacao.CD_IBGE -- 109-PCD_IBGE
                                                                , NULL -- 110 - PCD_TISS_CONSELHO_PROF_SOL
                                                                , NULL -- 111 - PUF_CONSELHO_PROF_SOLC
                                                                , NULL -- 112 - PNR_REG_CONSELHO_PROF_SOLIC
                                                                , NULL -- 113 - PCD_CLASSIFICACAO_TUMOR
                                                                , NULL -- 114 - PCD_CLASSIFICACAO_NODULO
                                                                , NULL -- 115 - PQTD_DIAS_CICLO
                                                                , NULL -- 116 - CD_CLASSIFICACAO_METASTASE
                                                                , NULL -- 117 - PCD_IDENTIFICACAO_BENEFICIARIO
                                                                , rPedidoAutorizacao.TP_ETAPA_AUTORIZACAO  -- 118 - PCD_ETAPA_AUTORIZACAO
                                                                , NULL -- 119 - PCD_MOT_AUSENCIA_COD_VALIDACAO
                                                                , NULL -- 120 - PCD_VALIDACAO
                                                                , NULL -- 121 - PCD_PRESTADOR_EMISSAO_GUIA
                                                                , NULL -- 122 - PCD_TIP_ACOMODACAO
                                                                , NULL -- 123 - PNM_PRESTADOR_EXECUTOR_PF
                                                                , NULL -- 124 - PCD_TISS_CONSELHO_PROF_EXEC_PF
                                                                , NULL -- 125 - PNR_REG_CONSELHO_PROFI_EXEC
                                                                , NULL -- 126 - PUF_CONSELHO_PROFISSIONAL_EXEC
                                                                , NULL -- 127 - PCD_ESPECIALIDADE_EXECUTANTE
                                                                , NULL -- 128 - PDT_EMISSAO
                                                                , NULL -- 129 - PDS_PLANO_BENEF
                                                                , NULL -- 130 - PDS_NOME_EMPRESA
                                                                , NULL -- 131 - PNR_TELEFONE_BENEF
                                                                , NULL -- 132 - PNM_TITULAR_BENEF
                                                                , NULL -- 133 - PNR_REGISTRO_ANS_ANEXO
                                                                , NULL -- 134 - PNR_GUIA_ANEXO
                                                                , NULL -- 135 - PNR_GUIA_REFERENCIADA_ANEXO
                                                                , NULL -- 136 - PNR_GUIA_OPERADORA_ANEXO
                                                                , NULL -- 137 - PNM_BENEFICIARIO_ANEXO
                                                                , NULL -- 138 - PNR_CARTEIRA_ANEXO
                                                                , NULL -- 139 - PSN_DOENCA_PERIODONTAL
                                                                , NULL -- 140 - PSN_ALTERACAO_TECIDO_MOLE
                                                                , NULL -- 141 - PDS_OBSERVACAO_ANEXO
                                                                , NULL -- 142 - PCD_REEMBOLSO
                                                                , rPedidoAutorizacao.NR_TOKEN --143 - NR_TOKEN
                                                                );
                    UPDATE DBAPS.GUIA
                       SET TP_FLUXO_PTU_WS               = 'SERVER'
                          ,CD_PTU_MENSAGEM_ORIGEM        = nIdPtuMensagem --P_ID_PTU_AUTORIZACAO
                          ,CD_PTU_MENSAGEM_DESTINO       = rPedidoAutorizacao.NR_TRANSACAO_PRESTADORA --nIdPtuMensagem
                          ,CD_UNIMED_ORIGEM              = LPAD(rPedidoAutorizacao.CD_UNIMED_ORIGEM, 3, '0')
                          ,CD_UNIMED_EXECUTORA           = LPAD(rPedidoAutorizacao.CD_UNIMED_ATEND, 3, '0')
                          ,CD_UNIMED_SOLICITANTE         = LPAD(rPedidoAutorizacao.CD_UNIMED_ATEND, 3, '0')
                          ,CD_UNI_SOLICIT_EVENTUAL       = LPAD(rPedidoAutorizacao.CD_PRESTADOR_REQUI_UNIMED, 3, '0')
                          ,CD_PREST_SOLICIT_EVENTUAL     = rPedidoAutorizacao.CD_PRESTADOR_REQUISITANTE
                          ,CD_UNI_EXEC_EVENTUAL          = LPAD(rPedidoAutorizacao.CD_PRESTADOR_UNIMED, 3, '0')
                          ,CD_PREST_EXEC_EVENTUAL        = rPedidoAutorizacao.CD_PRESTADOR
                          ,NM_PREST_EXEC_EVENTUAL        = rPedidoAutorizacao.NM_PRESTADOR
                          ,TP_SEXO                       = DECODE(rPedidoAutorizacao.TP_SEXO, 1, 'M', 3, 'F')
                          ,NR_IDADE_BENEFICIARIO         = rPedidoAutorizacao.NR_IDADE
                          ,NR_VIA_CARTAO                 = rPedidoAutorizacao.NR_VIA_CARTAO
                          ,CD_CID                        = rPedidoAutorizacao.CD_CID
                          ,CD_PTU_MENS_ORDEM_SERVICO_ORI = rPedidoAutorizacao.NR_IDENT_ORDEM_SERVICO
                          ,SN_ORDEM_SERVICO              = rPedidoAutorizacao.SN_ORDEM_SERVICO
                          ,CD_INDICADOR_ACIDENTE         = rPedidoAutorizacao.TP_ACIDENTE
                          ,SN_LIMINAR                    = rPedidoAutorizacao.SN_LIMINAR
                     WHERE NR_GUIA = nNrGuiaOpme;
    --
                    FOR rSolicitacaoProcedimento IN cPedidoAutorizacaoItem(rPedidoAutorizacao.CD_PTU_PEDIDO_AUTORIZACAO, 3) LOOP
                      UPDATE DBAPS.ITGUIA
                         SET DS_PROCEDIMENTO        = rSolicitacaoProcedimento.DS_SERVICO
                            ,TP_INDICADOR_ANEXO     = 3
                            ,CD_UNIDADE_MEDIDA      = rSolicitacaoProcedimento.UNI_MEDIDA_MED
                            ,QT_TOTAL_DOSAGEM_CICLO = rSolicitacaoProcedimento.QT_TOTAL_DOSAGEM_CICLO
                            ,SN_PACOTE_PTU          = rSolicitacaoProcedimento.SN_PACOTE
                            ,VL_PROCEDIMENTO        = Nvl(Nvl(rSolicitacaoProcedimento.VL_UNIT_SERVICO, rSolicitacaoProcedimento.VL_MONETARIO), VL_PROCEDIMENTO)
                            ,TP_TABELA_INTERCAMBIO  = LPad(rSolicitacaoProcedimento.TP_TABELA,2,'0')
                            ,CD_SERVICO_PTU        =  rSolicitacaoProcedimento.CD_SERVICO
                       WHERE NR_GUIA = nNrGuiaRadio
                         AND NR_SQ_ITEM_PTU =
                             rSolicitacaoProcedimento.SQ_ITEM
                         AND CD_PROCEDIMENTO = rSolicitacaoProcedimento.CD_PROCEDIMENTO;
                    END LOOP;
                  EXCEPTION
                    WHEN OTHERS THEN
                      vCdGlosa      := '4001';
                      vDsGlosa      := REPLACE('ERRO NA AUTORIZA_GUIA. ERRO: ' ||
                                               SQLERRM ||
                                               ' LINHA DO ERRO: ' ||
                                               DBMS_UTILITY.FORMAT_ERROR_BACKTRACE, Chr(13) ||
                                                Chr(10));
                      vExcecao      := SQLERRM;
                      vExcecaoLinha := DBMS_UTILITY.FORMAT_ERROR_BACKTRACE;
                      SELECT DBAPS.SEQ_PTU_MENSAGEM.NEXTVAL
                        INTO nIdPtuMensagemLog
                        FROM SYS.DUAL;
                      -- INSERINDO NO LOG DE ERROS
                      INSERT INTO DBAPS.PTU_MENSAGEM_LOG
                        (CD_PTU_MENSAGEM_LOG
                        ,CD_PTU_MENSAGEM
                        ,DT_LOG
                        ,DS_LOG)
                      VALUES
                        (nIdPtuMensagemLog --CD_PTU_MENSAGEM_LOG
                        ,P_ID_PTU_MENSAGEM --CD_PTU_MENSAGEM
                        ,SYSDATE --DT_LOG
                        ,'ERRO: ' || vExcecao || ' LINHA DO ERRO: ' ||
                         vExcecaoLinha --DS_LOG
                         );
                  END; -- END - AUTORIZA ANEXO DE OPME.
                END IF; -- END IF - AUTORIZACAO DO ANEXO DE OPME.
              END IF; -- END IF - VERIFICA SE HA ANEXOS. >1
            END IF; -- VERIFICA SE DEU ERRO NA PRIMEIRA AUTORIZA GUIA (PRINCIPAL);
          END IF; -- END-IF DE GLOSA NO CORPO DA MENSAGEM (**PARTE 1**)
        END IF; -- MENSAGEM COM GLOSA NO CABECALHO
      ELSE
        -- ERROS NO CABECALHO
        INSERE_RESPOSTA_PADRAO(nIdPtuMensagem, rPedidoAutorizacao.CD_PTU_PEDIDO_AUTORIZACAO, vDsGlosa, 1);
      END IF; /* ENDIF (**CABECALHO**) */
    END IF; --IF rGuia.NR_GUIA IS NOT NULL THEN
    -- NAO TIVER ERRO NO CABECALHO REALIZA A RESPOSTA DO PEDIDO DE AUTORIZACAO OU COMPLEMENTO
    --Se encontrat algum item em auditoria colocar todas as guias em auditoria
    BEGIN
      OPEN cItGuiaAnexos(rPedidoAutorizacao.NR_TRANSACAO_PRESTADORA, P_CD_UNIMED_PRESTADORA);
      FETCH cItGuiaAnexos
        INTO rItGuiaAnexos;
      CLOSE cItGuiaAnexos;
      IF rItGuiaAnexos.NR_GUIA IS NOT NULL THEN
        DBAPS.PRC_INSERE_DEBUG_LOG(P_ID_PTU_AUTORIZACAO, '3.1) A Guia ' ||
                                    rItGuiaAnexos.NR_GUIA ||
                                    'se encontra em auditoria', 'PTU0600');
        UPDATE DBAPS.ITGUIA
           SET TP_STATUS = 2
         WHERE CD_ITGUIA IN
               (SELECT IG.CD_ITGUIA
                  FROM DBAPS.ITGUIA IG
                      ,DBAPS.GUIA   G
                 WHERE IG.NR_GUIA = G.NR_GUIA
                   AND G.CD_PTU_MENSAGEM_DESTINO =
                       rPedidoAutorizacao.NR_TRANSACAO_PRESTADORA
                   AND LPAD(G.CD_UNIMED_SOLICITANTE, 4, '0') =
                       LPAD(P_CD_UNIMED_PRESTADORA, 4, '0'));
        COMMIT;
        DBAPS.PRC_INSERE_DEBUG_LOG(P_ID_PTU_AUTORIZACAO, '3.2) Todos os itens da transacao ' ||
                                    rPedidoAutorizacao.NR_TRANSACAO_PRESTADORA ||
                                    'foram colocados em auditoria', 'PTU0600');
      END IF;
    EXCEPTION
      WHEN OTHERS THEN
        vExcecao      := SQLERRM;
        vExcecaoLinha := DBMS_UTILITY.FORMAT_ERROR_BACKTRACE;
        DBAPS.PRC_INSERE_DEBUG_LOG(P_ID_PTU_AUTORIZACAO, '3.1.1 vExcecao' ||
                                    vExcecao ||
                                    ' vExcecaoLinha = ' ||
                                    vExcecaoLinha, 'PTU0600');
    END;
    DBAPS.PRC_INSERE_DEBUG_LOG(P_ID_PTU_AUTORIZACAO, '4) NAO TIVER ERRO NO CABECALHO REALIZA A RESPOSTA P_CD_GLOSA: ' ||
                                P_CD_GLOSA ||
                                ' vDsGlosa = ' ||
                                vDsGlosa, 'PTU0600');
    DBAPS.PRC_INSERE_DEBUG_LOG(P_ID_PTU_AUTORIZACAO, '4,1)NR_GUIA: ' ||
                                nNrGuiaQuimio, 'PTU0600');
    IF P_CD_GLOSA IS NULL THEN
      ----IF P_CD_GLOSA IS NULL THEN RESPOSTA PEDIDO AUTORIZACAO
      nStatusSolicitacaoGuia := 1; -- Negado
      FOR rGuia IN cGuia(rPedidoAutorizacao.NR_TRANSACAO_PRESTADORA, P_CD_UNIMED_PRESTADORA) LOOP
        IF rGuia.SN_VALIDA_REST_CARENCIA = 'N' THEN
          IF rGuia.CD_MOT_CANCELAMENTO_GUIA IS NOT NULL THEN
            nStatusSolicitacaoGuia := 1; -- Negado
          ELSIF rGuia.DS_OBSERVACAO IS NOT NULL THEN
            nStatusSolicitacaoGuia := 4; -- Em Estudo
          ELSE
           --                  FOR rItGuiaAuditoria IN cItGuiaAuditoria(rGuia.NR_GUIA) LOOP
            nStatusSolicitacaoGuia := 4; -- Em Estudo
            --                  END LOOP;
          END IF;
        ELSIF rGuia.SN_VALIDA_REST_CARENCIA = 'S' THEN
          nStatusSolicitacaoGuia := 2; -- Autorizado
          --             ELSE
          --              nStatusSolicitacaoGuia := 4; -- Em Estudo
        END IF;
      END LOOP; --FOR rGuia IN cGuia(rPedidoAutorizacao.NR_TRANSACAO_PRESTADORA) LOOP
      --        BEGIN
      --          DELETE FROM DBAPS.PTU_RESP_PEDIDO_AUT WHERE CD_PTU_MENSAGEM = nIdPtuMensagem;
      --        EXCEPTION
      --          WHEN Others THEN
      --            vExcecao  := SQLERRM;
      --            vExcecaoLinha := DBMS_UTILITY.FORMAT_ERROR_BACKTRACE;
      --        END;
      DBAPS.PRC_INSERE_DEBUG_LOG(P_ID_PTU_AUTORIZACAO, '5.1) Guia: ' ||
                                  rGuia.NR_GUIA ||
                                  '; Status solicitaCAO da guia: ' ||
                                  nStatusSolicitacaoGuia ||
                                  '; Dt. venc. guia: ' ||
                                  dDtVencimentoGuia ||
                                  '; nIdPtuMensagem: ' ||
                                  nIdPtuMensagem, 'PTU0600');
      nCdPtuRespPedidoAut := NULL;
      SELECT DBAPS.SEQ_PTU_MENSAGEM.NEXTVAL
        INTO nCdPtuRespPedidoAut
        FROM DUAL;
      INSERT INTO DBAPS.PTU_RESP_PEDIDO_AUT
        (CD_PTU_RESP_PEDIDO_AUT
        ,CD_PTU_MENSAGEM
        ,NR_TRANSACAO_PRESTADORA
        ,NR_TRANSACAO_ORIGEM_BENEF
        ,CD_UNIMED_EXECUTORA
        ,CD_UNIMED
        ,CD_IDENTIFICACAO
        ,NM_BENEFICIARIO
        ,DT_VALIDADE_AUTORIZACAO
        ,TP_AUTORIZACAO
        ,TP_ACOMODACAO
        ,CD_VERSAO_PTU
        ,TP_SEXO
        ,DT_NASCIMENTO
        ,DS_OBSERVACAO
        ,DS_MENSAGEM_ERRO)
      VALUES
        (nCdPtuRespPedidoAut --CD_PTU_RESP_PEDIDO_AUT
        ,nIdPtuMensagem --CD_PTU_MENSAGEM
        ,rPedidoAutorizacao.NR_TRANSACAO_PRESTADORA --NR_TRANSACAO_PRESTADORA
        ,DECODE(nStatusSolicitacaoGuia, 2, nIdPtuMensagem, NULL) --NR_TRANSACAO_ORIGEM_BENEF
        ,P_CD_UNIMED_PRESTADORA --CD_UNIMED_EXECUTORA
        ,rPedidoAutorizacao.CD_UNIMED_ORIGEM --CD_UNIMED
        ,rPedidoAutorizacao.CD_IDENTIFICACAO --CD_IDENTIFICACAO
        ,Nvl(SubStr(vNmBeneficiario, 1, 25), 'BENEFICIARIO') --NM_BENEFICIARIO
        ,DECODE(nStatusSolicitacaoGuia, 2, dDtVencimentoGuia, NULL) --DT_VALIDADE_AUTORIZACAO
        ,1 --TP_AUTORIZACAO 1 = Unimed 2 = WSD
        ,Nvl(vTpAcomodacao, 'C') --TP_ACOMODACAO
        ,Nvl(rPedidoAutorizacao.CD_VERSAO_PTU, P_VERSAO_PTU) --CD_VERSAO_PTU
        ,rPedidoAutorizacao.TP_SEXO --TP_SEXO
        ,dDtNascimento --DT_NASCIMENTO
        ,DECODE(P_DS_GLOSA, NULL, NULL, 'ERRO: ' || P_DS_GLOSA) --DS_OBSERVACAO
        ,P_DS_GLOSA);
      DBAPS.PRC_INSERE_DEBUG_LOG(P_ID_PTU_AUTORIZACAO, '5.1) OS: nStatusSolicitacaoGuia: ' ||
                                  nStatusSolicitacaoGuia ||
                                  '; dDtVencimentoGuia: ' ||
                                  dDtVencimentoGuia, 'PTU0600');
      vSnPedidoAutorizado := 'N';
      FOR rItGuia IN cItGuia(rPedidoAutorizacao.NR_TRANSACAO_PRESTADORA, P_CD_UNIMED_PRESTADORA) LOOP
        nCdPtuRespPedidoAutItem := NULL;
        SELECT DBAPS.SEQ_PTU_MENSAGEM.NEXTVAL
          INTO nCdPtuRespPedidoAutItem
          FROM DUAL;
        BEGIN
          vDsMensagem := NULL;
          FOR r IN (SELECT DBAPS.FNC_REMOVE_ACENTO(DS_ERRO) DS_ERRO
                      FROM DBAPS.ITGUIA_ERROS
                     WHERE NR_GUIA = rItGuia.NR_GUIA
                       AND CD_ITGUIA = rItGuia.CD_ITGUIA) LOOP
            vDsMensagem := vDsMensagem || r.DS_ERRO;
          END LOOP;
        EXCEPTION
          WHEN OTHERS THEN
            vDsMensagem := NULL;
        END;
        --
        -- Se houver ao menos 1 item autorizado, NAO limpar o campo numeroTransacaoOrigemBeneficiario
        IF rItGuia.TP_STATUS = 2 THEN
          vSnPedidoAutorizado := 'S';
        END IF;
        --
        INSERT INTO DBAPS.PTU_RESP_PEDIDO_AUT_ITEM
          (CD_PTU_RESP_PEDIDO_AUT_ITEM
          ,CD_PTU_RESP_PEDIDO_AUT
          ,TP_TABELA
          ,CD_SERVICO
          ,DS_SERVICO
          ,QT_AUTORIZADA
          ,TP_INDICACAO_AUTORIZACAO
          ,DS_MENSAGEM_ESPEC
          ,SQ_ITEM)
        VALUES
          (nCdPtuRespPedidoAutItem --CD_PTU_RESP_PEDIDO_AUT_ITEM
          ,nCdPtuRespPedidoAut --CD_PTU_RESP_PEDIDO_AUT
          ,rItguia.TP_TABELA --TP_TABELA
          ,Nvl(rItGuia.CD_SERVICO_PTU, rItGuia.CD_PROCEDIMENTO) --CD_SERVICO
          ,rItGuia.DS_PROCEDIMENTO --DS_SERVICO
          ,Decode(rItGuia.TP_STATUS, 2, rItGuia.QT_SOLICITADO, 4, NULL, NULL) --QT_AUTORIZADA
          ,rItGuia.TP_STATUS --TP_INDICACAO_AUTORIZACAO
          ,DECODE(rItGuia.TP_STATUS, 1, SubStr(TRIM(regexp_replace(vDsMensagem, '[;]|[;]|[^a-zA-Z0-9 ]+')), 1, 500), NULL) --DS_MENSAGEM_ESPEC
          ,rItGuia.NR_SQ_ITEM_PTU
        );
        --
        DBAPS.PRC_INSERE_DEBUG_LOG(P_ID_PTU_AUTORIZACAO, '5.1) Item da OS: rItGuia.TP_STATUS' ||
                                    rItGuia.TP_STATUS || '', 'PTU0600');
        IF rItGuia.TP_STATUS = 1 THEN
          FOR rGlosaPtuOnline IN cGlosaPtuOnline(rItGuia.CD_ITGUIA) LOOP
            nCdPtuRespPedidoAutItemEsp := NULL;
            SELECT DBAPS.SEQ_PTU_MENSAGEM.NEXTVAL
              INTO nCdPtuRespPedidoAutItemEsp
              FROM DUAL;
            INSERT INTO DBAPS.PTU_RESP_PED_AUT_MENSAGEM_ESP
              (CD_RESP_PED_AUT_MENSAGEM_ESP
              ,CD_PTU_RESP_PEDIDO_AUT_ITEM
              ,CD_PTU_MENSAGEM_ESPECIFICA)
            VALUES
              (nCdPtuRespPedidoAutItemEsp --CD_RESP_PED_AUT_MENSAGEM_ESP
              ,nCdPtuRespPedidoAutItem --CD_PTU_RESP_PEDIDO_AUT_ITEM
              ,NVL(rGlosaPtuOnline.CD_GLOSA, 2004) -- CD_PTU_MENSAGEM_ESPECIFICA Cadastro beneficiario com problemas
               );
          END LOOP;
        END IF;
      END LOOP; --FOR rItGuia in cItGuia(rPedidoAutorizacao.NR_TRANSACAO_PRESTADORA) LOOP
      -- Se houver ao menos 1 item autorizado, NAO limpar o campo numeroTransacaoOrigemBeneficiario
      IF vSnPedidoAutorizado = 'N' THEN
        UPDATE DBAPS.PTU_RESP_PEDIDO_AUT
           SET NR_TRANSACAO_ORIGEM_BENEF = NULL
              ,DT_VALIDADE_AUTORIZACAO   = NULL
         WHERE CD_PTU_RESP_PEDIDO_AUT = nCdPtuRespPedidoAut;
        DBAPS.PRC_INSERE_DEBUG_LOG(P_ID_PTU_AUTORIZACAO, '7.1) Existe item autorizado: ' ||
                                    vSnPedidoAutorizado ||
                                    '; Cod. Resposta Pedido: ' ||
                                    nCdPtuRespPedidoAut, 'PTU0600');
      END IF;
    ELSE
      /* ALTERACAO DIA 02/10/2018: AUTORIZACAO SEM RESPOSTA EM CASO DE GUIA NAO AUTORIZADA */
      INSERE_RESPOSTA_PADRAO(nIdPtuMensagem, rPedidoAutorizacao.CD_PTU_PEDIDO_AUTORIZACAO, NVL(vDsGlosa, P_DS_GLOSA), 1);
    END IF; --IF P_CD_GLOSA IS NULL THEN RESPOSTA PEDIDO AUTORIZACAO
    RETURN nIdPtuMensagem;
  END gravarRespostaPedidoAut;
BEGIN
  SELECT DBAPS.FNC_VERSAO_PTU_ONLINE
    INTO P_VERSAO_PTU
    FROM dual;
  SELECT MAX(cd_versao_tiss)
    INTO P_VERSAO_TISS
    FROM DBAPS.V_CONSULTA_VERSAO_TISS;
  IF P_ID_PTU_MENSAGEM IS NULL THEN
    Raise_Application_Error(-20999, 'NAO FOI INFORMADO CODIGO DA P_ID_PTU_MENSAGEM PARA PROCESSAR ESTA PROCEDURE');
  END IF;
  -- BUSCA OS DADOS NA TABELA PTU MENSAGEM (TABELA MAE).
  OPEN cPtuMensagem(P_ID_PTU_MENSAGEM);
  FETCH cPtuMensagem
    INTO rPtuMensagem;
  CLOSE cPtuMensagem;
  -- VALIDANDO CABECALHO DA MENSAGEM PTU.
  DBAPS.PRC_PTU_VALIDA_CABECALHO(P_ID_PTU_MENSAGEM --P_ID_PTU_MENSAGEM
                                , vTpTransSolicitacao --P_CD_TRANSACAO
                                , vTpCliente --P_TP_CLIENTE
                                , vCdUnimedPrestadora --P_CD_UNIMED_PRESTADORA
                                , vCdUnimedOrigemBeneficiario --P_CD_UNIMED_ORIGEM_BENEF
                                , vCdGlosa --P_CD_GLOSA
                                , vDsGlosa --P_DS_GLOSA
                                , vCdVersaoPtu --P_CD_VERSAO
                                , vCdMultiEmpresa --P_CD_MULTI_EMPRESA
                                 );
  IF vCdGlosa IS NULL
     AND vCdMultiEmpresa IS NOT NULL THEN
    DBAMV.PKG_MV2000.ATRIBUI_EMPRESA(vCdMultiEmpresa);
  END IF;
  -- BUSCA OS DADOS DA TRANSACAO DE REQUISICAO DE ACORDO COM A PROCEDURE VALIDA CABECALHO.
  IF (vTpTransSolicitacao = '00600' OR vTpTransSolicitacao = '00605') THEN
    /**
    * GRAVAR RESPOSTA
    */
    DBAPS.PRC_INSERE_DEBUG_LOG(rPtuMensagem.CD_PTU_MENSAGEM, '1) rPtuMensagem.CD_PTU_MENSAGEM: ' ||
                                rPtuMensagem.CD_PTU_MENSAGEM, 'PTU0600');
    P_ID_PTU_MENSAGEM_OUT := gravarRespostaPedidoAut(rPtuMensagem.CD_PTU_MENSAGEM --P_ID_PTU_AUTORIZACAO
                                                    , vCdGlosa --P_CD_GLOSA
                                                    , vDsGlosa --P_DS_GLOSA
                                                    , vCdMultiEmpresa --P_CD_MULTI_EMPRESA
                                                    , vCdVersaoPtu --P_CD_VERSAO_PTU
                                                    , '00501' --P_CD_TRANSACAO
                                                    , vTpCliente --P_TP_CLIENTE
                                                    , vCdUnimedPrestadora --P_CD_UNIMED_PRESTADORA
                                                    , vCdUnimedOrigemBeneficiario --P_CD_UNIMED_ORIGEM_BENEF
                                                    , vTpTransSolicitacao --TP_TRANSACAO
                                                     );
    DBAPS.PRC_INSERE_DEBUG_LOG(rPtuMensagem.CD_PTU_MENSAGEM, '5) P_ID_PTU_MENSAGEM_OUT: ' ||
                                P_ID_PTU_MENSAGEM_OUT, 'PTU0600');
  END IF;
EXCEPTION
  WHEN OTHERS THEN
    vExcecao      := SQLERRM;
    vExcecaoLinha := DBMS_UTILITY.FORMAT_ERROR_BACKTRACE;
    DBAPS.PRC_INSERE_PTU_MENSAGEM_LOG(P_ID_PTU_MENSAGEM, 'PRC_PTU_AUTORIZADOR 2671', SQLERRM, DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
    P_ID_PTU_MENSAGEM_OUT := DBAPS.FNC_PTU_INSERE_CABECALHO(P_ID_PTU_MENSAGEM --P_ID_MENSAGEM_ENVIO
                                                           , '00501' --P_CD_TRANSACAO
                                                           , 'UNIMED' --P_TP_CLIENTE
                                                           , rPtuMensagem.CD_UNIMED_DESTINO --P_CD_UNIMED_ORIGEM_BENEF
                                                           , P_VERSAO_PTU --P_CD_VERSAO
                                                           , 4001 --P_CD_GLOSA
                                                           , 'ERRO: ' ||
                                                             vExcecao ||
                                                             ' - OCORREU UM ERRO NO PROCESSAMENTO DA SUA REQUISICAO. VERIFIQUE O LOG COM O COD: ' ||
                                                             nIdPtuMensagemLog --P_DS_GLOSA
                                                           , rPtuMensagem.CD_UNIMED_ORIGEM --P_CD_UNIMED_PRESTADORA
                                                           , SYSDATE --P_DT_TRANSACAO
                                                            );
    SELECT DBAPS.SEQ_PTU_MENSAGEM.NEXTVAL
      INTO nCdPtuRespPedidoAut
      FROM DUAL;
    INSERT INTO DBAPS.PTU_RESP_PEDIDO_AUT
      (CD_PTU_RESP_PEDIDO_AUT
      ,CD_PTU_MENSAGEM
      ,NR_TRANSACAO_PRESTADORA
      ,NR_TRANSACAO_ORIGEM_BENEF
      ,CD_UNIMED_EXECUTORA
      ,CD_UNIMED
      ,CD_IDENTIFICACAO
      ,NM_BENEFICIARIO
      ,DT_VALIDADE_AUTORIZACAO
      ,TP_AUTORIZACAO
      ,TP_ACOMODACAO
      ,CD_VERSAO_PTU
      ,TP_SEXO
      ,DT_NASCIMENTO
      ,DS_OBSERVACAO
      ,DS_MENSAGEM_ERRO)
    VALUES
      (nCdPtuRespPedidoAut --CD_PTU_RESP_PEDIDO_AUT
      ,P_ID_PTU_MENSAGEM --CD_PTU_MENSAGEM
      ,rPedidoAutorizacao.NR_TRANSACAO_PRESTADORA --NR_TRANSACAO_PRESTADORA
      ,NULL --NR_TRANSACAO_ORIGEM_BENEF
      ,rPtuMensagem.CD_UNIMED_PRESTADORA --CD_UNIMED_EXECUTORA
      ,rPedidoAutorizacao.CD_UNIMED_ORIGEM --CD_UNIMED
      ,rPedidoAutorizacao.CD_IDENTIFICACAO --CD_IDENTIFICACAO
      ,'BENEFICIARIO' --NM_BENEFICIARIO
      ,NULL --DT_VALIDADE_AUTORIZACAO
      ,1 --TP_AUTORIZACAO (1 - unimed)
      ,'C' --TP_ACOMODACAO
      ,Nvl(rPedidoAutorizacao.CD_VERSAO_PTU, P_VERSAO_PTU) --CD_VERSAO_PTU
      ,rPedidoAutorizacao.TP_SEXO --TP_SEXO
      ,NULL --DT_NASCIMENTO
      ,'ERRO: OCORREU UM ERRO NO PROCESSAMENTO DA SUA REQUISICAO. VERIFIQUE O LOG COD: ' ||
       nIdPtuMensagemLog --P_DS_GLOSA --DS_OBSERVACAO
      ,vExcecao);
    INSERE_RESPOSTA_PADRAO(nIdPtuMensagem, rPedidoAutorizacao.CD_PTU_PEDIDO_AUTORIZACAO, vDsGlosa, 1);
END;
/
