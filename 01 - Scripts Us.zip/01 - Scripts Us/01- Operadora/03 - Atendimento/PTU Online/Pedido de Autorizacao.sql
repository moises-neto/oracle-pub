 --PEDIDO
Declare 
preturn Number;
Begin

preturn  := DBAPS.fnc_ptu_pedido_autorizacao_v9(110121329);

dbms_output.put_line(preturn);

  
   
End;

658847789

--RESPOSTA

Declare
  Preturn Number;
Begin

  Preturn := Dbaps.Fnc_Resp_Ptu_Pedido_Autori(p_Id_Ptu_Mensagem => 658847789,
                                              p_Nr_Guia         => 110121329);

  Dbms_Output.Put_Line(Preturn);

End;



  

 Select Utl_Http.Request('http://192.168.200.32:8002/mvautorizadorguias/ServletEmailGuia?nrGuia=113151869&tpAtendimento=2&empresa=1&emailPrestador=esthersecundino@icloud.com')
  From Dual;

     
--CANCELAMENTO

Declare
  Preturn Number;
Begin

  Preturn := DBAPS.FNC_PTU_CANCELAMENTO(P_NR_GUIA => 110121329, P_DS_MENSAGEM => 'CANCELAMENTO AUTOMATICO DE INTEGRACAO' );

  Dbms_Output.Put_Line(Preturn);

End;




