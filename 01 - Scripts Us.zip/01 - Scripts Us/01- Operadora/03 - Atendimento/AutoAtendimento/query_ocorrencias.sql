pr_mov_fluxo_setor


select ktworkflowbd.kt_wf_fnc_preatend_mvto(x.id_wf_preatendimento,
                                                  x.id_etapa_destino,
                                                  x.id_etapa_status,
                                                  'INTEGRACAO',
                                                  'ENVIADO POR :' ||
                                                  x.cd_usuario,
                                                  NULL,
                                                  'FINALIZADO',
                                                  NULL,
                                                  NULL,
                                                  NULL,
                                                  NULL,
                                                  x.nr_transacao,
                                                  x.ds_protocolo_ans,
                                                  NULL)
      --  into v_retorno
        from dual;

Select d.*, rowid from de_para_class_ocorrencia  d
where d.cd_classificacao_ocorrencia in(34,56)


Select * from ktworkflowbd.kt_wf_etapa
     --195

       --62        
                      
       Select * from MOV_FLUXO_SETOR_SOUL_SAUDE c 
        Where trunc(c.dt_mov) = '25/03/2021'
       Where c.nr_transacao =  '2103000140628' 
       where c.cd_classificacao_ocor_guia = 195
       
       
       Select * from all_source a
       where Upper(a.TEXT) like '%MOV_FLUXO_SETOR_SOUL_SAUDE%' 
       
       dbaps.TRG_IMV_OCORRENCIA_AUTO


select distinct g.id_wf_preatendimento_guia,
                    ds_classificacao,
                    integrado,
                    cd_classificacao_ocor_guia,
                    cd_usuario,
                    dp.id_workflow_atual,
                    dp.id_etapa_destino,
                    w.id_wf_preatendimento,
                    dp.id_etapa_status,
                    l.nr_transacao,
                    l.ds_protocolo_ans
      from MOV_FLUXO_SETOR_SOUL_SAUDE             l,
           ktworkflowbd.kt_wf_preatendimento_guia g,
           ktworkflowbd.kt_wf_preatendimento      w,
           DE_PARA_CLASS_OCORRENCIA               dp
     where l.integrado = 'N'
       and g.id_wf_preatendimento = w.id_wf_preatendimento
       and g.id_wf_preatendimento_guia = l.id_wf_preatendimento_guia
       and dp.cd_classificacao_ocorrencia = l.cd_classificacao_ocor_guia
       and dp.id_workflow_atual = w.id_workflow;
