create or replace procedure ktsiaintegrabd.pr_mov_fluxo_setor is

  cursor c_mov is
    select distinct g.id_wf_preatendimento_guia,
                    ds_classificacao,
                    integrado,
                    cd_classificacao_ocor_guia,
                    cd_usuario,
                    dp.id_workflow_atual,
                    dp.id_etapa_destino,
                    w.id_wf_preatendimento,
                    dp.id_etapa_status,
                    l.nr_transacao,
                    l.ds_protocolo_ans
      from MOV_FLUXO_SETOR_SOUL_SAUDE             l,
           ktworkflowbd.kt_wf_preatendimento_guia g,
           ktworkflowbd.kt_wf_preatendimento      w,
           DE_PARA_CLASS_OCORRENCIA               dp
     where l.integrado = 'N'
       and g.id_wf_preatendimento = w.id_wf_preatendimento
       and g.id_wf_preatendimento_guia = l.id_wf_preatendimento_guia
       and dp.cd_classificacao_ocorrencia = l.cd_classificacao_ocor_guia
       and dp.id_workflow_atual = w.id_workflow;

  v_retorno varchar2(4000);

begin

  for x in c_mov loop
  
    if x.cd_classificacao_ocor_guia = 143 then
    
      select ktworkflowbd.kt_wf_fnc_preatend_mvto(x.id_wf_preatendimento,
                                                  x.id_etapa_destino,
                                                  x.id_etapa_status,
                                                  'INTEGRACAO',
                                                  'ENVIADO POR :' ||
                                                  x.cd_usuario,
                                                  NULL,
                                                  'FINALIZADO',
                                                  NULL,
                                                  NULL,
                                                  NULL,
                                                  NULL,
                                                  x.nr_transacao,
                                                  x.ds_protocolo_ans,
                                                  NULL)
        into v_retorno
        from dual;
    
    else
    
      select ktworkflowbd.kt_wf_fnc_preatend_mvto(x.id_wf_preatendimento,
                                                  x.id_etapa_destino,
                                                  x.id_etapa_status,
                                                  'INTEGRACAO',
                                                  'ENVIADO POR :' ||
                                                  x.cd_usuario,
                                                  NULL,
                                                  'ENVIADO',
                                                  NULL,
                                                  NULL,
                                                  NULL,
                                                  NULL,
                                                  x.nr_transacao,
                                                  x.ds_protocolo_ans,
                                                  NULL)
        into v_retorno
        from dual;
    
    end if;
  
    commit;
    update MOV_FLUXO_SETOR_SOUL_SAUDE g
       set g.integrado = 'S'
     where g.id_wf_preatendimento_guia = x.id_wf_preatendimento_guia;
  
    commit;
  
  end loop;
end pr_mov_fluxo_setor;
/
