 select distinct g.id_wf_preatendimento_guia,
                    ds_classificacao,
                    integrado,
                    cd_classificacao_ocor_guia,
                    cd_usuario,
                    dp.id_workflow_atual,
                    dp.id_etapa_destino,
                    w.id_wf_preatendimento,
                    dp.id_etapa_status,
                    l.nr_transacao,
                    l.ds_protocolo_ans
      from MOV_FLUXO_SETOR_SOUL_SAUDE             l,
           ktworkflowbd.kt_wf_preatendimento_guia g,
           ktworkflowbd.kt_wf_preatendimento      w,
           DE_PARA_CLASS_OCORRENCIA               dp
     where l.integrado = 'N'
       and g.id_wf_preatendimento = w.id_wf_preatendimento
       and g.id_wf_preatendimento_guia = l.id_wf_preatendimento_guia
       and dp.cd_classificacao_ocorrencia = l.cd_classificacao_ocor_guia
       and dp.id_workflow_atual = w.id_workflow;
       
       
       Select * from  ktworkflowbd.kt_wf_preatendimento_guia g 
       where g.id_wf_preatendimento = 309472
       
       
       Select * from ktworkflowbd.kt_wf_preatendimento  p
       where p.ds_transacao_operadora =  ' 2103000140628'  
       
       Select * from MOV_FLUXO_SETOR_SOUL_SAUDE m 
       where m.id_wf_preatendimento_guia = 228973 
       
       
