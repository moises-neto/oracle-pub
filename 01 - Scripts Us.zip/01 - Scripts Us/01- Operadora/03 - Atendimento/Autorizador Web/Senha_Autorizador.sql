Select a.cd_autorizador, p.nm_prestador prestador,
p.cd_prestador  ,
       p.ds_cod_conselho crm_login, a.nm_autorizador, a.ds_senha       ,       
       pe.cd_cnes cnes,
       pe.ds_endereco endereco,
       pe.nr_endereco nr,
       pe.ds_bairro bairro,
       pe.ds_complemento complemento,
       pe.ds_municipio cidade,
       pe.cd_prestador_endereco
from dbaps.prestador_endereco pe
inner join dbaps.prestador p on (p.cd_prestador = pe.cd_prestador)
inner join dbaps.prestador_endereco_autorizador pa on (pe.cd_prestador_endereco = pa.cd_prestador_endereco)
inner join dbaps.autorizador a on (pa.cd_autorizador = a.cd_autorizador)
where pe.cd_tipo_endereco not in (5, 7) --5= residencial, 7= cobran�a/principal, 8= Consultorio 1, 9 = consultorio 2, (consultorio >= 8)
--and p.nm_prestador like upper('Maria%Jose%')
--and p.ds_senha_web = 'EAX531'
--and a.nm_autorizador in ('130478')
--and p.ds_cod_conselho = '40348' --CRM
and p.cd_prestador = 300005
--and a.cd_autorizador = 2562
--And pe.cd_prestador_endereco = 1336
--and a.cd_autorizador = 800060
--And p.nm_prestador like '%THALES%MARTINEZ%'
and pe.dt_inativacao is null -- endereco  ativo
and p.dt_inativacao is null
order by p.nm_prestador




--= 1336
