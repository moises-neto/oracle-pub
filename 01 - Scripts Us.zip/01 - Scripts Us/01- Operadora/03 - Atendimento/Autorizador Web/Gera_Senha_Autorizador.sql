select custom.fnc_gera_senha_autorizador(169273) from dual 
