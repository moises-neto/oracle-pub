CREATE OR REPLACE Function DBAPS.Fn_Feriado(Pdia In Varchar2) Return Boolean Is
  Result        Boolean;
  Vano          Varchar2(4);
  Vcarnaval     Varchar2(10);
  Vsextasanta   Varchar2(10);
  Vpascoa       Varchar2(10);
  Vcorpuschrist Varchar2(10);
Begin
  
 Execute Immediate 'ALTER SESSION
                          SET NLS_DATE_LANGUAGE = "BRAZILIAN PORTUGUESE"
                              NLS_NUMERIC_CHARACTERS = ",."
                              NLS_DATE_FORMAT = "DD/MM/YYYY"
                              NLS_LANGUAGE = "BRAZILIAN PORTUGUESE"
                              NLS_SORT  = "BINARY"
                              NLS_TIME_FORMAT = "HH24:MI:SSXFF"
                              NLS_COMP  = "BINARY"';

  /*
  01/01  CONFRATERNIZACAO

  24/02  CARNAVAL           --+
  10/04  SEXTA FEIRA SANTA    | Feriados Inconstantes
  12/04  PASCOA               |
  11/06  CORPUS CHRISTI     --+

  21/04  TIRADENTES
  01/05  DIA DO TRABALHO
  09/07  REV. CONSTITUCION.
  15/08  ANIV.SOROCABA
  07/09  IND. DO BRASIL
  12/10  N. S. APARECIDA
  02/11  FINADOS
  15/11  PROCL. DA REPUBLICA
  20/11  CONSCIENCIA NEGRA
  25/12  NATAL */
  ---Substr(Vdtdigitacao, 1, 5)
  --Raise_application_error(-20000, 'Pdia '||Pdia);
  
  --rafael vidal - 22-05-2020
  --Projeto de Lei n° 351/2020,
  --https://www.al.sp.gov.br/propositura?id=1000324227
  --Foi adiado em 2020 o feriado de 9 de julho para o dia 25-05-2020
  --em tentativa de combater o covid-19
  If Pdia = '25/05/2020' Then
    Return True;
  Elsif Pdia = '09/07/2020' Then
    Return False;
    -- Moisés de Souza - 25/02/2021
    -- Foi adiado o feriado em 2021 por motivo da pandemia (COVID-19).
    -- Ainda não foi informado o dia de comemoração segundo site: https://www.carnaval2021.com/datas-carnaval-dias/
  ELSIf Pdia = '16/02/2021' Then
    Return False;  
  End If;
  
  
  Vano := Substr(to_date(Pdia,'dd/mm/yyyy'), -4);

  Vpascoa       := To_Char(To_Date(Data_Pascoa_Rafael(Vano)));
  Vsextasanta   := To_Char(To_Date(Vpascoa) - 2);
  Vcarnaval     := To_Char(To_Date(Vpascoa) - 47);
  Vcorpuschrist := To_Char(To_Date(Vpascoa) + 60);

  If Substr(Pdia, 1, 5) In ('01/01',
                            Substr(Vcarnaval, 1, 5),
                            Substr(Vpascoa, 1, 5),
                            Substr(Vsextasanta, 1, 5),
                            Substr(Vcorpuschrist, 1, 5),
                            '21/04',
                            '01/05',
                            '09/07',
                            '15/08',
                            '07/09',
                            '12/10',
                            '02/11',
                            '15/11',
                            '20/11',
                            '25/12') Then
    Result := True;
  Else
    Result := False;
  End If;
  Return(Result);
Exception
  When Others Then
    Raise_Application_Error(-20011,--Substr('Função', 1, 10),
                            'Função: ' || Sqlerrm ||
                            '. Momento de buscar feriados' || 'Pdia: ' || Pdia );
End Fn_Feriado;
