-- CM - Servi�os Prestados por Prestador - Resumo
/*Solicito o relat�rio contemplando a produ��o dos servi�os prestados por toda nossa rede pr�prio e prestadores jur�dicos abaixo:

Teste - 40101037
Holter - 20102020
Mapa - 20102038
ECG - 40101010

Per�odo: 2� semestre de 2021

Todos os prestadores, sendo pr�prio e credenciados.

Contemplando os profissionais/m�dicos solicitantes dos mesmos, e se atentar no valor pago, onde deve ser somado, 
caso tenha, HM e CO e uma �nica linha.

O relat�rio, dever� ter uma coluna com o local da realiza��o, ou seja, se for PJ (nome do PJ), se for m�dico cooperado
 (nome do m�dico cooperado) e se foi realizado no HMS (HMS), se for realizado na ZN (Zona Norte), etc...

 */
select distinct Custom.Fnc_Retorna_Abrangencia_Unimed(substr(v.Cd_Mat_Alternativa,
                                                             1,
                                                             3)) unimed,
                v.Cd_Prestador_Solicitante,
                v.Nm_Prestador_Solicitante,
                v.dt_competencia,
                v.CD_PRESTADOR,
                v.nm_prestador,
                v.ds_especialidade,
                v.GUIA,
                v.CD_LOTE,
                v.cd_Fatura,
                v.cd_mat_alternativa carteira,
                v.NOME,
                v.IDADE,
                v.PLANO,
                --  v.GRAU_PART,
                v.DT_REALIZADO,
                v.CD_PROCEDIMENTO cod_servico,
                v.ds_procedimento servico,
                v.QT_PAGO qtde,
                sum(v.VL_TOTAL_PAGO) valor,
                v.TP_TABELA valor_refer,
                v.VIAS,
                v.SN_AURG,
                v.SN_APD,
                v.SN_AVD /*,
       v.tp_pagamento*/

  from DBAPS.vw_cm_servicos_prestador2 v

 where V.dt_competencia between '202106' and '202112'
      
   AND v.Cd_Procedimento in (40101037, 20102020, 20102038, 40101010)

 group by Custom.Fnc_Retorna_Abrangencia_Unimed(substr(v.Cd_Mat_Alternativa,
                                                       1,
                                                       3)),
          v.dt_competencia,
          v.CD_PRESTADOR,
          v.nm_prestador,
          v.ds_especialidade,
          v.GUIA,
          v.CD_LOTE,
          v.cd_Fatura,
          v.cd_mat_alternativa,
          v.NOME,
          v.IDADE,
          v.PLANO,
          -- v.GRAU_PART,
          v.DT_REALIZADO,
          v.CD_PROCEDIMENTO,
          v.ds_procedimento,
          v.QT_PAGO,
          v.TP_TABELA,
          v.VIAS,
          v.SN_AURG,
          v.SN_APD,
          v.SN_AVD,
          v.Cd_Prestador_Solicitante,
          v.Nm_Prestador_Solicitante
 order by 2, 1
