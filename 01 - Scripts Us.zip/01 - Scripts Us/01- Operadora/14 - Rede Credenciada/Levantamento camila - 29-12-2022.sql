Create Table levantamento_rede_camila As
Select a.*
      
  From (Select distinct Custom.Fnc_Retorna_Abrangencia_Unimed(Substr(v.Cd_Mat_Alternativa,
                                                            1,
                                                            3)) Unimed,
               v.Dt_Competencia,
               v.Cd_Prestador,
               v.Nm_Prestador,
               v.Ds_Especialidade,
               v.Guia, 
               v.Cd_Conta_Medica,
               v.Cd_Lote,
               v.Cd_Fatura,
               v.Cd_Mat_Alternativa Carteira,
               v.Nome,
               v.Idade,
               v.Plano,
               v.Dt_Realizado,
               v.Cd_Procedimento Cod_Servico,
               v.Ds_Procedimento Servico,
               (Select Gp.Ds_Grupo_Procedimento
                  From Dbaps.Grupo_Procedimento Gp, Dbaps.Procedimento p
                 Where Gp.Cd_Grupo_Procedimento = p.Cd_Grupo_Procedimento
                   And p.Cd_Procedimento = v.Cd_Procedimento) As Ds_Grupo_Procedimento,
               v.Qt_Pago Qtde,
               --Sum(v.Vl_Total_Pago) Valor,
               v.Tp_Tabela Valor_Refer
        
          From Dbaps.Vw_Cm_Servicos_Prestador2 v
         Where v.Dt_Competencia between '202112' and '202211'
           And v.Cd_Prestador = 1001895
           group by Custom.Fnc_Retorna_Abrangencia_Unimed(substr(v.Cd_Mat_Alternativa,
                                                       1,
                                                       3)),
          v.dt_competencia,
          v.CD_PRESTADOR,
          v.Cd_Conta_Medica,
          v.nm_prestador,
          v.ds_especialidade,
          v.GUIA,
          v.CD_LOTE,
          v.cd_Fatura,
          v.cd_mat_alternativa,
          v.NOME,
          v.IDADE,
          v.PLANO,
          v.DT_REALIZADO,
          v.CD_PROCEDIMENTO,
          v.ds_procedimento,
          v.QT_PAGO,
          v.TP_TABELA   
          
       ) a
 Where a.Ds_Grupo_Procedimento Not In ('MATERIAIS', 'MEDICAMENTOS', 'OPME')
        

--2� - p�s cria��o da tabela

Select  a.*,
                Decode(Row_Number()
                       Over(Partition By a.Cd_Conta_Medica,
                            a.Carteira,
                            a.Nome,
                            a.Cd_Prestador Order By a.Cd_Conta_Medica,
                            a.Carteira,
                            a.Nome,
                            a.Cd_Prestador),
                       1,
                       b.Vl_Total,
                       0) Vl_Total
  From (Select l.Unimed,
               l.Dt_Competencia,
               l.Cd_Prestador,
               l.Nm_Prestador,
               l.Ds_Especialidade,
               l.Guia,
               l.Cd_Conta_Medica,
               l.Cd_Lote,
               l.Cd_Fatura,
               l.Carteira,
               l.Nome,
               l.Idade,
               l.Plano,
               l.Dt_Realizado,
               l.Cod_Servico,
               l.Servico,
               l.Ds_Grupo_Procedimento,
               l.Qtde,
               l.Valor_Refer
          From Levantamento_Rede_Camila_V12 l) a,
       
       (Select Sum(v.Vl_Total_Pago) As Vl_Total, v.Cd_Conta_Medica
          From Dbaps.Vw_Cm_Servicos_Prestador2 v
         Where v.Dt_Competencia Between '202112' And '202211'  
           And v.Cd_Prestador = 1001895
           
         Group By Custom.Fnc_Retorna_Abrangencia_Unimed(Substr(v.Cd_Mat_Alternativa,
                                                               1,
                                                               3)),
                  v.Dt_Competencia,
                  v.Cd_Prestador,
                  v.Cd_Conta_Medica,
                  v.Cd_Lote                  
        ) b

 Where a.Cd_Conta_Medica = b.Cd_Conta_Medica
