
/*Boa tarde:

Solicito a gentileza de relat�rio do per�odo dos �ltimos 3 meses, 
referente todos os pacientes que passaram pelas terapias constantes na planilha anexa, com o CID F84.0 E F84.1.

No relat�rio deve conter:

Data autoriza��o: DT_AUTORIZACAO
N�mero da guia: NR_GUIA
Unimed: CD_UNIMED_ORIGEM
Carteira
Nome
Idade
CID: CD_CID
Diagn�stico: DS_DIAGNOSTICO
C�digo Procedimento: CD_PROCEDIMENTO
Descri��o: DS_PROCEDIMENTO
E-mail benefici�rio
Telefone benefici�rio
E-mail titular plano
Telefone titular do plano*/

Select Distinct (Select g.Dt_Autorizacao
                   From Dbaps.Guia g
                  Where g.Nr_Guia = v.Nr_Guia) As Dt_Autorizacao,
                v.Nr_Guia,
                v.Cd_Unimed_Origem,
                v.Nr_Carteira_Beneficiario,
                v.Nm_Beneficiario,
                Custom.Fn_Idade_V2(Pdt_Comparacao => Trunc(v.Dt_Realizado),
                                   Pnascimento    => u.Dt_Nascimento,
                                   Pmascara       => 'a') || ' ' ||
                ' Anos ' ||
                
                Custom.Fn_Idade_V2(Pdt_Comparacao => v.Dt_Realizado,
                                   Pnascimento    => u.Dt_Nascimento,
                                   Pmascara       => 'm') || ' ' ||
                ' Meses'
                
                As Idade,
                
                (Select g.Cd_Cid
                   From Dbaps.Guia g
                  Where g.Nr_Guia = v.Nr_Guia) As Cd_Cid,
                (Select c.Ds_Cid
                   From Dbaps.Cid c, Dbaps.Guia g
                  Where c.Cd_Cid = g.Cd_Cid
                    And g.Nr_Guia = v.Nr_Guia) As Ds_Diagnostico,
                Nvl(v.Cd_Procedimento, v.Cd_Procedimento_Digitado) As Cd_Procedimento,
                (Select p.Ds_Procedimento
                   From Dbaps.Procedimento p
                  Where p.Cd_Procedimento = v.Cd_Procedimento
                 Union
                 Select p.Ds_Procedimento
                   From Dbaps.Procedimento p
                  Where p.Cd_Procedimento = v.Cd_Procedimento_Digitado) As Ds_Procedimento,
                Trunc(v.Dt_Realizado) As Dt_Realizacao,
                u.Ds_Email As Email,
                Nvl(u.Nr_Telefone, u.Nr_Celular) As Telefone,
                Nvl((Select (Select u.Ds_Email
                              From Dbaps.Usuario u
                             Where u.Cd_Matricula = Us.Cd_Matricula_Tem
                               And u.Sn_Ativo = 'S') As e_Email
                      From Dbaps.Usuario Us
                     Where Us.Cd_Matricula = v.Cd_Matricula
                       And Us.Sn_Ativo = 'S'),
                    u.Ds_Email) As Email_Titular,
                
                Nvl((Select (Select Nvl(u.Nr_Telefone, u.Nr_Celular)
                              From Dbaps.Usuario u
                             Where u.Cd_Matricula = Us.Cd_Matricula_Tem
                               And u.Sn_Ativo = 'S')
                      From Dbaps.Usuario Us
                     Where Us.Cd_Matricula = v.Cd_Matricula
                       And Us.Sn_Ativo = 'S'),
                    Nvl(u.Nr_Telefone, u.Nr_Celular)) As Telefone_Titular

  From Dbaps.v_Ctas_Medicas v, Dbaps.Usuario u
 Where v.Cd_Matricula = u.Cd_Matricula
   And v.Dt_Competencia Between '202203' And '202206'
   And Exists
 (Select 1
          From Proc_Moises p
         Where p.Cd_Procedimento =
               Nvl(v.Cd_Procedimento, v.Cd_Procedimento_Digitado))
   And Exists (Select 1
          From Dbaps.Guia g
         Where g.Nr_Guia = v.Nr_Guia
           And g.Cd_Cid In ('F840', 'F841'))

-- And v.Nr_Guia = 88809379

Union All -- Interc�mbio

Select Distinct (Select g.Dt_Autorizacao
                   From Dbaps.Guia g
                  Where g.Nr_Guia = v.Nr_Guia) As Dt_Autorizacao,
                v.Nr_Guia,
                v.Cd_Unimed_Origem,
                v.Nr_Carteira_Beneficiario,
                v.Nm_Beneficiario,
                Custom.Fn_Idade_V2(Pdt_Comparacao => Trunc(v.Dt_Realizado),
                                   Pnascimento    => (Select Bt.Dt_Nascimento
                                                        From Dbaps.Beneficiario_Transito Bt
                                                       Where Bt.Cd_Matricula =
                                                             v.Nr_Carteira_Beneficiario),
                                   Pmascara       => 'a') || ' ' ||
                ' Anos ' ||
                
                Custom.Fn_Idade_V2(Pdt_Comparacao => v.Dt_Realizado,
                                   Pnascimento    => (Select Bt.Dt_Nascimento
                                                        From Dbaps.Beneficiario_Transito Bt
                                                       Where Bt.Cd_Matricula =
                                                             v.Nr_Carteira_Beneficiario),
                                   Pmascara       => 'm') || ' ' || 'Meses'
                
                As Idade,
                
                (Select g.Cd_Cid
                   From Dbaps.Guia g
                  Where g.Nr_Guia = v.Nr_Guia) As Cd_Cid,
                (Select c.Ds_Cid
                   From Dbaps.Cid c, Dbaps.Guia g
                  Where c.Cd_Cid = g.Cd_Cid
                    And g.Nr_Guia = v.Nr_Guia) As Ds_Diagnostico,
                Nvl(v.Cd_Procedimento, v.Cd_Procedimento_Digitado) As Cd_Procedimento,
                (Select p.Ds_Procedimento
                   From Dbaps.Procedimento p
                  Where p.Cd_Procedimento = v.Cd_Procedimento
                 Union
                 Select p.Ds_Procedimento
                   From Dbaps.Procedimento p
                  Where p.Cd_Procedimento = v.Cd_Procedimento_Digitado) As Ds_Procedimento,
                Trunc(v.Dt_Realizado) As Dt_Realizacao,
                (Select Bt.Ds_Email
                   From Dbaps.Beneficiario_Transito Bt
                  Where Bt.Cd_Matricula = v.Nr_Carteira_Beneficiario) As Email,
                (Select Nvl(Bt.Nr_Telefone, Bt.Nr_Celular)
                   From Dbaps.Beneficiario_Transito Bt
                  Where Bt.Cd_Matricula = v.Nr_Carteira_Beneficiario) As Telefone,
                Null As Email_Titular,
                Null As Telefone_Titular

  From Dbaps.v_Ctas_Medicas v
 Where v.Dt_Competencia Between '202203' And '202206'
   And Exists
 (Select 1
          From Proc_Moises p
         Where p.Cd_Procedimento =
               Nvl(v.Cd_Procedimento, v.Cd_Procedimento_Digitado))
   And Exists (Select 1
          From Dbaps.Guia g
         Where g.Nr_Guia = v.Nr_Guia
           And g.Cd_Cid In ('F840', 'F841'))
   And v.Cd_Unimed_Origem <> 018
