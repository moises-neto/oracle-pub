
--apagar a linha
select /*(select p.nm_prestador
          from dbaps.prestador p
         Where dp.cd_prestador = p.cd_prestador) as nome_prest,  */
       dp.*,
       rowid
  from dbaps.desliga_prestador dp
 where dp.cd_prestador = 019847;
 
 select p.*, rowid from dbaps.prestador p
 where p.cd_prestador = 019847
 

