/*Cria��o da tabela*/
Create Table Custom.Afastamento_Prestador( 
cd_afastamento_prestador number (8) not null,
cd_prestador Number(14) not null,
Nm_Prestador Varchar2(500) not null,
CRM Varchar2(20) not null,
Tp_Afastamento Varchar(50) not null,
Dt_Afastamento Date not null,
Dt_Retorno Date,
Constraint PK_Afastamento Primary key (cd_afastamento_prestador),
Constraint FK_Prestador Foreign Key (cd_prestador) References dbaps.prestador (cd_prestador)
);

/*Cria��o da sequencia*/
Create Sequence custom.sq_afastamento_prestador
start  with 1
INCREMENT BY 1;

Select custom.sq_afastamento_prestador.nextval from dual;

/*Cria��o da trigger para auto incrimento do ID*/

Create or Replace Trigger CUSTOM.Trg_Auto_Incremento_ID
 
  BEFORE INSERT ON Custom.Afastamento_Prestador
  References New as New Old as Old 
 FOR EACH ROW
BEGIN
  SELECT sq_afastamento_prestador.nextval INTO :new.cd_afastamento_prestador FROM dual;
END;
 --Cria��o da trigger para evitar que exista mais de um afastamento para o mesmo prestador com a data de retorno nula

Create Or Replace Trigger Custom.Trg_Bk_Data
  BEFORE INSERT ON Custom.Afastamento_Prestador
  References New as New Old as Old 
  FOR EACH ROW
    
DECLARE
   PRAGMA AUTONOMOUS_TRANSACTION;                      
   v_data_retorno date();
   v_data_afastamento date;
   v_cd_prestador number(14);
   
Begin
  Select p.cd_prestador, p.dt_afastamento, p.dt_retorno 
  From custom.afastamento_prestador p
  Into v_cd_prestador, v_data_afastamento, v_data_retorno
  Where p.cd_prestador = :new.cd_prestador;

IF(v_cd_prestador = :New.cd_prestador And v_data_afastamento = :New.Dt_Afastamento) Then

IF(v_data_retorno is null) Then    
  Raise_Application_Error(-20001, 'Para esse prestador, j� existe um afastamento');
  
 End IF;
 
 End IF; 
End;


Select rowid, p.* from Custom.Afastamento_Prestador p 

Select p.cd_prestador, p.nm_prestador, p.crm
  From Custom.Afastamento_Prestador p
                                        
  
Select p.nm_prestador, p.tp_afastamento, p.dt_afastamento, nvl(to_char(p.dt_retorno),'Sem Preenchimento') as dt_retorno From Custom.Afastamento_Prestador p where p.crm =  '10'


