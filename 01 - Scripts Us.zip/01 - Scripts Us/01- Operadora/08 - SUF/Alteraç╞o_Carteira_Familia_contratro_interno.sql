/*
MU2007-047 - ALTERAR NUMERA��O CARTEIRINHA

alterar a numera��o das carteirinhas conforme abaixo:

Contrato 1005585

atual: 018 5708000218003
novo: 018 5739...

Contrato 1011700
atual: 018 5708000136007
novo: 018 5739...

 */
-- backup

Select c.cd_contrato_interno,  c.*, rowid From contrato c
Where c.cd_contrato in (1009155,1009113,1009418,1008649,1009071,1008691,1009072,1009074);

Select * From dbaps.usuario u
where u.cd_contrato in (1009155,1009113,1009418,1008649,1009071,1008691,1009072,1009074)

--

select
 c.cd_contrato_interno,
 c.cd_contrato,
 u.cd_matricula,
 u.cd_mat_alternativa,
 u.cd_familia,
 u.cd_familia_contrato,
 u.cd_dependencia
  from dbaps.usuario u, dbaps.contrato c
 where u.cd_contrato in (1009155,1009113,1009418,1008649,1009071,1008691,1009072,1009074)
   and c.cd_contrato = u.cd_contrato;

-- novo
select x.*,
       (select Dbaps.Fnc_Calc_Dig_Cartao_Unimed(x.carteira_sem_digito)
          from dual) digito,
       
       x.carteira_sem_digito || (select Dbaps.Fnc_Calc_Dig_Cartao_Unimed(x.carteira_sem_digito)
                                   from dual) cd_mat_alternativa

  from (select t.*,
               lpad(t.cd_familia, 6, '0') familia_carteira,
               '018' || t.cd_familia_contrato || lpad(t.cd_familia, 6, '0') ||
               t.cd_dependencia carteira_sem_digito
        --  (select Dbaps.Fnc_Calc_Dig_Cartao_Unimed('018750009602501') from dual) cd_mat_alternativa,
          from (select
                
                 u.cd_matricula,
                 u.cd_contrato,
                 
                 ((select max(ut.cd_familia)
                     from dbaps.usuario ut, dbaps.contrato cc
                    where cc.cd_contrato = ut.cd_contrato
                      and substr(cc.cd_contrato_interno, 0, 4) = substr(cp.cd_contrato_interno,0,4)) + 1) cd_familia,
                 
                 cp.cd_contrato_interno cd_familia_contrato,
                 
                 u.cd_dependencia
                
                  from dbaps.usuario u, dbaps.contrato c, dbaps.contrato cp
                 where u.cd_contrato in(1009155,1009113,1009418,1008649,1009071,1008691,1009072,1009074)
                   and c.cd_contrato = u.cd_contrato
                   And cp.cd_contrato = c.cd_contrato_tem) t) x; 
                 

-- 1� Titular
Declare
Begin

  For Ix In (select x.*,
                    (select Dbaps.Fnc_Calc_Dig_Cartao_Unimed(x.carteira_sem_digito)
                       from dual) digito,
                    
                    x.carteira_sem_digito ||
                    (select Dbaps.Fnc_Calc_Dig_Cartao_Unimed(x.carteira_sem_digito)
                       from dual) cd_mat_alternativa
             
               from (select t.*,
                            lpad(t.cd_familia, 6, '0') familia_carteira,
                            '018' || t.cd_familia_contrato ||
                            lpad(t.cd_familia, 6, '0') || t.cd_dependencia carteira_sem_digito
                     --  (select Dbaps.Fnc_Calc_Dig_Cartao_Unimed('018750009602501') from dual) cd_mat_alternativa,
                       from (select u.cd_contrato,
                                    u.cd_matricula,
                                    
                                     ((select max(ut.cd_familia)
                     from dbaps.usuario ut, dbaps.contrato cc
                    where cc.cd_contrato = ut.cd_contrato
                      and substr(cc.cd_contrato_interno, 0, 4) = substr(cp.cd_contrato_interno,0,4)) + 1) cd_familia,
                                    
                               cp.cd_contrato_interno cd_familia_contrato,
                                    
                                    u.cd_dependencia
                             
                               from dbaps.usuario u, dbaps.contrato c, dbaps.contrato cp
                              where u.cd_contrato in(1009074)
                                and c.cd_contrato = u.cd_contrato
                                And cp.cd_contrato = c.cd_contrato_tem
                                and u.tp_usuario = 'T') t) x) Loop
  
    Begin
    
      UPDATE DBAPS.USUARIO U
         SET U.Cd_Familia          = Ix.Cd_Familia,
             U.Cd_Familia_Contrato = Ix.Cd_Familia_Contrato,
             U.Cd_Mat_Alternativa  = Ix.Cd_Mat_Alternativa
       WHERE U.CD_CONTRATO = IX.CD_CONTRATO
         and u.cd_matricula = Ix.Cd_Matricula
         and u.tp_usuario = 'T';
         
         dbms_output.put_line('Matricula alterada: ' || ix.cd_matricula || ' Contrato: ' || ix.cd_contrato || ' Carteira nova: ' || ix.cd_mat_alternativa );
          commit;
    Exception
      When Others Then
        Rollback;
        Raise_Application_Error(-20002,
                                'Falha: ' || Sqlerrm || ' Matricula: ' ||
                                Ix.Cd_Matricula);
    End;
  End Loop;

Exception
  When Others Then
    Rollback;
    Raise_Application_Error(-20001, 'Falha: ' || Sqlerrm);
End;

/

-- backup
  select
  
   u.cd_matricula,
   u.cd_mat_alternativa,
   u.cd_familia,
   u.cd_familia_contrato,
   u.cd_dependencia
  
    from dbaps.usuario u, dbaps.contrato c
   where u.cd_contrato in(1009074)
     and c.cd_contrato = u.cd_contrato; 

--alter trigger DBAPS.TRG_USUARIO_UNIMED disable;

-- 2� Dependente
Declare
Begin

  For Ix In (select x.*,
       (select Dbaps.Fnc_Calc_Dig_Cartao_Unimed(x.carteira_sem_digito)
          from dual) digito,
       
       x.carteira_sem_digito || (select Dbaps.Fnc_Calc_Dig_Cartao_Unimed(x.carteira_sem_digito)
                                   from dual) cd_mat_alternativa

  from (select t.*,
               lpad(t.cd_familia, 6, '0') familia_carteira,
               '018' || t.cd_familia_contrato || lpad(t.cd_familia, 6, '0') ||
               t.cd_dependencia carteira_sem_digito
        --  (select Dbaps.Fnc_Calc_Dig_Cartao_Unimed('018750009602501') from dual) cd_mat_alternativa,
          from (select
                 u.cd_contrato,
                 u.cd_matricula,
                 
                  (Select us.cd_familia From dbaps.usuario us where u.cd_matricula_tem = us.cd_matricula
                  and us.cd_matricula_tem is null) cd_familia,
                 
                 cp.cd_contrato_interno cd_familia_contrato,
                 
                 u.cd_dependencia
                
                  from dbaps.usuario u, dbaps.contrato c, dbaps.contrato cp
                 where u.cd_contrato in(1009074)
                   and c.cd_contrato = u.cd_contrato 
                   And cp.cd_contrato = c.cd_contrato_tem
                    And cp.cd_contrato = c.cd_contrato_tem
                    and u.tp_usuario <> 'T') t) x) Loop
  
    Begin
    
      UPDATE DBAPS.USUARIO U
         SET U.Cd_Familia          = Ix.Cd_Familia,
             U.Cd_Familia_Contrato = Ix.Cd_Familia_Contrato,
             U.Cd_Mat_Alternativa  = Ix.Cd_Mat_Alternativa
       WHERE U.CD_CONTRATO = IX.CD_CONTRATO
         and u.cd_matricula = Ix.Cd_Matricula
         and u.tp_usuario <> 'T'; 
         
    dbms_output.put_line('Matricula alterada: ' || ix.cd_matricula || ' Contrato: ' || ix.cd_contrato || ' Carteira nova: ' || ix.cd_mat_alternativa );
        commit;
    Exception
      When Others Then
        Rollback;
        Raise_Application_Error(-20002,
                                'Falha: ' || Sqlerrm || ' Matricula: ' ||
                                Ix.Cd_Matricula);
                                
                                
    End;
  End Loop;

Exception
  When Others Then
    Rollback;
    Raise_Application_Error(-20001, 'Falha: ' || Sqlerrm);
End;

/

--alter trigger DBAPS.TRG_USUARIO_UNIMED enable;

