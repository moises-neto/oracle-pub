/*
Liberar tela para Altera��o de Respons�vel do Contrato

Contexto:
Ao reativar um contrato, o respons�vel financeiro
� alterado para o titular.
Por isso, a trava est� para todos
*/



-- Desliga a Triger:
ALTER TRIGGER DBAPS.TRG_RESP_CONTRATO_BLOK DISABLE;

-- Ap�s a corre��o, habilita a trigger:
ALTER TRIGGER DBAPS.TRG_RESP_CONTRATO_BLOK ENABLE;
