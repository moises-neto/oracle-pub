/*
Altera��o de datas do benefici�rio

A data de comiss�o inicial pode ser alterada com a permiss�o do RE.
J� a data de ades�o, s� poder� ser alterada ap�s a aprova��o da Francini - Cadastro.
Por isso, tais altera��es somente poder�o ser realizadas mediante chamado de Altera��o de Dados do Benefici�rio (Mudan�a)
ap�s o chamado ser devidamente aprovado pela Francini.

*/


select us.dt_cadastro, us.dt_comissao_inicial, us.* from dbaps.usuario us
where us.cd_contrato = '&Contrato'
and us.sn_ativo = 'S';


update dbaps.usuario us
set us.dt_cadastro = '&Dt_Correta',
us.dt_comissao_inicial = '&Dt_Correta'
where us.cd_contrato = '&Contrato'
and us.sn_ativo = 'S';


select us.dt_cadastro, us.dt_comissao_inicial, us.* from dbaps.usuario us
where us.cd_contrato = '&Contrato'
and us.sn_ativo = 'S';
