Select rowid,
       c.dt_vencimento_contrato,
       c.dt_venda,
       c.dt_prox_reajuste,
       c.nr_dia_vencimento
  From contrato c
 where c.cd_contrato = 1016295
