
-- Quando d� a mensagem que a proposta j� foi efetivada, mas n�o foi


-- ver se tem algum contrato vinculado com a proposta
select p.cd_novo_contrato, p.* from dbaps.proposta p
where p.cd_proposta = 4310;

-- ver se gerou algum contrato vinculado com a proposta
select c.cd_proposta, c.*, rowid from dbaps.contrato c
where c.cd_proposta = 4310;

-- ver se gerou benefici�rios
select u.cd_mat_alternativa, u.* from dbaps.usuario u
where u.cd_contrato = 1008110; -- pega o cd_novo_contrato da proposta (1� select)

-- passar o n�mero do contrato para desligamento do SUF
-- e limpar a proposta do contrato
select c.cd_proposta, c.*, rowid from dbaps.contrato c
where c.cd_proposta = 4310;
