/*
Quando a proposta � aprovada na data errada,
ser� solicitada a corre��o das datas do contrato,
o solicitante dever� informar os campos a serem alterados,
sendo:
Data Venda (DD/MM/YYYY)
Pr�ximo Reajuste (DD/MM/YYYY + 1 ano)
Vencimento do Contrato (DD/MM/YYYY + 1 ano)
e Dia de Vencimento (DD) - este campo corresponde ao dia de vencimento do boleto
*/


select co.dt_venda,
       co.dt_prox_reajuste,
       co.dt_vencimento_contrato,
       co.nr_dia_vencimento,
       co.*
  from dbaps.contrato co
 where co.cd_contrato = '&Contrato';

update dbaps.contrato co
   set co.dt_venda               = '&DtCorreta',
       co.dt_prox_reajuste       = add_months('&DtCorreta', 12),
       co.dt_vencimento_contrato = add_months('&DtCorreta', 12),
       co.nr_dia_vencimento = '&Dia_Vencto'
 where co.cd_contrato = '&Contrato';
 

select co.dt_venda,
       co.dt_prox_reajuste,
       co.dt_vencimento_contrato,
       co.nr_dia_vencimento,
       co.*
  from dbaps.contrato co
 where co.cd_contrato = '&Contrato';


/*Ap�s conferir a altera��o -> dar commit */

