/*
CH2104-4138 - Favor reativar Servi�o - Contrato 7015  8219 HIGHTECHX TECNOLOGIA DIGITAL LTDA M

Favor reativar servi�os
53,9001 - APH
9001 - BF
Contrato 7015  8219 HIGHTECHX TECNOLOGIA DIGITAL LTDA Me
Data 29/04/2021

*/
select u.cd_contrato,
       u.cd_matricula,
       su.cd_servico,
       su.dt_exclusao,
       ds.dt_desligamento,
       ds.dt_reativacao
  from dbaps.usuario           u,
       dbaps.servicos_usuarios su,
       dbaps.desliga_servico   ds
 where u.cd_contrato in (1019281,1019279) --contrato MV
   and su.cd_matricula = u.cd_matricula
   and ds.cd_matricula = u.cd_matricula
   and ds.cd_servico = su.cd_servico
   and su.cd_servico in (53,9001)
   and u.sn_ativo = 'S';

Declare
Begin

  For Ix In (select u.cd_contrato,
                    u.cd_matricula,
                    su.cd_servico,
                    su.dt_exclusao,
                    ds.dt_desligamento,
                    ds.dt_reativacao
               from dbaps.usuario           u,
                    dbaps.servicos_usuarios su,
                    dbaps.desliga_servico   ds
              where u.cd_contrato in (1019281,1019279) --Contrato MV
                and su.cd_matricula = u.cd_matricula
                and ds.cd_matricula = u.cd_matricula
                and ds.cd_servico = su.cd_servico
                And ds.dt_reativacao is null
                and su.cd_servico in (53,9001)
                and u.sn_ativo = 'S') Loop
  
    Begin
    
      UPDATE DBAPS.Desliga_Servico ds
         SET ds.dt_reativacao = '01/03/2022'
       WHERE ds.cd_matricula = Ix.Cd_Matricula
         and ds.cd_servico = Ix.Cd_Servico
         and ds.dt_desligamento = Ix.Dt_Desligamento
         and ds.cd_servico in (53,9001);
    
      update dbaps.servicos_usuarios su
         set su.dt_exclusao = null
       where su.cd_matricula = Ix.Cd_Matricula
         and su.cd_servico = Ix.Cd_Servico
         and su.dt_exclusao = Ix.Dt_Exclusao;
    
    Exception
      When Others Then
        Rollback;
        Raise_Application_Error(-20002,
                                'Falha: ' || Sqlerrm || 'Matricula: ' ||
                                Ix.Cd_Matricula || ' Servi�o: ' ||
                                Ix.Cd_Servico);
    End;
  End Loop;

Exception
  When Others Then
    Rollback;
    Raise_Application_Error(-20001, 'Falha: ' || Sqlerrm);
End;

/

  select u.cd_contrato,
         u.cd_matricula,
         su.cd_servico,
         su.dt_exclusao,
         ds.dt_desligamento,
         ds.dt_reativacao
    from dbaps.usuario           u,
         dbaps.servicos_usuarios su,
         dbaps.desliga_servico   ds
   where u.cd_contrato in (8219) --Contrato MV
     and su.cd_matricula = u.cd_matricula
     and ds.cd_matricula = u.cd_matricula
     and ds.cd_servico = su.cd_servico
     and su.cd_servico in (53,9001)
     and u.sn_ativo = 'S';
