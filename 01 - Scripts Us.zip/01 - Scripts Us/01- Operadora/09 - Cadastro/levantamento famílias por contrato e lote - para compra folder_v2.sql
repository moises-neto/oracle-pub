select distinct u.cd_familia familia,
                u.cd_contrato,
                ca.cd_lote lote,
                l.dt_lote,
                upper(to_char(l.dt_lote, 'month')) mes
  from dbaps.usuario       u,
       dbaps.carteira      ca,
       dbaps.contrato      c,
       dbaps.lote_carteira l
 where u.cd_matricula = ca.cd_matricula
   and u.cd_contrato = c.cd_contrato
   and l.cd_lote = ca.cd_lote
   --and trunc(u.dt_cadastro_sistema) between '01/06/2020' and '31/05/2021'
   and trunc(l.dt_lote) between '01/06/2020' and '31/05/2021'
   and l.Cd_Motivo_Emissao_Carteira in ('1')
   and c.sn_demitido_aposentado_obito = 'N'
   and c.tp_contrato in ('E', 'A')
  and c.sn_demitido_aposentado_obito = 'N'
  and c.sn_remido = 'N'
  And c.cd_contrato_interno <> 2021
  -- and l.cd_lote = 16124
 --  and u.cd_familia = 2
 order by 3
