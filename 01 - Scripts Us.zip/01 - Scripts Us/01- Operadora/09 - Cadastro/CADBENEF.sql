select t.*, rowid from tmp_conf_cadbenef t;


select t.*,
       
       case
         when (sn_envio_a1300_co = 'N' or sn_envio_a1300_us = 'N') then
          'MARCADO COMO N�O ENVIA A1300'
         when trunc(t.dt_cadastro) >= nvl('&Dt_Referencia', trunc(sysdate)) then
          'ADES�O NO M�S DA NOTIFICA��O (ir� no pr�ximo A1300)'
         when trunc(t.dt_cadastro_sistema) > trunc(t.dt_cadastro) then
          'CADASTRADO AP�S ADES�O'
         when trunc(t.dt_desligamento) <= last_day(t.dt_cadastro) then
          'DESLIGAMENTO NO M�S DA ADES�O'
         when trunc(t.dt_desligamento) < trunc(t.dt_cadastro) + 30 then
          'DESLIGAMENTO COM MENOS DE 30 DIAS'
         when trunc(t.dt_cadastro) >= nvl('&Dt_Referencia', trunc(sysdate)) then
          'ENVIADO NO M�S DA NOTIFICA��O'
         when t.migracao_contrato is not null and
              trunc(t.migracao_contrato) >= nvl('&Dt_Referencia', trunc(sysdate)) then
          ' MIGRA��O DE CONTRATO EM: ' || t.migracao_contrato ||
          ' (m�s da notifica��o)'
         when t.troca_carteira is not null and
              trunc(t.troca_carteira) >= nvl('&Dt_Referencia', trunc(sysdate)) then
          ' TROCA DE CARTEIRA EM: ' || t.troca_carteira ||
          ' (m�s da notifica��o)'
         else
          null
       end situacao

  from (select distinct co.cd_contrato_interno,
                        co.tp_contrato,
                        co.sn_ativo            contrato_ativo,
                        co.Sn_Demitido_Aposentado_Obito,
                        co.sn_remido,
                        co.sn_envio_a1300      sn_envio_a1300_co,
                        us.sn_ativo            benef_ativo,
                        us.cd_matricula,
                        us.cd_mat_alternativa,
                        us.nm_segurado,
                        us.dt_cadastro,
                        us.dt_cadastro_sistema,
                        us.sn_envio_a1300      sn_envio_a1300_us,
                        
                        (select max(d.dt_desligamento)
                           from dbaps.desligamento d
                          where d.cd_matricula = us.cd_matricula
                            and d.dt_reativacao is null) dt_desligamento,
                        
                        (select max(hc.dt_inclusao)
                           from dbaps.his_contrato hc
                          where hc.cd_contrato = us.cd_contrato
                            and hc.cd_matricula = us.cd_matricula) migracao_contrato,
                        
                        (select max(ca.dt_emissao)
                           from dbaps.carteira ca
                          where ca.cd_matricula = us.cd_matricula
                            and ca.ds_numero_carteira <>
                                us.cd_mat_alternativa) troca_carteira,
                        
                        (select max(pr.dh_geracao)
                           from dbaps.ptu_a1300_r306      r6,
                                dbaps.ptu_remessa_retorno pr
                          where pr.cd_ptu_remessa_retorno =
                                r6.cd_ptu_remessa_retorno
                            and r6.id_benef =
                                substr(us.cd_mat_alternativa, 4, 13)) ultimo_a1300
        
          from dbaps.usuario us, dbaps.contrato co, tmp_conf_cadbenef t
         where co.cd_contrato = us.cd_contrato
           and t.id_benef = substr(us.cd_mat_alternativa, 4, 13)                          
        ) t;
             
        select *
  from tmp_conf_cadbenef t
 where not exists
 (select 1
          from dbaps.usuario us
         where substr(us.cd_mat_alternativa, 4, 13) = t.id_benef);
