/*
MU2103-010 - Altera��o de Tabela de pre�o

Favor alterar as tabelas do contrato 5252 / 3598 - TABELIAO DE PROTESTO DE LETRAS E TITULOS.

PLANO 269 - PARA TABELA 1203

PLANO 270 - PARA TABELA 1204

*/

-- Tabela de Pre�o
select pc.cd_plano, pc.cd_tabela_preco, pc.*, rowid from dbaps.plano_contrato pc
where pc.cd_contrato = 3598;

-- CONFERIR
select * from dbaps.valores_tabela_contrato vtc
where vtc.cd_contrato = 3598
and vtc.cd_plano = 269
and vtc.cd_tabela_preco = 1203;

