/*
Favor criar um relat�rio com as vidas novas PJ e PF, m�s a m�s, desde Janeiro/2021, com as idades hoje:
Matr�cula, Nome Benefici�rio, N�mero Cart�o, Plano PJ ou PF, Data Inclus�o, Data de Nascimento, Idade, Sexo.
*/

Select u.cd_matricula as Matricula,
       u.nm_segurado as "Nome Benefici�rio",
       u.cd_mat_alternativa as "N�mero do Cart�o",
       'PF' AS "Plano",
       u.dt_cadastro as "Data Inclus�o",
       u.dt_nascimento as "Data de Nascimento",
       fn_idade(PDT_COMPARACAO => sysdate, PNASCIMENTO => u.dt_nascimento) as Idade,
       u.tp_sexo As "Sexo"

  From Dbaps.Usuario u, Dbaps.Contrato c
 Where u.cd_contrato = c.cd_contrato
   And trunc(u.dt_cadastro) Between '01/01/2021' AND Sysdate
   and (c.tp_contrato = 'I' or
       (c.tp_contrato = 'A' and c.sn_demitido_aposentado_obito = 'S'))
       
Union

 Select u.cd_matricula as Matricula,
       u.nm_segurado as "Nome Benefici�rio",
       u.cd_mat_alternativa as "N�mero do Cart�o",
       'PJ' AS "Plano",
       u.dt_cadastro as "Data Inclus�o",
       u.dt_nascimento as "Data de Nascimento",
       fn_idade(PDT_COMPARACAO => sysdate, PNASCIMENTO => u.dt_nascimento) as Idade,
       u.tp_sexo As "Sexo"

  From Dbaps.Usuario u, Dbaps.Contrato c
 Where u.cd_contrato = c.cd_contrato
   And trunc(u.dt_cadastro) Between '01/01/2021' AND Sysdate
   And c.sn_demitido_aposentado_obito = 'N'
   and c.tp_contrato in ('E', 'A')      
