Select * From sib_usuario


Select * From sib_retorno_custom c
where c.nome like 'THAIS EMANOELE RIBEIRO DOS SANTOS PROENCA';

Select u.cd_mat_alternativa, u.cd_cco, u.nr_div_cco, rowid  from dbaps.usuario u
Where u.nm_segurado like 'THAIS EMANOELE RIBEIRO DOS SANTOS PROENCA'

--Velho
0184263000056017 
0345479609 01 --cco e dig
--Atual
461114766  5 --cco e dig
0185700000046010 --carteira

select * From sib s
where s.nr_sequencial = 537;

select * From sib_usuario s
where s.cd_sib = 578
and s.cd_matricula = 253990122


Select u.cd_mat_alternativa From dbaps.usuario u
Where u.cd_matricula = 253990122
