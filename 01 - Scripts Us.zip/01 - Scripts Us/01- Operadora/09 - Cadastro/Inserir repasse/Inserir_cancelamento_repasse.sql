BEGIN
  DBAMV.PKG_MV2000.ATRIBUI_EMPRESA('1');
END;
/

  Select ru.*
    From dbaps.usuario                     u,
         dbaps.contrato                    c,
         dbaps.repasse_intercambio_usuario ru
   where u.cd_contrato = c.cd_contrato
     and ru.cd_matricula = u.cd_matricula
     and c.cd_contrato_interno = '5789'
     and u.sn_ativo = 'S'
     and RU.CD_REPASSE_INTERCAMBIO_USUARIO IN
         (Select max(riu.cd_repasse_intercambio_usuario)
            From dbaps.repasse_intercambio_usuario riu
           where riu.cd_matricula = ru.cd_matricula)
     and ru.dt_cancelamento is null 
     
   
  
   Declare
  
   v_seq number;

Begin

  v_seq := 0;

  For Ix In (
             
             Select ru.cd_repasse_intercambio,
                     ru.cd_repasse_intercambio_usuario,
                     RU.CD_MATRICULA,
                     RU.DT_REPASSE,
                     ru.cd_multi_empresa,
                     '10/01/2022' as DT_CANCELAMENTO,
                     '10/01/2022' AS DT_INCLUSAO,
                     'D' AS TP_MOVIMENTACAO,
                     RU.DT_COMP_RISCO,
                     RU.NR_CONTRATO_ORIGEM_REPASSE,
                     RU.SN_RN430,
                     RU.CD_CONTRATO,
                     RU.CD_PLANO,
                     RU.CD_MAT_ALTERNATIVA,
                     RU.CD_FAMILIA
             
               From dbaps.usuario                     u,
                     dbaps.contrato                    c,
                     dbaps.repasse_intercambio_usuario ru
              where u.cd_contrato = c.cd_contrato
                and ru.cd_matricula = u.cd_matricula
                and c.cd_contrato_interno = '5789'
                and u.sn_ativo = 'S'
                and RU.CD_REPASSE_INTERCAMBIO_USUARIO IN
                    (Select max(riu.cd_repasse_intercambio_usuario)
                       From dbaps.repasse_intercambio_usuario riu
                      where riu.cd_matricula = ru.cd_matricula)
                and ru.dt_cancelamento is null
             
             ) Loop
  
    Begin
    
      Begin
        Update dbaps.repasse_intercambio_usuario ruu
           set ruu.dt_cancelamento = '10/01/2022'
         where ruu.cd_repasse_intercambio_usuario =
               ix.cd_repasse_intercambio_usuario;
      
      End;
    
      v_seq := dbaps.seq_repasse_intercambio_usu.nextval;
    
      INSERT INTO dbaps.repasse_intercambio_usuario
        (cd_repasse_intercambio_usuario,
         cd_repasse_intercambio,
         cd_matricula,
         dt_repasse,
         cd_multi_empresa,
         dt_inclusao,
         dt_comp_risco,
         tp_movimentacao,
         dt_cancelamento,
         sn_rn430,
         cd_contrato,
         cd_plano,
         cd_mat_alternativa,
         cd_familia)
      values
        (v_seq,
         Ix.Cd_Repasse_Intercambio,
         Ix.Cd_Matricula,
         Ix.Dt_Repasse,
         Ix.Cd_Multi_Empresa,
         Ix.Dt_Inclusao,
         Ix.Dt_Comp_Risco,
         Ix.tp_movimentacao,
         Ix.dt_cancelamento,
         Ix.Sn_Rn430,
         Ix.Cd_Contrato,
         Ix.Cd_Plano,
         Ix.Cd_Mat_Alternativa,
         Ix.cd_familia);
    
    Exception
      When Others Then
        Rollback;
        Raise_Application_Error(-20002,
                                'Falha: ' || Sqlerrm || ' Matricula: ' ||
                                Ix.Cd_Matricula);
    End;
  End Loop;

Exception
  When Others Then
    Rollback;
    Raise_Application_Error(-20001, 'Falha: ' || Sqlerrm);
End;
