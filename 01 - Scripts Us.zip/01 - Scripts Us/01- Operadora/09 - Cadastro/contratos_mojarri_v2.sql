select u.cd_matricula AS Matricula,
       u.cd_mat_alternativa As Carteira,
       u.nm_segurado As Beneficiario,
       Case (u.tp_usuario)
         When 'T' Then
          'Titular'
         When 'D' Then
          'Dependente'
         When 'A' Then
          'Agregado'
         else
          'Verificar'
       end Tipo_Beneficiario,
       u.cd_plano,
       p.ds_plano
  from dbaps.usuario u, dbaps.contrato c, dbaps.plano p
 where u.cd_contrato = c.cd_contrato
   and p.cd_plano = u.cd_plano
   and substr(u.cd_familia_contrato, 0, 4) = 2020
   and u.sn_ativo = 'S'
   order by Beneficiario, Tipo_Beneficiario 

  /*select *
          from dbaps.contrato c
         where c.cd_contrato_interno = '2020'
        
          select substr(u.cd_familia_contrato, 0, 4)
                  from dbaps.usuario u
                 where u.cd_matricula = 1876710010*/
