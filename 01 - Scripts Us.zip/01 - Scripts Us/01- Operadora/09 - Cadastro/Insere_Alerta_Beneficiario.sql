Declare

  Cursor cDados is
  
    Select u.cd_matricula
      From usuario u, contrato c
     where u.cd_contrato = c.cd_contrato
       and c.tp_contrato = 'U'
       And u.cd_matricula not in
           (Select u.cd_matricula
              From usuario u, contrato c, Dbaps.Alerta a
             where u.cd_contrato = c.cd_contrato
               and a.cd_identificador = u.cd_matricula
               and a.tp_identificador = 'BENEFICIARIO'
               and c.tp_contrato = 'U');

  v_Cd_Alerta   Number := 0;
  v_Cd_Italerta Number := 0;

BEGIN

  FOR i IN cDados LOOP
    Select Dbaps.Seq_Alerta.Nextval Into v_Cd_Alerta From Dual;
    Begin
      Insert Into Dbaps.Alerta
        (Cd_Alerta,
         Cd_Identificador,
         Tp_Identificador,
         Cd_Usuario_Inclusao,
         Dt_Usuario_Inclusao)
      Values
        (v_Cd_Alerta, i.Cd_Matricula, 'BENEFICIARIO', 'DBAPS', Sysdate);
      Select Dbaps.Seq_Italerta.Nextval Into v_Cd_Italerta From Dual;
    
      Insert Into Dbaps.Italerta
        (Cd_Italerta,
         Cd_Alerta,
         Cd_Departamento,
         Dt_Vigencia_Inicial,
         Dt_Vigencia_Final,
         Sn_Bloqueia_Atendimento,
         Ds_Observacao,
         Cd_Usuario_Inclusao,
         Dt_Usuario_Inclusao)
      Values
        (v_Cd_Italerta,
         v_Cd_Alerta,
         22, --CADASTRO
         Trunc(Sysdate) - 1,
         Add_Months(Trunc(Sysdate), 300), --PARA ADICIONAR 300 MESES, POIS SE DEIXAR EM BRANCO (SEM DATA) ELE N�O FUNCIONA
         'N',
         'BENEFICI�RIO N�O PERTENCE A UNIMED SOROCABA (RN 430)',
         'DBAPS',
         Sysdate /*,
                      ''*/);
    Exception
      When others Then
      
        Raise_Application_Error(-20001,
                                'Falha: ' || Sqlerrm || 'campo: ' ||
                                i.cd_matricula);
    End;
  END LOOP;

Exception
  When DUP_VAL_ON_INDEX THEN
    Null;
End;
/* When Others Then
    Rollback;
    Raise_Application_Error(-20001,
                            'Falha: ' || Sqlerrm || 'campo: ' || cDados.cd_matricula);*/

Select a.*, it.*
  From Dbaps.Alerta a, Dbaps.Italerta it
 where a.cd_alerta = it.cd_alerta
