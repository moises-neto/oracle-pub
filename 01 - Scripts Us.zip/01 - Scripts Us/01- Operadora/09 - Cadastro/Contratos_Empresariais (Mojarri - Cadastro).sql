select * from dbaps.contrato co
where co.tp_contrato in ('A', 'E')
and co.sn_demitido_aposentado_obito = 'S'
and co.sn_remido = 'N'
and co.sn_ativo = 'S';
