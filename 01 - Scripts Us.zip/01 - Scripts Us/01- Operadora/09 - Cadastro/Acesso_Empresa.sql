select co.cd_empresa, co.*
  from dbaps.contrato co
 where co.cd_contrato_interno = '2021'
   and co.cd_contrato = 1013907;

select e.portal_cd_login_alternativo, e.portal_ds_senha_alternativa, e.*
  from dbaps.empresa e
 where e.cd_empresa = 8212;
