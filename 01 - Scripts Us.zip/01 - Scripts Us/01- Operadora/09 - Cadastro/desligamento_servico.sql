declare
begin
  for x in (select u.cd_matricula
              from dbaps.usuario u
             where u.cd_contrato = '1014390'
             ) -- Colocar o contrato aqui
   loop
    begin 
      update dbaps.desliga_servico d
         set d.dt_desligamento = '03/03/2022' -- Colocar a data de desligamento desejada aqui
       where d.cd_matricula = x.cd_matricula
         and d.cd_servico in (9001, 53); -- Colocar o servi�o aqui
    
    Exception
      When Others Then
        Rollback;
        Raise_Application_Error(-20002,
                                'Falha: ' || Sqlerrm || ' Matricula: ' ||
                                x.Cd_Matricula);
      
    end;
  end loop;

Exception
  When Others Then
    Rollback;
    Raise_Application_Error(-20001, 'Falha: ' || Sqlerrm);
End;



DBAPS.DES_SERV_PK


Select d.*, Rowid
  From Dbaps.Servicos_Usuarios d

 Where Exists (Select 1
          From Dbaps.Usuario u
         Where d.Cd_Matricula = u.Cd_Matricula
           And u.Cd_Contrato = 1014390)
   And d.Cd_Servico In (9001, 53)
   
   And d.dt_exclusao Is  Null;

   
 Select d.*, Rowid
  From Dbaps.Desliga_Servico d

 Where Exists (Select 1
          From Dbaps.Usuario u
         Where d.Cd_Matricula = u.Cd_Matricula
           And u.Cd_Contrato = 1014390)
   And d.Cd_Servico In (9001, 53); 
   
   
   Select s.*, Rowid From dbaps.servicos_contrato s
   Where s.cd_contrato = '1014390'  
   
   
   ---01/02/2021     
   --MOSOUZA
   
       

