Select Distinct '018' As Cd_Uni,
                c.ds_numero_carteira As Id_Benef,
                nvl(trunc(h.Dh_Ultima_Alteracao),trunc(h.dt_inclusao)) As Dt_Desligamento,
                '01' As Motivo_Exclusao,
                u.Cd_Matricula As Cd_Matricula,
                '01' As Cd_Mot_Desligamento,
                p.Cd_Plano As Cd_Plano,
                Decode(p.Tp_Periodo_Implantacao,
                       1,
                       p.Cd_Plano_Operadora,
                       p.Cd_Registro_Ms) As Reg_Plano_Ans
  From Dbaps.Usuario        u,
       Dbaps.Carteira       c,
       Dbaps.Plano          p,
       custom.Temp_Cadbenef_Moises t,
       His_Contrato         h
 Where c.Cd_Matricula = u.Cd_Matricula
   And p.Cd_Plano = u.Cd_Plano
   And t.Cd_Carteirinha = c.Ds_Numero_Carteira
   And u.Cd_Mat_Alternativa <> c.Ds_Numero_Carteira
   And h.Cd_Matricula = u.Cd_Matricula
      
   And h.Cd_His_Contrato =
       (Select Max(Hh.Cd_His_Contrato)
          From His_Contrato Hh
         Where Hh.Cd_Matricula = h.Cd_Matricula);