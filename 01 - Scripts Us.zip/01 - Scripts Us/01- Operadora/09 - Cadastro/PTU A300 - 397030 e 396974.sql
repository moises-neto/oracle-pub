-- 397030, 396974
/*
Mojarri, 08:45
exporta 2 arquivos PTU para o excel por gentileza?

Mojarri, 09:21
id 397030

Mojarri, 09:21
id 396974
*/


/*TAB=397030*/
select u.tp_usuario, p.* from ptu_a300_r304 p, dbaps.usuario u
where p.cd_ptu_remessa_retorno = 397030
and substr(u.cd_mat_alternativa, 4, 13) = p.id_benef
order by p.nm_benef;



/*TAB=396974*/
select u.tp_usuario, p.* from ptu_a300_r304 p, dbaps.usuario u
where p.cd_ptu_remessa_retorno = 396974
and substr(u.cd_mat_alternativa, 4, 13) = p.id_benef
order by p.nm_benef;
