/*
avor realizar levantamento dos benefici�rios do contrato 2021  UNIMED DE SOROCABA COOPERATIVA DE TRABALHO MEDICO 
que foram desligados com o motivo 5 inclusao indevida
*/

Select * from dbaps.usuario u

where u.cd_contrato = 2021


select u.cd_matricula AS Matricula,
       u.cd_empresa || ' - ' || c.nm_responsavel_financeiro AS Empresa,
       u.nm_segurado As Beneficiario,
       u.cd_mat_alternativa As Carteira
  from dbaps.usuario u, dbaps.contrato c
 where u.cd_contrato  = c.cd_contrato
 and c.cd_contrato_interno = '2021'
   and u.cd_matricula in
       (select d.cd_matricula
          from DBAPS.DESLIGAMENTO d
         where d.cd_mot_desligamento = 5)
