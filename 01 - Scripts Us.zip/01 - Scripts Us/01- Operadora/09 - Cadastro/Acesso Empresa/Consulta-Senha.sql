select e.cd_empresa,
         t.nm_responsavel_financeiro,
         l.nrcontrato                  login,
         l.senha,
         t.cd_contrato                 contratomv,
         e.portal_cd_login_alternativo,
         e.portal_ds_senha_alternativa,
         l.smce
    from custom.empresa_relatorio_utilizacao@orcoop l,
         dbaps.contrato                             t,
         dbaps.empresa                              e
   where l.nrcontrato = t.cd_contrato_interno
     and t.cd_contrato_tem is null
     and e.cd_empresa = t.cd_empresa
     and e.cd_empresa_tem is null   
     and e.sn_ativo = 'S'
     and l.nrcontrato = 2021
     and l.smce = 'S';
     /*  
     redefini login/senha
     select e.portal_cd_login_alternativo, e.portal_ds_senha_alternativa, rowid from dbaps.empresa e where e.cd_empresa = '821'
     */
select e.identificacao, e.senha, e.*
  from custom.empresa_relatorio_utilizacao@orcoop e
 where e.nrcontrato in ('2021'); -- contrato interno
