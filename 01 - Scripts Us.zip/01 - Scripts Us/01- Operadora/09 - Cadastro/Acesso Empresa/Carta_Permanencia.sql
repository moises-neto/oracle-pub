Select distinct Ca.Familia familia,
              Ca.Pessoa_Tit titular,
              Ca.Pessoa_Dependente nome,
              ca.Cd_Graudependencia cdtipo,
              ca.Ds_Graudependencia tipo,
              Ca.Dtiniciocontrato inicio,
              Ca.Dt_Nascimento nascimento,
              ca.idade,
              ca.Nrcontrato contrato,
              ca.Cpf_Usu cpf,
              ca.Nr_Cns nrcns,
              ca.Cdusuario_Dependente carteirinha,
              ca.Tp_Acomodacao tpplano,
              decode(ca.Ds_Lotacao, '', '-', ca.Ds_Lotacao) lotacao,
              decode(ca.dt_validade_carteira, '', '-', ca.dt_validade_carteira) valcarteira,
              ca.Cd_Matricula_Rh,
              'R$ '|| Dbaps.Fnc_Valor_Beneficiario(ca.Cd_Matricula,
              Sysdate,
              ca.Nr_Idade_Fixada,
              'N',
              Null) Valor_Mensalidade_Benef
              From Custom.Vw_Contrato_Usuario_Ae Ca
              Where Ca.Nrcontrato = '2021'
              and ca.Sn_Demitido_Aposentado_Obito = 'N'
              Order By Ca.Pessoa_Tit, Ca.Familia, ca.Cd_Graudependencia
