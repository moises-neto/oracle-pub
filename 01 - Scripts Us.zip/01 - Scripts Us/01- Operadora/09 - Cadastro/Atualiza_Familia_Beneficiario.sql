--update dbaps.usuario us
--set us.cd_familia = substr(us.cd_familia_contrato,5,6)
select us.cd_matricula,
       substr(us.cd_familia_contrato, 5, 6) as Familia_Nova,
       us.cd_familia,
       us.cd_familia_contrato,
       us.sn_titular,
       us.*
  from dbaps.usuario us
 where  us.cd_contrato = 1015474-- us.cd_matricula in (1928930091)
   for update;
