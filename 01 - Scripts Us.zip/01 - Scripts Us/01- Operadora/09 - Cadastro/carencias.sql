--6) Inclus�es_Observacao: para os benefici�rios com os Hist�ricos: 9, 9001 e 20
--(M_USUARIO >> Hist�rico >> Tp. Observa��o),
--informar: Matr�cula, Nome completo benefici�rio, N�mero Cart�o, Data Ades�o, Modelo Car�ncia, Tp Observa��o e Observa��o

Select Distinct u.cd_matricula as Matricula,
                'PF' as Tipo,
                u.nm_segurado AS Nome_Completo,
                u.cd_mat_alternativa as Carteira,
                u.dt_cadastro as Data_Adesao,
                ac.ds_agrupamento_carencia as Modelo_Carencia,
                (Select tou.ds_tipo_observacao_usuario
                   From dbaps.tipo_observacao_usuario tou
                  Where tou.cd_tipo_observacao_usuario =
                        uo.cd_tipo_observacao_usuario) as TP_observacao,
                        uo.cd_tipo_observacao_usuario,
                uo.ds_usuario_observacao as Observacao
From dbaps.usuario        u,
       usuario_observacao   uo,
       dbaps.agrupamento_carencia ac,
       dbaps.contrato       c
 Where to_date(u.dt_cadastro, 'DD/MM/YYYY') between '01/01/2021' AND
       '29/10/2021'
   and u.cd_matricula = uo.cd_matricula 
   and u.cd_agrupamento_carencia = ac.cd_agrupamento_carencia
    and u.cd_matricula = uo.cd_matricula
   and u.cd_contrato = c.cd_contrato
   and uo.cd_tipo_observacao_usuario in (9, 9001, 20)
   
   
   and (c.tp_contrato = 'I' or
        (c.tp_contrato = 'A' and c.sn_demitido_aposentado_obito = 'S'))

Union

Select Distinct u.cd_matricula as Matricula,
                'PJ' as Tipo,
                u.nm_segurado AS Nome_Completo,
                u.cd_mat_alternativa as Carteira,
                u.dt_cadastro as Data_Adesao,
                ac.ds_agrupamento_carencia as Modelo_Carencia,
                (Select tou.ds_tipo_observacao_usuario
                   From dbaps.tipo_observacao_usuario tou
                  Where tou.cd_tipo_observacao_usuario =
                        uo.cd_tipo_observacao_usuario) as TP_observacao,
                        uo.cd_tipo_observacao_usuario,
                uo.ds_usuario_observacao as Observacao
  From dbaps.usuario        u,
       usuario_observacao   uo,
       dbaps.agrupamento_carencia ac,
       dbaps.contrato       c
 Where to_date(u.dt_cadastro, 'DD/MM/YYYY') between '01/01/2021' AND
       '29/10/2021'
   and u.cd_matricula = uo.cd_matricula 
   and u.cd_agrupamento_carencia = ac.cd_agrupamento_carencia
    and u.cd_matricula = uo.cd_matricula
   and u.cd_contrato = c.cd_contrato
   and uo.cd_tipo_observacao_usuario in (9, 9001, 20)
   and c.sn_demitido_aposentado_obito = 'N'
   And c.tp_contrato in ('A', 'E')  
  -- and u.cd_matricula = 1874920009

 Order by 2  
