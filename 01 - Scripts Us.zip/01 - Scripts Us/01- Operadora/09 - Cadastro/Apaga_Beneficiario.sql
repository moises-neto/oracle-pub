select s.*, rowid from dbaps.solicitacao_web s
where s.cd_solicitacao = 77660;


Select us.cd_matricula_tem, us.*, rowid
  From Dbaps.Usuario Us
 Where Us.Cd_Matricula In (1821110240);


Select us.cd_matricula_tem, us.*, rowid
  From Dbaps.Usuario Us
 Where Us.Cd_Matricula In (1821110240 )
 and us.cd_matricula_tem is not null;
 
 select AW.*, ROWID from ARQUIVO_SOLICITACAO_WEB aw
 where aw.cd_matricula = 1821110240 ;

select a.*, rowid
  from dbaps.usuario_anexo a
 where a.Cd_Matricula In (1821110240 );

select fr.*, rowid
  from dbaps.LOG_CARENCIA_USUARIO fr
 where fr.cd_matricula In (1821110240 );

SELECT FR.*, ROWID
  FROM DBAPS.CARTEIRA FR
 where fr.cd_matricula In (1821110240 );

select g.*, rowid
  from USUARIO_ADESAO g
 where g.cd_matricula in (1821110240 );

select cu.*, rowid
  from dbaps.carencia_usuario cu
 where cu.cd_matricula in (1821110240 );

select uo.*, rowid
  from dbaps.USUARIO_OBSERVACAO uo
 where uo.cd_matricula in (1821110240 );

select hi.*, rowid
  from dbaps.HIS_EMPRESA hi
 where hi.cd_matricula in (1821110240);

select aa.*, rowid
  from SUSPENSAO_USUARIO aa
 where aa.cd_matricula in (1821110240);
