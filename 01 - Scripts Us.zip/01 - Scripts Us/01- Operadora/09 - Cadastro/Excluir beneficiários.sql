/*TAB=FAMILIA*/
Select u.Cd_Familia, u.Cd_Familia_Contrato, u.Cd_Mat_Alternativa
  From Dbaps.Usuario u
 Where Substr(u.Cd_Mat_Alternativa, 1, 7) = '0185761'
   --And Trunc(u.Dt_Cadastro) >= '01/11/2021'
 Order By 1;


Select u.Cd_Matricula
  From Dbaps.Usuario u, Dbaps.Usuario_Observacao Uo
 Where Uo.Cd_Matricula = u.Cd_Matricula
   And Substr(u.Cd_Mat_Alternativa, 1, 7) = '0185761'
   And Trunc(u.Dt_Cadastro) >= '01/11/2021'
   And Uo.Cd_Tipo_Observacao_Usuario = '9000'
 Order By 1;

/*TAB=DELETAR*/

-- 1- Dependentes
Select u.Cd_Matricula, u.Nm_Segurado
  From Dbaps.Usuario u, Dbaps.Usuario_Observacao Uo
 Where Uo.Cd_Matricula = u.Cd_Matricula
   And Substr(u.Cd_Mat_Alternativa, 1, 7) = '0185761'
   And Trunc(u.Dt_Cadastro) >= '01/11/2021'
   And Uo.Cd_Tipo_Observacao_Usuario = '9000'
   And u.cd_matricula_tem Is Not Null
 Order By 1;
 
-- 2- Titular
Select u.Cd_Matricula, u.Nm_Segurado
  From Dbaps.Usuario u, Dbaps.Usuario_Observacao Uo
 Where Uo.Cd_Matricula = u.Cd_Matricula
   And Substr(u.Cd_Mat_Alternativa, 1, 7) = '0185761'
   And Trunc(u.Dt_Cadastro) >= '01/11/2021'
   And Uo.Cd_Tipo_Observacao_Usuario = '9000'
   And u.cd_matricula_tem Is Null
 Order By 1;
 

-- DEPENDENTES

BEGIN
DBAMV.PKG_MV2000.ATRIBUI_EMPRESA('1');
END;
/

Declare
Begin

  For Ix In (Select u.Cd_Matricula, u.Nm_Segurado
  From Dbaps.Usuario u, Dbaps.Usuario_Observacao Uo
 Where Uo.Cd_Matricula = u.Cd_Matricula
   And Substr(u.Cd_Mat_Alternativa, 1, 7) = '0185761'
   And Trunc(u.Dt_Cadastro) >= '01/11/2021'
   And Uo.Cd_Tipo_Observacao_Usuario = '9000'
   And u.cd_matricula_tem Is Not Null) Loop
  
    Begin
    
      Dbaps.Prc_Delete_Beneficiario(Ix.Cd_Matricula, 'S');
    
    Exception
      When Others Then
        Rollback;
        Raise_Application_Error(-20002,
                                'Falha: ' || Sqlerrm || ' Cd_Matricula: ' ||
                                Ix.Cd_Matricula);
    End;
  End Loop;

Exception
  When Others Then
    Rollback;
    Raise_Application_Error(-20001, 'Falha: ' || Sqlerrm);
End;
/

-- TITULAR

Declare
Begin

  For Ix In (Select u.Cd_Matricula, u.Nm_Segurado
  From Dbaps.Usuario u, Dbaps.Usuario_Observacao Uo
 Where Uo.Cd_Matricula = u.Cd_Matricula
   And Substr(u.Cd_Mat_Alternativa, 1, 7) = '0185761'
   And Trunc(u.Dt_Cadastro) >= '01/11/2021'
   And Uo.Cd_Tipo_Observacao_Usuario = '9000'
   And u.cd_matricula_tem Is Null) Loop
  
    Begin
    
      Dbaps.Prc_Delete_Beneficiario(Ix.Cd_Matricula, 'S');
    
    Exception
      When Others Then
        Rollback;
        Raise_Application_Error(-20002,
                                'Falha: ' || Sqlerrm || ' Cd_Matricula: ' ||
                                Ix.Cd_Matricula);
    End;
  End Loop;

Exception
  When Others Then
    Rollback;
    Raise_Application_Error(-20001, 'Falha: ' || Sqlerrm);
End;
/

/*TAB=DELETAR*/
  Select u.Cd_Matricula, u.Nm_Segurado
    From Dbaps.Usuario u, Dbaps.Usuario_Observacao Uo
   Where Uo.Cd_Matricula = u.Cd_Matricula
     And Substr(u.Cd_Mat_Alternativa, 1, 7) = '0185761'
     And Trunc(u.Dt_Cadastro) >= '01/11/2021'
     And Uo.Cd_Tipo_Observacao_Usuario = '9000'
   Order By 1;


