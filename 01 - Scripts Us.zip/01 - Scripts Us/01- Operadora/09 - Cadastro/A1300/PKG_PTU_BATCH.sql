CREATE OR REPLACE NONEDITIONABLE PACKAGE DBAPS.PKG_PTU_BATCH IS
	/**************************************************************
    <objeto>
     <nome>PKG_PTU_BATCH</nome>
     <usuario>Bruno Felix</usuario>
     <alteracao>20/04/2020 15:37</alteracao>
     <descricao>Package respons�vel por m�todos �teis ao PTU Batch</descricao>
     <parametro></parametro>
     <versao>1.2</versao>
     <tags>PTU</tags>
     <soul>PLANO-1-145</soul>
    </objeto>
  ***************************************************************/
	FUNCTION FNC_AJUSTA_DADO_PTU(PTP_DADO VARCHAR2, PVALOR NUMBER) RETURN NUMBER;
	FUNCTION FNC_AJUSTA_DADO_PTU(PTP_DADO VARCHAR2, PVALOR VARCHAR2) RETURN VARCHAR2;
	FUNCTION FNC_AJUSTA_DADO_PTU(PTP_DADO VARCHAR2, PVALOR DATE) RETURN VARCHAR2;

  FUNCTION FNC_BENEF_ENVIADO_A1300(P_CD_MAT_ALTERNATIVA VARCHAR2, P_CD_MULTI_EMPRESA NUMBER, P_DATA_LIMITE DATE) RETURN VARCHAR2;

  /** A1300 **/
  TYPE ROW_QUERY_PTU_A1300 IS RECORD(
		CD_MATRICULA_TEM VARCHAR2(100),
    CD_MATRICULA VARCHAR2(100),
    CD_MAT_ALTERNATIVA Varchar2(20),
    NM_SEGURADO VARCHAR2(300),
    DT_NASCIMENTO DATE,
    TP_SEXO VARCHAR2(10),
    NR_CPF VARCHAR2(20),
    TP_REGISTRO VARCHAR2(1));
	TYPE TABLE_QUERY_PTU_A1300 IS TABLE OF ROW_QUERY_PTU_A1300;
	FUNCTION GET_TABLE_QUERY_PTU_A1300(P_TP_MOVIMENTACAO IN VARCHAR2, P_DT_INICIAL IN DATE DEFAULT To_Date('01/01/1900','dd/mm/yyyy'), P_DT_FINAL IN DATE, P_SN_APENAS_ATIVOS IN VARCHAR2, P_CD_MULTI_EMPRESA IN NUMBER) RETURN TABLE_QUERY_PTU_A1300 PIPELINED;
  /** A1300 **/

END PKG_PTU_BATCH;
/
CREATE OR REPLACE NONEDITIONABLE PACKAGE BODY DBAPS.pkg_ptu_batch IS
  /** INICIO VARIAVEIS **/
  vAux                 VARCHAR2(4000);
  vLetrasAcentuadas    VARCHAR2(26) := '��������������������������';
  vLetrasSemAcento     VARCHAR2(26) := 'aaaaAAAAeeEEiIoooOOOuuUUCc';
  vDataAux             DATE;
  vReturnExistRegistro VARCHAR2(1);
  /** FIM VARIAVEIS **/
  /** INICIO FUNCTIONS **/
  FUNCTION FNC_AJUSTA_DADO_PTU(PTP_DADO VARCHAR2, PVALOR NUMBER) RETURN NUMBER IS
  BEGIN
    IF PVALOR IS NULL THEN
      RETURN NULL;
    END IF;
    IF UPPER(PTP_DADO) = 'N' THEN -- NUM�RICO DE 0 � 9
      vAux := REGEXP_REPLACE(PVALOR, '[^0-9,.]+');
    ELSIF UPPER(PTP_DADO) = 'NS' THEN -- NUM�RICO DE 0 � 9 COM SINAL A FRENTE DOS D�GITOS ( - OU +)
      vAux := REGEXP_REPLACE(PVALOR, '[^[:digit:][.+,-]+');
    END IF;
    RETURN REPLACE(REPLACE(Trim(vAux), Chr(10), ''), Chr(13), '');
  END;
  FUNCTION FNC_AJUSTA_DADO_PTU(PTP_DADO VARCHAR2, PVALOR VARCHAR2) RETURN VARCHAR2 IS
  BEGIN
    IF PVALOR IS NULL THEN
      RETURN NULL;
    END IF;
    IF UPPER(PTP_DADO) = 'N' THEN -- NUM�RICO DE 0 � 9
      vAux := REGEXP_REPLACE(PVALOR, '[^0-9,.]+');
    ELSIF UPPER(PTP_DADO) = 'NS' THEN -- NUM�RICO DE 0 � 9 COM SINAL A FRENTE DOS D�GITOS ( - OU +)
      vAux := REGEXP_REPLACE(PVALOR, '[^[:digit:][.+,-]+');
    ELSIF UPPER(PTP_DADO) = 'A' THEN -- ALFAB�TICO DE A � Z, MAI�SCULAS E MIN�SCULAS E BRANCOS
      vAux := REGEXP_REPLACE(PVALOR, '[^A-Za-z[:space:]]+');
      vAux := TRANSLATE(vAux, vLetrasAcentuadas, vLetrasSemAcento);
    ELSIF UPPER(PTP_DADO) = 'AN' THEN -- ALFAB�TICO DE A � Z MAI�SCULAS E MIN�SCULAS E NUM�RICO DE 0 � 9 E BRANCOS
      vAux := REGEXP_REPLACE(PVALOR, '[^-.+[:alnum:][:space:]]+');
      vAux := TRANSLATE(vAux, '��������������������������', 'aaaaAAAAeeEEiIoooOOOuuUUCc');
    ELSIF UPPER(PTP_DADO) IN ('ANS', 'ANS+') THEN -- ALFAB�TICO DE A � Z MAI�SCULAS E MIN�SCULAS, NUM�RICO E CARACTERES ESPECIAIS E BRANCOS
      vAux := REGEXP_REPLACE(PVALOR, '[^]\[!@#$%*()-\+\=\/{}_;\.\,:\?''A-Za-z0-9[:space:]]+');
      vAux := TRANSLATE(vAux, '��������������������������<>', 'aaaaAAAAeeEEiIoooOOOuuUUCc');
      vAux := replace(vAux, Chr(13), '');
      vAux := replace(vAux, Chr(10), '');
    ELSIF UPPER(PTP_DADO) = 'MM' THEN -- M�S DE 1 � 12
      vDataAux := TO_DATE(PVALOR, 'DD/MM/YYYY');
      vAux := TO_CHAR(vDataAux, 'MM');
      IF TO_NUMBER(vAux) < 1 OR TO_NUMBER(vAux) > 12 THEN
        RAISE_APPLICATION_ERROR(-20999, 'Para tipo de dado [MM], informar m�s entre 1 e 12.');
      END IF;
    ELSIF UPPER(PTP_DADO) = 'UF' THEN -- UNIDADE FEDERATIVA - FORMATO XX, ONDE XX PERTENCE AO DOM�NIO
      IF PVALOR NOT IN ('RS', 'SC', 'PR', 'SP', 'MG', 'RJ', 'ES', 'MS', 'MT', 'GO', 'TO', 'PA', 'AM', 'RO', 'RR', 'AC', 'DF', 'BA', 'SE', 'CE', 'PI', 'PB', 'RN', 'AL', 'MA', 'PE', 'AP') THEN
        RAISE_APPLICATION_ERROR(-20999, 'Para tipo de dado [UF], uma Unidade Federativa v�lida.');
      END IF;
      RETURN UPPER(PVALOR);
    END IF;
    RETURN REPLACE(REPLACE(Trim(vAux), Chr(10), ''), Chr(13), '');
  END;
  FUNCTION FNC_AJUSTA_DADO_PTU(PTP_DADO VARCHAR2, PVALOR DATE) RETURN VARCHAR2 IS
  BEGIN
    IF PVALOR IS NULL THEN
      RETURN NULL;
    END IF;
    IF UPPER(PTP_DADO) = 'DD' THEN -- DIA DE 1 � 31
      vAux := TO_CHAR(PVALOR, 'DD');
      IF NOT TO_NUMBER(vAux) BETWEEN 1 AND 31 THEN
        RAISE_APPLICATION_ERROR(-20999, 'Para tipo de dado [DD], informar dia entre 1 e 31.' || vAux);
      END IF;
    ELSIF UPPER(PTP_DADO) = 'YYYY' THEN -- ANO DE 1900 � 2999
      vAux := TO_CHAR(PVALOR, 'YYYY');
      IF NOT TO_NUMBER(vAux) BETWEEN 1900 AND 2999 THEN
        RAISE_APPLICATION_ERROR(-20999, 'Para tipo de dado [YYYY], informar ano entre 1900 e 2999.');
      END IF;
    ELSIF UPPER(PTP_DADO) = 'HH' THEN -- HORA LOCAL DE 00 � 23
      vAux := TO_CHAR(PVALOR, 'HH24');
      IF NOT TO_NUMBER(vAux) BETWEEN 0 AND 24 THEN
        RAISE_APPLICATION_ERROR(-20999, 'Para tipo de dado [HH], informar ano entre 00 e 23.');
      END IF;
    ELSIF UPPER(PTP_DADO) = 'MI' THEN -- MINUTOS LOCAL DE 00 � 59
      vAux := TO_CHAR(PVALOR, 'MI');
      IF TO_NUMBER(vAux) < 0 OR TO_NUMBER(vAux) > 59 THEN
        RAISE_APPLICATION_ERROR(-20999, 'Para tipo de dado [MI], informar ano entre 00 e 59.');
      END IF;
    ELSIF UPPER(PTP_DADO) = 'SS' THEN -- SEGUNDOS LOCAL DE 00 � 59
      vAux := TO_CHAR(PVALOR, 'SS');
      IF TO_NUMBER(vAux) < 0 OR TO_NUMBER(vAux) > 59 THEN
        RAISE_APPLICATION_ERROR(-20999, 'Para tipo de dado [SS], informar ano entre 00 e 59.');
      END IF;
    ELSIF UPPER(PTP_DADO) = '-GG' THEN -- DESLOCAMENTO (+ OU -) EM RELA��O AO MERIDIANO DE GREENWICH
      RETURN '-03';
    ELSIF UPPER(PTP_DADO) = 'DATA1' THEN -- FORMATO YYYY/MM/DDHH:MI:SS~GG
      RETURN TO_CHAR(PVALOR, 'YYYY/MM/DDHH:MI:SS') || '-03';
    ELSIF UPPER(PTP_DADO) = 'DATA2' THEN -- FORMATO YYYYMMDD
      RETURN TO_CHAR(PVALOR, 'YYYY/MM/DD');
    ELSIF UPPER(PTP_DADO) = 'HORA' THEN -- FORMATO HH:MI:SS
      RETURN TO_CHAR(PVALOR, 'HH:MI:SS');
    END IF;
    RETURN REPLACE(REPLACE(Trim(vAux), Chr(10), ''), Chr(13), '');
  END;
  FUNCTION FNC_BENEF_ENVIADO_A1300(P_CD_MAT_ALTERNATIVA VARCHAR2, P_CD_MULTI_EMPRESA NUMBER, P_DATA_LIMITE DATE) RETURN VARCHAR2 IS
    CURSOR cBenefA1300R306 IS
      SELECT 'S'
        FROM DBAPS.PTU_REMESSA_RETORNO PRR,
              DBAPS.PTU_A1300_R306 R306
        WHERE PRR.CD_PTU_REMESSA_RETORNO = R306.CD_PTU_REMESSA_RETORNO
          AND PRR.TP_ARQUIVO = 'A1300'
          AND PRR.TP_PROCESSO = 'REM'
          AND PRR.TP_STATUS = 'E'
          AND R306.ID_BENEF = SUBSTR(REGEXP_REPLACE(P_CD_MAT_ALTERNATIVA, '[^[:digit:]]+'), 4, 16)
          AND PRR.CD_MULTI_EMPRESA = P_CD_MULTI_EMPRESA
          AND PRR.DT_MOV_FIM <= P_DATA_LIMITE;
  BEGIN
    vReturnExistRegistro := NULL;
    OPEN cBenefA1300R306;
    FETCH cBenefA1300R306 INTO vReturnExistRegistro;
    CLOSE cBenefA1300R306;
    RETURN Nvl(vReturnExistRegistro, 'N');
  END;
  --A1300
  FUNCTION GET_TABLE_QUERY_PTU_A1300(P_TP_MOVIMENTACAO IN VARCHAR2, P_DT_INICIAL IN DATE DEFAULT To_Date('01/01/1900','dd/mm/yyyy'), P_DT_FINAL IN DATE, P_SN_APENAS_ATIVOS IN VARCHAR2, P_CD_MULTI_EMPRESA IN NUMBER)
    RETURN TABLE_QUERY_PTU_A1300
    PIPELINED IS
    CURSOR cQueryA1300 IS
      SELECT DISTINCT CD_MATRICULA_TEM,
             CD_MATRICULA,
             NM_SEGURADO,
             DT_NASCIMENTO,
             CD_MAT_ALTERNATIVA,
             TP_SEXO,
             NR_CPF,
             TP_REGISTRO
         FROM (SELECT 'I' TP_REGISTRO,
                      U.CD_MATRICULA_TEM,
                      U.CD_MATRICULA,
                      U.NM_SEGURADO,
                      U.DT_NASCIMENTO,
                      U.CD_MAT_ALTERNATIVA,
                      U.TP_SEXO,
                      U.NR_CPF
                 FROM DBAPS.USUARIO U
                WHERE U.SN_ENVIO_A1300 = 'S'
                  AND U.CD_MULTI_EMPRESA = P_CD_MULTI_EMPRESA
                  AND ((P_DT_INICIAL IS NOT NULL AND U.DT_CADASTRO BETWEEN P_DT_INICIAL AND P_DT_FINAL) OR (P_DT_INICIAL IS NULL))
                  AND ((P_DT_FINAL IS NOT NULL AND U.DT_CADASTRO <= P_DT_FINAL) OR (P_DT_FINAL IS NULL))
                  AND ((P_SN_APENAS_ATIVOS = 'S' AND U.SN_ATIVO = 'S') OR (P_SN_APENAS_ATIVOS = 'T'))
               UNION
               SELECT Decode(FNC_BENEF_ENVIADO_A1300(U.CD_MAT_ALTERNATIVA, U.CD_MULTI_EMPRESA, P_DT_INICIAL), 'N', 'I', 'A') TP_REGISTRO,
                      U.CD_MATRICULA_TEM,
                      U.CD_MATRICULA,
                      U.NM_SEGURADO,
                      U.DT_NASCIMENTO,
                      U.CD_MAT_ALTERNATIVA,
                      U.TP_SEXO,
                      U.NR_CPF
                 FROM DBAPS.USUARIO U
                WHERE U.CD_MATRICULA IN (SELECT CD_MATRICULA
                                           FROM (SELECT CD_MATRICULA
                                                   FROM DBAPS.HIS_CONTRATO HC
                                                  WHERE ((P_DT_INICIAL IS NOT NULL AND HC.DT_INCLUSAO BETWEEN P_DT_INICIAL AND P_DT_FINAL) OR (P_DT_INICIAL IS NULL))
                                                    AND ((P_DT_FINAL IS NOT NULL AND HC.DT_INCLUSAO <= P_DT_FINAL) OR (P_DT_FINAL IS NULL))
                                                 UNION
                                                 SELECT CD_MATRICULA
                                                   FROM DBAPS.HIS_PLANO HP
                                                  WHERE ((P_DT_INICIAL IS NOT NULL AND HP.DT_ALTERACAO BETWEEN P_DT_INICIAL AND P_DT_FINAL) OR (P_DT_INICIAL IS NULL))
                                                    AND ((P_DT_FINAL IS NOT NULL AND HP.DT_ALTERACAO <= P_DT_FINAL) OR (P_DT_FINAL IS NULL))
                                                 UNION
                                                 SELECT CD_MATRICULA
                                                   FROM DBAPS.LOG_ATUALIZA_CAD_USU LACU
                                                  WHERE ((P_DT_INICIAL IS NOT NULL AND LACU.DT_ATUALIZA_CADASTRO BETWEEN P_DT_INICIAL AND P_DT_FINAL) OR (P_DT_INICIAL IS NULL))
                                                    AND ((P_DT_FINAL IS NOT NULL AND LACU.DT_ATUALIZA_CADASTRO <= P_DT_FINAL) OR (P_DT_FINAL IS NULL))
                                                )
                                        )
                  AND U.SN_ENVIO_A1300 = 'S'
                  AND U.CD_MULTI_EMPRESA = P_CD_MULTI_EMPRESA
                  AND ((P_SN_APENAS_ATIVOS = 'S' AND U.SN_ATIVO = 'S') OR (P_SN_APENAS_ATIVOS = 'T'))
                  AND P_TP_MOVIMENTACAO = 'P'
               UNION
               SELECT 'D' TP_REGISTRO,
                      U.CD_MATRICULA_TEM,
                      U.CD_MATRICULA,
                      U.NM_SEGURADO,
                      U.DT_NASCIMENTO,
                      U.CD_MAT_ALTERNATIVA,
                      U.TP_SEXO,
                      U.NR_CPF
                 FROM DBAPS.USUARIO U,
                      DBAPS.DESLIGAMENTO D
                WHERE SN_ENVIO_A1300 = 'S'
                  AND CD_MULTI_EMPRESA = P_CD_MULTI_EMPRESA
                  AND U.CD_MATRICULA = D.CD_MATRICULA
                  AND D.DT_REATIVACAO IS NULL
                  AND D.DT_DESLIGAMENTO IN (SELECT Max(DT_DESLIGAMENTO) FROM DBAPS.DESLIGAMENTO WHERE CD_MATRICULA = U.CD_MATRICULA)
                  AND ((P_DT_INICIAL IS NOT NULL AND D.DT_DESLIGAMENTO BETWEEN P_DT_INICIAL AND P_DT_FINAL) OR (P_DT_INICIAL IS NULL))
                  AND ((P_DT_FINAL IS NOT NULL AND D.DT_DESLIGAMENTO <= P_DT_FINAL) OR (P_DT_FINAL IS NULL))
                  AND ((P_SN_APENAS_ATIVOS = 'N' AND U.SN_ATIVO = 'N') OR (P_SN_APENAS_ATIVOS = 'T'))
                  AND U.CD_MATRICULA NOT IN (
                      SELECT CD_MATRICULA
                      FROM DBAPS.USUARIO U
                      WHERE U.SN_ENVIO_A1300 = 'S'
                        AND U.CD_MULTI_EMPRESA = P_CD_MULTI_EMPRESA
                        AND ((P_DT_INICIAL IS NOT NULL AND U.DT_CADASTRO BETWEEN P_DT_INICIAL AND P_DT_FINAL) OR (P_DT_INICIAL IS NULL))
                        AND ((P_DT_FINAL IS NOT NULL AND U.DT_CADASTRO <= P_DT_FINAL) OR (P_DT_FINAL IS NULL))
                        AND ((P_SN_APENAS_ATIVOS = 'S' AND U.SN_ATIVO = 'S') OR (P_SN_APENAS_ATIVOS = 'T'))
                  )
               UNION
               SELECT 'R' TP_REGISTRO,
                      U.CD_MATRICULA_TEM,
                      U.CD_MATRICULA,
                      U.NM_SEGURADO,
                      U.DT_NASCIMENTO,
                      U.CD_MAT_ALTERNATIVA,
                      U.TP_SEXO,
                      U.NR_CPF
                 FROM DBAPS.USUARIO U,
                      DBAPS.DESLIGAMENTO D
                WHERE SN_ENVIO_A1300 = 'S'
                  AND CD_MULTI_EMPRESA = P_CD_MULTI_EMPRESA
                  AND U.CD_MATRICULA = D.CD_MATRICULA
                  AND D.DT_REATIVACAO IS NOT NULL
                  AND D.DT_REATIVACAO IN (SELECT Max(DT_REATIVACAO) FROM DBAPS.DESLIGAMENTO WHERE CD_MATRICULA = U.CD_MATRICULA)
                  AND ((P_DT_INICIAL IS NOT NULL AND D.DT_REATIVACAO BETWEEN P_DT_INICIAL AND P_DT_FINAL) OR (P_DT_INICIAL IS NULL))
                  AND ((P_DT_FINAL IS NOT NULL AND D.DT_REATIVACAO <= P_DT_FINAL) OR (P_DT_FINAL IS NULL))
                  AND ((P_SN_APENAS_ATIVOS = 'S' AND U.SN_ATIVO = 'S') OR (P_SN_APENAS_ATIVOS = 'T'))
                  AND P_TP_MOVIMENTACAO = 'P'
              )
         ORDER BY TP_REGISTRO DESC, NM_SEGURADO ASC;
    rQueryA1300 ROW_QUERY_PTU_A1300;
    vTpRegistro   VARCHAR2(2);
  BEGIN
    --
    FOR r IN cQueryA1300 LOOP

      vTpRegistro := r.TP_REGISTRO;
      /* REGRA 1 - UNIMED BRASIL
         REGISTRO TIPO 'R' DEVEM SER ENVIADOS COMO 'A' ATERA��O
      */
      IF r.TP_REGISTRO = 'R' THEN
         vTpRegistro := 'A';
      END IF;
      --
      /* REGRA 2 - UNIMED BRASIL
         NA MESMA COMPETENCIA N�O PODE SER ENVIADO 2 REGISTROS PARA O MESMO BENEFICIARIO
         EX: 'I' E 'D' (inclusao e desligamento)

         ser� tratado no bot�o processar para gerar 2 arquivos
       */

        rQueryA1300.CD_MATRICULA_TEM := r.CD_MATRICULA_TEM;
        rQueryA1300.CD_MATRICULA     := r.CD_MATRICULA;
        rQueryA1300.NM_SEGURADO      := r.NM_SEGURADO;
        rQueryA1300.DT_NASCIMENTO    := r.DT_NASCIMENTO;
        rQueryA1300.CD_MAT_ALTERNATIVA    := r.CD_MAT_ALTERNATIVA;
        rQueryA1300.TP_SEXO          := r.TP_SEXO;
        rQueryA1300.NR_CPF           := r.NR_CPF;
        rQueryA1300.TP_REGISTRO      := vTpRegistro;
        PIPE ROW(rQueryA1300);
      --
    END LOOP;
    RETURN;
  END;
  --A1300
  /** FIM FUNCTION **/
END;
/
