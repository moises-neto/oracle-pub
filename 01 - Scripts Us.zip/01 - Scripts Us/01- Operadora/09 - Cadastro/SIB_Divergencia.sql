

select l.cd_cco||l.nr_div_cco, l.cd_mat_alternativa,l.cd_matricula_ans,l.* from usuario l
where l.cd_matricula = 1118570151
union all
select l.cd_cco||l.nr_div_cco, l.cd_mat_alternativa,l.cd_matricula_ans,l.* from usuario l
where l.cd_matricula = 1118570071       --TITULAR
;

 

/*dados que est�o na ANS*/
select * from custom.sib_retorno_conferencia_unimed l
where l.nome = 'CAROLINA THAME ALVES DO AMARAL'


