Create Or Replace Noneditionable Package Custom.Pkg_Lancamento_Horas

/*
  Desenvolvedor: Mois�s de Souza e Josiel
  Data de Aplica��o: 25/07/2023
  M�dulos utilizados: Lan�amento de Horas
  Objetivo: Organiza��o dos scripts de lan�amento de horas
  */

 Is

  Procedure Prc_Integra_Escala_Medica(p_Lancamento_Hora_Mv In Number,
                                      p_Dt_Inicio          Date,
                                      p_Dt_Fim             Date,
                                      p_Sn_Cooperado_Pj    In Char Default 'N');

  Procedure Prc_Delete_Dados_Integracao(p_Lancamento_Hora_Mv In Number,
                                        p_Dt_Inicio          Date,
                                        p_Dt_Fim             Date);
End Pkg_Lancamento_Horas;
/
Create Or Replace Noneditionable Package Body Custom.Pkg_Lancamento_Horas

 Is

  Procedure Prc_Integra_Escala_Medica(p_Lancamento_Hora_Mv In Number,
                                      p_Dt_Inicio          Date,
                                      p_Dt_Fim             Date,
                                      p_Sn_Cooperado_Pj    In Char Default 'N') Is
  
    Cursor c_Dados_Escala Is
      Select *
        From Custom.Escala_Dados_Hora e
       Where Trunc(e.Dt_Escala_Inicio_Atual) Between p_Dt_Inicio And
             p_Dt_Fim
            --N�o duplicar itens.
         And Not Exists
       (Select 1
                From Custom.Itlancamento_Hora_Escala c_h
               Where e.Cd_Prestador = c_h.Cd_Prestador
                 And p_Lancamento_Hora_Mv = c_h.Cd_Lancamento_Hora
                 And e.Tipo_Hora = c_h.Cd_Tipo_Hora
                 And e.Dt_Escala_Inicio_Atual = c_h.Dt_Inicio
                 And e.Dt_Escala_Termino_Atual = c_h.Dt_Fim
                 And e.Cd_Centro_Custo = c_h.Cd_Setor)
            
         And (p_Sn_Cooperado_Pj = 'S' And e.Cd_Prestador_Pj Is Not Null Or
              (p_Sn_Cooperado_Pj = 'N' And e.Cd_Prestador_Pj Is Null));
  
    Cursor Cvalidalancamentohora Is
      Select 1
        From Dbaps.Lancamento_Hora a
       Where a.Cd_Lancamento_Hora = p_Lancamento_Hora_Mv;
  
    v_Valor            Number;
    v_Tipo_Hora        Number;
    v_Existe_Escala    Number;
    v_Existe           Number;
    v_Existe_Prestador Number;
    v_Cd_Reduzido_Ctb Constant Number := 5110;
    v_Existe_Lancamento_Hora Pls_Integer := 0;
  
  Begin
    Open Cvalidalancamentohora;
    Fetch Cvalidalancamentohora
      Into v_Existe_Lancamento_Hora;
    Close Cvalidalancamentohora;
    --VALIDA��ES.
    If (p_Lancamento_Hora_Mv Is Null) Then
      Raise_Application_Error(-20001,
                              'Favor Informar o Lanca�mento Hora !');
    
    End If;
    If (v_Existe_Lancamento_Hora <> 1) Then
      Raise_Application_Error(-20002,
                              ' ATEN��O: Lan�amento Hora n�o cadastrado na tela M_LANCAMENTO_HORA!');
    End If;
  
    If (p_Dt_Fim Is Null Or p_Dt_Inicio Is Null) Then
      Raise_Application_Error(-20003,
                              ' ATEN��O: Periodo Inicial ou Final n�o est� preenchido!');
    
    End If;
  
    --FIM VALIDA��ES
  
    Custom.Pr_Envia_Email_V2('josiel.cardoso@unimedsorocaba.coop.br',
                             'josiel.cardoso@unimedsorocaba.coop.br',
                             'Procedure IMPORTA��O DE HORAS/ESCALA MEDICA INICIADA',
                             'AS HORAS SERAO INCLUSAS NA FATURA HMS : ' ||
                             p_Lancamento_Hora_Mv || ' PERIODO DE : ' ||
                             p_Dt_Inicio || ' AT�: ' || p_Dt_Fim);
  
    Custom.Pr_Envia_Email_V2('moises.neto@unimedsorocaba.coop.br',
                             'moises.neto@unimedsorocaba.coop.br',
                             'Procedure IMPORTA��O DE HORAS/ESCALA MEDICA INICIADA',
                             'AS HORAS SERAO INCLUSAS NA FATURA HMS : ' ||
                             p_Lancamento_Hora_Mv || ' PERIODO DE : ' ||
                             p_Dt_Inicio || ' AT�: ' || p_Dt_Fim);
  
    Custom.Pr_Envia_Email_V2('caroline.ramos@unimedsorocaba.coop.br',
                             'caroline.ramos@unimedsorocaba.coop.br',
                             'Procedure IMPORTA��O DE HORAS/ESCALA MEDICA INICIADA',
                             'AS HORAS SERAO INCLUSAS NA FATURA HMS : ' ||
                             p_Lancamento_Hora_Mv || ' PERIODO DE : ' ||
                             p_Dt_Inicio || ' AT�: ' || p_Dt_Fim);
  
    -- 1: PASSO  - EXCLUIR DA TABELA CUSTOM.ITLANCAMENTO_HORA_ESCALA O PER�ODO JA INCLUIDO PARA OS COOPERADOS.
  
    -- 2: PASSO  - ANTES DE INSERIR LOCALIZAR A FATURA CORRETA.
  
    -- 3: PASSO - INSERIR NA TABELA CUSTOM.ITLANCAMENTO_HORA_ESCALA
  
    -- 4: PASSO - INSERT NA DBAPS.ITLANCAMENTO_HORA
 
  
    Prc_Delete_Dados_Integracao(p_Lancamento_Hora_Mv => p_Lancamento_Hora_Mv,
                                p_Dt_Inicio          => p_Dt_Inicio,
                                p_Dt_Fim             => p_Dt_Fim);
  
    ---PRECISA VERIFICAR O QUE � ISSO.                             
    Delete Custom.Escala_Dados l Where l.Nm_Funcionario Like 'Em B%';
  
    Update Custom.Escala_Dados l
       Set l.Nr_Escala_Id_Interno = 999
     Where l.Nm_Escala = 'Centro Obst�trico (In Loco)'
       And l.Nm_Time = 'Plant�o a Dist�ncia';
  
    Update Custom.Escala_Dados l
       Set l.Nr_Escala_Id_Interno = 998
     Where Upper(l.Nm_Time) Like '%BRONCOSCOPIA%';
  
    For x In c_Dados_Escala Loop
      v_Valor := 0;
    
      v_Valor := x.Qt_Horas *
                 f_Valor_Hora(Trunc(x.Dt_Escala_Inicio_Atual), x.Tipo_Hora);
    
      v_Tipo_Hora := x.Tipo_Hora;
    
      Insert Into Itlancamento_Hora_Escala
        (Cd_Itlancamento_Hora,
         Cd_Lancamento_Hora,
         Cd_Prestador,
         Cd_Tipo_Hora,
         Dt_Inicio,
         Dt_Fim,
         Nr_Horas,
         Vl_Horas,
         Ds_Observacao,
         Dt_Inclusao,
         Cd_Usuario_Inclusao,
         Cd_Setor,
         Cd_Repasse_Prestador,
         Cd_Reduzido_Ctb,
         Id_Escala_Cabecalho,
         Tipo)
      Values
        (Custom.Seq_Itlancamento_Hora_Escala.Nextval,
         p_Lancamento_Hora_Mv,
         x.Cd_Prestador,
         v_Tipo_Hora,
         x.Dt_Escala_Inicio_Atual,
         x.Dt_Escala_Termino_Atual,
         x.Qt_Horas,
         v_Valor,
         x.Nm_Escala || '-' || x.Nm_Time,
         Sysdate,
         'DBAPS',
         x.Cd_Centro_Custo,
         Null,
         v_Cd_Reduzido_Ctb,
         Null,
         x.Tipo_Escala);
    
    -- COMMIT;
    
    End Loop;
  
    ---- INSERIR NA TABELA PRINCIPAL DBAPS.ITLANCAMENTO_HORA
    Insert Into Dbaps.Itlancamento_Hora
      (Cd_Itlancamento_Hora,
       Cd_Lancamento_Hora,
       Cd_Prestador,
       Cd_Tipo_Hora,
       Dt_Inicio,
       Dt_Fim,
       Nr_Horas,
       Vl_Horas,
       Ds_Observacao,
       Dt_Inclusao,
       Cd_Usuario_Inclusao,
       Cd_Setor,
       Cd_Repasse_Prestador,
       Cd_Reduzido_Ctb)
      Select Ct_Item.Cd_Itlancamento_Hora,
             Ct_Item.Cd_Lancamento_Hora,
             Ct_Item.Cd_Prestador,
             Ct_Item.Cd_Tipo_Hora,
             Ct_Item.Dt_Inicio,
             Ct_Item.Dt_Fim,
             Ct_Item.Nr_Horas,
             Ct_Item.Vl_Horas,
             Ct_Item.Ds_Observacao,
             Ct_Item.Dt_Inclusao,
             Ct_Item.Cd_Usuario_Inclusao,
             Ct_Item.Cd_Setor,
             Ct_Item.Cd_Repasse_Prestador,
             Ct_Item.Cd_Reduzido_Ctb
        From Custom.Itlancamento_Hora_Escala Ct_Item
       Where Cd_Lancamento_Hora = p_Lancamento_Hora_Mv
         And Not Exists
       (Select 1
                From Dbaps.Itlancamento_Hora Ilh
               Where Ilh.Cd_Prestador = Ct_Item.Cd_Prestador
                 And Ilh.Cd_Lancamento_Hora = Ct_Item.Cd_Lancamento_Hora
                 And Ilh.Cd_Tipo_Hora = Ct_Item.Cd_Tipo_Hora
                 And Ilh.Dt_Inicio = Ct_Item.Dt_Inicio
                 And Ilh.Dt_Fim = Ct_Item.Dt_Fim
                 And Ilh.Cd_Setor = Ct_Item.Cd_Setor);
  
  End Prc_Integra_Escala_Medica;

  Procedure Prc_Delete_Dados_Integracao(p_Lancamento_Hora_Mv In Number,
                                        p_Dt_Inicio          Date,
                                        p_Dt_Fim             Date) Is
  
  Begin
  
    --limpando tabela temp para reeimporta��o
    Delete Custom.Itlancamento_Hora_Escala Ce
     Where Ce.Cd_Lancamento_Hora = p_Lancamento_Hora_Mv
       And Trunc(Ce.Dt_Inicio) Between p_Dt_Inicio And p_Dt_Fim;
  
    --limpando a tabela principal
    Delete Dbaps.Itlancamento_Hora h
     Where h.Cd_Lancamento_Hora = p_Lancamento_Hora_Mv
       And Trunc(h.Dt_Inicio) Between p_Dt_Inicio And p_Dt_Fim;
    Commit;
  End Prc_Delete_Dados_Integracao;

End Pkg_Lancamento_Horas;
/
