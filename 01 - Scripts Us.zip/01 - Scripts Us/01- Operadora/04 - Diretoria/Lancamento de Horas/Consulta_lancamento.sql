Select * from fatura  f
where f.cd_fatura = 24695

select * from hor

select * from tipo_hora t
where t.cd_tipo_hora = 54  

Select *

 FROM DBAPS.ITLANCAMENTO_HORA I,
       DBAPS.PRESTADOR         P,
       DBAPS.TIPO_HORA         T,
       DBAMV.SETOR             S,
       DBAPS.LANCAMENTO_HORA   L /*,
       DBAPS.PERIODO_TIPO_HORA TP*/
       
 where P.CD_PRESTADOR = I.CD_PRESTADOR
   AND T.CD_TIPO_HORA = I.CD_TIPO_HORA
   AND S.CD_SETOR = I.CD_SETOR
   AND L.CD_LANCAMENTO_HORA = I.CD_LANCAMENTO_HORA
   and p.cd_prestador = 102554  
   and t.cd_tipo_hora = 54
   
   Select * from LANCAMENTO_HORA l
   where l.cd_fatura = 24695 
   
   Select * from ITLANCAMENTO_HORA i
   where i.cd_prestador = 102554 
   and i.cd_tipo_hora = 54
