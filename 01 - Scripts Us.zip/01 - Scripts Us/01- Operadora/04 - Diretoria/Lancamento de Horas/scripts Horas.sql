/*#########################################################################################################
                                SCRIPT IMPORTAÇÃO DE HORAS FIXA E VARIAVEL
#########################################################################################################*/


-- 1 -->>  LANÇAR OS REGISTROS NA TABELA TEMPORÁRIA

SELECT * 
     FROM CUSTOM.IMP_ITLANCAMENTO_HORA  I
     
--2 -->> DEPOIS FAZER O INSERT NA PRINCIPAL

 INSERT INTO DBAPS.ITLANCAMENTO_HORA
 SELECT * 
     FROM CUSTOM.IMP_ITLANCAMENTO_HORA;
	 
	
	
	
/*#########################################################################################################
                                SCRIPT IMPORTAÇÃO DE HORAS MODELO ENTRADA E SAÍDA 
#########################################################################################################*/

-- (01) Limpar a Tabela de Importação
TRUNCATE TABLE dbaps.imp_horas_trabalhas;


-- (02) Carregar a Tabela de Importacação
SELECT i.*, ROWID FROM dbaps.imp_horas_trabalhas i

-- (03) Executar Rotina de Importacao com CD_LANCAMENTO_HORA
DECLARE

  CURSOR cHorasImp IS
    SELECT DISTINCT H.CDLANCAMENTOHORA
      FROM DBAPS.IMP_HORAS_TRABALHAS H
     WHERE 1 = 1;

BEGIN

  FOR C IN cHorasImp LOOP
  
    dbaps.pr_imp_horas_trabalhadas(pcd_lancamentohora => C.CDLANCAMENTOHORA);
  
  END LOOP;
END;


-- (04) Conferencia Imporacao
SELECT * 
  FROM dbaps.itlancamento_hora i 
 WHERE i.cd_lancamento_hora = ? -- alterar cd_lancamento_hora
   AND i.cd_tipo_hora       = ? -- alterar cd_tipo_hora
   AND I.DS_OBSERVACAO      = '#IMPRELOGIO#'
     
     
	 
	
	


/*#########################################################################################################
                                MIGRAR LANCAMENTOS DE HORAS PARA SUAS RESPECTIVAS FATURAS
#########################################################################################################*/

-- FATURA DE COOP PJ
-- FATURA HMS
-- FATURA SEDE
	
	UPDATE  DBAPS.ITLANCAMENTO_HORA IH2
SET IH2.CD_LANCAMENTO_HORA = 170
WHERE ih2.cd_itlancamento_hora IN
     (
     
     
     SELECT ih.cd_itlancamento_hora--, IH.CD_PRESTADOR,CUSTOM.FNC_RETORNA_PREST_ASSOCIADO(IH.CD_PRESTADOR) COOP_PJ,IH.CD_LANCAMENTO_HORA
           FROM DBAPS.ITLANCAMENTO_HORA IH
           INNER JOIN DBAPS.LANCAMENTO_HORA LH ON LH.CD_LANCAMENTO_HORA = IH.CD_LANCAMENTO_HORA
           WHERE 1=1
           AND LH.CD_FATURA = '50314'
           AND TRUNC(IH.Dt_Inicio) BETWEEN '16/05/2023' AND '15/06/2023'
           AND  CUSTOM.FNC_RETORNA_PREST_ASSOCIADO(IH.CD_PRESTADOR) IS NOT NULL
                         
                    
                     )
                     