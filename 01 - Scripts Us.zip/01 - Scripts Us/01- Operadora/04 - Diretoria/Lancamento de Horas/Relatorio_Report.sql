SELECT P.CD_PRESTADOR,
       P.NM_PRESTADOR,
       (I.NR_HORAS),
       -- TP.VL_HORA
       --VALOR_HORA,    
       T.DS_TIPO_HORA,
       S.NM_SETOR     CENTRO_DE_CUSTO,
       I.VL_HORAS     Total_pago,
       --TP.VL_HORA,
       L.CD_FATURA FATURA,
       I.DT_INICIO HRINICIO,
       I.DT_FIM HRFIM,
       I.CD_TIPO_HORA,
       S.CD_SETOR,
       I.DS_OBSERVACAO obs,
       Substr(to_char(i.nr_horas, 'FM999999990D90'),
              1,
              Instr(to_char(i.nr_horas, 'FM999999990D90'), ',') - 1) || ':' ||
       TO_CHAR(TRUNC(MOD((round(TO_NUMBER('0,' ||
                                          Substr(to_char(i.nr_horas,
                                                         'FM999999990D90'),
                                                 Instr(to_char(i.nr_horas,
                                                               'FM999999990D90'),
                                                       ',') + 1,
                                                 Length(to_char(i.nr_horas,
                                                                'FM999999990D90')))) * 60) * 60),
                         3600) / 60),
               'FM00') QTD_HORAS
  FROM DBAPS.ITLANCAMENTO_HORA I,
       DBAPS.PRESTADOR         P,
       DBAPS.TIPO_HORA         T,
       DBAMV.SETOR             S,
       DBAPS.LANCAMENTO_HORA   L /*,
       DBAPS.PERIODO_TIPO_HORA TP*/
       
 where P.CD_PRESTADOR = I.CD_PRESTADOR
   AND T.CD_TIPO_HORA = I.CD_TIPO_HORA
   AND S.CD_SETOR = I.CD_SETOR
   AND L.CD_LANCAMENTO_HORA = I.CD_LANCAMENTO_HORA
   --AND TP.CD_TIPO_HORA = I.CD_TIPO_HORA
   
   AND (TRIM('{CDPRESTADOR}') IS NULL OR P.CD_PRESTADOR = '102554')
   AND (TRIM('{CDFATURA}') IS NULL OR L.CD_FATURA = '24695')
  -- AND (TRIM('{CD_SETOR}') IS NULL OR S.CD_SETOR = '{CD_SETOR}')
   AND (TRIM('{CD_TIPO_HORA}') IS NULL OR t.CD_TIPO_HORA = '54')

   
   And I.CD_TIPO_HORA not in (2, 18, 20, 38, 39, 40,23) -- Horas Fixas
   --and ((I.DT_INICIO between TP.Dt_Inicio and TP.Dt_Fim))
   
   
 ORDER BY P.NM_PRESTADOR, I.DT_INICIO, S.NM_SETOR
