Select p.Cd_Prestador As "C�digo do Prestador",
       Initcap(p.Nm_Prestador) As "Nome do Cooperado",
       (Select Ep.Cd_Especialidade || ' - ' || Initcap(e.Ds_Especialidade)
          From Dbaps.Especialidade_Prestador Ep, Especialidade e
         Where Ep.Cd_Especialidade = e.Cd_Especialidade
           And Ep.Cd_Prestador = p.Cd_Prestador
           And Ep.Sn_Principal = 'S') As "Especialidade Principal",
       p.Ds_Email As "Email",
       p.Nr_Cpf_Cgc As "CPF",
       p.Ds_Cod_Conselho As Crm,
       (Select Initcap(Te.Ds_Tipo_Endereco)
          From Dbaps.Tipo_Endereco Te
         Where Te.Cd_Tipo_Endereco = Pe.Cd_Tipo_Endereco) As "Tipo Endere�o",
       Initcap(Pe.Ds_Municipio) As "Cidade",
       Initcap(Pe.Ds_Bairro) As "Bairro",
       Initcap(Pe.Tp_Logradouro) As "Logradouro",
       Initcap(Pe.Ds_Endereco) As "Endere�o",
       Pe.Nr_Endereco As "N�mero",
       Initcap(Pe.Ds_Complemento) As "Complemento",
       Pe.Nr_Ddd,
       Pe.Nr_Telefone,
       p.Nr_Celular

  From Dbaps.Prestador p, Dbaps.Prestador_Endereco Pe
 Where p.Cd_Prestador = Pe.Cd_Prestador
   And p.Dt_Inativacao Is Null
   And p.Cd_Tip_Prestador = 0
   And Pe.Dt_Inativacao Is Null
   And p.Cd_Prestador <> 0
 Order By 2, 6
