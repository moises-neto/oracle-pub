 
Select Pap.Ds_Papel, U.*,U.Rowid 
  From Dbasgu.Usuarios U, Dbasgu.Papel_Usuarios Pa, Dbasgu.Papel Pap
 Where U.Sn_Ativo = 'N'
 --where Pa.Cd_Usuario = U.Cd_Usuario
   And Pa.Cd_Usuario = U.Cd_Usuario
   And Pap.Cd_Papel  = Pa.Cd_Papel
   And Pap.Cd_Papel = 228 -- Papel 180 usado na pesquisa 
 
