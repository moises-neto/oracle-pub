select *from solsai_pro s where s.cd_pre_med = 3089820
