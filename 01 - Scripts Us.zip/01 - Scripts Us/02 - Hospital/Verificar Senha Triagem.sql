select *from triagem_atendimento t where t. ds_senha = 'PL0018'
