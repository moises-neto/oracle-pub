Select U.CD_USUARIO,U.NM_USUARIO, U.DS_OBSERVACAO, U.SN_ATIVO
  From Dbasgu.Usuarios U 
 --Where U.Sn_Ativo = 'S'
 WHERE DS_Observacao in '0071 - RECEPCAO - HMS (ESTAGIARIO)'

