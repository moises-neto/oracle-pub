/*********INTEGRACAO DE GE********|
+---------------------------------+
|   VALOR   |  TIPO DE INTEGRACAO |   
+-----------+---------------------+
|     A     | AGUARDANDO(DEDU��O) |
|     N     |     PEDIDO NOVO     |
|     P     |  PROCESSANDO PEDIDO | 
|     S     |PEDIDO ENVIADO AO RIS|
+-----------+---------------------+
|   VALOR   |  ORDEM DE CONTROLE  |
+-----------+---------------------+
|    NW     |   PEDIDO NOVO       |
|    XO     |  ALTERAR PEDIDO     |
|    CA     |  EXCLUIR PEDIDO     |
|---------------------------------*/

SELECT --O.ID,
       O.PAC_NOME,
       O.NRO_ATENDIMENTO,
       O.PED_NUMERO,
       O.CTRL_DATE_AGENDAMENTO DT_PEDIDO,
       O.ACCESS_NUMBER,    
       O.PRT_ID_RIS,
       O.PRT_NAME,
       O.ORDER_CONTROL,
       TO_CHAR(O.CTRL_READING_DATE, 'DD/MM/YYYY HH24:MI:SS') DT_CONSUMO_GE,
       TO_CHAR(O.CTRL_ENTREGA_DATE_RIS,'DD/MM/YYYY HH24:MI:SS') DT_ENVIO_RIS,
       O.CTRL_INTEGRATION
       --O.OBSERVACAO
       FROM GEINTEGRA.ORM_INCOMING O
  --WHERE O.PED_NUMERO = 'PEDIDO'
  WHERE O.NRO_ATENDIMENTO = '4582840'
ORDER BY O.CTRL_ENTREGA_DATE_RIS, O.NRO_ATENDIMENTO;



