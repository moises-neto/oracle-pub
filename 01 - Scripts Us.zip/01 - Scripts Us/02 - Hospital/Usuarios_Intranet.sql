Select u.Cd_Usuario,
       u.Nm_Usuario,
       Case
         When Length(u.Cpf) = 9 Then
          '00' || u.Cpf
         When Length(u.Cpf) = 10 Then
          '0' || u.Cpf
         Else
          u.Cpf
       End Cpf,
       u.Ds_Observacao,
       '' Setor,
       '' Responsavel,
       '' Papel,
       'S' SOUL
      
  From Dbasgu.Usuarios u
 Where u.Sn_Ativo = 'S'
   And u.Ds_Observacao Not In
       ('180 - MEDICOS', '15 - LABORATORIO TERCEIRIZADO')
   And u.Cd_Usuario Not In ('DBASGU',
                            'GEINTEGRA',
                            'COMPRASWEB',
                            'GERENCIADOR',
                            'PACS',
                            'PALM',
                            'LAUDOWEB',
                            'SUPRIMENTOS',
                            'FARMACIADAY',
                            'RAIOX',
                            'IMUNOQUIMICA',
                            'MICROBIOLOGIA',
                            'HEMATOLOGIA',
                            'ACESSOPRD',
                            'INTEGRA',
                            'IMPRESSAO',
                            'DBAPS',
                            'ACOLHIMENTO',
                            'DBAMV',
                            'NPACIENTE',
                            'LACTARIO',
                            'ASSISTENCIAL',
                            'AUTOMATICO',
                            'TRIAGEM',
                            'TESTE',
                            'MVPADRAO',
                            'SCIH',
                            'CONTROLADOR',
                            'NEOH')
   And (Case
         When Length(u.Cpf) = 9 Then
          '00' || u.Cpf
         When Length(u.Cpf) = 10 Then
          '0' || u.Cpf
         Else
          u.Cpf
       End) Not In (Select wu.Nrcpf
                      From WEB_USUARIO@ORSAT.WORLD wu
                     Where wu.Nrcpf = (Case
                             When Length(u.Cpf) = 9 Then
                              '00' || u.Cpf
                             When Length(u.Cpf) = 10 Then
                              '0' || u.Cpf
                             Else
                              u.Cpf
                           End))

Union All

Select '' CDUSUARIO,
       U.NOUSUARIO,
       U.NRCPF,
       (SELECT C.NMCARGO
          FROM WEB_CARGO@ORSAT.WORLD C
         WHERE C.CDCARGO = U.CDCARGO) CARGO,
       (SELECT TO_CHAR(CC.CDCENTROCUSTO || ' - ' || CC.NOCENTROCUSTO)
          FROM WEB_CENTRO_CUSTO@ORSAT CC
         WHERE CC.CDCENTROCUSTO = U.CDCENTROCUSTO
           AND CC.CDUNIDADE = U.CDUNIDADE) SETOR,
       
       (SELECT us.nousuario
          FROM WEB_GESTOR@ORSAT G, WEB_USUARIO@ORSAT US
         WHERE G.CDCENTROCUSTO = u.CDCENTROCUSTO
           AND G.CDUSUARIO = US.CDUSUARIO
           AND G.TPGESTOR = 'C'
           AND US.AOATIVO = 'S'
           and rownum = 1) RESPONSAVEL,
       (SELECT listagg(C.CD_PAPEL || ' - ' || P.DS_PAPEL, ', ') within group(order by C.CD_PAPEL) PAPEL
          FROM CUSTOM.PAPEL_CENTRO_CUSTO C, DBASGU.PAPEL P
         WHERE C.CENTRO_CUSTO = U.CDCENTROCUSTO
           AND P.CD_PAPEL = C.CD_PAPEL) AS PAPEL,
       'N' SOUL
      
  From WEB_USUARIO@ORSAT.WORLD U
 Where U.NRCPF Not In (Select Case
                                When Length(us.Cpf) = 9 Then
                                 '00' || us.Cpf
                                When Length(us.Cpf) = 10 Then
                                 '0' || us.Cpf
                                Else
                                 us.Cpf
                              End
                         From Dbasgu.Usuarios us
                        Where (Case
                                When Length(us.Cpf) = 9 Then
                                 '00' || us.Cpf
                                When Length(us.Cpf) = 10 Then
                                 '0' || us.Cpf
                                Else
                                 us.Cpf
                              End) = U.NRCPF)
   And u.Aoativo = 'S'
 Order By 2
 
 select u.cd_usuario_gravacao from dbasgu.usuarios u where u.cd_usuario ='KBARBOSA'
 
 
 SELECT * FROM WEB_CARGO@ORSAT.WORLD C
 
 
 SELECT *
          FROM WEB_CENTRO_CUSTO@ORSAT CC
          
          select * From WEB_USUARIO@ORSAT.WORLD wu
          where wu.nousuario in ('LUIS CARLOS TERCIANI','MOISES DE SOUZA NETO')
          
          SELECT * FROM WEB_FUNCAO@ORSAT
          SELECT * FROM WEB_USUARIO@ORSAT U
          
          SELECT * FROM ALL_TABLES@ORSAT WHERE OWNER = 'ADMWEB'
          
          SELECT * FROM WEB_GESTOR@ORSAT G 
          JOIN WEB_USUARIO@ORSAT U
          ON U.CDUSUARIO = G.CDUSUARIO 
          WHERE G.CDCENTROCUSTO = U.CDCENTROCUSTO
          
       SELECT * FROM WEB_GESTOR@ORSAT G, WEB_USUARIO@ORSAT  US
          --WHERE G.CDCENTROCUSTO = 80
          WHERE G.CDUSUARIO = US.CDUSUARIO
          AND US.AOATIVO = 'S'
          AND G.TPGESTOR = 'C'
          and rownum = 1
