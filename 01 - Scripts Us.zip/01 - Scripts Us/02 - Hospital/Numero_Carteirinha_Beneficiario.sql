SELECT a.nr_carteira, a.dt_atendimento, a.tp_atendimento, a.dt_alta
      FROM   atendime a
      WHERE  a.cd_atendimento =  '4545312';
      
      SELECT decode(g.nr_carteira_beneficiario,
                    NULL,
                    (SELECT DISTINCT c.cd_mat_alternativa
                       FROM dbaps.usuario@ormvps c
                      WHERE c.cd_matricula = g.cd_matricula),
                    g.nr_carteira_beneficiario) nr_carteira_aut,
             g.dt_vencimento dt_validade_aut,
             (SELECT m.ds_mot_cancelamento_guia
                FROM dbaps.mot_cancelamento_guia@ormvps m
               WHERE m.cd_mot_cancelamento_guia = g.cd_mot_cancelamento_guia) mot_canc,
             (SELECT max(i.qt_solicitado)
                FROM dbaps.itguia@ormvps i
               WHERE i.nr_guia = g.nr_guia) qt_autorizado,
             (SELECT min(i.qt_solic_prest)
                FROM dbaps.itguia@ormvps i
               WHERE i.nr_guia = g.nr_guia) qt_solicitado,
             g.cd_ptu_mensagem_destino senha_externa,
             g.nr_guia senha_interna
        FROM dbaps.guia@ormvps g
       WHERE g.nr_guia = TRIM(to_char(14900539));
               
               SELECT DISTINCT G.CD_SENHA
		  	FROM GUIA    G
			 WHERE G.CD_ATENDIMENTO = '4325764'
				 AND G.TP_GUIA <> 'O'	;
