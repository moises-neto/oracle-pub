 select E.CD_ESTOQUE, E.DS_ESTOQUE, E.TP_COTA_ESTOQUE, E.SN_LIM_TRANS_COTA
   from dbamv.estoque e
   where e.cd_estoque in (21, 4,1,2,3,5);
   
   
   SELECT * FROM dbamv.estoque e
   where E.SN_LIM_TRANS_COTA not in ('N');
   

   /*
   BEGIN
     FOR C IN (SELECT p.cd_id_do_usuario
                      FROM DBAMV.USU_ESTOQUE P
                      WHERE p.cd_id_do_usuario IN('ABERA')               
   AND P.CD_ESTOQUE IN (4, 5,6,7,8,9, 10,11, 12, 13, 14,15,16, 17, 18, 19,21, 22, 23,25, 26,31, 50,55, 56,57, 58,59,60, 61, 66, 67,74,75,76)
   AND P.SN_TRANS_QUANT_COTA = 'S') 
   
   LOOP
       BEGIN
         UPDATE DBAMV.USU_ESTOQUE E
            SET E.SN_TRANS_QUANT_COTA = 'N'
          WHERE E.CD_ID_DO_USUARIO = C.CD_ID_DO_USUARIO;
       
       END;
     END LOOP;
   
   END;
*/
   
   
   select p.cd_id_do_usuario from dbamv.usu_estoque P
   where P.SN_TRANS_QUANT_COTA = 'S'
   and rownum <= 2


select o.cd_estoque, o.cd_id_do_usuario, o.sn_trans_quant_cota from dbamv.usu_estoque o
where o.cd_id_do_usuario in ('MAGALHARDO','PCARMO','MNETO')

select D.cd_estoque, D.cd_id_do_usuario, D.sn_trans_quant_cota from dbamv.usu_estoque D
where D.sn_trans_quant_cota not in ('S', 'N')

select rowid, e.* from CUSTOM.CHM_TI_PAPEL_ESTOQUE e where e.cd_estoque in (27,
35,
36,
37,
38,
39)
