--SELECT CONTA AMBULATORIAL
SELECT t.cd_atendimento,
       t.nr_guia,
       t.nm_paciente,
       t.cd_cpf_contratado
   FROM tiss_guia t      
WHERE t.cd_atendimento IN ( SELECT i.Cd_Atendimento FROM reg_amb r, itreg_amb i 
WHERE r.cd_remessa = 517801   --N�MERO DA REMESSA     
   AND r.cd_reg_amb = i.cd_reg_amb);

--SELECT CONTA HOSPITALAR
SELECT t.cd_atendimento,
       t.nr_guia,
       t.nm_paciente,
       t.cd_cpf_contratado
  FROM tiss_guia t    
WHERE t.cd_atendimento IN ( SELECT r.Cd_Atendimento FROM reg_fat r, itreg_fat i        
WHERE r.cd_remessa = 516955   --N�MERO DA REMESSA       
  AND r.cd_reg_fat = i.cd_reg_fat);

--SELECT NUMERO DA GUIA
SELECT g.nr_guia,
       g.dt_autorizacao,
       g.cd_senha 
  FROM guia g    
WHERE g.cd_atendimento = 4327150;   --N�MERO DO ATENDIMENTO; 

--SELECT NUMERO DO ATENDIMENTO
SELECT  t.cd_atendimento,
        t.nr_guia_sol,
        t.dt_autorizacao,
        t.cd_senha,
ROWID FROM tiss_guia t
WHERE t.cd_atendimento = 4327150;   --N�MERO DO ATENDIMENTO





