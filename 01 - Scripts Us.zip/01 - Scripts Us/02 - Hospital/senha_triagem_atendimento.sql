select * from triagem_atendimento
o where o.ds_senha like '%POE0002%'
and O.DH_PRE_ATENDIMENTO > '28/08/2020'
