SELECT * FROM Custom.Vw_Docs_Eletronicos_Fechados Vw
WHERE custom.Vw.Cd_Documento = 374
   AND vw.Cd_Prestador = '1093';
   
   --AND vw.Cd_Usuario = 'MNETO'; 
   
SELECT * FROM CUSTOM.VW_DIAG_EXAM_PRESC;
   
SELECT * FROM CUSTOM.VW_DIAGN_EXA_DUP_LAB VW
WHERE VW.CD_ATENDIMENTO = '4545312';

SELECT * FROM custom.dc_mov_paciente;

SELECT * FROM Custom.Vw_Docs_Eletronicos_Fechados vw
WHERE VW.Cd_Atendimento = '4545312'
AND VW.Cd_Usuario = 'LCARSETI';

SELECT * FROM DBAMV.Pw_Documento_Clinico;

SELECT Dc.Cd_Paciente,
       Dc.Cd_Atendimento,
       Dc.Nm_Documento,
       Ec.Cd_Documento,
       Dc.Dh_Criacao,
       Dc.Dh_Fechamento,
       Dc.Cd_Documento_Clinico,
       Dc.Cd_Usuario,
       Dc.Cd_Prestador,
       Dc.Cd_Setor,
       Ec.Cd_Editor_Registro,
       Dc.Cd_Objeto
  FROM Pw_Documento_Clinico Dc, 
       Pw_Editor_Clinico Ec
WHERE DC.CD_ATENDIMENTO = '4545312'
AND DC.CD_USUARIO = 'AGIANOTTI'
AND Dc.Cd_Documento_Clinico = Ec.Cd_Documento_Clinico;

