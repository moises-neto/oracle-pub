SELECT *
  FROM ALL_SOURCE S
 WHERE UPPER(S.TEXT) LIKE '%1671%'
   AND S.TYPE IN ('TRIGGER', 'PROCEDURE')
   
   
   
   
DBAMV.PACK_LANCA_FFCV

select distinct a.* from all_souRce A where a.type = 'PACKAGE' AND A.OWNER NOT IN ('SYS','SYSTEM')

