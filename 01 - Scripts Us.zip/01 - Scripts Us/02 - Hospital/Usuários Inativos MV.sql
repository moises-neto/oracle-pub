Select *
  From dbasgu.usuarios u
 Where u.sn_ativo = 'N'
 Order By u.cd_usuario 
