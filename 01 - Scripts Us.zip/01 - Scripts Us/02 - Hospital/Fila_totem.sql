 Select F.*,F.Rowid From Fila_Senha F
 where f.ds_fila like '%UTI%'

