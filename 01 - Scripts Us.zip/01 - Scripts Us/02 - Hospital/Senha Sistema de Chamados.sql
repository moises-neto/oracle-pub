Select S.*, Custom.Cript(S.Password, 'XMSDES-CRIPT') Senha From Chm_Solicitantes S
Where S.Cd_Login = Upper('CPAIVA')

SELECT u.*, Custom.Cript(u.cd_senha, 'XMSDES-CRIPT') Senha FROM Dbasgu.Usuarios U
WHERE U.CD_USUARIO = Upper('CPAIVA');
