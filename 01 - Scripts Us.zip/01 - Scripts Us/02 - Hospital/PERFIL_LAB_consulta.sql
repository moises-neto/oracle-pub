
SELECT l.cd_usuario, l.tp_atividade, p.tp_prestador, p.cd_prestador
  FROM USUARIO_PRESTADOR_LAB L
 inner join prestador p
    on p.cd_prestador = l.cd_prestador
 WHERE L.CD_USUARIO IN
       (SELECT UP.CD_USUARIO
          FROM DBASGU.PAPEL_USUARIOS UP
         WHERE UP.CD_PAPEL in (158, 151, 166, 150, 272, 160))

  SELECT *
          FROM USUARIO_PRESTADOR_LAB L
         WHERE L.CD_USUARIO IN (SELECT UP.CD_USUARIO
                                  FROM DBASGU.PAPEL_USUARIOS UP
                                 WHERE UP.CD_PAPEL = '151');


select u.cd_usuario
  from dbasgu.papel_usuarios u
 where u.cd_papel in (161, 162)

 CUSTOM.TRG_TI_VINCULA_PERMISSOES_TUDO

  select u.cd_usuario, pa.cd_papel, pa.ds_papel
          from dbasgu.papel_usuarios u
          join dbasgu.papel pa
            on pa.cd_papel = u.cd_papel
         inner join dbasgu.usuarios p
            on u.cd_usuario = p.cd_usuario
         where u.cd_papel in (151, 270, 158, 159, 166, 150, 272, 160)
           and p.sn_ativo = 'S'
        
          SELECT *
                  FROM USUARIO_PRESTADOR_LAB L
                 WHERE L.CD_USUARIO IN
                       (SELECT UP.CD_USUARIO
                          FROM DBASGU.PAPEL_USUARIOS UP
                         WHERE UP.CD_PAPEL = '151');
                 
                   
                   SELECT U.CD_PRESTADOR
                     FROM DBASGU.PAPEL_USUARIOS P
                     JOIN DBASGU.USUARIOS U
                       ON P.CD_USUARIO = U.CD_USUARIO
                    WHERE P.CD_PAPEL IN (162, 161)
                    
                    GRANT INSERT, UPDATE, DELETE, SELECT ON DBASGU.USUARIO_PRESTADOR_LAB TO CUSTOM;
                    
                    SELECT U.CD_PRESTADOR
                    FROM DBASGU.PAPEL_USUARIOS P
                    JOIN DBASGU.USUARIOS U
                      ON P.CD_USUARIO = U.CD_USUARIO
                   WHERE P.CD_PAPEL IN (162, 161)
                   
                   --MARMAIA
                   --ESHITARA
                   --DBAMV
                   
                   INSERT INTO USUARIO_PRESTADOR_LAB(CD_USUARIO, CD_PRESTADOR, TP_ATIVIDADE, TP_ACAO)
                  VALUES(:NEW.CD_USUARIO, F.CD_PRESTADOR, 'P', 'L')
                   
                   SELECT *
                  FROM USUARIO_PRESTADOR_LAB L
                 WHERE L.CD_USUARIO IN
                       (SELECT UP.CD_USUARIO
                          FROM DBASGU.PAPEL_USUARIOS UP
                         WHERE UP.CD_PAPEL = '272')
                   for update;



select *
  from prestador p
 where p.tp_prestador = 'O'
   and p.tp_situacao = 'A'

  select *
          from tip_presta tp
         where tp.nm_tip_presta like '%LAB%'
        
          select *
                  from DBAsgu.PAPEL_USUARIOs
                 
                 USUARIO_PRESTADOR_LAB
