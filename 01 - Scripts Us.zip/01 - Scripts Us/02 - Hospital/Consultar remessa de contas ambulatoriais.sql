Consultar remessa de contas ambulatoriais:
select t.cd_atendimento, t.nr_guia, t.nm_paciente, t.cd_cpf_contratado from tiss_guia t
       where t.cd_atendimento in (
select distinct i.Cd_Atendimento from reg_amb r, itreg_amb i
       where r.cd_remessa = �NUMERO DA REMESSA� 
       and r.cd_reg_amb = i.cd_reg_amb);

