Select pw.cd_tipo_documento "C�digo tipo do objeto",
       o.tp_objeto          "Descri��o tipo do objeto",
       o.cd_objeto          "C�digo do objeto",
       o.nm_objeto          "Descri��o do objeto"
  From editor_registro         e,
       editor_layout           l,
       editor_versao_documento v,
       editor_documento        d,
       pw_documento_objeto     p,
       pagu_objeto             o,
       pw_documento_clinico    pw,
       pw_editor_clinico       ec
 Where e.cd_layout    = l.cd_layout
   And l.cd_versao_documento = v.cd_versao_documento
   And v.cd_documento = d.cd_documento
   And d.cd_documento = p.cd_documento
   And p.cd_objeto    = o.cd_objeto
   And pw.cd_documento_clinico = ec.cd_documento_clinico
   And ec.cd_editor_registro = e.cd_registro
   /* Informar abaixo o c�digo do registro do doc */
   And e.cd_registro = 7806747;
