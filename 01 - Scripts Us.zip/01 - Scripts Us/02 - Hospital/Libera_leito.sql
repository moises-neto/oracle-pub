
select l.*, rowid from dbamv.leito l
where l.ds_leito like '%ENF045-1%' 

--OR  l.ds_leito like '%ENF039-2%'

SELECT M.*, ROWID FROM DBAMV.MOV_INT M
WHERE M.CD_LEITO = '554'
ORDER BY M.HR_MOV_INT DESC

select * from paciente p
where p.cd_paciente = 1009169




--3784


