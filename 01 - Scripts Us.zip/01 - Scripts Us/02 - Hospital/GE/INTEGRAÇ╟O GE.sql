select pac_id AS PRONTUARIO,       
       pac_nome||' '||pac_sobrenome paciente,
       nro_atendimento,
       --sal_id sala_exame,
       ped_numero,
       --local_entrega,
       order_control,
       --prt_id_ris cod_exame_ge,
       prt_name desc_exame,
       access_number,
       to_char(p.hr_pedido, 'dd/mm/yyyy hh24:mi:ss') hr_pedido,
       ctrl_date_agendamento dt_integracao_hus,
       to_char(ctrl_reading_date, 'dd/mm/yyyy hh24:mi:ss') dt_integracao_ge,
       to_char(ctrl_entrega_date_ris, 'dd/mm/yyyy hh24:mi:ss') dt_envio_ris,
       ctrl_integration
       --observacao
       
       from geintegra.orm_incoming o, dbamv.ped_rx p
       where ((p.dt_pedido = '09/11/2018') or (o.ctrl_reading_date is null))
       and o.ped_numero = to_char(p.cd_ped_rx)
order by id
       
