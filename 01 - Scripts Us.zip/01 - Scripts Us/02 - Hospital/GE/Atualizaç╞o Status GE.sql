select *from geintegra.laudo_ris a where a.pedido = '1620776'

-- F Aprovado
-- S Escrito
-- X Excluso
