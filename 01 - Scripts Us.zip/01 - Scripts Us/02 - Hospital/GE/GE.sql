select *
     from PACSBILDSEQ@MEDORA P,
          UNTBEH@MEDORA      U
     where P.PACSBILDSEQ_STATUS IN ('a', 'f', 'm', 'w', 'z') --deixando s� o 'F' n�o exibe nenhum resultado, certeza que � esta coluna?
     AND P.TERMIN_UBTID = U.TERMIN_UBTID 
     AND P.PATIENT_PID = U.PATIENT_PID 
     order by P.PACSBILDSEQ_STATUS;
     /*UNTBEH_STATUS est� coluna possui as siglas 'F'*/
----------------------------------------------------------------------------------     
     select *
     from UNTBEH@MEDORA U,
          PACSBILDSEQ@MEDORA P
     where u.untbeh_zusatz_id = '2680022'  
     AND P.TERMIN_UBTID(+) = U.TERMIN_UBTID    
    AND P.PATIENT_PID(+) = U.PATIENT_PID 
     
     UNION
     
     select *
     from UNTBEH@MEDORA U,
          PACSBILDSEQ@MEDORA P
     where u.untbeh_zusatz_id = '2686407'  
     AND P.TERMIN_UBTID(+) = U.TERMIN_UBTID    
     AND P.PATIENT_PID(+) = U.PATIENT_PID 
     
     UNION
     
     select *
     from UNTBEH@MEDORA U,
          PACSBILDSEQ@MEDORA P
     where u.untbeh_zusatz_id = '2681526'  
     AND P.TERMIN_UBTID(+) = U.TERMIN_UBTID    
     AND P.PATIENT_PID(+) = U.PATIENT_PID 
    
     
---------------------------------------------------------------------------
    
select U.UNTBEH_ZUSATZ_ID,
P.PACSBILDSEQ_STUDY_UID,
U.UNTBEH_STATUS,
P.UBERGEBNIS_UBEID       
     from UNTBEH@MEDORA U,
          PACSBILDSEQ@MEDORA P
     --where u.untbeh_zusatz_id = '2684082'  
     WHERE U.UNTBEH_STATUS = 'u'
     --AND P.PACSBILDSEQ_STUDY_UID is NULL
    -- AND P.UBERGEBNIS_UBEID IS NULL
     AND TO_CHAR(UNTBEH_START_GEPLANT, 'MM/YYYY') = '11/2018'
     AND P.TERMIN_UBTID(+) = U.TERMIN_UBTID   
     AND P.PATIENT_PID(+) = U.PATIENT_PID
     
     

select *
     from UNTBEH@MEDORA U,
          PACSBILDSEQ@MEDORA P
     where U.UNTBEH_SCHWANGER_JN <> 'n' --acesso number. 
     AND P.TERMIN_UBTID(+) = U.TERMIN_UBTID      
    AND P.PATIENT_PID(+) = U.PATIENT_PID 
    AND TO_CHAR(UNTBEH_START_GEPLANT, 'MM/YYYY') = '11/2018'
    union 
    
    select *
     from UNTBEH@MEDORA U,
          PACSBILDSEQ@MEDORA P
     where u.untbeh_zusatz_id = '2685184' --acesso number. 
     AND P.TERMIN_UBTID(+) = U.TERMIN_UBTID      
    AND P.PATIENT_PID(+) = U.PATIENT_PID 
    
    union 
    
    select *
     from UNTBEH@MEDORA U,
          PACSBILDSEQ@MEDORA P
     where u.untbeh_zusatz_id = '2688531' --acesso number. 
    AND P.TERMIN_UBTID(+) = U.TERMIN_UBTID      
    AND P.PATIENT_PID(+) = U.PATIENT_PID 
    
   
SELECT *
--U.UNTBEH_ZUSATZ_ID
  FROM PACSBILDSEQ@MEDORA P,
       UNTBEH@MEDORA U
--WHERE u.untbeh_zusatz_id = '2680022' -- INSERIR O ACC NUMBER DO EXAME
WHERE U.UNTBEH_STATUS <> 'u'
AND P.PACSBILDSEQ_STUDY_UID IS NULL
AND P.TERMIN_UBTID(+) = U.TERMIN_UBTID
AND P.PATIENT_PID(+) = U.PATIENT_PID
AND to_char(untbeh_start_geplant, 'MM/YYYY') = '12/2018'
--AND to_char(untbeh_start_geplant, 'MM/YYYY') = '12/2018'
ORDER BY untbeh_start_geplant ;


select * from Dbamv.ITPED_RX ir
--where to_char(ir.dt_realizado, 'DD/MM/YYYY') = '19/12/2018'
where cd_itped_rx = '2680368';

select count(P.UBERGEBNIS_UBEID)
from
PACSBILDSEQ@MEDORA P,
       UNTBEH@MEDORA U
where P.TERMIN_UBTID(+) = U.TERMIN_UBTID      
AND P.PATIENT_PID(+) = U.PATIENT_PID 

SELECT * FROM UNTBEH_AUDIT@MEDORA;


SELECT count(P.UBERGEBNIS_UBEID)  FROM PACSBILDSEQ@MEDORA P, UNTBEH@MEDORA U
 WHERE P.pacsbildseq_status not in ('z', 'n')
   AND P.TERMIN_UBTID(+) = U.TERMIN_UBTID
   AND P.PATIENT_PID(+) = U.PATIENT_PID
		
 
 

		select UA.UNTBEH_AUDIT_ID,
       MV.PAC_NOME                    AS PAC_NOME_MV,
       MV.PAC_SOBRENOME               AS PAC_SOBRENOME_MV,
       MV.PED_NUMERO                  as PED_NUMERO_MV,
       MV.NRO_ATENDIMENTO,
       MV.ACCESS_NUMBER,
       P.TERMIN_UBTID                 as TERMIN_UBTID_PACS,
       UA.TERMIN_UBTID                as TERMIN_UBTID_RIS,
       P.PATIENT_PID,
       UA.PATIENT_PID,
       ua.untbeh_audit_id,
       ua.termin_ubtid,
       ua.untbeh_start_geplant,
       ua.untbeh_start,
       ua.untbeh_ende,
       p.pacsbildseq_status,
       ua.untbeh_status,
       ua.untbeh_bemerkung,
       ua.mitarbeiter_pid,
       ua.mitarbeiter_pid,
       ua.institut_pid,
       ua.untbeh_fragestellung,
       ua.abrfall_abrid,
       ua.untbeh_schwanger_jn,
       ua.untbeh_zusatz_id,
       ua.letzte_aenderung,
       ua.terminal,
       ua.pp_incomplete_report_jn,
       ua.pp_misc_text_1,
       ua.pp_misc_text_4,
       ua.pp_misc_boolean_jn_1,
       ua.ppa_modified_date,
       ua.ppa_modified_terminal,
       ua.ppa_module,
       ua.ppa_sys_dml_action_code,
       ua.pp_approval_status_code,
       ua.pp_request_date,
       ua.pp_last_filler_order_number

  from untbeh_audit@MEDORA UA,
       PACSBILDSEQ@medora P,
       geintegra.orm_incoming MV

 --where to_char(ua.untbeh_start_geplant, 'DD/MM/YYYY') = '12/12/2018'
 --and p.ubergebnis_ubeid = '1564323'

      --AND P.TERMIN_UBTID(+) = UA.TERMIN_UBTID
       WHERE mv.nro_atendimento = '5451119'
  AND P.PATIENT_PID(+) = UA.PATIENT_PID
   and UA.UNTBEH_GRUPPEN_FREMDID = MV.PED_NUMERO

--and ua.patient_pid = p.patient_pid(+)

 --order by mv.pac_nome
 
 
 select *

 from dbamv.LAUDO_RX

 WHERE CD_PED_RX = 2084133
 --WHERE DT_LAUDO = '07/01/2019'
 --AND CD_PRESTADOR = '312'
              
 
 ---------------------------------------------------------------
 
  
  select pa.nm_paciente,
         a.cd_atendimento,
         a.cd_paciente,
         s.nm_set_exa,
         p.cd_ped_rx,
         to_char(p.dt_pedido, 'dd/mm/yyyy hh24:mi:ss') dt_pedido
         
    from ATENDIME       A,
         PACIENTE PA,
         SET_EXA  S,
         PED_RX         P
   WHERE s.cd_set_exa = '5' 
     AND PA.CD_PACIENTE = A.CD_PACIENTE
     AND A.CD_ATENDIMENTO = P.CD_ATENDIMENTO
     and p.cd_set_exa = s.cd_set_exa
     and A.DT_ATENDIMENTO LIKE '23/03/2019'
     
     
     
     SELECT P.CD_PACIENTE,
       --P.CD_PACIENTE_ANTIGO,
       P.NM_PACIENTE,
       P.DT_CADASTRO,
       P.DT_ULTIMA_ATUALIZACAO
select * 
  FROM DBAMV.PACIENTE P

 WHERE P.CD_PACIENTE = '1121190'
 
 
 select * from PED_RX P;
 
 select l.cd_laudo, l.cd_prestador, l.cd_ped_rx, l.ds_laudo, l.hr_laudo from dbamv.laudo_rx l
 where l.dt_laudo = '01/01/2016'
 and l.cd_prestador = '1093'
 
 select l.cd_laudo, 
        l.cd_prestador, 
        l.cd_ped_rx, 
        l.ds_laudo, 
        l.hr_laudo 
 from dbamv.laudo_rx l
 WHERE l.cd_laudo = 1614028
 
 select * from set_exa;
 
 select * from ITPED_RX;
 
 select * from all_directories
  SELECT *  from dba_users@medora u, mitarbeiter@medora m
  
  where initial_rsrc_consumer_group = 'DEFAULT_CONSUMER_GROUP'
   and profile = 'RIS_USER'
   and u.username(+) = m.ma_bs_username
   and u.username  = 'CPAIVA'
   
  
 Select m.ma_kuerzel as Cod,
       m.vorname as Nome,
       m.name as Sobrenome,
       u.username as Usuario,
       u.created as Dt_Criacao,
       u.account_status as Status,
       u.lock_date as Dt_Bloq,
       u.expiry_date as DT_Exp,
       m.bemerkung as Nota
  from dba_users@medora u, mitarbeiter@medora m
 where initial_rsrc_consumer_group = 'DEFAULT_CONSUMER_GROUP'
   and profile = 'RIS_USER'
   and u.username(+) = m.ma_bs_username
   and u.username  = 'CPAIVA'
 order by m.vorname, m.name desc
 
 
Select lower(Substr(Rtrim(Dbasgu.Cripto_Descripto(Cd_Senha, 'SMVCRIPTON'), 'KK'),
              Length(Cd_Usuario) + 1, 30)) AS SENHA
  From Dbasgu.Usuarios
 Where (Cd_Usuario) = 'JUCOUTO' 
 
 
 select rowid, mv.* from geintegra.orm_incoming MV where mv.ped_numero in  ('2339980','2270759' )
 
 
 
 
 
 /* MERGE DE PACIENTES NO RIS */
 
 SELECT PERSONEN_ID,KISS_PATIENT_JN,SWITCH_PATIENT,NAME,VORNAME,
VORNAME_LOCAL_CHARSET,NAME_LOCAL_CHARSET,TITEL,NPERSON_NAMENSZUSATZ,
GEBURTSDATUM,GESCHLECHT,GEBURTSNAME,PATIENT_ZUSATZ_ID,PATIENT_FREMD_ID,
STRASSE_HAUSNR,LAND_AKZ,PLZ,ORT,ONKZ,TEL_RUFNUMMER,FAX_RUFNUMMER,
JPERSON_PID_VERSICHERUNG,PATIENT_KBV_IK,PD_INST_DATA_SHARING_AGREED_JN FROM 
V_PATZUS WHERE (PERSONEN_ID=110841316


SELECT * FROM V_PATZUS@MEDORA
WHERE PERSONEN_ID = 110390400

SELECT PERSONEN_ID,KISS_PATIENT_JN,SWITCH_PATIENT,NAME,VORNAME,
NAME_LOCAL_CHARSET,VORNAME_LOCAL_CHARSET,TITEL,NPERSON_NAMENSZUSATZ,
GEBURTSDATUM,GESCHLECHT,GEBURTSNAME,PATIENT_ZUSATZ_ID,PATIENT_FREMD_ID,
STRASSE_HAUSNR,LAND_AKZ,PLZ,ORT,ONKZ,TEL_RUFNUMMER,FAX_RUFNUMMER,
JPERSON_PID_VERSICHERUNG,PATIENT_KBV_IK,PD_INST_DATA_SHARING_AGREED_JN FROM 
V_PATZUS@MEDORA WHERE (PERSONEN_ID IS NOT NULL)


SELECT * FROM PATIENT@MEDORA
--WHERE PERSONEN_ID = 110390400
WHERE ROWNUM <=10

 ------------ alterar codigo do ris
  select m.MA_KUERZEL, M.MITARBEITER_ORACLE_USER_NAME from mitarbeiter m
 WHERE M.MA_KUERZEL IN (SELECT U.CD_PRESTADOR FROM DBASGU.USUARIOS@ORMVPRD U WHERE U.SN_ATIVO = 'S')
 
 
 
--consulta prestado x codigo do ris
select to_char(m.ma_kuerzel) as Cod,
       m.vorname as Nome,
       m.name as Sobrenome,
       u.username as Usuario,
       u.created as Dt_Criacao,
       u.account_status as Status,
       u.lock_date as Dt_Bloq,
       u.expiry_date as DT_Exp,
       m.bemerkung as Nota
  from dba_users@medora U, mitarbeiter@medora m, dbasgu.usuarios u
 where initial_rsrc_consumer_group = 'DEFAULT_CONSUMER_GROUP'
   and profile = 'RIS_USER'
   and u.username = m.ma_bs_username
   and  M.BEMERKUNG = 'MEDICOS TELEIMAGEM'
   and m.ma_kuerzel = to_char(u.cd_prestador)
 order by m.vorname, m.name desc
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
