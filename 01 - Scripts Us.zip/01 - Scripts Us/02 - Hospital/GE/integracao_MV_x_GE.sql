---CONSULTA INTEGRA��O INTEGRA��O MV x RIS POR PEDIDO

/*
Ir ate o campo : " CTRL_READING_DATE"� E� �"CTRL_ENTREGA_DATE_RIS"� e apagar os registros.
"CTRL_INTEGRATION" COLOCAR A LETRA "P" �Depois confirmar, fechar o cadeado e clicar em "Commit"
*/

SELECT o.id,
       o.pac_id,
       o.pac_nome || ' ' || o.pac_sobrenome AS NOME_PACIENTE,
       o.setor_solicitante,
       o.nro_atendimento,
       o.tpo_atendimento,
       o.pac_tipo,
       TO_DATE(o.ped_dt_criacao,'yyyy/mm/dd hh24:mi:ss') AS DATA_PEDIDO,
       o.ped_numero,
       o.access_number,
       o.cod_med_sol,
       o.sal_id,
     --o.vis_id,
       to_date(o.ctrl_admit_date, 'yyyy/mm/dd hh24:mi:ss') AS ctrl_admit_date,
       o.order_control,
       to_date(o.ctrl_date_agendamento,'yyyy/mm/dd hh24:mi:ss') AS DATA_AGENDAMENTO,
       o.prt_id,
       o.prt_id_ris,
       o.prt_name,
       o.dep_id,
       o.ctrl_reading_date,
       o.ctrl_entrega_date_ris,
       o.ctrl_integration,
       ROWID
  FROM geintegra.Orm_Incoming o
 WHERE o.Nro_Atendimento = 5451119
   --AND O.Ped_Numero = 2362209
 ORDER BY O.ACCESS_NUMBER ASC

--------------------------------------------------------------------------------------------------------------------------------------------------
-------FOR�AR INTEGRA��O MV x RIS
DECLARE

BEGIN
� FOR IMG IN (SELECT P.CD_PED_RX
� � � � � � � � � � ,P.CD_ITPED_RX
� � � � � � � � � � ,R.DT_PEDIDO
� � � � � � � � � � ,R.HR_PEDIDO
� � � � � � � � FROM ITPED_RX P
� � � � � � � � � � ,PED_RX � R
� � � � � � � �WHERE P.CD_PED_RX = R.CD_PED_RX
� � � � � � � � �AND P.CD_ITPED_RX NOT IN (SELECT (TO_NUMBER(O.ACCESS_NUMBER)) 
                                                  FROM GEINTEGRA.ORM_INCOMING O 
                                                  WHERE TO_DATE(O.PED_DT_CRIACAO, 'yyyy/mm/dd hh24:mi:ss') >= SYSDATE - 5)
� � � � � � � � �AND R.Cd_Atendimento IN (5124189)
� � � � � � � � �) LOOP�
� � INSERT INTO CUSTOM.IGE_SAIDA_INTEGRACAO 
    VALUES (CUSTOM.IGE_ID_SAIDA_INTEGRACAO.NEXTVAL, IMG.CD_PED_RX, IMG.CD_ITPED_RX, 'NW', NULL, NULL);
� �
� END LOOP;
END;

--------------------------------------------------------------------------------------------------------------------------------------------------
SELECT --o.id,
       o.nro_atendimento,
       o.ped_numero,
       o.access_number,  
        o.pac_nome,
       o.ctrl_date_agendamento dt_pedido,  
       --o.prt_id_ris,
       o.prt_name,
       o.order_control,
       o.setor_solicitante,      
       to_char(o.ctrl_reading_date, 'dd/mm/yyyy hh24:mi:ss') dt_consumo_ge,
       to_char(o.ctrl_entrega_date_ris,'dd/mm/yyyy hh24:mi:ss') dt_envio_ris,
       o.ctrl_integration,
       o.ctrl_reading_date      
       --o.observacao
       FROM geintegra.orm_incoming o
  WHERE o.ped_numero = '2265534'
  --and access_number ='2409821'
  ORDER BY o.nro_atendimento;
----------------------------------------------------------------------------------------------------
  SELECT * FROM CUSTOM.LOG_EXCL_ITPED_RX L
WHERE L.CD_PED_RX = '2086119';

------------------------------------------------------------------------------------------------------
SELECT o.nro_atendimento,
       o.ped_numero,
       o.access_number,  
       o.pac_nome,
       l.user_db,
       l.user_so,
       l.data_exclusao,
       to_date(o.ctrl_date_agendamento,'dd/mm/yyyy hh24:mi:ss') dt_pedido, 
       o.prt_name,
       o.order_control,
       o.setor_solicitante,      
       to_char(o.ctrl_reading_date, 'dd/mm/yyyy hh24:mi:ss') dt_consumo_ge,
       to_char(o.ctrl_entrega_date_ris,'dd/mm/yyyy hh24:mi:ss') dt_envio_ris,
       o.ctrl_entrega_date_ris,
       o.ctrl_integration integracao   
         FROM geintegra.orm_incoming o,
              custom.log_excl_ITPED_RX l
WHERE o.nro_atendimento = 4860862
      AND o.ped_numero = l.cd_ped_rx
ORDER BY o.nro_atendimento;
--WHERE o.nro_atendimento = '&Atendimento'
--WHERE o.access_number = '&Acesso Number'
     
--------------------------------------------------------------------------------------------------------------
SELECT * FROM
custom.log_movimento_exame;
--------------------------------------------------------------------------------------------------------------
SELECT * FROM custom.log_protecao_radiologica pr
WHERE pr.cd_atendimento = '2086119';
--------------------------------------------------------------------------------------------------------------
SELECT * FROM custom.log_protecao_radiologica pr;
WHERE pr.dthr_pedido = '01/04/2018';
--------------------------------------------------------------------------------------------------------------



