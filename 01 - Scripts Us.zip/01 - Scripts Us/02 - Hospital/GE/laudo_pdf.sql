DECLARE

  cursor c is
  select cd_laudo, 
        cd_prestador, 
        cd_ped_rx, 
        ds_laudo, 
        hr_laudo 
 from dbamv.laudo_rx 
 WHERE cd_laudo = 1614028;
 
 arquivo_saida Utl_File.file_type;
 
BEGIN
  arquivo_saida := utl_file.fopen('C:\', 'laudo.rtf', 'w');
  For reg_linha in c loop
    utl_file.put_line(arquivo_saida, reg_linha.cd_laudo);
    utl_file.put_line(arquivo_saida, reg_linha.ds_laudo);
 end loop;
 utl_file.fclose(arquivo_saida);
 dbms_output.put_line('Arquivo Gerado com sucesso');
 
END;




select * from all_directories;


select * from user_views
