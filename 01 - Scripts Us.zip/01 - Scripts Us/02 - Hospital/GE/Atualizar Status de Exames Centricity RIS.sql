select U.TERMIN_UBTID,
       U.UNTBEH_ZUSATZ_ID,
       U.UNTBEH_START, 
       U.LETZTE_AENDERUNG, 
       U.UNTBEH_STATUS, 
       U.PATIENT_PID,
       u.rowid
from Untbeh u 
where u.untbeh_zusatz_id = '2050031'; 

--Alterar o Status de Aprovado para escrito e depois excluir o laudo
-- STATUS
--a Admitido
--b Iniciado
--w Espera
--u Terminado
--s Escrito
--D Ditado
--f Aprovado
