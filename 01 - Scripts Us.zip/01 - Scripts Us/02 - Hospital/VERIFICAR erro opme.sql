SELECT EXPR1,
       NRITEMMATERIAL,
       CD_TAB_FAT,
       AUTORIZADO,
       CODMATERIAL,
       CD_PRODUTO,
       DESCRICAO,
       CODFORNECEDOR,
       NOFORNECEDOR,
       QUANTIDADE,
       ROUND(CASE
               WHEN Y.CD_TAB_FAT IN (1, 17) THEN
                Y.VLUNITARIO
               WHEN TO_NUMBER(Y.VLUNITSTAXA) > 0 THEN
                Y.VLUNITSTAXA
               ELSE
                Y.VLUNITARIO - (0.15 * Y.VLUNITARIO)
             END,
             2) VLUNITARIOSTAXA,
       ROUND(CASE
               WHEN Y.CD_TAB_FAT IN (1, 17) THEN
                Y.VLUNITARIO * Y.QUANTIDADE
               WHEN TO_NUMBER(Y.VLUNITSTAXA) > 0 THEN
                Y.VLUNITSTAXA * Y.QUANTIDADE
               ELSE
                (Y.VLUNITARIO - (0.15 * Y.VLUNITARIO)) * Y.QUANTIDADE
             END,
             2) VLUNITARIOSTAXATOTAL,
       VLUNITARIO,
       VLTOTAL,
       VLUNIT15MAIS,
       ROUND(VLUNIT15MAIS * Y.QUANTIDADE, 2) VLUNIT15MAISTOTAL,
       NRANVISA,
       OBSERVACAO,
       CODTNUMM,
       CD_KIT
  FROM (SELECT ROWNUM AS EXPR1,
               OM.NRSOLICITACAO,
               OM.NRITEMMATERIAL,
               (SELECT (SELECT T.CD_TAB_FAT
                          FROM VAL_PRO VPR,
                               TAB_FAT T
                         WHERE VPR.CD_PRO_FAT = V.CD_PRO_FAT
                           AND VPR.DT_VIGENCIA = V.DT_VIGENCIA
                           AND VPR.CD_TAB_FAT = T.CD_TAB_FAT) CD_TAB_FAT
                  FROM PRODUTO PR,
                       PRO_FAT P,
                       (SELECT VP.CD_PRO_FAT,
                               MAX(VP.DT_VIGENCIA) DT_VIGENCIA
                          FROM VAL_PRO VP
                         GROUP BY VP.CD_PRO_FAT) V
                 WHERE PR.CD_PRO_FAT = P.CD_PRO_FAT
                   AND P.CD_PRO_FAT = V.CD_PRO_FAT
                   AND PR.CD_PRODUTO = P.CD_PRODUTO) CD_TAB_FAT,
               OM.AUTORIZADO,
               OM.CODMATERIAL,
               P.CD_PRODUTO,
               OM.DESCRICAO,
               OM.CODFORNECEDOR,
               OM.NOFORNECEDOR,
               OM.QUANTIDADE,
               OM.VLUNITARIO,
               OM.VLUNITARIO * OM.QUANTIDADE AS VLTOTAL,
               OM.NRANVISA,
               OM.OBSERVACAO,
               OM.CODTNUMM,
               OM.CD_KIT,
               OM.VLUNITARIOSTAXA VLUNITSTAXA,
               OM.VLUNIT15MAIS
          FROM OPME_MATERIAL OM
          LEFT OUTER JOIN DBAMV.PRODUTO P
            ON OM.CODMATERIAL = TO_CHAR(P.CD_PRODUTO)
          LEFT OUTER JOIN DBAMV.FORNECEDOR F
            ON OM.CODFORNECEDOR = F.CD_FORNECEDOR_INTEGRA
         WHERE (OM.AUTORIZADO = 'S' AND OM.NRSOLICITACAO = 116379)) Y ---- Preencher o N�mero da solicita��o;
