CREATE OR REPLACE TRIGGER CUSTOM.TRG_TI_VINCULA_PERMISSOES_TUDO
  BEFORE INSERT OR UPDATE ON DBASGU.PAPEL_USUARIOS
  REFERENCING NEW AS NEW OLD AS OLD
  FOR EACH ROW

  /************************************************************************************************
  * OBJETO: CUSTOM.TRG_TI_VINCULA_PERMISSOES_TUDO                                                 *
  *************************************************************************************************
  * M�DULO: SOUL MV - HOSPITALAR                                                                  *
  * OBJETIVO: LIBERA��O DE USU�RIO PELO PAPEL VINCULADO                                           *
  *************************************************************************************************
  * IMPORTANTE:                                                                                   *
  |-----------------------------------------------------------------------------------------------|
  | DATA      |   SOLICITANTE    |   RESPONS�VEL     |  VERS�O  | ALTERA��O                       |
  |-----------+----------+---------------+---------------+----------------------------------------|
  |04/05/2020 | LARISSA GONZALES | MOIS�S DE SOUZA   |  1.0    | CRIA��O TRIGGER                  |
  |-----------+----------+---------------+---------------+---------------------------------------*/

DECLARE

  --PRESTADOR VINCULADO AO USU�RIO/ SENDO DO TIPO NAIS.

  CURSOR CPRESTADOR IS
    SELECT P.CD_PRESTADOR, T.CD_TIP_PRESTA
      FROM TIP_PRESTA T, PRESTADOR P
     WHERE T.NM_TIP_PRESTA LIKE '%NAIS%'
       AND P.TP_SITUACAO = 'A'
       AND P.CD_TIP_PRESTA = T.CD_TIP_PRESTA
       AND P.CD_PRESTADOR =
           (SELECT U.CD_PRESTADOR
              FROM DBASGU.USUARIOS U
             WHERE U.CD_USUARIO = :NEW.CD_USUARIO);

  --Vari�veis
  V_PRESTADOR CPRESTADOR%ROWTYPE;

BEGIN

  --LIBER�A�O DE TODOS OS SETORES E UNIDADE DE INTERNA��O PARA TODOS OS PAPEIS

  --SETORES

  FOR F IN (SELECT S.CD_SETOR FROM SETOR S WHERE S.SN_ATIVO = 'S')
  
   LOOP
    BEGIN
    
      INSERT INTO DBAMV.USUARIO_UNID_INT
        (CD_UNID_INT, CD_ID_USUARIO, CD_SETOR)
      VALUES
        (NULL, :NEW.CD_USUARIO, F.CD_SETOR);
    
    EXCEPTION
      WHEN DUP_VAL_ON_INDEX THEN
        NULL;
      
    END;
  END LOOP;

  --UNIDADE DE INTERNA��O

  FOR U IN (SELECT U.CD_UNID_INT, U.CD_SETOR
              FROM UNID_INT U
             WHERE U.SN_ATIVO = 'S')
  
   LOOP
    BEGIN
      INSERT INTO DBAMV.USUARIO_UNID_INT
        (CD_UNID_INT, CD_ID_USUARIO, CD_SETOR)
      VALUES
        (U.CD_UNID_INT, :NEW.CD_USUARIO, U.CD_SETOR);
    
    EXCEPTION
      WHEN DUP_VAL_ON_INDEX THEN
        NULL;
      
    END;
  END LOOP;

  --LIBERA��O DE EMPRESA

  OPEN CPRESTADOR; --ABRINDO CURSOR
  FETCH CPRESTADOR
    INTO V_PRESTADOR;

  IF (:NEW.CD_PAPEL) IN (100, 102, 98, 195) THEN
  
    DELETE DBAMV.USUARIO_MULTI_EMPRESA M
     WHERE M.CD_ID_USUARIO = :NEW.CD_USUARIO;
  
    FOR E IN (SELECT E.CD_MULTI_EMPRESA FROM DBAMV.MULTI_EMPRESAS E) LOOP
      BEGIN
      
        INSERT INTO DBAMV.USUARIO_MULTI_EMPRESA
        VALUES
          (E.CD_MULTI_EMPRESA, :NEW.CD_USUARIO);
      EXCEPTION
        WHEN DUP_VAL_ON_INDEX THEN
          NULL;
        
      END;
    END LOOP;
  
  ELSIF (CPRESTADOR%FOUND) THEN
  
    DELETE DBAMV.USUARIO_MULTI_EMPRESA M
     WHERE M.CD_ID_USUARIO = :NEW.CD_USUARIO;
  
    FOR E IN (SELECT E.CD_MULTI_EMPRESA FROM DBAMV.MULTI_EMPRESAS E) LOOP
      BEGIN
      
        INSERT INTO DBAMV.USUARIO_MULTI_EMPRESA
        VALUES
          (E.CD_MULTI_EMPRESA, :NEW.CD_USUARIO);
      EXCEPTION
        WHEN DUP_VAL_ON_INDEX THEN
          NULL;
        
      END;
    END LOOP;
  
    CLOSE CPRESTADOR; --FECHANDO CURSOR
  
  ELSE
    DELETE DBAMV.USUARIO_MULTI_EMPRESA M
     WHERE M.CD_ID_USUARIO = :NEW.CD_USUARIO;
  
    FOR E IN (SELECT E.CD_MULTI_EMPRESA FROM DBAMV.MULTI_EMPRESAS E)
    
     LOOP
      BEGIN
      
        INSERT INTO DBAMV.USUARIO_MULTI_EMPRESA
        VALUES
          (1, :NEW.CD_USUARIO);
      
      EXCEPTION
        WHEN DUP_VAL_ON_INDEX THEN
          NULL;
        
      END;
    END LOOP;
  
  END IF;

  --LIBERA��O CENTRO CIRURGICO
  IF (:NEW.CD_PAPEL) IN (195,
                         184,
                         253,
                         254,
                         122,
                         140,
                         91,
                         106,
                         124,
                         105,
                         83,
                         228,
                         180,
                         128,
                         240,
                         260,
                         98) THEN
  
    DELETE DBAMV.USU_CEN_CIR C WHERE C.NM_USUARIO = :NEW.CD_USUARIO;
  
    FOR C IN (SELECT DISTINCT C.CD_CEN_CIR FROM DBAMV.CEN_CIR C)
    
     LOOP
      BEGIN
      
        INSERT INTO DBAMV.USU_CEN_CIR
          (NM_USUARIO, CD_CEN_CIR)
        
        VALUES
          (:NEW.CD_USUARIO, C.CD_CEN_CIR);
      
      EXCEPTION
        WHEN DUP_VAL_ON_INDEX THEN
          NULL;
        
      END;
    END LOOP;
  
  ELSIF (:NEW.CD_PAPEL) IN (93, 258) THEN
  
    DELETE DBAMV.USU_CEN_CIR C WHERE C.NM_USUARIO = :NEW.CD_USUARIO;
  
    FOR C IN (SELECT DISTINCT C.CD_CEN_CIR
                FROM DBAMV.CEN_CIR C
               WHERE C.CD_CEN_CIR IN (4))
    
     LOOP
      BEGIN
        INSERT INTO DBAMV.USU_CEN_CIR
          (NM_USUARIO, CD_CEN_CIR)
        
        VALUES
          (:NEW.CD_USUARIO, C.CD_CEN_CIR);
      
      EXCEPTION
        WHEN DUP_VAL_ON_INDEX THEN
          NULL;
        
      END;
    END LOOP;
  
  ELSE
    DELETE DBAMV.USU_CEN_CIR C WHERE C.NM_USUARIO = :NEW.CD_USUARIO;
  
  END IF;

  --NOTAS
  IF (:NEW.CD_PAPEL) IN (170) THEN
  
    FOR N IN (SELECT N.CD_FORMULARIO_NF FROM DBAMV.FORMULARIO_NF N)
    
     LOOP
      BEGIN
      
        INSERT INTO DBAMV.USUARIO_CANCELA_NOTA C
          (CD_FORMULARIO_NF, CD_USUARIO)
        
        VALUES
          (N.CD_FORMULARIO_NF, :NEW.CD_USUARIO);
      
      EXCEPTION
        WHEN DUP_VAL_ON_INDEX THEN
          NULL;
        
      END;
    END LOOP;
  
  ELSE
    DELETE DBAMV.USUARIO_CANCELA_NOTA C
     WHERE C.CD_USUARIO = :NEW.CD_USUARIO;
  
  END IF;

  --ENCERRA CHAMADO

  IF (:NEW.CD_PAPEL) IN (137) THEN
  
    FOR E IN (SELECT E.CD_MULTI_EMPRESA FROM DBAMV.USUARIO_ENCERRAMENTO E)
    
     LOOP
      BEGIN
      
        INSERT INTO DBAMV.USUARIO_ENCERRAMENTO E
          (CD_MULTI_EMPRESA, CD_USUARIO)
        
        VALUES
          (E.CD_MULTI_EMPRESA, :NEW.CD_USUARIO);
      
      EXCEPTION
        WHEN DUP_VAL_ON_INDEX THEN
          NULL;
        
      END;
    END LOOP;
  
  ELSE
    DELETE DBAMV.USUARIO_ENCERRAMENTO E
     WHERE E.CD_USUARIO = :NEW.CD_USUARIO;
  
  END IF;

  --LIBERA��O DO SAME

  IF (:NEW.CD_PAPEL) IN (128, 98) THEN
  
    FOR S IN (SELECT S.CD_CAD_SAME FROM DBAMV.CAD_SAME S)
    
     LOOP
      BEGIN
      
        INSERT INTO DBAMV.USUARIO_CAD_SAME C
          (CD_CAD_SAME, CD_USUARIO)
        
        VALUES
          (S.CD_CAD_SAME, :NEW.CD_USUARIO);
      
      EXCEPTION
        WHEN DUP_VAL_ON_INDEX THEN
          NULL;
        
      END;
    END LOOP;
  
  ELSE
    DELETE DBAMV.USUARIO_CAD_SAME CS WHERE CS.CD_USUARIO = :NEW.CD_USUARIO;
  
  END IF;

  --SETORES DE EXAMES DE IMAGEM

  IF (:NEW.CD_PAPEL) IN
     (195, 249, 93, 228, 245, 248, 142, 258, 165, 180, 88, 260, 98) THEN
  
    DELETE DBAMV.PSDI_SET_EXA IMG WHERE IMG.NM_USUARIO = :NEW.CD_USUARIO;
  
    FOR IMG IN (SELECT IMG.CD_SET_EXA
                  FROM DBAMV.SET_EXA IMG
                 WHERE IMG.TP_SETOR = 'R')
    
     LOOP
      BEGIN
      
        INSERT INTO DBAMV.PSDI_SET_EXA IMG
          (CD_SET_EXA, NM_USUARIO)
        
        VALUES
          (IMG.CD_SET_EXA, :NEW.CD_USUARIO);
      
      EXCEPTION
        WHEN DUP_VAL_ON_INDEX THEN
          NULL;
        
      END;
    END LOOP;
  
  ELSIF (:NEW.CD_PAPEL) IN (232) THEN
  
    DELETE DBAMV.PSDI_SET_EXA IMG WHERE IMG.NM_USUARIO = :NEW.CD_USUARIO;
  
    FOR IMG IN (SELECT IMG.CD_SET_EXA
                  FROM DBAMV.SET_EXA IMG
                 WHERE IMG.CD_SET_EXA IN (36, 37, 38, 40, 45, 48))
    
     LOOP
      BEGIN
      
        INSERT INTO DBAMV.PSDI_SET_EXA IMG
          (CD_SET_EXA, NM_USUARIO)
        
        VALUES
          (IMG.CD_SET_EXA, :NEW.CD_USUARIO);
      
      EXCEPTION
        WHEN DUP_VAL_ON_INDEX THEN
          NULL;
        
      END;
    END LOOP;
  
  ELSE
    DELETE DBAMV.PSDI_SET_EXA IMG WHERE IMG.NM_USUARIO = :NEW.CD_USUARIO;
  
  END IF;

  --SETORES DE EXAMES DE LABORAT�RIO

  IF (:NEW.CD_PAPEL) IN
     (195, 249, 228, 142, 256, 162, 164, 251, 161, 165, 207, 98, 232, 100) THEN
  
    DELETE DBAMV.USUARIOS_SET_EXA LAB
     WHERE LAB.NM_USUARIO = :NEW.CD_USUARIO;
  
    FOR LAB IN (SELECT LAB.CD_SET_EXA
                  FROM DBAMV.SET_EXA LAB
                 WHERE LAB.TP_SETOR = 'S')
    
     LOOP
      BEGIN
      
        INSERT INTO DBAMV.USUARIOS_SET_EXA LAB
          (CD_SET_EXA, NM_USUARIO)
        
        VALUES
          (LAB.CD_SET_EXA, :NEW.CD_USUARIO);
      
      EXCEPTION
        WHEN DUP_VAL_ON_INDEX THEN
          NULL;
        
      END;
    END LOOP;
  
  ELSIF (:NEW.CD_PAPEL) IN (253,
                            254,
                            122,
                            202,
                            246,
                            212,
                            140,
                            91,
                            106,
                            124,
                            105,
                            83,
                            93,
                            258,
                            192,
                            180,
                            233,
                            155,
                            260,
                            170,
                            252) THEN
  
    DELETE DBAMV.USUARIOS_SET_EXA LAB
     WHERE LAB.NM_USUARIO = :NEW.CD_USUARIO;
  
    BEGIN
      --INSERINDO REGISTROS APENAS O SETOR 1
      INSERT INTO DBAMV.USUARIOS_SET_EXA LAB
        (CD_SET_EXA, NM_USUARIO)
      
      VALUES
        (1, :NEW.CD_USUARIO);
    
    EXCEPTION
      WHEN DUP_VAL_ON_INDEX THEN
        NULL;
    END;
  
  ELSE
  
    DELETE DBAMV.USUARIOS_SET_EXA LAB
     WHERE LAB.NM_USUARIO = :NEW.CD_USUARIO;
  
  END IF;

  --LIBER�A�O DE ORIGENS

  IF (:NEW.CD_PAPEL) IN (195, 253, 254, 122, 249, 98) THEN
  
    DELETE DBAMV.USU_ORIGEM O WHERE O.CD_USUARIO = :NEW.CD_USUARIO;
  
    FOR ORI IN (SELECT ORI.CD_ORI_ATE
                  FROM ORI_ATE ORI
                 WHERE ORI.SN_ATIVO = 'S')
    
     LOOP
      BEGIN
      
        INSERT INTO DBAMV.USU_ORIGEM
          (CD_ORI_ATE, CD_USUARIO)
        VALUES
          (ORI.CD_ORI_ATE, :NEW.CD_USUARIO);
      
      EXCEPTION
        WHEN DUP_VAL_ON_INDEX THEN
          NULL;
        
      END;
    END LOOP;
  
  ELSIF (:NEW.CD_PAPEL) IN (161, 162) THEN
    --RECEP��O JK
  
    DELETE DBAMV.USU_ORIGEM O WHERE O.CD_USUARIO = :NEW.CD_USUARIO;
  
    FOR ORI IN (SELECT ORI.CD_ORI_ATE
                  FROM ORI_ATE ORI
                 WHERE ORI.CD_ORI_ATE IN (5)
                   AND ORI.SN_ATIVO = 'S')
    
     LOOP
      BEGIN
      
        INSERT INTO DBAMV.USU_ORIGEM
          (CD_ORI_ATE, CD_USUARIO)
        VALUES
          (ORI.CD_ORI_ATE, :NEW.CD_USUARIO);
      
      EXCEPTION
        WHEN DUP_VAL_ON_INDEX THEN
          NULL;
        
      END;
    END LOOP;
  
  ELSIF (:NEW.CD_PAPEL) IN (256) THEN
    --RECEP��O JK
  
    DELETE DBAMV.USU_ORIGEM O WHERE O.CD_USUARIO = :NEW.CD_USUARIO;
  
    FOR ORI IN (SELECT ORI.CD_ORI_ATE
                  FROM ORI_ATE ORI
                 WHERE ORI.CD_ORI_ATE IN (23)
                   AND ORI.SN_ATIVO = 'S')
    
     LOOP
      BEGIN
      
        INSERT INTO DBAMV.USU_ORIGEM
          (CD_ORI_ATE, CD_USUARIO)
        VALUES
          (ORI.CD_ORI_ATE, :NEW.CD_USUARIO);
      
      EXCEPTION
        WHEN DUP_VAL_ON_INDEX THEN
          NULL;
        
      END;
    END LOOP;
  
  ELSIF (:NEW.CD_PAPEL) IN (10) THEN
    -- CETHUS
  
    DELETE DBAMV.USU_ORIGEM O WHERE O.CD_USUARIO = :NEW.CD_USUARIO;
  
    FOR ORI IN (SELECT ORI.CD_ORI_ATE
                  FROM ORI_ATE ORI
                 WHERE ORI.CD_ORI_ATE IN (25)
                   AND ORI.SN_ATIVO = 'S')
    
     LOOP
      BEGIN
      
        INSERT INTO DBAMV.USU_ORIGEM
          (CD_ORI_ATE, CD_USUARIO)
        VALUES
          (ORI.CD_ORI_ATE, :NEW.CD_USUARIO);
      
      EXCEPTION
        WHEN DUP_VAL_ON_INDEX THEN
          NULL;
        
      END;
    END LOOP;
  
  ELSIF (:NEW.CD_PAPEL) IN (232) THEN
    --RECEP��O ZN
  
    DELETE DBAMV.USU_ORIGEM O WHERE O.CD_USUARIO = :NEW.CD_USUARIO;
  
    FOR ORI IN (SELECT ORI.CD_ORI_ATE
                  FROM ORI_ATE ORI
                 WHERE ORI.CD_ORI_ATE IN (4)
                   AND ORI.SN_ATIVO = 'S')
    
     LOOP
      BEGIN
      
        INSERT INTO DBAMV.USU_ORIGEM
          (CD_ORI_ATE, CD_USUARIO)
        VALUES
          (ORI.CD_ORI_ATE, :NEW.CD_USUARIO);
      
      EXCEPTION
        WHEN DUP_VAL_ON_INDEX THEN
          NULL;
        
      END;
    END LOOP;
  
  ELSIF (:NEW.CD_PAPEL) IN (228) THEN
    --RECEP��O HMS
  
    DELETE DBAMV.USU_ORIGEM O WHERE O.CD_USUARIO = :NEW.CD_USUARIO;
  
    FOR ORI IN (SELECT ORI.CD_ORI_ATE
                  FROM ORI_ATE ORI
                 WHERE ORI.CD_ORI_ATE IN (4)
                   AND ORI.SN_ATIVO = 'S')
    
     LOOP
      BEGIN
      
        INSERT INTO DBAMV.USU_ORIGEM
          (CD_ORI_ATE, CD_USUARIO)
        VALUES
          (ORI.CD_ORI_ATE, :NEW.CD_USUARIO);
      
      EXCEPTION
        WHEN DUP_VAL_ON_INDEX THEN
          NULL;
        
      END;
    END LOOP;
  
  ELSIF (:NEW.CD_PAPEL) IN (100, 102) THEN
    --RECEP��O ESPA�O VIVER BEM (NAIS)
  
    DELETE DBAMV.USU_ORIGEM O WHERE O.CD_USUARIO = :NEW.CD_USUARIO;
  
    FOR ORI IN (SELECT T.CD_ORI_ATE
                  FROM ORI_ATE T
                 WHERE T.SN_ATIVO = 'S'
                   AND T.CD_MULTI_EMPRESA = 2)
    
     LOOP
      BEGIN
        INSERT INTO DBAMV.USU_ORIGEM
          (CD_ORI_ATE, CD_USUARIO)
        VALUES
          (ORI.CD_ORI_ATE, :NEW.CD_USUARIO);
      
      EXCEPTION
        WHEN DUP_VAL_ON_INDEX THEN
          NULL;
        
      END;
    END LOOP;
  
  ELSE
    DELETE DBAMV.USU_ORIGEM O WHERE O.CD_USUARIO = :NEW.CD_USUARIO;
  
  END IF;

  --LIBERA��O DE FUN��O DA ENGENHARIA

  IF (:NEW.CD_PAPEL) IN (208, 205, 98) THEN
  
    DELETE DBAMV.USUARIOS_OFICINA_FUNCAO F
     WHERE F.CD_USUARIO = :NEW.CD_USUARIO;
  
    FOR F IN (SELECT F.CD_OFICINA
                FROM DBAMV.OFICINA F
               WHERE F.CD_OFICINA IN (2, 3, 8))
    
     LOOP
      BEGIN
      
        INSERT INTO DBAMV.USUARIOS_OFICINA_FUNCAO
          (CD_USUARIO, CD_OFICINA, TP_FUNCAO)
        VALUES
          (:NEW.CD_USUARIO, F.CD_OFICINA, 'TD');
      
      EXCEPTION
        WHEN DUP_VAL_ON_INDEX THEN
          NULL;
        
      END;
    END LOOP;
  ELSE
  
    DELETE DBAMV.USUARIOS_OFICINA_FUNCAO F
     WHERE F.CD_USUARIO = :NEW.CD_USUARIO;
  
    FOR F IN (SELECT F.CD_OFICINA
                FROM DBAMV.OFICINA F
               WHERE F.CD_OFICINA IN (2, 3, 8))
    
     LOOP
      BEGIN
      
        INSERT INTO DBAMV.USUARIOS_OFICINA_FUNCAO
          (CD_USUARIO, CD_OFICINA, TP_FUNCAO)
        VALUES
          (:NEW.CD_USUARIO, F.CD_OFICINA, 'SS');
      
      EXCEPTION
        WHEN DUP_VAL_ON_INDEX THEN
          NULL;
        
      END;
    END LOOP;
  END IF;

  --SETORES DE EXAMES AGENDAMENTO

  IF (:NEW.CD_PAPEL) IN
     (195, 249, 246, 228, 137, 245, 248, 142, 258, 180, 233, 98, 232) THEN
  
    DELETE DBAMV.USUARIO_SETOR S WHERE S.NM_USUARIO = :NEW.CD_USUARIO;
  
    FOR S IN (SELECT S.CD_SETOR
                FROM DBAMV.SETOR S
               WHERE S.SN_ATIVO = 'S'
                 AND S.TP_GRUPO_SETOR IN ('A', 'E'))
    
     LOOP
      BEGIN
      
        INSERT INTO DBAMV.USUARIO_SETOR
          (CD_SETOR, NM_USUARIO)
        VALUES
          (S.CD_SETOR, :NEW.CD_USUARIO);
      
      EXCEPTION
        WHEN DUP_VAL_ON_INDEX THEN
          NULL;
        
      END;
    END LOOP;
  
  ELSIF (:NEW.CD_PAPEL) IN (10) THEN
  
    DELETE DBAMV.USUARIO_SETOR S WHERE S.NM_USUARIO = :NEW.CD_USUARIO;
  
    FOR S IN (SELECT S.CD_SETOR FROM DBAMV.SETOR S WHERE S.CD_SETOR IN (87)) -- SETORES DO LABORATORIO
    
     LOOP
      BEGIN
      
        INSERT INTO DBAMV.USUARIO_SETOR
          (CD_SETOR, NM_USUARIO)
        VALUES
          (S.CD_SETOR, :NEW.CD_USUARIO);
      
      EXCEPTION
        WHEN DUP_VAL_ON_INDEX THEN
          NULL;
        
      END;
    END LOOP;
  
  ELSE
    DELETE DBAMV.USUARIO_SETOR S WHERE S.NM_USUARIO = :NEW.CD_USUARIO;
  
  END IF;

  --UNIDADES DE ATENDIMENTO

  IF (:NEW.CD_PAPEL) IN
     (195, 249, 246, 228, 137, 245, 248, 142, 258, 180, 233, 98, 232, 10) THEN
  
    DELETE DBAMV.USUARIO_UNID_ATENDIMENTO U
     WHERE U.CD_USUARIO = :NEW.CD_USUARIO;
  
    FOR F IN (SELECT U.CD_UNIDADE_ATENDIMENTO
                FROM UNIDADE_ATENDIMENTO U
               WHERE U.SN_ATIVO = 'S')
    
     LOOP
      BEGIN
      
        INSERT INTO DBAMV.USUARIO_UNID_ATENDIMENTO
          (CD_UNIDADE_ATENDIMENTO, CD_USUARIO)
        VALUES
          (F.CD_UNIDADE_ATENDIMENTO, :NEW.CD_USUARIO);
      
      EXCEPTION
        WHEN DUP_VAL_ON_INDEX THEN
          NULL;
        
      END;
    END LOOP;
  
  ELSE
  
    DELETE DBAMV.USUARIO_UNID_ATENDIMENTO U
     WHERE U.CD_USUARIO = :NEW.CD_USUARIO;
  
  END IF;

  --laborat�rio perfil

  /*IF (:NEW.CD_PAPEL) IN (162,161) THEN
  
    FOR F IN (select u.cd_usuario
                from dbasgu.papel_usuarios u
               where u.cd_papel in (161, 162)) LOOP
    
      BEGIN
      
        INSERT INTO DBAMV.PAPEL_USUARIOS
          (cd_usuario, cd_papel, tp_papel, sn_usuario_master)
        VALUES
          (:NEW.CD_USUARIO, 151, 'L', 'N' );
      
      EXCEPTION
        WHEN DUP_VAL_ON_INDEX THEN
          NULL;
        
      END;
    END LOOP;
 END IF;*/

  ---ESTOQUES     
  FOR L_ESTOQUE IN (SELECT DISTINCT *
                      FROM CUSTOM.CHM_TI_PAPEL_ESTOQUE L
                     WHERE L.CD_PAPEL = :NEW.CD_PAPEL)
  
   LOOP
  
    BEGIN
      INSERT INTO DBAMV.USU_ESTOQUE E
        (CD_ESTOQUE,
         CD_ID_DO_USUARIO,
         SN_AUTORIZA_EXCL_SOLICITACAO,
         SN_AUTORIZA_ALTE_SOLICITACAO,
         TP_USUARIO,
         SN_PERMITE_ALT_ORD_COMPRAS,
         SN_ALT_VL_UNIT_OC,
         VL_PERC_VAR_VL_UNIT,
         SN_TRANS_QUANT_COTA,
         SN_AUTORIZA_ALTE_MOVIMENTACAO,
         SN_AUTORIZA_EXCL_MOVIMENTACAO,
         DT_INTEGRA,
         CD_SEQ_INTEGRA)
      VALUES
        (L_ESTOQUE.CD_ESTOQUE,
         :NEW.CD_USUARIO,
         L_ESTOQUE.SN_AUTORIZA_EXCL_SOLICITACAO,
         L_ESTOQUE.SN_AUTORIZA_ALTE_SOLICITACAO,
         L_ESTOQUE.TP_USUARIO,
         L_ESTOQUE.SN_PERMITE_ALT_ORD_COMPRAS,
         L_ESTOQUE.SN_ALT_VL_UNIT_OC,
         L_ESTOQUE.VL_PERC_VAR_VL_UNIT,
         L_ESTOQUE.SN_TRANS_QUANT_COTA,
         L_ESTOQUE.SN_AUTORIZA_ALTE_MOVIMENTACAO,
         L_ESTOQUE.SN_AUTORIZA_EXCL_MOVIMENTACAO,
         L_ESTOQUE.DT_INTEGRA,
         L_ESTOQUE.CD_SEQ_INTEGRA);
    
    EXCEPTION
      WHEN DUP_VAL_ON_INDEX THEN
        NULL;
    END;
  
  END LOOP;

END;
