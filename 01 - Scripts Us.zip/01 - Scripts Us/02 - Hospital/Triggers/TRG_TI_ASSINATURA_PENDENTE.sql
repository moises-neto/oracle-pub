CREATE OR REPLACE Trigger Trg_Ti_Assinatura_Pendente
  Before Insert On Dbamv.Pw_Documento_Clinico

  Referencing New As New Old As Old
  For Each Row

/************************************************************************************************
* Objeto: Custom.Trg_Ti_Assinatura_Pendente                                                     *
*************************************************************************************************
* Módulo: PEP2                                                                                  *
* Objetivo: Bloqueio Assinaturas Pendentes.                                                     *
*************************************************************************************************
* Importante:                                                                                   *
|-----------------------------------------------------------------------------------------------|
| Data      | Chamado  | Solicitante   | Responsável   | Versão  | Alteração                    |
|-----------+----------+---------------+---------------+----------------------------------------|
|30/03/2017 |          | Edson Cumpian |Suzany Rocha   |  1.0    | Criação Trigger              |
|-----------+----------+---------------+---------------+----------------------------------------|
|07/01/2019 | 176827   | Fabiola       |Gustavo Costa  |  2.0    | Ajustes na Trigger           |
|-----------+----------+---------------+---------------+---------+-----------------------------*/

Declare
  vPendencia     Number := 0;
  vParametro     Varchar2(2);
  vDoc           Number(10);
  vTipoPrestador Number(10);
  vEmpresa       NUmber(10);

  vErroAssPendente Exception;
  --PRAGMA exception_init(vErroAssPendente, -20000);

Begin

  -- ***** ATENÇÃO *****
  -- Trigger em conjunto com outra trigger CUSTOM.Trg_Ti_Assinatura_Pendente_alt e CUSTOM.Trg_Ti_Assinatura_Pendente_doc
  -- Foi necessário pois o registro da pw_editor_clinico é inserido com autonomus transaction, então como esta trigger barra a inclusão
  -- da pw_documento_clinico, ao inserir o registro esses valores não existem mais.   

  -- Verifica se o parametros está ativo
  Select P.Ativo
    Into vParametro
    From Custom.Chm_Parametros P
   Where P.Cd_Parametros = 106;
  
  -- So barra se estiver sendo aberto um destes tipos de documentos
  Select count(1)
    Into vDoc
    From pagu_objeto po
   Where po.cd_objeto = :new.cd_objeto
     And po.tp_objeto in ('DOCELE', 'ALTMED', 'PRESCR');
  
  -- E se for os tipos de prestador abaixo
  Select count(1)
    Into vTipoPrestador
    From prestador pr
   Where pr.cd_prestador = :new.cd_prestador
     And pr.cd_tip_presta in (4, 11, 14, 31, 68, 71, 65, /**/ 5, 6, 10, 1, 32, 9, 36, /**/ 8, 90, 91, 94, 95);
  
  -- Está fazendo o bloqueio apenas para empresa 1 - hospital.
  Select max(a.cd_multi_empresa)
    Into vEmpresa
    From atendime a
   Where a.cd_atendimento = :new.cd_atendimento;

  -- Verifica se tem documentos abertos.
  If vDoc > 0 And vTipoPrestador > 0 And vEmpresa = 1 And vParametro = 'S' Then -- ** ATENCAO ** Para liberar para todos os tipos de prestador, remover a condição "And vTipoPrestador > 0"

      Select Count(*)
        Into vPendencia
        From Pw_Documento_Clinico p
       Where p.Tp_Status = 'FECHADO'
         And p.cd_documento_digital Is Null
         And p.Cd_Prestador In
             (Select u.Cd_Prestador
                From Dbasgu.Usuarios u
               Where u.Cd_Usuario = :New.Cd_Usuario
                 And u.cd_prestador Not In (1093,--Prestador HMS
                                            1165,--Acolhimento
                                            3715 --Plantão Obstetrícia
                                            
                                            
                                                 )                                                                               
                                         
         And p.Dh_Referencia >= sysdate - 30 /*To_Date('15/12/2019', 'dd/mm/yyyy')*/
         And (Sysdate - p.Dh_Referencia) >= 1
         and p.cd_objeto in
             (select o.cd_objeto
                from pagu_objeto o
               where p.cd_objeto = o.cd_objeto
                 and o.sn_assinatura = 'S'
                 /*and tp_objeto in ('DOCELE', 'ALTMED', 'PRESCR'));*/
                 And o.Cd_Tema_Clinico Not In (145, 6, 158, 114)
                 /*And o.tp_objeto Not In ('PRESCR')*/ -- Comentado em 17/02/2020
              ));

      

      If vParametro = 'S' Then
        If vPendencia > 0 Then
          raise vErroAssPendente;
        End If;
      End If;

  End If;

  /*Select Count(*)
   Into vPendencia
   From Pw_Documento_Clinico p, Pagu_Objeto o
  Where p.Tp_Status = 'FECHADO'
    And p.Cd_Prestador In (Select u.Cd_Prestador
                             From Dbasgu.Usuarios u
                            Where u.Cd_Usuario = :New.Cd_Usuario)
    And p.Dh_Referencia >= To_Date('01/01/2018', 'dd/mm/yyyy')
    And (Sysdate - p.Dh_Referencia) >= 1
    And o.Cd_Objeto = p.Cd_Objeto
    And o.Sn_Assinatura = 'S'--And (o.Sn_Assinatura = 'S' Or o.Sn_Assinatura Is Null)
    And o.Cd_Tema_Clinico Not In (145, 86, 85, 143, 144, 81)
    --And p.Cd_Documento_Digital Is Null
    And p.Cd_Prestador Not In (2970, 486, 2045, 286, 622,
                               2774, 2773, 3376, 3531, 2141,
                               1786, 3519, 3148, 1093, 342,
                               954, 765, 918)*/

EXCEPTION
  WHEN vErroAssPendente THEN
      Raise_Application_Error(-20000,
                              'Atenção: Documentos Pendentes há mais de 24 horas. Obrigatório assinatura digital para continuar a utilização do sistema.' ||
                              Chr(10) || Chr(10) ||
                              'Acesse: Lista de Pacientes - Assinaturas Pendentes.' ||
                              Chr(10) || Chr(10));
  WHEN OTHERS THEN
      RAISE_APPLICATION_ERROR(-20001, 'teste');
End;
