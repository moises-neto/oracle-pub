--select A.*, A.ROWID from carteira a 
--where a.nr_carteira in ('0185371000056010');


--reg_fat
select * from dba_source a where a.TEXT like '%52757%'; 
custom.TR_FAT_FECHA_CONTA_AMB
