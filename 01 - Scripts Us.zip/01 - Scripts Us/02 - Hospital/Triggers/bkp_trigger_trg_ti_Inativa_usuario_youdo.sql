CREATE OR REPLACE TRIGGER TRG_TI_INATIVA_USUARIO_YOUDO
  AFTER UPDATE OF SN_ATIVO ON DBASGU.USUARIOS
  REFERENCING NEW AS NEW OLD AS OLD
  FOR EACH ROW

  /************************************************************************************************
  * OBJETO: CUSTOM.TRG_TI_INATIVA_USUARIO_YOUDO                                                    *
  *************************************************************************************************
  * MÓDULO: SOUL MV - HOSPITALAR                                                                  *
  * OBJETIVO: INATIVAR USUARIO DO YOUDO e MV Plano de Sáude, QUANDO O MESMO FOR INATIVO NO SOULMV *
  *************************************************************************************************
  * IMPORTANTE:                                                                                   *
  |-----------------------------------------------------------------------------------------------|
  | DATA      |   SOLICITANTE    |   RESPONSÁVEL     |  VERSÃO  | ALTERAÇÃO                       |
  |-----------+----------+---------------+---------------+----------------------------------------|
  |10/06/2020 | LARISSA GONZALES | FERNANDO FILHO    |  1.0     | CRIAÇÃO TRIGGER                 |
  |-----------+----------+---------------+---------------+----------------------------------------|
  |19/06/2020 | LARISSA GONZALES | MOISÉS DE SOUZA   |  2.0     | ALTERAÇÃO TRIGGER               |
  |-----------+----------+---------------+---------------+---------------------------------------*/
  
BEGIN
  IF :NEW.SN_ATIVO = 'N' then
    
    --INATIVA USUARIO NO YOUDO.
    UPDATE KTSIABD.KT_USUARIO K
    SET K.SN_ATIVO = 'N',
        K.DT_ALTERACAO = sysdate
     WHERE K.ID_USUARIO = :OLD.CD_USUARIO;
     
     --INATIVA USUARIO NO PLANO DE SAÚDE
     UPDATE DBASGU.USUARIOS@ORMVPS U
     SET U.SN_ATIVO = 'N',
         U.DH_ALTERACAO_USUARIO = SYSDATE
     WHERE U.CD_USUARIO = :OLD.CD_USUARIO;

ELSE  
     --ATIVA USUARIO NO NO YOUDO.
     UPDATE KTSIABD.KT_USUARIO K
    SET K.SN_ATIVO = 'S',
        K.DT_ALTERACAO = sysdate
     WHERE K.ID_USUARIO = :OLD.CD_USUARIO;
     
     --ATIVA USUARIO NO PLANO DE SAÚDE
     UPDATE DBASGU.USUARIOS@ORMVPS U
     SET U.SN_ATIVO = 'S',
     U.DH_ALTERACAO_USUARIO = SYSDATE
     WHERE U.CD_USUARIO = :OLD.CD_USUARIO;

   END IF;

   EXCEPTION WHEN NO_DATA_FOUND THEN
     NULL;
   

END;
