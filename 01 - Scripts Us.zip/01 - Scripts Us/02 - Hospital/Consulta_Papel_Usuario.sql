 
custom.trg_ti_assinatura_pendente


SELECT Distinct 
       u.cd_usuario,
       u.nm_usuario, 
       u.ds_observacao,
       pap.cd_papel || ' - ' || pap.ds_papel as DESCRICAO_PAPEL,
       pu.tp_papel

  FROM Dbasgu.Usuarios U, 
       Dbasgu.Papel_Usuarios Pu, 
       Dbasgu.Papel Pap
      -- DBAMV.USUARIOS_SET_EXA se

--       DBASGu.Papel_Mod PM 
 WHERE U.Sn_Ativo = 'S'
 and pap.ds_papel like '%RECEP%'
 --and u.ds_observacao in '2007 - SERVICO SOCIAL COOP'
      -- AND PAP.DS_PAPEL LIKE '%FARMACEUTI%'
   --AND PAP.CD_PAPEL = '248'
   AND Pu.Cd_Usuario = U.Cd_Usuario
   AND Pap.Cd_Papel = Pu.Cd_Papel
  -- and se.nm_usuario = u.cd_usuario
  -- and u.ds_observacao in ('')
  AND PU.CD_PAPEL in ('122','253','254','255')
  -- AND pap.cd_papel in ('249','233','228','256','232','164','207','162','251','161','165')
   and (select distinct se.nm_usuario from DBAMV.USUARIOS_SET_EXA se
where se.cd_set_exa not in 58)
  
   group by u.ds_observacao,
       pap.cd_papel || ' - ' || pap.ds_papel,
       pu.tp_papel



select u.*, rowid from dbasgu.usuarios u where u.cd_usuario = 'DDOMINGUES';
SELECT * FROM ALL_USERS U WHERE U.username = 'DDOMINGUES'


SELECT * FROM DBASGU.PAPEL P
WHERE P.SN_ATIVO = 'S'
AND P.DS_PAPEL NOT LIKE '%PERFIL%'
AND P.CD_PAPEL not in (265, 271, 107, 111, 112, 103)



SELECT PU.*, ROWID FROM DBASGU.PAPEL_USUARIOS PU WHERE PU.CD_USUARIO = 'TESTSUPORTE'

SELECT DISTINCT u.ds_observacao AS OBSERVACAO
                        --  pap.ds_papel    AS PAPEL,
                         -- pap.cd_papel    AS CODIGO_PAPEL,
                         -- PU.TP_PAPEL
                         -- u.cd_usuario
                          
                     FROM Dbasgu.Usuarios       U,
                          Dbasgu.Papel_Usuarios Pu,
                          Dbasgu.Papel          Pap
                  
                      where u.sn_ativo in 'S'
                     
                      and u.ds_observacao NOT IN ('1090 - TESTE', 
                      'USU�RIO DO MVEDITOR, USADO PARA INTEGRA��O', 
                      'USUARIO PARA TESTE - SUPORTE',
                      'USUARIO - INTREGRACAO MV X MICRODATA',
                      'ULTRASSOM',
                      'IMPRESSAO',
                      'ADMINISTRADOR')
                      AND pu.Cd_Usuario = U.Cd_Usuario
                      AND Pap.Cd_Papel = Pu.Cd_Papel
                    ORDER BY U.DS_OBSERVACAO desc;
                    
 
 SELECT U.CD_USUARIO,
        U.NM_USUARIO,
       u.ds_observacao,
    pap.cd_papel || ' - ' || pap.ds_papel as DESCRICAO_PAPEL,
     pu.tp_papel

  FROM Dbasgu.Usuarios U,
    Dbasgu.Papel_Usuarios Pu, 
     Dbasgu.Papel Pap
--DBASGu.Papel_Mod PM 
 WHERE U.Sn_Ativo = 'S'
   --AND PAP.DS_PAPEL LIKE '%FARMACEUTI%'
   --AND PAP.CD_PAPEL = '248'
   AND Pu.Cd_Usuario = U.Cd_Usuario
   AND Pap.Cd_Papel = Pu.Cd_Papel
   AND PU.CD_PAPEL = 170
   --AND pap.ds_papel not like '%PERFIL%'
   --AND PU.CD_PAPEL = 271 
   --AND U.CD_USUARIO IN 'TAGONCALVES'
   AND U.DS_OBSERVACAO IN '180 - MEDICOS (NAIS)'
  --AND PU.TP_PAPEL = 'P'
  --AND PAP.DS_PAPEL IN ('236 - DESENVOLVIMENTO HUMANO')
-------------------------------------------------------- 

SELECT *
  FROM DBASGU.VDIC_CONSULTAR_USUARIO U
      
 WHERE U.CD_USUARIO = 'BRALMEIDA';
--------------------------------------------------------------------------------------------------------------------------------------------------------

SELECT distinct u.cd_usuario AS USUARIO,
       u.nm_usuario AS NM_USUARIO,
       u.ds_observacao AS SETOR,
       pm.cd_modulo AS TELA
FROM   DBASGu.Papel_Mod PM, 
       dbasgu.usuarios u, 
       DBASGU.PAPEL_USUARIOS P
       where u.sn_ativo in 'S'
AND  U.CD_USUARIO = P.CD_USUARIO
AND P.CD_PAPEL = PM.CD_PAPEL
AND P.CD_PAPEL = 170
--and PM.CD_MODULO IN ('M_ITENS_AGENDAMENTO', 'M_ESCALA_CENTRAL')
--AND U.DS_OBSERVACAO NOT LIKE '%TI%'

SELECT pm.cd_modulo FROM DBASGu.Papel_Mod PM WHERE PM.CD_PAPEL = 100
and pm.cd_modulo not in
(SELECT pm.cd_modulo FROM DBASGu.Papel_Mod PM WHERE PM.CD_PAPEL = 102);

SELECT rowid, pm.* FROM DBASGu.Papel_Mod PM WHERE PM.CD_PAPEL in 83

SELECT pm.*, rowid FROM DBASGu.Papel_Mod PM where pm.cd_papel in ('151', '165', '160')
and pm.cd_modulo in ('M_ITENS_AGENDAMENTO', 'M_ESCALA_CENTRAL')

SELECT u.cd_usuario, u.nm_usuario, u.ds_observacao, pm.cd_modulo

  FROM DBASGu.Papel_Mod pm, dbasgu.papel_usuarios pu, dbasgu.usuarios u

 where pm.cd_modulo in ('M_EXALAB')
   and pm.cd_papel = pu.cd_papel
   and pu.cd_usuario = u.cd_usuario
   and u.ds_observacao not like '%TI%'
   and u.sn_ativo = 'S'

SELECT * FROM dbasgu.usuarios u
where u.cd_usuario  = '151'

select * from dbasgu.papel_usuarios pu
where pu.cd_usuario  = 'STANK'

select rowid, u.* from dbasgu.papel_usuarios u where u.cd_usuario = 'LGRILLO'
select u.*, rowid from dbasgu.usuarios u where u.cd_usuario = 'LGRILLO'

--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
     
select * from DBAMV.Prestador p where p.cd_prestador = 1180;
--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

select * from DBAMV.Prestador p where p.cd_prestador = '356';

--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

 --- Consulta Papel x Usu�rios
  Select Pap.Ds_Papel, U.*,U.Rowid
    From Dbasgu.Usuarios U, Dbasgu.Papel_Usuarios Pa, Dbasgu.Papel Pap
   Where U.Sn_Ativo = 'S'
     And Pa.Cd_Usuario = U.Cd_Usuario
     And Pap.Cd_Papel  = Pa.Cd_Papel
     And Pap.Cd_Papel = 170 -- Papel 180 usado na pesquisa 
 --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

 --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
   -- consulta usu�rio x papel
   SELECT U.CD_USUARIO,
          u.nm_usuario,
          U.DS_OBSERVACAO,
          PAP.CD_PAPEL,
          PU.TP_PAPEL
   FROM Dbasgu.Usuarios u, 
       Dbasgu.Papel Pap,
       dbasgu.papel_usuarios pu 
 WHERE pu.cd_papel = pap.cd_papel
 AND pu.cd_usuario = u.cd_usuario 
 and u.nm_usuario like 'AMANDA%'     
 AND pap.cd_papel not in 265
 and pap.cd_papel = 260;
 --AND U.DS_OBSERVACAO LIKE '%1200%';
 -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- 
 --auditoria de usu�rio
 
  SELECT DECODE(a.Tp_Transacao, 'I', 'INSER��O', 'U', 'ALTERA��O', 'EXCLUS�O') Tipo,
       a.Usuario "RESPONS�VEL",
       a.Dt_Transacao DATA,
       c.Coluna Campo,
       NVL(c.Dado_Anterior, '-') "DADO ANTERIOR",
       c.Dado_Atual "DADO ATUAL"
 
  FROM Audit_Tabela a,
       Audit_Coluna c
WHERE a.Cd_Audit_Tabela = c.Cd_Audit_Tabela
   AND a.Cd_Tabela = c.Cd_Tabela
   AND a.Cd_Tabela = 'USUARIOS'
   AND UPPER(c.Chave_Primaria) IN (SELECT U.CD_USUARIO

  FROM Dbasgu.Usuarios U,
    Dbasgu.Papel_Usuarios Pu, 
     Dbasgu.Papel Pap

 WHERE U.Sn_Ativo = 'S'
   
   AND Pu.Cd_Usuario = U.Cd_Usuario
   AND Pap.Cd_Papel = Pu.Cd_Papel
   AND PU.CD_PAPEL = 170  )
ORDER BY a.Cd_Audit_Tabela,
          c.Coluna

 SELECT U.CD_USUARIO

  FROM Dbasgu.Usuarios U,
    Dbasgu.Papel_Usuarios Pu, 
     Dbasgu.Papel Pap

 WHERE U.Sn_Ativo = 'S'
   
   AND Pu.Cd_Usuario = U.Cd_Usuario
   AND Pap.Cd_Papel = Pu.Cd_Papel
   AND PU.CD_PAPEL = 170                   
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
