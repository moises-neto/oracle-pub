select distinct cd_setor, setor
  from (select distinct TO_NUMBER(REGEXP_REPLACE(se.cd_setor, '[^[:digit:]]')) cd_setor,
                        se.nm_setor setor
          from dbasgu.usuarios u, setor se
         where (TO_NUMBER(REGEXP_REPLACE(u.ds_observacao, '[^[:digit:]]')) in (1234, 233,223) -- diretoria
            or u.cd_usuario in ('FERNSILVA','JRABELLO','JMORAD','MSOEIRO','PHUNGARO'))
           and u.sn_ativo = 'S'
           and se.sn_ativo = 'S'
           and u.cd_usuario =  @CODIGOUSUARIO@
        UNION
                select  distinct TO_NUMBER(REGEXP_REPLACE(se.cd_setor, '[^[:digit:]]')) cd_setor,
                        (se.nm_setor) setor
          from dbasgu.usuarios u, setor se
         where u.cd_usuario =  @CODIGOUSUARIO@
           And se.cd_setor in (160,56,52,51,149,54,227,176,146,145,144,203,290,67,53) -- Engenharia
           and (TO_NUMBER(REGEXP_REPLACE(u.ds_observacao, '[^[:digit:]]')) )in (0239, 1115, 1120, 1122, 0160)
           and u.sn_ativo = 'S'
           and se.sn_ativo = 'S'
        UNION
        select distinct l.cd_setor cd_setor,
                        (s.nm_setor) setor  
          from localidade l,
               setor s
         where l.nm_responsavel =  @NOMEUSUARIO@ 
           and l.cd_setor = s.cd_setor
        UNION
        select  se.cd_Setor cd_setor,
                        (se.nm_setor) setor
          from dbasgu.usuarios u, setor se
         where u.cd_usuario =  @CODIGOUSUARIO@ 
           and se.cd_cen_cus = TO_NUMBER(REGEXP_REPLACE(u.ds_observacao, '[^[:digit:]]'))
           and u.sn_ativo = 'S'
           and se.sn_ativo = 'S'
           and se.cd_setor not in (180)
 )
        
        
 order by setor
