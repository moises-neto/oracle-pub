--Consulta de usu�rio no sistema MV2000
SELECT u.cd_usuario,
       u.nm_usuario,
       u.ds_observacao,
       u.cd_prestador,
       u.cpf,
       u.sn_ativo
FROM dbasgu.usuarios u
WHERE u.cd_usuario LIKE '%TESTE%';

--SELECT * FROM DBASGU.LOG_ACESSO_MV2000;

--Consulta de LOG de usu�rios no sistema MV2000
SELECT lam.cd_acesso,
       lam.cd_sistema_origem,
       lam.cd_usuario,
       lam.maquina,
       lam.dt_conexao,
       lam.dt_desconexao
FROM dbasgu.log_acesso_mv2000 lam

WHERE lam.cd_usuario LIKE '%%' --USU�RIO
      AND lam.dt_conexao BETWEEN '04/04/2018' AND SYSDATE --DATA DE CONEXAO
      AND lam.cd_sistema_origem LIKE 'PSSD' --MODULO
      AND lam.maquina LIKE '%%' --M�QUINA
ORDER BY lam.cd_usuario ASC;

--SELECT F.CD_FUNC, F.NM_FUNC, F.SN_ATIVO, F.DT_VIGENCIA, F.CD_SETOR, F.CD_USUARIO
--FROM FUNCIONARIO F;
--WHERE F.NM_FUNC LIKE '%MOISES%';

--SELECT * FROM CUSTOM.RAMAL;





