 SELECT U.CD_PRESTADOR
        FROM DBASGU.USUARIOS U
       WHERE U.CD_USUARIO = 'MEDICO10'
       
       
       SELECT u.cd_usuario
        FROM DBASGU.USUARIOS U
        join prestador p
          on u.cd_prestador = p.cd_prestador
       WHERE U.CD_USUARIO = 'MEDICO10'
         
         and p.cd_tip_presta in (60, 18, 19, 6, 98, 51)
         and p.tp_situacao = 'A';
