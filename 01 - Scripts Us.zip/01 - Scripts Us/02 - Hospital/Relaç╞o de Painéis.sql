Select l.*, rowid  from ti_paineis l
