/*********************CHAMADOS DE T.I*************************|
|-------------------------------------------------------------|
|--------------------STATUS DE CHAMADOS-----------------------|
|-------------------------------------------------------------|
| N� STATUS |    TIPO DE STATUS   |                           |   
|-----------+---------------------|                           |
|     2     |     ESPERA          |                           | 
|     3     |     FECHADO         |                           | 
|     4     |     EXTERNO         |                           | 
|     5     |     CANCELADO       |                           |
|     6     |     PARADO          |                           | 
|     7     |  AGUARDANDO RESPOSTA|                           |
|     10    |     CONCLUIDO       |                           | 
|     12    |     REPROVADO       |                           |
|------------------------------------------------------------*/
----------------------------------------------------------------------------------------------------------------------------------------------
/*****************************************************************************************/ 
SELECT A.CD_ATENDIMENTO AS CHAMADO,
       --A.CD_ATENDIMENTO_PAI AS CHAMADO_PAI,
       U.NM_USUARIO     AS NM_USUARIO_TI,
       SO.NM_USUARIO    AS SOLICITANTE,
       S.NM_SETOR       AS SETOR,
       SER.NM_SERVICO   AS SERVICO,
       E.NM_EVENTO      AS EVENTO,
       A.DS_ATENDIMENTO,
       A.DS_SOLUCAO,
       ST.NM_STATUS    AS NM_STATUS,
       A.DT_ABERTURA   AS DATA_ABERTURA,
       A.DT_CONCLUSAO  AS DATA_CONCLUSAO,
       A.DT_FECHAMENTO AS DATA_FECHAMENTO
  FROM CUSTOM.CHM_ATENDIMENTO A
 INNER JOIN CUSTOM.CHM_SETOR S
    ON A.CD_SETOR = S.CD_SETOR
 INNER JOIN CUSTOM.CHM_SOLICITANTES SO
    ON A.CD_USUARIO = SO.CD_USUARIO
 INNER JOIN CUSTOM.CHM_USUARIOS U
    ON A.CD_USUARIO_TI = U.CD_USUARIO
 INNER JOIN CUSTOM.CHM_CATEGORIZACAO C
    ON a.cd_categorizacao = c.cd_categorizacao
 INNER JOIN custom.chm_servico SER
    ON c.cd_servico = ser.cd_servico
 INNER JOIN CUSTOM.CHM_EVENTO E
    ON c.cd_evento = e.cd_evento
 INNER JOIN CUSTOM.CHM_STATUS ST
    ON A.CD_STATUS = ST.CD_STATUS
    
   -- where a.cd_atendimento = 190580
    --where a.cd_atendimento = 150371
WHERE U.NM_USUARIO LIKE '%YAN%' -- NOME DO ATENDENTE(TI) DO CHAMADO.
--WHERE SO.nm_usuario like 'CAROL%' -- NOME DO SOLICITANTE.
--WHERE SO.CD_LOGIN = 'FCOVOS' -- USU�RIO DO SOLICITANTE.
--AND SER.NM_SERVICO LIKE 'SOUL - SISTEMA HOSPITALAR'
        ---where so.cd_login = 'ABONI'
--where s.nm_setor like '%UNIFICADA%'
--WHERE A.DS_ATENDIMENTO LIKE '%JKUPPER%'
--WHERE A.DS_ATENDIMENTO LIKE '%INFORMA��O%'
--WHERE SO.CD_LOGIN = 'LGONZALES'
--AND SO.NM_USUARIO LIKE '%THAINA%'
AND (A.DS_SOLUCAO LIKE '%INSTALA%'
OR A.DS_ATENDIMENTO LIKE '%INSTALA%'
OR A.DS_SOLUCAO LIKE '%INSTALA%'
OR A.DS_ATENDIMENTO LIKE '%INSTALA%')

--AND SO.CD_LOGIN LIKE '%RUBSILVA%'
--AND S.NM_SETOR LIKE '%ENDOSCOPIA%'
--and ser.nm_servico not in ('ATENDIMENTO - TELEF�NICO')
--and s.nm_setor like '%NATHALIA.PEDRO%'

--WHERE SER.NM_SERVICO like 'ATENDIMENTO - TELEF�NICO'
--AND S.NM_SETOR IN ('RECEPCAO UNIFICADA - HMS',
--AND A.DS_SOLUCAO LIKE '%ALIMA%'                     
--where A.CD_USUARIO = 71
--WHERE A.DS_ATENDIMENTO LIKE '%GCESARIO%' -- DESCRI��O DO SOLICITANTE NO CHAMADO.
--AND a.ds_atendimento like '%KARINA%'
--AND S.NM_SETOR LIKE '%UNIFICADA%' -- NOME DO SETOR DO SOLICITANTE.
--AND ST.NM_STATUS LIKE '%FECHADO%' -- CONSULTA PELO NOME DO STATUS DO CHAMADO.
--AND A.DT_ABERTURA BETWEEN '24/07/2019' AND '24/07/2019' -- CONSULTA PELA DATA INICIAL (DD/MM/AAAA) E DATA FINAL (DD/MM/AAAA). O COMANDO "SYSDATE", SE REFERE A DATA ATUAL.
AND A.DT_ABERTURA BETWEEN '01/06/2020' AND sysdate
--AND A.CD_SETOR IN ('182', '183', '184')
order by a.dt_abertura;

select * from all_users ua where ua.username = 'MICASILVA'

select rowid, a.* from custom.chm_atendimento a where a.cd_atendimento = 205027   


select rowid, a.* from custom.chm_setor a where a.cd_setor = 68



SELECT ROWID, U.* FROM CUSTOM.CHM_USUARIOS U WHERE U.CD_USUARIO = 109;
----------------------------------------------------------------------------------------------------------------------------------------------
/*****************************************************************************************/
 -- CHAMADOS LAN�ADOS SETOR INTERNA��O.
/*****************************************************************************************/ 
SELECT A.CD_ATENDIMENTO AS CHAMADO,
       -- A.CD_ATENDIMENTO_PAI AS CHAMADO_PAI,
       U.NM_USUARIO AS NM_USUARIO_TI,
       --SO.NM_USUARIO    AS SOLICITANTE,
       S.NM_SETOR       AS SETOR,
       SER.NM_SERVICO   AS SERVICO,
       E.NM_EVENTO      AS EVENTO,
       A.DS_ATENDIMENTO,
       A.DS_SOLUCAO,
       --  ST.NM_STATUS     AS NM_STATUS,
       TO_CHAR(A.DT_ABERTURA, 'DD/MM/YYYY') AS DATA_ABERTURA,
       TO_CHAR(A.DT_CONCLUSAO, 'DD/MM/YYYY') AS DATA_CONCLUSAO
      -- SUM(TRUNC((a.dt_conclusao - a.dt_abertura) * 1440)) QTD_MINUTOS
-- SUM(TRUNC(SUM(TRUNC((a.dt_conclusao - a.dt_abertura))) * 1440)) TOTAL
-- SUM(TRUNC(QTD_MINUTOS)) TOTAL_MINUTOS
--   A.DT_FECHAMENTO
  FROM CUSTOM.CHM_ATENDIMENTO   A,
       CUSTOM.CHM_SETOR         S,
       CUSTOM.CHM_USUARIOS      U,
       custom.chm_servico       SER,
       CUSTOM.CHM_CATEGORIZACAO C,
       CUSTOM.CHM_EVENTO        E

 where A.CD_USUARIO_TI = 71
   AND to_date(A.DT_ABERTURA, 'dd/mm/yyyy') BETWEEN '30/10/2019' AND '13/11/2019'
       
   AND A.CD_SETOR IN ('182', '183', '184')
   AND A.CD_SETOR = S.CD_SETOR
   AND A.CD_USUARIO_TI = U.CD_USUARIO
   AND a.cd_categorizacao = c.cd_categorizacao
   AND c.cd_servico = ser.cd_servico
   AND c.cd_evento = e.cd_evento
   and ser.nm_servico not in ('ATENDIMENTO - TELEF�NICO')

AND (A.DS_ATENDIMENTO LIKE '%DR%' 
OR A.DS_ATENDIMENTO LIKE '%MEDICO%'
OR A.DS_SOLUCAO LIKE '%DR%' 
OR A.DS_SOLUCAO LIKE '%MEDICO%')
ORDER BY A.DT_ABERTURA

--and E.NM_EVENTO like '%IMP%'
--order by a.dt_abertura 
--and (a.ds_atendimento like '%IMPRESSORA%' OR a.ds_atendimento like '%IMPRESS�O%')

/*AND a.ds_atendimento not like '%IMPRESSORA%'
AND A.DS_ATENDIMENTO NOT LIKE '%IMPRESS�O%'
AND a.ds_solucao NOT like '%IMPRESSORA%'
AND A.DS_SOLUCAO NOT LIKE '%IMPRESS�O%'*/
/*and (a.ds_atendimento like '%REDE%' 
OR A.DS_ATENDIMENTO LIKE '%WI-FI%' 
OR A.DS_SOLUCAO LIKE '%REDE%' 
OR A.DS_SOLUCAO LIKE '%WI-FI%')*/
--AND E.NM_EVENTO like '%IMPR%'
--AND (A.DS_SOLUCAO LIKE '%SISTEMA%' OR A.DS_ATENDIMENTO LIKE 'SISTEMA')
ORDER BY A.DT_ABERTURA

/*atendimento lan�ados interna��o com tempo de atendimento de cada chamado, e total do atendimento*/
SELECT to_char(A.CD_ATENDIMENTO) AS CHAMADO,
                 U.NM_USUARIO     AS NM_USUARIO_TI,
                 S.NM_SETOR       AS SETOR,
                 SER.NM_SERVICO   AS SERVICO,
                 E.NM_EVENTO      AS EVENTO,
                 A.DS_ATENDIMENTO,
                 A.DS_SOLUCAO,
                 TO_CHAR(A.DT_ABERTURA, 'DD/MM/YYYY') AS DATA_ABERTURA, 
                 TO_CHAR(A.DT_CONCLUSAO, 'DD/MM/YYYY') AS DATA_CONCLUSAO,
                 '' || SUM(TRUNC((a.dt_conclusao - a.dt_abertura) * 1440)) QTD_MINUTOS
  FROM 
         CUSTOM.CHM_ATENDIMENTO A, 
         CUSTOM.CHM_SETOR S,
         CUSTOM.CHM_USUARIOS U,
         custom.chm_servico SER,
         CUSTOM.CHM_CATEGORIZACAO C,
         CUSTOM.CHM_EVENTO E

  where A.CD_USUARIO_TI = 71
  AND to_date(A.DT_ABERTURA, 'dd/mm/yyyy') BETWEEN '30/10/2019' AND '13/11/2019'
  AND A.CD_SETOR IN ('182', '183', '184')
  AND A.CD_SETOR = S.CD_SETOR
  AND A.CD_USUARIO_TI = U.CD_USUARIO
  AND a.cd_categorizacao = c.cd_categorizacao
  AND c.cd_servico = ser.cd_servico
  AND c.cd_evento = e.cd_evento
  and ser.nm_servico not in ('ATENDIMENTO - TELEF�NICO')
  --and E.NM_EVENTO LIKE '%COMPUT%'
 -- and e.nm_evento like '%IMPRESSORA%'
  AND E.NM_EVENTO LIKE '%AUX%'
  --AND A.DS_ATENDIMENTO NOT LIKE '%DR%'
 -- and a.ds_atendimento not like '%DR%'
 /*and (a.ds_atendimento like '%REDE%' 
OR A.DS_ATENDIMENTO LIKE '%WI-FI%' 
OR A.DS_SOLUCAO LIKE '%REDE%' 
OR A.DS_SOLUCAO LIKE '%WI-FI%')*/
GROUP by A.CD_ATENDIMENTO, 
        U.NM_USUARIO, 
        S.NM_SETOR, 
        SER.NM_SERVICO, 
        E.NM_EVENTO,
        A.DS_ATENDIMENTO,
        A.DS_SOLUCAO,
        A.DT_ABERTURA,
        A.DT_CONCLUSAO,
        A.CD_ATENDIMENTO

--------
UNION 
--------

SELECT '',
       '',
       '',
       '',
       '',
       '',
       '',
       '', 
       '',
       'TOTAL: ' || SUM(TRUNC((a.dt_conclusao - a.dt_abertura) * 1440)) QTD_MINUTOS
  FROM 
       CUSTOM.CHM_ATENDIMENTO A, 
       CUSTOM.CHM_SETOR S,
       CUSTOM.CHM_USUARIOS U,
       custom.chm_servico SER,
       CUSTOM.CHM_CATEGORIZACAO C,
       CUSTOM.CHM_EVENTO E

  WHERE A.CD_USUARIO_TI = 71
    AND to_date(A.DT_ABERTURA, 'dd/mm/yyyy') BETWEEN '30/10/2019' AND '13/11/2019'
    AND A.CD_SETOR IN ('182', '183', '184')
    AND A.CD_SETOR = S.CD_SETOR
    AND A.CD_USUARIO_TI = U.CD_USUARIO
    AND a.cd_categorizacao = c.cd_categorizacao
    AND c.cd_servico = ser.cd_servico
    AND c.cd_evento = e.cd_evento
    and ser.nm_servico not in ('ATENDIMENTO - TELEF�NICO')
----------------------------------------------------------------------------------------------------------------------------------------------

select * from CUSTOM.CHM_ATENDIMENTO A
where a.dt_abertura like '25/03/2019'
and a.cd_setor = 9
----------------------------------------------------------------------------------------------------------------------------------------------
SELECT * FROM CUSTOM.CHM_USUARIOS U
WHERE U.NM_USUARIO LIKE '%JEFERSON%'
----------------------------------------------------------------------------------------------------------------------------------------------
select rowid, a.* from custom.chm_atendimento a
where a.dt_abertura like '10/10/2019'
and a.ds_atendimento like '%PAINEL%'
AND A.Cd_Usuario_Ti = 54
----------------------------------------------------------------------------------------------------------------------------------------------
SELECT ROWID, a.* FROM CUSTOM.CHM_ATENDIMENTO A
where a.cd_atendimento = 192917
where a.cd_atendimento IN ('179185', '179187');
----------------------------------------------------------------------------------------------------------------------------------------------
SELECT a.*, C.*, E.*
  FROM CUSTOM.CHM_ATENDIMENTO   A,
       CUSTOM.CHM_CATEGORIZACAO C,
       CUSTOM.CHM_EVENTO        E
       
   -- WHERE E.NM_EVENTO LIKE '%AUXI�LIO%'
    where A.CD_CATEGORIZACAO = C.CD_CATEGORIZACAO
    AND C.CD_EVENTO = E.CD_EVENTO
    and e.nm_evento like '%M�DICO%'
----------------------------------------------------------------------------------------------------------------------------------------------

SELECT ROWID, a.* FROM CUSTOM.CHM_ATENDIMENTO A
where a.cd_atendimento = 389;
----------------------------------------------------------------------------------------------------------------------------------------------

SELECT ROWID, a.* FROM CUSTOM.CHM_ATENDIMENTO A
where a.cd_atendimento = 

----------------------------------------------------------------------------------------------------------------------------------------------
select * from custom.chm_atendimento a
where a.cd_setor = 43
and a.dt_abertura between '01/09/2019' and '07/09/2019'
----------------------------------------------------------------------------------------------------------------------------------------------
select rowid, t.* from custom.chm_hist_tec t where t.cd_atendimento in (201778)

select rowid, a.*
  from custom.chm_atendimento a
 where a.cd_atendimento in(201778,202640,202643,201783,20196,200258,198977,194474,199518,199523,201918)	
---------------------------------------------------------------------------------------------------------------------------------------------

select t.* from custom.chm_hist_tec t where t.cd_status = 5
and t.dt_fim between '20/01/2019' and '25/01/2019' 

select a.* from custom.chm_atendimento a where a.cd_setor = 9
and a.dt_abertura like '10/12/2019'
----------------------------------------------------------------------------------------------------------------------------------------------

select * from custom.log_os
where rownum <= 10

OR A.CD_ATENDIMENTO = 102681
OR A.CD_ATENDIMENTO = 134023;

select tp.*, tp.rowid
from CUSTOM.CHM_TEXTO_PADRAO TP
JOIN CUSTOM.CHM_USUARIOS U 
ON TP.CD_USUARIO = U.CD_USUARIO
where u.cd_login in ('MATCAMARGO')

select US.*, US.ROWID from custom.chm_usuarios us
where us.cd_login in ('MATCAMARGO', 'MNETO')

select * from custom.chm_usu_cc

SELECT a.*,rowid FROM CUSTOM.CHM_ACESSOS A
WHERE A.CD_USUARIO IN ('MATCAMARGO','MNETO')

SELECT * FROM CUSTOM.CHM_ACESSOS A
WHERE A.CD_USUARIO = 'MNETO'

SELECT * FROM CUSTOM.CHM_MODULOS

SELECT * FROM CUSTOM.CHM_MENU


SELECT UM.*, uM.ROWID FROM CUSTOM.CHM_USU_MODULO UM WHERE UM.COD_USUARIO = 109;
SELECT UM.* FROM CUSTOM.CHM_USU_MODULO UM WHERE UM.COD_USUARIO = 71;

INNER JOIN CUSTOM.CHM_MENU M
ON CM.CD_MODULO = M.CD_MODULO
INNER JOIN CUSTOM.CHM_USU_MODULO UM
ON UM.COD_MODULO = CM.CD_MODULO
WHERE UM.COD_USUARIO = 109;


SELECT * FROM CUSTOM.CHM_MODULOS CM
INNER JOIN CUSTOM.CHM_MENU M
ON CM.CD_MODULO = M.CD_MODULO
INNER JOIN CUSTOM.CHM_USU_MODULO UM
ON UM.COD_MODULO = CM.CD_MODULO
WHERE UM.COD_USUARIO = 109;




SELECT * FROM CUSTOM.CHM_SOLICITANTES S
WHERE S.EMAIL = 'ROSINEIDE@UNIMEDSOROCABA.COOP.BR';

select a.cd_atendimento chamado,
       a.nm_equipe,
       a.nm_servico servico,
       a.nm_evento evento,
       to_char(a.dt_abertura, 'dd/mm/yyyy hh24:mi') abertura,
       a.nm_usuario solicitante,
       a.ds_nivel nivel,
       a.tempo
  from custom.chm_vw_analitico a
 where a.nm_status in ('ESPERA', 'PARADO')
   and a.usuario_ti = 'SEM RESPONS�VEL'
   and a.nm_equipe IN
       ('HMS - INFRAESTRUTURA', 'OPERADORA - INFRAESTRUTURA', 'HMS - SISTEMAS')

select count(a.cd_atendimento) as chamados_MOISES
from custom.chm_atendimento a,
     CUSTOM.CHM_USUARIOS U
where U.CD_LOGIN = 'MNETO'
AND a.cd_usuario_ti = U.CD_USUARIO


SELECT * FROM CUSTOM.CHM_VW_TAXA_CHAMADO_ATEND_V2

select * from user_tables ut
where ut.TABLE_NAME like '%%';


---------------------------------------------
SELECT A.CD_ATENDIMENTO AS CHAMADO,
       U.NM_USUARIO AS NM_USUARIO_TI,
       SO.NM_USUARIO AS SOLICITANTE,
       S.NM_SETOR AS SETOR,
       SER.NM_SERVICO AS SERVICO,
       E.NM_EVENTO AS EVENTO,
       A.DS_ATENDIMENTO,
       A.DS_SOLUCAO,
       ST.NM_STATUS AS NM_STATUS,
       A.DT_ABERTURA,
       A.DT_CONCLUSAO,
       A.DT_FECHAMENTO,
       SUM(TRUNC((a.dt_conclusao - a.dt_abertura) * 1440)) QTD_MINUTOS
  FROM CUSTOM.CHM_ATENDIMENTO A
 INNER JOIN CUSTOM.CHM_SETOR S
    ON A.CD_SETOR = S.CD_SETOR
 INNER JOIN CUSTOM.CHM_SOLICITANTES SO
    ON A.CD_USUARIO = SO.CD_USUARIO
 INNER JOIN CUSTOM.CHM_USUARIOS U
    ON A.CD_USUARIO_TI = U.CD_USUARIO
 INNER JOIN CUSTOM.CHM_CATEGORIZACAO C
    ON a.cd_categorizacao = c.cd_categorizacao
 INNER JOIN custom.chm_servico SER
    ON c.cd_servico = ser.cd_servico
 INNER JOIN CUSTOM.CHM_EVENTO E
    ON c.cd_evento = e.cd_evento
 INNER JOIN CUSTOM.CHM_STATUS ST
    ON A.CD_STATUS = ST.CD_STATUS
 INNER JOIN CUSTOM.CHM_USU_EQUIPE CUE
    ON U.CD_USUARIO = CUE.CD_USUARIO
 INNER JOIN CUSTOM.CHM_EQUIPE CE
    ON CUE.CD_EQUIPE = CE.CD_EQUIPE

 WHERE A.DT_ABERTURA BETWEEN '01/01/2019' AND '06/01/2019'
   AND SER.NM_SERVICO = 'ATENDIMENTO - TELEF�NICO'
   AND CE.NM_EQUIPE = 'HMS - SUPORTE'
-- AND CE.NM_EQUIPE = 'HMS - SUPORTE'     
 GROUP BY A.CD_ATENDIMENTO,
          U.NM_USUARIO,
          SO.NM_USUARIO,
          S.NM_SETOR,
          SER.NM_SERVICO,
          E.NM_EVENTO,
          A.DS_ATENDIMENTO,
          A.DS_SOLUCAO,
          ST.NM_STATUS,
          A.DT_ABERTURA,
          A.DT_CONCLUSAO,
          A.DT_FECHAMENTO
 order by a.dt_abertura
          
          
          
          
SELECT * FROM   CUSTOM.CHM_EQUIPE;   
SELECT * FROM CUSTOM.CHM_USU_EQUIPE;

SELECT * FROM CUSTOM.CHM_EMPRESA     



select distinct
 x.mes,
 x.nm_equipe,
 x.usuario_ti,
 sum(x.total) atuacoes,
 sum(x.total_cham) chamados,
 (select count(va.cd_atendimento) from custom.chm_vw_analitico va 
 where va.mes_conclusao = x.mes and va.usuario_ti = x.usuario_ti
 and va.cd_status = 3
 and va.sn_plantao = 'N') concluido,
 sum(x.esforco_total) esforco_total,
 round(avg(x.esforco_medio)) esforco_medio
from
(select
 to_char(h.dt_inicio, 'mm/yyyy') mes,
 a.nm_equipe,
 a.usuario_ti,
 count(h.cd_hist_tec) total,
 count(distinct h.cd_atendimento) total_cham,
 sum(trunc((h.dt_fim - h.dt_inicio) * 1440)) esforco_total,
 avg(trunc((h.dt_fim - h.dt_inicio) * 1440)) esforco_medio
 from custom.chm_vw_analitico a,
 custom.chm_hist_tec h,
 custom.chm_equipe e
 where a.cd_atendimento = h.cd_atendimento
 and to_char(h.dt_inicio, 'mm/yyyy') = '05/2019'
 and h.cd_status = 1
 and h.dt_fim is not null
 and a.nm_equipe = e.nm_equipe
 and e.cd_empresa = '1'
 and a.nm_equipe = 'HMS - PACS'
 and a.sn_plantao = 'N'
group by 
 to_char(h.dt_inicio, 'mm/yyyy'),
 a.nm_equipe,
 a.usuario_ti 
union all
select
 to_char(a.dt_abertura, 'mm/yyyy') mes,
 a.nm_equipe,
 a.usuario_ti,	
 count(a.cd_atendimento) total,
 count(a.cd_atendimento) total_cham,
 sum(a.tempo) esforco_total,
 avg(a.tempo) esforco_medio
 from custom.chm_vw_analitico a,
 custom.chm_equipe e
 where to_char(a.dt_abertura, 'mm/yyyy') = '05/2019'
 and a.cd_status = 3
 and a.nm_equipe = e.nm_equipe
 and e.cd_empresa = '1'
 and a.nm_equipe = 'HMS - PACS'
 and a.sn_plantao = 'N'
group by 
 to_char(a.dt_abertura, 'mm/yyyy'),
 a.nm_equipe,
 a.usuario_ti) x
group by x.mes,
 x.nm_equipe,
 x.usuario_ti 
order by x.usuario_ti 




SELECT * FROM custom.chm_equipe

select * from custom.chm_categorizacao cc, custom.chm_servico cse

where rownum < 10

select * from


select SV.NM_SERVICO, SG.NM_SEGMENTO, EV.NM_EVENTO

from CHM_SERVICO SV, CHM_SEGMENTOS SG, CHM_EVENTO EV, CHM_CATEGORIZACAO CT
WHERE SV.SN_ATIVO = 'S'
and sg.cd_segmento = ct.cd_segmento
AND CT.CD_SERVICO = SV.CD_SERVICO
AND CT.CD_EVENTO = EV.CD_EVENTO
AND SG.NM_SEGMENTO LIKE '%AN�LISE%' 

select * from CHM_CATEG_UTILIZADORES t 
where t.cd_categorizacao = 1952
--where t.cd_categorizacao = 1949
 
where T.Cd_Setor in (select s.cd_setor from CHM_SETOR s
where s.cd_empresa not in (1)
and s.sn_ativo = 'S')
--and t.sn_ativo = 'S'

delete custom.CHM_CATEG_UTILIZADORES t
 where t.cd_setor in (select s.cd_setor
                        from CHM_SETOR s
                       where s.cd_empresa not in (1)
                         and s.sn_ativo = 'S')
   and t.sn_ativo = 'S'

select s.*
  from CHM_SETOR s
 where s.cd_empresa not in (1)
   and s.sn_ativo = 'S'

update custom.CHM_CATEG_UTILIZADORES t 
set t.sn_ativo = 'N'
where t.cd_categorizacao = 531

select rowid, a.* from custom.chm_atendimento a
where a.cd_usuario_ti is null
and a.dt_fechamento is null
and a.cd_atendimento_pai is null
order by a.dt_abertura desc

delete custom.chm_atendimento a
where a.cd_usuario_ti is null
and a.dt_fechamento is null
and a.cd_atendimento_pai is null
and a.cd_atendimento not in (205027,205023,204897,204877)


select rowid, a.* from CHM_HIST_ARQ a where a.cd_atendimento in (select a.cd_atendimento from custom.chm_atendimento a
where a.cd_usuario_ti is null
and a.dt_fechamento is null
and a.cd_atendimento_pai is null
and a.cd_atendimento not in (205027,205023,204897,204877))


select rowid, a.* from custom.CHM_HIST_TEC a where a.cd_atendimento in (select a.cd_atendimento from custom.chm_atendimento a
where a.cd_usuario_ti is null
and a.dt_fechamento is null
and a.cd_atendimento_pai is null
and a.cd_atendimento not in (205027,205023,204897,204877))


select rowid, a.* from custom.CHM_LOG_TROCA_CATEGORIZACAO a where a.cd_atendimento in (select a.cd_atendimento from custom.chm_atendimento a
where a.cd_usuario_ti is null
and a.dt_fechamento is null
and a.cd_atendimento_pai is null
and a.cd_atendimento not in (205027,205023,204897,204877))



select rowid, a.* from custom.CHM_TRANS_ATEND a where a.cd_atendimento in (select a.cd_atendimento from custom.chm_atendimento a
where a.cd_usuario_ti is null
and a.dt_fechamento is null
and a.cd_atendimento_pai is null
and a.cd_atendimento not in (205027,205023,204897,204877))



