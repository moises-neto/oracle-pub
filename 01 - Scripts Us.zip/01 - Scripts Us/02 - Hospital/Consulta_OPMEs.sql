  
SELECT oc.* ,oc.ROWID FROM custom.opme_complemento oc
WHERE oc.nrsolicitacao = '177633';

SELECT oc.* ,oc.ROWID FROM custom.opme_complemento oc
WHERE oc.nrsolicitacao = '174737';

SELECT os.* ,os.ROWID FROM custom.opme_status os;

SELECT ot.* ,ot.ROWID FROM custom.opme_tipo_guia ot;

SELECT ore.* ,ore.ROWID FROM custom.opme_reabertura ore;

SELECT omr.* ,omr.ROWID FROM custom.opme_motivo_reab omr;

select O.* ,O.ROWID from custom.opm_solicitacao o
where o.nrsolicitacao = '174737';




