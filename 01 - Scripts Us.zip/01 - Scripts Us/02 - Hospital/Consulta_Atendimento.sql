/*********************ATENDIMENTOS*****************************|
|--------------------------------------------------------------|
| VALOR  |   TIPO DE ATENDIMENTO   |                           |   
|-----------+----------------------|                           |
|    I   |     INTERNACAO          |                           | 
|    U   |     URG�NCIA/EMERG�NCIA |                           | 
|    A   |     AMBUL�TORIAL        |                           | 
|    E   |     EXTERNO             |                           |
|    H   |     HOME CARE           |                           | 
|-------------------------------------------------------------*/

--INTERNACAO
SELECT * FROM DBAMV.ATENDIME A
WHERE A.CD_ATENDIMENTO = '4873855'


AND A.TP_ATENDIMENTO = 'I'; 

--EMERG�NCIA
SELECT * FROM DBAMV.ATENDIME A
WHERE  A.CD_ATENDIMENTO = '4539969'
AND TP_ATENDIMENTO = 'U'; 

--AMBULATORIAL
SELECT * FROM DBAMV.ATENDIME A
WHERE  A.CD_ATENDIMENTO = '4540893'
AND TP_ATENDIMENTO = 'A';

--EXTERNO
SELECT * FROM DBAMV.ATENDIME A
WHERE  A.CD_ATENDIMENTO = 5137707

AND TP_ATENDIMENTO = 'E'; 

--HOME CARE

SELECT * FROM DBAMV.ATENDIME A
WHERE  A.CD_ATENDIMENTO = '4540486'
AND TP_ATENDIMENTO = 'H';

select A.*, A.ROWID from carteira a 
where a.nr_carteira in ('0185708000232006') --CARTEIRINHA
--WHERE a.cd_paciente = '' --PRONTU�RIO
--WHERE A.NM_TITULAR LIKE '%%' --NOME DO PACIENTE


/*SELECT COUNT (A.CD_ATENDIMENTO) AS ATENDIMENTO,
      A.TP_ATENDIMENTO  
FROM  DBAMV.ATENDIME A
WHERE A.DT_ATENDIMENTO BETWEEN '01/05/2018' AND '31/05/2018'
AND A.TP_ATENDIMENTO = 'I'
GROUP BY A.TP_ATENDIMENTO;

SELECT COUNT(A.CD_ATENDIMENTO) AS QTDD_ATENDIMENTO,
       A.CD_CONVENIO
FROM  DBAMV.ATENDIME A
WHERE A.DT_ATENDIMENTO BETWEEN '01/05/2018' AND '31/05/2018'
AND A.TP_ATENDIMENTO = 'I'
GROUP BY A.CD_CONVENIO;*/

/*Select  to_char(dt_logs,'dd/mm/yyy hh24:mi:ss') DataHora,  
           id_usuario, 
           ds_operacao,
           ds_logs,
           ip_maquina, 
           nome_maquina, 
           id_sessao        
  from dbacp.logs
  WHERE To_Char(Trunc(dt_logs), 'dd/mm/yyyy') = To_Char(Trunc(sysdate), 'dd/mm/yyyy') 
order by dt_logs desc

select * from dbacp.logs;*/


