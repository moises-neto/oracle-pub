Select lower(Substr(Rtrim(Dbasgu.Cripto_Descripto(Cd_Senha, 'SMVCRIPTON'), 'KK'),
              Length(Cd_Usuario) + 1, 30)) AS SENHA
  From Dbasgu.Usuarios
 Where (Cd_Usuario) = upper('ACOLADEL') 

 SELECT  Dbasgu.Cripto_Descripto(u.cd_senha, 'SMVCRIPTON')
  FROM Dbasgu.Usuarios U WHERE U.CD_USUARIO ='TESTESUPORTE1'
   
   SELECT  Dbasgu.Cripto_Descripto(u.cd_senha, 'SMVCRIPTON')
  FROM Dbasgu.Usuarios U WHERE U.CD_USUARIO ='MNETO'  
  
 SELECT U.CD_SENHA FROM Dbasgu.Usuarios U WHERE U.CD_USUARIO ='TESTESUPORTE1' for update;
  SELECT U.CD_SENHA FROM Dbasgu.Usuarios@Ormvgh U WHERE U.CD_USUARIO ='TESTESUPORTE1' for update;  
  
  sELECT Dbasgu.Cripto_Descripto('FFILHONAN123456*%', 'SMVCRIPTOS') fROM DUAL;
  
  Select u.cd_senha From dbasgu.usuarios u
  where u.cd_usuario = 'LTOBIAS' 
  
  sELECT Dbasgu.Cripto_Descripto('IKPUS\]RaFILORUK', 'SMVCRIPTON') fROM DUAL; 
  
  sELECT Dbasgu.Cripto_Descripto('nprtvxz|~�����', 'SMVCRIPTON') fROM DUAL;  
  
  
  
  sELECT Dbasgu.Cripto_Descripto('IKPUS\]RaFILORUK', 'SMVCRIPTON') fROM DUAL; 
  
  sELECT Dbasgu.Cripto_Descripto('nprtvxz|~�����', 'SMVCRIPTON') fROM DUAL;    
  

  


