select * from inovapar.iun_laboratorio i where i.atd_senha = '1329237'
