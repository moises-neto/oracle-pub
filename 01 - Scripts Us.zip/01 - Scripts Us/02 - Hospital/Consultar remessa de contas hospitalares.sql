Consultar remessa de contas Hospitalares:
select t.cd_atendimento, t.nr_guia, t.nm_paciente, t.cd_cpf_contratado from tiss_guia t
       where t.cd_atendimento in (
select distinct r.Cd_Atendimento from reg_fat r, itreg_fat i
       where r.cd_remessa =  �NUMERO DA REMESSA�
       and r.cd_reg_fat = i.cd_reg_fat);
