select * from ITSOLSAI_PRO t
where t.cd_solsai_pro = :m_cd_solsai_pro 
