SELECT r.*,
       r.rowid 
FROM custom.ramal r
WHERE R.RAMAL = 3414 
WHERE r.ramal in ('3790', '3636','3628', '3523', '3702')

--WHERE r.setor like '%%'
--WHERE r.funcionario like '%%'


--or r.setor like '%QUALIDADE%'
--OR r.empresa = 'HOSPITAL'
--r.setor LIKE '%DIR%';
--r.ramal like '3020'
--and r.funcionario like '%LAUREN%'



