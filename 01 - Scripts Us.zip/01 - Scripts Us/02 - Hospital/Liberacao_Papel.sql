CALL CUSTOM.PRC_TI_IMP_PERM_PAPEL ('MNETO');

CUSTOM.TRG_TI_VINCULA_PERMISSOES_TUDO
CUSTOM.TRG_TI_VINCULA_PERFIL_LAB
CUSTOM.TRG_TI_ASSINATURA_PENDENTE

dbasgu.papel_usuarios

select * from all_jobs a
where a.WHAT like '%usuario%'



select rowid, u.* from dbasgu.usuarios u where u.cd_usuario = 'TESTE1'
select rowid, u.* from dbasgu.papel_usuarios u where u.cd_usuario = 'TESTE1'

/*****************TABELAS DO MV***********************/
-- AGENDA unidade de atendimento x SETOR
SELECT A.* FROM DBAMV.USUARIO_UNID_ATENDIMENTO A WHERE A.CD_USUARIO = 'MEDICO21';

SELECT S.* FROM DBAMV.Usuario_Setor s WHERE s.nm_usuario = 'MEDICO21';

--UNIDADE INTERNA��O e setor
SELECT A.* FROM DBAMV.USUARIO_UNID_INT A WHERE A.CD_ID_USUARIO = 'MEDICO21';

--estoque
SELECT rowid, ue.* FROM DBAMV.USU_ESTOQUE UE WHERE UE.CD_ID_DO_USUARIO = 'MEDICO21';

-- setor laboratorio
SELECT rowid, s.* from dbamv.usuarios_set_exa s where s.nm_usuario = 'MEDICO21';

-- setor imagem
select rowid, img.* from dbamv.psdi_set_exa img where img.nm_usuario = 'MEDICO21';

--origem
select ROWID, O.* from dbamv.usu_origem o where o.cd_usuario = 'MEDICO22';

--centro cir�rgico
select ROWID, C.* FROM DBAMV.USU_CEN_CIR C WHERE C.NM_USUARIO = 'MEDICO22';
--Empresa
select ROWID, M.* FROM DBAMV.USUARIO_MULTI_EMPRESA M WHERE  M.cd_id_usuario = 'MEDICO22';
--NOTAS

select ROWID, C.* FROM DBAMV.USUARIO_CANCELA_NOTA C WHERE C.CD_USUARIO  = 'MNETO';

--SAME
select ROWID, o.* FROM DBAMV.USUARIO_CAD_SAME O WHERE o.cd_usuario  = 'MEDICO22';

--ENGENHARIA FUN��O X SETOR
select ROWID, f.* FROM DBAMV.USUARIOS_OFICINA_FUNCAO F WHERE f.cd_usuario  = 'MEDICO22';

--ENCERRA CHAMADO
select ROWID, o.* FROM DBAMV.USUARIO_ENCERRAMENTO O WHERE o.cd_usuario  = 'MEDICO20';

/*****************TABELAS DE CUSTOMIZA��O PARA INTEGRA��O DE PAPEL X LIBERACAO***********************/

--unidade interna��o x setor x papel
select rowid, ui.* from custom.chm_ti_papel_setor_unid_int ui where ui.cd_papel = 206;

select rowid, ui.* from custom.chm_ti_papel_setor_unid_int ui where ui.cd_papel = 102;

--estoque x papel
select ROWID, T.* from CUSTOM.CHM_TI_PAPEL_ESTOQUE t where t.cd_papel = 205;
select ROWID, T.* from CUSTOM.CHM_TI_PAPEL_ESTOQUE t where t.cd_papel = 209;

-- centro cirurgico  x papel
select * from custom.chm_ti_papel_cen_cir cc where cc.cd_papel = 102;
select * from custom.chm_ti_papel_cen_cir cc where cc.cd_papel = 100;
-- origem x papel
select rowid, o.* from custom.chm_ti_papel_origem o where o.cd_papel = 102;
select rowid, o.* from custom.chm_ti_papel_origem o where o.cd_papel = 100;

-- setor exame laboratorio x papel
select rowid, e.* from custom.chm_ti_papel_psdi_exame e where e.cd_papel = 100;
Select rowid, e.* from custom.chm_ti_papel_psdi_exame e where e.cd_papel = 228;

-- setor de exames de imagem x papel
select rowid, img.* from custom.chm_ti_papel_exame img where img.cd_papel = 100;
select rowid, img.* from custom.chm_ti_papel_exame img where img.cd_papel = 162;
-- unidade atendimento x papel
select rowid, ua.* from CUSTOM.chm_ti_papel_unid_atendimento ua where ua.cd_papel = 102;
select rowid, ua.* from CUSTOM.chm_ti_papel_unid_atendimento ua where ua.cd_papel = 100;

-- setor de unidade de atendimento x papel
select ROWID, S.* from custom.chm_ti_papel_setor s where s.cd_papel = 102;
select ROWID, S.* from custom.chm_ti_papel_setor s where s.cd_papel = 100;

select distinct ua.cd_papel from CUSTOM.chm_ti_papel_unid_atendimento ua

select distinct s.cd_papel from custom.chm_ti_papel_setor s 

/*
      SELECT pm.cd_modulo FROM DBASGu.Papel_Mod PM WHERE PM.CD_PAPEL = 100
and pm.cd_modulo not in
(SELECT pm.cd_modulo FROM DBASGu.Papel_Mod PM WHERE PM.CD_PAPEL = 102);


SELECT pm.cd_modulo FROM DBASGu.Papel_Mod PM WHERE PM.CD_PAPEL = 102
minus
SELECT pm.cd_modulo FROM DBASGu.Papel_Mod PM WHERE PM.CD_PAPEL = 100;        */   
                 
 --AGENDA SETOR (10, 98, 100, 102, 137, 164, 208, 221, 228, 232, 233, 240, 245, 248, 249, 256, 260)
select distinct S.CD_PAPEL,
us.ds_observacao
  from custom.chm_ti_papel_setor s
 inner join dbasgu.papel_usuarios u
    on s.cd_papel = u.cd_papel
  join dbasgu.usuarios us
    on u.cd_usuario = us.cd_usuario
   
    
    --AGENDA UNIDADE DE ATENDIMENTO (10, 98, 100, 102, 137, 164, 221, 228, 232, 233, 240, 245, 248, 249, 256, 260)
    select distinct ua.CD_PAPEL,
us.ds_observacao
  from CUSTOM.chm_ti_papel_unid_atendimento ua
 inner join dbasgu.papel_usuarios u
    on ua.cd_papel = u.cd_papel
  join dbasgu.usuarios us
    on u.cd_usuario = us.cd_usuario
    
                
                 
                 
                 
                 
                 
                 
                 
                 
                 
                 
                 
                 
                 
                 
                 
