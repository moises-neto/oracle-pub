Select y.Cd_Usuario_portal,
       y.Nm_Usuario,
       y.Ds_Observacao,
       Replace(To_Char(Wm_Concat(y.Ds_Centro_Custo)), ',', ', ') Ds_Centro_Custo
  From (Select *
          From (Select up.Cd_Usuario_Portal,
                       (Select us.Nm_Usuario
                          From Dbasgu.Usuarios us
                         Where us.Cd_Usuario = up.Cd_Usuario_Portal) Nm_Usuario,
                       (Select us.Ds_Observacao
                          From Dbasgu.Usuarios us
                         Where us.Cd_Usuario = up.Cd_Usuario_Portal) Ds_Observacao,
                       cc.Cd_Setor_Mv2000 ||' - '|| cc.Ds_Centro_Custo Ds_Centro_Custo
                  From dbacp.Usuario_Portal@Ormvbi.world up,
                       Centro_Custo@Ormvbi.world cc,
                       Perfil_Setor@Ormvbi.world ps
                 Where up.Id_Usuario_Portal = ps.Id_Usuario_Portal
                   And ps.Cd_Centro_Custo = cc.Cd_Centro_Custo
                   And up.Sn_Ativo = 'S'
                   And up.Cd_Usuario_Portal In (Select us.Cd_Usuario
                                                  From Dbasgu.Usuarios us
                                                 Where us.Cd_Usuario = up.Cd_Usuario_Portal
                                                   And us.Sn_Ativo = 'S'
                                                   And us.Cd_Usuario Not In ('DBASGU','GEINTEGRA','COMPRASWEB','GERENCIADOR','PACS',
                                                                             'PALM','LAUDOWEB','SUPRIMENTOS','FARMACIADAY','RAIOX',
                                                                             'IMUNOQUIMICA','MICROBIOLOGIA','HEMATOLOGIA','ACESSOPRD','INTEGRA',
                                                                             'IMPRESSAO','DBAPS','ACOLHIMENTO','DBAMV','NPACIENTE',
                                                                             'LACTARIO','ASSISTENCIAL','AUTOMATICO','TRIAGEM','TESTE',
                                                                             'MVPADRAO','SCIH','CONTROLADOR', 'NEOH'))
                   And cc.Cd_Setor_Mv2000 In (Select s.Cd_Setor
                                                From Setor s
                                               Where s.Cd_Setor = cc.Cd_Setor_Mv2000
                                                 And s.Sn_Ativo = 'S')) x
         Where Trim(Substr(x.Ds_Observacao, 1, Instr(x.Ds_Observacao, '-') -1)) <> Trim(Substr(x.Ds_Centro_Custo, 1, Instr(x.Ds_Centro_Custo, '-') -1))) y
 Where y.Ds_Centro_Custo <> '253 - COOPERADOS'
 Group By y.Cd_Usuario_portal,
       y.Nm_Usuario,
       y.Ds_Observacao
 Order By 2,4
