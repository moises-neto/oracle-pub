Select P.Dh_Criacao Data,
 Ate.Cd_Atendimento Atendimento,
 Pac.Nm_Paciente Paciente,
 S.Cd_Setor Cod_Setor,
 S.Nm_Setor Setor,
 Upper(Case
 When Length(O.Nm_Objeto) > 0 Then
 '[' || O.Nm_Objeto || '] - ' || T.Ds_Tipo_Documento
 Else T.Ds_Tipo_Documento End) Documento,
 U.Nm_Usuario Usuario,
 p.cd_usuario,
 (
 Case
 When Tip.Cd_Tip_Presta In (1) Then 'ASSISTENTE SOCIAL'
 When Tip.Cd_Tip_Presta In (3) Then 'ODONTOLOGISTA'
 When Tip.Cd_Tip_Presta In (4, 11, 14, 31, 68, 71) Then 'ENFERMAGEM'
 When Tip.Cd_Tip_Presta In (5, 6, 10) Then 'EQUIPE MULTIDISCIPLINAR'
 When Tip.Cd_Tip_Presta In (8) Then 'M�DICO'
 When Tip.Cd_Tip_Presta In (9, 36) Then 'NUTRI��O'
 When Tip.Cd_Tip_Presta In (32) Then 'FARMACEUTICO(A)'
 End) Equipe
 From Pw_Documento_Clinico P,
 Pw_Tipo_Documento T,
 Assinatura_Digital A,
 Pagu_Objeto O,
 Paciente Pac,
 Atendime Ate,
 Setor S,
 Dbasgu.Usuarios U,
 Prestador Pre,
 Tip_Presta Tip,
 (Select M.Cd_Atendimento,
 U.Cd_Setor,
 To_Date(To_Char(Nvl(M.Dt_Mov_Int,Sysdate), 'YYYYMMDD') || ' ' ||To_Char(Nvl(M.Hr_Mov_Int,Sysdate), 'HH24MISS'), 'YYYYMMDDHH24MISS') Movimentacao,
 To_Date(To_Char(Nvl(M.Dt_Lib_Mov,Sysdate), 'YYYYMMDD') || ' ' ||To_Char(Nvl(M.Hr_Lib_Mov,Sysdate), 'HH24MISS'), 'YYYYMMDDHH24MISS') Liberacao
 From Mov_Int M, Leito L, Unid_Int U
 Where M.Tp_Mov In ('I', 'O')
 And L.Cd_Leito = M.Cd_Leito
 And U.Cd_Unid_Int = L.Cd_Unid_Int

 Union All

 Select A.Cd_Atendimento,
 O.Cd_Setor,
 To_Date(To_Char(Nvl(A.Dt_Atendimento,Sysdate), 'YYYYMMDD') || ' ' ||To_Char(Nvl(A.Hr_Atendimento,Sysdate), 'HH24MISS'), 'YYYYMMDDHH24MISS') Movimentacao,
 To_Date(To_Char(Nvl(A.Dt_Alta,Sysdate), 'YYYYMMDD') || ' ' ||To_Char(Nvl(A.Hr_Alta,Sysdate), 'HH24MISS'), 'YYYYMMDDHH24MISS') Liberacao
 From Atendime A, Ori_Ate O
 Where A.Cd_Leito Is Null
 And A.Cd_Ori_Ate = O.Cd_Ori_Ate
 And A.Dt_Atendimento >= '02/01/2017'
 ) M
 Where P.Cd_Tipo_Documento = T.Cd_Tipo_Documento
 And O.Cd_Objeto = P.Cd_Objeto
 And A.Cd_Documento_Digital (+) = P.Cd_Documento_Digital
 And Pac.Cd_Paciente = P.Cd_Paciente
 And Ate.Cd_Atendimento = P.Cd_Atendimento
 And P.Tp_Status = 'FECHADO'
 And ((O.Sn_Assinatura = 'S'
 Or O.Sn_assinatura Is Null)
 Or P.Cd_Objeto Is Null)

 And (P.Cd_Documento_Digital Is Null Or (P.Cd_Documento_Digital Is Not Null And A.Cd_Documento_Digital Is Null))
 And T.Sn_Pendencias_Alertas = 'S'
 And (Trunc(P.Dh_Criacao) >= Trunc(T.Dh_Pendencias_Alertas) Or T.Dh_Pendencias_Alertas Is Null)
 And P.Dh_Referencia >= '02/01/2017'
 And M.Cd_Setor = S.Cd_Setor
 And M.Cd_Atendimento = P.Cd_Atendimento
 And P.Dh_Criacao >= M.Movimentacao
 And P.Dh_Criacao <= M.Liberacao
 And U.Cd_Usuario = P.Cd_Usuario
 --And P.Cd_Usuario = 'ANDRESSILVA' -- colocar o LOGIN do usu�rio que ser� inativo
 And Pre.Cd_Prestador = U.Cd_Prestador
 And Tip.Cd_Tip_Presta = Pre.Cd_Tip_Presta
 And (
 Case
 When Tip.Cd_Tip_Presta In (1) Then 'ASSISTENTE SOCIAL'
 When Tip.Cd_Tip_Presta In (3) Then 'ODONTOLOGISTA'
 When Tip.Cd_Tip_Presta In (4, 11, 14, 31, 68, 71) Then 'ENFERMAGEM'
 When Tip.Cd_Tip_Presta In (5, 6, 10) Then 'EQUIPE MULTIDISCIPLINAR'
 When Tip.Cd_Tip_Presta In (8) Then 'M�DICO'
 When Tip.Cd_Tip_Presta In (9, 36) Then 'NUTRI��O'
 When Tip.Cd_Tip_Presta In (32) Then 'FARMACEUTICO(A)'
 End) 
 In ('ENFERMAGEM','EQUIPE MULTIDISCIPLINAR', 'ASSISTENTE SOCIAL', 'ODONTOLOGISTA', 'M�DICO', 'NUTRI��O', 'FARMACEUTICO (A)');
