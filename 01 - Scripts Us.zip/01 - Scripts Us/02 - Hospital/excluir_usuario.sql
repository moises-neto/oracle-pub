

dbasgu.cnt_lacemv2000_usuario_fk_1
dbasgu.papel_usuarios_usuarios_fk
dbamv.usu_unid_ind_usuarios_fk
dbamv.cnt_atendime_chmd_pnel_usu_fk

select * from dbasgu.usuarios u where u.cd_usuario = 'TESTESUPORTE1' for update;
select * from LOG_ACESSO_MV2000 mv where mv.cd_usuario = 'TESTESUPORTE31' for update;
select * from PAPEL_USUARIOS us where us.cd_usuario = 'TESTESUPORTE1' for update;
select * from USUARIO_UNID_INT ui where ui.cd_id_usuario = 'TESTESUPORTE1' for update;
select * from USUARIO_UNID_ATENDIMENTO ua where ua.cd_usuario = 'TESTESUPORTE1' for update;
select * from PROCESSOS_USUARIOS ua where ua.cd_usuario = 'TESTESUPORTE1' for update;
  
select * from ATENDIME_CHAMADA_PAINEL cp where cp.cd_usuario = 'RAIOX' for update;
  
select * from ATENDIME_CHAMADA_PAINEL cp where cp.cd_atendimento = 4997416
  

204242
dbamv.cnt_usu_uni_at_usuario_1

select * from dbasgu.cnt_usuarios_processos_fk
