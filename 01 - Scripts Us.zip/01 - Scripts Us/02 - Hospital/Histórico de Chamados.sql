Select a.Cd_Atendimento Cod_Atendimento,
       St.Nm_Status      Status,
       Se.Nm_Setor      Nome_Setor,
       s.Cd_Login       Login_Usuario,
       s.Nm_Usuario     Nome_Usuario,
       Ser.Nm_Servico   Servico,
       a.Ds_Atendimento Texto_Abertura,
       a.Dt_Abertura,
       a.Dt_Conclusao,
       a.Dt_Fechamento,
       a.Ds_Solucao
  From Chm_Atendimento   a,
       Chm_Solicitantes  s,
       Chm_Setor         Se,
       Chm_Categorizacao c,
       Chm_Servico       Ser,
       Chm_Status        St
 Where a.Cd_Usuario = s.Cd_Usuario
   And a.Cd_Setor = Se.Cd_Setor
   And a.Cd_Categorizacao = c.Cd_Categorizacao
   And c.Cd_Servico = Ser.Cd_Servico
   And a.Cd_Status = St.Cd_Status
   And s.Cd_Login = 'LUCCSILVA'
