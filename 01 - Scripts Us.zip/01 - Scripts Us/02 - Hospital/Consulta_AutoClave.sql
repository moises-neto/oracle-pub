/*SELECT * FROM  dbamv.esterilizacao E
WHERE E.CD_ESTERILIZADOR = 1;*/

SELECT ROWID,
       cd_esteriliza,
       cd_esterilizador,
       cd_tp_instrumental,
       cd_carga_lote,
       sn_biologico,
       sn_quimico,
       sn_fisico,
       sn_est_completa,
       cd_usuario_inicio,
       dt_inic_esteriliza,
       cd_usuario_fim,
       dt_fim_esteriliza,
       cd_cancelamento    
FROM   DBAMV.Esterilizacao E
WHERE  E.cd_esterilizador = 3
AND E.DT_INIC_ESTERILIZA BETWEEN '17/04/2019' AND SYSDATE
/*--AND EXTRACT (DAY FROM E.DT_INIC_ESTERILIZA ) = 14 --dia
AND EXTRACT (MONTH FROM E.DT_INIC_ESTERILIZA ) = 06 --mes
AND EXTRACT (YEAR FROM E.DT_INIC_ESTERILIZA ) = 2018 --ano*/
ORDER BY E.CD_ESTERILIZA DESC;




