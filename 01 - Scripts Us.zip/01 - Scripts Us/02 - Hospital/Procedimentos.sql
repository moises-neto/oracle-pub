select * from dbaps.tiss_instalacao_tabela_18 p18 Where p18.cd_procedimento =  10101063;
select * from dbaps.tiss_instalacao_tabela_19 p19 Where p19.cd_procedimento =  10101063;
select * from dbaps.tiss_instalacao_tabela_20 p20 Where p20.cd_procedimento =  10101063;

select * from dbaps.tiss_instalacao_tabela_22 p22 where p22.cd_procedimento = 10101063 for update

Select * from dbaps.procedimento p where p.cd_procedimento = 40324796

select * from procedimento p, dbaps.grupo_procedimento gp
where gp.cd_grupo_procedimento = p.cd_grupo_procedimento
AND GP.CD_GRUPO_PROCEDIMENTO = 1019
and gp.ds_grupo_procedimento like '%INTERN%'

SELECT * FROM dbaps.grupo_procedimento gp
