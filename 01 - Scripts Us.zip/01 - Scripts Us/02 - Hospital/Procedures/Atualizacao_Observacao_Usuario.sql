Declare
  Cursor cDados is
    Select us.cd_usuario, us.ds_observacao
      From dbasgu.usuarios@ORMVGH us, dbasgu.usuarios u
     Where u.cd_usuario = us.cd_usuario
       and us.ds_observacao in ('2013 - RECEPCAO COOPERATIVA',
                                '2013 - RECEPCAO COOPERATIVA (POSTOS)',
                                '0189 - UNIDADE ZONA NORTE (POSTOS)',
                                '2007 - INTERCAMBIO - COOP',
                                '0289 - NAIS')
       And u.ds_observacao <> us.ds_observacao;

Begin

  For i in cDados Loop
    Update dbasgu.usuarios usu
       set usu.ds_observacao = i.ds_observacao
     Where usu.cd_usuario = i.cd_usuario;
  End loop;

Exception
  When Others Then
    Rollback;
    Raise_Application_Error(-20001, 'Falha: ' || Sqlerrm);
  
End;

--Select * from dbasgu.usuarios usu where usu.cd_usuario = 'MFRASSETO'
