UPDATE DBASGU.USUARIOS U
   SET U.DS_OBSERVACAO =
       (SELECT UP.DS_OBSERVACAO
          FROM DBASGU.USUARIOS@ormvgh UP
          WHERE U.CD_USUARIO = UP.CD_USUARIO
         AND UP.DS_OBSERVACAO <> U.DS_OBSERVACAO
           AND U.CD_USUARIO NOT IN ('DBASGU',
                                    'GEINTEGRA',
                                    'COMPRASWEB',
                                    'GERENCIADOR',
                                    'PACS',
                                    'PALM',
                                    'LAUDOWEB',
                                    'SUPRIMENTOS',
                                    'FARMACIADAY',
                                    'RAIOX',
                                    'IMUNOQUIMICA',
                                    'MICROBIOLOGIA',
                                    'HEMATOLOGIA',
                                    'ACESSOPRD',
                                    'INTEGRA',
                                    'IMPRESSAO',
                                    'DBAPS',
                                    'ACOLHIMENTO',
                                    'DBAMV',
                                    'NPACIENTE',
                                    'LACTARIO',
                                    'ASSISTENCIAL',
                                    'AUTOMATICO',
                                    'TRIAGEM',
                                    'TESTE',
                                    'MVPADRAO',
                                    'SCIH',
                                    'CONTROLADOR',
                                    'NEOH'))
 WHERE U.DS_OBSERVACAO <> (SELECT UP.DS_OBSERVACAO
						   FROM DBASGU.USUARIOS@ormvgh UP
						   WHERE UP.CD_USUARIO = U.CD_USUARIO)
						   
AND U.DS_OBSERVACAO NOT IN
               ('0189 - UNIDADE ZONA NORTE',
                '0189 - UNIDADE ZONA NORTE (POSTOS)',
                '0289 - NAIS',
                '2007 - INTERCAMBIO - COOP',
                '2007 - SERVICO SOCIAL COOP',
                '2003 - CONTAS MEDICAS',
                '2013 - RECEPCAO COOPERATIVA',
                '2013 - RECEPCAO COOPERATIVA (POSTOS)');