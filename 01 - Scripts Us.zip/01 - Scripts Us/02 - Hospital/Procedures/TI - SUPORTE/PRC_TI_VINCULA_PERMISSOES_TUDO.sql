CREATE OR REPLACE PROCEDURE CUSTOM.TRG_TI_VINCULA_PERMISSOES_TUDO(V_USUARIO IN, V_PAPEL IN)

BEGIN

DECLARE

  --PRESTADOR VINCULADO AO USU�RIO/ SENDO DO TIPO NAIS.

  CURSOR CPRESTADOR IS
    SELECT P.CD_PRESTADOR, T.CD_TIP_PRESTA
      FROM TIP_PRESTA T, PRESTADOR P
     WHERE T.NM_TIP_PRESTA LIKE '%NAIS%'
       AND P.TP_SITUACAO = 'A'
       AND P.CD_TIP_PRESTA = T.CD_TIP_PRESTA
       AND P.CD_PRESTADOR =
           (SELECT U.CD_PRESTADOR
              FROM DBASGU.USUARIOS U
             WHERE U.CD_USUARIO = v_usuario);

  --VARI�VEIS
  V_PRESTADOR CPRESTADOR%ROWTYPE;

BEGIN

  --LIBER�A�O DE TODOS OS SETORES E UNIDADE DE INTERNA��O PARA TODOS OS PAPEIS

  --SETORES

  IF (v_papel) NOT IN (265) THEN
    FOR F IN (SELECT S.CD_SETOR FROM SETOR S WHERE S.SN_ATIVO = 'S')

     LOOP
      BEGIN

        INSERT INTO DBAMV.USUARIO_UNID_INT
          (CD_UNID_INT, CD_ID_USUARIO, CD_SETOR)
        VALUES
          (NULL, v_usuario, F.CD_SETOR);

      EXCEPTION
        WHEN DUP_VAL_ON_INDEX THEN
          NULL;

      END;
    END LOOP;
  END IF;

  --UNIDADE DE INTERNA��O
  IF (v_papel) NOT IN (265) THEN
    FOR U IN (SELECT U.CD_UNID_INT, U.CD_SETOR
                FROM UNID_INT U
               WHERE U.SN_ATIVO = 'S')

     LOOP
      BEGIN
        INSERT INTO DBAMV.USUARIO_UNID_INT
          (CD_UNID_INT, CD_ID_USUARIO, CD_SETOR)
        VALUES
          (U.CD_UNID_INT, v_usuario, U.CD_SETOR);

      EXCEPTION
        WHEN DUP_VAL_ON_INDEX THEN
          NULL;

      END;
    END LOOP;
  END IF;

  --LIBERA��O DE EMPRESA

  OPEN CPRESTADOR; --ABRINDO CURSOR
  FETCH CPRESTADOR
    INTO V_PRESTADOR;

  IF (v_papel) IN (100, 98, 195) THEN

    /* DELETE DBAMV.USUARIO_MULTI_EMPRESA M
    WHERE M.CD_ID_USUARIO = v_usuario;*/

    FOR E IN (SELECT E.CD_MULTI_EMPRESA FROM DBAMV.MULTI_EMPRESAS E) LOOP
      BEGIN

        INSERT INTO DBAMV.USUARIO_MULTI_EMPRESA
        VALUES
          (E.CD_MULTI_EMPRESA, v_usuario);
      EXCEPTION
        WHEN DUP_VAL_ON_INDEX THEN
          NULL;

      END;
    END LOOP;

  ELSIF (CPRESTADOR%FOUND) THEN

    /* DELETE DBAMV.USUARIO_MULTI_EMPRESA M
    WHERE M.CD_ID_USUARIO = v_usuario;*/

    FOR E IN (SELECT E.CD_MULTI_EMPRESA FROM DBAMV.MULTI_EMPRESAS E) LOOP
      BEGIN

        INSERT INTO DBAMV.USUARIO_MULTI_EMPRESA
        VALUES
          (E.CD_MULTI_EMPRESA, v_usuario);
      EXCEPTION
        WHEN DUP_VAL_ON_INDEX THEN
          NULL;

      END;
    END LOOP;

    CLOSE CPRESTADOR; --FECHANDO CURSOR

  ELSIF (v_papel) NOT IN (265) THEN
    /* DELETE DBAMV.USUARIO_MULTI_EMPRESA M
    WHERE M.CD_ID_USUARIO = v_usuario;*/

    FOR E IN (SELECT E.CD_MULTI_EMPRESA FROM DBAMV.MULTI_EMPRESAS E)

     LOOP
      BEGIN

        INSERT INTO DBAMV.USUARIO_MULTI_EMPRESA
        VALUES
          (1, v_usuario);

      EXCEPTION
        WHEN DUP_VAL_ON_INDEX THEN
          NULL;

      END;
    END LOOP;

  END IF;

  --LIBERA��O CENTRO CIRURGICO
  IF (v_papel) IN (195,
                         184,
                         253,
                         254,
                         122,
                         140,
                         91,
                         106,
                         124,
                         105,
                         83,
                         228,
                         180,
                         128,
                         240,
                         260,
                         98) THEN

    DELETE DBAMV.USU_CEN_CIR C WHERE C.NM_USUARIO = v_usuario;

    FOR C IN (SELECT DISTINCT C.CD_CEN_CIR FROM DBAMV.CEN_CIR C)

     LOOP
      BEGIN

        INSERT INTO DBAMV.USU_CEN_CIR
          (NM_USUARIO, CD_CEN_CIR)

        VALUES
          (v_usuario, C.CD_CEN_CIR);

      EXCEPTION
        WHEN DUP_VAL_ON_INDEX THEN
          NULL;

      END;
    END LOOP;

  ELSIF (v_papel) IN (93, 258) THEN

    DELETE DBAMV.USU_CEN_CIR C WHERE C.NM_USUARIO = v_usuario;

    FOR C IN (SELECT DISTINCT C.CD_CEN_CIR
                FROM DBAMV.CEN_CIR C
               WHERE C.CD_CEN_CIR IN (4))

     LOOP
      BEGIN
        INSERT INTO DBAMV.USU_CEN_CIR
          (NM_USUARIO, CD_CEN_CIR)

        VALUES
          (v_usuario, C.CD_CEN_CIR);

      EXCEPTION
        WHEN DUP_VAL_ON_INDEX THEN
          NULL;

      END;
    END LOOP;

  ELSE
    DELETE DBAMV.USU_CEN_CIR C WHERE C.NM_USUARIO = v_usuario;

  END IF;

  --NOTAS
  IF (v_papel) IN (170) THEN

    FOR N IN (SELECT N.CD_FORMULARIO_NF FROM DBAMV.FORMULARIO_NF N)

     LOOP
      BEGIN

        INSERT INTO DBAMV.USUARIO_CANCELA_NOTA C
          (CD_FORMULARIO_NF, CD_USUARIO)

        VALUES
          (N.CD_FORMULARIO_NF, v_usuario);

      EXCEPTION
        WHEN DUP_VAL_ON_INDEX THEN
          NULL;

      END;
    END LOOP;

  ELSE
    DELETE DBAMV.USUARIO_CANCELA_NOTA C
     WHERE C.CD_USUARIO = v_usuario;

  END IF;

  --ENCERRA CHAMADO

  IF (v_papel) IN (137) THEN

    FOR E IN (SELECT E.CD_MULTI_EMPRESA FROM DBAMV.USUARIO_ENCERRAMENTO E)

     LOOP
      BEGIN

        INSERT INTO DBAMV.USUARIO_ENCERRAMENTO E
          (CD_MULTI_EMPRESA, CD_USUARIO)

        VALUES
          (E.CD_MULTI_EMPRESA, v_usuario);

      EXCEPTION
        WHEN DUP_VAL_ON_INDEX THEN
          NULL;

      END;
    END LOOP;

  ELSE
    DELETE DBAMV.USUARIO_ENCERRAMENTO E
     WHERE E.CD_USUARIO = v_usuario;

  END IF;

  --LIBERA��O DO SAME

  IF (v_papel) IN (128, 98) THEN

    FOR S IN (SELECT S.CD_CAD_SAME FROM DBAMV.CAD_SAME S)

     LOOP
      BEGIN

        INSERT INTO DBAMV.USUARIO_CAD_SAME C
          (CD_CAD_SAME, CD_USUARIO)

        VALUES
          (S.CD_CAD_SAME, v_usuario);

      EXCEPTION
        WHEN DUP_VAL_ON_INDEX THEN
          NULL;

      END;
    END LOOP;

  ELSE
    DELETE DBAMV.USUARIO_CAD_SAME CS WHERE CS.CD_USUARIO = v_usuario;

  END IF;

  --SETORES DE EXAMES DE IMAGEM

  IF (v_papel) IN (232) THEN

    DELETE DBAMV.PSDI_SET_EXA IMG WHERE IMG.NM_USUARIO = v_usuario;

    FOR IMG IN (SELECT IMG.CD_SET_EXA
                  FROM DBAMV.SET_EXA IMG
                 WHERE IMG.CD_SET_EXA IN (36, 37, 38, 40, 45, 48))

     LOOP
      BEGIN

        INSERT INTO DBAMV.PSDI_SET_EXA IMG
          (CD_SET_EXA, NM_USUARIO)

        VALUES
          (IMG.CD_SET_EXA, v_usuario);

      EXCEPTION
        WHEN DUP_VAL_ON_INDEX THEN
          NULL;

      END;
    END LOOP;

  ELSIF (v_papel) IN
        (195, 249, 93, 228, 245, 248, 142, 258, 165, 180, 88, 260, 98) THEN

    FOR IMG IN (SELECT IMG.CD_SET_EXA
                  FROM DBAMV.SET_EXA IMG
                 WHERE IMG.TP_SETOR = 'R')

     LOOP
      BEGIN

        INSERT INTO DBAMV.PSDI_SET_EXA IMG
          (CD_SET_EXA, NM_USUARIO)

        VALUES
          (IMG.CD_SET_EXA, v_usuario);

      EXCEPTION
        WHEN DUP_VAL_ON_INDEX THEN
          NULL;

      END;
    END LOOP;

  END IF;

  --SETORES DE EXAMES DE LABORAT�RIO

  IF (v_papel) IN (253,
                         254,
                         122,
                         202,
                         246,
                         212,
                         140,
                         91,
                         106,
                         124,
                         105,
                         83,
                         93,
                         258,
                         192,
                         180,
                         233,
                         155,
                         260,
                         170,
                         252) THEN

    DELETE DBAMV.USUARIOS_SET_EXA LAB
     WHERE LAB.NM_USUARIO = v_usuario;

    BEGIN
      --INSERINDO REGISTROS APENAS O SETOR 1 DO LABORAT�RIO.
      INSERT INTO DBAMV.USUARIOS_SET_EXA LAB
        (CD_SET_EXA, NM_USUARIO)

      VALUES
        (1, v_usuario);

      --INSERINDO REGISTROS APENAS O SETOR 14 BANCO DE SANGUE.
      INSERT INTO DBAMV.USUARIOS_SET_EXA LAB
        (CD_SET_EXA, NM_USUARIO)

      VALUES
        (14, v_usuario);

    EXCEPTION
      WHEN DUP_VAL_ON_INDEX THEN
        NULL;

    END;

  ELSIF (v_papel) IN (195,
                            249,
                            228,
                            233,
                            142,
                            256,
                            162,
                            164,
                            251,
                            161,
                            165,
                            207,
                            98,
                            232,
                            100) THEN

    FOR LAB IN (SELECT LAB.CD_SET_EXA
                  FROM DBAMV.SET_EXA LAB
                 WHERE LAB.TP_SETOR IN ('S', 'B'))

     LOOP
      BEGIN

        INSERT INTO DBAMV.USUARIOS_SET_EXA LAB
          (CD_SET_EXA, NM_USUARIO)

        VALUES
          (LAB.CD_SET_EXA, v_usuario);

      EXCEPTION
        WHEN DUP_VAL_ON_INDEX THEN
          NULL;

      END;
    END LOOP;

  END IF;

  --LIBER��O DE ORIGENS

 /* IF(v_papel) NOT IN (100, 102,232,10,256,161,162, 195, 253, 254, 122, 249, 98, 228) THEN
   DELETE DBAMV.USU_ORIGEM O WHERE O.CD_USUARIO = v_usuario;

   END IF;*/
   IF v_papel IN ( 100, 102,232,10,256,161,162, 195, 253, 254, 122, 249, 98, 228) THEN
   DELETE DBAMV.USU_ORIGEM O WHERE O.CD_USUARIO = v_usuario;
   END IF;
   
  IF (v_papel) IN (195, 253, 254, 122, 249, 98, 228) THEN
    --LIBERA TODAS AS ORIGENS PARA ESSES PAPEIS

    FOR ORI IN (SELECT ORI.CD_ORI_ATE
                  FROM ORI_ATE ORI
                 WHERE ORI.SN_ATIVO = 'S')

     LOOP
      BEGIN

        INSERT INTO DBAMV.USU_ORIGEM
          (CD_ORI_ATE, CD_USUARIO)
        VALUES
          (ORI.CD_ORI_ATE, v_usuario);

      EXCEPTION
        WHEN DUP_VAL_ON_INDEX THEN
          NULL;

      END;
    END LOOP;

  ELSIF (v_papel) IN (161, 162) THEN
    --LABORATORIO

    DELETE DBAMV.USU_ORIGEM O WHERE O.CD_USUARIO = v_usuario;

    FOR ORI IN (SELECT ORI.CD_ORI_ATE
                  FROM ORI_ATE ORI
                 WHERE ORI.CD_ORI_ATE IN (5)
                   AND ORI.SN_ATIVO = 'S')

     LOOP
      BEGIN

        INSERT INTO DBAMV.USU_ORIGEM
          (CD_ORI_ATE, CD_USUARIO)
        VALUES
          (ORI.CD_ORI_ATE, v_usuario);

      EXCEPTION
        WHEN DUP_VAL_ON_INDEX THEN
          NULL;

      END;
    END LOOP;

  ELSIF (v_papel) IN (256) THEN
    --RECEP��O JK

    DELETE DBAMV.USU_ORIGEM O WHERE O.CD_USUARIO = v_usuario;

    FOR ORI IN (SELECT ORI.CD_ORI_ATE
                  FROM ORI_ATE ORI
                 WHERE ORI.CD_ORI_ATE IN (23)
                   AND ORI.SN_ATIVO = 'S')

     LOOP
      BEGIN

        INSERT INTO DBAMV.USU_ORIGEM
          (CD_ORI_ATE, CD_USUARIO)
        VALUES
          (ORI.CD_ORI_ATE, v_usuario);

      EXCEPTION
        WHEN DUP_VAL_ON_INDEX THEN
          NULL;

      END;
    END LOOP;

  ELSIF (v_papel) IN (10) THEN
    --CETHUS

    DELETE DBAMV.USU_ORIGEM O WHERE O.CD_USUARIO = v_usuario;

    FOR ORI IN (SELECT ORI.CD_ORI_ATE
                  FROM ORI_ATE ORI
                 WHERE ORI.CD_ORI_ATE IN (25)
                   AND ORI.SN_ATIVO = 'S')

     LOOP
      BEGIN

        INSERT INTO DBAMV.USU_ORIGEM
          (CD_ORI_ATE, CD_USUARIO)
        VALUES
          (ORI.CD_ORI_ATE, v_usuario);

      EXCEPTION
        WHEN DUP_VAL_ON_INDEX THEN
          NULL;

      END;
    END LOOP;

  ELSIF (v_papel) IN (232) THEN
    --RECEP��O ZN

    DELETE DBAMV.USU_ORIGEM O WHERE O.CD_USUARIO = v_usuario;

    FOR ORI IN (SELECT ORI.CD_ORI_ATE
                  FROM ORI_ATE ORI
                 WHERE ORI.CD_ORI_ATE IN (4)
                   AND ORI.SN_ATIVO = 'S')

     LOOP
      BEGIN

        INSERT INTO DBAMV.USU_ORIGEM
          (CD_ORI_ATE, CD_USUARIO)
        VALUES
          (ORI.CD_ORI_ATE, v_usuario);

      EXCEPTION
        WHEN DUP_VAL_ON_INDEX THEN
          NULL;

      END;
    END LOOP;

  ELSIF (v_papel) IN (100, 102) THEN
    --RECEP��O ESPA�O VIVER BEM (NAIS)

    DELETE DBAMV.USU_ORIGEM O WHERE O.CD_USUARIO = v_usuario;

    FOR ORI IN (SELECT T.CD_ORI_ATE
                  FROM ORI_ATE T
                 WHERE T.SN_ATIVO = 'S'
                   AND T.CD_MULTI_EMPRESA = 2)

     LOOP
      BEGIN
        INSERT INTO DBAMV.USU_ORIGEM
          (CD_ORI_ATE, CD_USUARIO)
        VALUES
          (ORI.CD_ORI_ATE, v_usuario);

      EXCEPTION
        WHEN DUP_VAL_ON_INDEX THEN
          NULL;

      END;
    END LOOP;
    
      
  END IF;

  --LIBERA��O DE FUN��O DA ENGENHARIA

 IF (v_papel) NOT IN (205, 206, 208, 209) THEN

    --USU�RO QUE N�O POSSUI PERFIL DA ENGENHARIA.

    FOR F IN (SELECT F.CD_OFICINA
                FROM DBAMV.OFICINA F
               WHERE F.CD_OFICINA IN (2, 3, 8))

     LOOP
      BEGIN

        INSERT INTO DBAMV.USUARIOS_OFICINA_FUNCAO
          (CD_USUARIO, CD_OFICINA, TP_FUNCAO)
        VALUES
          (v_usuario, F.CD_OFICINA, 'SS');

      EXCEPTION
        WHEN DUP_VAL_ON_INDEX THEN
          NULL;

      END;
    END LOOP;
  END IF;

  IF (v_papel) IN (206) THEN
    ---ENGENHARIA - CLINICA

    DELETE DBAMV.USUARIOS_OFICINA_FUNCAO F
     WHERE F.CD_USUARIO = v_usuario;

    FOR F IN (SELECT F.CD_OFICINA
                FROM DBAMV.OFICINA F
               WHERE F.CD_OFICINA IN (3, 8))

     LOOP
      BEGIN

        INSERT INTO DBAMV.USUARIOS_OFICINA_FUNCAO
          (CD_USUARIO, CD_OFICINA, TP_FUNCAO)
        VALUES
          (v_usuario, F.CD_OFICINA, 'SS');

        INSERT INTO DBAMV.USUARIOS_OFICINA_FUNCAO
          (CD_USUARIO, CD_OFICINA, TP_FUNCAO)
        VALUES
          (v_usuario, 2, 'TD');

      EXCEPTION
        WHEN DUP_VAL_ON_INDEX THEN
          NULL;

      END;
    END LOOP;

  ELSIF (v_papel) IN (205) THEN
    --ENGENHARIA - HMS

    DELETE DBAMV.USUARIOS_OFICINA_FUNCAO F
     WHERE F.CD_USUARIO = v_usuario;
    FOR F IN (SELECT F.CD_OFICINA
                FROM DBAMV.OFICINA F
               WHERE F.CD_OFICINA IN (2, 8))

     LOOP
      BEGIN

        INSERT INTO DBAMV.USUARIOS_OFICINA_FUNCAO
          (CD_USUARIO, CD_OFICINA, TP_FUNCAO)
        VALUES
          (v_usuario, F.CD_OFICINA, 'SS');

        INSERT INTO DBAMV.USUARIOS_OFICINA_FUNCAO
          (CD_USUARIO, CD_OFICINA, TP_FUNCAO)
        VALUES
          (v_usuario, 3, 'TD');

      EXCEPTION
        WHEN DUP_VAL_ON_INDEX THEN
          NULL;

      END;
    END LOOP;

  ELSIF (v_papel) IN (209) THEN
    --ENGENHARIA OBRAS E REFORMAS

    DELETE DBAMV.USUARIOS_OFICINA_FUNCAO F
     WHERE F.CD_USUARIO = v_usuario;
    FOR F IN (SELECT F.CD_OFICINA
                FROM DBAMV.OFICINA F
               WHERE F.CD_OFICINA IN (2, 3))

     LOOP
      BEGIN

        INSERT INTO DBAMV.USUARIOS_OFICINA_FUNCAO
          (CD_USUARIO, CD_OFICINA, TP_FUNCAO)
        VALUES
          (v_usuario, F.CD_OFICINA, 'SS');

        INSERT INTO DBAMV.USUARIOS_OFICINA_FUNCAO
          (CD_USUARIO, CD_OFICINA, TP_FUNCAO)
        VALUES
          (v_usuario, 8, 'TD');

      EXCEPTION
        WHEN DUP_VAL_ON_INDEX THEN
          NULL;

      END;
    END LOOP;

  ELSIF (v_papel) IN (208) THEN
    --ENGENHARIA - ADMINISTRATIVO

    DELETE DBAMV.USUARIOS_OFICINA_FUNCAO F
     WHERE F.CD_USUARIO = v_usuario;
    FOR F IN (SELECT F.CD_OFICINA
                FROM DBAMV.OFICINA F
               WHERE F.CD_OFICINA IN (2, 3, 8))

     LOOP
      BEGIN

        INSERT INTO DBAMV.USUARIOS_OFICINA_FUNCAO
          (CD_USUARIO, CD_OFICINA, TP_FUNCAO)
        VALUES
          (v_usuario, F.CD_OFICINA, 'TD');

      EXCEPTION
        WHEN DUP_VAL_ON_INDEX THEN
          NULL;

      END;
    END LOOP;

  END IF;

  --SETORES DE EXAMES AGENDAMENTO

  IF (v_papel) IN
     (260, 195, 249, 246, 228, 137, 245, 248, 142, 258, 180, 233, 98, 232) THEN

    DELETE DBAMV.USUARIO_SETOR S WHERE S.NM_USUARIO = v_usuario;

    FOR S IN (SELECT S.CD_SETOR
                FROM DBAMV.SETOR S
               WHERE S.SN_ATIVO = 'S'
                 AND S.TP_GRUPO_SETOR IN ('A', 'E'))

     LOOP
      BEGIN

        INSERT INTO DBAMV.USUARIO_SETOR
          (CD_SETOR, NM_USUARIO)
        VALUES
          (S.CD_SETOR, v_usuario);

      EXCEPTION
        WHEN DUP_VAL_ON_INDEX THEN
          NULL;

      END;
    END LOOP;
    
   ELSIF (v_papel) IN (100) THEN

    DELETE DBAMV.USUARIO_SETOR S WHERE S.NM_USUARIO = v_usuario;

    FOR S IN (SELECT S.CD_SETOR
                FROM DBAMV.SETOR S
               WHERE S.SN_ATIVO = 'S'
               AND S.CD_MULTI_EMPRESA = 2)

     LOOP
      BEGIN

        INSERT INTO DBAMV.USUARIO_SETOR
          (CD_SETOR, NM_USUARIO)
        VALUES
          (S.CD_SETOR, v_usuario);

      EXCEPTION
        WHEN DUP_VAL_ON_INDEX THEN
          NULL;

      END;
    END LOOP; 

  ELSIF (v_papel) IN (10) THEN

    DELETE DBAMV.USUARIO_SETOR S WHERE S.NM_USUARIO = v_usuario;

    FOR S IN (SELECT S.CD_SETOR FROM DBAMV.SETOR S WHERE S.CD_SETOR IN (87)) -- SETORES DO LABORATORIO

     LOOP
      BEGIN

        INSERT INTO DBAMV.USUARIO_SETOR
          (CD_SETOR, NM_USUARIO)
        VALUES
          (S.CD_SETOR, v_usuario);

      EXCEPTION
        WHEN DUP_VAL_ON_INDEX THEN
          NULL;

      END;
    END LOOP;

  ELSIF (v_papel) NOT IN (260,
                                195,
                                249,
                                246,
                                228,
                                137,
                                245,
                                248,
                                142,
                                258,
                                180,
                                233,
                                98,
                                232) THEN

    DELETE DBAMV.USUARIO_SETOR S WHERE S.NM_USUARIO = v_usuario;

  END IF;

  --UNIDADES DE ATENDIMENTO

  IF (v_papel) IN (260,
                         195,
                         249,
                         246,
                         228,
                         137,
                         245,
                         248,
                         142,
                         258,
                         180,
                         233,
                         98,
                         232,
                         100,
                         10) THEN

    DELETE DBAMV.USUARIO_UNID_ATENDIMENTO U
     WHERE U.CD_USUARIO = v_usuario;

    FOR F IN (SELECT U.CD_UNIDADE_ATENDIMENTO
                FROM UNIDADE_ATENDIMENTO U
               WHERE U.SN_ATIVO = 'S')

     LOOP
      BEGIN

        INSERT INTO DBAMV.USUARIO_UNID_ATENDIMENTO
          (CD_UNIDADE_ATENDIMENTO, CD_USUARIO)
        VALUES
          (F.CD_UNIDADE_ATENDIMENTO, v_usuario);

      EXCEPTION
        WHEN DUP_VAL_ON_INDEX THEN
          NULL;

      END;
    END LOOP;

  ELSIF (v_papel) NOT IN (260,
                                195,
                                249,
                                246,
                                228,
                                137,
                                245,
                                248,
                                142,
                                258,
                                180,
                                233,
                                98,
                                232,
                                10) THEN

    DELETE DBAMV.USUARIO_UNID_ATENDIMENTO U
     WHERE U.CD_USUARIO = v_usuario;

  END IF;

  ---ESTOQUES
  FOR L_ESTOQUE IN (SELECT DISTINCT *
                      FROM CUSTOM.CHM_TI_PAPEL_ESTOQUE L
                     WHERE L.CD_PAPEL = v_papel)

   LOOP

    BEGIN
      INSERT INTO DBAMV.USU_ESTOQUE E
        (CD_ESTOQUE,
         CD_ID_DO_USUARIO,
         SN_AUTORIZA_EXCL_SOLICITACAO,
         SN_AUTORIZA_ALTE_SOLICITACAO,
         TP_USUARIO,
         SN_PERMITE_ALT_ORD_COMPRAS,
         SN_ALT_VL_UNIT_OC,
         VL_PERC_VAR_VL_UNIT,
         SN_TRANS_QUANT_COTA,
         SN_AUTORIZA_ALTE_MOVIMENTACAO,
         SN_AUTORIZA_EXCL_MOVIMENTACAO,
         DT_INTEGRA,
         CD_SEQ_INTEGRA)
      VALUES
        (L_ESTOQUE.CD_ESTOQUE,
         v_usuario,
         L_ESTOQUE.SN_AUTORIZA_EXCL_SOLICITACAO,
         L_ESTOQUE.SN_AUTORIZA_ALTE_SOLICITACAO,
         L_ESTOQUE.TP_USUARIO,
         L_ESTOQUE.SN_PERMITE_ALT_ORD_COMPRAS,
         L_ESTOQUE.SN_ALT_VL_UNIT_OC,
         L_ESTOQUE.VL_PERC_VAR_VL_UNIT,
         L_ESTOQUE.SN_TRANS_QUANT_COTA,
         L_ESTOQUE.SN_AUTORIZA_ALTE_MOVIMENTACAO,
         L_ESTOQUE.SN_AUTORIZA_EXCL_MOVIMENTACAO,
         L_ESTOQUE.DT_INTEGRA,
         L_ESTOQUE.CD_SEQ_INTEGRA);

    EXCEPTION
      WHEN DUP_VAL_ON_INDEX THEN
        NULL;
    END;

  END LOOP;

  ---------LIBERA��O DE PERFIL DO LABORAT�RIO

  IF (v_papel) NOT IN
     (162, 161, 100, 164, 249, 228, 232, 256, 192, 207, 98, 246) THEN
    DELETE DBASGU.PAPEL_USUARIOS U
     WHERE U.CD_USUARIO = v_usuario
       AND U.TP_PAPEL IS NULL;

    --DELETANDO ANALISTA CLINICO CASO O PAPEL SEJA DIFERENTE DOS INFORMADOS ACIMA.
    DELETE DBASGU.USUARIO_PRESTADOR_LAB L
     WHERE L.CD_USUARIO = v_usuario;

    --LABORAT�RIO PERFIL 150

  ELSIF (v_papel) IN (249) THEN
    DELETE DBASGU.PAPEL_USUARIOS U
     WHERE U.CD_USUARIO = v_usuario
       AND U.TP_PAPEL IS NULL;

    BEGIN

      INSERT INTO DBASGU.PAPEL_USUARIOS
        (CD_USUARIO, CD_PAPEL, TP_PAPEL, SN_USUARIO_MASTER)
      VALUES
        (v_usuario, 150, '', 'N');

    EXCEPTION
      WHEN DUP_VAL_ON_INDEX THEN
        NULL;

    END;

    --LABORAT�RIO PERFIL 151

  ELSIF (v_papel) IN (162, 161) THEN
    DELETE DBASGU.PAPEL_USUARIOS U
     WHERE U.CD_USUARIO = v_usuario
       AND U.TP_PAPEL IS NULL;

    BEGIN

      INSERT INTO DBASGU.PAPEL_USUARIOS
        (CD_USUARIO, CD_PAPEL, TP_PAPEL, SN_USUARIO_MASTER)
      VALUES
        (v_usuario, 151, '', 'N');

    EXCEPTION

      WHEN DUP_VAL_ON_INDEX THEN
        NULL;

    END;

    BEGIN
      --INSERINDO ANALISTA CLINICO

      FOR F IN (SELECT P.CD_PRESTADOR
                  FROM DBASGU.USUARIOS P
                 WHERE P.CD_USUARIO = v_usuario)

       LOOP
        BEGIN

          INSERT INTO DBASGU.USUARIO_PRESTADOR_LAB
            (CD_USUARIO, CD_PRESTADOR, TP_ATIVIDADE, TP_ACAO)

          VALUES
            (v_usuario, F.CD_PRESTADOR, 'P', 'L');

        EXCEPTION
          WHEN DUP_VAL_ON_INDEX THEN
            NULL;

        END;

      END LOOP;
    END;

    --LABORAT�RIO PERFIL 158

  ELSIF (v_papel) IN (164) THEN
    DELETE DBASGU.PAPEL_USUARIOS U
     WHERE U.CD_USUARIO = v_usuario
       AND U.TP_PAPEL IS NULL;

    BEGIN

      INSERT INTO DBASGU.PAPEL_USUARIOS
        (CD_USUARIO, CD_PAPEL, TP_PAPEL, SN_USUARIO_MASTER)
      VALUES
        (v_usuario, 158, '', 'N');

    EXCEPTION
      WHEN DUP_VAL_ON_INDEX THEN
        NULL;

    END;

    --LABORAT�RIO PERFIL 159

  ELSIF (v_papel) IN (228, 232, 256) THEN
    DELETE DBASGU.PAPEL_USUARIOS U
     WHERE U.CD_USUARIO = v_usuario
       AND U.TP_PAPEL IS NULL;

    BEGIN

      INSERT INTO DBASGU.PAPEL_USUARIOS
        (CD_USUARIO, CD_PAPEL, TP_PAPEL, SN_USUARIO_MASTER)
      VALUES
        (v_usuario, 159, '', 'N');

    EXCEPTION
      WHEN DUP_VAL_ON_INDEX THEN
        NULL;

    END;

    --LABORAT�RIO PERFIL 160

  ELSIF (v_papel) IN (207) THEN
    DELETE DBASGU.PAPEL_USUARIOS U
     WHERE U.CD_USUARIO = v_usuario
       AND U.TP_PAPEL IS NULL;

    BEGIN

      INSERT INTO DBASGU.PAPEL_USUARIOS
        (CD_USUARIO, CD_PAPEL, TP_PAPEL, SN_USUARIO_MASTER)
      VALUES
        (v_usuario, 160, '', 'N');

    EXCEPTION
      WHEN DUP_VAL_ON_INDEX THEN
        NULL;

    END;

    --INSERINDO T�CNICO
    BEGIN
      FOR F IN (SELECT U.CD_PRESTADOR
                  FROM DBASGU.USUARIOS U
                  JOIN PRESTADOR P
                    ON P.CD_PRESTADOR = U.CD_PRESTADOR
                 WHERE U.CD_USUARIO = v_usuario
                   AND P.CD_TIP_PRESTA = 18)

       LOOP
        BEGIN

          INSERT INTO DBASGU.USUARIO_PRESTADOR_LAB
            (CD_USUARIO, CD_PRESTADOR, TP_ATIVIDADE, TP_ACAO)

          VALUES
            (v_usuario, F.CD_PRESTADOR, 'T', 'L');

        EXCEPTION
          WHEN DUP_VAL_ON_INDEX THEN
            NULL;

        END;
      END LOOP;
    END;

    --LABORAT�RIO PERFIL 166

  ELSIF (v_papel) IN (192, 100) THEN
    DELETE DBASGU.PAPEL_USUARIOS U
     WHERE U.CD_USUARIO = v_usuario
       AND U.TP_PAPEL IS NULL;

    BEGIN

      INSERT INTO DBASGU.PAPEL_USUARIOS
        (CD_USUARIO, CD_PAPEL, TP_PAPEL, SN_USUARIO_MASTER)
      VALUES
        (v_usuario, 166, '', 'N');

    EXCEPTION
      WHEN DUP_VAL_ON_INDEX THEN
        NULL;

    END;

    --LABORAT�RIO PERFIL 270

  ELSIF (v_papel) IN (98) THEN
    DELETE DBASGU.PAPEL_USUARIOS U
     WHERE U.CD_USUARIO = v_usuario
       AND U.TP_PAPEL IS NULL;

    BEGIN

      INSERT INTO DBASGU.PAPEL_USUARIOS
        (CD_USUARIO, CD_PAPEL, TP_PAPEL, SN_USUARIO_MASTER)
      VALUES
        (v_usuario, 270, '', 'N');

    EXCEPTION
      WHEN DUP_VAL_ON_INDEX THEN
        NULL;

    END;

    --LABORAT�RIO PERFIL 272
  ELSIF (v_papel) IN (246) THEN
    DELETE DBASGU.PAPEL_USUARIOS U
     WHERE U.CD_USUARIO = v_usuario
       AND U.TP_PAPEL IS NULL;

    BEGIN

      INSERT INTO DBASGU.PAPEL_USUARIOS
        (CD_USUARIO, CD_PAPEL, TP_PAPEL, SN_USUARIO_MASTER)
      VALUES
        (v_usuario, 272, '', 'N');

    EXCEPTION
      WHEN DUP_VAL_ON_INDEX THEN
        NULL;
    END;

    --INSERINDO ANALISTA CLINICO
    BEGIN
      FOR F IN (SELECT U.CD_PRESTADOR
                  FROM DBASGU.USUARIOS U
                  JOIN PRESTADOR P
                    ON P.CD_PRESTADOR = U.CD_PRESTADOR
                 WHERE U.CD_USUARIO = v_usuario
                   AND P.CD_TIP_PRESTA = 6)

       LOOP
        BEGIN

          INSERT INTO DBASGU.USUARIO_PRESTADOR_LAB
            (CD_USUARIO, CD_PRESTADOR, TP_ATIVIDADE, TP_ACAO)

          VALUES
            (v_usuario, F.CD_PRESTADOR, 'P', 'L');

        EXCEPTION
          WHEN DUP_VAL_ON_INDEX THEN
            NULL;

        END;
      END LOOP;
    END;

  END IF;

  --LIBERA��O DE FAVORITOS

  IF (v_papel) IN (228) THEN

    DELETE DBASGU.PROCESSOS_USUARIOS PU
     WHERE PU.CD_USUARIO = v_usuario;

    BEGIN
      FOR F IN (SELECT P.CD_PROCESSO
                  FROM DBASGU.MENU_PROCESSO P
                 WHERE P.CD_PROCESSO IN ('DIAGNOSTICO', 'ATEND_EMERG'))

       LOOP
        BEGIN

          INSERT INTO DBASGU.PROCESSOS_USUARIOS
            (CD_PROCESSO, CD_USUARIO)
          VALUES
            (F.CD_PROCESSO, v_usuario);

        EXCEPTION
          WHEN DUP_VAL_ON_INDEX THEN
            NULL;

        END;
      END LOOP;
    END;

  ELSIF (v_papel) IN (91, 140, 124, 105, 106) THEN

    DELETE DBASGU.PROCESSOS_USUARIOS PU
     WHERE PU.CD_USUARIO = v_usuario;

    BEGIN
      FOR F IN (SELECT P.CD_PROCESSO
                  FROM DBASGU.MENU_PROCESSO P
                 WHERE P.CD_PROCESSO IN ('ATEND_FARMACIA'))

       LOOP
        BEGIN

          INSERT INTO DBASGU.PROCESSOS_USUARIOS
            (CD_PROCESSO, CD_USUARIO)
          VALUES
            (F.CD_PROCESSO, v_usuario);

        EXCEPTION
          WHEN DUP_VAL_ON_INDEX THEN
            NULL;

        END;
      END LOOP;
    END;

  ELSIF (v_papel) IN (208) THEN
    DELETE DBASGU.PROCESSOS_USUARIOS PU
     WHERE PU.CD_USUARIO = v_usuario;

    BEGIN
      FOR F IN (SELECT P.CD_PROCESSO
                  FROM DBASGU.MENU_PROCESSO P
                 WHERE P.CD_PROCESSO IN ('ENGENHARIA'))

       LOOP
        BEGIN

          INSERT INTO DBASGU.PROCESSOS_USUARIOS
            (CD_PROCESSO, CD_USUARIO)
          VALUES
            (F.CD_PROCESSO, v_usuario);

        EXCEPTION
          WHEN DUP_VAL_ON_INDEX THEN
            NULL;

        END;
      END LOOP;
    END;

  ELSIF (v_papel) IN (138) THEN
    DELETE DBASGU.PROCESSOS_USUARIOS PU
     WHERE PU.CD_USUARIO = v_usuario;

    BEGIN
      FOR F IN (SELECT P.CD_PROCESSO
                  FROM DBASGU.MENU_PROCESSO P
                 WHERE P.CD_PROCESSO IN ('APROVACAO_COMPRAS'))

       LOOP
        BEGIN

          INSERT INTO DBASGU.PROCESSOS_USUARIOS
            (CD_PROCESSO, CD_USUARIO)
          VALUES
            (F.CD_PROCESSO, v_usuario);

        EXCEPTION
          WHEN DUP_VAL_ON_INDEX THEN
            NULL;

        END;
      END LOOP;
    END;

  ELSIF (v_papel) IN (240) THEN
    DELETE DBASGU.PROCESSOS_USUARIOS PU
     WHERE PU.CD_USUARIO = v_usuario;

    BEGIN
      FOR F IN (SELECT P.CD_PROCESSO
                  FROM DBASGU.MENU_PROCESSO P
                 WHERE P.CD_PROCESSO IN ('AGENDAMENTO'))

       LOOP
        BEGIN

          INSERT INTO DBASGU.PROCESSOS_USUARIOS
            (CD_PROCESSO, CD_USUARIO)
          VALUES
            (F.CD_PROCESSO, v_usuario);

        EXCEPTION
          WHEN DUP_VAL_ON_INDEX THEN
            NULL;

        END;
      END LOOP;
    END;

  ELSIF (v_papel) IN (98) THEN

    DELETE DBASGU.PROCESSOS_USUARIOS PU
     WHERE PU.CD_USUARIO = v_usuario;

    BEGIN
      FOR F IN (SELECT P.CD_PROCESSO
                  FROM DBASGU.MENU_PROCESSO P
                 WHERE P.CD_PROCESSO IN ('MENU_TI'))

       LOOP
        BEGIN

          INSERT INTO DBASGU.PROCESSOS_USUARIOS
            (CD_PROCESSO, CD_USUARIO)
          VALUES
            (F.CD_PROCESSO, v_usuario);

        EXCEPTION
          WHEN DUP_VAL_ON_INDEX THEN
            NULL;

        END;
      END LOOP;
    END;

  END IF;

END;
COMMIT;
END;
