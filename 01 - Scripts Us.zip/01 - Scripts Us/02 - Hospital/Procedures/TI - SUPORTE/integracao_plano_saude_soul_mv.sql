DECLARE

  Cursor cUsuario is
    Select u.* from dbasgu.usuarios u where u.cd_usuario = '&USUARIO'; 
    
   v_usuario cUsuario%rowtype;
BEGIN
  open cUsuario;
  fetch cUsuario
  into v_usuario;
  IF(cUsuario%notfound) THEN 
      Raise_application_error(-20000,
                            'Usu�rio n�o encontrado na base de dados do Hospital: ' ||
                            sqlerrm);
   end if; 
   close cUsuario;

  FOR c In cUsuario loop
    Begin
    
      insert into Dbasgu.Usuarios@ORMVPS
        (CD_USUARIO,
         NM_USUARIO,
         DS_OBSERVACAO,
         TP_PRIVILEGIO,
         CD_SENHA,
         TP_STATUS,
         SN_ATIVO,
         CPF,
         SN_SENHA_PLOGIN,
         SN_ABRE_FECHA_CONTA,
         SN_RECEBE_MSG_EXPIRA_CHAVE,
         SN_ALTERA_AUDITORIA_IN_LOCO,
         SN_CADASTRA_PACIENTE,
         SN_ALTERA_CADASTRO_PACIENTE,
         CD_IDIOMA,
         SN_AUDITOR_TABELA,
         SN_CRIA_USUARIO,
         SN_PERMITE_DESVINCULO_PACOTE,
         SN_ALTERA_PACIENTE_SEM_CPF,
         SN_ALTERA_OBSERVACAO_GUIA,
         SN_PERMITE_FECHA_CNT_ANATOMIA,
         SN_PERMITE_DUPLICIDADE_CPF)
      
      values
        (c.CD_USUARIO,
         c.NM_USUARIO,
         c.DS_OBSERVACAO,
         c.TP_PRIVILEGIO,
         c.cd_senha,
         c.TP_STATUS,
         'S',
         C.CPF,
         c.SN_SENHA_PLOGIN,
         c.SN_ABRE_FECHA_CONTA,
         c.SN_RECEBE_MSG_EXPIRA_CHAVE,
         c.SN_ALTERA_AUDITORIA_IN_LOCO,
         c.SN_CADASTRA_PACIENTE,
         c.SN_ALTERA_CADASTRO_PACIENTE,
         c.CD_IDIOMA,
         c.SN_AUDITOR_TABELA,
         c.SN_CRIA_USUARIO,
         c.SN_PERMITE_DESVINCULO_PACOTE,
         c.SN_ALTERA_PACIENTE_SEM_CPF,
         c.SN_ALTERA_OBSERVACAO_GUIA,
         c.SN_PERMITE_FECHA_CNT_ANATOMIA,
         c.SN_PERMITE_DUPLICIDADE_CPF);
      /*BEGIN
        INSERT INTO DBAMV.USUARIO_MULTI_EMPRESA@ORMVPS.WORLD
        VALUES
          (1, C.CD_USUARIO);
      
      Exception
        when DUP_VAL_ON_INDEX then
          Raise_application_error(-20003,
                            'Usu�rio n�o encontrado na base de dados do Hospital: ' ||
                            sqlerrm);
      END;*/
    END;
  END LOOP;

Exception 
  When others Then
    Raise_application_error(-20001, 'Erro interno: ' || sqlerrm);
    rollback;
  
END;

SELECT *
  FROM Dbasgu.Log_Senha L
 WHERE L.CD_USUARIO = 'TESTESUPORTE1'
   FOR UPDATE

SELECT *
  FROM DBAMV.USUARIO_MULTI_EMPRESA@ORMVPS.WORLD U
 WHERE U.CD_ID_USUARIO = '1'
   FOR UPDATE

SELECT U.*
  FROM DBASGU.USUARIOS@ORMVPS.WORLD U
 WHERE U.CD_USUARIO = 'TESTESUPORTE13'
   FOR UPDATE;

--DELETE FROM DBASGU.USUARIOS U WHERE U.CD_USUARIO = 'TESTESUPORTE1'

SELECT U.SN_PERMITE_DUPLICIDADE_CPF, U.*
  FROM DBASGU.papel_USUARIOS U
 WHERE U.CD_USUARIO = 'TESTESUPORTE1'
   FOR UPDATE;

--SELECT ROWID, P.* FROM DBASGU.PAPEL_USUARIOS P WHERE P.CD_USUARIO = 'TESTESUPORTE1'
