CALL
   CUSTOM.PRC_PAINEL_USUARIO_COPIA(
     vUsuarioNovo  => 'MIFERREIRA',
     vUsuarioCopia => 'FLALVES',
     vDeletaPermissoes => 'S',
     vAtualizaPagPrincipal => 'S'
   );
   
 
