DECLARE
   --
   CURSOR C_DOC_CLINICO IS
    SELECT P.CD_DOCUMENTO_CLINICO
         , P.CD_ATENDIMENTO
         , P.CD_PACIENTE
         , P.CD_PRESTADOR
         , P.CD_USUARIO
         , P.CD_OBJETO
      FROM DBAMV.PW_DOCUMENTO_CLINICO P
     WHERE P.CD_TIPO_DOCUMENTO = 54
       AND P.TP_STATUS = 'IMPORTADO'
       AND p.cd_atendimento =  5560294 --alterar o n�mero do atendimento e executar.
     ORDER BY DH_REFERENCIA DESC;
   --
   TYPE TBREGISTRODOCUMENTO IS TABLE OF C_DOC_CLINICO%ROWTYPE INDEX BY PLS_INTEGER;
   RTBREGISTRODOCUMENTO    TBREGISTRODOCUMENTO;
   NCOUNT NUMBER := 0;
   --
   PROCEDURE INSERE_DOC_CLINICO(pCdAtendimento NUMBER, pCdPaciente NUMBER, pCdPrestador NUMBER, pCdUsuario VARCHAR2, pCdObjeto NUMBER ) IS
   BEGIN
   --
      INSERT INTO DBAMV.PW_DOCUMENTO_CLINICO ( CD_DOCUMENTO_CLINICO
                                             , CD_TIPO_DOCUMENTO
                                             , TP_STATUS
                                             , DH_REFERENCIA
                                             , DH_CRIACAO
                                             , DH_FECHAMENTO
                                             , DH_IMPRESSO
                                             , DH_DOCUMENTO
                                             , CD_PACIENTE
                                             , CD_PRESTADOR
                                             , CD_ATENDIMENTO
                                             , CD_USUARIO
                                             , CD_OBJETO)
                                      VALUES ( dbamv.seq_pw_documento_clinico.nextval
                                             , 54
                                             , 'FECHADO'
                                             , SYSDATE
                                             , SYSDATE
                                             , NULL
                                             , NULL
                                             , SYSDATE
                                             , pCdPaciente
                                             , pCdPrestador
                                             , pCdAtendimento
                                             , pCdUsuario
                                             , pCdObjeto);
   --
   END;
   --
BEGIN
  --
  OPEN C_DOC_CLINICO;
    --
    LOOP
    --
      FETCH C_DOC_CLINICO BULK COLLECT INTO RTBREGISTRODOCUMENTO;
      --
      EXIT WHEN RTBREGISTRODOCUMENTO.COUNT = 0;
      --
      FOR I IN 1..RTBREGISTRODOCUMENTO.COUNT LOOP
      --
      -- ATUALIZA O STATUS DO DOCUMENTO CLINICO PARA 'FECHADO'
       UPDATE DBAMV.PW_DOCUMENTO_CLINICO DC
          SET DC.TP_STATUS = 'FECHADO'
        WHERE DC.CD_DOCUMENTO_CLINICO = RTBREGISTRODOCUMENTO(I).CD_DOCUMENTO_CLINICO
          AND DC.TP_STATUS = 'IMPORTADO';
      --
      -- CRIA UM NOVO DOCUMENTO CLINICO DO TIPO AFERICAO AGRUPARA EM BRANCO PARA PODER SER SELECIONADO AO ENTRAR NA TELA E NAO APRESENTAR A LENTIDAO
       INSERE_DOC_CLINICO( RTBREGISTRODOCUMENTO(I).CD_ATENDIMENTO
                         , RTBREGISTRODOCUMENTO(I).CD_PACIENTE
                         , RTBREGISTRODOCUMENTO(I).CD_PRESTADOR
                         , RTBREGISTRODOCUMENTO(I).CD_USUARIO
                         , RTBREGISTRODOCUMENTO(I).CD_OBJETO);
      --
       NCOUNT := NCOUNT + 1;
       -- COMITA A CADA 1000 REGISTROS
       IF NCOUNT = 1000 THEN
         COMMIT;
         NCOUNT := 0;
       END IF;
      --
      END LOOP;
    --
    END LOOP;
    --
   -- COMMIT;
  --
  CLOSE C_DOC_CLINICO;
END;
