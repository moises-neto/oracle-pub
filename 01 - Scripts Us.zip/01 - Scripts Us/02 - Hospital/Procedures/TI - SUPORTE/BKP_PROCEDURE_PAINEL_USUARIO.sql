CREATE OR REPLACE Procedure DBACP.PRC_IMPORTA_USUARIO_MV2000 (vPapel number) is

-- Procedure que importa usuários do MV2000 para as soluções de BI e Qualidade da MV
-- Data de Criação - 19/11/2012
-- Anderson Lima

cursor cUsuarios is
   Select       upper(u.cd_usuario)         cd_usuario_portal, --Alterado de lower para upper por Keila Coutinho em 24/01/2019
                lower(u.ds_email)           ds_email, 
                'S'                  sn_ativo,
                u.nm_usuario nm_usuario,
                2                    cd_tipo_usuario,
                null                 cd_pagina_principal,
			          dbaportal.fnc_se_criptografia(u.cd_usuario,
																		 nvl((select substr(rtrim(dbasgu.criptO_descripto(cd_senha, 'SMVCRIPTON'), 'KK'),length(cd_usuario)+1,30)
																				FROM dbasgu.usuarios@ormvprd
																			 where cd_usuario = u.cd_usuario), cd_usuario)) ds_senha,
                'N'                  sn_usuario_microstrategy,
                null                    cd_microstrategy_data_source,
                null                    cd_tipo_licenca,
                'S'                  sn_bsc,
                'N'                  sn_backoffice,
                --dbacp.SEQ_USUARIO_PORTAL.nextval  id_usuario_portal,
								(select cd_papel  
             from dbasgu.papel_usuarios@ormvprd where tp_papel = 'P' and lower(cd_usuario) = lower(u.cd_usuario)) papel
from dbamv.usuario_multi_empresa@ormvprd e, dbasgu.usuarios@ormvprd u
 where e.cd_id_usuario = u.cd_usuario
   and e.cd_multi_empresa = 1
   and u.sn_ativo = 'S'
   and ((u.cd_usuario not like 'DBA%') and (u.cd_usuario not like 'LAUDOWEB') 
	       and (u.cd_usuario not like 'ACOLHIMENTO') and (u.cd_usuario not like 'COMPRASWEB') 
				 and (u.cd_usuario not like 'PLANISA') and (u.cd_usuario not like 'SCIH')
				 and (u.cd_usuario not like 'FRNASC') )
   and upper(u.cd_usuario) not in (select upper(uu.cd_usuario_portal) from dbacp.usuario_portal uu where upper(uu.cd_usuario_portal) = upper(u.cd_usuario));

begin
  for rUsuarios in cUsuarios loop
    INSERT
        INTO dbacp.usuario_portal
            (cd_usuario_portal,
             ds_email,
             sn_ativo,
             nm_usuario,
             cd_tipo_usuario,
             cd_pagina_principal,
             ds_senha,
             sn_usuario_microstrategy,
             cd_microstrategy_data_source,
             cd_tipo_licenca,
             sn_bsc,
             sn_backoffice,
             id_usuario_portal,
             cd_endereco,
             cd_cargo,
             cd_senioridade,
             xml_favoritos,
             sn_primeiro_acesso)

      Values(rUsuarios.cd_usuario_portal,
             rUsuarios.ds_email,
             rUsuarios.sn_ativo,
             rUsuarios.nm_usuario,
             rUsuarios.cd_tipo_usuario,
             rUsuarios.cd_pagina_principal,
             rUsuarios.ds_senha,
             rUsuarios.sn_usuario_microstrategy,
             rUsuarios.cd_microstrategy_data_source,
             rUsuarios.cd_tipo_licenca,
             rUsuarios.sn_bsc,
             rUsuarios.sn_backoffice,
             dbacp.SEQ_USUARIO_PORTAL.nextval,
             --rUsuarios.id_usuario_portal,
             null,
             null,
             null,
             '<root>
                <favoritos nome="Meus Favoritos"/>
                <grupos nome="Meus Grupos">
                 <grupo nome="Central">
                  <item nome="Central" url="centralDocumentos.swf" descricao="Gerencie documentos de forma segura."/>
                 </grupo>
                </grupos>
              </root>',
             'N');
/*     IF rUsuarios.papel IS NOT NULL AND rUsuarios.papel = 180 THEN
					INSERT INTO DBACP.USUARIO_PORTAL_PAPEL (CD_USUARIO_PORTAL, CD_PAPEL) VALUES(rUsuarios.cd_usuario_portal, 283);		 
			ELSE IF rUsuarios.papel IS NOT NULL AND rUsuarios.papel <> 180 THEN
					INSERT INTO DBACP.USUARIO_PORTAL_PAPEL (CD_USUARIO_PORTAL, CD_PAPEL) VALUES(rUsuarios.cd_usuario_portal, 145);							
		      END IF;
			END IF;*/
			--Acesso ao papel SE_Acesso_Geral - Anderson Lima - 25/09/2013
			INSERT INTO DBACP.USUARIO_PORTAL_PAPEL (CD_USUARIO_PORTAL, CD_PAPEL) VALUES(rUsuarios.cd_usuario_portal, 332);		
			INSERT INTO DBACP.USUARIO_PORTAL_PAPEL (CD_USUARIO_PORTAL, CD_PAPEL) VALUES(rUsuarios.cd_usuario_portal, 361);	--Anderson 26/03/2014	
  end loop;
 commit;
end;

