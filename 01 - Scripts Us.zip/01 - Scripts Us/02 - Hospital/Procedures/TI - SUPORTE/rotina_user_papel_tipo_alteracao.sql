DECLARE
  
  CURSOR TIP_PAPEL AS 
  SELECT PU.TP_PAPEL
    FROM DBASGU.USUARIOS U, DBASGU.PAPEL_USUARIOS PU, DBASGU.PAPEL P
   WHERE pu.cd_papel = '&PAPEL'
     AND pu.tp_papel = '&P_ou_A'
     AND PU.CD_USUARIO = U.CD_USUARIO
     AND PU.CD_PAPEL = P.CD_PAPEL
  
BEGIN
      FOR I IN TIP_PAPEL LOOP
          BEGIN
          UPDATE DBASGU.PAPEL_USUARIOS PU
          SET PU.TP_PAPEL = '&P_ou_A'
          
END;

SELECT rowid, u.*

  FROM Dbasgu.Papel_Usuarios U

 WHERE u.cd_papel in ('228')
   and u.tp_papel = 'A'
   
   
Select lower(Substr(Rtrim(Dbasgu.Cripto_Descripto(Cd_Senha, 'SMVCRIPTON'), 'KK'),
������������� Length(Cd_Usuario) + 1, 30))
� From Dbasgu.Usuarios
�Where (Cd_Usuario) = 'MNETO' 
