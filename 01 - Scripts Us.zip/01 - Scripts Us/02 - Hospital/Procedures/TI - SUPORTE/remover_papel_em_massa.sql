BEGIN 
FOR USUARIO IN (SELECT U.CD_USUARIO
      FROM DBASGU.USUARIOS U, DBASGU.PAPEL_USUARIOS PU, DBASGU.PAPEL PAP
     WHERE U.SN_ATIVO = 'S'
       AND PAP.CD_PAPEL = --PAPEL
       AND PU.CD_USUARIO = U.CD_USUARIO
       AND PAP.CD_PAPEL = PU.CD_PAPEL)
 LOOP
BEGIN
      DELETE FROM DBASGU.PAPEL_USUARIOS M
      WHERE M.CD_PAPEL = --PAPEL
      AND M.CD_USUARIO = USUARIO.CD_USUARIO;
      
      UPDATE DBASGU.PAPEL_USUARIOS M
      SET M.TP_PAPEL = 'P'
      
END;
END LOOP;
END;

SELECT * FROM DBASGU.PAPEL_USUARIOS M
WHERE M.CD_PAPEL = 247
FOR UPDATE
  
SELECT * FROM DBASGU.PAPEL_USUARIOS M
WHERE  M.CD_USUARIO IN (SELECT U.CD_USUARIO FROM DBASGU.USUARIOS U
 WHERE U.DS_OBSERVACAO LIKE '%HEMODINAMICA%'
 AND U.SN_ATIVO = 'S')
 for update
 
 
   
SELECT *
  FROM DBASGU.PAPEL_USUARIOS M
 where exists (SELECT U.CD_USUARIO
          FROM DBASGU.USUARIOS U
         WHERE m.cd_usuario = u.cd_usuario
         --AND U.DS_OBSERVACAO LIKE '1100 - SND'
           AND U.SN_ATIVO = 'S')
           AND M.CD_PAPEL = 260
           
           
           
           select u.cd_usuario, p.cd_papel, u.ds_observacao
           from dbasgu.usuarios u
           inner join
           dbasgu.papel_usuarios p
           on u.cd_usuario = p.cd_usuario
           where p.cd_papel = 260
           and u.sn_ativo = 'S'
           
           
           
           
          
 
 
 
 
 
 
 
 
 
 
 
 
 
