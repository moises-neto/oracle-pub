/* LEMBRAR DE  INSERIR O SCRIPT ABAIXO NA TRIGGER  CUSTOM.TRG_TI_INATIVA_USUARIO_YOUDO

--REMOVE LICEN�A DO PAINEL DE INDICADORES
     DELETE DBACP.USUARIO_SISTEMA_LICENCA@ORMVBI L
     WHERE L.CD_USUARIO_PORTAL = :OLD.CD_USUARIO;

*/
   --Consultando par�metri��o dos portlets SQL.
 select * from dbacp.configuracao_parametros_sql s
 where s.cd_usuario_portal = 'FPORTAS' AND S.CD_PORTLET = '3632' FOR UPDATE
 
 
  -- copiando p�ginas e papeis de um usu�rio e aplicando no outro
   CALL
   CUSTOM.PRC_PAINEL_USUARIO_COPIA(
     vUsuarioNovo  => 'MIFERREIRA',
     vUsuarioCopia => 'FLALVES',
     vDeletaPermissoes => 'S',
     vAtualizaPagPrincipal => 'S'
   );
   
    --consultando licen�as LITE  de usu�rios inativos
   SELECT *
     FROM DBACP.USUARIO_SISTEMA_LICENCA L
    WHERE l.cd_tipo_licenca = 1
      AND l.cd_usuario_portal in
          (select u.cd_usuario_portal
             from Dbacp.Usuario_Portal U
            where u.sn_ativo = 'N')
      for update
 -----------------------------------------------------------------------------------------------------------------------------------------------    

     SELECT l.*, rowid  from DBACP.USUARIO_SISTEMA_LICENCA L
     where l.cd_usuario_portal = 'JRABELLO'
     
     select * from dbacp.portlet_papel where rownum <=10;  
     select * from dbacp.portlet where rownum <=10;
     
      select * from dbacp.portlet p join dbacp.pagina pag 
      on p.cd_grupo_portlet = pag.cd_pagina
      where p.cd_portlet = 959
      
      select * from dba_tables d where d.TABLE_NAME like '%SETO%'
      
     SELECT p.tp_perfil, c.cd_centro_custo, c.ds_centro_custo
       FROM DBAPORTAL.PERFIL_SETOR P
       join DBAPORTAL.CENTRO_CUSTO c
      WHERE P.TP_PERFIL = 'G'

-- copia as p�ginas, licen�as e papeis do painel de indicadores de um usu�rio, e libera para todos do mesmo papel  
DECLARE
  CURSOR CUSUARIO IS
  
 SELECT UPPER(u.cd_usuario) AS CD_USUARIO
   FROM Dbasgu.Usuarios@Ormvprd       U,
        Dbasgu.Papel_Usuarios@Ormvprd Pu,
        Dbasgu.Papel@Ormvprd          Pap
  WHERE U.Sn_Ativo = 'S'
    AND Pu.Cd_Usuario = U.Cd_Usuario
    AND Pap.Cd_Papel = Pu.Cd_Papel
    and u.cd_usuario not in ('DBAMV',
                             'MVPADRAO',
                             'DBASGU',
                             'IMPRESSAO',
                             'ACESSOPRD',
                             'GEINTEGRA',
                             'DBAPS') -- restringindo os usu�rios para n�o entrar na consulta e realizar a libera��o.
    AND PU.CD_PAPEL in ('260');
       
BEGIN
  FOR USUARIO IN CUSUARIO LOOP
    BEGIN
     CUSTOM.PRC_PAINEL_USUARIO_COPIA(
     vUsuarioNovo  => USUARIO.CD_USUARIO,
     vUsuarioCopia => 'TESTE3',
     vDeletaPermissoes => 'N',
     vAtualizaPagPrincipal => 'N'
   );
    END;
  END LOOP;
END;


select * from dbacp.pagina p
where p.ds_titulo like '%Estoque%'




SELECT rowid, U.CD_USUARIO_PORTAL
      FROM Dbacp.Usuario_Portal U
      WHERE u.sn_ativo = 'S'
      AND U.CD_USUARIO_PORTAL != UPPER(U.CD_USUARIO_PORTAL)

 --Select Para trazer a lista de paineis
                        select r.*, rowid
                                from custom.ti_paineis r;
                             --   select * from custom.ti_paineis_observacoes;
                                
