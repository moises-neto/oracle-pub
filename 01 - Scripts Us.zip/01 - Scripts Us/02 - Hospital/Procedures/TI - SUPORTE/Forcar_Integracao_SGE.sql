declaRe

  -- Local variables here
  v_Qt_Requisitantes integer;
  v_Nm_Usuario Varchar2(50);
  v_Cd_Empresa Number;
  v_Senha Varchar2(50);
  V_Email Varchar2(50);

begin
     -- Contar quantos requisitantes existem na tabela antiga
     -- a partir de um login
     select count(r.rq_user_erp) into v_Qt_Requisitantes from custom.rq_requisitante r
     where r.rq_user_erp = '&LOGIN';
     
     Dbms_Output.Put_Line('USU�RIO: ' || '&LOGIN');

     if v_Qt_Requisitantes = 0 then

         Dbms_Output.Put_Line('N�O EXISTE NA TABELA DE REQUISITANTES');

         -- Buscar informa��es do usu�rio
         Select Sol.Nm_Usuario Into v_Nm_Usuario From Custom.Chm_Solicitantes Sol
         Where Sol.Cd_Login = '&LOGIN';

         Select Sol.Cd_Empresa Into v_Cd_Empresa From Custom.Chm_Solicitantes Sol
         Where Sol.Cd_Login = '&LOGIN';

         Select Sol.Password Into v_Senha From Custom.Chm_Solicitantes Sol
         Where Sol.Cd_Login = '&LOGIN';

         Select Sol.Email Into V_Email From Custom.Chm_Solicitantes Sol
         Where Sol.Cd_Login = '&LOGIN';

         insert into custom.rq_requisitante
         values
           (custom.rq_requisitante_seq.nextval,
            v_Nm_Usuario,
            '&LOGIN',
            'S',
            v_Cd_Empresa,
            v_Senha,
            null,
            'N',
            V_Email,
            'N',
            'N',
            'N',
            null,
            'N'
            );

       Commit;

        Dbms_Output.Put_Line('INTEGRADO');

     Else

        Dbms_Output.Put_Line('N�O INTEGRADO, J� EXISTE! ');

     end if;


end;
