SELECT * FROM USER_TABLES;

/*create table custom.usuario_papel_observacao as (

SELECT DISTINCT
       U.DS_OBSERVACAO,
       P.CD_PAPEL,  
       P.DS_PAPEL
  FROM DBASGU.USUARIOS U, DBASGU.PAPEL_USUARIOS PU, DBASGU.PAPEL P
 --WHERE ROWNUM <= 10
 WHERE U.SN_ATIVO = 'S'
 AND u.cd_usuario = pu.cd_usuario
 AND pu.cd_papel = p.cd_papel
 )*/
 custom.trg_usuario_papel_observacao

custom.trg_valida_obs_usuario


 
/* create trigger custom.trg_usuario_papel_observacao 
before 
insert 
on dbasgu.papel_usuarios

Referencing New As New Old As Old
  For Each Row
    
DECLARE
v_observacao varchar2(40);
v_existe_obs number(10);

begin

select u.ds_observacao into v_observacao from dbasgu.usuarios u where u.cd_usuario = :old.cd_usuario;

select count(*) into v_existe_obs from custom.usuario_papel_observacao up where up.ds_observacao = v_observacao and up.cd_papel = :new.cd_papel;
if (v_existe_obs = 0) then
  raise_application_error(-20001, 'N�O EXISTE A OBSERVA��O!');
  
  END IF;
    
end;*/
 
-- select U.*, ROWID from DBASGU.USUARIOS U where u.ds_observacao like '%RECEP��O%' and u.sn_ativo = 'S'


