CREATE OR REPLACE PROCEDURE PRC_TI_IMP_PERM_PAPEL(USUARIO VARCHAR2) IS
  /*****************************************************************************************************
  * OBJETO: CUSTOM.PRC_TI_IMP_PERM_PAPEL                                                               *
  ******************************************************************************************************
  * MÓDULO:                                                                                            *
  * OBJETIVO: PADRONIZA PERMISSÕES DOS USUÁRIOS POR PAPEL                                              *
  ******************************************************************************************************
  * IMPORTANTE:                                                                                        *
  |----------------------------------------------------------------------------------------------------|
  | DATA      | CHAMADO  | SOLICITANTE        | RESPONSÁVEL     | VERSÃO  | ALTERAÇÃO                  |
  |-----------+----------+--------------------+-----------------+--------------------------------------|
  |30/06/2015 |          | LARISSA GONZALES   | RODRIGO MARCIANO|  1.0    | CRIAÇÃO DA PROCEDURE       |
  |-----------+----------+--------------------+-----------------+--------------------------------------|
  |20/08/2019 |          | LARISSA GONZALES   | GUSTAVO COSTA   |  1.1    | ADICIONADO TRATATIVA       |
  |           |          |                    |                 |         | DUP_VAL_ON_INDEX           |
  |-----------+----------+--------------------+-----------------+--------------------------------------|
  */
  
  -- V_VALIDA_PAPEL NUMBER;
BEGIN

 DECLARE

    CURSOR SETOR IS
      SELECT DISTINCT S.CD_SETOR
        FROM CUSTOM.CHM_TI_PAPEL_SETOR S
       WHERE S.CD_PAPEL IN (SELECT P.CD_PAPEL
                              FROM DBASGU.PAPEL_USUARIOS P
                             WHERE P.CD_USUARIO = USUARIO);

   CURSOR CENTRO_CIRURGICO IS
      SELECT DISTINCT S.CD_CEN_CIR
        FROM CUSTOM.CHM_TI_PAPEL_CEN_CIR S
       WHERE S.CD_PAPEL IN (SELECT P.CD_PAPEL
                              FROM DBASGU.PAPEL_USUARIOS P
                             WHERE P.CD_USUARIO = USUARIO);

    CURSOR ORIGEM_ATENDIMENTO IS
      SELECT DISTINCT S.CD_ORI_ATE
        FROM CUSTOM.CHM_TI_PAPEL_ORIGEM S
       WHERE S.CD_PAPEL IN (SELECT P.CD_PAPEL
                              FROM DBASGU.PAPEL_USUARIOS P
                             WHERE P.CD_USUARIO = USUARIO);

    CURSOR UNIDADE_ATENDIMENTO IS
      SELECT DISTINCT S.CD_UNIDADE_ATENDIMENTO
        FROM CUSTOM.CHM_TI_PAPEL_UNID_ATENDIMENTO S
       WHERE S.CD_PAPEL IN (SELECT P.CD_PAPEL
                              FROM DBASGU.PAPEL_USUARIOS P
                             WHERE P.CD_USUARIO = USUARIO);

    CURSOR UNIDADE_INTERNACAO IS
      SELECT DISTINCT S.CD_UNI_INT, S.CD_SETOR
        FROM CUSTOM.CHM_TI_PAPEL_SETOR_UNID_INT S
       WHERE S.CD_PAPEL IN (SELECT P.CD_PAPEL
                              FROM DBASGU.PAPEL_USUARIOS P
                             WHERE P.CD_USUARIO = USUARIO);
                             
                   

    CURSOR ESTOQUE IS
      SELECT DISTINCT *
        FROM CUSTOM.CHM_TI_PAPEL_ESTOQUE ES
       WHERE ES.CD_PAPEL IN (SELECT P.CD_PAPEL
                               FROM DBASGU.PAPEL_USUARIOS P
                            WHERE P.CD_USUARIO = USUARIO);


 CURSOR EXAMES_PSDI IS
      SELECT DISTINCT E.CD_SET_EXA
        FROM CUSTOM.CHM_TI_PAPEL_PSDI_EXAME E
       WHERE E.CD_PAPEL IN (SELECT P.CD_PAPEL
                              FROM DBASGU.PAPEL_USUARIOS P
                             WHERE P.CD_USUARIO = USUARIO);

    CURSOR EXAMES IS
      SELECT DISTINCT E.CD_SET_EXA
        FROM CUSTOM.CHM_TI_PAPEL_EXAME E
       WHERE E.CD_PAPEL IN (SELECT P.CD_PAPEL
                              FROM DBASGU.PAPEL_USUARIOS P
                             WHERE P.CD_USUARIO = USUARIO);

    CURSOR CAD_SAME IS
      SELECT DISTINCT S.CD_CAD_SAME
        FROM CUSTOM.CHM_TI_PAPEL_CAD_SAME S
       WHERE S.CD_PAPEL IN (SELECT P.CD_PAPEL
                              FROM DBASGU.PAPEL_USUARIOS P
                             WHERE P.CD_USUARIO = USUARIO);

    CURSOR ENCERRA_CHAMADO IS
      SELECT DISTINCT R.CD_MULTI_EMPRESA
        FROM CUSTOM.CHM_TI_PAPEL_USUARIO_ENCERR R
       WHERE R.CD_PAPEL IN (SELECT P.CD_PAPEL
                              FROM DBASGU.PAPEL_USUARIOS P
                             WHERE P.CD_USUARIO = USUARIO);

    CURSOR CANCELA_NOTA IS
      SELECT DISTINCT N.CD_FORMULARIO_NF
        FROM CUSTOM.CHM_TI_PAPEL_USU_CANCELA_NOTA N
       WHERE N.CD_PAPEL IN (SELECT P.CD_PAPEL
                              FROM DBASGU.PAPEL_USUARIOS P
                             WHERE P.CD_USUARIO = USUARIO);

  /*  CURSOR FUNC_ESPEC IS
      SELECT DISTINCT F.CD_ESPEC
        FROM CUSTOM.CHM_TI_PAPEL_FUNC_ESPEC F
       WHERE F.CD_PAPEL IN (SELECT P.CD_PAPEL
                              FROM DBASGU.PAPEL_USUARIOS P
                          WHERE P.CD_USUARIO = USUARIO);*/
                           

 BEGIN
    -- APAGA AS PERMISSÕES DE SETOR DO USUARIO
    DELETE FROM DBAMV.USUARIO_SETOR I WHERE I.NM_USUARIO = USUARIO;

    FOR S IN SETOR LOOP
      Begin
        INSERT INTO DBAMV.USUARIO_SETOR
          (CD_SETOR, NM_USUARIO)
        VALUES
          (S.CD_SETOR, USUARIO);
      Exception 
        When dup_val_on_index then
          null;
      End;

    END LOOP;

    -- APAGA AS PERMISSÕES DE CENTRO CIRURGICO DO USUARIO
    DELETE FROM DBAMV.USU_CEN_CIR I WHERE I.NM_USUARIO = USUARIO;

    FOR C IN CENTRO_CIRURGICO LOOP
      Begin
        INSERT INTO DBAMV.USU_CEN_CIR
          (CD_CEN_CIR, NM_USUARIO)
        VALUES
          (C.CD_CEN_CIR, USUARIO);
      Exception 
        When dup_val_on_index then
          null;
      End;
    END LOOP;

    -- APAGA AS PERMISSÕES DE ORIGEM DE ATENDIMENTO DO USUARIO
    DELETE FROM DBAMV.USU_ORIGEM I WHERE I.CD_USUARIO = USUARIO;

    FOR C IN ORIGEM_ATENDIMENTO LOOP
      BEGIN
        INSERT INTO DBAMV.USU_ORIGEM
          (CD_ORI_ATE, CD_USUARIO)
        VALUES
          (C.CD_ORI_ATE, USUARIO);
      EXCEPTION
        When dup_val_on_index then
          null;
        WHEN OTHERS THEN
          RAISE_APPLICATION_ERROR(-20100, 'ORIGEM :' || C.CD_ORI_ATE);
      END;

    END LOOP;

    -- APAGA AS PERMISSÕES DE ORIGEM DE ATENDIMENTO DO USUARIO
    DELETE FROM DBAMV.USUARIO_UNID_ATENDIMENTO I
     WHERE I.CD_USUARIO = USUARIO;

    FOR C IN UNIDADE_ATENDIMENTO LOOP
      Begin
        INSERT INTO DBAMV.USUARIO_UNID_ATENDIMENTO
          (CD_UNIDADE_ATENDIMENTO, CD_USUARIO)
        VALUES
          (C.CD_UNIDADE_ATENDIMENTO, USUARIO);
      EXCEPTION
        When dup_val_on_index then
          null;
      End;
    END LOOP;

    -- APAGA AS PERMISSÕES DE SETOR E UNIDADE DE INTERNAÇÃO DO USUÁRIO

    DELETE FROM DBAMV.USUARIO_UNID_INT I WHERE I.CD_ID_USUARIO = USUARIO;

    FOR U IN UNIDADE_INTERNACAO LOOP
      Begin
        INSERT INTO DBAMV.USUARIO_UNID_INT
          (CD_UNID_INT, CD_ID_USUARIO, CD_SETOR)
        VALUES
          (U.CD_UNI_INT, USUARIO, U.CD_SETOR);
      EXCEPTION
        When dup_val_on_index then
          null;
      End;
    END LOOP;


    -- APAGA AS PERMISSÕES DE ESTOQUE DO USUÁRIO
  --  DELETE FROM DBAMV.USU_ESTOQUE E WHERE E.CD_ID_DO_USUARIO = USUARIO;
 
    FOR E IN ESTOQUE LOOP
      Begin
        INSERT INTO DBAMV.USU_ESTOQUE
          (CD_ESTOQUE,
           CD_ID_DO_USUARIO,
           SN_AUTORIZA_EXCL_SOLICITACAO,
           SN_AUTORIZA_ALTE_SOLICITACAO,
           TP_USUARIO,
           SN_PERMITE_ALT_ORD_COMPRAS,
           SN_ALT_VL_UNIT_OC,
           VL_PERC_VAR_VL_UNIT,
           SN_TRANS_QUANT_COTA,
           SN_AUTORIZA_ALTE_MOVIMENTACAO,
           SN_AUTORIZA_EXCL_MOVIMENTACAO,
           DT_INTEGRA,
           CD_SEQ_INTEGRA)
        VALUES
          (E.CD_ESTOQUE,
           USUARIO,
           E.SN_AUTORIZA_EXCL_SOLICITACAO,
           E.SN_AUTORIZA_ALTE_SOLICITACAO,
           E.TP_USUARIO,
           E.SN_PERMITE_ALT_ORD_COMPRAS,
           E.SN_ALT_VL_UNIT_OC,
           E.VL_PERC_VAR_VL_UNIT,
           E.SN_TRANS_QUANT_COTA,
           E.SN_AUTORIZA_ALTE_MOVIMENTACAO,
           E.SN_AUTORIZA_EXCL_MOVIMENTACAO,
           E.DT_INTEGRA,
           E.CD_SEQ_INTEGRA);
      EXCEPTION
        When dup_val_on_index then
          null;
      End;
    END LOOP;

    -- APAGA AS PERMISSÕES DE EXAMES PSDI DO USUÁRIO
   DELETE FROM DBAMV.PSDI_SET_EXA E WHERE E.NM_USUARIO = USUARIO;

    FOR EXP IN EXAMES_PSDI LOOP
      Begin
        INSERT INTO DBAMV.PSDI_SET_EXA
          (CD_SET_EXA, NM_USUARIO)
        VALUES
          (EXP.CD_SET_EXA, USUARIO);
      EXCEPTION
        When dup_val_on_index then
          null;
      End;
    END LOOP;

    --APAGA AS PERMISSÕES DE EXAMES DO USUÁRIO
    DELETE FROM DBAMV.USUARIOS_SET_EXA E WHERE E.NM_USUARIO = USUARIO;

    FOR EX IN EXAMES LOOP
      Begin
        INSERT INTO DBAMV.USUARIOS_SET_EXA
          (CD_SET_EXA, NM_USUARIO)
        VALUES
          (EX.CD_SET_EXA, USUARIO);
      EXCEPTION
        When dup_val_on_index then
          null;
      End;
    END LOOP;

    -- APAGA AS PERMISSÕES DE SAME DO USUÁRIO
    DELETE FROM DBAMV.Usuario_Cad_Same S WHERE S.CD_USUARIO = USUARIO;


    FOR SAME IN CAD_SAME LOOP
      Begin
        INSERT INTO DBAMV.USUARIO_CAD_SAME
          (CD_CAD_SAME, CD_USUARIO)
        VALUES
          (SAME.CD_CAD_SAME, USUARIO);
      EXCEPTION
        When dup_val_on_index then
          null;
      End;
    END LOOP;

    -- APAGA AS PERMISSÕES DE ENCERRAMENTO CHAMADOS DO USUÁRIO
    DELETE FROM DBAMV.USUARIO_ENCERRAMENTO E WHERE E.CD_USUARIO = USUARIO;

    FOR ENC IN ENCERRA_CHAMADO LOOP
      Begin
        INSERT INTO DBAMV.USUARIO_ENCERRAMENTO
          (CD_MULTI_EMPRESA, CD_USUARIO)
        VALUES
          (ENC.CD_MULTI_EMPRESA, USUARIO);
      EXCEPTION
        When dup_val_on_index then
          null;
      End;
    END LOOP;

    -- APAGA AS PERMISSÕES DE CANCELA NOTAS FISCAIS DO USUÁRIO
    DELETE FROM DBAMV.USUARIO_CANCELA_NOTA C WHERE C.CD_USUARIO = USUARIO;

    FOR CANC IN CANCELA_NOTA LOOP
      Begin
        INSERT INTO DBAMV.USUARIO_CANCELA_NOTA
          (CD_FORMULARIO_NF, CD_USUARIO)
        VALUES
          (CANC.CD_FORMULARIO_NF, USUARIO);
      EXCEPTION
        When dup_val_on_index then
          null;
      End;
    END LOOP;

    -- APAGA AS PERMISSÕES DE FUNCIONARIO X ESPECIALIDADE DO USUÁRIO
  /*  DELETE FROM DBAMV.FUNC_ESPEC F
     WHERE F.CD_FUNC IN
           (SELECT CD_FUNC
              FROM FUNCIONARIO C
             WHERE C.NM_FUNC IN
                   (SELECT NM_USUARIO
                      FROM DBASGU.USUARIOS U
                     WHERE (U.CD_USUARIO = C.CD_USUARIO
                        OR U.NM_USUARIO = C.NM_FUNC)
                        AND U.CD_USUARIO = USUARIO
                        ));

    FOR FUNC IN FUNC_ESPEC LOOP
      INSERT INTO DBAMV.FUNC_ESPEC
        (CD_ESPEC, CD_FUNC)
      VALUES
        (FUNC.CD_ESPEC, USUARIO);
    END LOOP;*/
   

  END;

COMMIT;

END;
