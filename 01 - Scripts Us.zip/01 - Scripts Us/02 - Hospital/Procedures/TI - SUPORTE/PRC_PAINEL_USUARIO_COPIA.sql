 
 CREATE OR REPLACE PROCEDURE CUSTOM.PRC_COPIA_USUARIO_PAINEL(vUsuarioNovo, 
														     vUsuarioCopia 
																IN VARCHAR2)
 
 IS
 
DECLARE

  CURSOR USUARIO IS
    SELECT U.CD_USUARIO_PORTAL
      FROM Dbacp.Usuario_Portal U
     WHERE U.CD_USUARIO_PORTAL = vUsuarioNovo;

  CURSOR cPAGINA_PRINCIPAL_USER_ADD IS
    SELECT u.cd_pagina_principal
      FROM Dbacp.Usuario_Portal U
     WHERE U.CD_USUARIO_PORTAL = vUsuarioNovo;

  CURSOR PAGINA IS
    SELECT P.CD_PAGINA
      FROM Dbacp.Usuario_Portal_Pagina P
     WHERE P.CD_USUARIO_PORTAL = vUsuarioCopia
       AND P.CD_PAGINA NOT IN
           (SELECT PP.CD_PAGINA
              FROM Dbacp.Usuario_Portal_Pagina PP
             WHERE PP.CD_USUARIO_PORTAL = vUsuarioNovo);

  CURSOR PAPEL IS
    SELECT P.CD_PAPEL
      FROM Dbacp.usuario_portal_papel P
	   WHERE P.CD_USUARIO_PORTAL = vUsuarioCopia
       AND P.CD_PAPEL NOT IN
           (SELECT PP.CD_PAPEL
              FROM Dbacp.usuario_portal_papel PP
             WHERE PP.CD_USUARIO_PORTAL = vUsuarioNovo);

  Cursor cLICENSA IS
    SELECT L.CD_USUARIO_PORTAL
      FROM DBACP.USUARIO_SISTEMA_LICENCA L
     WHERE L.CD_USUARIO_PORTAL = vUsuarioNovo;
     
  CURSOR cQTDDLICENSAS is
   select sum(count(l.cd_usuario_portal)) as licensas
     FROM DBACP.USUARIO_SISTEMA_LICENCA L
    where l.cd_tipo_licenca = 1
    group by l.cd_sistema, l.cd_tipo_licenca;
    
--declaração de váriaveis

  v_DELETAR_PERMISSOES        varchar2(3) := '&APAGAR_PERMISSOES';
  v_LICENSA                   cLICENSA%ROWTYPE;
  v_QTDDLICENSAS              cQTDDLICENSAS%ROWTYPE;
  v_USUARIO                   USUARIO%ROWTYPE;
  v_PAGINA_PRINCIPAL_USER_ADD cPAGINA_PRINCIPAL_USER_ADD%ROWTYPE;
  v_ATUALIZA_PAG_PRINCIPAL VARCHAR2(3) := '&ATUALIZA_PAG_PRINCIPAL';
  
BEGIN
  OPEN USUARIO;
  FETCH USUARIO
    INTO v_USUARIO;

  ----VERIFICANDO SE O USUÁRIO EXISTE NO PAINEL DE INDICADORES

  IF (USUARIO%NOTFOUND) THEN
  
    RAISE_APPLICATION_ERROR(-20001, 'USUÁRIO NÃO ENCONTRADO');
  
  END IF;
  CLOSE USUARIO;

  ----DELETANDO PÁGINAS e PAPÉIS do USUÁRIO

  IF (v_DELETAR_PERMISSOES = 'S' OR v_DELETAR_PERMISSOES = 'SIM') THEN
  
    DELETE FROM Dbacp.Usuario_Portal_Pagina P
     WHERE P.CD_USUARIO_PORTAL = vUsuarioNovo;
  
    DELETE FROM Dbacp.usuario_portal_papel Pap
     WHERE Pap.CD_USUARIO_PORTAL = vUsuarioNovo;
  
  END IF;

 --TRATANDO O LIMITE DE LICENÇAS LITE
  
 OPEN cQTDDLICENSAS;
  FETCH cQTDDLICENSAS
   INTO  v_QTDDLICENSAS;
     
   
IF(v_QTDDLICENSAS.licensas >= 999) THEN

   RAISE_APPLICATION_ERROR(-20001, 'ATENÇÃO: O LIMITE DE LICENÇAS LITE (999) FOI ATINGIDO!');              

CLOSE cQTDDLICENSAS;
END IF;

----APLICANDO LICENÇA PARA NOVOS USUÁRIOS
 OPEN cLICENSA;
  FETCH cLICENSA
   INTO v_LICENSA;
 
 IF (cLICENSA%NOTFOUND) THEN
  
    INSERT INTO DBACP.USUARIO_SISTEMA_LICENCA
      (CD_USUARIO_PORTAL, CD_SISTEMA, CD_TIPO_LICENCA)
    VALUES
      (vUsuarioNovo, 7, 1);
  END IF;
  
  close cLicensa;

  -----APLICANDO PAGINAS

  FOR I IN PAGINA LOOP
    BEGIN
      FOR J IN USUARIO LOOP
        BEGIN
        
          INSERT INTO Dbacp.Usuario_Portal_Pagina
            (CD_USUARIO_PORTAL, CD_PAGINA, SN_CUSTOMIZAR_REFERENCIADA)
          VALUES
            (J.CD_USUARIO_PORTAL, I.CD_PAGINA, 'N');
        
        END;
        
      END LOOP;
    END;
  END LOOP;
  ------ APLICANDO PÁGINA PRINCIPAL
  
  IF (v_ATUALIZA_PAG_PRINCIPAL = 'SIM' OR v_ATUALIZA_PAG_PRINCIPAL = 'S') THEN
  
  UPDATE Dbacp.Usuario_Portal U
     SET U.CD_PAGINA_PRINCIPAL =
         (SELECT u.cd_pagina_principal
            FROM Dbacp.Usuario_Portal U
           WHERE U.CD_USUARIO_PORTAL = vUsuarioCopia)
  
   WHERE U.CD_USUARIO_PORTAL = vUsuarioNovo;
  END IF;
  
  
  -----APLICANDO PAPEIS PAPEIS

  FOR I IN PAPEL LOOP
    BEGIN
      FOR J IN USUARIO LOOP
        BEGIN
        
          INSERT INTO Dbacp.usuario_portal_papel
            (Cd_Usuario_Portal, Cd_Papel)
          VALUES
            (J.CD_USUARIO_PORTAL, I.CD_PAPEL);
        END;
      END LOOP;
    END;
  END LOOP;

END;

END CUSTOM.PRC_PAINEL_USUARIO_COPIA;