sELECT * fROM DBA_SOURCE A
WHERE (A.TEXT LIKE '%2013%' or A.TEXT LIKE '%2007%' or A.TEXT LIKE '%0189%' or A.TEXT LIKE '%0289%')
AND A.OWNER IN ('CUSTOM', 'DBAPS', 'DBAMV')
aND UPPER(A.TEXT) LIKE UPPER('%ds_observacao%')

--TRG_BLOCK_PEDIDO_AUT
--TRG_BLOCK_ANEXO_OCORRENCIA
--PRC_ANALISAR_GUIA_CLIENTE
--PRC_ANALISAR_GUIA_CLIENTE_R
--FNC_RET_GUIA_CADASTRADA_RECEP
--FNC_RETORNA_GUIA_REVALIDADA

/*
************************Observa��es Antigas************************
--------------------Atendimento (Tiemi)----------------------------------------
2013 - RECEPCAO COOPERATIVA
2013 - RECEPCAO COOPERATIVA (POSTOS)

--------------------Atendimento(Simone e Karina)-------------------------------
2007 - INTERCAMBIO - COOP

--------------------Atendimento(Tiemi e Karina Bicalho)------------------------
 0189 - UNIDADE ZONA NORTE (POSTOS)
 
--------------------Atendimento (Ana Paula)------------------------------------ 
 0289 - NAIS

*/
--------------------------------------------------------------------------------

/*
************************Novas observa��es************************
--------------------Atendimento (Tiemi)----------------------------------
318 - GERENCIA DE ATENDIMENTO
103 - RECEPCAO
112 - UNIDADE BOITUVA
113 - UNIDADE PORTO FELIZ
114 - UNIDADE PIEDADE
--------------------Atendimento(Simone e Karina)---------------------------
166 - INTERCAMBIO
312 - RECEPCAO AUTORIZACOES

--------------------Atendimento(Tiemi e Karina Bicalho)--------------------
209 - AUTORIZACOES ZONA NORTE
205 - RECEPCAO ASSISTENCIAL ZONA NORTE

--------------------Atendimento (Ana Paula)--------------------------------- 
289 - NAIS
291 - APS
--------------------------------------------------------------------------*/
