--Quando liberar o usu�rio para acessar o sistema SAS, � necess�rio adicionar o n�mero de registro do colaborador no campo NRFUNCIONAL
-- e o centro de custo da farm�cia (1140) no campo RQ_CC_COD, utilizando o select abaixo:

SELECT R.*,R.ROWID 
       FROM CUSTOM.RQ_REQUISITANTE R 
WHERE R.RQ_USER_ERP IN ('JOIRIBEIRO')

SELECT R.*,R.ROWID 
       FROM CUSTOM.RQ_REQUISITANTE R 
       WHERE R.RQ_CC_COD IS NULL
       AND R.RQ_ATIVO = 'S';
       
       SELECT ROWID, T.* FROM CUSTOM.RQ_REQ_INTEGRA_MV T WHERE T.RQ_USER_ERP IN ('EMELO')
       
       SELECT * FROM CUSTOM.CHM_TI_PAPEL_SETOR;



SELECT ROWID, PM.* FROM DBASGU.PAPEL_MOD PM
WHERE PM.CD_PAPEL = 202


SELECT * FROM ALL_USERS U
WHERE U.username = 'ALPEDROSO'
