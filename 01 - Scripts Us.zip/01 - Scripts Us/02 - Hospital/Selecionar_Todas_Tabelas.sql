select * from all_tables
