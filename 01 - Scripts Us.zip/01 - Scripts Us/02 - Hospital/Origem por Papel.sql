select t.*, t.rowid from CHM_TI_PAPEL_ORIGEM t where t.cd_papel = 240
