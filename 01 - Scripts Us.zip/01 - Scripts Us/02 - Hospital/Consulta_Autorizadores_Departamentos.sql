SELECT -- INITCAP(A.NM_AUTORIZADOR) AS COLABORADOR,
       --O.DS_EMAIL AS EMAIL,
       o.cd_depto_operadora,
       initcap(O.DS_DEPTO_OPERADORA) AS DEPARTAMENTO
    
  FROM DBAPS.DEPTO_OPERADORA O
  
  JOIN DBAPS.AUTORIZADOR A
    ON O.CD_AUTORIZADOR_SUPERIOR = A.CD_AUTORIZADOR
 WHERE A.NM_AUTORIZADOR NOT IN UPPER('sac')
 
 
 select rowid, o.* from DBAPS.DEPTO_OPERADORA o where o.cd_depto_operadora = 48
 
 
 ---REMOVE PERMISS�ES DE COMUNICA��O CONTINGENCIA E LEITURA CONTINGENCIA NO AUTORIZADOR QUANDO O MESMO POSSUI PAPEL 170 E FOR DO N�VEL 1
 DECLARE
   CURSOR CUSUARIO IS
     SELECT U.CD_USUARIO
       FROM DBAPS.AUTORIZADOR A
       JOIN DBASGU.USUARIOS U
         ON U.CD_USUARIO = A.CD_USUARIO
       JOIN DBASGU.PAPEL_USUARIOS P
         ON P.CD_USUARIO = U.CD_USUARIO
      WHERE P.CD_PAPEL = 170
        AND A.NR_NIVEL = 1
        AND (A.SN_UTILIZA_COMUNICACAO_BENEFI = 'S' OR
            A.SN_LEITURA_CONTINGENCIA = 'S')
      ORDER BY U.CD_USUARIO;
 
 BEGIN
 
   FOR C IN CUSUARIO LOOP
   
     BEGIN
       UPDATE DBAPS.AUTORIZADOR A
          SET A.SN_LEITURA_CONTINGENCIA       = 'N',
              A.SN_UTILIZA_COMUNICACAO_BENEFI = 'N'
        WHERE A.CD_USUARIO = C.CD_USUARIO;
     
     END;
   END LOOP;
 END;
 
 
 
 
 
 
 SELECT U.CD_USUARIO, U.DS_OBSERVACAO, P.CD_PAPEL
        FROM DBASGU.USUARIOS U
         JOIN DBASGU.PAPEL_USUARIOS P
         ON P.CD_USUARIO = U.CD_USUARIO
      WHERE u.ds_observacao like '%180 - MEDICOS%'
 
 
 DBAPS.CNT_CALL_CENTER_DEPTO_OPE_FK
 
 
 select *
   from DBAPS.DEPTO_OPERADORA t
   join DBAPS.CALL_CENTER_MENSAGEM cm
     on t.cd_depto_operadora = cm.cd_depto
  where t.cd_autorizador_superior is null
  
  select *
    from DBAPS.DEPTO_OPERADORA t
   where t.cd_autorizador_superior is null
   order by t.cd_depto_operadora

 
 delete DBAPS.DEPTO_OPERADORA o where o.cd_depto_operadora =   
 
 dbaps.cnt_depto_autzc_depto_ope_2_fk
 dbaps.cnt_lim_prcer_usu_call_dept_fk
 dbaps.cnt_call_center_depto_ope_fk
 
dbaps.cnt_depto_autzc_depto_ope_1_fk
dbaps.cnt_italerta_depto_oper_fk
 
 --departamento associado
select rowid, da.* from DBAPS.DEPARTAMENTO_AUTORIZACAO da where da.cd_depto_operadora_aut = 55


select rowid, da.* from DBAPS.DEPARTAMENTO_AUTORIZACAO da where da.cd_departamento_autorizacao = 55
 
--limite de parecer callcenter
select rowid, l.* from dbaps.LIMITE_PARECER_USU_CALLCENTER l where l.cd_depto_operadora = 54

 --tabela de departamento
 select rowid, o.* from DBAPS.DEPTO_OPERADORA o where o.cd_depto_operadora = 52
 
 --autorizador x departamento
 select rowid, a.* from dbaps.autorizador a where a.cd_depto_operadora = 54
 
 --mensagem call center
 select rowid, c.* from dbaps.CALL_CENTER_MENSAGEM c where c.cd_depto = 54
 
 
 select rowid, i.* from dbaps.ITALERTA i where i.cd_departamento = 40
 


select * from dbaps.Tipo_hora
