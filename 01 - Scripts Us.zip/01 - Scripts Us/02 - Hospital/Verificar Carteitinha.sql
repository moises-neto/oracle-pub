SELECT A.*, A.ROWID FROM carteira a 
WHERE a.nr_carteira IN ('8650001976414001');

SELECT A.*, A.ROWID FROM carteira a 
WHERE a.nr_carteira IN ('0370000016901315');


SELECT c.* FROM CARTEIRA C
WHERE rownum <= 20
and c.sn_carteira_ativo = 'N'
and c.sn_titular = 'S'
AND to_char(C.DT_INTEGRA, 'MM/YYYY') between '05/2019' and '07/2019'
      
