select * from pw_documento_clinico where cd_documento_clinico in (17097111,17313715,17097023);
--4125(DJSILVA) - Trocado por 189(SRESSIO)


select * from pw_documento_clinico where cd_documento_clinico in (19720011);
--4134(JULMARTINS) - Trocado por 3008 (JOSEJUNIOR)

select * from pw_documento_clinico where cd_documento_clinico in (17011629, 17011610, 17011552);
--4326(CLUZ) - trocado por 68 (CRODRIGUES)

select * from pw_documento_clinico where cd_documento_clinico in (16681097, 16681110, 16681115, 16681041);
--4326(CLUZ) - trocado por 68 (CRODRIGUES)
