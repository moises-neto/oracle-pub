select f.ds_funcionalidade, p.nm_papel
  from dbacp.FUNCIONALIDADE_PAPEL t, dbacp.papel p, dbacp.funcionalidade f
 where t.cd_funcionalidade in (1, 2)
   and t.cd_papel = p.cd_papel
   and f.cd_funcionalidade = t.cd_funcionalidade
 order by 2
 
 
 
