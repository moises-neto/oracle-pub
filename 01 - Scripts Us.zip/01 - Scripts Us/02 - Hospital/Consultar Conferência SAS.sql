
SELECT s.Solsai_Pro "SOLICITA��O",
       s.Atendime Atendimento,
       s.Nm_Paciente Paciente,
       s.Produto,
       s.Horainsert "DATA/HORA CONFER�NCIA",
       s.Cd_Usuario "USU�RIO CONFER�NCIA"
  FROM CUSTOM.Saf_Conferencia s
WHERE s.Solsai_Pro = 4778669 --N�mero Solicita��o  
