SELECT r.*, r.rowid FROM ramal r
WHERE r.empresa = 'HOSPITAL'
--WHERE R.SETOR LIKE '%%'
--WHERE R.FUNCIONARIO LIKE '%%'
--And r.setor like '%SUPORTE%'
AND r.ramal LIKE '3521';
--and r.funcionario like '%LARISSA%

SELECT EMPRESA FROM RAMAL;


