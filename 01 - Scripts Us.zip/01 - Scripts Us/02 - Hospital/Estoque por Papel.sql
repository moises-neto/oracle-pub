select * from CHM_TI_PAPEL_ESTOQUE t where t.cd_papel = 228
