
--ROTINA

alter trigger DBAPS.TRG_LOGRADOURO_CEP_UNICO_BLOK disable;


CALL DBAPS.prc_mvs_importa_cep();

DBAPS.TRG_LOGRADOURO_CEP_UNICO_BLOK

DBAPS.CEP_LOGRADOUR_CEP_BAIRROS_FK


--BAIRRO
Select * From cep_bairros cb where cb.cd_bairro = 19526 for UPDATE;

Select * From cep_bairros@ormvgh cb;

------------------------------------------------------------------------
--LOCALIDADE
SELECT * From dbaps.cep_localidades c
where c.cd_localidade = 10464

select * From DBAMV.cep_localidades cl
where cl.nr_cep = 65047092
select * From DBAMV.cep_localidades@ormvgh cl;

------------------------------------------------------------------------
--LOGRADOURO SA SUS
select * From cep_logradouro_sa04_sus cls;
select * From cep_logradouro_sa04_sus@ormvgh cls;
------------------------------------------------------------------------
-- LOGRADOURO
select * From dbaps.cep_logradouros clr
Where clr.nr_cep = '18730027';



select * From dbamv.cep_logradouros clr
Where clr.nr_cep = '18730027'
for update;

select * From dbamv.cep_logradouros@ormvgh clr
where clr.nr_cep = '18730027';
------------------------------------------------------------------------
--LOGRADOURO SUS
select * From cep_logradouros_sus clsu;
select * From cep_logradouros_sus@ormvgh clsu;

------------------------------------------------------------------------
--CEP SUS
select * From cep_sus cs;
select * From cep_sus@ormvgh cs;

------------------------------------------------------------------------
--CEP UF
select * From cep_uf cf;
select * From cep_uf@ormvgh cf;







