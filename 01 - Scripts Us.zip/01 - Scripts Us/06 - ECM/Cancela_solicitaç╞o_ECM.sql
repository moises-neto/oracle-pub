declare
  v_nr_solicitacao number(10);
  v_texto          varchar2(200);
  v_ultima_tar     number(10);
  v_processo       varchar2(100);
  v_cont           number(4);
begin




  -- *********ALTERA AQUI *****************
  -- alterar estas variaveis de acordo com o caso  

  for r in (select num_proces
              from Inf$ecm.proces_workflow
             where num_proces in (
                                  
                                  --ALTERA AQUI COM A LISTA DE SOLICITA��ES!
                                  153995, 153140

                                  
                                  )) loop
  
    -- ALTERA AQUI COM O TEXTO DESEJADO! 
    v_texto := 'Processo cancelado por: Solicita��o da Ver�nica Queiroz, via chamado CH2108-4109.';
  
  -- ***************************************
  
  
  -- Daqui para baixo n�o precisa alterar mais nada!
  
  
  
    
  
    v_nr_solicitacao := r.num_proces;
    v_cont := 1;
  
    -- Selecionando o codigo de processo, de acordo com a solicita��o passada
    SELECT cod_def_proces
      into v_processo
      FROM Inf$ecm.proces_workflow
     where num_proces = v_nr_solicitacao;
  
    -- Inserindo tarefa de cancelamento
    for lst in (select *
                  from Inf$ecm.Tar_Proces
                 where num_proces = v_nr_solicitacao
                   and log_ativ = 1) loop
    
      select max(cod_tarefa) + 1 into v_ultima_tar from Inf$ecm.Tar_ctral;
    
      /*insert into Inf$ecm.Tar_Ctral
        (COD_EMPRESA,
         COD_TAREFA,
         DAT_CONCLUS_TAR,
         NUM_HRS_CONCLUS_TAR,
         DAT_CRIACAO,
         NUM_HRS_CRIACAO,
         NUM_HRS_PRAZ,
         DES_TAREFA,
         DAT_FIM_PRAZ,
         CD_MATRICULA,
         IDI_STATUS)
      values
        (1,
         v_ultima_tar,
         trunc(sysdate),
         0,
         trunc(sysdate),
         0,
         0,
         v_processo,
         null,
         'SIS',
         4 -- cancelamento
         );
    
      -- Inserindo tarefa esfor�o para o cancelamento
      insert into Inf$ecm.tar_esfor values (1, v_ultima_tar);*/
    
      -- Inserindo data de conclus�o do processo para cada tarefa em aberto.
      for ret in (select *
                    from Inf$ecm.tar_workflow
                   where num_proces = v_nr_solicitacao) loop
      
        update Inf$ecm.tar_ctral
           set dat_conclus_tar = trunc(sysdate)
         where cod_tarefa = ret.cod_tarefa
           and cod_empresa = ret.cod_empresa
           and dat_conclus_tar is null;
      
      end loop;
    
      -- Inserindo o processo de cancelamento
     /* insert into Inf$ecm.Tar_Proces
        (CD_MATRICULA,
         COD_EMPRESA,
         NUM_SEQ_MOVTO,
         NUM_PROCES,
         NUM_SEQ_TRANSF,
         LOG_ATIV,
         DAT_MSG_ATRASO_RESPONS,
         NUM_HORA_MSG_ATRASO_RESPONS,
         COD_MATR_ESCOLHID,
         NUM_SEQ_ESCOLHID,
         CD_MATRICULA_CONCLUS,
         IDI_TIP_CONCLUS,
         DAT_FIM_PRAZ,
         NUM_HORA_FIM_PRAZ,
         DAT_INIC_PRAZ,
         NUM_HORA_INIC_PRAZ,
         DAT_MSG_ATRASO_GESTOR,
         NUM_HORA_MSG_ATRASO_GESTOR,
         DAT_MSG_ATRASO_REQUISIT,
         NUM_HORA_MSG_ATRASO_REQUISIT,
         IDI_STATUS,
         DAT_CONCLUS_TAR,
         NUM_HORA_CONCLUS_TAR,
         DSL_OBS_TAR,
         LOG_ASSINADO,
         DS_ARQUIVO_HASH,
         DS_NOME_ARQUIVO_ASS,
         DAT_MSG_EXPIRAC_RESPONS,
         NUM_HORA_MSG_EXPIRAC_RESPONS,
         DAT_MSG_EXPIRAC_GESTOR,
         NUM_HORA_MSG_EXPIRAC_GESTOR,
         DAT_MSG_EXPIRAC_REQUISIT,
         NUM_HORA_MSG_EXPIRAC_REQUISIT)
      Values
        ('SIS',
         1,
         lst.num_seq_movto + v_cont,
         lst.num_proces,
         lst.num_seq_transf,
         0,
         null,
         0,
         null,
         0,
         null,
         0,
         null,
         0,
         null,
         0,
         null,
         0,
         null,
         0,
         4,
         trunc(sysdate),
         lst.num_hora_conclus_tar,
         v_texto,
         0,
         null,
         null,
         null,
         0,
         null,
         0,
         null,
         0);*/
      
      v_cont := v_cont + 1;
    
      -- Muda para zero, porque quando esta 1 siginfica que o processo esta parado neste passo
      update Inf$ecm.Tar_Proces
         set log_ativ = 0
       where num_proces = v_nr_solicitacao;
    
      -- Muda para zero, porque quando esta 1 siginfica que o processo esta parado neste passo
      update Inf$ecm.proces_workflow
         set log_ativ = 0
       where num_proces = v_nr_solicitacao;
    
    end loop;
  
  end loop;

end;
