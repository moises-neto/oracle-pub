select a.*, rowid from inf$ecm.colaborador a
where Upper(a.login) like Upper('%lperez%')
or Upper(a.login) like Upper('%carodrigues%')

sELECT p.*, rowid from inf$ecm.grupo_colaborador p
where p.cd_matricula in ('525154', '2004266')

sELECT a.nm_colaborador from inf$ecm.grupo g, inf$ecm.grupo_colaborador p, inf$ecm.colaborador a
where p.cd_grupo = g.cd_grupo
and a.cd_matricula = p.cd_matricula
and g.cd_grupo in ('redcred')

sELECT * from inf$ecm.grupo g
where g.ds_grupo like '%red%'


