select a.login, DECODE(A.ID_ATIVO, 1, 'Ativo')
  from inf$ecm.colaborador a, dbasgu.usuarios@ormvpr u
 where upper(u.cd_usuario) = upper(a.login)
   and a.id_ativo = 1
  -- and a.e_mail is null
  -- and u.ds_email is not null
   and u.sn_ativo = 'N' 
