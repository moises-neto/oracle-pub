select a.cd_matricula, a.Nm_Colaborador, a.e_mail ,rowid from inf$ecm.colaborador a
where a.login = 'jovieira'

sELECT * FROM ALL_TABLES T
WHERE T.OWNER = UPPER('inf$ecm')

Select * from inf$ecm.vw_usu_cadastros u
where rownum <= 20


select * from 
